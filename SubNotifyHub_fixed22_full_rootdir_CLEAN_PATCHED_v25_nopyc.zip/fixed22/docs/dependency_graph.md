# Core Module Dependency Graph

```mermaid
graph TD
    subgraph core[Core Submodules]
        logging[logging]
        http[http]
        cache[cache]
        storage[storage]
        plugins[plugins]
        exceptions[exceptions]
    end

    %% Internal dependencies
    cache --> http
    cache --> logging
    cache -.->|circular| storage
    exceptions --> logging
    http --> exceptions
    http --> logging
    plugins --> logging
    storage -.->|circular| cache
    storage --> logging
```
