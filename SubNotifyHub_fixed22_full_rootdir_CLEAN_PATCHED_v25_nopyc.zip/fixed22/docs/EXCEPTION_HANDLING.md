# 异常处理指南

本文档描述项目中统一的异常处理机制，包括异常类别、处理工具、恢复策略和最佳实践。

## 目录

- [异常类别](#异常类别)
- [处理工具](#处理工具)
- [恢复策略](#恢复策略)
- [专用处理器](#专用处理器)
- [异常指标](#异常指标)
- [最佳实践](#最佳实践)
- [迁移指南](#迁移指南)

## 异常类别

所有应用异常继承自 `AppException` 基类，位于 `core/exceptions.py`：

```python
from core.exceptions import (
    AppException,       # 基类
    NetworkError,       # 网络相关错误
    DatabaseError,      # 数据库相关错误
    ValidationError,    # 数据验证错误
    ConfigurationError, # 配置错误
    ExternalServiceError, # 外部服务错误
)
```

### 异常映射

第三方异常会自动映射到内部异常类别：

```python
from core.exception_mapping import map_exception

try:
    # 可能抛出 httpx.TimeoutException
    response = await client.get(url)
except Exception as e:
    app_exc = map_exception(e)  # 返回 NetworkError
```

## 处理工具

### @safe_call 装饰器

用于包装函数，自动捕获和处理异常：

```python
from core.safe_call import safe_call

# 基本用法
@safe_call(default=None)
def fetch_data():
    return risky_operation()

# 指定捕获的异常类型
@safe_call(catch=(ValueError, KeyError), default={})
def parse_config(data):
    return json.loads(data)

# 自定义错误回调
def on_error(exc):
    send_alert(str(exc))

@safe_call(on_error=on_error, default=[])
async def fetch_items():
    return await api.get_items()
```

**参数说明：**
- `catch`: 要捕获的异常类型元组，默认 `(Exception,)`
- `default`: 异常时的返回值
- `on_error`: 异常时的回调函数
- `log_level`: 日志级别，默认 `"error"`
- `include_traceback`: 是否包含堆栈跟踪，默认 `True`

### safe_context 上下文管理器

用于包装代码块：

```python
from core.safe_context import safe_context, async_safe_context

# 同步用法
result = []
with safe_context(catch=(ValueError,), context_name="parse_items"):
    result = parse_items(data)

# 异步用法
async with async_safe_context(catch=(httpx.HTTPError,), context_name="fetch"):
    data = await client.get(url)
```

## 恢复策略

### 重试策略

```python
from core.recovery import RetryStrategy, with_retry

# 使用装饰器
@with_retry(max_retries=3, backoff_base=1.0)
async def fetch_with_retry():
    return await unreliable_api()

# 手动使用
strategy = RetryStrategy(max_retries=3, backoff_base=1.0, backoff_max=30.0)
delay = strategy.get_delay(attempt=2)  # 计算第 2 次重试的延迟
```

### 熔断器

```python
from core.recovery import CircuitBreaker

breaker = CircuitBreaker(failure_threshold=5, recovery_timeout=30.0)

async def call_external_service():
    if not breaker.can_execute():
        raise ExternalServiceError("Circuit breaker is open")
    
    try:
        result = await external_api()
        breaker.record_success()
        return result
    except Exception as e:
        breaker.record_failure()
        raise
```

## 专用处理器

### 数据库异常处理

```python
from core.db_exception_handler import (
    handle_db_exception,
    should_retry_db_error,
    with_db_retry,
)

# 检查是否应该重试
if should_retry_db_error(exc):
    # 连接错误，可以重试
    pass

# 使用装饰器自动重试
@with_db_retry(max_retries=3)
def execute_query(conn, sql):
    return conn.execute(sql)
```

### HTTP 异常处理

```python
from core.http_exception_handler import (
    handle_http_exception,
    should_retry_http_error,
    with_http_retry,
)

# 检查是否应该重试
if should_retry_http_error(exc):
    # 超时或 5xx 错误，可以重试
    pass

# 使用装饰器自动重试
@with_http_retry(max_retries=3)
async def fetch_api_data(client, url):
    return await client.get(url)
```

## 异常指标

### 记录异常

```python
from core.exception_metrics import record_exception

try:
    risky_operation()
except Exception as e:
    record_exception(category="network", module=__name__)
    raise
```

### 查询指标

```python
from core.exception_metrics import get_exception_counts, get_exception_summary

# 获取计数
counts = get_exception_counts()
# 返回: {"network": {"module.name": 5}, "database": {"other.module": 2}}

# 获取摘要
summary = get_exception_summary()
# 返回包含阈值检查的详细信息
```

### API 端点

- `GET /api/metrics/exceptions` - 获取异常摘要
- `GET /api/metrics/exceptions/counts` - 获取详细计数

## 最佳实践

### 1. 捕获具体异常

```python
# ❌ 不推荐
try:
    data = fetch_data()
except Exception:
    pass

# ✅ 推荐
try:
    data = fetch_data()
except (httpx.TimeoutException, httpx.ConnectError) as e:
    logger.warning("Network error", error=str(e))
    data = default_data
```

### 2. 保留异常上下文

```python
# ❌ 不推荐
except ValueError:
    raise RuntimeError("Failed")

# ✅ 推荐
except ValueError as e:
    raise RuntimeError("Failed to parse") from e
```

### 3. 使用结构化日志

```python
# ❌ 不推荐
logger.error(f"Error: {e}")

# ✅ 推荐
logger.error("Operation failed", error=str(e), context={"id": item_id})
```

### 4. 区分可恢复和不可恢复错误

```python
# 可恢复：网络超时、临时服务不可用
# 不可恢复：配置错误、数据完整性错误

if should_retry_http_error(exc):
    # 重试
    pass
else:
    # 记录并传播
    raise
```

## 迁移指南

### 从 `except Exception: pass` 迁移

```python
# 旧代码
try:
    result = risky_operation()
except Exception:
    pass

# 新代码 - 方式 1：使用 safe_call
@safe_call(catch=(SpecificError,), default=None)
def safe_operation():
    return risky_operation()

# 新代码 - 方式 2：使用 safe_context
with safe_context(catch=(SpecificError,), context_name="operation"):
    result = risky_operation()
```

### 从 `except Exception: logger.exception` 迁移

```python
# 旧代码
try:
    result = risky_operation()
except Exception:
    logger.exception("Failed")
    result = None

# 新代码
@safe_call(
    catch=(SpecificError,),
    default=None,
    log_level="error",
    include_traceback=True
)
def safe_operation():
    return risky_operation()
```

### 扫描工具

使用扫描工具查找需要迁移的代码：

```bash
python -m tools.scan_swallowed_exceptions
```

输出示例：
```
=== 静默异常扫描报告 ===
扫描时间: 2024-01-15 10:30:00

[HIGH] core/cache.py:45
  except Exception:
      pass

[MEDIUM] integrations/api.py:123
  except Exception:
      logger.exception("API call failed")
```
