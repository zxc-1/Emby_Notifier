# 数据库连接池迁移指南

## 概述

本项目实现了 SQLite 数据库连接池，支持同步和异步两种模式，提供连接复用、健康检查和优雅关闭功能。

## 核心模块

- `core/db/pool_config.py` - 连接池配置
- `core/db/sync_pool.py` - 同步连接池
- `core/db/async_pool.py` - 异步连接池
- `core/db/pool_manager.py` - 全局池管理器

## 配置

### 环境变量

| 变量名 | 默认值 | 说明 |
|--------|--------|------|
| `DB_POOL_MIN_SIZE` | 0 | 最小连接数 |
| `DB_POOL_MAX_SIZE` | 10 | 最大连接数 |
| `DB_POOL_MAX_IDLE_TIME` | 300.0 | 空闲连接最大存活时间（秒） |
| `DB_POOL_TIMEOUT` | 30.0 | 连接超时时间（秒） |

### 代码配置

```python
from core.db.pool_config import PoolConfig

config = PoolConfig(
    min_size=0,
    max_size=10,
    max_idle_time=300.0,
    connection_timeout=30.0,
)
```

## 使用方法

### 同步连接池

```python
from core.db.pool_manager import get_sync_pool

# 获取连接池（自动创建或复用）
pool = get_sync_pool("/path/to/db.sqlite")

# 方式 1：上下文管理器（推荐）
with pool.connection() as conn:
    conn.execute("SELECT * FROM users")
    # 自动提交和释放连接

# 方式 2：手动管理
conn = pool.acquire()
try:
    conn.execute("SELECT * FROM users")
    conn.commit()
finally:
    pool.release(conn)
```

### 异步连接池

```python
from core.db.pool_manager import get_async_pool

# 获取连接池
pool = get_async_pool("/path/to/db.sqlite")

# 方式 1：上下文管理器（推荐）
async with pool.connection() as conn:
    await conn.execute("SELECT * FROM users")

# 方式 2：手动管理
conn = await pool.acquire()
try:
    await conn.execute("SELECT * FROM users")
    await conn.commit()
finally:
    await pool.release(conn)
```

## 监控

### 指标端点

访问 `/api/metrics/db-pools` 获取连接池统计：

```json
{
  "sync_pools": {
    "/data/tg_bot.db": {
      "active": 2,
      "idle": 3,
      "total_created": 10,
      "total_reused": 150
    }
  },
  "async_pools": {},
  "summary": {
    "total_sync_pools": 1,
    "total_async_pools": 0,
    "total_active_connections": 2,
    "total_idle_connections": 3
  }
}
```

### 日志

连接池耗尽时会记录警告日志：

```
WARNING - 连接池已耗尽 - active=10, max_size=10, db_path=/data/tg_bot.db
```

## 迁移步骤

### 从直接连接迁移

**迁移前：**
```python
import sqlite3

def get_data():
    conn = sqlite3.connect("/data/app.db")
    try:
        result = conn.execute("SELECT * FROM data").fetchall()
        return result
    finally:
        conn.close()
```

**迁移后：**
```python
from core.db.pool_manager import get_sync_pool

def get_data():
    pool = get_sync_pool("/data/app.db")
    with pool.connection() as conn:
        return conn.execute("SELECT * FROM data").fetchall()
```

### 从 thread-local 连接迁移

**迁移前：**
```python
import threading
_tls = threading.local()

def _conn():
    if not hasattr(_tls, 'conn'):
        _tls.conn = sqlite3.connect("/data/app.db")
    return _tls.conn
```

**迁移后：**
```python
from core.db.pool_manager import get_sync_pool

def _get_pool():
    return get_sync_pool("/data/app.db")

# 使用上下文管理器
with _get_pool().connection() as conn:
    conn.execute("...")
```

## 关闭连接池

应用关闭时会自动关闭所有连接池（通过 lifespan）。

手动关闭：

```python
from core.db.pool_manager import close_all_pools, close_all_async_pools

# 同步池
close_all_pools(timeout=5.0)

# 异步池
await close_all_async_pools(timeout=5.0)
```

## 注意事项

1. **连接复用**：连接池会自动复用空闲连接，减少连接创建开销
2. **健康检查**：获取连接时会自动检查连接健康状态
3. **事务管理**：使用 `connection()` 上下文管理器时，正常退出自动提交，异常时自动回滚
4. **线程安全**：同步连接池是线程安全的
5. **协程安全**：异步连接池是协程安全的
