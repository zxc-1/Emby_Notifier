# Docker 构建指南

## 概述

本项目使用 Docker 多阶段构建，将构建过程分为 Builder 和 Runtime 两个阶段，以减小镜像体积、提高安全性。

## 快速开始

### 构建镜像

```bash
# 默认构建
docker build -t subnotifyhub:latest .

# 指定 Python 版本
docker build --build-arg PYTHON_VERSION=3.11 -t subnotifyhub:py311 .

# 指定端口
docker build --build-arg APP_PORT=9000 -t subnotifyhub:custom .
```

### 运行容器

```bash
# 基本运行
docker run -d -p 8000:8000 --name subnotifyhub subnotifyhub:latest

# 带数据卷
docker run -d -p 8000:8000 \
  -v /path/to/media:/media \
  -v subnotifyhub_data:/data \
  --name subnotifyhub subnotifyhub:latest
```

### 使用 docker-compose

```bash
# 启动服务
docker-compose up -d

# 查看日志
docker-compose logs -f

# 停止服务
docker-compose down
```

## 构建参数

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `PYTHON_VERSION` | 3.12 | Python 版本 |
| `APP_PORT` | 8000 | 应用端口 |

## 多阶段构建说明

### Builder 阶段

- 基础镜像：`python:3.12-slim`
- 安装 pip 依赖到独立目录 `/build/deps`
- 不包含在最终镜像中

### Runtime 阶段

- 基础镜像：`python:3.12-slim`
- 从 Builder 复制依赖
- 创建非 root 用户 `appuser`
- 配置健康检查

## 安全特性

1. **非 root 用户**：容器以 `appuser` (UID 1000) 运行
2. **最小依赖**：仅包含运行时必需的系统包
3. **无构建工具**：最终镜像不包含 gcc、make 等

## 健康检查

容器配置了健康检查：

- **端点**：`/health`
- **间隔**：30 秒
- **超时**：10 秒
- **重试**：3 次
- **启动等待**：5 秒

查看健康状态：

```bash
docker inspect --format='{{.State.Health.Status}}' subnotifyhub
```

## 故障排除

### 构建失败

1. **依赖安装失败**
   ```bash
   # 检查 requirements.txt 语法
   pip check -r requirements/requirements.txt
   ```

2. **网络问题**
   ```bash
   # 使用国内镜像
   docker build --build-arg PIP_INDEX_URL=https://pypi.tuna.tsinghua.edu.cn/simple -t subnotifyhub:latest .
   ```

### 容器启动失败

1. **端口冲突**
   ```bash
   # 检查端口占用
   netstat -tlnp | grep 8000
   ```

2. **权限问题**
   ```bash
   # 检查数据卷权限
   ls -la /path/to/data
   ```

### 健康检查失败

1. **检查应用日志**
   ```bash
   docker logs subnotifyhub
   ```

2. **手动测试端点**
   ```bash
   docker exec subnotifyhub curl -f http://localhost:8000/health
   ```

## 镜像大小对比

| 构建方式 | 预估大小 |
|----------|----------|
| 单阶段构建 | ~500MB |
| 多阶段构建 | ~300MB |

## 推送到 Docker Hub

```bash
# 登录
docker login

# 标记镜像
docker tag subnotifyhub:latest username/subnotifyhub:latest

# 推送
docker push username/subnotifyhub:latest
```
