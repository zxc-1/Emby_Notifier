## 1.6.16.0 (2026-01-08)

- P0: Telegram 429 限流“根治”：解析 `parameters.retry_after` 并透传到 `RetryableNotifyError.retry_after`；worker backoff 将采用 max(retry_after, 指数退避)。
- P0: 多进程/多 worker 安全：preflight 更强 workers 探测（WEB_CONCURRENCY/UVICORN_CMD_ARGS/GUNICORN_CMD_ARGS），并在日志中明确 APP_ROLE 风险；recent_entries 与 poster_cache 增加跨进程文件锁（避免写入/读取竞态）。
- P1: forward_bridge MediaHelp token 状态去全局变量化：引入 `MediaHelpAuthState`，运行时状态绑定到 AppContext，并通过 `forward_bridge.http_client.__getattr__` 保持兼容。
- P1: compat shim 去噪：core/bootstrap_* shim 默认不再抛 DeprecationWarning（仅在 SHOW_DEPRECATION_WARNINGS=1 时提示）。
- P1: 配置校验增强：Settings.validate_required 增加 TG token/chat/webhook 模式必要字段校验，启动期 fail-fast。

## 1.6.16.2 (2026-01-08)

- UI: 管理后台 Web UI 进一步拆分 JS：拆成 state/tabs/auth/save_flow/ui_prefs/inline_hints/integrations，多文件按需维护。
- UI: admin_settings 页面外部脚本统一改为 `defer`，确保 DOM 完整解析后再执行（避免脚本在 HTML 中段执行导致后续 modal 元素拿不到）。


## 1.6.15.0 (2026-01-08)

- P0: 修复 AppContext dataclass 字段顺序错误（默认值字段在前导致 import 期 TypeError），并将关键依赖收敛为 ports 类型（http/tmdb/matcher/115/kv/blob/share_repo）。
- P1: worker.enqueue 返回 EnqueueResult（OK/DUPLICATE/QUEUE_FULL/STOPPED/ERROR），上游 webhook/mediahelp 端点按状态更精确返回。
- P1: 115 share 根目录存在文件但无视频且含目录时，不再误选 README/NFO 终止扫描，改为继续 BFS 进入子目录。
- P1: tg_bot Telegram API 全量 ports 化：业务代码改为 import ports.tg_bot_api（保留函数式调用兼容）。
- Fix: 补齐 compat shim：core.bootstrap_wiring 增加 init_persistence/start_worker；dispatch 增加 preflight_validate_dispatch。

## 1.6.14.0 (2026-01-08)

- P1: tg_bot URL 特性注册表化：新增 `tg_bot.app.url_handler_registry`，支持 feature 以 `register_url_handlers` 注册 URL 处理器（例如 douban hotlist 预览），router 不再硬编码 try-import。
- P1: CI/本地门禁补齐：将 `tools.check_settings_access` 加入 pre-commit，防止深层模块直接 import `settings.runtime.get_settings` 导致不可注入/难测。
- Fix: 版本单一事实源一致化：`pyproject.toml` version 与 `core/version.py` 对齐。

## 1.6.13.6 (2026-01-08)

### P2: 入口编排注册表化（source -> parser -> pipeline -> renderer -> channels）
- 新增 `notifier.sources`：Source Parser Registry（内置 emby 解析器；支持插件注册新 source）
- 新增 `notifier.service.event_handler_registry`：按 (source,event) 选择处理器（支持插件覆盖/扩展）
- 新增 `notifier.service.dispatch.process_inbound`：统一入口调度（默认回落到历史 pipeline 行为）
- `bootstrap.build_handler` 改为使用 dispatch（并在启动时吸收 `plugin_registry.data` 的 parsers/handlers）
- `ingest_emby_webhook` 入队时补齐 `_source=emby` / `_kind=webhook`，便于后续多源扩展与可观测性
- `PIPELINE_STEPS_BY_SOURCE`：支持按 source 覆盖 step chain（保留全局 `PIPELINE_STEPS` 默认）

## 1.6.13.6 (2026-01-08)

- P2: 入口编排升级为注册表链路：source -> parser -> pipeline(steps) -> renderer -> channels。
- 新增 notifier/sources 源解析 registry（内置 emby 解析器，插件可扩展）。
- 新增 notifier/service/dispatch + handler registry（按 source/event 路由，支持插件注入）。
- 支持 PIPELINE_STEPS_BY_SOURCE 为不同 source 配置不同 pipeline steps；启动期 preflight 校验。
- webhook 入队 payload 增加 _source/_kind 字段，便于追踪与分流。

## 1.6.13.5 (2026-01-08)

- P2: 模板渲染 registry 化 + 配置驱动：
  - 新增 notifier.templates.registry：可通过 `@register("name")` 注册 render_notification 渲染器。
  - `notifier.templates.renderer` 升级为 Proxy：每次渲染按 `TEMPLATE_RENDERER` 选择实现（默认 zh_cn），便于热重载/插件扩展。
  - Settings 新增 `TEMPLATE_RENDERER`。
- P2: TG Bot 功能模块配置化：
  - Settings 新增 `TG_BOT_FEATURES` / `TG_BOT_FEATURES_EXTRA` / `TG_BOT_FEATURES_DISABLED`。
  - tg_bot.app.feature_registry 不再硬编码功能列表，完全由配置控制（保持原有默认顺序）。

## 1.6.13.4 (2026-01-08)

- P1: Settings 依赖方向收敛：
  - bootstrap 启动期绑定 ports.settings_provider（set_settings_provider(get_settings)），为深层模块提供稳定注入入口。
  - api/admin/tg_bot 全量切换为 `from ports.settings_provider import get_settings`（仍保留 settings.runtime.reload_settings 用于热重载）。
  - 结果：跨层调用减少对 settings.runtime 的静态依赖，后续可进一步将 settings 视图化并注入 AppContext。

## 1.6.13.3 (2026-01-08)

- P0: compat 隔离“根治”：
  - core/bootstrap_* 兼容 shim 直接转发到 bootstrap/*（不再经由 compat），并加 DeprecationWarning。
  - tools/check_layering + tools/check_layering_imports 增加全局门禁：除 compat/** 外禁止 import compat（防止兼容层渗透到新代码）。
  - tools/check_layering_imports 扩展覆盖 integrations/notifier/tg_bot 等层级，边界更清晰。
- Fix: tools/build_release 先跑 guardrails 再创建 dist/，避免因 dist 属于禁入目录导致“tree not clean”误报。

## 1.6.13.2 (2026-01-08)

- P1: TMDB 端口语义化：ports.tmdb 从 `get_json(path, ...)` 升级为 `search/fetch_detail/find_by_external_id/alias_titles` 等高层 API；notifier/tmdb_client 改为调用语义化方法（避免在 feature 层拼 REST path）。

## 1.6.13.1 (2026-01-08)

- P1: 纯逻辑迁移到 domain：tmdb_match 的 Candidate/normalize/fingerprint/similarity/scoring/autopick 全部下沉至 `domain/tmdb_match/**`；`integrations/tmdb_match/*` 仅保留薄 wrapper（保持旧 import 路径不变，同时允许 settings 控制 normalize 行为）。
- P1: 115 share URL 纯逻辑迁移：`domain/share115/url.py`；`integrations/share115/share115_url.py` 变为 wrapper（默认 host 仍由 SHARE115_DEFAULT_HOST 控制）。
- P2: CI 强化：新增 `tools.check_layering_imports` step，双门禁防止分层回归。
- P2: Settings 文档化自动化：新增 `tools.export_settings_md`，从 pydantic Settings 模型生成/校验 `SETTINGS.md` 的自动引用段（CI 中 `--check`）。

## 1.6.13.0 (2026-01-08)

- P1: share_resolver 完成 ports 化：application/usecases/share_resolver/** 不再直接 import integrations（TMDB matcher + 115 share 通过 AppContext 端口注入）。
- P1: 新增 ports.tmdb_matcher / ports.share115 以及对应 integrations 适配器（DefaultTmdbMatcher / DefaultShare115Gateway）。
- P2: tools/check_layering 收紧：application 禁止 import integrations（防回归）。
- 修复：tools/check_layering 误判 integrations 内部自引用（integrations -> integrations）的问题。

## 1.6.12.64 (2026-01-08)

- P1: 外部依赖 ports 化增强：新增 ports.http_client + integrations.httpx_adapter，notifier 层不再直接 import httpx。
- P1: TMDB 访问统一走 ports：新增 ports.tmdb + integrations.tmdb_gateway，通过 ctx.tmdb_gateway 调用。
- P1: notifier 渠道注册统一走 core.plugin_loader：新增 notifier.plugins.builtin_notifiers（默认启用），build_notifier_chain 从 plugin_registry 注入渠道。
- P2: 配置 schema version：新增 CONFIG_SCHEMA_VERSION=1，并在 preflight 里做启动期校验。
- P2: 更严格分层规则：启动期扫描 notifier/* 直接 import integrations/* 并在 strict 模式下失败。

## 1.6.12.63 (2026-01-07)

- P0: 统一 AppContext 访问入口：core.runtime_ctx 改为 ports.app_context 的兼容 shim，避免双 ContextVar“分裂脑”。
- P0: webhook 入口瘦身：API 仅负责验签/解析 JSON；去重/trace 注入/入队/指标统计收敛到 application.usecases.ingest_emby_webhook（并复用 notifier.dedup_key 的统一语义）。
- P0: 运行时状态收拢到 ctx：recent_* 统计 deque 与 kv/blob store 由 build_context_and_expose 统一创建并挂载到 AppContext；core.stores 优先从 ctx 取，减少模块级单例。

## 1.6.12.62 (2026-01-07)

- P0: ports.contracts：为核心运行时对象补齐 Protocol 约束（提升类型提示/维护性，避免反向依赖）。
- P0: ports.settings_provider：引入 contextvars 任务级绑定 + 进程级 fallback，减少隐式全局耦合。
- P1: tools.check_layering_imports + pre-commit hook：静态扫描层级越界 import（防止架构退化）。
- P1: contract tests：补齐 ports.app_context / ports.settings_provider 契约测试。

## 1.6.12.61 (2026-01-07)

- P0: 新增 ports.app_context：用 contextvars + 进程级 fallback 暴露 AppContext，后台任务/测试可在不依赖 FastAPI 的情况下获取 ctx。
- P0: share_resolver_repo 优先从当前 ctx 读取 adapter（ctx.share_resolver_repo），仅在 ctx 不可用时回退到进程级单例；减少全局状态耦合。
- P1: api/deps.get_ctx 增加 ports.app_context 回退路径，避免极端启动/扩展场景下误报 CONTEXT_NOT_READY。

## 1.6.12.51

- P0: 根治 application -> notifier 反向依赖：RecentEntries 依赖收敛到 domain（NotificationContent/episode_agg/extract_code 迁移至 domain.utils，并保留 notifier shim）。
- P0: core 进一步纯净化：bootstrap_* 全量迁出至顶层 bootstrap/（core/bootstrap_* 仅保留兼容 shim）。
- P0: 分层守卫升级：tools.check_layering 新增 application 规则，阻止 application import notifier/tg_bot/api/admin。

## 1.6.12.41

- P0: poster_cache 缓存清理默认策略更新：7天 / 200MB / 500张，并补齐 PosterCache.ensure_web_cover()（recent_entries UI 可用）。
- P1: notifier/service/pipeline.py 拆为 pipeline_extract/pipeline_enrich/pipeline_render/pipeline_covers/pipeline_content，pipeline.py 保留兼容 facade。
- P1: notifier/service/enrich.py 拆为 enrich_covers/enrich_region_lang/enrich_merge/enrich_fetch，enrich.py 保留兼容 facade。
- P1: core/poster_cache.py 拆为 poster_cache_keys/poster_cache_fetch/poster_cache_fs/poster_cache_evict + poster_cache 聚合。
- P1: forward_bridge/http_client.py 拆为 auth/client/endpoints/errors，http_client.py 保留兼容 facade。

## 1.6.12.40

- P0: forward_bridge/subscriptions_core.py 拆分：新增 sub_models/seasons/mh_api/tmdb_lookup/sub_cache/sub_ops，subscriptions_core 保留为兼容 facade（旧 import 路径不变）。
- P2: douban_hotlist 拆分补齐：新增 fetcher.py 统一网络抓取；subject meta 解析与标题规范化迁移至 parser.py；resolver/backfill 改为薄编排。

## 1.6.12.38

- P0: Hotlist UI 根治拆分：tg_bot/features/hotlist/ui.py 拆为 ui_handlers/ui_pages/ui_keyboard/ui_format/snapshot，并保留 ui.py 作为兼容 facade（旧 import 路径不变）。

## 1.6.12.37

- P0: Telegram notifier 按职责拆分：新增 notifier.telegram.{telegram_format,telegram_transport,telegram_media,telegram_notifier}；notifier.notifiers.telegram 保留为兼容 shim（内置 registry import 与单测导入路径不变）。

## 1.6.12.36

- P0: 清理测试与运行时弃用/噪声 warning：forward_bridge 改为 lifespan；webhook/polling 改用 tg_bot.app.dispatcher（不再 import tg_bot.service）；pytest 过滤已知第三方噪声告警（ddtrace/psutil, python-multipart）。

## 1.6.12.35

- P0: 最终分层闭环：移除 core/services/tg_polling.py（core 不再依赖 tg_bot）；TG polling 管理服务迁至 tg_bot.services.TgPollingService，并由 bootstrap_lifespan 装配。
- P1: 分层守卫进一步收紧：core/services 仅允许依赖基础设施，不允许 import notifier/tg_bot/api/admin。

## 1.6.12.34

- P0: core 纯净化：PosterCache/RecentEntries 不再从 core 反向依赖 notifier；RecentEntriesStore 迁至 application.recent_entries，PosterCache 直接使用 core.http_clients。
- P0: 可重复构建：新增 requirements.lock 与 requirements-dev.lock，并在 requirements-dev.txt 通过 -c 约束间接依赖版本。
- P1: 分层守卫升级：tools.check_layering 现在会阻止 core 非 wiring 文件 import notifier/tg_bot/api/admin。

## 1.6.12.33

- P0: 分层根治：notifier 不再直接 import integrations；Telegram outbound 通过 ports.telegram + integrations.telegram_client.TelegramBotCaller 适配器注入。
- P1: 插件协议：新增 core.plugin_api.PLUGIN_API_VERSION，plugin_loader 支持版本 gate（strict 模式缺失/不匹配将 fail）。
- P1: 错误模型：新增 domain/errors.py 与 application/errors.py，并在 bootstrap_app_factory 中按错误类型映射到一致的 JSON 错误响应（含 trace_id）。
- P2: 测试结构：tests 目录拆分为 unit/contract/integration，snapshot 工具保持不变。
- P2: core/context 解耦：移除对 notifier 的直接依赖，避免 core 反向引用 feature layer。

## 1.6.12.32

- P0: 依赖稳定性：requirements.txt 改为 pin 版本（避免上游漂移导致随机回归）；requirements-dev.txt 引入 -r requirements.txt，CI 同步安装 runtime+dev。
- P1: CI 一致性：actions/setup-python 统一到 Python 3.12（与 pyproject requires-python 对齐），并新增配置/分层/发布洁净度 guardrails。
- P1: Release 洁净度：新增 tools.check_tree_clean（禁止 pyc/__pycache__/cache 等进入仓库/发布），并提供 tools.build_release 一键生成 nopyc tarball。
- P2: 可观测性：core.http_retry 日志补充 trace_id，方便跨调用链排查。

## 1.6.12.24

- P0: 修复 Admin TG Bot 设置保存（JSON/AJAX）成功分支仍同步调用 `reload_settings()` 的问题：改为 `await asyncio.to_thread(reload_settings)`，避免阻塞事件循环。
- P1: core.fs.dump_env_file：当目标 .env 不存在时，完成首次写入后直接 return（减少一次多余的读写与潜在权限/并发边界风险）。
- P1: 版本号统一：core/version.py 与 pyproject.toml 同步为 1.6.12.24。

## 1.6.12.21

- P0: 修复 core.fs.dump_env_file 在 chmod 失败时错误 return，导致 .env 重写被中断的问题（现在 chmod 失败只记录/忽略，不影响写入）。
- P0: 版本号单一来源修正：core/version.py 与 pyproject.toml 统一为 1.6.12.21。
- P1: 配置层解耦：Settings 移至顶层 settings/ 包（settings.all + settings.runtime），避免 core/api 反向依赖 notifier；notifier/config.py 与 notifier/settings/* 保留兼容 shim。
- P1: 去重键逻辑收口：新增 notifier/dedup_key.py，worker 入队去重 key 统一由纯函数构建，减少复制粘贴漂移。

## 1.6.12.20

- 进一步整理运行态配置：ENV_PATH 读取统一收口到 core.runtime_env.get_env_path（settings/debug/env_store/preflight/cli）。
- env_store 语义统一：新增 env_path()/update_env_file()；保留 env_local_path()/update_env_local() 作为兼容 wrapper（不再推荐使用）。
- preflight/cli 去重：新增 core.preflight_helpers，统一可写性检查；路径/多 worker 开关改走 runtime_env getter。
- logging getenv 收口：NO_COLOR/LOG_COLOR/LOG_FILE/ACCESS_LOG 等改由 runtime_env 提供，减少散落读取。

## 1.6.12.12

- P2: HTTP responses now include X-Trace-Id; request-scoped trace_id is also stored on request.state for correlation.
- P2: Global unhandled exception handler returns trace_id (and redacted error info when DEBUG_ENABLE_DEBUG_API enabled).
- P2: Outbound httpx requests automatically inject X-Trace-Id when trace_id is present.
- P2: Added debug endpoints:
  - GET /debug/config (redacted effective settings + origins: ENV/.env/.env.local/DEFAULT)
  - GET /debug/deadletter (list + tail summary)


## 1.6.12.11

- P1: plugin loader now supports explicit register(registry, app, settings) protocol with backward-compatible side-effect imports.
- P1: added PluginRegistry for routers and lifecycle hooks.
- P1: introduced ports/ package and migrated storage imports to ports.stores.

## v1.6.12.10

### P0 (maintenance / extensibility / troubleshooting)
- 拆分启动逻辑：`core.bootstrap` 变为稳定入口，核心实现拆到 `core.bootstrap_app_factory` / `core.bootstrap_lifespan` / `core.bootstrap_wiring` / `core.bootstrap_preflight`。
- 运行时状态收敛：新增 `core.state_compat`，以 `AppContext` 为主，按需在 `app.state` 暴露兼容字段；API/页面端优先走 ctx。
- 拆分配置：大体量 Settings 移至 `notifier/settings/all.py`，`notifier/config.py` 仅保留 dotenv+缓存与对外 API。
- 拆分 worker：死信/重试/类型拆到 `notifier.worker_deadletter` / `notifier.worker_retry` / `notifier.worker_types`，主 worker 逻辑更聚焦。

## v1.6.12.9

- Fix(热榜/包含当前 文案): 榜单头部展示不再依赖 source_tag 是否包含“热榜”，只要 source_label=榜单 就会自动置顶并剥离“（包含当前）”，彻底避免 tag 命名漂移导致回归。

## v1.6.12.8

- Fix(热榜/包含当前 文案): 新建订阅任务(mediahelp_sub_created) 通知头部统一走 _build_op_header，自动去掉榜单名末尾的“（包含当前）”。

## v1.6.12.7

- Fix(tg share pick): share 纠错/选择回调增加并发防抖（CallbackGuard）+ 提前删除 pending token，彻底避免“连点/双击”导致重复提交（重复创建订阅/重复写入映射）。
- Fix(115 offdir picker): 目录选择器的翻页/进入/上一级/根目录动作增加并发防抖，避免 stack/offset 被并发回调污染导致选错目录。

## v1.6.12.6

- Fix(tg pending pwd): pending 提取码续跑的内存缓存增加 TTL 清理 + 容量上限，避免“只发链接不发提取码”导致内存条目长期累积。
- Fix(tg outbox): outbox worker 空闲退出时会回收空队列与 last_active 记录，避免大量不同 chat_id 使用后 dict 长期增长。

## v1.6.12.5

- Fix(share explicit TMDB): 显式 tmdb_id 流在 TMDB 不可用时，优先使用同 share_code 的缓存映射 media_type，避免 TV 被默认写成 movie。
- Test(115 QR): 增加 numeric status>=3 过期态回归用例，防止再次回归到 session_not_found 假报错。

## v1.6.12.4

- Fix(115 QR login): 轮询结果优先使用 phase，并正确识别 status>=3 的过期态；过期/刷新/成功都会回收 QR session + 移除旧键盘，避免“过期却走换取 cookie -> session_not_found”的假报错。
- Fix(share explicit TMDB): 当显式 tmdb_id 未带 media_type/season 时，新增一次快速 TMDB 详情推断，避免 TV 被默认按 movie 创建订阅。

## v1.6.12.3

- Fix(TG covers): 发送图片候选顺序改为 fanart 优先（fanart_local -> fanart_url -> poster_local -> poster_url -> cover_url），避免本地 poster 存在时“短路”导致永远不发横图。

## v1.6.11.0

- Fix: version single-source-of-truth (core.version); Settings.APP_VERSION no longer drifts from package version.
- Chore: complete tg_bot/features module layout (handlers/callbacks/service/views) for all feature slices (cloud115/hotlist/http_other).

## v1.6.10.0

- Fix: tg_bot.features.mediahelp help-view import path (avoid runtime ImportError).
- Refactor: tg_bot.features.* no longer import legacy tg_bot/*_flow shims for share/cloud115.

## v1.6.9.0

- Refactor(Feature slices): 将 TG 侧 Share/MediaHelp/Account/Cloud115/HttpOther 的实现迁移到 `tg_bot.features.*` 子包（service/views/handlers/callbacks），旧的 `*_flow*.py` / `share_flow_*` / `cloud115_flow_core.py` 仅保留兼容 wrapper。
- Chore(Deprecation): 旧模块仅在 `EMBY_NOTIFIER_DEBUG_IMPORTS=1` 时发出 DeprecationWarning，避免线上噪音；新代码建议只 import `tg_bot.features.*`。

## v1.6.6.4

- Fix(DeprecationWarning): 移除对弃用模块 `tg_bot.patterns` 的引用，统一改为 `tg_bot.common.patterns`（TMDB_EXPLICIT_RE）。
- Chore(Python 口径): 以 Docker 镜像为准统一到 Python 3.12：black/ruff/mypy 目标版本更新为 3.12，并在 pyproject.toml 增加 requires-python >=3.12。
- Enh(TaskRegistry): TG polling 后台任务纳入 TaskRegistry 统一生命周期管理；Hotlist “火并忘”任务改用 create_task_logged，避免静默丢异常。
- Enh(可观测性): 增加 HTTP 请求级指标（按 route 模板/状态码统计 count + latency），可直接从 /metrics 拉取。
- Enh(PosterCache): 增加后台周期性逐出（默认 10 分钟一次，可用 POSTER_CACHE_EVICT_BG_* 调整），降低请求路径触发全量扫描造成的尾延迟。
- Security(权限收紧): admin session secret 以及 .env.local 写盘后尽量设置 0600 权限（best-effort；非 root/只读 FS 会自动降级）。

## v1.6.6.3

- Fix(时长精度): RunTimeTicks -> 毫秒改为整数除法（// 10_000），避免大 ticks 转 float 造成精度丢失或偶发 off-by-1。
- Fix(TG 文本/实体错位): 发送前统一将文本换行符归一为 \n（\r\n/\r -> \n），避免在 Windows/混合换行场景 caption 分割与 text_link entity offset 偶发错位。
- Chore(packaging): 打包时排除 .pytest_cache 等开发缓存目录，减小体积并避免无关文件污染发布包。

## v1.6.6.2

- Fix(tg callback): callback_codec.pack 在 params 为空时不再强制追加 ?v=1，避免破坏旧的 callback_data 匹配与不必要的长度膨胀。
- Fix(dedup 策略一致性): pipeline 构造 NotificationContent.media_key 时跟随 EPISODE_DEDUP_STRATEGY（与 webhook/worker 保持一致）。
- Chore(packaging): 打包前清理所有 __pycache__ 与 .pyc，确保发布包真正不含 pyc。

## v1.6.6.1

- forward_bridge/http_client.py: MediaHelp token 状态文件写入改为原子替换（避免 JSON 半写导致启动/登录异常），并尽量设置 0600 权限。
- notifier/security.py: ADMIN_PBKDF2_ITERATIONS 增加上限钳制，避免误配置导致登录/启动卡死。

## v1.6.6.0 (2026-01-03)

- Fix(配置健壮性): 统一关键 env 数值解析为“安全兜底 + 区间裁剪”，避免误配置导致启动/运行时异常（CLOUD115/PosterCache/日志等）。
- Fix(115目录/缓存): CLOUD115_FSLIST_* 的 TTL/RETRY/MAX 解析改为安全解析，避免 import 顶层 ValueError 直接炸服务。
- Fix(PosterCache/下载): POSTER_CACHE_* timeout/chunk/mime 解析在实例初始化时完成并缓存；误配置不再导致“无图/异常”。
- Fix(DEBUG 历史): DEBUG_NOTIFICATION_HISTORY_SIZE=0 现在会正确禁用历史记录（不再被当成默认 100）。
- Fix(多 Worker): 默认检测到多 worker 将 fail-fast（可通过 ALLOW_MULTI_WORKER=1 继续启动）；admin session secret 采用原子创建，降低竞态风险。
- Fix(Admin 凭据): ADMIN_PASSWORD_FILE 写入改为原子 replace，避免并发写导致文件损坏/半写入。
- Enh(日志/重试可观测性): 文件日志初始化失败会显式 warning；LOG_FILE_* 数值 env 安全解析；http_retry/share115 的 delay 日志精度提升到 0.01s。

## v1.6.5.47 (2026-01-03)

- Fix(115分享链接/绑定稳定性): 修复 share_tmdb_map 将整段 file_sig 误存为 content_hash 的历史 bug；现在仅使用稳定的 content-hash 作为主键维度，避免“改名/补标题/补提取码”导致映射重复与识别抖动。
- Fix(115分享链接/映射读取): get_mapping 读取时优先返回 strength=strong 的记录（同 share_code 下避免被后写入的 weak 记录盖掉）。
- Fix(SQLite/自动迁移): 启动时自动回填/修复旧库中的 content_hash（从 v2/v3 file_sig 中提取 content 部分），减少历史脏数据影响。
- Fix(显式TMDB绑定): 显式 tmdb_id 绑定时会尽量通过 TMDB detail 判断 media_type（避免 TV 被误写成 movie）。
- Fix(提取码不丢失): upsert_mapping 在新 receive_code 为空时不再覆盖旧 receive_code（避免“后续分享不带提取码”把已保存的提取码清空）。

## v1.6.5.46 (2026-01-03)

- Fix(TG/提取码跟随/群聊串线): pending 提取码续跑记录改为按 (chat_id, user_id) 维度存储，避免群聊里 A 发链接、B 发提取码导致误续跑。
- Fix(TG/提取码跟随/多链接歧义): 同一条消息里出现多条“缺提取码”的 115 分享链接时，不再盲目记录最后一条；改为仅在“唯一可判定”时启用自动续跑，避免误配。
- Fix(TG/提取码跟随/重启丢失): pending 记录同步写入 SQLite kv_cache（10 分钟 TTL），容器重启后用户继续发送提取码仍可续跑。
- Fix(TG/提取码识别): 支持尾随标点/包裹符（如 `8888。`、`【8888】`）与全角数字（如 `８８８８`），避免“看似发了提取码但机器人没反应”。
- Fix(/bind/内联提取码): `/bind <tmdb_id> ...` 现在会在整行文本中提取/清洗分享链接与提取码（支持 `<...>` 包裹与 `提取码:xxxx`），避免绑定后仍提示缺提取码。

## v1.6.5.45 (2026-01-03)

- Fix(115分享链接/HTML转义): `parse_share_url()` 入口新增 `html.unescape()`，修复 `?foo=1&amp;password=xxxx` 这类 URL 在提取码不在第一个参数时漏识别。
- Fix(/bind/包裹符): TG /bind 命令里如果链接被 `<>《》【】` 等包裹（如 `<https://115.com/s/...>`），现在会正确清洗后再解析。
- Fix(115分享链接/多行多链接): 多行文本里“分享链接 + 下一行提取码”的组合现在会按“最近一条缺提取码的链接”进行无歧义配对（仅在可判定时自动补全，避免误配）。
- UX(TG/提取码跟随消息): 记录最近一条『缺提取码』的 share_code（10 分钟 TTL），用户下一条消息只发 `8888` 或 `提取码:8888` 将自动续跑分享链路。
- Enh(115分享码/无域名): 支持识别只包含 `sw...` 的裸 share_code（在“整条消息仅 share_code”或上下文包含 115/分享/提取码时生效），自动转为 `https://115.com/s/<code>`。

## v1.6.5.44 (2026-01-03)

- Fix(115分享链接/域名边界): 严格校验 host（仅允许 `115.com/115cdn.com/anxia.com` 及其子域名），避免 `evil115.com` 这类“后缀撞车”误判为 115 分享链接。
- Fix(115分享链接/尾随标点): `parse_share_url()` 入口会剥离常见尾随标点（含全角 `：；`），避免提取码被污染。
- Fix(115分享链接/提取码长度): TG 文本里的『提取码：xxxx』自动补全支持长度 3~16，与 URL/fragment 规则一致。
- Fix(115口令分享/误触发): 口令 token 的上下文判定移除 `app` 子串触发条件，避免类似 "happiness" 这类噪音导致误识别。
- Fix(115分享链接/路径误命中): scheme-less locator 的前置边界更严格，避免从其他 URL path 内部（如 `.../a-115.com/s/...`）误起匹配。
- Test: 新增/扩展回归用例覆盖上述场景。

## v1.6.5.43 (2026-01-03)

- Fix(115分享链接/链路误路由): `parse_share_url()` 现在会在 `urlparse()` 前把 `115.com/s/...` 这类无 scheme 的裸域名链接规范化为 `https://...`，避免解析失败导致分享链接被当成“离线链接”等其他链路处理。
- Test: 新增回归用例覆盖“裸域名分享链接解析 + 离线提取排除”。

## v1.6.5.42 (2026-01-03)

- Fix(115分享链接/误识别): `parse_share_url()` 现在会校验 host，避免把 `https://example.com/115.com/s/xxxx` 这类“路径里包含 115.com”误当成真实分享链接。
- Fix(115分享链接/fragment): 当分享链接的 `#fragment` 实际是标题/说明（如 `#%20Title.2025...`）时，不再误当作提取码；只在 fragment 符合提取码形态（纯字母数字 3~16）时才当作提取码。
- Fix(离线提交流程): 离线链接提取现在用 `parse_share_url()` 严格排除 115 分享链接（含 `anxia.com`），避免把分享链接当成离线链接提交。

## v1.6.5.18 (2026-01-03)

- TG：热榜订阅支持在 TG 端自定义订阅规则（不再依赖 Web 面板/命令行）：
  - 评分门槛（≥）+「无评分放行/拦截」
  - 年份筛选（近 N 年/自定义范围）
  - 关键词黑/白名单（输入追加/清空）
  - 类型标签黑/白名单（输入追加/清空）
  - 缺元数据策略（缺 year/tags 时放行/拦截）

## v1.6.5.17 (2026-01-03)
- UI(通知模版/统一头部): MediaHelp/Forward 相关订阅通知（已存在/已更新/已删除/未找到/失败等）统一使用“来源 + 操作标题 + 分隔线”头部，便于一眼区分操作来源。
- UI(剧集/季信息): 更新与删除通知在剧集场景下明确展示“第几季/全季”范围（更新显示当前订阅季；删除显示被删除的订阅范围）。
- Fix(上下文传递): 更新订阅季/删除订阅的通知 payload 继承 source_tag/source_label/source_value（热榜订阅/Forward客户端/分享链接）并支持分享链接来源截断。

## v1.6.5.16 (2026-01-03)
- UI(通知模版/新建订阅任务): 头部改为“来源”优先的两行标题 + 分隔线；来源名统一为：热榜订阅 / Forward客户端 / 分享链接。
- UI(通知模版/分享链接): 来源字段过长时按“域名 + 前缀”策略截断（默认 50 字符）。
- UI(排版): 去除分隔线下方空行；在“榜单/关键词/来源”与“📺 剧集/🎬 电影”之间保留一个空行。

## v1.6.5.15 (2026-01-03)
- Hotfix(热榜/频率): 默认轮询频率调整为 60 分钟（HOTLIST_POLL_INTERVAL_SEC 仍可覆盖）。
- Fix(热榜/空榜单假象): 快照写入增加“非空才提交”保护，避免 empty snapshot 覆盖旧快照；并在 poller/include_current 增加强制一致性日志：fetch_items / snapshot_items(before/after) / using=fetch。
- Build: 继续保持发布包去除 __pycache__/*.pyc。
- Change(热榜/推送): 移除『热榜新增』批量消息与『热榜日报』汇总消息（不再发送新增/日报推送）。
- UI(热榜面板): 去除『模式』切换入口；配置页不再展示默认模式/日报时间。

## v1.6.5.14 (2026-01-03)
- Fix(人之初/串片): Douban subject 页优先从 `#info` 区块提取 IMDb（避免页面脚本/推荐位 tt-id 误命中）；并新增 imdb->tmdb 标题一致性校验（明显不一致时丢弃 imdb 结果，改走标题兜底），避免映射到无关作品。

## v1.6.5.8 (2026-01-02)
- Fix(热榜/包含当前): include_current 现在会按用户指定 limit 尽量处理全部条目（只跳过缺失 subject_id 的条目），不再被 subscription 的 top_n/auto_rules 误伤导致“拉 10 条只处理 3 条”。
- UI(通知模版): Forward 客户端的“搜索订阅”新建任务标题改为 `📌 新建订阅任务（🔎 Forward客户端-搜索订阅）`（仅对 source_tag=🔎 搜索订阅 生效，避免影响 TG 侧 🔍 搜索订阅）。

## v1.6.5.7 (2026-01-02)
- Fix(Telegram/拆分): 修复短消息也会按“最后一个换行”强行拆分，导致“🕒 时间”被单独发一条的问题；现在只在超长需要拆分时才优先按换行断开。
- UI(通知模版): 新建订阅任务推送改为统一模板：`📌 新建订阅任务（<来源标签>）`，并支持展示 来源/榜单/关键词 等上下文；时间统一 `YYYY-MM-DD HH:MM:SS` 置底。
- Hotfix(热榜/建任务): 热榜（包含当前/追新/补历史）创建 MediaHelp 任务时自动带上“榜单”上下文用于通知展示。
- Build: 继续保持发布包去除 __pycache__/*.pyc。

## v1.6.5.6 (2026-01-02)
- Hotfix(热榜订阅通知): 订阅(包含当前)仅发一条合并消息；追新发现新上榜仅发一条通知；移除成功/失败/统计/MediaHelp 结果追加；时间置底；预览默认 3 条。
- Hotfix(MediaHelp): 修复 JSON 重试导入时的自动订阅创建问题（继承 v1.6.5.5）。
- Build: 发布包去除 __pycache__/*.pyc。

## 1.6.5
- 热榜订阅：移除“补历史/回填”入口与相关文案；订阅入口仅保留两种（追新 / 包含当前）。
- 热榜订阅入口统一回到 Root 五宫格页面；配置页改为人话展示（频率/日报时间/自动建任务）。
- 修复自动建任务调用参数不匹配导致订阅无法创建任务的问题。

## v1.6.3 (2026-01-01)
- Fix(Forward/稳定性): forward_bridge MediaHelp 请求统一走 core.http_retry（超时/重试/回退）并补齐 external_* 指标（service=mediahelp）。
- Fix(Forward/可观测): forward_bridge 全部 API 响应统一 ResponseModel，默认携带 trace_id（便于联动日志排障），并补齐 response_model 声明。
- Refactor(Forward/解耦): subscriptions_core 增加 get_subscriptions_snapshot/get_sub_entry，避免 routes 直接暴露/修改 SUB_CACHE。
- Fix(Telegram/可靠性): outbox 队列满时不再抛异常；改为旁路直发（best-effort）并计数 tg_outbox_dropped/tg_outbox_bypass。
- Fix(Telegram/回调token): callback token sqlite 写/读失败时自动回退到内存 TTL 存储（TG_CALLBACK_TOKEN_TTL_SEC 可配）。
- Refactor(Telegram/模块化): 新增 command_router/text_router/text_handlers，dispatcher 精简并补齐 tg_updates_total/tg_command_total/tg_callback_total 指标。

## v1.6.0 (2026-01-01)
- P2(扩展性): 新增 notifier 通道注册表（registry）与 CompositeNotifier，多通道通知可通过 NOTIFIER_TYPES=telegram,... 配置启用；支持顺序/并发发送，以及 "需要全部成功" / "任一成功" 判定（NOTIFIER_SEND_PARALLEL / NOTIFIER_SEND_REQUIRE_ALL）。
- P2(扩展性): 新增 Pipeline Step Runner（notifier/service/step_runner.py），步骤链可通过 PIPELINE_STEPS=extract,enrich,... 配置；默认保持历史行为，并为每步导出时延指标 `pipeline_step_<name>_ms`。
- Tests: 增加 registry 与 step runner 的基础单测。

## v1.5.9 (2026-01-01)
- P1(观测): notifier.metrics 增加 observe()，以零依赖方式导出 *_count/*_sum/*_max（用于时延观测）。
- P1(观测): 新增时延指标：webhook_enqueue_ms、enqueue_put_ms、queue_wait_ms、queue_total_delay_ms、notify_handle_ms。
- P1(行为可控): Episode webhook/worker 去重策略可配置 EPISODE_DEDUP_STRATEGY=series|path（默认 series）；pipeline 的 media_key 固定为 series 策略。
- P1(工程化): 增加 tests/（pytest）与开发工具配置（ruff/black/mypy/pre-commit）示例，不影响生产依赖。

## v68.3 (2025-12-30)
- Fix(媒体键/单集入库): Episode 通知的 `media_key` 由 `item_id` 升级为稳定的 `series_id + SxxEyy`（保留 library_id 维度），使 UI/worker 去重不再受 series 详情页 URL 影响，并提升重试幂等性。
- Tests: 新增 Episode `media_key` 生成与字符串季/集号解析的单测。

## v68.1 (2025-12-30)
- Fix(最近入库/聚合推送): 聚合剧集通知新增 deterministic `media_key`（基于 series_id/season/episode-set），避免多条合并消息共享同一 series 详情页 URL 时在“最近入库”被误去重/覆盖，导致只显示第一条与最后一条。

## v68.2 (2025-12-30)
- Fix(聚合/稳定性): 聚合排序与 key 生成改为安全解析（兼容 season/episode 为 "S01" 之类字符串），避免异常导致整组聚合消息丢失。
- Fix(最近入库/聚合去重): media_key 生成不再回退到 episode item_id（避免重试/顺序变化破坏去重），改为优先 series_id/series_name，并加入 library_id 维度；当明细过长时自动用 item_id 集合 SHA1 生成短签名。
- Tests: 增加聚合 media_key 的类型鲁棒性用例。

## v68.0 (2025-12-30)
- Fix(Cloud115/Extract): BTIH 严格校验（仅 40-hex / 32-base32），避免 Telegra/TG 预览把标题粘到 hash 后导致 “BTIH 长度异常(2xx)”。
- Fix(Cloud115/Extract): 对被污染的 magnet（断行/缺少 &dn= 分隔）做安全的 BTIH 恢复：只截取第一个合法 hash，不做模糊匹配。
- Test: 增加 Telegra/TG 断行与标题粘连场景的单测覆盖。

## v67.6 (2025-12-29)
- P0(Forward 秒弹一致性): 取消订阅（DELETE /api/v1/subscribe/*）也改为 pending + 后台执行，HTTP 立即返回 accepted，Forward 端不再阻塞等待 MediaHelp。
- P0(Forward 去重): 同一条目 (tmdb_id, season) 在 pending 期间重复点击/Forward 重试直接 accepted，不重复创建后台任务；若出现“订阅/取消订阅”冲突，以最新动作为准并取消旧任务。
- P1(Forward 刷新策略): refresh_sub_cache 增加最小刷新间隔（默认 2s，可配），避免 status/userlist 高频轮询压垮 MediaHelp；/api/v1/user/*/subscribe_list 默认不再 force refresh（支持 ?refresh=1 强刷）。
- P1(Forward 稳定性): 背景任务运行期间定期续命 pending（默认 5s，可配），避免 TTL 到期造成状态回跳。

## v67.0 (2025-12-29)
- UI(Cloud115): Cookie 健康检查按“启用 + 标题 + 一行说明”常显；“默认每 6 小时...”及后续参数收纳到“高级参数”折叠（默认折叠）。

## v66.8 (2025-12-29)
- UI(Cloud115): 扫码登录/测试 Cookie/刷新目录三个按钮强制同一行显示（小屏自动缩小内边距/字号）。
- UI(Cloud115): Cookie 健康检查区域保留“标题/描述/启用”常显；“默认每 6 小时...”及参数项移入“高级参数”折叠块（默认折叠）。

## v66.6 (2025-12-29)
- UI(Cloud115): 健康检查折叠头部去掉冗余描述文案；“启用健康检查”复选框前置到标题左侧（更像其它布尔项）。

## v66.2 (2025-12-29)
- UI(Cloud115): Cookie 健康检查折叠块改为“标题+描述+状态”样式（对齐 115 云下载卡片，不再显示一坨 KEY/勾选）；启用开关移动到展开内容中，勾选框样式与其它布尔项一致。

## v66.1 (2025-12-29)
- UI(Cloud115): Cookie 健康检查折叠块的“启用”勾选框样式与其它布尔开关一致（统一大小 + accent-color），并优化 summary 布局避免挤在一行。
- Fix(Forward/Season Filter): 兼容 Forward 上游不同的季字段名（season_number/seasonNumber/season_num/seasonNum/seasonNo）以及 "S01/第1季" 这类字符串，启用按季过滤时不再误订阅全季。

## v66 (2025-12-29)
- UI(Cloud115): “扫码绑定类型/扫码登录/测试 Cookie/刷新目录”改为两行布局，避免移动端挤在一起；并在“扫码绑定类型”前增加 115 图标。
- UI(Cloud115): Cookie 健康检查默认折叠（可展开配置）；扫码登录区域放到 Cookie 输入框下面。

## v65 (2025-12-29)
- Fix(Forward/Defaults): defaults 仅接受 {data:{...}} 形态（回退 v40 行为），避免误把 envelope/root 当 defaults 导致订阅绑定到错误云盘/目录（进而触发 tv 订阅执行失败）。
- Fix(Forward/Poster): 当 MH search 命中但 poster_path 为空时，自动用 TMDB by id 补齐 poster，避免订阅卡片灰色占位。

## v64 (2025-12-29)
- TG(115login): /115login 先弹出「登录方式」按钮（支付宝生活/微信生活/Android/iOS/TV/Harmony/Web），选择后再生成二维码；刷新二维码会复用原绑定类型，不再重新弹选择。

## v61 (2025-12-29)
- Change(UI/Notify Meta): 非成人内容不再展示 NFO 多源评分（📊 Ⓛ/Ⓒ），仅保留社区评分（⭐）。
- Change(Aggregate): 剧集聚合窗口默认从 60s 调整为 30s（NOTIFIER_AGGREGATE_WINDOW）。

## v57 (2025-12-29)
- Fix(TMDb detail cache): 定义 `_DETAIL_CACHE`，修复 `fetch_tmdb_detail()` 触发的 `NameError: _DETAIL_CACHE is not defined`。
- UX(TMDB auto pick): `auto_strength` 改为“风险闸门”，不再用 share_flow 的第二套固定阈值把 `ok_pick=True` 打回 weak；仅在少数高风险场景（单候选保守、年份强冲突、force_tv 误类型、候选过多且 gap 极小、超短标题）降级为需要确认；保留 v43 单候选严格升级逻辑。

## v53
- Fix(UI Recent): /admin/recent.json 与初始渲染统一做 Episode compact（同剧同季多集聚合成一条），避免“列表刷屏/闪一下/总数不一致”。
- Fix(聚合通知去重): NOTIFIER_AGGREGATE_WINDOW>0 且聚合条目为 episode_number=None 时，避免 recent_entries 重复写入两条；同时 replace_series_entries 增加防御性去重。
- Fix(Telegram): split_text 对超长 URL/magnet 采用“整行 urlish 继承”，避免从第二段开始把参数切烂；caption 过长时不再退化为固定文案；对可能炸实体的 chunk 自动禁用 parse_mode，避免双请求/重复上传。
- Fix(tg_bot dead-letter): init_db 短路前校验 failed_update 表存在，避免路径切换/配置缓存导致记录链路悄悄失效。
- Tests: 新增 recent 聚合/去重、caption/overflow、URL/magnet split、failed_update 记录回归用例。

## v54
- Fix(webhook/queue): Webhook 与 worker 的 dedup 仅在 **成功入队后** 才写入记录，避免队列满(503)时“先写去重键 → 重试被误判 DUPLICATE → 事件永久丢失”。
- Fix(dedup TTL): `DEDUP_TTL_SECONDS=0` 语义改为 **关闭去重**；若需要“永久去重”，使用 `DEDUP_TTL_SECONDS=-1`。
- Hardening(env parse): 对少数启动敏感的数字 env（PosterCache/RecentEntries/PBKDF2 iterations）做容错解析，避免空字符串/非数字导致启动即崩。
- Tests: 新增 webhook/worker queue-full 去重回归用例 + ttl=0 语义回归。

## v52
- Fix: Forward Bridge：未设置 `FORWARD_BRIDGE_TOKEN` 时不做鉴权校验（兼容 v40/v25 旧配置），避免 Forward 登录测试被 401 拦截。

## v51.2
- Fix: Forward 联动设置保存 MEDIAHELP_BASE 不再依赖前端 JS（服务器端根据 MEDIAHELP_BASE_SCHEME + MEDIAHELP_BASE_HOST 组装并持久化）。
- Fix: Forward 页面预填充 MediaHelp 地址的 scheme/host；未登录页也提供默认值避免模板引用错误。

## v51.3
- Fix: 基础配置保存 EMBY_BASE_URL 不再依赖前端 JS（服务器端根据 EMBY_BASE_URL_SCHEME + EMBY_BASE_URL_HOST 组装并持久化）。
- Fix: 设置页预填充 Emby 地址的 scheme/host，避免“保存成功但未写入”的弱网/WebView 缓存场景。

# v51.1.forwardtoken-removed.buildfix (2025-12-28)

## Fix
- 修复 `admin/routes_part2.py` 的装饰器语法错误（多了一行 `, response_class=JSONResponse)`），否则 Dockerfile 的 `python -m compileall` 会失败，导致镜像构建中断。

---

# v48.recent.dedup.v1 (2025-12-28)

## 最近入库：过滤订阅任务 + 去重/合并重复入库

### Fix
1) **“最近入库”只展示媒体入库/更新通知**
   - 订阅任务/系统通知（如“新建订阅任务 -- Forward客户端”）不再写入最近入库列表。

2) **更稳健的重复入库去重（防止同番号成对出现、成人/非成人混入）**
   - webhook/队列 dedup key 从单纯 `item_id` 提升为 **规范化媒体键**：
     - AV-like：优先 `code:{番号}`（支持 `FC2-xxxxxxx`、`MD-xxxx-x`、`MIAB-xxx`、`DASS-xxx` 等），其次 `folder:{父目录}`
     - 兜底仍是 `item:{item_id}`
   - 最近入库在写入时再做一层“窗口去重”（按 detail_url / display_title 等稳定键），避免偶发重复推送导致 UI 成对重复。

Files changed:
- api/webhook.py
- notifier/worker.py
- core/bootstrap.py
- core/recent_entries.py
- notifier/templates/admin_settings.html
- notifier/config.py
- PATCH_NOTES.md

---

# v46.ui.strict.v1 (2025-12-28)

## 115 扫码登录：修复 iOS/WebView 轮询 `TypeError: Load failed` + 二次扫码卡住 + 页面放大无法缩小

### Root cause
- 前端使用 `setInterval(async ()=> await fetch(poll))` 实现轮询：当一次 `/poll` 响应时间超过 interval 间隔时，会产生 **重叠并发请求**。
- iOS Safari/WebView 对同域并发连接/被中止的请求更敏感，容易抛出 `TypeError: Load failed`（网络层失败，而非后端业务返回）。
- 弹窗关闭/重新扫码时未 Abort 在途 fetch，导致连接占用/状态机残留，出现“再次扫码一直生成中，必须整页刷新才恢复”。
- iOS 在输入框字体 < 16px 时聚焦会自动放大页面；部分内置浏览器禁用手势缩放，导致“放大后缩不回去”。

### Fix
- 轮询改为 **串行 setTimeout**（single-flight），并加入 `AbortController` + 15s 超时，杜绝重叠请求与挂起连接。
- `visibilitychange`：页面从后台回到前台时延迟恢复轮询，并在 hidden 时 abort 释放连接。
- 网络层连续失败自动重建二维码（无需手动刷新页面）。
- 移动端输入框 font-size 提升到 16px + 扫码回填后主动 blur，避免 iOS 自动放大且无法缩小。

Files changed:
- static/admin.js
- static/admin.css
- PATCH_NOTES.md

---

# v47.ui.strict.v2 (2025-12-28)

## 修复点
1) **EMBY_BASE_URL / MEDIAHELP_BASE 自动补全协议头**
   - UI 侧在 blur 与提交前自动把 `ip:port` / `host:port` 补全为 `http(s)://...`（以当前页面协议为准）。
   - 后端原有的 AnyHttpUrl 兼容逻辑保留。

2) **iOS 保存配置偶发 `TypeError: Load failed` 兜底（去重模式切换后保存）**
   - AJAX 保存增加一次重试（cache-bust）。
   - 若仍失败且检测为 iOS 的 `Load failed/Failed to fetch/NetworkError`，自动降级为传统 form submit（页面刷新），避免“保存失败但实际可保存”的体验问题。

Files changed:
- static/admin.js
- notifier/config.py (APP_VERSION)
- PATCH_NOTES.md

---

# v45.ui.strict.v3 (2025-12-28)

## MediaHelp：登录/测试后页面状态实时刷新

### Changes
- 登录成功、或点击“测试 Token”成功后，会同步更新页面上的「运行态登录」状态行，避免用户误以为仍是“未登录/需重登”。

Files changed:
- static/admin.js
- PATCH_NOTES.md

---

# v45.ui.strict.v2 (2025-12-28)

## 115 扫码登录：成功后自动弹出“保存配置”确认 + 保存后页面即时遮罩

### Changes
1) **扫码成功后自动提示保存（仍需用户确认）**
   - 当扫码获取到 Cookie 并回填到 `CLOUD115_COOKIE` 后，自动弹出“保存配置”确认框，避免用户忘记点击底部保存。

2) **AJAX 保存成功后，页面即时切换为“当前已设置（不回显）”**
   - TG Bot 表单走 AJAX 保存，页面不会刷新；为避免 secret 值在输入框中长期可见，同时让 UI 看起来“已刷新”，保存成功后会立即把 secret 输入框替换为遮罩文案。
   - 影响字段：`CLOUD115_COOKIE`、`TG_BOT_WEBHOOK_SECRET`（其它 `data-secret=1` 字段同逻辑）。

Files changed:
- static/admin.js
- PATCH_NOTES.md

---

# v45.ui.strict.v1 (2025-12-28)

## 115 扫码登录：轮询“会话不存在/已过期”根因修复

### Root cause
- 管理后台扫码登录在后端用进程内字典保存 `qid -> token(uid/time/sign)` 会话。
- 若部署为 **多进程 / 多副本**（例如多 workers、负载均衡到多容器），`/start` 与后续 `/poll` 可能落到不同实例，导致 `/poll` 找不到 qid，前端出现：
  - `轮询失败：二维码会话不存在或已过期（xxs 后自动刷新）`

### Fix
1) **后端提供无状态轮询参数**
   - `/admin/tg-bot/115/qrcode/start` 除 `qid` 外新增返回 `qtoken`（对 token 做 urlsafe base64 打包）。
   - `/admin/tg-bot/115/qrcode/poll` 新增支持 `qtoken`：当本地 qid 会话不存在时，自动回退到 `qtoken` 继续轮询/换取 Cookie。

2) **前端轮询自动携带 qtoken**
   - `static/admin.js` 在启动二维码后缓存 `qtoken`，轮询时附带 `&qtoken=...`，从而在多实例场景也不会丢会话。

Files changed:
- admin/routes_part2.py
- static/admin.js
- PATCH_NOTES.md

---

# v44.ui.strict.v7 (2025-12-28)

## UI strict audit（管理后台）全量核查续查

### Fixes
1) **Forward 联动 / 配置参数：保存成功后弹出“已保存”提示（与 TG Bot 一致）**
   - `/admin/forward-settings`、`/admin/settings` 保存成功后写入 session flash，在重定向回 `/admin?tab=...` 后自动弹出统一 `msg-modal`。
   - 提示文案包含本次更新项数量；Forward 在基础配置缺失时会在同一弹窗中追加提醒（不会覆盖“已保存”提示）。

2) **msg-modal 支持换行**
   - `#msg-body` 增加 `white-space: pre-line`，让“已保存 + 提醒”等多段文案可读。

Files changed:
- admin/routes_part1.py
- static/admin.css
- PATCH_NOTES.md

---

# v44.ui.strict.v6 (2025-12-28)

## UI strict audit（管理后台）续查

### Fixes
1) **确认保存后关闭弹窗，避免原生校验被遮罩挡住**
   - 之前确认保存（非 tgbot 表单）时会保持 `save-modal` 打开；若浏览器原生校验未通过，用户无法看到/定位具体哪个输入框报错。
   - 现在点击「确认保存」会先关闭确认弹窗，再触发表单提交/校验。

2) **sanitize 提交过滤：不再禁用 required 字段**
   - 避免“未触碰字段过滤”意外禁用 required 输入框，导致绕过浏览器原生校验，最终只能在后端报错。

3) **旧浏览器提交兼容：避免 form.submit() 绕过校验/submit 事件**
   - 当 `requestSubmit()` 不可用时，改为创建临时 `type=submit` 按钮触发点击，以确保原生校验与 submit 事件链路仍然工作；仅在极端情况下才降级到 `form.submit()`。

Files changed:
- static/admin.js
- PATCH_NOTES.md

---

# v44.ui.strict.v5 (2025-12-28)

## UI strict audit（管理后台）续查

### Fixes
1) **保存确认流程：避免校验失败后“回车绕过确认”**
   - `requestSubmit()` 因浏览器原生校验未触发 `submit` 事件时，`data-confirmed-submit` 可能残留为 `1`，导致后续 Enter 直接提交。
   - 现在在确认提交后追加兜底定时器自动复位该标记（不影响正常提交跳转）。

2) **115 二维码登录：回填 Cookie 后标记为真实输入**
   - 扫码成功后回填 `CLOUD115_COOKIE` 的同时，强制设置 `dataset.mode='user'` / `dataset.touched='1'`，避免仍被当作 mask/hint：
     - 避免“已回填但仍提示二维码过期/不算已填”的误判
     - 避免后续前端过滤把真实 Cookie 当成遮罩文案跳过提交

3) **localStorage 兼容性加固（Safari 无痕/隐私模式）**
   - 增加 `__lsGet/__lsSet/__lsRemove` 安全封装，避免 `localStorage` 抛异常导致整个 admin.js 中断（登录标记 / 主题背景 / UI 偏好等）。

4) **TG Bot 表单防护变量统一**
   - 修正 TG Bot 表单 submit 监听中误用 `window.__ADMIN_NEED_LOGIN/__ADMIN_NEED_CHANGE_PWD`（可能不存在）。
   - 统一改为使用 `isLoggedIn` + `window.__MUST_CHANGE_PASSWORD`，行为与其它 Tab 一致。

Files changed:
- static/admin.js
- PATCH_NOTES.md

---

# v44.ui.strict.v4 (2025-12-28)

## UI strict audit（管理后台）续查

### Fixes
1) **外观设置未登录提醒弹窗可用性修复**
   - 修复 `showUIPersistTip()` 被意外定义在 `showToast()` 内部导致全局不可用的问题。
   - 影响面：未登录时点击「应用」/触发 UI 偏好保存会抛错，后续 JS 逻辑可能中断。

2) **“最近入库” demo 渲染结构/样式对齐**
   - `ensureDemoEntries()` 生成的 demo DOM 结构改为与真实渲染一致：`li > .entry-link > .entry-row`。
   - 统一 class：`entry-cover / entry-text / entry-meta-line`，避免移动端/暗色主题下 demo 条目错位。

Files changed:
- static/admin.js
- PATCH_NOTES.md

---

# v44.ui.strict.v3 (2025-12-28)

## UI strict audit（管理后台）

### Fixes
1) **Inline hint/mask 输入框行为修复**
   - secret 输入框（`data-secret=1`）：focus→blur 后若回填 hint/mask，确保恢复为 `type=text`，避免 Safari/iOS 上 hint 变成 “••••”。
   - **用户主动清空**（touched=1 且值为空）时，不再自动回填 hint/mask，避免“清空后又变回默认文案并被提交进 env.local”。
   - `setupInlineHints()` 做成幂等：支持在 `form.reset()` 后重新初始化，不会重复绑定事件。

2) **回车提交一致性**
   - 在任意输入框按 Enter 触发 submit 时，不再直接保存；统一弹出“保存确认”弹窗（与点击「保存更改」一致），避免误触导致配置被写入。

Files changed:
- static/admin.js
- PATCH_NOTES.md

---

# 1.7.70.fix-subscribe.v32 (2025-12-26)

## v32 变更
- 115 离线回执：提交/展示 URL 解耦，保留 magnet 原始 dn 标题（不再被 canonical 化丢失）。
- 115 离线回执：小批量（<=3）按离线 key（btih/hash）匹配成功/失败/跳过，消除 "已处理" 兜底误判。
- 115 去重：仅发生 "第2次自动跳过" 且无待确认时，改为单条卡片回执（不再输出统计模版）。
- 回执模板：标题（dn）超长截断，避免 TG 消息超长导致发送失败。
- 结构加固：同 key 多次提交时回执按序消费（key->deque），避免覆盖导致回执错配。
- P0 修复：Telegram notifier 缩进/返回值错误导致实际不可用，已将 send/_download_image 归位到 TelegramNotifier，并统一 _download_image 返回 (data, filename, content_type)。

Files changed:
- tg_bot/cloud115_flow_core.py
- tg_bot/cloud115/templates.py
- notifier/notifiers/telegram.py
- notifier/config.py (APP_VERSION)
- PATCH_NOTES.md

---

# 1.7.70.fix-subscribe.v31.fix11 (2025-12-26)

## fix11 变更
- TG polling：offset 文件按 bot token 隔离（切换 TG_BOT_TOKEN 时自动切换 offset store，避免吃不到/跳过消息）
- TMDB sqlite 持久化缓存：search_multi 增加 db_key + 读写反序列化（重启后 search 缓存生效）
- 115 分享链接：支持密码在 fragment（#后面）形式解析
- TG polling：drop_pending_updates 默认改为 False（重启不丢离线消息）
- tg_bot sqlite：WAL pragma 失败时降级，不再启动即崩
- dotenv 热加载：删除 key 时恢复外部注入的旧值，不再误删

---


后续稳定性/可维护性增强（在不影响主流程的前提下补日志与语义修正）：
- health：修正 `worker.recent_10m` 语义（改为“notify 发送次数”），并新增 `recent_notify_10m / recent_webhook_10m` 明确字段，避免监控误解。
- 115 files API：在首次 `webapi/files` 目录浏览请求时打印一次分页字段样本（offset/limit/page_size 等），用于兼容性排障。
- 关键链路吞异常补日志（`exc_info=True`，默认 DEBUG 级别）：
  - Emby 时间解析：fromisoformat 失败时输出 debug 堆栈
  - TMDB sqlite kv_cache：get/set/purge/to_thread/resp.close 失败时输出 debug 堆栈
  - Telegram polling / 编辑消息：关键 fallback 异常输出 debug 堆栈

Files changed:
- api/health.py
- core/cloud115.py
- notifier/metadata/emby_meta.py
- tg_bot/tmdb_match_api.py
- tg_bot/telegram_api.py
- notifier/config.py (APP_VERSION)
- PATCH_NOTES.md

---

# 1.7.70.fix-subscribe.v31.fix9 (2025-12-26)

继续清理 event loop 中的同步文件系统访问（按你的选择迁移 1+2）：
- poster_cache：cache hit 快路径（glob/stat/meta.json read）改为 `asyncio.to_thread()` 中完成，避免高频命中时因弱 IO 抖动拖慢 bot/webhook。
- forward_bridge MediaHelp token：运行期不再做 `.env.local` 的 mtime/stat 触碰；bootstrap 启动阶段的 token 磁盘恢复改为 `to_thread()`，避免首个请求触发同步读盘阻塞 event loop。
- admin：调用 `reload_settings()` 的位置改为 `to_thread()`（内部会读 `.env/.env.local`），避免保存配置时阻塞 loop。

Files changed:
- core/poster_cache.py
- core/bootstrap.py
- forward_bridge/http_client.py
- admin/routes_part1.py
- admin/routes_part2.py
- notifier/config.py (APP_VERSION)
- PATCH_NOTES.md

---

# 1.7.70.fix-subscribe.v30.fix8 (2025-12-26)

优化/迁移（把剩余同步 IO / sqlite 调用移出 event loop）：
- admin：/admin 相关的 env/json/credentials 文件读写统一改为 `asyncio.to_thread()`，弱 IO / 高并发下更不容易卡住 FastAPI event loop。
- forward-bridge：MediaHelp 登录后 token 写盘、同步到 `.env.local` 的文件 IO 改为 `to_thread()`；同时修复 `login_mediahelp()` 里误调用 `set_token()` 的潜在 NameError 问题。
- tg_bot：share/115离线/menu/轮询错误记录等路径上所有 sqlite storage 调用点统一改为 `to_thread()`，避免 sqlite IO / 锁等待拖慢消息处理。
- RecentEntriesStore：启动 load 阶段的 JSON 读盘改为 `to_thread()`，进一步降低启动抖动。

Files changed:
- admin/routes_base.py
- admin/routes_part1.py
- admin/routes_part2.py
- forward_bridge/http_client.py
- forward_bridge/routes.py
- core/recent_entries.py
- tg_bot/cloud115_flow_core.py
- tg_bot/cloud115_flow_part2.py
- tg_bot/mediahelp_flow.py
- tg_bot/menu.py
- tg_bot/polling.py
- tg_bot/service.py
- tg_bot/share_flow_core.py
- tg_bot/share_flow_callbacks.py
- tg_bot/share_flow_resolve.py
- notifier/config.py (APP_VERSION)
- PATCH_NOTES.md

---

# 1.7.70.fix-subscribe.v29.fix7 (2025-12-26)

优化/修复：
- poster_cache：远程海报缓存写盘从 async 路径移出 event loop（改为内存缓冲 + to_thread 原子落盘）。
- TG polling offset：json offset 文件的 load/save 改为 to_thread，避免弱 IO 环境阻塞 event loop。
- share115：新增配置项（extra=forbid 兼容）并默认复用进程级 shared httpx.AsyncClient，降低“忘记 close”导致的资源泄漏风险；Share115Client 支持 async with。
- share115 日志：INFO 级别默认改为输出 hash（可用 SHARE115_LOG_SAMPLES 打开少量样本日志），避免目录/文件名泄露与刷屏。
- is_adult_content：成人覆盖配置（库名/路径前缀）的 lower set/prefix 结果缓存，减少每条通知的重复构造与 GC 开销。
- webhook dedup：dedup_key 改为 event+item_id（不再拼 created_raw），提升去重命中率并避免重复入队。
- TG share flow：Share115Client 调用统一使用 keyword-only（cookie=...）并使用 async with。

Files changed:
- core/poster_cache.py
- tg_bot/polling.py
- core/share115.py
- notifier/config.py (APP_VERSION + SHARE115_* settings)
- notifier/utils.py
- api/webhook.py
- tg_bot/share_flow_core.py
- tg_bot/share_flow_callbacks.py
- tg_bot/share_flow_resolve.py
- PATCH_NOTES.md

---

# 1.7.70.fix-subscribe.v28.fix6 (2025-12-26)

Bugfix:
- TG 订阅回执：修复 share_title “补抓”逻辑因为 keyword-only 调用方式错误而始终失败的问题（改为关键字调用）。
- 通知详情 TMDB 链接：Season 类型事件归一到 TV 路径（/tv/{id}），避免错误生成 /movie/{id}。
- Webhook 入队指标：移除 webhook 侧 enqueue_* 重复计数（enqueue_* 仅由 worker 侧计数），新增 webhook_received。
- RecentEntriesStore 关闭：修复 debounce save loop 在 close 取消时可能丢最后一批 recent entries 的落盘问题（close 先强制立即保存再停后台任务）。

Files changed:
- tg_bot/share_flow_core.py
- notifier/service/pipeline.py
- api/webhook.py
- core/recent_entries.py
- notifier/config.py (APP_VERSION)
- PATCH_NOTES.md

---

# 1.7.69.fix-subscribe.v6 (based on emby_notifier_tg_bot_p0_p1_p2_filesig)

## v21 (2025-12-25)

P2 / 稳定性与质量改进：
- TMDB alias enrichment 并发受控：topK 详情拉取加入 Semaphore（默认 4，可用 `TMDB_ALIAS_ENRICH_CONCURRENCY` 调整），减少 burst 时对 TMDB 的冲击。
- TMDB alias cache 更细粒度：alias 缓存 key 加入 language（`(media_type, tmdb_id, TMDB_LANGUAGE)`），避免不同部署语言配置混用缓存。
- `normalize_title()` 中文噪声词清理更保守：新增 `TMDB_CN_TAG_CLEANUP_MODE=conservative/aggressive/off`；conservative 仅在括号段或分隔符相邻时清理，降低误伤真实片名概率。
- 简繁转换支持可选 opencc：若环境安装 opencc 且 `TMDB_USE_OPENCC=True`（默认），优先用 opencc；否则 fallback 到内置轻量映射。
- share_tmdb_map 支持内容变更历史：schema 增加 `content_hash` 并改为复合主键 `(share_code, content_hash)`，默认用 `file_sig` 作为 hash；插入后保留最近 N 条（`SHARE_TMDB_MAP_HISTORY`，默认 3）。旧库自动 best-effort rebuild。
- 关键排障点补充：sig mismatch 增加 warn 日志（带 share_code sha1 前缀、expected/current sig）。

附：新增最小回归 runner（文件名 guess 链路）
- `tests/tmdb_regression_cases.sample.jsonl`
- `tools/run_tmdb_regression.py`
- `tests/README_regression.md`

## v20 (2025-12-25)

P0/P1 修复（高风险链路优先）：
- 115 share/snap 列表解析：先做字段归一化（cid/fid/file_id/id → dir_id/file_id），再决定 chosen，避免目录条目被提前 continue 掉导致 BFS 漏扫深层目录。
- 115 API “HTTP 200 但 errno/state 失败”统一处理：新增业务错误类型 + 可重试 errno 的退避重试；失败日志带 step/errno/state，便于排障。
- TMDB detail 拉取：改用统一的 async_request_with_retry（含 429/超时重试），并补充非 200 / JSON 失败的可观测日志。
- auto-pick 规则收敛：share-flow 不再复制一套判定逻辑；把 support/main-hint/force_mt/token/year guard 作为 ctx 传入 tmdb_match_core.should_auto_pick，保证同候选同决策。
- 降低“吞异常”成本：关键链路的静默 except 改为 debug/warn（带上下文）。

## v19 (2025-12-25)

- 统一所有“token + TTL”内存会话为 `SessionManager`：统一 TTL（支持 sliding）、清理策略、owner(chat_id/user_id) 校验、过期后默认清键盘策略。
  - 覆盖：115dir / 115offdir / 115copy / 115qrmeta / H 预览等。
- 关键 callback 增加幂等锁/去重（同一 message 的 commit/submit 防抖）：
  - H commit（离线提交）
  - 115offdir pick/default（一次性目录选择提交）
  - 115dup force/skip（重复离线确认）
- 最小回归用例同步更新：不再依赖旧的内存 dict，改用 SessionManager。

## v18 (2025-12-25)

- telegra 解析：按失败原因分层提示（200 但无分享 / 403 / 429 / 超时 / 其他）。
- 所有结束态默认先清键盘：完成/取消/过期等先 `tg_clear_keyboard`，再决定是否编辑内容（对 photo caption 更稳）。
- 增加最小回归用例：解析分类（Share/Offline/H）、H 预览分页勾选、过期 token 点击、photo caption 的 cancel/expire。
  - 运行：`python -m tg_bot.regression_min`

## v17 (2025-12-25)
- 115 分享链接解析：扩大视频扩展名识别（含 .rmvb/.iso/.vob/.mpg/.mpeg/.m2v/.mts）。
- 选主视频：避免误选 trailers/extras/samples（支持中英文关键词）。
- BDMV 目录：优先扫描 STREAM，提升蓝光结构命中率。
- TMDB 标题清洗：补充常见中文发布/字幕/平台噪声词清理。
- TMDB 查询：增加简繁体变体（轻量映射），短查询自适应拉大 fetch_n，补充 /search/multi 回退。
- 自动匹配：多提示加权（主提示权重更高），Top3 详情重打分更积极；弱匹配提供“可更正”按钮。

This package is built on top of `emby_notifier_tg_bot_p0_p1_p2_filesig.tar.gz` you provided.

## Forward-Bridge fixes (root-cause)
1) Unified, safe JSON parsing for all MediaHelp calls
   - Added `forward_bridge/http_utils.py` (`safe_json`, `resp_brief`) and replaced direct `resp.json()` in login/defaults/list/create/update/delete/execute paths.
   - Prevents startup/endpoint crashes when MediaHelp returns HTML/text.

2) MediaHelp token persistence source-of-truth
   - Runtime token now follows the *newer* source between STATE_FILE and `/data/.env.local` (mtime-based hot-reload).
   - Successful logins also sync token back into `.env.local`.

3) Subscribe payload type mismatch mitigation
   - When callers omit/garble `type` but still provide a title, we probe TMDB (movie+tv) to correct media_type.

4) Robust `mediaid` parsing
   - Accepts case-insensitive `tmdb:` prefix and multi-segment forms like `TMDB:tv:123` (extract last integer segment).

5) `/api/v1/subscribe/user/{username}` now returns useful data
   - Returns normalized subscription list from SUB_CACHE (`tmdb_id`, `uuid`, `name`, `cron`, `selected_seasons`, `full_season`).

6) TMDB detail in-memory cache (TTL)
   - Reduces duplicate TMDB calls when multiple entrypoints create/update/confirm subscriptions.

7) SUB_CACHE schema hardening
   - Validates entries via `SubCacheEntryModel` at refresh boundary while preserving dict storage (compat with tg_bot).

8) Pydantic v2 compatibility
   - Replaced `.dict()` with `.model_dump()` in forward routes logging.

9) Reduced "re-export maze" complexity in tasks layer
   - `subscriptions_tasks.py` now uses explicit imports instead of dynamic re-export assignments.

10) Routes import canonical APIs
   - `routes.py` imports `subscription_api` / `subscriptions_core` / `subscriptions_tasks` directly (facade remains for compatibility).

## Files changed
- forward_bridge/http_utils.py (new)
- forward_bridge/http_client.py
- forward_bridge/routes.py
- forward_bridge/subscription_api.py
- forward_bridge/subscriptions_core.py
- forward_bridge/subscriptions_tasks.py
- notifier/config.py
- PATCH_NOTES.md

---

# 1.7.69.fix-subscribe.v4 (based on emby_notifier_enhanced_v1.7.69_bugfixes_nostar)

This package is built on top of the original `emby_notifier_enhanced_v1.7.69_bugfixes_nostar.tar.gz` you provided.

## Fixes (root-cause)
1) TG share flow: prevent `TgOutMessage(...)` repr from being sent to Telegram
   - Fixed callsite to use `reply2.text` / `reply2.reply_markup` when editing/sending messages.

2) MediaHelp subscribe payload: `year` is always normalized as string
   - TG share flow payload now passes `year` as `str` (not int).
   - ForwardSubscribePayload model normalizes `year` from int/str to `str` (pydantic v2 compatible).

3) MediaHelp "未知标题" on subscribe: ensure title enrichment when MH search returns placeholder meta
   - If MH search returns meta without a title, force TMDB fetch (same type first, then alternate type).

4) Notifier worker retry: delayed retry queue now actually works
   - Initialize and track delayed retry tasks; cancel/await them on shutdown to avoid leaks.

5) TG offline flow: "处理中…" message can now be edited away
   - `tg_send_message_ret()` returns `Optional[int]` message_id; service layer now treats it as int (not dict).

6) Forward bridge: remove unreachable close_client dead code
   - Keep a clear no-op function since shared http client is owned by app lifespan.

7) SUB_CACHE season filter: normalize `selected_seasons` to avoid string-as-iterable corruption
   - `refresh_sub_cache()` now parses and merges seasons using `_parse_selected_seasons()`.

## Files changed
- notifier/worker.py
- tg_bot/service.py
- forward_bridge/http_client.py
- forward_bridge/subscriptions_core.py
- notifier/config.py (APP_VERSION)
- PATCH_NOTES.md

---

# 1.7.69.fix-subscribe.v7

## What this patch focuses on
Improve TMDB recall/accuracy for **TV episode release names** like:
`Fallout.S02E01.The.Innovator.2160p.AMZN.WEB-DL.DD+5.1.Atmos.DoVi.H.265.mkv`

Symptoms fixed:
- "识别标题"被污染为"Show + EpisodeTitle + Platform/Audio"，导致 TMDB 候选集不包含正确剧集。
- 当启用 `guessit` 时，guessit 可能用更长的标题覆盖掉我们更干净的剧名（例如把 "Fallout" 覆盖成 "Fallout The Innovator"），进一步降低召回。

## Changes
1) Prefer clean show title over noisy episode strings when TV hints exist
   - `tg_bot/tmdb_match_guess.py`: when `season`/TV markers exist, only accept `guessit` title if it is not significantly longer than the parsed title (or if parsed title is too short).
2) Stronger title normalization for platform/audio tags
   - `tg_bot/tmdb_match_core.py::normalize_title()`: treat '+' as a separator; remove common platform tokens (AMZN/NF/DSNP/ATVP...) and audio tokens (DD/DDP), and add `DoVi` cleanup.

## Files changed
- tg_bot/tmdb_match_guess.py
- tg_bot/tmdb_match_core.py
- notifier/config.py (APP_VERSION)
- PATCH_NOTES.md


---

# 1.7.69.fix-subscribe.v23

## What this patch focuses on
Fix TMDB recall/accuracy for **TV episode scene names that include a 4-digit year** (often a release tag), e.g.:
`Man's.Inhumanity.to.Man.S01E03.2025.2160p.WEB-DL...`

Symptoms fixed:
- 正确剧集未召回，候选列表全是同年关键词碰撞条目（year 被当作硬过滤/硬裁剪）。
- 候选区/按钮编号不一致（文本行用 enumerate(start=1) 又被二次 +1）。

## Changes
1) TV search no longer uses year as a strict filter when year is likely unreliable
   - `tg_bot/tmdb_match_guess.py`: compute `year_for_search`; for TV-like queries (Sxx/Exx markers) year defaults to **soft** (not passed to TMDB search).
2) Year tightening is disabled for TV-like queries
   - Avoid dropping correct shows whose TMDB first_air_date_year differs from release tags.
3) Multi-search fallback is now triggered by *quality* (not only candidate count)
   - Even if we get many low-quality collisions, we still try `/search/multi` to improve recall.
4) Auto-pick year-distance guard skips TV-like queries
   - Prevents wrong year tags from blocking correct auto selection.
5) Fix candidate numbering mismatch in weak auto-pick correction UI
   - `tg_bot/share_flow_resolve.py`: remove enumerate(start=1) to keep text list numbering consistent with callback indexes / buttons.

## Files changed
- tg_bot/tmdb_match_guess.py
- tg_bot/share_flow_resolve.py
- notifier/config.py (APP_VERSION)
- PATCH_NOTES.md

---

# v62 (2025-12-29) 115 扫码登录：可选绑定类型

## UI
- Admin -> TG Bot -> 115 云下载：新增“扫码绑定类型”下拉框（支付宝生活/微信生活/android/ios/tv/harmony/web）。

## Backend
- 115 扫码登录：/admin/tg-bot/115/qrcode/start 支持传入 `app`，并在扫码确认后按选定 app 换取 cookie。
- 选定的 app 会写入 `CLOUD115_QR_APP`（.env.local），作为下次默认值。

## Files changed
- admin/routes_part2.py
- notifier/templates/admin_settings.html
- static/admin.js
- notifier/config.py
- PATCH_NOTES.md
## schemefix1 (2025-12-28)
## schemefix1r1 (2025-12-28)
- Revert: .strm-specific mediainfo wait cap; use global MEDIAINFO_TIMEOUT behavior.

- Webhook/worker dedup: event-independent; AV-style folder-level dedup; 2nd-layer enqueue dedup.
- Adult detect: CODE_PATTERN 3~7 digits (FC2); AV/JAV segment match; keywords fc2/ppv/madou/onlyfans.
- Telegram: caption/overflow split line-aware; text split avoids cutting URLs; disable web preview for text messages.

---

# v51 (2025-12-28) Forward callback auth simplification

## Fix
- **Remove FORWARD_BRIDGE_TOKEN requirement for `/notify/mediahelp`**.
  Forward / MediaHelp callback now reuses **`MEDIAHELP_TOKEN`** as the only shared secret.

## Behavior
- Accepted token locations:
  - `Authorization: Bearer <token>` (or raw token)
  - `X-MediaHelp-Token: <token>`
  - `X-Forward-Token: <token>` (backward compatibility)
  - `?token=<token>`
- If `MEDIAHELP_TOKEN` is empty, endpoint denies by default unless `MEDIAHELP_ALLOW_PUBLIC_NOTIFY=true`.

## UI
- Removed `FORWARD_BRIDGE_TOKEN` field from Admin -> Forward tab to prevent misconfiguration.

## Files changed
- core/webhook_security.py
- api/mediahelp.py
- admin/routes_base.py
- admin/routes_part1.py
- notifier/templates/admin_settings.html
- notifier/config.py
- PATCH_NOTES.md


## v67.2
- Forward 订阅“秒弹”优化：订阅创建不再等待 SUB_CACHE 刷新锁（短等待0.25s，随后后台刷新），避免被 status 查询刷新拖慢。


# v70.0 (2025-12-30) TG 横图优先逻辑修正

## Fix
- Emby Backdrop URL 仅在存在 `BackdropImageTags/SeriesBackdropImageTags` 时才生成，避免 tag-less Backdrop/0 导致 fanart_url 假阳性并短路回查/TMDB兜底。
- covers 回查逻辑对“疑似无 tag 的 Backdrop URL”做过滤，确保能进入回查窗口。

## Logging
- Telegram 发送阶段当 `fanart_url` 下载失败（non-200 / 非图片 / 异常）时输出可见日志（自动剥离 api_key），方便排查为什么回退到竖图。

## Files changed
- notifier/service/emby.py
- notifier/service/enrich.py
- notifier/notifiers/telegram.py
- notifier/config.py

## v1.5.7.2
- tg_bot: dispatcher now imports only feature facades; callback/command routing is table-driven (priority preserved).
- tg_bot: add common callback_codec/callback_router + UpdateContext for better testability.
- tg_bot: migrate storage modules into tg_bot/storage/tables with full backward-compatible shims.

## v1.5.7.4

- tg_bot: remove root-level tmdb_match* and storage_* shims; move TMDB code under tg_bot/tmdb and storage code under tg_bot/storage.
- Update all internal imports accordingly.

## v1.5.7.3
- tg_bot: fix compatibility shim `tg_bot.service` to re-export all historical symbols (including underscore helpers) after refactor.

## 1.5.7.10 (2025-12-31)
- admin: rename and further split routes modules (remove routes_part1/routes_part2).
- no functional changes; structure-only refactor.

## 1.5.7.21 (2026-01-01)
- Fix: 成人条目 UI 标题避免重复拼接番号（"CODE CODE title"）。

## 1.5.8 (2026-01-01)
- Refactor(P0): 去重/媒体身份规则统一到 `core/media_identity.py`，webhook + worker + pipeline 共享同一套 key 生成逻辑，减少重复实现并降低后续维护成本。
- Files changed: `core/media_identity.py`, `api/webhook.py`, `notifier/worker.py`, `notifier/service/pipeline.py`, `notifier/config.py`.

## 1.6.2 (2026-01-01)

- Forward-bridge: centralized pending/task state with a single tick loop; removed per-task heartbeat loops; added background-task de-dup and opposite-action cancellation.
- Forward-bridge: refresh_sub_cache singleflight wrapper to reduce redundant refresh contention.
- TG bot: per-chat outbound queue (outbox) + 429 Retry-After handling for send/edit/delete calls (better ordering + fewer flood errors).
- TG bot: session persistence optional via sqlite (TG_SESSION_STORE=sqlite); added session/job/callback-token tables.
- TG bot: long-running job skeleton with cancel button for http_other offline submit (best-effort cancellation).

## 1.6.4 (2026-01-01)

- Douban Hotlist: 修复订阅面板 callback/token 兼容问题（旧接口误用导致按钮不可用）。
- Douban Hotlist: 订阅面板新增：通知开关（🔔/🔕）、自动建任务开关（🤖/🧑‍💻）、单条忽略（🙈）。
- Douban Hotlist: 新增忽略管理命令：/hotlist_ignore /hotlist_unignore /hotlist_ignores。
- Douban Hotlist: poller 支持 per-subscription filters（notify/auto_create/top_n）+ ignore 过滤。
- Douban Hotlist: 通知拆分为「新增通知」与「自动建任务结果」两路，支持分别开关；当仅开启结果通知时，消息将只汇总自动建任务结果。
- Douban Hotlist: 自动建任务支持规则过滤（filters_json.auto_rules）：min_rating / auto_top_n / kw_white / kw_black；新增命令 /hotlist_rules /hotlist_rule。
- Douban Hotlist: 自动建任务新增「轻量二次解析」元信息过滤：media=movie|tv、year_min/year_max、tag_white/tag_black（仅对通过初筛的条目抓 subject 页）。
- Douban Hotlist: 新增「仅新增」订阅策略：订阅时写入 seen 基线，后续仅对未出现过的条目发送新增通知 / 自动建任务；新增 seen 表避免因排行波动导致重复触发。
- Douban Hotlist: 新增分页回填：订阅面板提供「订阅并回填第一页」与「回填下一页」；新增命令 /hotlist_backfill_next。
- Douban Hotlist: 抓取优先使用 rexxar API（支持 start/count 分页），并保留 HTML 解析作为兜底。
- Config: 补齐 hotlist 相关设置项（jitter/concurrency/digest check interval 等），并修正 timeout/hour 字段名称兼容。
- Web Admin: 新增「热榜订阅」Tab（查看/新增订阅、调整开关/规则、触发回填下一页）。

## 1.6.1 (2026-01-01)
- P3: 配置预检（fail-fast）：`NOTIFIER_TYPES` / `PIPELINE_STEPS` 支持严格校验（默认跟随 `CONFIG_STRICT=true`），未知类型/步骤在启动期直接报错暴露。
- P3: Pipeline Step Registry：步骤通过注册表机制解耦，便于后续扩展/替换，不再硬编码在 runner 内。
- P3: CompositeNotifier 增强：支持单通道超时（`NOTIFIER_CHANNEL_TIMEOUT_SEC`）；require_all 模式下并行发送遇到首个失败会取消其余任务；失败摘要更清晰。
- P3: Worker Retry 改进：指数退避支持 cap（`NOTIFIER_RETRY_BACKOFF_MAX_SEC`）+ jitter（`NOTIFIER_RETRY_JITTER_RATIO`）+ Retry-After（针对 httpx 429/5xx）。
- P3: Deadletter：新增启动期保留/数量清理（`DEADLETTER_RETENTION_DAYS` / `DEADLETTER_MAX_FILES`）；记录增强（event/media_sig/dedup_key 以及 item_id/path...）。
- P3: Deadletter Replay 工具：`python -m tools.replay_deadletter` 可将死信 payload 回放到 `/emby/webhook`。
- P3: 多实例一致性：入队兜底去重支持持久化（`ENQUEUE_DEDUP_PERSISTENT` / `ENQUEUE_DEDUP_KEY_PREFIX`）。
- P3: Metrics：支持 labels；增加 build-info（`app_build_info{version="..."}`）与外部服务请求/错误维度（`external_*{service=...}`），并在成功发送处增加 `notify_sent_total{event,media_type}`。


## v1.6.5.27
- hotlist: 删除订阅级联清理 ignore/seen；无订阅者时清理 snapshot
- hotlist: snapshot 支持空列表覆盖（避免 UI 长期显示旧榜单）
- hotlist: poller 批量读取 ignore/seen，首轮 baseline_ready=false 时仅同步 seen，避免炸自动建任务
- admin: hotlist.json ignore_count 批量统计；移除重复 session 赋值

## v1.6.5.28
- hotlist: 删除不可达死代码（批量热榜通知 flush 已收敛为“丢弃队列”），保留面板 preview 逻辑
- hotlist: poller/run_hotlist_daemon 去掉无效 notifier/notify_cb 链路（降低维护成本）
- hotlist: ignore 增加 TTL/容量治理（HOTLIST_IGNORE_TTL_DAYS 默认 180；HOTLIST_IGNORE_MAX_PER_SUB 默认 5000）
- db: 新增 ignore.created_ts 索引（加速 TTL/裁剪清理）
- build: 打包前清理 __pycache__/*.pyc，确保 nopyc 包不含 pyc

## v1.6.5.29
- hotlist: notify.py 删除未使用的 NotifyCoalescer/事件合并逻辑（仅保留面板 preview 构造）
- hotlist: ignore/seen 的 TTL 清理改为“限频 GC”，避免每次写入都触发表扫描（提醒：可用 HOTLIST_*_GC_INTERVAL_SEC 配置）
- hotlist: seen 增加容量上限治理（HOTLIST_SEEN_MAX_PER_SUB 默认 20000）
- admin: count_ignores_bulk 增加 chat_id/list_key 过滤，避免大表全表 GROUP BY
- db: 新增 idx_douban_hotlist_seen_list_ts 索引（加速 seen 裁剪/查询）

## v1.6.12.13 (2026-01-04)
- Fix: core/http_clients 改为 per-event-loop client/lock，避免在不同 event loop 场景下触发 "bound to a different event loop"（隐形 crash）。
- Fix: plugin 加载失败不再静默吞掉；当 CONFIG_STRICT=true 时保持 fail-fast。
- Fix: plugin 路由默认仅在 API role 暴露；worker-only role 默认不暴露新增 HTTP 端点（除非 add_router(..., api_only=False)）。
- Fix: /debug/config 的来源判定遵循 ENV 优先级，避免在 ENV 覆盖 dotenv 时显示错误来源。

## v1.6.12.14 (2026-01-04)
- Fix: 全面收敛 asyncio 原语为 loop-local，避免多 loop/热重载/工具脚本/测试环境下出现 "bound to a different event loop"：
  - forward_bridge subscription cache singleflight lock/task
  - tg_bot polling commands sync lock
  - tg_bot TMDB match inflight reuse lock/dict + TMDB concurrency semaphore
  - tmdb alias enrich semaphore
  - 115 share global semaphore + min-interval limiter
  - CallbackGuard 全部锁改为 per-loop state
  - AsyncRateLimiter 内部锁改为 per-loop
- Chore: 新增 core/loop_local.py 作为统一 loop-local helper。

## v1.6.12.19 (2026-01-04)
- Config: 进一步硬化“配置入口唯一”规范：业务模块禁止直接 os.getenv(...)，仅允许 bootstrap/version/debug/runtime_env/settings 模块读取 env。
- Config: 新增 core/runtime_env.py 统一收口进程形态/诊断类 getenv，移除 forward_bridge/tg_bot import-time getenv。
- Security: ADMIN_PBKDF2_ITERATIONS 纳入 Settings 且带安全钳制；无效值自动回退默认值避免启动/登录崩溃。
- CI: tools/check_config_access.py 增强门禁，防止 getenv/dotenv 回归造成配置来源混乱。

## v1.6.12.16 (2026-01-04)
- Config: 采用方案 A：优先级固定为 ENV > .env（可选） > DEFAULT；取消 .env.local 参与生效。
- Config: 移除将 dotenv 写回 os.environ 的逻辑，reload_settings 仅重建 Settings（不污染运行态环境变量）。
- Admin/UI: 配置保存统一写入 /data/.env，并触发 runtime reload。
- Debug: /debug/config 来源判定简化为 ENV/DOTENV/DEFAULT，并新增 dotenv 被 ENV 覆盖的 key 列表（避免诊断误导）。

## v1.6.12.15 (2026-01-04)
- Chore: 新增 tools/check_asyncio_globals.py（AST 扫描）作为防回归门禁，禁止在模块 import 时创建 asyncio.Lock/Event/Queue/Semaphore/Future/Task 等（避免跨 event loop 隐形崩溃）。
- Chore: pre-commit 增加本地 hook（check-asyncio-globals）。
- CI: 新增 GitHub Actions workflow（.github/workflows/ci.yml），运行 ruff + asyncio 门禁 + pytest。
