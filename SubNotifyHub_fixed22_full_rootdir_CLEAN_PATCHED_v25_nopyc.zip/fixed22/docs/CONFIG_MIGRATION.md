# Configuration Migration Guide

本指南说明如何从旧的硬编码配置迁移到新的统一配置模块。

## 概述

在此次重构中，我们将分散在代码各处的硬编码配置值统一到以下模块：

| 模块 | 路径 | 用途 |
|------|------|------|
| Timeout | `settings/timeouts.py` | 超时配置 |
| Retry | `settings/retries.py` | 重试配置 |
| Cache | `settings/caches.py` | 缓存配置 |
| Database | `settings/database.py` | 数据库配置 |

## 迁移步骤

### 1. 超时配置迁移

#### 旧代码

```python
# 硬编码超时值
async with httpx.AsyncClient(timeout=10.0) as client:
    response = await client.get(url)

# SQLite busy timeout
conn = sqlite3.connect(db_path, timeout=30)
conn.execute("PRAGMA busy_timeout = 5000")
```

#### 新代码

```python
from settings.timeouts import TimeoutCategory, get_timeout, get_db_busy_timeout_ms

# 使用配置模块
async with httpx.AsyncClient(timeout=get_timeout(TimeoutCategory.HTTP_DEFAULT)) as client:
    response = await client.get(url)

# SQLite busy timeout
conn = sqlite3.connect(db_path, timeout=get_timeout(TimeoutCategory.DB_CONNECT))
conn.execute(f"PRAGMA busy_timeout = {get_db_busy_timeout_ms()}")
```

#### 超时类别映射

| 旧硬编码值 | 新配置类别 |
|-----------|-----------|
| `timeout=10.0` (HTTP) | `TimeoutCategory.HTTP_DEFAULT` |
| `timeout=5.0` (快速) | `TimeoutCategory.HTTP_SHORT` |
| `timeout=30.0` (长) | `TimeoutCategory.HTTP_LONG` |
| `timeout=30` (DB) | `TimeoutCategory.DB_CONNECT` |
| `busy_timeout=5000` | `TimeoutCategory.DB_BUSY` (使用 `get_db_busy_timeout_ms()`) |
| `timeout=12.0` (TG) | `TimeoutCategory.TG_API` |
| `timeout=8.0` (TMDB) | `TimeoutCategory.TMDB_API` |
| `timeout=15.0` (115) | `TimeoutCategory.CLOUD115_API` |
| `timeout=15.0` (MH) | `TimeoutCategory.MH_API` |

---

### 2. 重试配置迁移

#### 旧代码

```python
# 硬编码重试值
max_attempts = 3
backoff_base = 1.0

for attempt in range(max_attempts):
    try:
        result = await make_request()
        break
    except Exception:
        await asyncio.sleep(backoff_base * (2 ** attempt))
```

#### 新代码

```python
from settings.retries import RetryCategory, get_retry_config

# 使用配置模块
config = get_retry_config(RetryCategory.HTTP_DEFAULT)

for attempt in range(config.max_retries):
    try:
        result = await make_request()
        break
    except Exception:
        backoff = min(config.backoff_base * (2 ** attempt), config.backoff_max)
        await asyncio.sleep(backoff)
```

#### 重试类别映射

| 旧硬编码值 | 新配置类别 |
|-----------|-----------|
| `max_attempts=3` (HTTP) | `RetryCategory.HTTP_DEFAULT` |
| `max_attempts=5` (关键) | `RetryCategory.HTTP_CRITICAL` |
| `retries=3` (DB) | `RetryCategory.DB_DEFAULT` |
| `max_attempts=3` (TG) | `RetryCategory.TG_API` |
| `max_attempts=3` (外部) | `RetryCategory.EXTERNAL_SERVICE` |

---

### 3. 缓存配置迁移

#### 旧代码

```python
# 硬编码缓存配置
cache = LRUCache(maxsize=1000)
TTL_SECONDS = 600
```

#### 新代码

```python
from settings.caches import CacheTTL, CacheSize, get_cache_ttl, get_cache_size, get_cache_config

# 使用配置模块
config = get_cache_config(CacheTTL.MEDIUM, CacheSize.MEDIUM)
cache = LRUCache(maxsize=config.max_size)
ttl = config.ttl_seconds

# 或单独获取
ttl = get_cache_ttl(CacheTTL.MEDIUM)
size = get_cache_size(CacheSize.MEDIUM)
```

#### 缓存类别映射

| 旧硬编码值 | 新配置类别 |
|-----------|-----------|
| TTL 60s | `CacheTTL.SHORT` |
| TTL 600s | `CacheTTL.MEDIUM` |
| TTL 3600s | `CacheTTL.LONG` |
| TTL 86400s | `CacheTTL.PERSISTENT` |
| Size 200 | `CacheSize.SMALL` |
| Size 1000 | `CacheSize.MEDIUM` |
| Size 5000 | `CacheSize.LARGE` |

---

### 4. 数据库配置迁移

#### 旧代码

```python
# 硬编码数据库配置
conn = sqlite3.connect(
    db_path,
    timeout=30,
    check_same_thread=False
)
conn.execute("PRAGMA busy_timeout = 5000")
conn.execute("PRAGMA journal_mode = WAL")
```

#### 新代码

```python
from settings.database import DBConfig, get_db_config

# 使用配置模块
conn = sqlite3.connect(
    db_path,
    timeout=get_db_config(DBConfig.CONNECT_TIMEOUT),
    check_same_thread=get_db_config(DBConfig.CHECK_SAME_THREAD)
)
conn.execute(f"PRAGMA busy_timeout = {get_db_config(DBConfig.BUSY_TIMEOUT)}")
if get_db_config(DBConfig.WAL_MODE):
    conn.execute("PRAGMA journal_mode = WAL")
```

---

## 环境变量覆盖

迁移后，所有配置值都可以通过环境变量覆盖，无需修改代码。

### 超时配置

```bash
export TIMEOUT_HTTP_DEFAULT=15.0
export TIMEOUT_TG_API=20.0
export TIMEOUT_DB_BUSY=10.0
```

### 重试配置

```bash
export RETRY_HTTP_DEFAULT_MAX=5
export RETRY_HTTP_DEFAULT_BACKOFF_BASE=2.0
export RETRY_TG_API_MAX=5
```

### 缓存配置

```bash
export CACHE_TTL_SHORT=120
export CACHE_SIZE_MEDIUM=2000
```

### 数据库配置

```bash
export DB_BUSY_TIMEOUT=10000
export DB_WAL_MODE=false
```

---

## 向后兼容性

### 默认值保持

所有默认值与原硬编码值完全一致，确保迁移后行为不变：

| 配置 | 原硬编码值 | 新默认值 |
|------|-----------|---------|
| HTTP 超时 | 10.0s | 10.0s |
| DB 连接超时 | 30s | 30s |
| SQLite busy timeout | 5000ms | 5000ms |
| HTTP 重试次数 | 3 | 3 |
| 缓存 TTL (中) | 600s | 600s |

### 无效值处理

如果环境变量设置了无效值，系统会：

1. 记录警告日志
2. 使用默认值
3. 继续正常运行

```python
# 示例：无效值处理
# 环境变量: TIMEOUT_HTTP_DEFAULT=-5.0
# 日志: WARNING - Invalid timeout value (must be positive): TIMEOUT_HTTP_DEFAULT=-5.0, using default
# 实际使用: 10.0 (默认值)
```

---

## 测试验证

迁移后，运行以下测试确保配置正确：

```bash
# 运行配置模块属性测试
pytest tests/contract/test_timeout_config_properties.py -v
pytest tests/contract/test_retry_config_properties.py -v
pytest tests/contract/test_cache_config_properties.py -v
pytest tests/contract/test_database_config_properties.py -v
pytest tests/contract/test_config_validation_properties.py -v
pytest tests/contract/test_config_defaults_properties.py -v

# 运行完整测试套件
pytest tests/ -v
```

---

## 常见问题

### Q: 迁移后超时值变了怎么办？

A: 检查是否设置了环境变量覆盖。使用以下命令查看：

```bash
env | grep -E "^(TIMEOUT_|RETRY_|CACHE_|DB_)"
```

### Q: 如何恢复原始硬编码行为？

A: 删除所有相关环境变量，系统将使用与原硬编码值一致的默认值。

### Q: 如何为特定环境设置不同配置？

A: 在 `.env` 文件或部署配置中设置环境变量：

```bash
# .env.production
TIMEOUT_HTTP_DEFAULT=15.0
RETRY_HTTP_DEFAULT_MAX=5

# .env.development
TIMEOUT_HTTP_DEFAULT=5.0
RETRY_HTTP_DEFAULT_MAX=2
```

### Q: 配置模块支持热更新吗？

A: 不支持。配置值在首次调用时从环境变量读取。如需更改，需要重启应用。

---

## 迁移检查清单

- [ ] 更新所有 `timeout=` 硬编码为 `get_timeout()` 调用
- [ ] 更新所有 `max_attempts=` / `retries=` 硬编码为 `get_retry_config()` 调用
- [ ] 更新所有缓存 TTL/Size 硬编码为 `get_cache_*()` 调用
- [ ] 更新所有数据库配置硬编码为 `get_db_config()` 调用
- [ ] 运行完整测试套件确保无回归
- [ ] 更新部署文档，说明新的环境变量
- [ ] 在 staging 环境验证配置覆盖功能
