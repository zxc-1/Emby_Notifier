# Settings (CONFIG_SCHEMA_VERSION=1)

This project uses **pydantic-settings**. Settings are loaded in this order:

1. Explicit init (tests/embedding)
2. Environment variables
3. `.env` file (path controlled by `ENV_PATH`, default `/data/.env`)
4. Secrets files (Docker/K8s secrets)

> **Important:** keep `CONFIG_SCHEMA_VERSION=1` unless you are upgrading across a schema-breaking release.

## Core

- `APP_NAME` (default: `Emby Notifier`)
- `APP_VERSION` (auto from `core.version.get_version()`)
- `APP_ROLE` (`api` / `worker` / `all`)
- `LOG_LEVEL` (`INFO`/`DEBUG`/...)

### Schema / strictness

- `CONFIG_SCHEMA_VERSION` (int, default `1`)
- `CONFIG_STRICT` (bool, default `true`)  
  When true, config mistakes and plugin incompatibilities fail startup.

## Plugins

- `PLUGINS` (comma/space separated module list)  
  Default: `notifier.plugins.builtin_notifiers`

A plugin module should define:

- `PLUGIN_API_VERSION` (must match `core.plugin_api.PLUGIN_API_VERSION`)
- Optional `PLUGIN_INFO` mapping
- Optional callable `register(registry, *, app=None, settings=None)`

### Notifier channels via plugins

Plugins can contribute notifier channels by writing to:

- `registry.data["notifiers"] = {"telegram": TelegramNotifier, ...}`

At startup, `bootstrap.bootstrap_wiring.build_notifier_chain()` mirrors these into the runtime `NotifierRegistry`.

## Telegram (outbound notifications)

- `TG_BOT_TOKEN` (required)
- `TG_CHAT_ID` (required)
- `TG_PARSE_MODE` (optional: `HTML` / `MarkdownV2`)

### Channel selection

- `NOTIFIER_TYPES` (comma separated; default empty -> telegram)
- `NOTIFIER_STRICT` (default follows `CONFIG_STRICT`)
- `NOTIFIER_SEND_PARALLEL` (bool)
- `NOTIFIER_SEND_REQUIRE_ALL` (bool)
- `NOTIFIER_CHANNEL_TIMEOUT_SEC` (float)

## TMDB (metadata enrichment)

- `TMDB_API_KEY` (optional but recommended)
- `TMDB_LANGUAGE` (optional, e.g. `zh-CN`)
- `TMDB_REGION` (optional, e.g. `CN`)

---

## Unified Configuration Modules

以下配置模块提供统一的超时、重试、缓存和数据库配置管理。所有配置值都可以通过环境变量覆盖。

### Timeout Configuration (`settings/timeouts.py`)

超时配置模块提供统一的超时值管理。

#### 环境变量格式

```
TIMEOUT_{CATEGORY_NAME}=<seconds>
```

#### 可用类别

| 类别 | 环境变量 | 默认值 | 说明 |
|------|---------|--------|------|
| `HTTP_DEFAULT` | `TIMEOUT_HTTP_DEFAULT` | `10.0` | 默认 HTTP 请求超时 |
| `HTTP_SHORT` | `TIMEOUT_HTTP_SHORT` | `5.0` | 短超时（快速失败场景） |
| `HTTP_LONG` | `TIMEOUT_HTTP_LONG` | `30.0` | 长超时（大文件、慢接口） |
| `DB_CONNECT` | `TIMEOUT_DB_CONNECT` | `30.0` | 数据库连接超时 |
| `DB_BUSY` | `TIMEOUT_DB_BUSY` | `5.0` | SQLite busy timeout（秒） |
| `TASK_DEFAULT` | `TIMEOUT_TASK_DEFAULT` | `30.0` | 默认任务超时 |
| `TASK_LONG` | `TIMEOUT_TASK_LONG` | `120.0` | 长任务超时 |
| `TASK_SHORT` | `TIMEOUT_TASK_SHORT` | `10.0` | 短任务超时 |
| `TG_API` | `TIMEOUT_TG_API` | `12.0` | Telegram API 超时 |
| `TMDB_API` | `TIMEOUT_TMDB_API` | `8.0` | TMDB API 超时 |
| `CLOUD115_API` | `TIMEOUT_CLOUD115_API` | `15.0` | 115 API 超时 |
| `MH_API` | `TIMEOUT_MH_API` | `15.0` | MediaHelp API 超时 |

#### 有效范围

- 所有超时值必须为正数（> 0）
- 不接受无穷大（`inf`）或非数字值
- 无效值将记录警告并使用默认值

#### 使用示例

```python
from settings.timeouts import TimeoutCategory, get_timeout, get_db_busy_timeout_ms

# 获取 HTTP 默认超时
timeout = get_timeout(TimeoutCategory.HTTP_DEFAULT)  # 10.0

# 获取自定义默认值
timeout = get_timeout(TimeoutCategory.HTTP_DEFAULT, default=20.0)

# 获取 SQLite busy timeout（毫秒）
busy_ms = get_db_busy_timeout_ms()  # 5000
```

```bash
# 环境变量覆盖示例
export TIMEOUT_HTTP_DEFAULT=15.0
export TIMEOUT_TG_API=20.0
```

---

### Retry Configuration (`settings/retries.py`)

重试配置模块提供统一的重试策略管理。

#### 环境变量格式

```
RETRY_{CATEGORY}_MAX=<count>
RETRY_{CATEGORY}_BACKOFF_BASE=<seconds>
RETRY_{CATEGORY}_BACKOFF_MAX=<seconds>
```

#### 可用类别

| 类别 | 默认重试次数 | 默认退避基数 | 默认最大退避 | 说明 |
|------|-------------|-------------|-------------|------|
| `HTTP_DEFAULT` | 3 | 1.0s | 30.0s | 默认 HTTP 重试 |
| `HTTP_CRITICAL` | 5 | 1.0s | 60.0s | 关键 HTTP 请求（更多重试） |
| `DB_DEFAULT` | 3 | 0.1s | 5.0s | 数据库操作重试 |
| `TG_API` | 3 | 0.6s | 10.0s | Telegram API 重试 |
| `EXTERNAL_SERVICE` | 3 | 1.0s | 30.0s | 外部服务重试 |

#### 环境变量示例

| 环境变量 | 说明 |
|---------|------|
| `RETRY_HTTP_DEFAULT_MAX` | HTTP 默认最大重试次数 |
| `RETRY_HTTP_DEFAULT_BACKOFF_BASE` | HTTP 默认退避基数 |
| `RETRY_HTTP_CRITICAL_MAX` | 关键 HTTP 最大重试次数 |
| `RETRY_TG_API_MAX` | Telegram API 最大重试次数 |

#### 有效范围

- `max_retries`: 非负整数（>= 0）
- `backoff_base`: 非负浮点数（>= 0），不接受无穷大
- `backoff_max`: 非负浮点数（>= 0），不接受无穷大
- 无效值将记录警告并使用默认值

#### 使用示例

```python
from settings.retries import RetryCategory, get_retry_config

# 获取 HTTP 默认重试配置
config = get_retry_config(RetryCategory.HTTP_DEFAULT)
print(config.max_retries)   # 3
print(config.backoff_base)  # 1.0
print(config.backoff_max)   # 30.0
print(config.backoff)       # (0.0, 1.0)

# 获取 Telegram API 重试配置
tg_config = get_retry_config(RetryCategory.TG_API)
```

```bash
# 环境变量覆盖示例
export RETRY_HTTP_DEFAULT_MAX=5
export RETRY_HTTP_DEFAULT_BACKOFF_BASE=2.0
export RETRY_TG_API_MAX=5
```

---

### Cache Configuration (`settings/caches.py`)

缓存配置模块提供统一的缓存策略管理。

#### 环境变量格式

```
CACHE_TTL_{CATEGORY}=<seconds>
CACHE_SIZE_{CATEGORY}=<count>
```

#### TTL 类别

| 类别 | 环境变量 | 默认值 | 说明 |
|------|---------|--------|------|
| `SHORT` | `CACHE_TTL_SHORT` | `60` | 短期缓存（1 分钟） |
| `MEDIUM` | `CACHE_TTL_MEDIUM` | `600` | 中期缓存（10 分钟） |
| `LONG` | `CACHE_TTL_LONG` | `3600` | 长期缓存（1 小时） |
| `PERSISTENT` | `CACHE_TTL_PERSISTENT` | `86400` | 持久缓存（1 天） |

#### Size 类别

| 类别 | 环境变量 | 默认值 | 说明 |
|------|---------|--------|------|
| `SMALL` | `CACHE_SIZE_SMALL` | `200` | 小缓存（200 条） |
| `MEDIUM` | `CACHE_SIZE_MEDIUM` | `1000` | 中缓存（1000 条） |
| `LARGE` | `CACHE_SIZE_LARGE` | `5000` | 大缓存（5000 条） |

#### 有效范围

- TTL 值必须为正整数（> 0）
- Size 值必须为正整数（> 0）
- 无效值将记录警告并使用默认值

#### 使用示例

```python
from settings.caches import CacheTTL, CacheSize, get_cache_ttl, get_cache_size, get_cache_config

# 获取短期 TTL
ttl = get_cache_ttl(CacheTTL.SHORT)  # 60

# 获取中等缓存大小
size = get_cache_size(CacheSize.MEDIUM)  # 1000

# 获取组合配置
config = get_cache_config(CacheTTL.MEDIUM, CacheSize.SMALL)
print(config.ttl_seconds)  # 600
print(config.max_size)     # 200
```

```bash
# 环境变量覆盖示例
export CACHE_TTL_SHORT=120
export CACHE_SIZE_MEDIUM=2000
```

---

### Database Configuration (`settings/database.py`)

数据库配置模块提供统一的数据库设置管理。

#### 环境变量格式

```
DB_{KEY_NAME}=<value>
```

#### 可用配置

| 配置键 | 环境变量 | 默认值 | 类型 | 说明 |
|--------|---------|--------|------|------|
| `CONNECT_TIMEOUT` | `DB_CONNECT_TIMEOUT` | `30` | int | 连接超时（秒） |
| `BUSY_TIMEOUT` | `DB_BUSY_TIMEOUT` | `5000` | int | SQLite busy timeout（毫秒） |
| `RETRY_COUNT` | `DB_RETRY_COUNT` | `3` | int | 重试次数 |
| `WAL_MODE` | `DB_WAL_MODE` | `true` | bool | 是否启用 WAL 模式 |
| `CHECK_SAME_THREAD` | `DB_CHECK_SAME_THREAD` | `false` | bool | SQLite check_same_thread |

#### 有效范围

- 整数配置（`CONNECT_TIMEOUT`, `BUSY_TIMEOUT`, `RETRY_COUNT`）：非负整数（>= 0）
- 布尔配置（`WAL_MODE`, `CHECK_SAME_THREAD`）：`1`, `true`, `yes`, `on` 为真，其他为假
- 无效值将记录警告并使用默认值

#### 使用示例

```python
from settings.database import DBConfig, get_db_config

# 获取连接超时
timeout = get_db_config(DBConfig.CONNECT_TIMEOUT)  # 30

# 获取 busy timeout（毫秒）
busy_ms = get_db_config(DBConfig.BUSY_TIMEOUT)  # 5000

# 获取 WAL 模式设置
wal_mode = get_db_config(DBConfig.WAL_MODE)  # True

# 获取 check_same_thread 设置
check_thread = get_db_config(DBConfig.CHECK_SAME_THREAD)  # False
```

```bash
# 环境变量覆盖示例
export DB_BUSY_TIMEOUT=10000
export DB_WAL_MODE=false
export DB_RETRY_COUNT=5
```

---

### Common Scenarios

#### 高延迟网络环境

```bash
# 增加所有 HTTP 超时
export TIMEOUT_HTTP_DEFAULT=30.0
export TIMEOUT_HTTP_LONG=60.0
export TIMEOUT_TG_API=30.0
export TIMEOUT_TMDB_API=20.0

# 增加重试次数
export RETRY_HTTP_DEFAULT_MAX=5
export RETRY_TG_API_MAX=5
```

#### 低内存环境

```bash
# 减少缓存大小
export CACHE_SIZE_SMALL=100
export CACHE_SIZE_MEDIUM=500
export CACHE_SIZE_LARGE=2000

# 减少缓存 TTL
export CACHE_TTL_LONG=1800
export CACHE_TTL_PERSISTENT=43200
```

#### 高并发数据库访问

```bash
# 增加 SQLite busy timeout
export DB_BUSY_TIMEOUT=10000

# 增加数据库重试
export DB_RETRY_COUNT=5
```

#### 快速失败模式

```bash
# 减少超时和重试
export TIMEOUT_HTTP_DEFAULT=5.0
export TIMEOUT_HTTP_SHORT=2.0
export RETRY_HTTP_DEFAULT_MAX=1
```

<!-- AUTO-GENERATED:SETTINGS -->

## Complete Settings Reference (auto-generated)

| Key | Type | Default | Description |
|---|---|---|---|
| `ADMIN_PASSWORD_FILE` | `str` | `/data/emby_notifier_admin.json` |  |
| `ADMIN_PBKDF2_ITERATIONS` | `int` | `210000` |  |
| `ADMIN_SESSION_SECRET` | `Optional` | `null` |  |
| `ADMIN_USERNAME` | `str` | `admin` |  |
| `ADULT_DETAIL_BASE_URL` | `Optional` | `null` |  |
| `ADULT_FORCE_LIBRARIES` | `List` | `PydanticUndefined` |  |
| `ADULT_FORCE_PATH_PREFIXES` | `List` | `PydanticUndefined` |  |
| `ADULT_IGNORE_LIBRARIES` | `List` | `PydanticUndefined` |  |
| `ADULT_IGNORE_PATH_PREFIXES` | `List` | `PydanticUndefined` |  |
| `APP_NAME` | `str` | `Emby Notifier` |  |
| `APP_ROLE` | `str` | `api` |  |
| `APP_VERSION` | `str` | `PydanticUndefined` |  |
| `BLOB_STORE_DIR` | `str` | `/data/blob_store` |  |
| `CLOUD115_API_TIMEOUT_SEC` | `float` | `30.0` |  |
| `CLOUD115_COOKIE` | `Optional` | `null` |  |
| `CLOUD115_DIR_CID` | `Optional` | `null` |  |
| `CLOUD115_DIR_MODE` | `str` | `default` |  |
| `CLOUD115_DUP_MODE` | `str` | `` |  |
| `CLOUD115_DUP_PERSISTENT` | `bool` | `false` |  |
| `CLOUD115_DUP_WINDOW_MINUTES` | `int` | `10` |  |
| `CLOUD115_HEALTHCHECK_ENABLED` | `bool` | `true` |  |
| `CLOUD115_HEALTHCHECK_FAIL_THRESHOLD` | `int` | `2` |  |
| `CLOUD115_HEALTHCHECK_INTERVAL_SEC` | `int` | `21600` |  |
| `CLOUD115_HEALTHCHECK_NOTIFY_COOLDOWN_SEC` | `int` | `7200` |  |
| `CLOUD115_HEALTHCHECK_TIMEOUT_SEC` | `float` | `6.0` |  |
| `CLOUD115_OFFLINE_FLOW_TIMEOUT` | `float` | `30.0` |  |
| `CLOUD115_POLL_ON_SUBMIT` | `bool` | `true` |  |
| `CLOUD115_QR_APP` | `str` | `alipaymini` |  |
| `CLOUD115_TARGET_WP_PATH_ID` | `Optional` | `null` |  |
| `CLOUD115_TARGET_WP_PATH_NAME` | `Optional` | `null` |  |
| `CONFIG_SCHEMA_VERSION` | `int` | `1` |  |
| `CONFIG_STRICT` | `bool` | `true` |  |
| `DEADLETTER_MAX_FILES` | `int` | `200` |  |
| `DEADLETTER_RETENTION_DAYS` | `int` | `14` |  |
| `DEBUG_ENABLE_DEBUG_API` | `bool` | `false` |  |
| `DEBUG_NOTIFICATION_HISTORY_SIZE` | `int` | `100` |  |
| `DEDUP_MAX_SIZE` | `int` | `5000` |  |
| `DEDUP_PERSISTENT` | `bool` | `false` |  |
| `DEDUP_TTL_SECONDS` | `int` | `600` |  |
| `DOUBAN_PROXY_URL` | `Optional` | `null` |  |
| `EMBY_API_KEY` | `Optional` | `null` |  |
| `EMBY_BASE_URL` | `Optional` | `null` |  |
| `EMBY_WAIT_FOR_IMAGE_ENABLED` | `bool` | `true` |  |
| `EMBY_WAIT_FOR_IMAGE_INTERVAL` | `int` | `3` |  |
| `EMBY_WAIT_FOR_IMAGE_MAX_WAIT` | `int` | `15` |  |
| `ENABLE_SEASON_FILTER` | `bool` | `false` |  |
| `ENQUEUE_DEDUP_KEY_PREFIX` | `str` | `dedup:enqueue:` |  |
| `ENQUEUE_DEDUP_PERSISTENT` | `Optional` | `null` |  |
| `EPISODE_DEDUP_STRATEGY` | `str` | `series` |  |
| `FORWARD_BRIDGE_ALLOW_NO_TOKEN` | `Optional` | `null` |  |
| `FORWARD_BRIDGE_ALLOW_PUBLIC_NOTIFY` | `bool` | `false` |  |
| `FORWARD_BRIDGE_DEBUG` | `bool` | `false` |  |
| `FORWARD_BRIDGE_ENABLED` | `bool` | `true` |  |
| `FORWARD_BRIDGE_SUB_CACHE_TTL` | `int` | `600` |  |
| `FORWARD_BRIDGE_TOKEN` | `Optional` | `null` |  |
| `FORWARD_BRIDGE_TOKEN_TTL` | `int` | `2505600` |  |
| `HOTLIST_AUTO_CREATE_CONCURRENCY` | `int` | `4` |  |
| `HOTLIST_AUTO_CREATE_SUBS` | `bool` | `true` |  |
| `HOTLIST_BACKFILL_LIMIT` | `int` | `50` |  |
| `HOTLIST_DEDUP_TTL_DAYS` | `int` | `30` |  |
| `HOTLIST_DEFAULT_MODE_GROUP` | `str` | `digest` |  |
| `HOTLIST_DEFAULT_MODE_PRIVATE` | `str` | `incremental` |  |
| `HOTLIST_DIGEST_CHECK_INTERVAL_SEC` | `int` | `60` |  |
| `HOTLIST_DIGEST_HOUR_LOCAL` | `int` | `9` |  |
| `HOTLIST_DIGEST_TOP_N` | `int` | `15` |  |
| `HOTLIST_ENABLED` | `bool` | `true` |  |
| `HOTLIST_HTTP_TIMEOUT_SEC` | `float` | `15.0` |  |
| `HOTLIST_NOTIFY_COALESCE_WINDOW_SEC` | `int` | `45` |  |
| `HOTLIST_POLL_INTERVAL_SEC` | `int` | `3600` |  |
| `HOTLIST_POLL_JITTER_RATIO` | `float` | `0.1` |  |
| `HOTLIST_SUBSCRIBE_BACKFILL` | `bool` | `true` |  |
| `KV_CACHE_MAX_BYTES` | `int` | `262144` |  |
| `KV_CACHE_VACUUM` | `bool` | `false` |  |
| `KV_STORE_BACKEND` | `str` | `sqlite` |  |
| `LOG_LEVEL` | `str` | `INFO` |  |
| `MEDIAHELP_BASE` | `Optional` | `null` |  |
| `MEDIAHELP_LOGIN_PASSWORD` | `Optional` | `null` |  |
| `MEDIAHELP_LOGIN_USERNAME` | `Optional` | `null` |  |
| `MEDIAHELP_TOKEN` | `Optional` | `null` |  |
| `MEDIAINFO_INTERVAL` | `float` | `1.0` |  |
| `MEDIAINFO_TIMEOUT` | `int` | `30` |  |
| `MEDIAINFO_WAIT_ENABLED` | `bool` | `true` |  |
| `NOTIFIER_AGGREGATE_MAX_ITEMS` | `int` | `20` |  |
| `NOTIFIER_AGGREGATE_WINDOW` | `float` | `30` |  |
| `NOTIFIER_CHANNEL_TIMEOUT_SEC` | `float` | `15.0` |  |
| `NOTIFIER_DEADLETTER_DIR` | `str` | `/data/deadletter` |  |
| `NOTIFIER_DRY_RUN` | `bool` | `false` |  |
| `NOTIFIER_ENQUEUE_TIMEOUT` | `float` | `2.0` |  |
| `NOTIFIER_MAX_QUEUE_SIZE` | `int` | `100` |  |
| `NOTIFIER_MAX_RETRY` | `int` | `3` |  |
| `NOTIFIER_RETRY_BACKOFF_BASE` | `float` | `2.0` |  |
| `NOTIFIER_RETRY_BACKOFF_MAX_SEC` | `float` | `60.0` |  |
| `NOTIFIER_RETRY_JITTER_RATIO` | `float` | `0.1` |  |
| `NOTIFIER_SEND_PARALLEL` | `bool` | `false` |  |
| `NOTIFIER_SEND_REQUIRE_ALL` | `bool` | `true` |  |
| `NOTIFIER_STRICT` | `Optional` | `null` |  |
| `NOTIFIER_TYPES` | `str` | `` |  |
| `NOTIFIER_WORKER_CONCURRENCY` | `int` | `3` |  |
| `PIPELINE_STEPS` | `str` | `extract,enrich,render,covers,content` |  |
| `PIPELINE_STEPS_BY_SOURCE` | `str` | `` | per-source overrides: `emby=extract,...; jellyfin=extract_jf,...` |
| `PIPELINE_STRICT` | `Optional` | `null` |  |
| `PLUGINS` | `str` | `notifier.plugins.builtin_notifiers` |  |
| `PLUGINS_STRICT` | `bool | None` | `null` |  |
| `SHARE115_BFS_BATCH_SIZE` | `int` | `4` |  |
| `SHARE115_DEFAULT_HOST` | `str` | `115.com` |  |
| `SHARE115_EPISODE_EARLY_STOP_MIN_VIDEOS` | `int` | `8` |  |
| `SHARE115_GLOBAL_MAX_CONCURRENCY` | `int` | `6` |  |
| `SHARE115_LOG_SAMPLES` | `bool` | `false` |  |
| `SHARE115_MIN_INTERVAL_MS` | `int` | `0` |  |
| `SHARE115_RESOLVE_PERSIST_TTL_SEC` | `int` | `86400` |  |
| `SHARE115_USE_SHARED_HTTP_CLIENT` | `bool` | `true` |  |
| `SHARE_TMDB_MAP_HISTORY` | `int` | `3` |  |
| `TELEGRA_RESOLVE_CONCURRENCY` | `int` | `4` |  |
| `TG_BOT_ALLOWED_USER_IDS` | `List` | `PydanticUndefined` |  |
| `TG_BOT_DB_PATH` | `str` | `/data/tg_bot.db` |  |
| `TG_BOT_INBOUND_ENABLED` | `bool` | `true` |  |
| `TG_BOT_MODE` | `str` | `polling` |  |
| `TG_BOT_POLL_DROP_PENDING_UPDATES` | `bool` | `false` |  |
| `TG_BOT_POLL_OFFSET_PATH` | `str` | `/data/tg_bot_offset.json` |  |
| `TG_BOT_POLL_TIMEOUT` | `int` | `25` |  |
| `TG_BOT_TOKEN` | `Optional` | `null` |  |
| `TG_BOT_WEBHOOK_BASE_URL` | `Optional` | `null` |  |
| `TG_BOT_WEBHOOK_DROP_PENDING_UPDATES` | `bool` | `false` |  |
| `TG_BOT_WEBHOOK_RETURN_OK_ON_ERROR` | `bool` | `true` |  |
| `TG_BOT_WEBHOOK_SECRET` | `Optional` | `null` |  |
| `TG_BOT_WEBHOOK_URL` | `Optional` | `null` |  |
| `TG_CALLBACK_MAX_LEN` | `int` | `60` |  |
| `TG_CALLBACK_TOKEN_TTL_SEC` | `int` | `3600` |  |
| `TG_CHAT_ID` | `Optional` | `null` |  |
| `TG_JOB_ENABLED` | `bool` | `true` |  |
| `TG_OUTBOX_ENABLED` | `bool` | `true` |  |
| `TG_OUTBOX_MAX_PER_CHAT` | `int` | `200` |  |
| `TG_PARSE_MODE` | `str` | `Markdown` |  |
| `TG_RATE_LIMIT_MS` | `int` | `80` |  |
| `TG_SESSION_STORE` | `str` | `memory` |  |
| `TMDB_ALIAS_ENRICH_CONCURRENCY` | `int` | `4` |  |
| `TMDB_API_KEY` | `Optional` | `null` |  |
| `TMDB_CACHE_MAX_SIZE` | `int` | `512` |  |
| `TMDB_CACHE_TTL` | `int` | `3600` |  |
| `TMDB_CN_TAG_CLEANUP_MODE` | `str` | `conservative` |  |
| `TMDB_DETAIL_CACHE_TTL` | `int` | `86400` |  |
| `TMDB_ENABLE_DUAL_LANGUAGE_SEARCH` | `bool` | `true` |  |
| `TMDB_ENABLE_EXTERNAL_ID_FIND` | `bool` | `true` |  |
| `TMDB_ENABLE_GUESSIT` | `bool` | `true` |  |
| `TMDB_FIND_CACHE_TTL` | `int` | `604800` |  |
| `TMDB_HTTP_CONCURRENCY` | `int` | `10` |  |
| `TMDB_LANGUAGE` | `str` | `zh-CN` |  |
| `TMDB_NEGATIVE_CACHE_TTL` | `int` | `180` |  |
| `TMDB_REGION` | `str` | `CN` |  |
| `TMDB_SEARCH_CACHE_TTL` | `int` | `900` |  |
| `TMDB_SEARCH_FETCH_N` | `int` | `40` |  |
| `TMDB_SEARCH_MAX_PAGES` | `int` | `5` |  |
| `TMDB_TV_YEAR_FALLBACK` | `bool` | `true` |  |
| `TMDB_USE_OPENCC` | `bool` | `true` |  |
| `WEBHOOK_ALLOWED_IPS` | `List` | `PydanticUndefined` |  |
| `WEBHOOK_SECRET` | `Optional` | `null` |  |
| `WEBHOOK_TRUSTED_PROXY_IPS` | `List` | `PydanticUndefined` |  |
| `WEBHOOK_TRUST_PROXY_HEADERS` | `bool` | `false` |  |

<!-- /AUTO-GENERATED:SETTINGS -->
