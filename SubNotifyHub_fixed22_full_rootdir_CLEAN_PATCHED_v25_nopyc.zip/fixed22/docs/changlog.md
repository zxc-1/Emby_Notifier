# changlog.md

本文件记录从 **V33** 起到 **V43** 的主要变更（面向功能/行为与线上排障）。

---

## V43（P1 根治：tg_bot 解耦 notifier + 插件元信息可观测）

- **tg_bot 不再依赖 notifier 层**
  - 将轻量 metrics 收敛到 `core.metrics`，tg_bot/forward_bridge/api 等统一从 core 引用。
  - 将管理员口令哈希/写盘等能力收敛到 `core.admin_auth`，`notifier.security` 保留为 shim（兼容旧导入）。
- **插件元信息可观测**
  - 插件加载时解析 `PLUGIN_INFO`（或退化为模块 doc/version），写入 `plugin_registry.plugin_infos`。
  - 新增 Debug 接口：`GET /debug/plugins`（需开启 `DEBUG_ENABLE_DEBUG_API`）展示已加载插件、router/hook 数量与元信息。

---

## V42（可观测性：命中全局剧缓存时提示标注）

- 当解析流程命中 `series_tmdb_map` 且通过轻量校验（即 `from=series_cache`）时，在最终回复消息顶部追加：
  - `✅ 全局剧缓存命中（中英别名）`
- 目的：让你能一眼确认“同剧不同来源/中英互通”的全局缓存链路是否在工作。

---

## V41（全局剧级映射：中英互通命中增强）

- **SeriesKey 写入增强：补写 zh-CN + en-US 标题 Key**
  - 在 *手动点选* 与 *auto strong* 写入 `series_tmdb_map` 时，除证据标题外，额外读取 TMDB 详情：
    - 当前部署语言（通常 zh-CN）的 `title/original_title`
    - 强制 `en-US` 的 `title/original_title`
  - 基于这些标题生成更多 SeriesKey 并写入同一 `tmdb_tv_id`，实现 **“第一次中文、第二次英文（或反之）也能直接命中”**。
- **不牺牲准确率**
  - 只对 *已确认*（manual/auto strong）的 `tmdb_tv_id` 扩充 Key；命中后仍保留 `fetch_tmdb_detail` 轻量校验，避免同名短标题误绑。

---

## V40（全局共享：剧级缓存/映射，解决“同剧不同来源”秒识别）

> 针对场景 C：同一部剧来自不同来源/不同分享码/不同季包；只要曾经确认过一次，之后应当无需重复搜索即可快速命中。

- **新增全局剧级映射表 `series_tmdb_map`**
  - 键为 *SeriesKey*（从剧名主体归一化生成），值为 `tmdb_tv_id`。
  - 记录 `confidence/source/hit_count/updated_at`，用于命中统计与观测。
- **新增 `make_series_fingerprints(title, year)`**
  - 从剧名生成多个稳定 Key（含“去副标题的短名”等），提高跨来源命中率，同时通过校验避免误绑。
- **写入时机（防污染）**
  - **用户手动点选确认**：写入全局剧级映射（source=manual，confidence=1.0）。
  - **自动匹配 strong**：写入全局剧级映射（source=auto_strong，confidence=score）。
  - weak 不写入，避免全局共享被错误结果污染。
- **命中路径（不牺牲准确率）**
  - 在 TMDB 搜索之前尝试命中 `series_tmdb_map`；命中后只做一次 `fetch_tmdb_detail` 轻量校验：
    - 标题相似度 / coverage 达阈值（短标题更严格）
    - 年份差距过大则拒绝
  - 校验通过即直接返回（并刷新 hit_count/updated_at），失败则降级走完整搜索。

---

## V39（性能优化：不牺牲准确率前提下提速）

- **TMDB 请求去重（request de-dup）+ in-flight 复用**
  - 对同一 `(method,url,params)` 的 TMDB 请求：同一轮解析内只发一次；其它并发调用直接复用正在进行的请求结果。
  - 增加秒级“原始响应短缓存”，进一步减少抖动与重复请求。
- **全局 TMDB HTTP 并发上限**
  - 新增 `TMDB_HTTP_CONCURRENCY`（默认 10，范围 1~32），避免过高并发导致限流/重试带来的整体变慢。
- **搜索分页/双语并行化（page-by-page 并行）**
  - `search/movie`、`search/tv`、`search/multi`：同一页下所有语言并行请求；下一页仅对“上一页有结果”的语言继续分页（保持原先 break 语义，不增加请求量）。
- **安全早停（Safe early-stop）**
  - 在 *极高置信度* 情况下，提前停止剩余的变体/类型搜索与后续网络增强，减少无意义的等待。
  - 由 `TMDB_SAFE_EARLY_STOP` 控制（默认 True）；早停阈值为高分+大 gap+高覆盖，且年份不远离（保证不降准确率）。
- **Alias enrichment 按需跳过（仅在安全早停成立时）**
  - 当 top1 已经“安全强”时跳过 alias 网络请求；其它情况保持原策略，确保准确率不变。

---

## V37（恢复分类型搜索：movie/tv 优先，low 才 multi）

- `search_candidates_via_tmdb()` 恢复为：
  - `media_type=movie` → `/search/movie`
  - `media_type=tv` → `/search/tv`
  - 仅在 media_type 不明确或 low-quality 回退时使用 `/search/multi`
- 目标：减少 `/search/multi` 的噪声与候选垃圾量，并提升可解释性。

---

## V43（单候选安全自动选）

- 当自动匹配流程最终“内部合并候选集仅剩 1 个”但因 gap 不存在/阈值保守而被判为 weak 时：
  - 追加一次 **TMDB detail 校验 + 重新打分**（score/coverage）
  - 仅在 **main hint 存在** 且 **分数/覆盖率达到更高阈值**（短标题/高碰撞词更严格）且 **年份无大偏差** 时，
    自动升级为 **strong**，直接订阅并绑定（避免“明明只剩 1 个还要点确认”的体验问题）。
- 仍保留严格防误绑保护：短词/高碰撞词必须更高阈值；强制 TV 时不允许自动绑定到 movie。

---

## V42（series_cache 命中提示）

- 当命中全局剧缓存（series_cache）并校验通过时，在回复消息顶部增加提示：
  - `✅ 全局剧缓存命中（中英别名）`
  - 便于快速确认缓存链路是否生效。

---

## V41（全局剧缓存：中英互通）

- 全局 TV 剧映射写入时，除证据标题外额外补写：
  - TMDB 的 **本地化标题** 与 **original_title**
  - 同时补写 **en-US** 语言下的标题 key
- 实现“第一次中文、第二次英文（或反过来）”也能命中全局剧缓存并快速识别。

---

## V40（全局共享：同剧不同来源秒识别）

- 新增全局 TV 剧级映射（SeriesKey → tmdb_tv_id），跨所有群/用户共享：
  - 仅对 **手动确认** / **auto strong** 的结果写入，防止污染。
- 在 TMDB 搜索前优先尝试命中 series_cache：
  - 命中后只做一次 detail 轻量校验（标题/年份）通过即直接使用，极大减少重复搜索与手动选择。

---

## V39（不降准确率的加速：去重/并发/早停/按需别名）

- 请求去重 + in-flight 复用：同一轮解析内相同请求只发一次，其它 await 同一 Future。
- typed/multi 搜索缓存体系补齐：内存 TTL + sqlite 持久化 + negative caching（空结果短 TTL）。
- 语言并行、分页按需推进：同页多语言并发，下一页仅对有结果语言继续。
- Safe early-stop：只有“强到不可能被后续推翻”时才取消剩余批次，保证准确率。
- Alias enrichment 按需：仅在不够确定时才拉别名，强结果跳过网络别名查询。

---

## V37（恢复按类别搜索 + low 才 multi 回退）

- movie / tv 分别调用 `/search/movie`、`/search/tv`（typed search）。
- 仅当候选质量低（low-quality）时，才使用 `/search/multi` 作为兜底回退，减少无意义 multi 查询。

---

## V36（候选详情链接 + 按钮网格化）

- 候选列表的“详情”从裸 URL 改为 **HTML 锚点（短文本可点击）**，避免长链接换行影响观感。
- 候选选择按钮改为 **网格（2 列）**，更紧凑易选。
- 仍保留“原标题按钮”作为选择入口（不改变选择交互语义）。

---

## V35（稳定性修复：避免“卡住/无回音”）

- 修复异常分支中的 **未定义变量引用**，避免“处理异常时再次抛异常”导致流程中断、TG 端停在“正在解析…”。
- Share 解析流程增加 **顶层兜底 try/except**：
  - 任意解析/搜索异常都会把 processing 消息更新为明确失败提示（不再像卡住一样没下文）。
- 增加（或强化）**negative caching（空结果短 TTL）**，避免同一噪声 hint 在短时间内反复打 TMDB。

---

## V34（识别准确度增强：A/B/C/D + UI 细节）

> 该版本聚焦“更准地识别 + 更准地自动选中”，并改进候选展示。

- **A：hint 垃圾过滤**  
  - 对 115 分享内容/文件名中的无意义片段（纯扩展名、纯数字、无效 token 等）做更强过滤，减少噪声候选。
- **B：自动选中增强（共识/投票）**  
  - 跨 hint 合并候选，引入“Top1 共识”“证据来源权重”等，提升自动选中准确度并降低误选。
- **C：TV/季先验（season prior）**  
  - 从证据文本推断季信息；在 TV 场景用作先验/重排，减少剧集错配。
- **D：候选裁剪与弱置信提示**  
  - 候选过多时做裁剪与更清晰的提示，引导用户确认；减少“垃圾候选堆满屏”的体验问题。
- **候选展示（V2 文案形态）**
  - 候选行追加“可点的详情入口”（后续在 V36 升级为 HTML 锚点）。
  - 按钮保持“原标题按钮”语义（后续在 V36 做成网格布局）。

---

## V33（基线）

- 作为本 changlog 的对比基线版本。

---

## V44

- **115 扫码登录：取消后二维码残留修复**
  - 取消扫码时改为优先 `deleteMessage` 删除二维码消息（Telegram 无法通过 edit 移除图片，只能改 caption，导致“已取消但二维码还在”的观感）。
  - 若删除失败则降级：清空键盘 + 把消息改为“已取消”。
  - 删除成功后额外发送一条“❌ 已取消”确认消息，避免用户看不到结果。

