# Core Module Structure

本文档描述了 `core` 模块的子模块结构、Public API 和使用指南。

## 概述

`core` 模块按功能域组织为以下子模块：

| 子模块 | 功能 | 主要导出 |
|--------|------|----------|
| `core.logging` | 日志基础设施 | `BizLogger`, `get_biz_logger_adapter` |
| `core.http` | HTTP 客户端和重试 | `get_http_client`, `async_request_with_retry` |
| `core.cache` | 缓存系统 | `TTLCache`, `PosterCache`, `kv_cache_*` |
| `core.storage` | 存储抽象 | `BlobStore`, `KVStore`, `file_lock` |
| `core.plugins` | 插件系统 | `PluginRegistry`, `load_plugins` |
| `core.exceptions` | 异常处理 | `AppException`, `safe_call`, `CircuitBreaker` |

## 子模块详情

### core.logging

统一的日志基础设施，提供业务日志记录功能。

**Public API:**
```python
from core.logging import (
    # BizLogger - 业务日志 DSL
    BizLogger,
    get_biz_logger,
    is_detail_enabled,
    
    # BizLoggerAdapter - stdlib 兼容适配器
    BizLoggerAdapter,
    get_biz_logger_adapter,
    
    # 日志初始化
    init_logging,
    log_ok,
    log_run,
    log_fetch,
    
    # Formatters
    BizTextFormatter,
    JsonLineFormatter,
    
    # Context 管理
    get_trace_id,
    set_trace_id,
    get_span_id,
    set_span,
    get_phase,
    set_phase,
    get_step,
    set_step,
)
```

**使用示例:**
```python
from core.logging import get_biz_logger_adapter

logger = get_biz_logger_adapter(__name__)
logger.info("Processing request", extra={"user_id": 123})
```

---

### core.http

HTTP 客户端和请求重试机制。

**Public API:**
```python
from core.http import (
    # HTTP 客户端
    get_http_client,
    get_async_http_client,
    
    # 重试机制
    async_request_with_retry,
    RetryConfig,
    
    # 异常处理
    handle_http_exception,
)
```

**使用示例:**
```python
from core.http import get_http_client, async_request_with_retry

# 同步客户端
client = get_http_client()
response = client.get("https://api.example.com/data")

# 异步请求带重试
result = await async_request_with_retry(
    "GET",
    "https://api.example.com/data",
    max_retries=3
)
```

---

### core.cache

缓存系统，包括 TTL 缓存、持久化缓存和海报缓存。

**Public API:**
```python
from core.cache import (
    # TTL 缓存
    TTLCache,
    
    # KV 缓存 (SQLite 持久化)
    kv_cache_get_json,
    kv_cache_set_json,
    kv_cache_delete,
    kv_cache_purge_expired,
    
    # 海报缓存
    PosterCache,
    get_poster_cache,
)
```

**使用示例:**
```python
from core.cache import kv_cache_get_json, kv_cache_set_json

# 存储数据
kv_cache_set_json("user:123", {"name": "Alice"}, ttl_sec=3600)

# 读取数据
data = kv_cache_get_json("user:123")
```

---

### core.storage

存储抽象层，提供 Blob 存储、KV 存储和文件锁。

**Public API:**
```python
from core.storage import (
    # 存储协议
    KVStore,
    BlobStore,
    DedupStore,
    
    # 默认实现
    SQLiteKVStore,
    MemoryKVStore,
    FSBlobStore,
    
    # 工厂函数
    get_kv_store,
    get_blob_store,
    
    # 文件操作
    load_json,
    save_json,
    load_env_file,
    dump_env_file,
    
    # 文件锁
    file_lock,
    
    # 环境文件管理
    env_path,
    update_env_file,
)
```

**使用示例:**
```python
from core.storage import get_kv_store, file_lock

# KV 存储
kv = get_kv_store()
kv.set_json("key", {"value": 42}, ttl_sec=600)
data = kv.get_json("key")

# 文件锁
with file_lock("/path/to/file.lock"):
    # 独占访问
    pass
```

---

### core.plugins

插件系统，支持动态加载和注册插件。

**Public API:**
```python
from core.plugins import (
    # 插件注册表
    PluginRegistry,
    get_plugin_registry,
    
    # 插件加载
    load_plugins,
    discover_plugins,
    
    # 插件 API
    PluginAPI,
)
```

**使用示例:**
```python
from core.plugins import get_plugin_registry, load_plugins

# 加载插件
load_plugins("notifier.plugins.builtin_notifiers")

# 获取注册的插件
registry = get_plugin_registry()
notifier = registry.get("telegram")
```

---

### core.exceptions

统一的异常处理，包括安全调用装饰器和熔断器。

**Public API:**
```python
from core.exceptions import (
    # 基础异常
    AppException,
    NetworkError,
    DatabaseError,
    ValidationError,
    ConfigurationError,
    
    # 安全调用
    safe_call,
    safe_context,
    async_safe_context,
    
    # 熔断器
    CircuitBreaker,
    CircuitBreakerOpenError,
    with_retry,
    
    # 异常映射
    map_exception,
    get_exception_category,
    
    # 异常指标
    record_exception,
    get_exception_counts,
)
```

**使用示例:**
```python
from core.exceptions import safe_call, CircuitBreaker

# 安全调用装饰器
@safe_call(catch=(ValueError, TypeError), default=None)
def risky_operation():
    ...

# 熔断器
breaker = CircuitBreaker(failure_threshold=5, recovery_timeout=30)

@breaker
async def external_api_call():
    ...
```

---

## 迁移指南

### 从旧路径迁移

旧的导入路径仍然可用，但会发出废弃警告。建议迁移到新路径：

| 旧路径 | 新路径 |
|--------|--------|
| `from core.bizlog import ...` | `from core.logging import ...` |
| `from core.http_clients import ...` | `from core.http import ...` |
| `from core.cache import ...` | `from core.cache import ...` |
| `from core.stores import ...` | `from core.storage import ...` |
| `from core.fs import ...` | `from core.storage import ...` |
| `from core.plugin_loader import ...` | `from core.plugins import ...` |
| `from core.safe_call import ...` | `from core.exceptions import ...` |

### 使用迁移工具

```bash
# 预览更改 (dry-run)
python tools/migrate_imports.py

# 执行迁移并备份
python tools/migrate_imports.py --apply --backup

# 回滚更改
python tools/migrate_imports.py --rollback
```

---

## 添加新子模块指南

### 1. 创建目录结构

```
core/
└── new_module/
    ├── __init__.py      # Public API 导出
    ├── implementation.py # 实现代码
    └── helpers.py       # 辅助函数
```

### 2. 定义 Public API

在 `__init__.py` 中明确导出公开符号：

```python
"""New module description."""

from .implementation import (
    PublicClass,
    public_function,
)

__all__ = [
    "PublicClass",
    "public_function",
]
```

### 3. 创建兼容层（如需要）

如果替换现有模块，创建兼容层：

```python
# core/old_module.py
"""Deprecated: Use core.new_module instead."""

import warnings
warnings.warn(
    "core.old_module is deprecated, use core.new_module instead",
    DeprecationWarning,
    stacklevel=2
)

from core.new_module import *
```

### 4. 更新依赖图

运行依赖图生成工具：

```bash
python tools/generate_dependency_graph.py --include-external
```

### 5. 添加测试

在 `tests/contract/test_submodule_api_properties.py` 中添加 API 完整性测试。

---

## 依赖关系

查看 [dependency_graph.md](./dependency_graph.md) 获取完整的依赖关系图。

### 依赖原则

1. **logging** 是基础模块，不依赖其他 core 子模块
2. **exceptions** 只依赖 logging
3. **http** 依赖 logging 和 exceptions
4. **storage** 依赖 logging 和 cache（用于 KV 存储）
5. **cache** 依赖 logging、http 和 storage
6. **plugins** 只依赖 logging

### 避免循环依赖

- 使用延迟导入（在函数内部导入）
- 使用 `TYPE_CHECKING` 进行类型注解
- 将共享类型定义移到独立模块
