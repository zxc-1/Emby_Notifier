from __future__ import annotations

import asyncio

from .poller import run_poll_loop


async def run_hotlist_daemon(*, stop_evt: asyncio.Event, task_registry: object | None = None) -> None:
    """Entry for bootstrap.

    NOTE (customized build):
      - v1.6.5.15 起移除 TG 端『热榜新增/日报』汇总推送。
      - 热榜模块仍负责：抓取榜单、去重、按规则自动创建订阅任务。

    (Digest loop removed.)
    """

    await run_poll_loop(stop_evt=stop_evt, task_registry=task_registry)
