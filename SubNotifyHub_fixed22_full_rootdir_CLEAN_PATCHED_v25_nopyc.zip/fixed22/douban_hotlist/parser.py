from __future__ import annotations

import hashlib
import json
import re
from dataclasses import asdict
from typing import Any, Dict, Iterable, List, Optional, Tuple

import html as _html

from core.logging import get_biz_logger_adapter
from .models import HotlistItem, HotlistResult
from .utils import canonical_list_url, extract_list_key, extract_subject_id, safe_float

biz = get_biz_logger_adapter(__name__)
logger = get_biz_logger_adapter(__name__)


# ---------------------------------------------------------------------------
# Subject meta parsing / TMDB title normalization (pure helpers)
# ---------------------------------------------------------------------------

# NOTE: Douban subject pages may contain multiple `tt...` tokens (ads/trackers/related works).
# A raw `tt\d+` regex often picks the wrong imdb id -> wrong TMDB mapping.
# Prefer extracting from explicit imdb link patterns first, then fall back.
_IMDB_LINK_RE = re.compile(r"(?is)https?://(?:www\.)?imdb\.com/title/(tt\d{7,9})")
_IMDB_LABEL_RE = re.compile(r"(?is)IMDb\s*[:：]?\s*(tt\d{7,9})")
_IMDB_RE = re.compile(r"(?i)tt\d{7,9}")
_INFO_DIV_RE = re.compile(r"(?is)<div[^>]{0,200}id=\"info\"[^>]*>(.*?)</div>")


def _uniq(parts: List[str]) -> List[str]:
    out: List[str] = []
    seen: set[str] = set()
    for p in parts or []:
        s = str(p or "").strip()
        if not s:
            continue
        if s in seen:
            continue
        seen.add(s)
        out.append(s)
    return out


def extract_imdb_id_from_html(html: str) -> str:
    """Best-effort extract an IMDb id from a Douban subject page html."""
    if not html:
        return ""
    # 1) Prefer the "info" block (where Douban usually lists "IMDb:"). This avoids tt-ids
    #    from scripts/related works.
    try:
        m_info = _INFO_DIV_RE.search(html)
        if m_info:
            info = m_info.group(1) or ""
            m = _IMDB_LINK_RE.search(info)
            if m:
                return str(m.group(1)).lower()
            m = _IMDB_LABEL_RE.search(info)
            if m:
                return str(m.group(1)).lower()
            # Occasionally the info block contains only a bare tt-id.
            ids = [str(x).lower() for x in _IMDB_RE.findall(info) if x]
            if len(ids) == 1:
                return ids[0]
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"info 块解析失败（已忽略） - 原因={type(e).__name__}")
        pass
    # 2) Next, try explicit imdb title links in the full page; if multiple, choose the one
    #    closest to an "IMDb" label.
    try:
        all_links = [str(x).lower() for x in _IMDB_LINK_RE.findall(html) if x]
        if all_links:
            if len(all_links) == 1:
                return all_links[0]
            # Choose the link with minimal distance to an "IMDb" label.
            label_pos = None
            m_lab = re.search(r"(?is)IMDb\s*[:：]", html)
            if m_lab:
                label_pos = m_lab.start()
            if label_pos is not None:
                best = all_links[0]
                best_dist = 10**18
                for m in _IMDB_LINK_RE.finditer(html):
                    tid = str(m.group(1)).lower()
                    dist = abs(m.start() - label_pos)
                    if dist < best_dist:
                        best_dist = dist
                        best = tid
                return best
            # Fallback: last link is often the actual info field.
            return all_links[-1]
    except (ValueError, TypeError, AttributeError, IndexError) as e:
        logger.detail(f"IMDb 链接提取失败（已忽略） - 原因={type(e).__name__}")
        pass
    try:
        m = _IMDB_LABEL_RE.search(html)
        if m:
            return str(m.group(1)).lower()
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"IMDb 标签提取失败（已忽略） - 原因={type(e).__name__}")
        pass
    # Fallback: still risky. Prefer the tt-id closest to an "imdb" mention.
    try:
        h = html.lower()
        ids = [str(x).lower() for x in _IMDB_RE.findall(h) if x]
        if not ids:
            return ""
        if len(ids) == 1:
            return ids[0]

        imdb_pos = [m.start() for m in re.finditer("imdb", h)]
        if imdb_pos:
            best_id = ids[0]
            best_dist = 10**18
            for m in _IMDB_RE.finditer(h):
                tid = str(m.group(0)).lower()
                p = m.start()
                dist = min(abs(p - ip) for ip in imdb_pos)
                if dist < best_dist:
                    best_dist = dist
                    best_id = tid
            return best_id

        return ids[-1]
    except (ValueError, TypeError, AttributeError, IndexError) as e:
        logger.detail(f"IMDb ID 回退提取失败（已忽略） - 原因={type(e).__name__}")
        return ""


# --- TMDB title-search normalization ---

_RE_BRACKETS = re.compile(r"[\(\[\{（【『「].*?[\)\]\}）】』」]", re.UNICODE)
_RE_SEASON_CN = re.compile(r"第\s*(\d+)\s*季", re.UNICODE)
_RE_SEASON_EN = re.compile(r"\bseason\s*(\d+)\b", re.IGNORECASE)
_RE_SEASON_SX = re.compile(r"\bS(\d{1,2})\b", re.IGNORECASE)
_RE_PUNCT = re.compile(r"[^0-9A-Za-z\u4e00-\u9fff\s]", re.UNICODE)


def normalize_title_for_tmdb_search(title: str) -> str:
    """Normalize a title string for TMDB search (conservative for CJK)."""
    if not title:
        return ""
    t = str(title).strip()
    t = _RE_BRACKETS.sub(" ", t)
    t = _RE_SEASON_CN.sub(" ", t)
    t = _RE_SEASON_EN.sub(" ", t)
    t = _RE_SEASON_SX.sub(" ", t)
    t = _RE_PUNCT.sub(" ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t


def title_consistent(expected_title: str, resolved_name: str) -> bool:
    """Heuristic guardrail against obvious wrong mapping."""
    e = normalize_title_for_tmdb_search(expected_title or "")
    r = normalize_title_for_tmdb_search(resolved_name or "")
    e2 = re.sub(r"\s+", "", e.lower())
    r2 = re.sub(r"\s+", "", r.lower())
    if not e2 or not r2:
        return True
    if e2 in r2 or r2 in e2:
        return True
    return False


# --- Season extraction / title normalization ---

_SEASON_ZH_RE = re.compile(r"(?i)(第\s*([0-9]{1,3}|[一二三四五六七八九十百两]{1,6})\s*季)")
_SEASON_EN_RE = re.compile(r"(?i)\b(?:season\s*(\d{1,3})|s(\d{1,2})\b)")
_YEAR_PAREN_RE = re.compile(r"[（(]\s*(\d{4})\s*[）)]")


def _zh_num_to_int(s: str) -> Optional[int]:
    """Very small Chinese numeral -> int converter (1..199)."""
    if not s:
        return None
    s0 = str(s).strip()
    if not s0:
        return None
    if s0.isdigit():
        try:
            v = int(s0)
            return v if v > 0 else None
        except (ValueError, TypeError) as e:
            logger.detail(f"数字转换失败（已忽略） - s0={s0}, 原因={type(e).__name__}")
            return None

    m = {"零": 0, "一": 1, "二": 2, "两": 2, "三": 3, "四": 4, "五": 5, "六": 6, "七": 7, "八": 8, "九": 9}
    if s0 == "十":
        return 10

    total = 0
    try:
        if "百" in s0:
            a, b = s0.split("百", 1)
            total += (m.get(a, 0) or 0) * 100
            s0 = b
        if "十" in s0:
            a, b = s0.split("十", 1)
            total += ((m.get(a, 1) if a else 1) or 1) * 10
            s0 = b
        if s0:
            total += (m.get(s0, 0) or 0)
    except (ValueError, TypeError, KeyError) as e:
        logger.detail(f"中文数字转换失败（已忽略） - s0={s0}, 原因={type(e).__name__}")
        return None
    return total if total > 0 else None


def extract_season_and_clean_title(title: str) -> tuple[str, Optional[int]]:
    """Extract season number from a title and return (clean_title, season)."""
    t = str(title or "").strip()
    if not t:
        return "", None

    season: Optional[int] = None
    m = _SEASON_ZH_RE.search(t)
    if m:
        season = _zh_num_to_int(m.group(2) or "")
        t = (t[: m.start()] + " " + t[m.end() :]).strip()

    if season is None:
        m2 = _SEASON_EN_RE.search(t)
        if m2:
            season = _zh_num_to_int(m2.group(1) or m2.group(2) or "")
            t = (t[: m2.start()] + " " + t[m2.end() :]).strip()

    t = _YEAR_PAREN_RE.sub(" ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t, season


# --- Season inference from hotlist suffix (TV hotlist only) -----------------

_ROMAN_SUFFIX_MAP: Dict[str, int] = {
    "Ⅰ": 1,
    "Ⅱ": 2,
    "Ⅲ": 3,
    "Ⅳ": 4,
    "Ⅴ": 5,
    "Ⅵ": 6,
    "Ⅶ": 7,
    "Ⅷ": 8,
    "Ⅸ": 9,
    "Ⅹ": 10,
}

_CHN_SUFFIX_MAP: Dict[str, int] = {
    "一": 1,
    "二": 2,
    "三": 3,
    "四": 4,
    "五": 5,
    "六": 6,
    "七": 7,
    "八": 8,
    "九": 9,
    "十": 10,
    "十一": 11,
    "十二": 12,
    "十三": 13,
    "十四": 14,
    "十五": 15,
    "十六": 16,
    "十七": 17,
    "十八": 18,
    "十九": 19,
    "二十": 20,
}


def infer_season_candidate_from_suffix(title: str) -> tuple[str, Optional[int], Optional[str]]:
    """Infer season from title suffix (e.g., 'XX2', 'XXⅡ', 'XX二').

    Returns (base_title, season_candidate, reason).

    Notes:
    - This MUST be used only for TV hotlist context.
    - This function only *infers* a candidate; caller should verify via Douban detail.
    """
    raw = (title or "").strip()
    if not raw:
        return raw, None, None

    # Pure number title: do not treat as season.
    if re.fullmatch(r"\d+", raw):
        return raw, None, None

    # If title ends with a 4-digit year, do not treat as season.
    m_year = re.search(r"(19\d{2}|20\d{2})$", raw)
    if m_year:
        return raw, None, None

    # Normalize some separators at the end.
    t = raw.rstrip()

    # 1) Arabic digits suffix (1-20), allow whitespace/separators before digit.
    m = re.match(r"^(.*?)[\s·\-—_]*([1-9]\d?)$", t)
    if m:
        base = m.group(1).strip()
        n = int(m.group(2))
        # Exclude common year-like suffixes explicitly mentioned.
        if n <= 20 and base:
            return base, n, "suffix_digit"

    # 2) Roman numeral suffix (unicode)
    for sym, n in _ROMAN_SUFFIX_MAP.items():
        if t.endswith(sym):
            base = t[: -len(sym)].strip().rstrip("·-—_")
            if base and 1 <= n <= 20:
                return base, n, "suffix_roman"

    # 2b) Roman numeral suffix (ASCII)
    ascii_map = {"I": 1, "II": 2, "III": 3, "IV": 4, "V": 5, "VI": 6, "VII": 7, "VIII": 8, "IX": 9, "X": 10}
    for sym, n in sorted(ascii_map.items(), key=lambda x: -len(x[0])):
        if re.search(rf"\b{re.escape(sym)}$", t):
            base = re.sub(rf"\b{re.escape(sym)}$", "", t).strip().rstrip("·-—_")
            if base and 1 <= n <= 20:
                return base, n, "suffix_roman_ascii"

    # 3) Chinese numeral suffix (no '季' required)
    for sym, n in sorted(_CHN_SUFFIX_MAP.items(), key=lambda x: -len(x[0])):
        if t.endswith(sym):
            base = t[: -len(sym)].strip().rstrip("·-—_")
            if base and 1 <= n <= 20:
                return base, n, "suffix_chn"

    return raw, None, None


_YEAR_SPAN_RE = re.compile(r"(?is)<span[^>]{0,200}class=\"year\"[^>]*>\((\d{4})\)</span>")
_RELEASE_Y_RE = re.compile(r"(?is)property=\"v:initialReleaseDate\"[^>]{0,300}content=\"(\d{4})[-/]")
_GENRE_RE = re.compile(r"(?is)property=\"v:genre\"[^>]{0,200}>([^<]{1,40})<")
_OG_TYPE_RE = re.compile(r"(?is)property=\"og:type\"[^>]{0,200}content=\"([^\"]{1,80})\"")


def parse_subject_meta(html: str) -> Dict[str, Any]:
    """Parse a Douban subject HTML page into lightweight metadata."""
    out: Dict[str, Any] = {"imdb_id": "", "year": None, "media_type_hint": "", "tags": []}
    if not html:
        return out

    out["imdb_id"] = extract_imdb_id_from_html(html)

    year: Optional[int] = None
    m = _YEAR_SPAN_RE.search(html)
    if m:
        try:
            year = int(m.group(1))
        except (ValueError, TypeError) as e:
            logger.detail(f"年份提取失败（已忽略） - year_str={m.group(1)}, 原因={type(e).__name__}")
            year = None
    if year is None:
        m = _RELEASE_Y_RE.search(html)
        if m:
            try:
                year = int(m.group(1))
            except (ValueError, TypeError) as e:
                logger.detail(f"发布年份提取失败（已忽略） - year_str={m.group(1)}, 原因={type(e).__name__}")
                year = None
    out["year"] = year

    tags: List[str] = []
    try:
        for mm in _GENRE_RE.finditer(html):
            t = str(mm.group(1) or "").strip()
            if t:
                tags.append(t)
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"标签提取失败（已忽略） - 原因={type(e).__name__}")
        pass
    out["tags"] = _uniq(tags)

    hint = ""
    try:
        m = _OG_TYPE_RE.search(html)
        if m:
            og = str(m.group(1) or "").lower()
            if "tv" in og or "show" in og:
                hint = "tv"
            elif "movie" in og or "film" in og:
                hint = "movie"
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"媒体类型提示提取失败（已忽略） - 原因={type(e).__name__}")
        hint = ""

    if not hint:
        low = html.lower()
        if "集数" in html or "episode" in low or "season" in low:
            hint = "tv"

    out["media_type_hint"] = hint
    return out


def parse_subject_aka(html: str) -> List[str]:
    """Parse "aka" (又名/别名) from Douban subject HTML.

    Strategy (best-effort):
    1) Desktop page usually contains: <span class="pl">又名:</span> ...
    2) If present, also try JSON blobs (Next.js __NEXT_DATA__) where aka may
       appear as an array.

    Returns a de-duplicated list; empty list on failure.
    """
    if not html:
        return []

    aka: List[str] = []

    # 1) Desktop HTML label
    try:
        m = re.search(r"又名[:：]</span>\s*([^<]{1,2000})", html)
        if m:
            raw = _strip_tags(m.group(1))
            if raw:
                # Douban commonly uses " / " separator
                parts = [p.strip() for p in re.split(r"\s*/\s*", raw) if p.strip()]
                aka.extend(parts)
    except Exception as e:
        biz.detail("ignored exception in parse_subject_aka", exc_info=True)
        pass

    # 2) JSON blobs (if any)
    try:
        data = _find_next_data_json(html)
        if data:
            txt = json.dumps(data, ensure_ascii=False)
            mm = re.search(r'"aka"\s*:\s*\[(.*?)\]', txt)
            if mm:
                payload = "[" + mm.group(1) + "]"
                try:
                    arr = json.loads(payload)
                    if isinstance(arr, list):
                        for x in arr:
                            s = str(x).strip()
                            if s:
                                aka.append(s)
                except Exception as e:
                    biz.detail("ignored exception in parse_subject_aka", exc_info=True)
                    pass
    except Exception as e:
        biz.detail("ignored exception in parse_subject_aka", exc_info=True)
        pass

    return _uniq([a for a in aka if a])



def _strip_tags(s: str) -> str:
    if not s:
        return ""
    s = re.sub(r"(?is)<[^>]{1,500}>", " ", s)
    s = _html.unescape(s)
    s = re.sub(r"\s+", " ", s).strip()
    return s


def _find_next_data_json(html: str) -> Optional[dict[str, Any]]:
    """Best-effort: extract Next.js __NEXT_DATA__ JSON blob."""
    if not html:
        return None
    marker = 'id="__NEXT_DATA__"'
    idx = html.find(marker)
    if idx < 0:
        idx = html.find("id='__NEXT_DATA__'")
    if idx < 0:
        return None

    # find the first '>' after the marker and the closing </script>
    try:
        gt = html.find('>', idx)
        if gt < 0:
            return None
        end = html.find('</script>', gt)
        if end < 0:
            return None
        payload = html[gt + 1 : end].strip()
        if not payload:
            return None
        return json.loads(payload)
    except (ValueError, TypeError, json.JSONDecodeError) as e:
        logger.detail(f"__NEXT_DATA__ JSON 解析失败（已忽略） - 原因={type(e).__name__}")
        return None


def _walk_find_items(obj: Any) -> list[dict[str, Any]]:
    """Recursively find dict entries that look like subject items."""
    out: list[dict[str, Any]] = []

    def _walk(x: Any) -> None:
        if x is None:
            return
        if isinstance(x, dict):
            # candidate dict
            try:
                url = x.get("url") or x.get("uri") or x.get("link")
                if url and isinstance(url, str) and "/subject/" in url:
                    title = x.get("title") or x.get("name") or x.get("subject_title")
                    if title is not None:
                        out.append(x)
            except (ValueError, TypeError, AttributeError, KeyError) as e:
                logger.detail(f"候选字典检查失败（已忽略） - 原因={type(e).__name__}")
                pass
            for v in x.values():
                _walk(v)
            return
        if isinstance(x, list):
            for it in x:
                _walk(it)

    _walk(obj)
    return out


def parse_hotlist_page(list_url: str, html: str) -> HotlistResult:
    """Parse a douban subject_collection page into structured items.

    Robustness strategy:
    - Prefer __NEXT_DATA__ JSON when available
    - Fallback to regex extraction from HTML
    """
    list_key = extract_list_key(list_url)
    if not list_key:
        # maybe canonical already
        try:
            m = re.search(r"/subject_collection/([0-9A-Za-z_-]+)", str(list_url or ""))
            list_key = str(m.group(1)) if m else ""
        except (ValueError, TypeError, AttributeError) as e:
            logger.detail(f"list_key 提取失败（已忽略） - list_url={list_url}, 原因={type(e).__name__}")
            list_key = ""

    can_url = canonical_list_url(list_key) if list_key else str(list_url or "")

    title = ""
    try:
        mt = re.search(r"(?is)<title>(.*?)</title>", html or "")
        if mt:
            title = _strip_tags(mt.group(1) or "")
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"标题提取失败（已忽略） - 原因={type(e).__name__}")
        title = ""

    items: list[HotlistItem] = []

    # 1) JSON path
    data = _find_next_data_json(html or "")
    if isinstance(data, dict):
        try:
            # In most douban mobile pages, content resides in props.pageProps
            root = data
            try:
                root = (data.get("props") or {}).get("pageProps") or data
            except (ValueError, TypeError, AttributeError, KeyError) as e:
                logger.detail(f"pageProps 提取失败（已忽略） - 原因={type(e).__name__}")
                root = data

            cand = _walk_find_items(root)
            seen: set[str] = set()
            for i, d in enumerate(cand):
                try:
                    u = str(d.get("url") or d.get("uri") or d.get("link") or "")
                    sid = extract_subject_id(u)
                    if not sid or sid in seen:
                        continue
                    seen.add(sid)
                    t = str(d.get("title") or d.get("name") or "").strip()
                    if not t:
                        t = f"subject {sid}"
                    r = None
                    # try nested rating/score
                    for k in ("rating", "score", "rate"):
                        if d.get(k) is not None:
                            r = safe_float(d.get(k))
                            break
                    if r is None:
                        try:
                            rr = (d.get("rating") or {})
                            if isinstance(rr, dict):
                                r = safe_float(rr.get("value") or rr.get("score"))
                        except (ValueError, TypeError, AttributeError, KeyError) as e:
                            logger.detail(f"评分提取失败（已忽略） - 原因={type(e).__name__}")
                            r = None

                    cover = None
                    for k in ("cover", "cover_url", "pic", "image"):
                        v = d.get(k)
                        if isinstance(v, str) and v.startswith("http"):
                            cover = v
                            break
                        if isinstance(v, dict):
                            for kk in ("url", "large", "normal"):
                                vv = v.get(kk)
                                if isinstance(vv, str) and vv.startswith("http"):
                                    cover = vv
                                    break

                    items.append(
                        HotlistItem(
                            subject_id=sid,
                            title=t,
                            url=(u if u.startswith("http") else f"https://movie.douban.com/subject/{sid}/"),
                            rating=r,
                            cover=cover,
                            rank=i + 1,
                        )
                    )
                except (ValueError, TypeError, AttributeError, KeyError) as e:
                    logger.detail(f"热榜项目解析失败（已跳过） - 原因={type(e).__name__}")
                    continue

            # Try to get a better list title from JSON
            if not title:
                try:
                    # Look for subject_collection name
                    sc = root.get("subject_collection") if isinstance(root, dict) else None
                    if isinstance(sc, dict):
                        title = str(sc.get("name") or sc.get("title") or "").strip()
                except (ValueError, TypeError, AttributeError, KeyError) as e:
                    logger.detail(f"列表标题提取失败（已忽略） - 原因={type(e).__name__}")
                    pass
        except Exception:
            logger.detail("豆瓣热榜：解析 __NEXT_DATA__ 失败", exc_info=True)

    # 2) HTML regex fallback
    if not items:
        seen: set[str] = set()
        # subject hrefs
        for m in re.finditer(r"(?is)<a[^>]{0,800}href=\"([^\"]{1,800}/subject/\d{4,12}/[^\"]*)\"[^>]*>(.*?)</a>", html or ""):
            u = _html.unescape(m.group(1) or "")
            sid = extract_subject_id(u)
            if not sid or sid in seen:
                continue
            seen.add(sid)
            t = _strip_tags(m.group(2) or "")
            items.append(HotlistItem(subject_id=sid, title=t or f"subject {sid}", url=(u if u.startswith("http") else f"https://movie.douban.com{u}"), rank=len(items) + 1))
            if len(items) >= 60:
                break

        # extra: bare /subject/xxxx/ occurrences
        if not items:
            for m in re.finditer(r"/subject/(\d{4,12})/", html or ""):
                sid = str(m.group(1))
                if sid in seen:
                    continue
                seen.add(sid)
                items.append(HotlistItem(subject_id=sid, title=f"subject {sid}", url=f"https://movie.douban.com/subject/{sid}/", rank=len(items) + 1))
                if len(items) >= 60:
                    break

    if not title:
        title = f"Douban Hotlist {list_key}" if list_key else "Douban Hotlist"

    # dedupe and re-rank
    uniq: list[HotlistItem] = []
    seen2: set[str] = set()
    for it in items:
        sid = str(it.subject_id or "")
        if not sid or sid in seen2:
            continue
        seen2.add(sid)
        uniq.append(it)

    for idx, it in enumerate(uniq):
        if it.rank is None:
            it.rank = idx + 1

    return HotlistResult(list_key=list_key, list_url=can_url, list_title=title, items=uniq)


def parse_hotlist_api_items(*, list_key: str, list_url: str, data: Any, start: int = 0) -> HotlistResult:
    """Parse rexxar subject_collection items JSON."""
    lk = str(list_key or "").strip()
    can_url = canonical_list_url(lk) if lk else str(list_url or "")

    title = ""
    items: list[HotlistItem] = []
    try:
        if isinstance(data, dict):
            sc = data.get("subject_collection")
            if isinstance(sc, dict):
                title = str(sc.get("name") or sc.get("title") or "").strip()

            raw_items = data.get("subject_collection_items")
            if not isinstance(raw_items, list):
                raw_items = data.get("items")
            if not isinstance(raw_items, list):
                raw_items = []

            for idx, it in enumerate(raw_items):
                if not isinstance(it, dict):
                    continue
                subj = it.get("subject")
                if not isinstance(subj, dict):
                    subj = it

                sid = str(subj.get("id") or subj.get("subject_id") or subj.get("sid") or "").strip()
                if not sid:
                    # some payloads carry uri/url only
                    u0 = str(subj.get("url") or subj.get("uri") or "").strip()
                    sid = extract_subject_id(u0)
                if not sid:
                    continue

                t = str(subj.get("title") or subj.get("name") or "").strip() or f"subject {sid}"
                u = str(subj.get("url") or subj.get("uri") or "").strip()
                if not u:
                    u = f"https://movie.douban.com/subject/{sid}/"

                r = None
                rr = subj.get("rating")
                if isinstance(rr, dict):
                    r = safe_float(rr.get("value") or rr.get("score"))
                elif rr is not None:
                    r = safe_float(rr)

                cover = None
                for k in ("cover", "cover_url", "pic", "image"):
                    v = subj.get(k)
                    if isinstance(v, str) and v.startswith("http"):
                        cover = v
                        break
                    if isinstance(v, dict):
                        for kk in ("url", "large", "normal"):
                            vv = v.get(kk)
                            if isinstance(vv, str) and vv.startswith("http"):
                                cover = vv
                                break
                        if cover:
                            break

                items.append(
                    HotlistItem(
                        subject_id=sid,
                        title=t,
                        url=u,
                        rating=r,
                        cover=cover,
                        rank=int(start or 0) + idx + 1,
                    )
                )
    except Exception:
        logger.detail("豆瓣热榜：解析 api json 失败", exc_info=True)

    if not title:
        title = f"Douban Hotlist {lk}" if lk else "Douban Hotlist"

    # dedupe preserve order
    uniq: list[HotlistItem] = []
    seen: set[str] = set()
    for it in items:
        sid = str(it.subject_id or "")
        if not sid or sid in seen:
            continue
        seen.add(sid)
        uniq.append(it)

    return HotlistResult(list_key=lk, list_url=can_url, list_title=title, items=uniq)


def compute_items_hash(items: Iterable[HotlistItem]) -> str:
    """Stable hash for a list of items (by subject_id order)."""
    try:
        s = "|".join([str(it.subject_id) for it in items if it and it.subject_id])
        return hashlib.sha1(s.encode("utf-8", errors="ignore")).hexdigest()
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"哈希计算失败（已忽略） - 原因={type(e).__name__}")
        return ""
