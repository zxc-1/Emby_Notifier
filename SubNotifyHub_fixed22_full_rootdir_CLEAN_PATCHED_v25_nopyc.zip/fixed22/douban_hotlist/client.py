from __future__ import annotations

import logging
from core.logging import get_biz_logger_adapter
from typing import Optional, List

import json
import re

from settings.runtime import get_settings
from core.http import async_request_with_retry_json, async_request_with_retry_text
from core.http import get_http_client

logger = get_biz_logger_adapter(__name__)


def _douban_headers(*, accept: str = "", referer: str = "") -> dict[str, str]:
    """Default headers for Douban requests.

    Douban sometimes returns 404/blank or anti-bot pages for default python
    User-Agent. We use a mobile UA by default and allow override via settings.
    """
    s = get_settings()
    ua = str(getattr(s, "HOTLIST_UA", getattr(s, "DOUBAN_UA", "")) or "").strip()
    if not ua:
        ua = "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Mobile Safari/537.36"
    al = str(getattr(s, "HOTLIST_ACCEPT_LANGUAGE", getattr(s, "DOUBAN_ACCEPT_LANGUAGE", "")) or "").strip()
    if not al:
        al = "zh-CN,zh;q=0.9,en;q=0.6"
    hdrs: dict[str, str] = {
        "User-Agent": ua,
        "Accept-Language": al,
    }
    if accept:
        hdrs["Accept"] = str(accept)
    if referer:
        hdrs["Referer"] = str(referer)
    return hdrs


async def fetch_text(url: str, *, timeout: Optional[float] = None) -> str:
    """Fetch douban page as text.

    Supports optional DOUBAN_PROXY_URL without affecting global http client.
    """
    u = str(url or "").strip()
    if not u:
        return ""
    s = get_settings()
    proxy = str(getattr(s, "DOUBAN_PROXY_URL", "") or "").strip()
    # Timeout: prefer HOTLIST_HTTP_TIMEOUT_SEC; keep backward compatibility with old env name.
    to = float(timeout if timeout is not None else getattr(s, "HOTLIST_HTTP_TIMEOUT_SEC", getattr(s, "DOUBAN_HTTP_TIMEOUT_SEC", 15)) or 15)

    # Prefer existing shared client when no proxy is required.
    if not proxy:
        cl = await get_http_client()
        headers = _douban_headers(accept="text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
        status, txt, _snip = await async_request_with_retry_text(
            cl,
            "GET",
            u,
            headers=headers,
            timeout=to,
            max_attempts=3,
            backoff=(0.5, 3.0),
            log_ctx="douban_hotlist",
            text_snip_len=200,
        )
        # Treat non-2xx as empty to trigger fallbacks.
        if int(status) < 200 or int(status) >= 300:
            logger.detail(f"豆瓣热榜：HTTP 响应非 2xx - status={status} url={u} snip={_snip}")
            return ""
        return txt or ""

    # Proxy mode: create an ephemeral client so we don't mutate the global one.
    try:
        import httpx  # type: ignore

        async with httpx.AsyncClient(
            proxies=proxy,
            headers=_douban_headers(accept="text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"),
            follow_redirects=True,
        ) as cl:
            status, txt, _snip = await async_request_with_retry_text(
                cl,
                "GET",
                u,
                timeout=to,
                max_attempts=3,
                backoff=(0.5, 3.0),
                log_ctx="douban_hotlist_proxy",
                text_snip_len=200,
            )
            if int(status) < 200 or int(status) >= 300:
                logger.detail(f"豆瓣热榜：HTTP 响应非 2xx - status={status} url={u} snip={_snip}")
                return ""
            return txt or ""
    except Exception:
        logger.detail("豆瓣热榜：代理 fetch 失败; 回退 to shared client", exc_info=True)
        cl = await get_http_client()
        headers = _douban_headers(accept="text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
        status, txt, _snip = await async_request_with_retry_text(
            cl,
            "GET",
            u,
            headers=headers,
            timeout=to,
            max_attempts=2,
            backoff=(0.5, 2.0),
            log_ctx="douban_hotlist",
            text_snip_len=200,
        )
        if int(status) < 200 or int(status) >= 300:
            logger.detail(f"豆瓣热榜：HTTP 响应非 2xx - status={status} url={u} snip={_snip}")
            return ""
        return txt or ""


async def fetch_json(url: str, *, params: Optional[dict] = None, timeout: Optional[float] = None, headers: Optional[dict[str, str]] = None) -> tuple[int, object, str]:
    """Fetch a URL and parse JSON.

    Returns: (status_code, parsed_json_or_None, text_snip)
    """
    u = str(url or "").strip()
    if not u:
        return 0, None, ""
    s = get_settings()
    proxy = str(getattr(s, "DOUBAN_PROXY_URL", "") or "").strip()
    to = float(timeout if timeout is not None else getattr(s, "HOTLIST_HTTP_TIMEOUT_SEC", getattr(s, "DOUBAN_HTTP_TIMEOUT_SEC", 15)) or 15)
    hdrs = {
        "User-Agent": "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Mobile Safari/537.36",
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.6",
        "Accept": "application/json, text/plain, */*",
    }
    try:
        if headers:
            hdrs.update({str(k): str(v) for k, v in headers.items() if k and v})
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"HTTP请求头合并失败（已忽略） - 原因={type(e).__name__}")

    if not proxy:
        cl = await get_http_client()
        return await async_request_with_retry_json(
            cl,
            "GET",
            u,
            params=params,
            headers=hdrs,
            timeout=to,
            max_attempts=3,
            backoff=(0.5, 3.0),
            log_ctx="douban_hotlist_json",
            text_snip_len=200,
        )

    # Proxy mode: create an ephemeral client so we don't mutate the global one.
    try:
        import httpx  # type: ignore

        async with httpx.AsyncClient(
            proxies=proxy,
            headers=hdrs,
            follow_redirects=True,
        ) as cl:
            return await async_request_with_retry_json(
                cl,
                "GET",
                u,
                params=params,
                headers=hdrs,
                timeout=to,
                max_attempts=3,
                backoff=(0.5, 3.0),
                log_ctx="douban_hotlist_json_proxy",
                text_snip_len=200,
            )
    except Exception:
        logger.detail("豆瓣热榜：代理 json fetch 失败; 回退 to shared client", exc_info=True)
        cl = await get_http_client()
        return await async_request_with_retry_json(
            cl,
            "GET",
            u,
            params=params,
            headers=hdrs,
            timeout=to,
            max_attempts=2,
            backoff=(0.5, 2.0),
            log_ctx="douban_hotlist_json",
            text_snip_len=200,
        )


async def fetch_collection_items(*, list_key: str, start: int = 0, count: int = 20, list_url: str = "") -> tuple[int, object, str]:
    """Fetch a subject_collection items page via rexxar API (preferred for pagination).

    Returns: (status_code, parsed_json_or_None, text_snip)
    """
    lk = str(list_key or "").strip()
    if not lk:
        return 0, None, ""
    st = max(0, int(start or 0))
    ct = max(1, int(count or 20))
    api = f"https://m.douban.com/rexxar/api/v2/subject_collection/{lk}/items"
    referer = str(list_url or "").strip() or f"https://m.douban.com/subject_collection/{lk}/"
    headers = {
        "Referer": referer,
        "X-Requested-With": "XMLHttpRequest",
    }
    return await fetch_json(api, params={"start": st, "count": ct}, headers=headers)


def _parse_aka_from_subject_html(html: str) -> List[str]:
    """Best-effort parse of Douban subject aliases (又名 / aka) from HTML.

    We intentionally keep this parser dependency-free (no BS4), using a few
    increasingly loose strategies.
    """
    h = str(html or "")
    if not h:
        return []

    # Strategy 1: JSON blob contains "aka": [ ... ]
    m = re.search(r'"aka"\s*:\s*\[(?P<body>.*?)\]', h, re.S)
    if m:
        body = m.group("body")
        try:
            arr = json.loads("[" + body + "]")
            if isinstance(arr, list):
                out = [str(x).strip() for x in arr if str(x).strip()]
                if out:
                    return out
        except Exception:
            pass

    # Strategy 2: desktop page pattern "又名:</span> a / b / c"
    m = re.search(r"又名\s*[:：]\s*</span>\s*(?P<val>[^<]+)", h)
    if m:
        val = m.group("val")
        parts = [p.strip() for p in re.split(r"\s*/\s*", val) if p.strip()]
        if parts:
            return parts

    # Strategy 3: mobile page uses label + content in the same text chunk.
    m = re.search(r"又名\s*[:：]\s*(?P<val>[^\n\r<]{1,300})", h)
    if m:
        val = m.group("val")
        # Stop at common separators
        val = re.split(r"(\n|\r|<)", val, 1)[0]
        parts = [p.strip() for p in re.split(r"\s*/\s*", val) if p.strip()]
        if parts:
            return parts

    return []


async def fetch_subject_aka(subject_id: str, *, timeout: Optional[float] = None) -> List[str]:
    """Fetch Douban subject detail HTML and parse aliases (aka/又名)."""
    sid = str(subject_id or "").strip()
    if not sid:
        return []

    # Prefer mobile subject page; fallback to desktop.
    urls = [
        f"https://m.douban.com/movie/subject/{sid}/",
        f"https://movie.douban.com/subject/{sid}/",
    ]
    for u in urls:
        try:
            html = await fetch_text(u, timeout=timeout, headers={"Referer": "https://m.douban.com/"})
            aka = _parse_aka_from_subject_html(html)
            if aka:
                return aka
        except Exception:
            # best-effort only
            continue
    return []
