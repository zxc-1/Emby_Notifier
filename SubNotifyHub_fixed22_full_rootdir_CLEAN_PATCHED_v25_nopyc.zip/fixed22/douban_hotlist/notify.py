from __future__ import annotations

import logging
from core.logging import get_biz_logger_adapter
logger = get_biz_logger_adapter(__name__)

import html
from typing import List, Optional

from .models import HotlistItem


def build_preview_message(
    *,
    list_title: str,
    list_url: str,
    items: List[HotlistItem],
    subscribed: bool,
    notify_new_items: bool = True,
    notify_auto_result: bool = True,
    auto_create_on: bool = True,
    ignore_count: int = 0,
    top_n: Optional[int] = None,
    rules_text: str = "",
    sub_policy: str = "new_only",
    page_size: int = 20,
    backfill_cursor: int = 0,
) -> str:
    """Build the Telegram-side panel preview message.

    This message is displayed in the hotlist UI panel. It uses Telegram HTML links
    so users can tap titles directly.

    NOTE (customized build): TG 端热榜『新增推送/日报/自动建任务摘要』已移除，
    此处仅保留“面板预览消息”构造。

    (Some args are intentionally kept for backward compatibility with panel code.)
    """

    title = list_title or "Douban Hotlist"
    sub_s = "✅已订阅" if subscribed else "➕未订阅"

    def _esc(x: str) -> str:
        try:
            return html.escape(str(x or ""), quote=True)
        except (ValueError, TypeError, AttributeError) as e:
            logger.detail(f"HTML转义失败 - 输入值类型={type(x).__name__}, 原因={type(e).__name__}")
            return str(x or "")

    lines: List[str] = []
    lines.append(f"🔥 {_esc(title)}")

    # Keep the preview message short explains only the important switches.
    notify_on = bool(notify_new_items) or bool(notify_auto_result)
    notify_s = "🔔通知:开" if notify_on else "🔕通知:关"
    status = " · ".join([sub_s, notify_s])
    # 这是“面板消息”，键盘里已经有『打开榜单』按钮；为避免“满屏 URL”，这里不再重复输出榜单链接。
    lines.append(f"状态：{status}")

    if not items:
        lines.append("\n（未解析到条目，可能需要代理/稍后重试）")
        return "\n".join(lines)

    lines.append("\n预览")
    for idx, it in enumerate(items[:3], start=1):
        t = it.title or f"subject {it.subject_id}"
        rating = ""
        if it.rating is not None:
            try:
                rating = f" ⭐{float(it.rating):.1f}"
            except (ValueError, TypeError) as e:
                logger.detail(f"评分格式化失败 - 评分值={it.rating!r}, 原因={type(e).__name__}")
                rating = f" ⭐{_esc(str(it.rating))}"

        u = str(getattr(it, "url", "") or "").strip()
        if u:
            # Clickable title
            lines.append(f"{idx}. <a href=\"{_esc(u)}\">{_esc(t)}</a>{rating}")
        else:
            lines.append(f"{idx}. {_esc(t)}{rating}")
    if len(items) > 3:
        lines.append(f"… 还有 {len(items) - 3} 条未展开")

    return "\n".join(lines)
