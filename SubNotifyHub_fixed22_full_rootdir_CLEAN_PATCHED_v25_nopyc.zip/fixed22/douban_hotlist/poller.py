from __future__ import annotations

import asyncio
from core.logging import get_biz_logger
from core.logging import get_biz_logger_adapter
import random
import time
from typing import Any, Dict, List, Optional, Tuple

from settings.runtime import get_settings
from core.metrics import metrics

from .client import fetch_collection_items, fetch_text
from .models import HotlistItem, HotlistResult
from .parser import compute_items_hash, parse_hotlist_api_items, parse_hotlist_page
from .store import (
    get_snapshot,
    get_ignore_sets_bulk,
    get_seen_in_bulk,
    get_auto_state_bulk,
    add_seen_many,
    upsert_auto_state,
    seen_any,
    list_distinct_list_keys,
    list_subscribers,
    patch_subscription_filters,
    update_snapshot_error,
    update_snapshot_success,
)
from .utils import normalize_mode
from .resolver import resolve_and_subscribe, resolve_subject_meta
from .rules import (
    needs_subject_meta,
    read_auto_rules,
    read_flags,
    read_page_size,
    read_top_n,
    should_auto_create_item,
    should_auto_create_meta,
)

logger = get_biz_logger_adapter(__name__)
biz = get_biz_logger(__name__)


def _mono() -> float:
    return float(time.monotonic())



def _is_retryable_reason(reason: str) -> bool:
    s = str(reason or '').strip().lower()
    if not s:
        return True
    # transient
    if s.startswith('exception'):
        return True
    if s.startswith('mediahelp_failed:exception'):
        return True
    if s.startswith('mediahelp_failed:timeout'):
        return True
    if s in ('no_tmdb', 'no_imdb_no_title_match'):
        # could become resolvable later (meta/IMDb/TMDB updates)
        return True
    if s.startswith('mediahelp_failed:'):
        # usually transient (upstream), keep retryable with backoff
        return True
    return False


def _should_retry_auto(*, state: dict, now_ts: float, s: Any) -> bool:
    # state keys: last_try_ts, attempt_count, last_ok, last_reason
    try:
        if not state:
            return False
        if bool(state.get('last_ok')):
            return False
        reason = str(state.get('last_reason') or '').strip()
        if not _is_retryable_reason(reason):
            return False

        max_attempts = int(getattr(s, 'HOTLIST_AUTO_RETRY_MAX_ATTEMPTS', 12) or 12)
        n = int(state.get('attempt_count') or 0)
        if n >= max_attempts:
            return False

        # Fast path: if store already computed next_retry_ts, use it.
        nrt = state.get('next_retry_ts')
        try:
            nrt_f = float(nrt) if nrt is not None else None
        except Exception:
            nrt_f = None
        if nrt_f is not None:
            return now_ts >= nrt_f

        last_try = state.get('last_try_ts')
        last_try_f = float(last_try) if last_try is not None else None
        if last_try_f is None:
            return True

        # Backoff: different base for different reasons
        rlow = str(reason or '').lower()
        if rlow.startswith('exception') or rlow.startswith('mediahelp_failed:exception') or rlow.startswith('mediahelp_failed:timeout'):
            base = float(getattr(s, 'HOTLIST_AUTO_RETRY_BASE_SEC', 1800) or 1800)  # 30m
        elif rlow in ('no_tmdb', 'no_imdb_no_title_match'):
            base = float(getattr(s, 'HOTLIST_AUTO_RETRY_BASE_NO_MATCH_SEC', 21600) or 21600)  # 6h
        else:
            base = float(getattr(s, 'HOTLIST_AUTO_RETRY_BASE_OTHER_SEC', 7200) or 7200)  # 2h

        # exponential, capped
        cap = float(getattr(s, 'HOTLIST_AUTO_RETRY_CAP_SEC', 604800) or 604800)  # 7d
        mult = 2 ** max(0, min(6, n - 1))
        wait = min(cap, base * mult)
        return (now_ts - last_try_f) >= wait
    except Exception as e:
        biz.detail("ignored exception in _should_retry_auto", exc_info=True)
        return False


async def fetch_and_parse_page(*, list_key: str, list_url: str, count: int = 20) -> Optional[HotlistResult]:
    """Fetch first page.

    Prefer rexxar API (stable + supports pagination) and fall back to HTML parsing for preview-style compatibility.
    """
    lk = str(list_key or "").strip()
    lu = str(list_url or "").strip()
    if not lk or not lu:
        return None

    s = get_settings()
    to = float(getattr(s, "HOTLIST_HTTP_TIMEOUT_SEC", getattr(s, "DOUBAN_HTTP_TIMEOUT_SEC", 15)) or 15)
    ct = max(1, min(100, int(count or 20)))

    # 1) API
    try:
        t0 = _mono()
        status, data, _snip = await fetch_collection_items(list_key=lk, start=0, count=ct, list_url=lu)
        metrics.observe("hotlist_fetch_ms", (_mono() - t0) * 1000.0)
        
        if int(status) >= 200 and int(status) < 300 and data is not None:
            res = parse_hotlist_api_items(list_key=lk, list_url=lu, data=data, start=0)
            logger.detail(f"hotlist: API 抓取成功 - 榜单={lk}, 条目数={len(list(res.items or []))}, 标题={res.list_title or ''}")
            return res
        else:
            logger.detail(f"hotlist: API 返回异常状态 - 榜单={lk}, 状态码={status}")
    except Exception as e:
        logger.detail(f"hotlist: API 抓取失败 - 榜单={lk}, 原因={type(e).__name__}", exc_info=True)

    # 2) HTML fallback (page 1 only)
    try:
        t0 = _mono()
        html = await fetch_text(lu, timeout=to)
        metrics.observe("hotlist_fetch_ms", (_mono() - t0) * 1000.0)
        
        if not html:
            logger.detail(f"hotlist: HTML 内容为空 - 榜单={lk}, URL={lu}")
            return None
            
        res2 = parse_hotlist_page(lu, html)
        logger.detail(f"hotlist: HTML 解析成功 - 榜单={lk}, 条目数={len(list(res2.items or []))}, 标题={res2.list_title or ''}")
        return res2
    except Exception as e:
        logger.detail(f"hotlist: HTML 解析失败 - 榜单={lk}, 原因={type(e).__name__}", exc_info=True)
        return None



async def process_one_list(
    *,
    list_key: str,
    list_url: str,
    task_registry: Any = None,
) -> None:
    """Fetch a list, update snapshot, and process subscribers.

    NOTE (customized build): 热榜『新增推送/日报』消息发送已移除。
    本函数仍负责：抓取榜单、去重、按规则自动创建订阅任务、维护 seen/baseline。
    """
    lk = str(list_key or "").strip()
    if not lk:
        return

    subs = list_subscribers(lk)
    if not subs:
        return

    lu = str(list_url or "").strip() or str(subs[0].get("list_url") or "").strip()
    if not lu:
        return
    with biz.entry(
        domain="Hotlist",
        action="轮询",
        group_title="热榜轮询",
        list_key=lk,
        list_url=lu,
        subs=len(subs),
    ):
        biz.step("构建订阅配置", i=1, total=5)

        # Snapshot hash (for short-circuit when nothing changed).
        prev_snap = None
        prev_hash = ""
        try:
            prev_snap = get_snapshot(lk)
            prev_hash = str((prev_snap or {}).get("last_hash") or "")
        except Exception:
            prev_snap = None
            prev_hash = ""

        # Build per-subscriber config (no per-subscriber DB reads here; those are batched later).
        sub_cfgs: List[Dict[str, Any]] = []
        chat_ids: List[int] = []
        wanted_count = 0

        def _as_bool(v: Any, default: bool = True) -> bool:
            if v is None:
                return default
            if isinstance(v, bool):
                return v
            s = str(v).strip().lower()
            if s in ("1", "true", "yes", "y", "on"):
                return True
            if s in ("0", "false", "no", "n", "off"):
                return False
            return default

        for sub in subs:
            cid = int(sub.get("chat_id") or 0)
            if cid == 0:
                continue
            filters = sub.get("filters") if isinstance(sub, dict) else None
            if not isinstance(filters, dict):
                filters = {}

            notify_new, notify_auto, auto_on = read_flags(filters)
            top_n = read_top_n(filters)
            page_size = read_page_size(filters)
            auto_rules = read_auto_rules(filters)
            # baseline_ready default True for legacy subs (no key present)
            baseline_ready = _as_bool(filters.get("baseline_ready", True), True)

            # Self-heal: if baseline_ready is False but seen rows already exist, treat it as ready
            # and try to persist the flip. This avoids a subscription being stuck in "baseline" mode
            # when patching filters previously failed.
            if (not baseline_ready) and seen_any(chat_id=cid, list_key=lk):
                baseline_ready = True
                try:
                    patch_subscription_filters(chat_id=cid, list_key=lk, patch={"baseline_ready": True})
                except Exception as e:
                    biz.warning("基线状态修复失败（将在下次轮询时自动重试）", chat_id=cid, 榜单=lk, 原因=type(e).__name__)

            try:
                wn = int(page_size or 20)
            except (ValueError, TypeError) as e:
                biz.warning("页面大小配置无效，使用默认值 20", chat_id=cid, 配置值=page_size, 原因=type(e).__name__)
                wn = 20
            wn = max(1, min(100, wn))
            tn = int(top_n or 0) if top_n else 0
            wanted_count = max(wanted_count, max(wn, tn))

            sub_cfgs.append(
                {
                    "chat_id": cid,
                    "mode": normalize_mode(str(sub.get("mode") or "incremental")),
                    "notify_new": bool(notify_new),
                    "notify_auto": bool(notify_auto),
                    "auto_on": bool(auto_on),
                    "top_n": top_n,
                    "page_size": wn,
                    "auto_rules": auto_rules,
                    "filters": filters,
                    "baseline_ready": baseline_ready,
                }
            )
            chat_ids.append(cid)

        if not sub_cfgs:
            return

        wanted_count = max(1, min(100, int(wanted_count or 20)))

        # Fetch
        biz.step("抓取榜单数据", i=2, total=5)
        t0 = _mono()
        try:
            res = await fetch_and_parse_page(list_key=lk, list_url=lu, count=wanted_count)
        except Exception as e:
            biz.fail("抓取榜单失败", stage="douban_poll", 榜单=lk, 原因=f"{type(e).__name__}: {str(e)[:100]}")
            update_snapshot_error(list_key=lk, reason="fetch_exception", detail=str(e)[:200])
            metrics.inc("hotlist_fetch_error")
            return

        if not res:
            biz.warning("榜单数据为空", 榜单=lk)
            update_snapshot_error(list_key=lk, reason="empty_parse", detail="no result")
            metrics.inc("hotlist_empty")
            return

        items = list(res.items or [])

        # Snapshot: always reflect the latest fetch, even if empty.
        try:
            h = compute_items_hash(items)
        except Exception as e:
            biz.warning("计算榜单哈希失败，使用空哈希值", 榜单=lk, 原因=type(e).__name__)
            h = ""
        update_snapshot_success(list_key=lk, list_title=res.list_title, items=items, items_hash=h)
        metrics.observe("hotlist_poll_ms", (_mono() - t0) * 1000.0)
        biz.ok("抓取完成", items=len(items), list_title=str(res.list_title or ""))
        biz.step("构建窗口与去重", i=3, total=5)

        if not items:
            # No further processing
            metrics.inc("hotlist_empty")
            return

        s = get_settings()
        now_ts = time.time()
        auto_enabled_global = bool(getattr(s, "HOTLIST_AUTO_CREATE_SUBS", True))

        # Batch DB reads
        ignores_map = get_ignore_sets_bulk(list_key=lk, chat_ids=chat_ids)

        # Build per-chat window ids + window items
        per_chat: Dict[int, Dict[str, Any]] = {}
        union_ids: set[str] = set()

        for cfg in sub_cfgs:
            cid = int(cfg["chat_id"])
            ign = ignores_map.get(cid) or set()
            wn = int(cfg.get("page_size") or 20)
            top_n = cfg.get("top_n")
            tn = int(top_n or 0) if top_n else 0
            window = max(wn, tn)
            window_items = items[: max(1, min(100, window))]

            window_ids: List[str] = []
            for it in window_items:
                sid = str(getattr(it, "subject_id", "") or "").strip()
                if not sid or sid in ign:
                    continue
                window_ids.append(sid)

            union_ids.update(window_ids)
            per_chat[cid] = {
                "cfg": cfg,
                "ignore": ign,
                "window_items": window_items,
                "window_ids": window_ids,
                "unseen_items": [],
            }
        seen_map = get_seen_in_bulk(list_key=lk, chat_ids=chat_ids, subject_ids=list(union_ids))
        # auto_state v2 map key format: "<subject_id>::<prefer_media_type>" (prefer_media_type can be "")
        auto_state_map = get_auto_state_bulk(list_key=lk, subject_ids=list(union_ids))

        def _state_key(sid: str, pref: str) -> str:
            return f"{str(sid or '').strip()}::{str(pref or '').strip().lower()}"

        # Build auto candidates (skip baseline-not-ready subs)
        # auto_need_keys is keyed by "<subject_id>::<prefer_media_type>" so movie/tv attempts don't pollute.
        meta_need_ids: set[str] = set()
        meta_pending_keys: Dict[str, set[str]] = {}
        auto_need_keys: set[str] = set()
        subj_hints: Dict[str, Dict[str, Any]] = {}


        # Track why a subject enters auto (human-readable):
        # - new: first time seen in window
        # - backfill: seen==True but no auto_state record (历史漏订补偿)
        # - retry: has auto_state but eligible for retry by backoff
        auto_reason: Dict[str, str] = {}

        def _reason_pri(x: str) -> int:
            m = {"new": 3, "backfill": 2, "retry": 1}
            return int(m.get(str(x or "").strip().lower(), 0))

        def _set_reason(key: str, reason: str) -> None:
            r = str(reason or "").strip().lower() or "retry"
            old = auto_reason.get(key)
            if (not old) or (_reason_pri(r) > _reason_pri(old)):
                auto_reason[key] = r

        def _get_state_for_seen(sid: str, pref: str) -> dict:
            # Fallback to neutral bucket ("") to avoid inference drift.
            return (
                auto_state_map.get(_state_key(sid, pref))
                or auto_state_map.get(_state_key(sid, ""))
                or {}
            )


        def _infer_pref_from_list_key(x: str) -> str:
            k = str(x or "").strip().lower()
            if k.startswith("movie_"):
                return "movie"
            if k.startswith("tv_") or k.startswith("show_"):
                return "tv"
            return ""

        def _infer_pref_from_rules(rules: dict) -> str:
            pref_hint = str((rules or {}).get("media") or "").strip().lower()
            if pref_hint not in ("movie", "tv"):
                pref_hint = ""
            if not pref_hint:
                pref_hint = _infer_pref_from_list_key(lk)
            return pref_hint


        for cid, blob in per_chat.items():
            cfg = blob.get("cfg") or {}
            if not bool(cfg.get("baseline_ready", True)):
                # Baseline sync handled later (seed seen, disable auto on first effective poll)
                continue
            if not (auto_enabled_global and cfg.get("auto_on")):
                continue

            ign = blob.get("ignore") or set()
            seen = seen_map.get(cid) or set()
            auto_state_local = auto_state_map
            rules = cfg.get("auto_rules") or {}
            top_n = cfg.get("top_n")

            unseen: List[HotlistItem] = []
            for it in blob.get("window_items") or []:
                sid = str(getattr(it, "subject_id", "") or "").strip()
                if not sid or sid in ign:
                    continue
                if sid in seen:
                    pref = _infer_pref_from_rules(rules)
                    st = _get_state_for_seen(sid, pref)
                    if st:
                        # Seen before + has state: follow retry/backoff.
                        if not _should_retry_auto(state=st, now_ts=now_ts, s=s):
                            continue
                    else:
                        # Seen before but no auto_state: historical漏订补偿（允许补一次）。
                        pass
                unseen.append(it)
            blob["unseen_items"] = unseen

            for it in unseen:
                sid = str(it.subject_id or "").strip()
                if not sid:
                    continue
                if not should_auto_create_item(it, rules=rules, fallback_top_n=top_n):
                    continue
                pref_hint = _infer_pref_from_rules(rules)
                k = _state_key(sid, pref_hint)
                if k not in subj_hints:
                    subj_hints[k] = {"title": str(getattr(it, "title", "") or ""), "prefer_media_type": pref_hint}

                # Determine why it enters auto: new/backfill/retry
                _in_seen = (sid in seen)
                _has_state = bool(_get_state_for_seen(sid, pref_hint)) if _in_seen else False
                if not _in_seen:
                    _set_reason(k, 'new')
                elif not _has_state:
                    _set_reason(k, 'backfill')
                else:
                    _set_reason(k, 'retry')

                if needs_subject_meta(rules):
                    meta_need_ids.add(sid)
                    meta_pending_keys.setdefault(sid, set()).add(k)
                else:
                    auto_need_keys.add(k)

        # Resolve meta where required
        meta_cache: Dict[str, Dict[str, Any]] = {}

        # Optimization (1): if list hash unchanged and there is no work (no auto candidates,
        # no meta fetch, no baseline pending, and no seen writes), short-circuit early.
        baseline_pending = any(not bool((c.get("baseline_ready", True))) for c in sub_cfgs)
        need_seen_write = False
        if not baseline_pending:
            try:
                for cid, blob in per_chat.items():
                    cfg = blob.get("cfg") or {}
                    if not bool(cfg.get("baseline_ready", True)):
                        baseline_pending = True
                        break
                    window_ids = blob.get("window_ids") or []
                    if not window_ids:
                        continue
                    seen = seen_map.get(int(cid)) or set()
                    for _sid in window_ids:
                        if _sid not in seen:
                            need_seen_write = True
                            raise StopIteration
            except StopIteration:
                pass
            except Exception:
                # conservative: if we can't prove we don't need writes, do not short-circuit
                need_seen_write = True

        if (str(prev_hash or "") == str(h or "")) and (not baseline_pending) and (not meta_need_ids) and (not auto_need_keys) and (not need_seen_write):
            biz.ok("榜单未变化，无需处理", list_key=lk, items=len(items))
            return
        if meta_need_ids:
            meta_sem = asyncio.Semaphore(int(getattr(s, "HOTLIST_META_CONCURRENCY", 6) or 6))

            async def _meta_one(sid: str) -> None:
                async with meta_sem:
                    try:
                        meta_cache[sid] = await resolve_subject_meta(sid)
                    except Exception as e:
                        biz.warning("获取条目元数据失败，使用空数据", subject_id=sid, 原因=type(e).__name__)
                        meta_cache[sid] = {"imdb_id": "", "year": None, "media_type_hint": "", "tags": []}

            try:
                res_meta = await asyncio.gather(*[_meta_one(x) for x in list(meta_need_ids)], return_exceptions=True)
                for _r in res_meta:
                    if isinstance(_r, Exception):
                        biz.detail(f"并行任务失败（已忽略）：{type(_r).__name__}", error=str(_r))
                for _r in res_meta:
                    if isinstance(_r, Exception) and not isinstance(_r, asyncio.CancelledError):
                        biz.detail("批量获取元数据出现异常（已忽略）", 原因=type(_r).__name__, exc_info=_r)
            except Exception as e:
                biz.warning("批量获取元数据失败", 原因=type(e).__name__)

            # Evaluate meta-gated rules
            for cid, blob in per_chat.items():
                cfg = blob.get("cfg") or {}
                if not (auto_enabled_global and cfg.get("auto_on")):
                    continue
                if not bool(cfg.get("baseline_ready", True)):
                    continue
                rules = cfg.get("auto_rules") or {}
                seen = seen_map.get(int(cid)) or set()
                if not needs_subject_meta(rules):
                    continue
                top_n = cfg.get("top_n")
                for it in blob.get("unseen_items") or []:
                    sid = str(it.subject_id or "").strip()
                    if not sid:
                        continue
                    if sid not in meta_need_ids:
                        continue
                    if not should_auto_create_item(it, rules=rules, fallback_top_n=top_n):
                        continue
                    meta = meta_cache.get(sid) or {}
                    if not should_auto_create_meta(meta, rules=rules):
                        continue
                    pref_hint = _infer_pref_from_rules(rules)
                    k = _state_key(sid, pref_hint)
                    # Ensure hint exists
                    if k not in subj_hints:
                        subj_hints[k] = {"title": str(getattr(it, "title", "") or ""), "prefer_media_type": pref_hint}
                    # Keep reason (new/backfill/retry) for summary/logging
                    _in_seen = (sid in seen)
                    _has_state = bool(_get_state_for_seen(sid, pref_hint)) if _in_seen else False
                    if not _in_seen:
                        _set_reason(k, 'new')
                    elif not _has_state:
                        _set_reason(k, 'backfill')
                    else:
                        _set_reason(k, 'retry')
                    auto_need_keys.add(k)

        # Summarize auto candidate reasons (new/backfill/retry)
        _new_cnt = sum(1 for _k in auto_need_keys if auto_reason.get(_k) == 'new')
        _backfill_cnt = sum(1 for _k in auto_need_keys if auto_reason.get(_k) == 'backfill')
        _retry_cnt = sum(1 for _k in auto_need_keys if auto_reason.get(_k) == 'retry')
        if _backfill_cnt:
            biz.warning(
                "检测到历史漏订：%s 条已见过但从未尝试订阅（缺 auto_state），将执行补漏自动订阅",
                _backfill_cnt,
                list_key=lk,
                backfill=_backfill_cnt,
            )
        biz.step(
            "执行 auto 订阅",
            i=4,
            total=5,
            auto_candidates=len(auto_need_keys),
            auto_new=_new_cnt,
            auto_backfill=_backfill_cnt,
            auto_retry=_retry_cnt,
        )
        # Auto subscribe once per subject
        auto_results: Dict[str, Tuple[bool, str]] = {}
        auto_total = 0
        auto_ok_count = 0
        auto_fail_count = 0
        sem = asyncio.Semaphore(int(getattr(s, "HOTLIST_AUTO_CREATE_CONCURRENCY", 4) or 4))

        def _split_key(k: str) -> tuple[str, str]:
            try:
                a, b = str(k).split("::", 1)
                return (a.strip(), b.strip().lower())
            except Exception as e:
                biz.detail("ignored exception in _split_key", exc_info=True)
                return (str(k or "").strip(), "")

        async def _auto_one(key: str) -> None:
            if not auto_enabled_global:
                auto_results[key] = (False, "disabled")
                return
            sid, pref_used = _split_key(key)
            async with sem:
                try:
                    hint = subj_hints.get(key) or {}
                    # Prefer the key-derived type over hint map value
                    if not pref_used:
                        pref_used = str(hint.get("prefer_media_type") or "")
                    pref_used = str(pref_used or "")[:12]
                    rkind = str(auto_reason.get(key) or "retry").strip().lower()
                    tname = str(hint.get("title") or "").strip()
                    label = (f"〈{tname}〉(douban={sid})" if tname else f"douban={sid}")
                    if rkind == "backfill":
                        biz.detail(f"🧾 补漏订阅：{label} 之前已见过但无订阅状态（缺 auto_state），现在补一次")
                    elif rkind == "new":
                        biz.detail(f"🆕 新增订阅：{label} 首次进入窗口，触发自动订阅")
                    elif rkind == "retry":
                        biz.detail(f"🔁 重试订阅：{label} 命中重试条件，开始重试")

                    ok, reason = await resolve_and_subscribe(
                        sid,
                        title_hint=(str(hint.get("title") or "")[:120] or None),
                        prefer_media_type=(pref_used or None),
                        source_tag="🔥 热榜订阅",
                        source_label="榜单",
                        source_value=str(res.list_title or list_key),
                    )
                except Exception as e:
                    biz.warning("自动订阅失败", subject_id=(sid or key), 原因=f"{type(e).__name__}: {str(e)[:80]}")
                    ok, reason = (False, "exception")
                auto_results[key] = (ok, str(reason or "")[:160])
                try:
                    upsert_auto_state(list_key=lk, subject_id=sid, prefer_media_type=pref_used, ok=bool(ok), reason=str(reason or ""))
                except Exception as _e:
                    pass

        if auto_need_keys:
            _auto_list = sorted(list(auto_need_keys))
            auto_total = len(_auto_list)
            try:
                res_auto = await asyncio.gather(*[_auto_one(x) for x in _auto_list], return_exceptions=True)
                for _r in res_auto:
                    if isinstance(_r, Exception):
                        biz.detail(f"并行任务失败（已忽略）：{type(_r).__name__}", error=str(_r))
                for _r in res_auto:
                    if isinstance(_r, Exception) and not isinstance(_r, asyncio.CancelledError):
                        biz.detail("批量自动订阅出现异常（已忽略）", 原因=type(_r).__name__, exc_info=_r)
            except Exception as e:
                biz.warning("批量自动订阅失败", 原因=type(e).__name__)
            else:
                for _i, _k in enumerate(_auto_list, start=1):
                    _ok, _reason = auto_results.get(_k, (False, ""))
                    _sid, _pref = _split_key(_k)
                    _hint = subj_hints.get(_k) or {}
                    _t = str(_hint.get('title') or '').strip()
                    _label = (f"〈{_t}〉(douban={_sid})" if _t else f"douban={_sid}")
                    _rk = str(auto_reason.get(_k) or 'retry').strip().lower()
                    if _ok:
                        _msg = {
                            'new': f"新增订阅成功：{_label}",
                            'backfill': f"补漏订阅成功：{_label}",
                            'retry': f"重试订阅成功：{_label}",
                        }.get(_rk, f"auto 订阅成功：{_label}")
                        biz.ok_item(_msg, i=_i, total=len(_auto_list), subject_id=_sid, media=(_pref or ''), reason=_reason)
                    else:
                        _msg = {
                            'new': f"新增订阅失败：{_label}",
                            'backfill': f"补漏订阅失败：{_label}",
                            'retry': f"重试订阅失败：{_label}",
                        }.get(_rk, f"auto 订阅失败：{_label}")
                        biz.warn_item(_msg, i=_i, total=len(_auto_list), subject_id=_sid, media=(_pref or ''), reason=_reason)

        # Finalize auto summary counters
        if auto_need_keys:
            auto_ok_count = sum(1 for _k in auto_need_keys if (auto_results.get(_k, (False, ''))[0]))
            auto_fail_count = int(auto_total) - int(auto_ok_count)

        biz.step("推进 seen/基线", i=5, total=5)
        # Advance seen set + baseline sync
        for cid, blob in per_chat.items():
            cfg = blob.get("cfg") or {}
            window_ids = list(blob.get("window_ids") or [])
            if not window_ids:
                continue

            if not bool(cfg.get("baseline_ready", True)):
                # First effective poll after subscription: seed seen and flip baseline_ready.
                add_seen_many(chat_id=cid, list_key=lk, subject_ids=window_ids, source="baseline_poll")
                try:
                    patch_subscription_filters(
                        chat_id=cid,
                        list_key=lk,
                        patch={"baseline_ready": True, "baseline_sync_ts": now_ts},
                    )
                except Exception as e:
                    biz.warning("基线同步状态保存失败（将在下次轮询时自动修复）", chat_id=cid, 榜单=lk, 原因=type(e).__name__)
                continue

            # Optimization: avoid needless writes when we can prove window already covered.
            seen = seen_map.get(int(cid)) or set()
            if all((x in seen) for x in window_ids):
                continue
            add_seen_many(chat_id=cid, list_key=lk, subject_ids=window_ids, source="poll")


        biz.ok("轮询完成", list_key=lk, list_title=(str(res.list_title or "") or None), items=len(items), auto_total=auto_total, auto_ok=auto_ok_count, auto_fail=auto_fail_count, auto_new=_new_cnt, auto_backfill=_backfill_cnt, auto_retry=_retry_cnt)


async def run_poll_loop(*, stop_evt: asyncio.Event, task_registry: Any = None) -> None:
    s = get_settings()
    if not bool(getattr(s, "HOTLIST_ENABLED", True)):
        return

    # Default poll frequency: 60 minutes (can be overridden by HOTLIST_POLL_INTERVAL_SEC)
    interval = float(getattr(s, "HOTLIST_POLL_INTERVAL_SEC", 3600) or 3600)
    jitter_ratio = float(getattr(s, "HOTLIST_POLL_JITTER_RATIO", 0.10) or 0.10)

    # Basic loop
    while not stop_evt.is_set():
        try:
            list_keys = list_distinct_list_keys()
            for lk in list_keys:
                if stop_evt.is_set():
                    break
                subs = list_subscribers(lk)
                lu = str(subs[0].get("list_url") or "") if subs else ""
                try:
                    await process_one_list(list_key=lk, list_url=lu, task_registry=task_registry)
                except Exception as e:
                    biz.warning("处理榜单失败", 榜单=lk, 原因=f"{type(e).__name__}: {str(e)[:100]}")
        except Exception as e:
            biz.warning("轮询循环异常", 原因=f"{type(e).__name__}: {str(e)[:100]}")

        # Sleep with jitter
        if stop_evt.is_set():
            break
        j = interval * jitter_ratio
        sleep_s = interval + (random.random() * 2 - 1) * j
        try:
            await asyncio.wait_for(stop_evt.wait(), timeout=max(1.0, sleep_s))
        except asyncio.TimeoutError:
            pass
