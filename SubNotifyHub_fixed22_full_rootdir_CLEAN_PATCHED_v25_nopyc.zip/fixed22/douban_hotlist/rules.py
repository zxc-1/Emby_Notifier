from __future__ import annotations

"""Hotlist rule helpers.

Rules are stored under subscription.filters_json.

We intentionally keep schema flexible (JSON) to avoid SQLite migrations.

Key conventions (filters_json):
  - notify_new_items: bool  (whether to notify new items)
  - notify_auto_result: bool (whether to notify auto-create result summary)
  - top_n: int (filter for notifications, optional)
  - auto_rules: dict
      - min_rating: float
      - block_unrated: bool (when min_rating is set, whether to block items without rating)
      - auto_top_n: int
      - kw_black: list[str]
      - kw_white: list[str]
      - media: 'movie'|'tv'  (optional)
      - year_min: int
      - year_max: int
      - tag_black: list[str]
      - tag_white: list[str]
      - strict_meta: bool (default True; if False, missing meta (year/tags/media) will be allowed)
"""
import logging
from core.logging import get_biz_logger_adapter
logger = get_biz_logger_adapter(__name__)


from typing import Any, Dict, Iterable, List, Optional, Tuple

from settings.runtime import get_settings

from .models import HotlistItem


def _bool(v: Any, default: bool) -> bool:
    if v is None:
        return bool(default)
    if isinstance(v, bool):
        return v
    s = str(v).strip().lower()
    if s in ("1", "true", "yes", "y", "on"):
        return True
    if s in ("0", "false", "no", "n", "off"):
        return False
    return bool(default)


def _int(v: Any) -> Optional[int]:
    try:
        if v is None:
            return None
        i = int(v)
        return i
    except (ValueError, TypeError) as e:
        logger.detail(f"整数转换失败（返回 None） - value={v}, 原因={type(e).__name__}")
        return None


def _float(v: Any) -> Optional[float]:
    try:
        if v is None:
            return None
        return float(v)
    except (ValueError, TypeError) as e:
        logger.detail(f"浮点数转换失败（返回 None） - value={v}, 原因={type(e).__name__}")
        return None


def normalize_keywords(v: Any) -> List[str]:
    if v is None:
        return []
    if isinstance(v, (list, tuple, set)):
        out: List[str] = []
        for x in v:
            s = str(x or "").strip()
            if s:
                out.append(s)
        return out
    s = str(v or "").strip()
    if not s:
        return []
    # allow comma / chinese comma / semicolon
    parts = [p.strip() for p in s.replace("；", ",").replace(";", ",").replace("，", ",").split(",")]
    return [p for p in parts if p]


def read_flags(filters: Dict[str, Any]) -> Tuple[bool, bool, bool]:
    """Return (notify_new_items, notify_auto_result, auto_create_on).

    v1.6.4+ 语义调整：
    - 不再支持 per-subscription 的“自动建任务”开关（避免误操作/漏建）。
    - “订阅/追新”都是默认会创建任务；是否允许创建任务仅受全局配置 HOTLIST_AUTO_CREATE_SUBS 控制。

    为了兼容旧数据，这里仍返回第三个 bool，但它等价于全局开关。
    """
    s = get_settings()
    default_auto = bool(getattr(s, "HOTLIST_AUTO_CREATE_SUBS", True))

    # Backward compatibility:
    # - step3 used 'notify' for all notifications.
    # - early Web Admin used 'notify_new' / 'notify_result'.
    old_notify = _bool(filters.get("notify"), True)
    old_notify_new = _bool(filters.get("notify_new"), old_notify)
    old_notify_result = _bool(filters.get("notify_result"), old_notify_new)

    notify_new = _bool(filters.get("notify_new_items"), old_notify_new)
    notify_auto = _bool(filters.get("notify_auto_result"), old_notify_result)

    # Per-sub switch removed: always follow global setting.
    auto_on = default_auto
    return notify_new, notify_auto, auto_on


def read_top_n(filters: Dict[str, Any]) -> Optional[int]:
    tn = _int(filters.get("top_n"))
    if tn and tn > 0:
        return tn
    return None


def read_auto_rules(filters: Dict[str, Any]) -> Dict[str, Any]:
    r = filters.get("auto_rules")
    if not isinstance(r, dict):
        r = {}

    out: Dict[str, Any] = {}
    mr = _float(r.get("min_rating"))
    if mr is not None:
        out["min_rating"] = float(mr)

    # When min_rating is set, default is lenient: allow unrated.
    # If user explicitly enables block_unrated, unrated items will be blocked.
    bu = r.get("block_unrated")
    if bu is not None:
        out["block_unrated"] = _bool(bu, False)

    atn = _int(r.get("auto_top_n"))
    if atn is not None and int(atn) > 0:
        out["auto_top_n"] = int(atn)

    out["kw_black"] = normalize_keywords(r.get("kw_black"))
    out["kw_white"] = normalize_keywords(r.get("kw_white"))

    media = str(r.get("media") or r.get("media_type") or r.get("type") or "").strip().lower()
    if media in ("movie", "tv"):
        out["media"] = media

    ym = _int(r.get("year_min") or r.get("ymin"))
    yM = _int(r.get("year_max") or r.get("ymax"))
    if ym is not None:
        out["year_min"] = int(ym)
    if yM is not None:
        out["year_max"] = int(yM)

    out["tag_black"] = normalize_keywords(r.get("tag_black"))
    out["tag_white"] = normalize_keywords(r.get("tag_white"))

    # strict_meta: default True for backward compatibility (previous behavior was conservative).
    sm = r.get("strict_meta")
    if sm is not None:
        out["strict_meta"] = _bool(sm, True)
    return out


def read_page_size(filters: Dict[str, Any], *, default: int = 20) -> int:
    """Page size for backfill / "new-only" window.

    Stored in filters_json as page_size.
    """
    try:
        v = filters.get("page_size")
        i = int(v) if v is not None else int(default)
        if i <= 0:
            return int(default)
        # Keep it sane
        return max(1, min(100, i))
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"页面大小读取失败（使用默认值） - value={filters.get('page_size') if isinstance(filters, dict) else None}, default={default}, 原因={type(e).__name__}")
        return int(default)


def read_baseline_pages(filters: Dict[str, Any], *, default: int = 1) -> int:
    try:
        v = filters.get("baseline_pages")
        i = int(v) if v is not None else int(default)
        if i <= 0:
            return int(default)
        return max(1, min(10, i))
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"基线页数读取失败（使用默认值） - value={filters.get('baseline_pages') if isinstance(filters, dict) else None}, default={default}, 原因={type(e).__name__}")
        return int(default)


def read_backfill_cursor(filters: Dict[str, Any], *, default: int = 0) -> int:
    try:
        v = filters.get("backfill_cursor")
        i = int(v) if v is not None else int(default)
        if i < 0:
            return 0
        return i
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"回填游标读取失败（使用默认值） - value={filters.get('backfill_cursor') if isinstance(filters, dict) else None}, default={default}, 原因={type(e).__name__}")
        return int(default)


def read_sub_policy(filters: Dict[str, Any], *, default: str = "new_only") -> str:
    """Subscription policy.

    - new_only: subscribe and only act on items that appear after baseline init
    - paged: subscribe and encourage page-by-page backfill (manual)

    Compatibility: if older records have backfill_cursor > 0 but no sub_policy, treat as paged.
    """
    if not isinstance(filters, dict):
        return str(default or "new_only")
    p = str(filters.get("sub_policy") or "").strip().lower()
    if p in ("new", "new_only", "incremental_new"):
        return "new_only"
    if p in ("paged", "page", "pagination"):
        return "paged"
    try:
        if int(filters.get("backfill_cursor") or 0) > 0:
            return "paged"
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"回填游标检查失败（已忽略） - value={filters.get('backfill_cursor') if isinstance(filters, dict) else None}, 原因={type(e).__name__}")
    return str(default or "new_only")


def needs_subject_meta(rules: Dict[str, Any]) -> bool:
    """Whether auto-rules require Douban subject metadata."""
    if not rules:
        return False
    if rules.get("media"):
        return True
    if rules.get("year_min") is not None or rules.get("year_max") is not None:
        return True
    if rules.get("tag_black") or rules.get("tag_white"):
        return True
    return False


def should_auto_create_meta(meta: Dict[str, Any], *, rules: Dict[str, Any]) -> bool:
    """Apply metadata-based gates for auto-create.

    meta keys expected:
      - year: int|None
      - media_type_hint: str
      - tags: list[str]
    """
    if not rules:
        return True

    # strict_meta: previous versions were conservative (missing year/tags/media => block).
    # Keep default=True for compatibility; allow user to relax it.
    strict_meta = rules.get("strict_meta")
    strict = True if strict_meta is None else _bool(strict_meta, True)

    # media gate
    want_media = str(rules.get("media") or "").strip().lower()
    if want_media in ("movie", "tv"):
        got = str((meta or {}).get("media_type_hint") or "").strip().lower()
        # If user configured a media gate but we couldn't infer media type:
        # - strict => block
        # - non-strict => allow
        if got not in ("movie", "tv"):
            return (not strict)
        if got != want_media:
            return False

    # year gate
    y = (meta or {}).get("year")
    try:
        y_i = int(y) if y is not None else None
    except (ValueError, TypeError) as e:
        logger.detail(f"年份解析失败（视为无年份） - value={y}, 原因={type(e).__name__}")
        y_i = None
    y_min = rules.get("year_min")
    y_max = rules.get("year_max")
    try:
        y_min_i = int(y_min) if y_min is not None else None
    except (ValueError, TypeError) as e:
        logger.detail(f"最小年份解析失败（视为无限制） - value={y_min}, 原因={type(e).__name__}")
        y_min_i = None
    try:
        y_max_i = int(y_max) if y_max is not None else None
    except (ValueError, TypeError) as e:
        logger.detail(f"最大年份解析失败（视为无限制） - value={y_max}, 原因={type(e).__name__}")
        y_max_i = None
    # If user configured year gate but we couldn't parse year:
    # - strict => block
    # - non-strict => allow
    if (y_min_i is not None or y_max_i is not None) and y_i is None:
        return (not strict)
    if y_i is not None:
        if y_min_i is not None and y_i < y_min_i:
            return False
        if y_max_i is not None and y_i > y_max_i:
            return False

    # tag gate
    tags = [str(x or "").strip().lower() for x in ((meta or {}).get("tags") or []) if str(x or "").strip()]
    # If user configured tag rules but we couldn't parse any tags:
    # - strict => block
    # - non-strict => allow
    if (rules.get("tag_black") or rules.get("tag_white")) and not tags:
        return (not strict)
    tag_white: List[str] = [str(x).strip().lower() for x in (rules.get("tag_white") or []) if str(x).strip()]
    if tag_white:
        # must match at least one
        ok = False
        for kw in tag_white:
            for t in tags:
                if kw in t:
                    ok = True
                    break
            if ok:
                break
        if not ok:
            return False

    tag_black: List[str] = [str(x).strip().lower() for x in (rules.get("tag_black") or []) if str(x).strip()]
    if tag_black:
        for kw in tag_black:
            for t in tags:
                if kw in t:
                    return False

    return True


def should_auto_create_item(it: HotlistItem, *, rules: Dict[str, Any], fallback_top_n: Optional[int] = None) -> bool:
    """Decide whether an item should trigger auto-create.

    Rules are deliberately conservative:
      - kw_white (if provided) is a hard gate
      - kw_black blocks
      - min_rating blocks only when rating is present
      - auto_top_n gates by rank
    """
    if not it or not it.subject_id:
        return False

    title = str(it.title or "").strip()
    t_low = title.lower()

    # TopN gate for auto-create
    auto_top_n = rules.get("auto_top_n")
    try:
        auto_top_n_i = int(auto_top_n) if auto_top_n is not None else None
    except (ValueError, TypeError) as e:
        logger.detail(f"自动 TopN 解析失败（视为无限制） - value={auto_top_n}, 原因={type(e).__name__}")
        auto_top_n_i = None
    if not auto_top_n_i:
        auto_top_n_i = int(fallback_top_n) if fallback_top_n else None
    if auto_top_n_i:
        try:
            r = int(it.rank or 0)
            if r <= 0 or r > int(auto_top_n_i):
                return False
        except (ValueError, TypeError) as e:
            logger.detail(f"排名检查失败（已忽略） - rank={it.rank}, auto_top_n={auto_top_n_i}, 原因={type(e).__name__}")

    kw_white: List[str] = list(rules.get("kw_white") or [])
    if kw_white:
        # must match at least one
        ok = False
        for kw in kw_white:
            if not kw:
                continue
            if str(kw).lower() in t_low:
                ok = True
                break
        if not ok:
            return False

    kw_black: List[str] = list(rules.get("kw_black") or [])
    if kw_black:
        for kw in kw_black:
            if not kw:
                continue
            if str(kw).lower() in t_low:
                return False

    min_rating = rules.get("min_rating")
    try:
        mr = float(min_rating) if min_rating is not None else None
    except (ValueError, TypeError) as e:
        logger.detail(f"最低评分解析失败（视为无限制） - value={min_rating}, 原因={type(e).__name__}")
        mr = None
    if mr is not None:
        # unrated handling
        if it.rating is None:
            if _bool(rules.get("block_unrated"), False):
                return False
        else:
            try:
                if float(it.rating) < float(mr):
                    return False
            except (ValueError, TypeError) as e:
                logger.detail(f"评分比较失败（已忽略） - rating={it.rating}, min_rating={mr}, 原因={type(e).__name__}")

    return True


def format_auto_rules(rules: Dict[str, Any]) -> str:
    """Human-readable one-liner."""
    if not rules:
        return "无"
    parts: List[str] = []
    if rules.get("min_rating") is not None:
        try:
            s = f"评分≥{float(rules.get('min_rating')):.1f}"
            if _bool(rules.get("block_unrated"), False):
                s += "(无分拦截)"
            parts.append(s)
        except (ValueError, TypeError) as e:
            logger.detail(f"评分格式化失败（使用原始值） - value={rules.get('min_rating')}, 原因={type(e).__name__}")
            parts.append(f"评分≥{rules.get('min_rating')}")
    if rules.get("auto_top_n"):
        parts.append(f"AutoTop {int(rules.get('auto_top_n'))}")

    if rules.get("media") in ("movie", "tv"):
        parts.append("仅" + ("电影" if rules.get("media") == "movie" else "剧集"))
    if rules.get("year_min") is not None or rules.get("year_max") is not None:
        y1 = rules.get("year_min")
        y2 = rules.get("year_max")
        if y1 is not None and y2 is not None:
            parts.append(f"年份{int(y1)}-{int(y2)}")
        elif y1 is not None:
            parts.append(f"年份≥{int(y1)}")
        elif y2 is not None:
            parts.append(f"年份≤{int(y2)}")

    kw_w = list(rules.get("kw_white") or [])
    kw_b = list(rules.get("kw_black") or [])
    if kw_w:
        parts.append("白:" + ",".join(kw_w[:5]) + ("…" if len(kw_w) > 5 else ""))
    if kw_b:
        parts.append("黑:" + ",".join(kw_b[:5]) + ("…" if len(kw_b) > 5 else ""))

    tw = list(rules.get("tag_white") or [])
    tb = list(rules.get("tag_black") or [])
    if tw:
        parts.append("类型白:" + ",".join(tw[:5]) + ("…" if len(tw) > 5 else ""))
    if tb:
        parts.append("类型黑:" + ",".join(tb[:5]) + ("…" if len(tb) > 5 else ""))

    # Only show when explicitly relaxed
    sm = rules.get("strict_meta")
    if sm is not None and (not _bool(sm, True)):
        parts.append("缺元数据放行")
    return " · ".join(parts) if parts else "无"
