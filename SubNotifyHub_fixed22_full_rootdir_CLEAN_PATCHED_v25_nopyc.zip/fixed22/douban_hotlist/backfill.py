from __future__ import annotations

import asyncio
import datetime as dt
from datetime import timezone
from core.logging import get_biz_logger
from typing import Any, Dict, List, Optional, Tuple

from settings.runtime import get_settings
from tg_bot.infra.telegram_api import tg_send_message

from .fetcher import fetch_hotlist_api_page, fetch_hotlist_html
from .parser import parse_hotlist_api_items, parse_hotlist_page
from .rules import (
    needs_subject_meta,
    read_auto_rules,
    read_backfill_cursor,
    read_page_size,
    read_sub_policy,
    read_top_n,
    should_auto_create_item,
    should_auto_create_meta,
)
from .store import (
    add_seen_many,
    get_snapshot,
    get_subscription,
    list_ignores,
    patch_subscription_filters,
    update_snapshot_success,
)

from .resolver import resolve_and_subscribe, resolve_subject_meta

biz = get_biz_logger(__name__)


async def _fetch_page(*, list_key: str, list_url: str, start: int, count: int) -> Tuple[str, str, List[Any]]:
    """Fetch one page of items.

    Returns: (list_title, list_url, items)
    """
    st = max(0, int(start or 0))
    ct = max(1, int(count or 20))
    status, data, snip = await fetch_hotlist_api_page(list_key=list_key, start=st, count=ct, list_url=list_url)
    biz.detail(
        "热榜 API 拉取完成",
        list_key=list_key,
        start=st,
        count=ct,
        status=status,
        has_json=bool(data is not None),
    )
    if int(status) >= 200 and int(status) < 300 and data is not None:
        res = parse_hotlist_api_items(list_key=list_key, list_url=list_url, data=data, start=st)
        biz.detail(
            "热榜 API 解析成功",
            list_key=list_key,
            start=st,
            items=len(list(res.items or [])),
            title=str(res.list_title or ""),
        )
        return str(res.list_title or list_key), str(res.list_url or list_url), list(res.items or [])
    # Fallback only for first page
    if st == 0:
        try:
            html = await fetch_hotlist_html(list_url)
            res2 = parse_hotlist_page(list_url, html)
            biz.detail(
                "热榜 HTML 回退解析成功",
                list_key=list_key,
                items=len(list(res2.items or [])),
                title=str(res2.list_title or ""),
            )
            return str(res2.list_title or list_key), str(res2.list_url or list_url), list(res2.items or [])
        except (TypeError, AttributeError, ValueError) as e:
            biz.detail("HTML 回退失败，已忽略", list_key=list_key, error=type(e).__name__)
            pass
    # Fail hard: pagination depends on the API.
    raise RuntimeError(f"fetch_collection_items failed: status={status} snip={snip}")


async def init_baseline_after_subscribe(*, chat_id: int, list_key: str) -> None:
    """Initialize baseline for a new subscription.

    Purpose:
    - Fill the seen-set with current items (so "仅新增" starts from now)
    - Write snapshot (so poller doesn't spam on first run)
    - Does NOT create any tasks.
    """
    biz.step("初始化 baseline", i=1, total=3, chat_id=chat_id, list_key=list_key)
    sub = get_subscription(chat_id=chat_id, list_key=list_key)
    if not sub:
        biz.warning("未找到订阅", chat_id=chat_id, list_key=list_key)
        return

    list_url = str(sub.get("list_url") or "")
    filters = sub.get("filters") if isinstance(sub, dict) else {}
    if not isinstance(filters, dict):
        filters = {}

    page_size = read_page_size(filters)
    pages = 1
    try:
        pages = int(filters.get("baseline_pages") or 1)
        pages = max(1, min(10, pages))
    except (TypeError, ValueError) as e:
        biz.detail("解析 baseline 页数失败，已忽略", error=type(e).__name__)
        pages = 1

    all_ids: List[str] = []
    first_items: List[Any] = []
    list_title = ""
    resolved_url = list_url
    fetched_any = False

    for p in range(pages):
        st = p * page_size
        try:
            title, ru, items = await _fetch_page(list_key=list_key, list_url=list_url, start=st, count=page_size)
            if p == 0:
                fetched_any = True
            if not list_title:
                list_title = title
            resolved_url = ru or resolved_url
            if p == 0:
                first_items = list(items or [])
            for it in items or []:
                sid = str(getattr(it, "subject_id", "") or "").strip()
                if sid:
                    all_ids.append(sid)
        except Exception:
            biz.detail("热榜 baseline 拉取失败", exc_info=True)
            break

    # Insert seen-set and snapshot
    if all_ids:
        add_seen_many(chat_id=chat_id, list_key=list_key, subject_ids=all_ids, source="baseline")

    try:
        # Snapshot: always from first page.
        from .parser import compute_items_hash

        update_snapshot_success(
            list_key=list_key,
            list_title=(list_title or list_key),
            items=first_items,
            items_hash=compute_items_hash(first_items),
        )
    except (TypeError, ValueError, ImportError) as e:
        biz.detail("更新快照失败，已忽略", list_key=list_key, error=type(e).__name__)
        pass

    # Ensure sub_policy default is new_only (purely for UI)
    try:
        pol = read_sub_policy(filters)
        if not pol:
            pol = "new_only"
        patch_subscription_filters(
            chat_id=chat_id,
            list_key=list_key,
            patch={
                "sub_policy": pol,
                "page_size": page_size,
                "baseline_ready": bool(fetched_any),
                "baseline_sync_ts": dt.datetime.now(timezone.utc).timestamp(),
                "baseline_attempts": int(filters.get("baseline_attempts") or 0) + 1 if isinstance(filters, dict) else 1,
            },
        )
    except (TypeError, ValueError, AttributeError) as e:
        biz.detail("更新订阅策略失败，已忽略", chat_id=chat_id, list_key=list_key, error=type(e).__name__)
        pass


async def include_current_once_after_subscribe(*, chat_id: int, list_key: str, limit: int = 10) -> Dict[str, Any]:
    """After subscribing with "包含当前", try creating tasks for the current list items once.

    - Does NOT change sub_policy (still default new_only / 追新)
    - Does NOT advance backfill cursor
    - Obeys global HOTLIST_AUTO_CREATE_SUBS and the subscription's auto rules
    """
    biz.step("首次订阅回填：尝试把当前榜单条目也创建一次订阅任务", i=1, total=2, 事件="include_current_once", chat_id=chat_id, list_key=list_key, limit=limit)
    sub = get_subscription(chat_id=chat_id, list_key=list_key)
    if not sub:
        return {"ok": False, "reason": "SUB_NOT_FOUND"}

    # Per UI requirement: this flow must send *only one* Telegram message.
    # Do NOT send follow-up "成功/失败/统计/MediaHelp结果" messages.

    def _now_dt() -> str:
        try:
            return dt.datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        except (TypeError, ValueError) as e:
            biz.detail("格式化时间失败，已忽略", error=type(e).__name__)
            return ""

    def _mk_a(url: str, text: str) -> str:
        """Build a safe HTML <a> tag (Telegram parse_mode=HTML)."""
        try:
            import html as _html

            u = str(url or "").strip()
            t = str(text or "").strip()
            if not u or not t:
                return _html.escape(t, quote=False)
            return f"<a href=\"{_html.escape(u, quote=True)}\">{_html.escape(t, quote=False)}</a>"
        except (TypeError, ImportError) as e:
            biz.detail("构建 HTML 链接失败，已忽略", error=type(e).__name__)
            return str(text or "")

    def _item_icon(list_title_or_key: str) -> str:
        try:
            s0 = str(list_title_or_key or "")
            if "电影" in s0:
                return "🎞️"
            return "🎬"
        except (TypeError, AttributeError) as e:
            biz.detail("获取图标失败，已忽略", error=type(e).__name__)
            return "🎬"

    def _fmt_rating(v: Any) -> str:
        if v is None:
            return ""
        try:
            return f" ⭐{float(v):.1f}"
        except (TypeError, ValueError) as e:
            biz.detail("格式化评分失败，已忽略", error=type(e).__name__)
            s2 = str(v or "").strip()
            return f" ⭐{s2}" if s2 else ""

    def _build_preview_lines(items2: List[Any], *, max_n: int = 3, icon: str = "🎬") -> List[str]:
        out: List[str] = []
        total = len(items2 or [])
        n = min(max_n, total)
        out.append(f"👀 预览（{n}/{total}）")
        for i, it in enumerate(list(items2 or [])[:n], start=1):
            t = str(getattr(it, "title", "") or "").strip() or f"subject {getattr(it, 'subject_id', '')}"
            u = str(getattr(it, "url", "") or "").strip()
            out.append(f"{i}) {icon} {_mk_a(u, t)}{_fmt_rating(getattr(it, 'rating', None))}")
        if total > n:
            out.append(f"… 其余 {total - n} 条（点下方展开）")
        return out

    s = get_settings()
    if not bool(getattr(s, "HOTLIST_AUTO_CREATE_SUBS", True)):
        # Still keep this flow one-message-only.
        try:
            await tg_send_message(
                chat_id,
                "\n".join(
                    [
                        "🔥📌 热榜订阅已创建",
                        f"【{list_key}】",
                        "",
                        "📥 包含当前：当前环境已关闭自动建任务，未处理当前榜单。",
                        "",
                        f"🕒 {_now_dt()}",
                    ]
                ),
            )
        except (TypeError, ValueError) as e:
            biz.detail("发送消息失败，已忽略", chat_id=chat_id, error=type(e).__name__)
            pass
        return {"ok": False, "reason": "AUTO_CREATE_GLOBAL_OFF"}

    list_url = str(sub.get("list_url") or "")
    filters = sub.get("filters") if isinstance(sub, dict) else {}
    if not isinstance(filters, dict):
        filters = {}

    lim = max(1, min(50, int(limit or 10)))

    # Fetch first page (current top items)
    try:
        list_title, resolved_url, items = await _fetch_page(list_key=list_key, list_url=list_url, start=0, count=max(lim, 10))
    except Exception as e:
        biz.fail("热榜 include_current 拉取失败", list_key=list_key, exc_info=True)
        try:
            await tg_send_message(
                chat_id,
                "\n".join(
                    [
                        "🔥📌 热榜订阅已创建",
                        f"【{list_key}】",
                        "",
                        "📥 包含当前：未能读取当前榜单（可稍后再试）",
                        "",
                        f"🕒 {_now_dt()}",
                    ]
                ),
            )
        except (TypeError, ValueError) as e:
            biz.detail("发送消息失败，已忽略", chat_id=chat_id, error=type(e).__name__)
            pass
        return {"ok": False, "reason": "FETCH_FAILED"}

    items = list(items or [])[:lim]

    # Consistency guardrail:
    # - Message/preview/resolve MUST use this fetch result (items)
    # - Snapshot is only for persistence, and must never feed back into this round's display
    snap_before = get_snapshot(list_key) or {}
    snap_before_n = len(list(snap_before.get("last_items") or []))

    # Best-effort: persist this round as snapshot (non-empty only; empty will keep_last_snapshot)
    try:
        if items:
            from .parser import compute_items_hash

            update_snapshot_success(
                list_key=list_key,
                list_title=(list_title or list_key),
                items=items,
                items_hash=compute_items_hash(items),
            )
    except (TypeError, ValueError, ImportError) as e:
        biz.detail("更新快照失败，已忽略", list_key=list_key, error=type(e).__name__)
        pass

    snap_after = get_snapshot(list_key) or {}
    snap_after_n = len(list(snap_after.get("last_items") or []))
    biz.ok(
        "📥 包含当前：已拉取榜单",
        stage="hotlist_backfill",
        chat_id=chat_id,
        list_key=list_key,
        title=list_title,
        total_items=len(items),
        limit=lim,
    )
    biz.detail(
        "快照一致性检查",
        list_key=list_key,
        fetch_items=len(items),
        snapshot_before=snap_before_n,
        snapshot_after=snap_after_n,
    )
    # Send the *single* receipt message ASAP (no follow-up results).
    try:
        total = len(items)
        title2 = str(list_title or list_key)
        icon = _item_icon(title2)
        # Prefer resolved_url (canonical), fallback to provided list_url.
        hotlist_url2 = str(resolved_url or list_url or "").strip()

        now_str = _now_dt()
        lines: List[str] = []
        lines.append("🔥📌 热榜订阅已创建")
        if hotlist_url2:
            lines.append(_mk_a(hotlist_url2, f"【{title2}】"))
        else:
            lines.append(f"【{title2}】")
        lines.append("")

        if total > 0:
            lines.append(f"📥 包含当前：{total} 条已入队（自动解析 → 自动建订阅）")
            lines.append("")
            lines.extend(_build_preview_lines(items, max_n=3, icon=icon))
        else:
            lines.append("📥 包含当前：当前榜单为空")

        lines.append("")
        lines.append(f"🕒 {now_str}")

        # Add an expand button when there are hidden items.
        reply_markup = None
        hidden = max(0, total - min(3, total))
        if hidden > 0:
            try:
                from tg_bot.storage.tables.callback_tokens import put_payload
                from tg_bot.callbacks.prefixes import CBPrefix

                payload = {
                    "kind": "hotlist_sub_receipt",
                    "chat_id": int(chat_id),
                    "user_id": 0,
                    "list_key": str(list_key),
                    "list_title": title2,
                    "list_url": hotlist_url2,
                    "ts": now_str,
                    "items": [
                        {
                            "title": str(getattr(it, "title", "") or ""),
                            "url": str(getattr(it, "url", "") or ""),
                            "rating": getattr(it, "rating", None),
                        }
                        for it in (items or [])
                    ],
                }
                tok = put_payload(payload, ttl_sec=86400)
                reply_markup = {
                    "inline_keyboard": [
                        [
                            {
                                "text": f"展开其余 {hidden} 条",
                                "callback_data": f"{CBPrefix.HOTLIST}exp:{tok}",
                            }
                        ]
                    ]
                }
            except (TypeError, ValueError, ImportError) as e:
                biz.detail("构建展开按钮失败，已忽略", error=type(e).__name__)
                reply_markup = None

        await tg_send_message(chat_id, "\n".join([x for x in lines if x is not None]), reply_markup=reply_markup)
    except (TypeError, ValueError) as e:
        biz.detail("发送回执消息失败，已忽略", chat_id=chat_id, error=type(e).__name__)
        pass

    if not items:
        return {"ok": True, "reason": "EMPTY"}

    # ✅ include_current 是“用户手动点包含当前”的明确指令：
    # 无论订阅里配置了哪些 auto_rules / top_n，都应该尽最大可能
    # 对本次拉取到的当前榜单条目创建订阅任务（最多 limit 条）。
    #
    # 旧实现会把 filters.top_n / auto_rules.auto_top_n 当作自动建任务门槛，
    # 导致“拉了 10 条但只处理 3 条”的错觉（也会让新建任务通知看起来缺失）。

    # Heuristic media type hint from list title/key (helps TMDB /find ordering).
    _lt = str(list_title or list_key or "")
    prefer_mt = ""
    if any(k in _lt for k in ("剧集", "电视剧", "电视", "动画", "综艺", "剧")):
        prefer_mt = "tv"
    elif any(k in _lt for k in ("电影",)):
        prefer_mt = "movie"

    cand: List[Any] = []
    for it in items:
        sid = str(getattr(it, "subject_id", "") or "").strip()
        if sid:
            cand.append(it)

    # Create tasks
    ok_cnt = 0
    fail_cnt = 0
    # Skipped due to rule filtering (includes meta rules when enabled)
    rule_skipped = max(0, len(items) - len(cand))
    skipped_cnt = 0
    # Track reasons to make the result message human-readable
    from collections import defaultdict
    reason_cnt: Dict[str, int] = defaultdict(int)
    reason_samples: Dict[str, str] = {}

    sem2 = asyncio.Semaphore(int(getattr(s, "HOTLIST_AUTO_CREATE_CONCURRENCY", 4) or 4))

    async def _one(it: Any) -> None:
        nonlocal ok_cnt, fail_cnt, skipped_cnt
        sid = str(getattr(it, "subject_id", "") or "").strip()
        if not sid:
            skipped_cnt += 1
            reason_cnt["no_subject_id"] += 1
            return
        async with sem2:
            try:
                biz.detail(
                    "▶️ 开始解析条目",
                    subject_id=sid,
                    title=str(getattr(it, "title", "") or "")[:80] or None,
                    prefer_media_type=prefer_mt or None,
                )
                ok, reason = await resolve_and_subscribe(
                    sid,
                    title_hint=str(getattr(it, "title", "") or ""),
                    prefer_media_type=prefer_mt,
                    source_tag="🔥 热榜订阅",
                    source_label="榜单",
                    source_value=f"{list_title or list_key}（包含当前）",
                )
                if ok:
                    biz.ok("✅ 条目解析成功", subject_id=sid)
                else:
                    biz.detail("条目解析未成功", subject_id=sid, reason=str(reason or "")[:120] or None)
            except Exception as e:
                biz.fail("热榜 include_current resolve_and_subscribe 崩溃", subject_id=sid, exc_info=True)
                msg = str(getattr(e, "message", "") or str(e) or "").strip()
                if msg:
                    if len(msg) > 120:
                        msg = msg[:120] + "…"
                    ok, reason = (False, f"exception:{msg}")
                else:
                    ok, reason = (False, "exception")
        if ok:
            ok_cnt += 1
        else:
            rs = str(reason or "").strip() or "unknown"
            # Prefer treating un-resolvable items as skipped rather than failed.
            base = rs.split(":", 1)[0]
            if base in ("no_imdb", "no_tmdb", "empty_subject_id"):
                skipped_cnt += 1
                reason_cnt[base] += 1
                if rs and base not in reason_samples:
                    reason_samples[base] = rs
                return
            # Otherwise count as failure.
            fail_cnt += 1
            reason_cnt[base] += 1
            if rs and base not in reason_samples:
                reason_samples[base] = rs

        # 结果已在上面记录

    try:
        res_all = await asyncio.gather(*[_one(x) for x in cand], return_exceptions=True)
        for _r in res_all:
            if isinstance(_r, Exception):
                biz.detail(f"并行任务失败（已忽略）：{type(_r).__name__}", error=str(_r))
        for _r in res_all:
            if isinstance(_r, Exception) and not isinstance(_r, asyncio.CancelledError):
                biz.detail("热榜批量处理出现异常（已忽略）", 原因=type(_r).__name__, exc_info=_r)
    except (RuntimeError, ValueError) as e:
        biz.warning("热榜包含当前批量处理失败", error=type(e).__name__)

    # No more user messages here (avoid follow-up statistics).

    biz.ok(
        "📥 包含当前：处理完成",
        chat_id=chat_id,
        list_key=list_key,
        total=len(items),
        成功=ok_cnt,
        失败=fail_cnt,
        跳过=int(rule_skipped) + int(skipped_cnt),
    )

    return {
        "ok": True,
        "ok_cnt": ok_cnt,
        "fail_cnt": fail_cnt,
        "skipped": int(rule_skipped) + int(skipped_cnt),
        "rule_skipped": int(rule_skipped),
        "total": len(items),
        "reason_cnt": dict(reason_cnt),
    }


async def backfill_next_page(*, chat_id: int, list_key: str, explicit_start: Optional[int] = None) -> Dict[str, Any]:
    """Backfill one page (default 20) and advance cursor.

    - If explicit_start is provided, use it as start (and also set cursor accordingly).
    - Otherwise, use filters.backfill_cursor.

    This creates tasks only when global HOTLIST_AUTO_CREATE_SUBS is ON.
    """
    sub = get_subscription(chat_id=chat_id, list_key=list_key)
    if not sub:
        return {"ok": False, "reason": "SUB_NOT_FOUND"}

    list_url = str(sub.get("list_url") or "")
    filters = sub.get("filters") if isinstance(sub, dict) else {}
    if not isinstance(filters, dict):
        filters = {}

    s = get_settings()
    auto_enabled_global = bool(getattr(s, "HOTLIST_AUTO_CREATE_SUBS", True))

    # Backfill is designed for “订阅/补历史” to create tasks.
    # Per-subscription auto-create switch has been removed; only the global
    # HOTLIST_AUTO_CREATE_SUBS can disable task creation.
    # If global auto-create is off, we should NOT advance cursor nor mark seen,
    # otherwise the user may permanently skip pages without actually creating tasks.
    if not auto_enabled_global:
        try:
            await tg_send_message(
                chat_id,
                "⚠️ 全局已关闭订阅建任务（HOTLIST_AUTO_CREATE_SUBS=false）：\n"
                "补历史不会推进页码，也不会标记已处理。",
            )
        except (TypeError, ValueError) as e:
            biz.detail("发送消息失败，已忽略", chat_id=chat_id, error=type(e).__name__)
            pass
        return {"ok": False, "reason": "AUTO_CREATE_GLOBAL_OFF"}

    page_size = read_page_size(filters)
    start = int(explicit_start) if explicit_start is not None else read_backfill_cursor(filters)
    start = max(0, int(start or 0))

    # Fetch items
    try:
        list_title, resolved_url, items = await _fetch_page(list_key=list_key, list_url=list_url, start=start, count=page_size)
    except Exception as e:
        biz.detail("热榜补历史拉取失败", exc_info=True)
        try:
            await tg_send_message(chat_id, f"⚠️ 补历史失败：{list_key}\n原因：{str(e)[:80]}")
        except (TypeError, ValueError) as e2:
            biz.detail("发送失败消息失败，已忽略", chat_id=chat_id, error=type(e2).__name__)
            pass
        return {"ok": False, "reason": "FETCH_FAILED"}

    if not items:
        try:
            await tg_send_message(chat_id, f"ℹ️ 补历史为空：{list_title or list_key}（start={start}）")
        except (TypeError, ValueError) as e:
            biz.detail("发送空结果消息失败，已忽略", chat_id=chat_id, error=type(e).__name__)
            pass
        return {"ok": True, "empty": True, "start": start, "count": 0}

    # Apply ignore list
    try:
        ignore = set(list_ignores(chat_id=chat_id, list_key=list_key) or [])
    except (TypeError, ValueError) as e:
        biz.detail("读取忽略列表失败，已忽略", chat_id=chat_id, list_key=list_key, error=type(e).__name__)
        ignore = set()

    cand: List[Any] = []
    cand_ids: List[str] = []
    for it in items:
        sid = str(getattr(it, "subject_id", "") or "").strip()
        if not sid:
            continue
        if sid in ignore:
            continue
        cand.append(it)
        cand_ids.append(sid)

    # Mark seen for this page (now only when backfill is actually creating tasks).
    if cand_ids:
        add_seen_many(chat_id=chat_id, list_key=list_key, subject_ids=cand_ids, source="backfill")

    # Auto-create (guaranteed ON here)
    ok = 0
    fail = 0
    skipped = 0
    attempted = 0

    rules = read_auto_rules(filters)
    top_n = read_top_n(filters)
    if top_n and int(top_n) > 0:
        cand2 = [it for it in cand if (getattr(it, "rank", 0) or 0) <= int(top_n)]
    else:
        cand2 = cand

    sem = asyncio.Semaphore(int(getattr(get_settings(), "HOTLIST_BACKFILL_CONCURRENCY", 3) or 3))

    async def _one(it):
        nonlocal ok, fail, skipped, attempted
        sid = str(getattr(it, "subject_id", "") or "").strip()
        if not sid:
            skipped += 1
            return
        if not should_auto_create_item(it, rules=rules, fallback_top_n=top_n):
            skipped += 1
            return
        if needs_subject_meta(rules):
            try:
                meta = await resolve_subject_meta(sid)
            except (TypeError, ValueError) as e:
                biz.detail("解析条目元信息失败，已忽略", subject_id=sid, error=type(e).__name__)
                meta = {}
            if not should_auto_create_meta(meta or {}, rules=rules):
                skipped += 1
                return

        async with sem:
            attempted += 1
            try:
                ok2, _reason = await resolve_and_subscribe(
                    sid,
                    source_tag="🔥 热榜订阅",
                    source_label="榜单",
                    source_value=str(list_title or list_key),
                )
                if ok2:
                    ok += 1
                else:
                    fail += 1
            except (TypeError, ValueError) as e:
                biz.detail("解析并订阅失败，已忽略", subject_id=sid, error=type(e).__name__)
                fail += 1

    await asyncio.gather(*[_one(it) for it in cand2])

    # Advance cursor
    next_cursor = start + page_size
    try:
        # 不改变订阅策略：订阅默认追新；仅推进补历史游标
        patch_subscription_filters(chat_id=chat_id, list_key=list_key, patch={"backfill_cursor": next_cursor, "page_size": page_size})
    except (TypeError, ValueError) as e:
        biz.detail("更新游标失败，已忽略", chat_id=chat_id, list_key=list_key, error=type(e).__name__)
        pass

    # Send summary
    try:
        await tg_send_message(
            chat_id,
            f"📥 补历史完成：{list_title or list_key}\n"
            f"范围：{start+1}-{start+len(items)}（页大小 {page_size}）\n"
            f"自动建任务：成功 {ok} / 失败 {fail} / 跳过 {skipped}\n"
            f"下一页：{next_cursor+1}-{next_cursor+page_size}",
        )
    except (TypeError, ValueError) as e:
        biz.detail("发送汇总消息失败，已忽略", chat_id=chat_id, error=type(e).__name__)
        pass

    return {
        "ok": True,
        "list_key": list_key,
        "list_title": list_title or list_key,
        "start": start,
        "page_size": page_size,
        "fetched": len(items),
        "candidates": len(cand),
        "attempted": attempted,
        "created_ok": ok,
        "created_fail": fail,
        "skipped": skipped,
        "next_cursor": next_cursor,
    }
