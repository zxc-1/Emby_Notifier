"""Built-in Douban hotlists.

These presets are just conveniences for users, so they don't have to search for URLs.
Users can still subscribe ANY subject_collection link by sending the URL.

Ref: Douban mobile subject_collection pages such as:
  - https://m.douban.com/subject_collection/movie_real_time_hotest
  - https://m.douban.com/subject_collection/tv_real_time_hotest
"""

from __future__ import annotations

from typing import Dict, List

from .utils import canonical_list_url


def get_builtin_lists() -> List[Dict[str, str]]:
    # Keep it small and stable.
    # Titles are user-facing and can be adjusted without breaking anything.
    items = [
        {"key": "movie_real_time_hotest", "title": "实时热门电影"},
        {"key": "tv_real_time_hotest", "title": "实时热门电视"},
        {"key": "subject_real_time_hotest", "title": "实时热门书影音"},
        {"key": "movie_weekly_best", "title": "一周口碑电影榜"},
        {"key": "tv_chinese_best_weekly", "title": "一周华语口碑剧集榜"},
        {"key": "tv_global_best_weekly", "title": "一周全球口碑剧集榜"},
        {"key": "show_chinese_best_weekly", "title": "一周国内口碑综艺榜"},
        {"key": "show_global_best_weekly", "title": "一周国外口碑综艺榜"},
        {"key": "movie_top250", "title": "豆瓣电影 Top250"},
        {"key": "book_top250", "title": "豆瓣读书 Top250"},
    ]

    out: List[Dict[str, str]] = []
    for it in items:
        k = str(it.get("key") or "").strip()
        if not k:
            continue
        out.append({"key": k, "title": str(it.get("title") or k), "url": canonical_list_url(k)})
    return out
