from __future__ import annotations

"""Douban hotlist: resolver (use-cases / orchestration).

Parsing & normalization are kept in parser.py (pure functions).
Network IO is kept in fetcher.py.

This module focuses on caching, TMDB resolution strategy and subscription orchestration.
"""

from core.logging import get_biz_logger_adapter
from core.logging import get_biz_logger, is_detail_enabled
import re
from typing import Any, Dict, List, Optional, Tuple

from settings.runtime import get_settings
from ports.stores import get_kv_store, get_kv_store_async

from .fetcher import fetch_subject_html
from .parser import (
    extract_imdb_id_from_html,
    normalize_title_for_tmdb_search,
    parse_subject_meta,
    parse_subject_aka,
    title_consistent,
    extract_season_and_clean_title,
    infer_season_candidate_from_suffix,
)
from .utils import canonical_subject_url

logger = get_biz_logger_adapter(__name__)
biz = get_biz_logger(__name__)


def _uniq(parts: List[str]) -> List[str]:
    out: List[str] = []
    seen: set[str] = set()
    for p in parts or []:
        s = str(p or "").strip()
        if not s:
            continue
        if s in seen:
            continue
        seen.add(s)
        out.append(s)
    return out


def _aka_confirms_season(aka_list: List[str], season: int) -> bool:
    """Return True if aka/aliases explicitly confirm the given season.

    We only accept explicit season markers to avoid false positives
    (e.g., a sequel or '2' in the title).
    """
    if not aka_list or not season or season < 1 or season > 99:
        return False
    s = int(season)

    # Chinese markers
    zh_patterns = [
        rf"第\s*{s}\s*季",
        rf"第\s*{s}\s*部",
    ]
    # Common Chinese numerals up to 20 for better matching like “第二季”
    zh_num = {
        1: "一",
        2: "二",
        3: "三",
        4: "四",
        5: "五",
        6: "六",
        7: "七",
        8: "八",
        9: "九",
        10: "十",
        11: "十一",
        12: "十二",
        13: "十三",
        14: "十四",
        15: "十五",
        16: "十六",
        17: "十七",
        18: "十八",
        19: "十九",
        20: "二十",
    }.get(s)
    if zh_num:
        zh_patterns.append(rf"第\s*{re.escape(zh_num)}\s*季")
        zh_patterns.append(rf"第\s*{re.escape(zh_num)}\s*部")

    # English markers
    en_patterns = [
        rf"\bSeason\s*0*{s}\b",
        rf"\bS\s*0*{s}\b",
    ]

    pats = [re.compile(p, re.IGNORECASE) for p in (zh_patterns + en_patterns)]
    for aka in aka_list:
        t = str(aka or "").strip()
        if not t:
            continue
        for pat in pats:
            if pat.search(t):
                return True
    return False


async def resolve_subject_meta(subject_id: str) -> Dict[str, Any]:
    """Resolve and cache Douban subject metadata.

    Cached in kv_cache: hotlist:meta:<subject_id>
    """
    sid = str(subject_id or "").strip()
    # This function may be called at high volume; keep detailed steps behind BIZ_DETAIL.
    biz.detail_step("解析条目元信息", i=1, total=3, subject_id=sid)
    if not sid:
        return {"imdb_id": "", "year": None, "media_type_hint": "", "tags": []}

    cache_key = f"hotlist:meta:{sid}"
    try:
        v = await get_kv_store_async().get_json(cache_key)
        if isinstance(v, dict) and (v.get("imdb_id") or v.get("year") or v.get("tags") is not None):
            biz.detail("元信息缓存命中", subject_id=sid)
            return v
    except (TypeError, ValueError, KeyError) as e:
        logger.detail(f"读取元信息缓存失败（已忽略） - subject_id={sid}, 原因={type(e).__name__}")
        pass

    try:
        html = await fetch_subject_html(sid)
    except Exception:
        logger.detail("resolve_subject_meta fetch 失败", exc_info=True)
        html = ""

    meta = parse_subject_meta(html or "")
    ttl = 90 * 24 * 3600 if (meta.get("imdb_id") or meta.get("year") or meta.get("tags")) else 24 * 3600
    biz.detail_step("抓取并解析", i=2, total=3, subject_id=sid)
    try:
        await get_kv_store_async().set_json(cache_key, meta, ttl_sec=int(ttl))
    except (TypeError, ValueError) as e:
        logger.detail(f"写入元信息缓存失败（已忽略） - subject_id={sid}, 原因={type(e).__name__}")
        pass
    biz.detail("元信息已解析", subject_id=sid, imdb_id=str(meta.get("imdb_id") or ""), year=meta.get("year"))
    biz.detail_step("写入缓存", i=3, total=3, subject_id=sid)
    return meta


async def resolve_subject_aka(subject_id: str) -> List[str]:
    """Fetch and parse aka/aliases for a subject.

    Only used on-demand (e.g., to verify suffix-inferred seasons) to avoid extra
    requests for every hotlist item.
    """
    sid = str(subject_id or "").strip()
    if not sid:
        return []

    cache_key = f"hotlist:aka:{sid}"
    try:
        v = await get_kv_store_async().get_json(cache_key)
        if isinstance(v, list):
            return [str(x) for x in v if str(x).strip()]
    except (TypeError, ValueError, KeyError):
        pass

    try:
        html = await fetch_subject_html(sid)
    except Exception:
        logger.detail("resolve_subject_aka fetch 失败", exc_info=True)
        html = ""

    aka_list = parse_subject_aka(html or "")
    try:
        await get_kv_store_async().set_json(cache_key, aka_list, ttl_sec=30 * 24 * 3600)
    except (TypeError, ValueError):
        pass
    return aka_list


async def resolve_imdb_id(subject_id: str) -> Optional[str]:
    """Resolve IMDb id from a Douban subject page.

    Cached in kv_cache: hotlist:imdb:<subject_id>
    """
    sid = str(subject_id or "").strip()
    if not sid:
        return None
    # Prefer subject meta cache if available
    try:
        meta = await get_kv_store_async().get_json(f"hotlist:meta:{sid}")
        if isinstance(meta, dict):
            v2 = str(meta.get("imdb_id") or "").strip()
            if v2.startswith("tt"):
                return v2
    except (TypeError, ValueError, KeyError) as e:
        logger.detail(f"读取元信息缓存失败（已忽略） - subject_id={sid}, 原因={type(e).__name__}")
        pass

    cache_key = f"hotlist:imdb:{sid}"
    try:
        v = await get_kv_store_async().get_json(cache_key)
        if isinstance(v, str) and v.startswith("tt"):
            return v
    except (TypeError, ValueError, KeyError) as e:
        logger.detail(f"读取IMDb缓存失败（已忽略） - subject_id={sid}, 原因={type(e).__name__}")
        pass

    try:
        html = await fetch_subject_html(sid)
    except Exception:
        logger.detail("resolve_imdb_id fetch 失败", exc_info=True)
        html = ""

    imdb = None
    if html:
        imdb = extract_imdb_id_from_html(html) or None

    try:
        # Cache (even negative) for a day to avoid hammering douban
        await get_kv_store_async().set_json(cache_key, imdb or "", ttl_sec=24 * 3600)
    except (TypeError, ValueError) as e:
        logger.detail(f"写入IMDb缓存失败（已忽略） - subject_id={sid}, 原因={type(e).__name__}")
        pass
    return imdb


async def resolve_tmdb_by_imdb(imdb_id: str, *, prefer_media_type: str = "") -> Optional[Dict[str, Any]]:
    """Resolve TMDB id and media_type by IMDb id using existing TMDB match API."""
    imdb = str(imdb_id or "").strip()
    biz.detail_step("IMDb→TMDB 外部ID映射", i=1, total=2, imdb_id=imdb, prefer_media_type=prefer_media_type)
    if not imdb:
        return None

    cache_key = f"hotlist:tmdb:imdb:{imdb}"
    try:
        v = await get_kv_store_async().get_json(cache_key)
        if isinstance(v, dict) and v.get("tmdb_id"):
            biz.detail("IMDb→TMDB 缓存命中", imdb_id=imdb)
            return v
    except (TypeError, ValueError, KeyError) as e:
        logger.detail(f"读取TMDB缓存失败（已忽略） - imdb_id={imdb}, 原因={type(e).__name__}")
        pass

    try:
        from integrations.tmdb_match.tmdb_match_api import find_by_external_id

        # external_source can be imdb_id
        cands = await find_by_external_id(imdb, external_source="imdb_id")
        if not cands:
            await get_kv_store_async().set_json(cache_key, {"tmdb_id": 0}, ttl_sec=24 * 3600)
            return None

        c0 = cands[0]

        pref = str(prefer_media_type or "").lower().strip()
        if pref in ("movie", "tv"):
            for c in cands:
                mt = getattr(c, "media_type", None) or getattr(c, "type", None) or ""
                if str(mt).lower() == pref:
                    c0 = c
                    break
        # Candidate is a dataclass-like object; access attributes defensively
        tmdb_id = getattr(c0, "tmdb_id", None) or getattr(c0, "id", None)
        media_type = getattr(c0, "media_type", None) or getattr(c0, "type", None)
        name = getattr(c0, "name", None) or getattr(c0, "title", None)
        year = getattr(c0, "year", None) or getattr(c0, "release_year", None)

        if not tmdb_id:
            await get_kv_store_async().set_json(cache_key, {"tmdb_id": 0}, ttl_sec=24 * 3600)
            return None

        out = {
            "tmdb_id": int(tmdb_id),
            "media_type": str(media_type or ""),
            "name": str(name or ""),
            "year": int(year) if isinstance(year, int) else None,
        }
        await get_kv_store_async().set_json(cache_key, out, ttl_sec=90 * 24 * 3600)
        # This is the meaningful business outcome; always emit.
        biz.ok("IMDb→TMDB 解析成功", imdb_id=imdb, tmdb_id=out.get("tmdb_id"), media_type=out.get("media_type"))
        biz.detail_step("返回结果", i=2, total=2)
        return out
    except Exception:
        # This is a key step for auto-create; don't hide it behind DEBUG.
        logger.fail("IMDb→TMDB 解析异常 - imdb_id=%s", imdb, exc_info=True)
        return None



async def resolve_tmdb_by_title(title: str, *, year: Optional[int] = None, prefer_media_type: str = "") -> Optional[Dict[str, Any]]:
    """Fallback: resolve TMDB candidate by title (+ optional year), then return dict like resolve_tmdb_by_imdb."""
    q = str(title or "").strip()
    if not q:
        return None

    detail = is_detail_enabled()

    pref = str(prefer_media_type or "").lower().strip()
    if pref not in ("movie", "tv"):
        pref = ""

    # Cache per (title, year, pref) to avoid hammering TMDB during include_current/backfill bursts.
    cache_key = f"hotlist:tmdb:title:{q.lower()}:{year or 0}:{pref or 'any'}"
    try:
        v = await get_kv_store_async().get_json(cache_key)
        if isinstance(v, dict) and v.get("tmdb_id"):
            if detail:
                biz.detail("标题→TMDB 缓存命中", query_title=q, year=(int(year) if isinstance(year, int) else None), prefer_media_type=pref or None)
            return v
    except (TypeError, ValueError, KeyError) as e:
        logger.detail(f"读取标题TMDB缓存失败（已忽略） - query={q}, 原因={type(e).__name__}")
        pass

    try:
        from integrations.tmdb_match.tmdb_match_api import search_candidates_multi_via_tmdb
        from integrations.tmdb_match.tmdb_match_core import score_candidate_meta
    except ImportError as e:
        logger.detail(f"导入TMDB模块失败（已忽略） - 原因={type(e).__name__}")
        return None

    # Try multiple query variants (guess mode) to reduce false negatives.
    q_norm = normalize_title_for_tmdb_search(q)
    variants = _uniq([
        q,
        q_norm,
        q.replace(" ", ""),
        q_norm.replace(" ", ""),
    ])
    cands = []
    tried: List[str] = []
    y = (int(year) if isinstance(year, int) else None)
    if detail:
        biz.detail_step("标题→TMDB", i=1, total=3, query_title=q, year=y, prefer_media_type=pref or None)

    for _idx, qq in enumerate(variants, start=1):
        if not qq:
            continue
        tried.append(f"{qq}|y={y or 0}")
        if detail:
            biz.detail_item("尝试查询", i=_idx, total=len(variants), query=qq, year=y or 0)
        try:
            cands = await search_candidates_multi_via_tmdb(qq, year=y, limit=12)
        except Exception:
            logger.fail("标题搜索异常 - query=%s, year=%s", qq, y, exc_info=True)
            cands = []
        if cands:
            break
        # If year was provided, a common failure is mismatched/unknown year; retry without year.
        if y is not None:
            tried.append(f"{qq}|y=0")
            try:
                cands = await search_candidates_multi_via_tmdb(qq, year=None, limit=12)
            except Exception:
                logger.fail("标题搜索异常（无年份） - query=%s", qq, exc_info=True)
                cands = []
            if cands:
                break

    if not cands:
        biz.detail("标题搜索无候选结果", stage="hotlist_resolve", query_title=q, year=y, tried=";".join(tried)[:240])
        if detail:
            biz.warning("标题→TMDB 无候选", query_title=q, year=y, prefer_media_type=pref or None, tried=";".join(tried)[:240])
        try:
            await get_kv_store_async().set_json(cache_key, {"tmdb_id": 0}, ttl_sec=24 * 3600)
        except (TypeError, ValueError) as e:
            logger.detail(f"写入空TMDB缓存失败（已忽略） - query={q}, 原因={type(e).__name__}")
            pass
        return None

    if detail:
        biz.detail_step("候选评分", i=2, total=3, candidates=len(list(cands or [])))

    best = None
    best_score = -1.0
    best_name = ""
    scored_top: List[Tuple[float, Any]] = []
    for c in cands:
        try:
            sc, cov, matched = score_candidate_meta(q, (int(year) if isinstance(year, int) else None), c)
        except (TypeError, ValueError, AttributeError) as e:
            logger.detail(f"评分候选失败（已忽略） - 原因={type(e).__name__}")
            continue
        bonus = 0.06 if (pref and str(getattr(c, "media_type", "")).lower() == pref) else 0.0
        # Mildly favor higher vote_count when scores are close
        try:
            vc = int(getattr(c, "vote_count", 0) or 0)
        except (TypeError, ValueError, AttributeError) as e:
            logger.detail(f"获取投票数失败（已忽略） - 原因={type(e).__name__}")
            vc = 0
        sc2 = float(sc) + float(bonus) + (0.00002 * min(vc, 50000))
        if detail:
            try:
                scored_top.append((float(sc2), c))
            except (ValueError, TypeError) as e:
                logger.detail(f"评分记录失败（已跳过） - 分数={sc2!r}, 原因={type(e).__name__}")
        if sc2 > best_score:
            best_score = sc2
            best = c
            best_name = matched

    if not best:
        return None

    if detail:
        try:
            scored_top.sort(key=lambda x: x[0], reverse=True)
            topk = scored_top[: min(3, len(scored_top))]
            for i2, (sc2, c2) in enumerate(topk, start=1):
                biz.detail_item(
                    "候选",
                    i=i2,
                    total=len(topk),
                    tmdb_id=int(getattr(c2, "tmdb_id", 0) or 0),
                    media_type=str(getattr(c2, "media_type", "") or ""),
                    score=round(float(sc2), 4),
                    name=str(getattr(c2, "title", "") or getattr(c2, "name", "") or "")[:60],
                )
        except Exception:
            logger.detail("hotlist：scored_top log 失败", exc_info=True)

    out = {
        "tmdb_id": int(getattr(best, "tmdb_id", 0) or 0),
        "media_type": str(getattr(best, "media_type", "") or ""),
        "name": str(best_name or getattr(best, "title", "") or ""),
        "year": int(getattr(best, "year", 0)) if isinstance(getattr(best, "year", None), int) else None,
    }
    try:
        await get_kv_store_async().set_json(cache_key, out, ttl_sec=30 * 24 * 3600)
    except (TypeError, ValueError) as e:
        logger.detail(f"写入TMDB缓存失败（已忽略） - query={q}, 原因={type(e).__name__}")
        pass
    if detail:
        biz.ok("标题→TMDB 解析成功", query_title=q, tmdb_id=out.get("tmdb_id"), media_type=out.get("media_type"), score=round(float(best_score), 4))
        biz.detail_step("返回结果", i=3, total=3)
    return out


async def ensure_auto_subscription(
    *,
    tmdb_id: int,
    media_type: str,
    name: str = "",
    year: Optional[int] = None,
    season: Optional[int] = None,
    source_tag: Optional[str] = None,
    source_label: Optional[str] = None,
    source_value: Optional[str] = None,
) -> Tuple[bool, str]:
    """Create a MediaHelp subscription task (best-effort).

    Returns (ok, detail)
    - ok: whether MediaHelp accepted the create request
    - detail: short failure detail (best-effort)
    """
    try:
        from forward_bridge.subscription_api import ensure_mediahelp_subscription

        # MediaHelp expects media_type movie/tv, or None.
        mt = str(media_type or "").lower().strip()
        if mt not in ("movie", "tv"):
            mt = ""
        se = int(season) if isinstance(season, int) and season > 0 else None

        biz.detail(
            "▶️ 发起 MediaHelp 订阅请求",
            stage="douban_mediahelp_subscribe",
            tmdb_id=int(tmdb_id),
            media_type=(mt if mt else None),
            name=str(name or "")[:60] or None,
            year=(int(year) if isinstance(year, int) else None),
            season=se,
        )

        ok, detail = await ensure_mediahelp_subscription(
            tmdbid=int(tmdb_id),
            type=(mt if mt else None),
            name=(str(name or "") or None),
            year=(int(year) if isinstance(year, int) else None),
            season=se,
            source_tag=source_tag,
            source_label=source_label,
            source_value=source_value,
        )
        d = str(detail or "").strip()
        if len(d) > 120:
            d = d[:120] + "…"
        return bool(ok), d
    except Exception as e:
        biz.fail("❌ 创建 MediaHelp 订阅失败", tmdb_id=tmdb_id, media_type=media_type, error=str(e)[:120])
        msg = str(getattr(e, "message", "") or str(e) or "").strip()
        if msg:
            if len(msg) > 120:
                msg = msg[:120] + "…"
            return False, f"exception:{msg}"
        return False, "exception"


async def resolve_and_subscribe(
    subject_id: str,
    *,
    title_hint: Optional[str] = None,
    prefer_media_type: Optional[str] = None,
    source_tag: Optional[str] = None,
    source_label: Optional[str] = None,
    source_value: Optional[str] = None,
) -> Tuple[bool, str]:
    """Resolve a Douban subject to TMDB and create MediaHelp subscription.

    Returns (ok, reason)
    """
    sid = str(subject_id or "").strip()
    if not sid:
        return False, "empty_subject_id"

    detail = is_detail_enabled()

    # Parse season from display title (e.g. "第X季").
    clean_title, season_hint = extract_season_and_clean_title(str(title_hint or ""))
    if season_hint:
        # If a season is explicit, it's almost certainly a TV show.
        if not str(prefer_media_type or "").strip():
            prefer_media_type = "tv"

    biz.detail(
        "▶️ 开始解析豆瓣条目",
        stage="douban_resolve",
        subject_id=sid,
        title_hint=str(title_hint or "")[:80] or None,
        prefer_media_type=str(prefer_media_type or "")[:12] or None,
        source_tag=str(source_tag or "")[:40] or None,
    )

    if clean_title or season_hint:
        biz.detail(
            "标题规范化处理",
            subject_id=sid,
            原始标题=str(title_hint or "")[:60] or None,
            清理后标题=str(clean_title or "")[:60] or None,
            季度提示=int(season_hint) if isinstance(season_hint, int) else None,
        )

    if detail:
        biz.detail_step(
            "解析元信息",
            i=1,
            total=4,
            subject_id=sid,
            title_hint=(str(title_hint or "")[:80] if title_hint else None),
            season_hint=(int(season_hint) if isinstance(season_hint, int) else None),
        )

    # Always fetch Douban meta
    try:
        meta = await resolve_subject_meta(sid)
    except (TypeError, ValueError) as e:
        logger.detail(f"解析条目元信息失败（已忽略） - subject_id={sid}, 原因={type(e).__name__}")
        meta = {}

    biz.detail(
        "豆瓣元信息已获取",
        subject_id=sid,
        imdb_id=str(meta.get("imdb_id") or "") or None,
        year=meta.get("year"),
        media_type_hint=str(meta.get("media_type_hint") or "") or None,
    )

    # Prefer media type:
    # 1) caller hint (from list context)
    # 2) douban meta hint (og:type)
    pref = str(prefer_media_type or meta.get("media_type_hint") or "").lower().strip()
    if pref not in ("movie", "tv"):
        pref = ""

    # --- Two-phase season inference (TV hotlist only) -----------------------
    # A) infer season_candidate from suffix (e.g. "御赐小仵作2" / "...Ⅱ")
    # B) confirm via Douban subject "又名/别名" (aka) to avoid false positives
    if pref == "tv" and not season_hint:
        raw = str(title_hint or "").strip()
        base_title, season_candidate, reason = infer_season_candidate_from_suffix(raw)
        if season_candidate:
            biz.detail(
                "🎬 识别季号候选",
                subject_id=sid,
                原始标题=raw[:80] or None,
                基础名=str(base_title or "")[:80] or None,
                推断季=int(season_candidate),
                推断依据=reason,
            )

            aka_list = await resolve_subject_aka(sid)
            if _aka_confirms_season(aka_list, int(season_candidate)):
                season_hint = int(season_candidate)
                clean_title = base_title or clean_title
                biz.ok(
                    "🔎 证实季号：Douban 又名命中",
                    subject_id=sid,
                    确认为=f"S{season_hint}",
                    又名示例=(aka_list[0][:80] if aka_list else None),
                )
            else:
                biz.warning(
                    "⚠️ 降级：季号未证实，按全季处理",
                    subject_id=sid,
                    推断季=int(season_candidate),
                    推断依据=reason,
                    又名条目数=len(aka_list),
                )

    imdb = str(meta.get("imdb_id") or "").strip() or (await resolve_imdb_id(sid))
    if imdb:
        biz.detail("已获取 IMDb ID", subject_id=sid, imdb_id=imdb)

    tm: Optional[Dict[str, Any]] = None
    imdb_suspect = False
    if imdb:
        if detail:
            biz.detail_step("IMDb→TMDB 外部ID映射", i=2, total=4, imdb_id=imdb, prefer_media_type=pref or None)
        tm = await resolve_tmdb_by_imdb(imdb, prefer_media_type=pref)
        if tm and tm.get("tmdb_id"):
            biz.ok(
                "✅ IMDb→TMDB 匹配成功",
                subject_id=sid,
                imdb_id=imdb,
                tmdb_id=tm.get("tmdb_id"),
                media_type=tm.get("media_type"),
                name=str(tm.get("name") or "")[:60] or None,
            )
        else:
            biz.detail("IMDb→TMDB 无匹配", subject_id=sid, imdb_id=imdb)

        # Guardrail: if imdb-mapping yields a title that looks unrelated to the expected title,
        # treat imdb as suspect and retry via title-search.
        try:
            exp = str(clean_title or title_hint or "").strip()
            got = str((tm or {}).get("name") or "").strip()
            if tm and exp and got and not title_consistent(exp, got):
                imdb_suspect = True
                biz.warning(
                    "⚠️ IMDb 匹配标题不一致，将改用标题搜索",
                    subject_id=sid,
                    imdb_id=imdb,
                    期望标题=exp[:60],
                    实际标题=got[:60],
                )
                tm = None
        except (TypeError, AttributeError) as e:
            logger.detail(f"标题一致性检查失败（已忽略） - 原因={type(e).__name__}")
            pass

    # Fallback: some Douban subjects don't have IMDb id; try TMDB title search.
    year_hint = meta.get("year") if isinstance(meta.get("year"), int) else None
    if not tm:
        t_hint = str(clean_title or title_hint or "").strip()
        if t_hint:
            if detail:
                biz.detail_step("标题→TMDB", i=3, total=4, query_title=t_hint[:80], year=year_hint, prefer_media_type=pref or None)
            tm = await resolve_tmdb_by_title(t_hint, year=year_hint, prefer_media_type=pref)
            if tm and tm.get("tmdb_id"):
                biz.ok(
                    "✅ 标题→TMDB 匹配成功",
                    subject_id=sid,
                    query_title=t_hint[:60],
                    year=year_hint,
                    tmdb_id=tm.get("tmdb_id"),
                    media_type=tm.get("media_type"),
                    name=str(tm.get("name") or "")[:60] or None,
                )
            else:
                biz.detail("标题→TMDB 无匹配", subject_id=sid, query_title=t_hint[:60], year=year_hint)

    # If season is explicit and list prefers TV, but imdb-path gave a movie, re-try via title for TV.
    if tm and season_hint and pref == "tv" and str(tm.get("media_type") or "").lower() == "movie":
        biz.warning(
            "⚠️ 期望剧集但匹配到电影，将改用标题搜索剧集",
            subject_id=sid,
            season=int(season_hint) if isinstance(season_hint, int) else None,
        )
        t_hint2 = str(clean_title or title_hint or "").strip()
        tm2 = await resolve_tmdb_by_title(t_hint2, year=year_hint, prefer_media_type="tv") if t_hint2 else None
        if tm2 and tm2.get("tmdb_id"):
            tm = tm2

    if not tm:
        if not imdb:
            biz.warning("⚠️ 解析失败：无 IMDb 且标题搜索无结果", subject_id=sid)
            return False, "no_imdb_no_title_match"
        biz.warning("⚠️ 解析失败：无法匹配 TMDB", subject_id=sid, imdb_id=imdb)
        return False, "no_tmdb"

    tmdb_id = int(tm.get("tmdb_id") or 0)
    if tmdb_id <= 0:
        biz.warning("⚠️ 解析失败：TMDB ID 无效", subject_id=sid, imdb_id=imdb or None)
        return False, "no_tmdb"

    if detail:
        biz.detail_step("创建订阅", i=4, total=4, tmdb_id=tmdb_id, media_type=str(tm.get("media_type") or "") or pref)
    sub_ok, sub_detail = await ensure_auto_subscription(
        tmdb_id=tmdb_id,
        media_type=(str(tm.get("media_type") or "") or pref),
        name=str(tm.get("name") or ""),
        year=(year_hint if isinstance(year_hint, int) else (tm.get("year") if isinstance(tm.get("year"), int) else None)),
        season=(int(season_hint) if isinstance(season_hint, int) and season_hint > 0 else None),
        source_tag=source_tag,
        source_label=source_label,
        source_value=source_value,
    )
    if sub_ok:
        biz.ok(
            "✅ 热榜订阅创建成功",
            subject_id=sid,
            tmdb_id=tmdb_id,
            media_type=str(tm.get("media_type") or "") or pref,
            name=str(tm.get("name") or "")[:60] or None,
        )
        return True, "ok"
    biz.warning(
        "⚠️ 热榜订阅创建失败",
        subject_id=sid,
        tmdb_id=tmdb_id,
        detail=str(sub_detail or "")[:120] or None,
    )
    return False, f"mediahelp_failed:{sub_detail}"