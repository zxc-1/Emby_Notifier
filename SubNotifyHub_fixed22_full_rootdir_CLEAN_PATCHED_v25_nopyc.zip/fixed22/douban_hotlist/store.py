from __future__ import annotations

import json
import time
from typing import Any, Dict, Iterable, Optional, Set

from core.logging import get_biz_logger
from tg_bot.storage import db as _db
from tg_bot.storage.schema import init_db

from .models import HotlistItem
from .utils import canonical_list_url, normalize_mode

biz = get_biz_logger(__name__)

# Best-effort GC timestamps (module-level, not persisted)
_LAST_IGNORE_GC_TS: float = 0.0
_LAST_SEEN_GC_TS: float = 0.0


def _now() -> float:
    return float(time.time())


def upsert_subscription(
    *,
    chat_id: int,
    list_key: str,
    list_url: Optional[str] = None,
    mode: str = "incremental",
    filters: Optional[Dict[str, Any]] = None,
) -> None:
    """Insert/update subscription.

    NOTE: `filters=None` means **preserve existing filters** (so UI toggles aren't wiped when switching mode).
    Use `filters={}` to explicitly clear filters.
    """
    init_db()
    lk = str(list_key or "").strip()
    if not lk:
        return
    lu = str(list_url or "") or canonical_list_url(lk)
    m = normalize_mode(mode)

    # Preserve filters unless explicitly overridden.
    eff_filters: Dict[str, Any]
    if filters is None:
        try:
            row = _db._with_retry(
                lambda c: c.execute(
                    "SELECT filters_json FROM douban_hotlist_subscription WHERE chat_id=? AND list_key=? LIMIT 1",
                    (int(chat_id), lk),
                ).fetchone(),
                retries=2,
            )
            if row and row[0]:
                eff_filters = json.loads(row[0]) if isinstance(row[0], str) else {}
                if not isinstance(eff_filters, dict):
                    eff_filters = {}
            else:
                eff_filters = {}
        except (ValueError, TypeError, json.JSONDecodeError, AttributeError) as e:
            biz.detail("过滤器读取失败，使用空字典", chat_id=chat_id, list_key=lk, error=type(e).__name__)
            eff_filters = {}
    else:
        eff_filters = dict(filters or {})

    fj = json.dumps(eff_filters, ensure_ascii=False, separators=(",", ":"))
    ts = _now()

    def _w(c):
        c.execute(
            """
            INSERT INTO douban_hotlist_subscription(chat_id, list_key, list_url, mode, filters_json, created_ts, updated_ts)
            VALUES(?,?,?,?,?,?,?)
            ON CONFLICT(chat_id, list_key) DO UPDATE SET
                list_url=excluded.list_url,
                mode=excluded.mode,
                filters_json=excluded.filters_json,
                updated_ts=excluded.updated_ts
            """,
            (int(chat_id), lk, lu, m, fj, ts, ts),
        )

    _db._with_retry(_w, retries=2)


def patch_subscription_filters(*, chat_id: int, list_key: str, patch: Dict[str, Any]) -> None:
    """Merge a patch dict into existing filters_json."""
    init_db()
    lk = str(list_key or "").strip()
    if not lk:
        return

    def _rw(c):
        row = c.execute(
            "SELECT filters_json FROM douban_hotlist_subscription WHERE chat_id=? AND list_key=? LIMIT 1",
            (int(chat_id), lk),
        ).fetchone()
        cur: Dict[str, Any] = {}
        try:
            if row and row[0]:
                cur = json.loads(row[0] or "{}")
            if not isinstance(cur, dict):
                cur = {}
        except (ValueError, TypeError, json.JSONDecodeError) as e:
            biz.detail("当前过滤器解析失败，使用空字典", chat_id=chat_id, list_key=lk, error=type(e).__name__)
            cur = {}

        for k, v in (patch or {}).items():
            # allow deleting a key with None
            if v is None:
                cur.pop(str(k), None)
            else:
                cur[str(k)] = v

        fj = json.dumps(cur, ensure_ascii=False, separators=(",", ":"))
        ts = _now()
        c.execute(
            "UPDATE douban_hotlist_subscription SET filters_json=?, updated_ts=? WHERE chat_id=? AND list_key=?",
            (fj, ts, int(chat_id), lk),
        )

    _db._with_retry(_rw, retries=2)


def add_ignore(*, chat_id: int, list_key: str, subject_id: str) -> None:
    init_db()
    lk = str(list_key or "").strip()
    sid = str(subject_id or "").strip()
    if not lk or not sid:
        return
    ts = _now()

    def _w(c):
        c.execute(
            "INSERT OR IGNORE INTO douban_hotlist_ignore(chat_id, list_key, subject_id, created_ts) VALUES(?,?,?,?)",
            (int(chat_id), lk, sid, ts),
        )

        # Best-effort cleanup to prevent unbounded growth.
        try:
            from settings.runtime import get_settings

            s = get_settings()

            # 1) Global TTL GC (rate-limited)
            global _LAST_IGNORE_GC_TS
            gc_interval = float(getattr(s, "HOTLIST_IGNORE_GC_INTERVAL_SEC", 3600) or 3600)
            ttl_days = int(getattr(s, "HOTLIST_IGNORE_TTL_DAYS", 180) or 180)
            if ttl_days > 0 and (ts - _LAST_IGNORE_GC_TS) >= max(30.0, gc_interval):
                cutoff = ts - float(ttl_days * 24 * 3600)
                c.execute(
                    "DELETE FROM douban_hotlist_ignore WHERE created_ts IS NOT NULL AND created_ts < ?",
                    (cutoff,),
                )
                _LAST_IGNORE_GC_TS = ts

            # 2) Per-subscription cap (always enforced preserves recent ignores)
            max_per = int(getattr(s, "HOTLIST_IGNORE_MAX_PER_SUB", 5000) or 5000)
            if max_per > 0:
                c.execute(
                    """
                    DELETE FROM douban_hotlist_ignore
                    WHERE rowid IN (
                        SELECT rowid
                        FROM douban_hotlist_ignore
                        WHERE chat_id=? AND list_key=?
                        ORDER BY COALESCE(created_ts, 0) DESC
                        LIMIT -1 OFFSET ?
                    )
                    """,
                    (int(chat_id), lk, max_per),
                )
        except (ValueError, TypeError, AttributeError) as e:
            biz.detail("忽略列表清理失败，已忽略", chat_id=chat_id, list_key=lk, error=type(e).__name__)
            pass

    _db._with_retry(_w, retries=2)

def remove_ignore(*, chat_id: int, list_key: str, subject_id: str) -> None:
    init_db()
    lk = str(list_key or "").strip()
    sid = str(subject_id or "").strip()
    if not lk or not sid:
        return

    def _w(c):
        c.execute("DELETE FROM douban_hotlist_ignore WHERE chat_id=? AND list_key=? AND subject_id=?", (int(chat_id), lk, sid))

    _db._with_retry(_w, retries=2)


def clear_ignores(*, chat_id: int, list_key: str) -> None:
    """Remove all ignored subject_ids for a subscription."""
    init_db()
    lk = str(list_key or "").strip()
    if not lk:
        return

    def _w(c):
        c.execute("DELETE FROM douban_hotlist_ignore WHERE chat_id=? AND list_key=?", (int(chat_id), lk))

    _db._with_retry(_w, retries=2)


def list_ignores(*, chat_id: int, list_key: str, limit: int = 200) -> list[str]:
    init_db()
    lk = str(list_key or "").strip()
    if not lk:
        return []

    def _r(c):
        return c.execute(
            "SELECT subject_id FROM douban_hotlist_ignore WHERE chat_id=? AND list_key=? ORDER BY created_ts DESC LIMIT ?",
            (int(chat_id), lk, int(limit or 200)),
        ).fetchall()

    rows = _db._with_retry(_r, retries=2) or []
    return [str(r[0]) for r in rows if r and r[0]]


def get_ignore_set(*, chat_id: int, list_key: str) -> Set[str]:
    try:
        return set(list_ignores(chat_id=chat_id, list_key=list_key, limit=5000))
    except (ValueError, TypeError, AttributeError) as e:
        biz.detail("忽略集合获取失败，返回空集合", chat_id=chat_id, list_key=list_key, error=type(e).__name__)
        return set()


def count_ignores(*, chat_id: int, list_key: str) -> int:
    init_db()
    lk = str(list_key or "").strip()
    if not lk:
        return 0

    def _r(c):
        row = c.execute(
            "SELECT COUNT(1) FROM douban_hotlist_ignore WHERE chat_id=? AND list_key=?",
            (int(chat_id), lk),
        ).fetchone()
        return int(row[0] or 0) if row else 0

    try:
        return int(_db._with_retry(_r, retries=2) or 0)
    except (ValueError, TypeError) as e:
        biz.detail("忽略数量统计失败，返回 0", chat_id=chat_id, list_key=lk, error=type(e).__name__)
        return 0




def count_ignores_bulk(*, pairs: list[tuple[int, str]]) -> Dict[str, int]:
    """Bulk ignore counts.

    Returns mapping key "<chat_id>::<list_key>" -> count.

    Note: we restrict the scan using chat_id IN (...) and list_key IN (...)
    to avoid a full-table GROUP BY on large ignore tables.
    """
    init_db()
    if not pairs:
        return {}

    wanted = {(int(cid), str(lk or '').strip()) for cid, lk in pairs if int(cid or 0) and str(lk or '').strip()}
    if not wanted:
        return {}

    cids = sorted({cid for cid, _ in wanted})
    lks = sorted({lk for _, lk in wanted})

    out: Dict[str, int] = {f"{cid}::{lk}": 0 for (cid, lk) in wanted}

    # SQLite parameter limit safety
    CID_CHUNK = 200
    LK_CHUNK = 50

    def _chunked(seq, n):
        for i in range(0, len(seq), n):
            yield seq[i:i+n]

    for cpart in _chunked(cids, CID_CHUNK):
        cqs = ','.join(['?'] * len(cpart))
        for lpart in _chunked(lks, LK_CHUNK):
            lqs = ','.join(['?'] * len(lpart))

            def _r(c):
                return c.execute(
                    f"""
                    SELECT chat_id, list_key, COUNT(1)
                    FROM douban_hotlist_ignore
                    WHERE chat_id IN ({cqs}) AND list_key IN ({lqs})
                    GROUP BY chat_id, list_key
                    """,
                    [*cpart, *lpart],
                ).fetchall()

            rows = _db._with_retry(_r, retries=2) or []
            for row in rows:
                try:
                    cid = int(row[0] or 0)
                    lk = str(row[1] or '').strip()
                    if (cid, lk) in wanted:
                        out[f"{cid}::{lk}"] = int(row[2] or 0)
                except (ValueError, TypeError, IndexError) as e:
                    biz.detail("批量忽略数量解析失败，已跳过", row=str(row), error=type(e).__name__)
                    continue

    return out




def get_ignore_sets_bulk(*, list_key: str, chat_ids: Iterable[int]) -> Dict[int, Set[str]]:
    """Fetch ignore sets for multiple subscribers in one query (best-effort)."""
    init_db()
    lk = str(list_key or '').strip()
    cids = [int(x) for x in (chat_ids or []) if int(x or 0)]
    if not lk or not cids:
        return {}

    out: Dict[int, Set[str]] = {cid: set() for cid in cids}

    # SQLite parameter limit safety
    CHUNK = 200

    def _chunked(seq, n):
        for i in range(0, len(seq), n):
            yield seq[i:i+n]

    for part in _chunked(cids, CHUNK):
        qs = ','.join(['?'] * len(part))
        def _r(c):
            return c.execute(
                f"SELECT chat_id, subject_id FROM douban_hotlist_ignore WHERE list_key=? AND chat_id IN ({qs})",
                [lk, *part],
            ).fetchall()
        rows = _db._with_retry(_r, retries=2) or []
        for row in rows:
            try:
                cid = int(row[0] or 0)
                sid = str(row[1] or '').strip()
                if cid and sid:
                    out.setdefault(cid, set()).add(sid)
            except (ValueError, TypeError, IndexError) as e:
                biz.detail("批量忽略集合解析失败，已跳过", row=str(row), error=type(e).__name__)
                pass

    return out


def get_seen_in_bulk(*, list_key: str, chat_ids: Iterable[int], subject_ids: Iterable[str]) -> Dict[int, Set[str]]:
    """Return seen subsets for multiple subscribers.

    This executes a batched query: (list_key AND chat_id IN (...) AND subject_id IN (...)).
    """
    init_db()
    lk = str(list_key or '').strip()
    cids = [int(x) for x in (chat_ids or []) if int(x or 0)]
    sids = [str(x).strip() for x in (subject_ids or []) if str(x).strip()]
    if not lk or not cids or not sids:
        return {cid: set() for cid in cids}

    out: Dict[int, Set[str]] = {cid: set() for cid in cids}

    # SQLite parameter limit safety
    CID_CHUNK = 100
    SID_CHUNK = 300

    def _chunked(seq, n):
        for i in range(0, len(seq), n):
            yield seq[i:i+n]

    for cpart in _chunked(cids, CID_CHUNK):
        cqs = ','.join(['?'] * len(cpart))
        for spart in _chunked(sids, SID_CHUNK):
            sqs = ','.join(['?'] * len(spart))
            def _r(c):
                return c.execute(
                    f"""
                    SELECT chat_id, subject_id
                    FROM douban_hotlist_seen
                    WHERE list_key=? AND chat_id IN ({cqs}) AND subject_id IN ({sqs})
                    """,
                    [lk, *cpart, *spart],
                ).fetchall()
            rows = _db._with_retry(_r, retries=2) or []
            for row in rows:
                try:
                    cid = int(row[0] or 0)
                    sid = str(row[1] or '').strip()
                    if cid and sid:
                        out.setdefault(cid, set()).add(sid)
                except (ValueError, TypeError, IndexError) as e:
                    biz.detail("批量已见集合解析失败，已跳过", row=str(row), error=type(e).__name__)
                    pass

    return out
def get_seen_in(*, chat_id: int, list_key: str, subject_ids: Iterable[str]) -> Set[str]:
    """Return the subset of subject_ids that are already seen for this subscriber."""
    init_db()
    lk = str(list_key or "").strip()
    if not lk:
        return set()
    ids = [str(x).strip() for x in (subject_ids or []) if str(x).strip()]
    if not ids:
        return set()

    # SQLite has a variable limit; keep it safe.
    out: Set[str] = set()

    def _chunk(lst: list[str], n: int = 400) -> Iterable[list[str]]:
        for i in range(0, len(lst), n):
            yield lst[i : i + n]

    def _r(c, chunk_ids: list[str]):
        qs = ",".join(["?"] * len(chunk_ids))
        sql = f"SELECT subject_id FROM douban_hotlist_seen WHERE chat_id=? AND list_key=? AND subject_id IN ({qs})"
        return c.execute(sql, [int(chat_id), lk, *chunk_ids]).fetchall()

    try:
        for ch in _chunk(ids):
            rows = _db._with_retry(lambda c: _r(c, ch), retries=2) or []
            for r in rows:
                if r and r[0]:
                    out.add(str(r[0]))
    except (ValueError, TypeError, AttributeError) as e:
        biz.detail("已见集合查询失败，返回空集合", chat_id=chat_id, list_key=lk, error=type(e).__name__)
        return set()

    return out


def add_seen_many(*, chat_id: int, list_key: str, subject_ids: Iterable[str], source: str = "") -> int:
    """Insert subject_ids into seen set (idempotent). Returns inserted count (best-effort)."""
    init_db()
    lk = str(list_key or "").strip()
    if not lk:
        return 0
    ids = [str(x).strip() for x in (subject_ids or []) if str(x).strip()]
    if not ids:
        return 0
    ts = _now()
    src = str(source or "")[:32]

    def _w(c):
        # Bulk insert
        c.executemany(
            "INSERT OR IGNORE INTO douban_hotlist_seen(chat_id, list_key, subject_id, first_seen_ts, source) VALUES(?,?,?,?,?)",
            [(int(chat_id), lk, sid, ts, src) for sid in ids],
        )

        # Best-effort cleanup to prevent unbounded growth.
        try:
            from settings.runtime import get_settings

            s = get_settings()

            # 1) Global TTL GC (rate-limited)
            global _LAST_SEEN_GC_TS
            gc_interval = float(getattr(s, "HOTLIST_SEEN_GC_INTERVAL_SEC", 3600) or 3600)
            ttl_days = int(getattr(s, "HOTLIST_SEEN_TTL_DAYS", getattr(s, "HOTLIST_DEDUP_TTL_DAYS", 60)) or 60)
            if ttl_days > 0 and (ts - _LAST_SEEN_GC_TS) >= max(30.0, gc_interval):
                cutoff = ts - float(ttl_days * 24 * 3600)
                c.execute(
                    "DELETE FROM douban_hotlist_seen WHERE first_seen_ts IS NOT NULL AND first_seen_ts < ?",
                    (cutoff,),
                )
                _LAST_SEEN_GC_TS = ts

            # 2) Per-subscription cap
            max_per = int(getattr(s, "HOTLIST_SEEN_MAX_PER_SUB", 20000) or 20000)
            if max_per > 0:
                c.execute(
                    """
                    DELETE FROM douban_hotlist_seen
                    WHERE rowid IN (
                        SELECT rowid
                        FROM douban_hotlist_seen
                        WHERE chat_id=? AND list_key=?
                        ORDER BY COALESCE(first_seen_ts, 0) DESC
                        LIMIT -1 OFFSET ?
                    )
                    """,
                    (int(chat_id), lk, max_per),
                )
        except (ValueError, TypeError, AttributeError) as e:
            biz.detail("已见记录清理失败，已忽略", chat_id=chat_id, list_key=lk, error=type(e).__name__)
            pass

        try:
            return int(c.total_changes or 0)
        except (ValueError, TypeError, AttributeError) as e:
            biz.detail("变更计数获取失败，返回 0", error=type(e).__name__)
            return 0

    try:
        return int(_db._with_retry(_w, retries=2) or 0)
    except (ValueError, TypeError) as e:
        biz.detail("已见记录添加失败，返回 0", chat_id=chat_id, list_key=lk, error=type(e).__name__)
        return 0



def get_auto_state_bulk(*, list_key: str, subject_ids: Iterable[str]) -> Dict[str, Dict[str, Any]]:
    """Bulk read auto-create attempt state.

    Returns mapping key "<subject_id>::<prefer_media_type>" -> {
        'last_try_ts': float|None,
        'attempt_count': int,
        'last_ok': bool,
        'last_reason': str,
        'next_retry_ts': float|None,
    }

    This state is global per (list_key, subject_id, prefer_media_type) and is used
    to enable retry for transient failures without spamming.
    """
    init_db()
    lk = str(list_key or "").strip()
    if not lk:
        return {}
    ids = [str(x).strip() for x in (subject_ids or []) if str(x).strip()]
    if not ids:
        return {}

    out: Dict[str, Dict[str, Any]] = {}

    def _chunk(lst: list[str], n: int = 400):
        for i in range(0, len(lst), n):
            yield lst[i : i + n]

    def _r(c, chunk_ids: list[str]):
        qs = ",".join(["?"] * len(chunk_ids))
        sql = f"""
        SELECT subject_id, prefer_media_type, last_try_ts, attempt_count, last_ok, last_reason, next_retry_ts
        FROM douban_hotlist_auto_state_v2
        WHERE list_key=? AND subject_id IN ({qs})
        """
        return c.execute(sql, [lk, *chunk_ids]).fetchall()

    try:
        for ch in _chunk(ids):
            rows = _db._with_retry(lambda c: _r(c, ch), retries=2) or []
            for row in rows:
                try:
                    sid = str(row[0] or "").strip()
                    if not sid:
                        continue
                    pref = str(row[1] or "").strip().lower()
                    k = f"{sid}::{pref}"
                    out[k] = {
                        "last_try_ts": float(row[2]) if row[2] is not None else None,
                        "attempt_count": int(row[3] or 0),
                        "last_ok": bool(int(row[4] or 0)),
                        "last_reason": str(row[5] or "").strip(),
                        "next_retry_ts": float(row[6]) if row[6] is not None else None,
                    }
                except Exception as e:
                    biz.detail("auto_state 解析失败，已跳过", row=str(row), error=type(e).__name__)
                    continue
    except Exception as e:
        biz.detail("auto_state 批量读取失败", list_key=lk, error=type(e).__name__)
        return {}

    return out


def upsert_auto_state(
    *,
    list_key: str,
    subject_id: str,
    prefer_media_type: str = "",
    ok: bool,
    reason: str = "",
) -> None:
    """Upsert auto-create attempt state for (list_key, subject_id, prefer_media_type).

    Stores next_retry_ts so poll loop can decide retry with a single timestamp comparison.
    """
    init_db()
    lk = str(list_key or "").strip()
    sid = str(subject_id or "").strip()
    pref = str(prefer_media_type or "").strip().lower()
    if not lk or not sid:
        return

    ts = _now()
    rs = str(reason or "")[:200]
    ok_i = 1 if ok else 0

    def _compute_next_retry_ts(*, attempt_count: int) -> Optional[float]:
        if ok:
            return None
        try:
            from settings.runtime import get_settings

            s = get_settings()
            # Retry policy mirrors poller._should_retry_auto
            rlow = str(rs or "").lower()
            if rlow.startswith('exception') or rlow.startswith('mediahelp_failed:exception') or rlow.startswith('mediahelp_failed:timeout'):
                base = float(getattr(s, 'HOTLIST_AUTO_RETRY_BASE_SEC', 1800) or 1800)
            elif rlow in ('no_tmdb', 'no_imdb_no_title_match'):
                base = float(getattr(s, 'HOTLIST_AUTO_RETRY_BASE_NO_MATCH_SEC', 21600) or 21600)
            else:
                base = float(getattr(s, 'HOTLIST_AUTO_RETRY_BASE_OTHER_SEC', 7200) or 7200)
            cap = float(getattr(s, 'HOTLIST_AUTO_RETRY_CAP_SEC', 604800) or 604800)
            mult = 2 ** max(0, min(6, int(attempt_count) - 1))
            wait = min(cap, base * mult)
            return float(ts + wait)
        except Exception as e:
            biz.detail("ignored exception in _compute_next_retry_ts", exc_info=True)
            return None

    def _w(c):
        row = c.execute(
            "SELECT attempt_count FROM douban_hotlist_auto_state_v2 WHERE list_key=? AND subject_id=? AND prefer_media_type=? LIMIT 1",
            (lk, sid, pref),
        ).fetchone()
        cur_n = int(row[0] or 0) if row else 0
        n2 = cur_n + 1
        next_retry_ts = _compute_next_retry_ts(attempt_count=n2)
        c.execute(
            """
            INSERT INTO douban_hotlist_auto_state_v2(
                list_key, subject_id, prefer_media_type, last_try_ts, attempt_count, last_ok, last_reason, next_retry_ts
            )
            VALUES(?,?,?,?,?,?,?,?)
            ON CONFLICT(list_key, subject_id, prefer_media_type) DO UPDATE SET
                last_try_ts=excluded.last_try_ts,
                attempt_count=excluded.attempt_count,
                last_ok=excluded.last_ok,
                last_reason=excluded.last_reason,
                next_retry_ts=excluded.next_retry_ts
            """,
            (lk, sid, pref, ts, n2, ok_i, rs, next_retry_ts),
        )

    try:
        _db._with_retry(_w, retries=2)
    except Exception as e:
        biz.detail("auto_state 写入失败，已忽略", list_key=lk, subject_id=sid, error=type(e).__name__)
        return


def seen_any(*, chat_id: int, list_key: str) -> bool:
    """Whether this subscription has any seen rows (fast existence check)."""
    init_db()
    lk = str(list_key or "").strip()
    if not lk:
        return False

    def _r(c):
        row = c.execute(
            "SELECT 1 FROM douban_hotlist_seen WHERE chat_id=? AND list_key=? LIMIT 1",
            (int(chat_id), lk),
        ).fetchone()
        return bool(row)

    try:
        return bool(_db._with_retry(_r, retries=1))
    except (ValueError, TypeError) as e:
        biz.detail("已见检查失败，返回 False", chat_id=chat_id, list_key=lk, error=type(e).__name__)
        return False

def delete_subscription(*, chat_id: int, list_key: str, cleanup: bool = True) -> None:
    """Delete a subscription.

    If cleanup is True (default), also delete related ignore/seen rows.
    If after deletion the list_key has no subscribers, its snapshot is removed too.
    """
    init_db()
    lk = str(list_key or "").strip()
    if not lk:
        return

    def _w(c):
        if cleanup:
            c.execute("DELETE FROM douban_hotlist_ignore WHERE chat_id=? AND list_key=?", (int(chat_id), lk))
            c.execute("DELETE FROM douban_hotlist_seen WHERE chat_id=? AND list_key=?", (int(chat_id), lk))
        c.execute("DELETE FROM douban_hotlist_subscription WHERE chat_id=? AND list_key=?", (int(chat_id), lk))

        # If no subscribers remain for this list_key, remove snapshot to avoid stale UI.
        try:
            row = c.execute(
                "SELECT COUNT(1) FROM douban_hotlist_subscription WHERE list_key=? LIMIT 1",
                (lk,),
            ).fetchone()
            if (not row) or int(row[0] or 0) <= 0:
                c.execute("DELETE FROM douban_hotlist_snapshot WHERE list_key=?", (lk,))
        except (ValueError, TypeError, IndexError) as e:
            biz.detail("快照清理失败，已忽略", list_key=lk, error=type(e).__name__)
            pass

    _db._with_retry(_w, retries=2)


def get_subscription(*, chat_id: int, list_key: str) -> Optional[Dict[str, Any]]:
    init_db()
    lk = str(list_key or "").strip()
    if not lk:
        return None

    def _r(c):
        return c.execute(
            """
            SELECT chat_id, list_key, list_url, mode, filters_json, created_ts, updated_ts
            FROM douban_hotlist_subscription WHERE chat_id=? AND list_key=? LIMIT 1
            """,
            (int(chat_id), lk),
        ).fetchone()

    row = _db._with_retry(_r, retries=2)
    if not row:
        return None

    try:
        filters = json.loads(row[4] or "{}")
        if not isinstance(filters, dict):
            filters = {}
    except (ValueError, TypeError, json.JSONDecodeError) as e:
        biz.detail("订阅过滤器解析失败，使用空字典", chat_id=chat_id, list_key=lk, error=type(e).__name__)
        filters = {}

    return {
        "chat_id": int(row[0] or 0),
        "list_key": row[1],
        "list_url": row[2],
        "mode": row[3] or "incremental",
        "filters": filters,
        "created_ts": float(row[5] or 0),
        "updated_ts": float(row[6] or 0),
    }


def list_subscriptions(*, chat_id: Optional[int] = None) -> list[Dict[str, Any]]:
    init_db()

    def _r(c):
        if chat_id is None:
            return c.execute(
                """
                SELECT chat_id, list_key, list_url, mode, filters_json, created_ts, updated_ts
                FROM douban_hotlist_subscription
                ORDER BY updated_ts DESC
                """
            ).fetchall()
        return c.execute(
            """
            SELECT chat_id, list_key, list_url, mode, filters_json, created_ts, updated_ts
            FROM douban_hotlist_subscription WHERE chat_id=?
            ORDER BY updated_ts DESC
            """,
            (int(chat_id),),
        ).fetchall()

    rows = _db._with_retry(_r, retries=2) or []
    out: list[Dict[str, Any]] = []
    for row in rows:
        try:
            filters = json.loads(row[4] or "{}")
            if not isinstance(filters, dict):
                filters = {}
        except (ValueError, TypeError, json.JSONDecodeError) as e:
            biz.detail("订阅列表过滤器解析失败，使用空字典", error=type(e).__name__)
            filters = {}
        out.append(
            {
                "chat_id": int(row[0] or 0),
                "list_key": row[1],
                "list_url": row[2],
                "mode": row[3] or "incremental",
                "filters": filters,
                "created_ts": float(row[5] or 0),
                "updated_ts": float(row[6] or 0),
            }
        )
    return out


def list_distinct_list_keys() -> list[str]:
    init_db()

    def _r(c):
        return c.execute(
            """
            SELECT DISTINCT list_key FROM douban_hotlist_subscription
            ORDER BY list_key ASC
            """
        ).fetchall()

    rows = _db._with_retry(_r, retries=2) or []
    return [str(r[0]) for r in rows if r and r[0]]


def list_subscribers(list_key: str) -> list[Dict[str, Any]]:
    init_db()
    lk = str(list_key or "").strip()
    if not lk:
        return []

    def _r(c):
        return c.execute(
            """
            SELECT chat_id, list_key, list_url, mode, filters_json
            FROM douban_hotlist_subscription WHERE list_key=?
            """,
            (lk,),
        ).fetchall()

    rows = _db._with_retry(_r, retries=2) or []
    out: list[Dict[str, Any]] = []
    for row in rows:
        try:
            filters = json.loads(row[4] or "{}")
            if not isinstance(filters, dict):
                filters = {}
        except (ValueError, TypeError, json.JSONDecodeError) as e:
            biz.detail("订阅者过滤器解析失败，使用空字典", list_key=lk, error=type(e).__name__)
            filters = {}
        out.append(
            {
                "chat_id": int(row[0] or 0),
                "list_key": str(row[1] or ""),
                "list_url": str(row[2] or ""),
                "mode": str(row[3] or "incremental"),
                "filters": filters,
            }
        )
    return out


def get_snapshot(list_key: str) -> Optional[Dict[str, Any]]:
    init_db()
    lk = str(list_key or "").strip()
    if not lk:
        return None

    def _r(c):
        return c.execute(
            """
            SELECT list_key, list_title, last_success_ts, last_items_json, last_hash, last_error_ts, last_error_reason, last_error_detail
            FROM douban_hotlist_snapshot WHERE list_key=? LIMIT 1
            """,
            (lk,),
        ).fetchone()

    row = _db._with_retry(_r, retries=2)
    if not row:
        return None

    try:
        items = json.loads(row[3] or "[]")
        if not isinstance(items, list):
            items = []
    except (ValueError, TypeError, json.JSONDecodeError) as e:
        biz.detail("快照项目解析失败，使用空列表", list_key=lk, error=type(e).__name__)
        items = []

    return {
        "list_key": str(row[0] or ""),
        "list_title": str(row[1] or ""),
        "last_success_ts": float(row[2] or 0.0),
        "last_items": items,
        "last_hash": str(row[4] or ""),
        "last_error_ts": float(row[5] or 0.0),
        "last_error_reason": str(row[6] or ""),
        "last_error_detail": str(row[7] or ""),
    }




def update_snapshot_success(*, list_key: str, list_title: str, items: Iterable[HotlistItem], items_hash: str) -> None:
    """Update snapshot on successful fetch.

    NOTE:
    - We **allow empty items** to overwrite snapshot, so UI can reflect a real empty list (or a parser change).
    - Parser/HTTP errors should be recorded via update_snapshot_error.
    """
    init_db()
    lk = str(list_key or "").strip()
    if not lk:
        return
    ts = _now()
    it_list = [it.to_dict() for it in list(items or [])]
    if not it_list:
        biz.warning("热榜快照将被空列表覆盖", stage="hotlist_snapshot", list_key=lk, reason="empty_overwrite")
    it_json = json.dumps(it_list, ensure_ascii=False, separators=(",", ":"))

    def _w(c):
        c.execute(
            """
            INSERT INTO douban_hotlist_snapshot(list_key, list_title, last_success_ts, last_items_json, last_hash, last_error_ts, last_error_reason, last_error_detail)
            VALUES(?,?,?,?,?,?,?,?)
            ON CONFLICT(list_key) DO UPDATE SET
                list_title=excluded.list_title,
                last_success_ts=excluded.last_success_ts,
                last_items_json=excluded.last_items_json,
                last_hash=excluded.last_hash,
                last_error_ts=NULL,
                last_error_reason='',
                last_error_detail=''
            """,
            (lk, str(list_title or ""), ts, it_json, str(items_hash or ""), None, "", ""),
        )

    _db._with_retry(_w, retries=2)


def update_snapshot_error(*, list_key: str, reason: str, detail: str = "") -> None:
    init_db()
    lk = str(list_key or "").strip()
    if not lk:
        return
    ts = _now()

    def _w(c):
        c.execute(
            """
            INSERT INTO douban_hotlist_snapshot(list_key, list_title, last_success_ts, last_items_json, last_hash, last_error_ts, last_error_reason, last_error_detail)
            VALUES(?,?,?,?,?,?,?,?)
            ON CONFLICT(list_key) DO UPDATE SET
                last_error_ts=excluded.last_error_ts,
                last_error_reason=excluded.last_error_reason,
                last_error_detail=excluded.last_error_detail
            """,
            (lk, "", 0.0, "[]", "", ts, str(reason or ""), str(detail or "")),
        )

    _db._with_retry(_w, retries=2)
