from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional


@dataclass
class HotlistItem:
    subject_id: str
    title: str
    url: str
    rating: Optional[float] = None
    cover: Optional[str] = None
    rank: Optional[int] = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "subject_id": self.subject_id,
            "title": self.title,
            "url": self.url,
            "rating": self.rating,
            "cover": self.cover,
            "rank": self.rank,
        }


@dataclass
class HotlistResult:
    list_key: str
    list_url: str
    list_title: str
    items: list[HotlistItem]

