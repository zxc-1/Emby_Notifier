"""Douban hotlist subscription subsystem.

Runtime entry: douban_hotlist.runtime.run_hotlist_daemon
"""

from .runtime import run_hotlist_daemon

__all__ = ["run_hotlist_daemon"]
