from __future__ import annotations

import logging
from core.logging import get_biz_logger_adapter
logger = get_biz_logger_adapter(__name__)

import re
from typing import Optional


_SUBJECT_COLLECTION_RE = re.compile(r"(?i)/subject_collection/([0-9A-Za-z_-]+)")


def extract_list_key(url: str) -> str:
    """Extract douban subject_collection/<type> key from a share URL."""
    u = str(url or "").strip()
    if not u:
        return ""
    m = _SUBJECT_COLLECTION_RE.search(u)
    if not m:
        return ""
    return str(m.group(1) or "").strip()


def canonical_list_url(list_key: str) -> str:
    k = str(list_key or "").strip()
    if not k:
        return ""
    return f"https://m.douban.com/subject_collection/{k}/"


def canonical_subject_url(subject_id: str) -> str:
    sid = str(subject_id or "").strip()
    if not sid:
        return ""
    # Use desktop movie subject page; it contains IMDb links reliably.
    return f"https://movie.douban.com/subject/{sid}/"


def extract_subject_id(url: str) -> str:
    u = str(url or "")
    m = re.search(r"/subject/(\d{4,12})(?:/|$|\?|#)", u)
    return str(m.group(1)) if m else ""


def normalize_mode(mode: str, *, default: str = "incremental") -> str:
    m = str(mode or "").strip().lower()
    if m in ("incremental", "digest"):
        return m
    return str(default or "incremental")


def safe_int(v: object, *, default: int = 0) -> int:
    try:
        i = int(v)  # type: ignore
        return i
    except (ValueError, TypeError) as e:
        logger.detail(f"整数转换失败，使用默认值 - 输入值={v!r}, 默认值={default}, 原因={type(e).__name__}")
        return int(default)


def safe_float(v: object) -> Optional[float]:
    try:
        if v is None:
            return None
        s = str(v).strip()
        if not s:
            return None
        return float(s)
    except (ValueError, TypeError) as e:
        logger.detail(f"浮点数转换失败 - 输入值={v!r}, 原因={type(e).__name__}")
        return None

