from __future__ import annotations

"""Douban hotlist: fetcher (network IO).

This module centralizes all outbound HTTP fetches used by douban_hotlist.
Parsing/cleaning should live in parser.py (pure functions).
"""

from typing import Any, List, Tuple

from .client import fetch_collection_items as _fetch_collection_items
from .client import fetch_text as _fetch_text
from .utils import canonical_subject_url


async def fetch_hotlist_html(list_url: str) -> str:
    """Fetch hotlist page HTML (subject_collection page)."""
    return await _fetch_text(str(list_url or ""))


async def fetch_hotlist_api_page(*, list_key: str, start: int, count: int, list_url: str) -> Tuple[int, Any, str]:
    """Fetch one hotlist API page via Douban internal API."""
    st = max(0, int(start or 0))
    ct = max(1, int(count or 20))
    return await _fetch_collection_items(list_key=list_key, start=st, count=ct, list_url=list_url)


async def fetch_subject_html(subject_id: str) -> str:
    """Fetch a Douban subject page HTML by subject_id."""
    url = canonical_subject_url(str(subject_id or "").strip())
    return await _fetch_text(url)


__all__ = [
    "fetch_hotlist_html",
    "fetch_hotlist_api_page",
    "fetch_subject_html",
]
