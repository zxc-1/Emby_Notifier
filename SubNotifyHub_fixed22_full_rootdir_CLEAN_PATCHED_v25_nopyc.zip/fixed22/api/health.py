from __future__ import annotations

from core.logging import get_biz_logger_adapter, get_trace_id
from collections import deque
from datetime import datetime, timezone
from typing import Any, Dict, Optional

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse

from api.responses import success_response
from core.context import AppContext
from ports.settings_provider import get_settings
from notifier.worker import NotificationWorker
from core.metrics import metrics
from forward_bridge.config import get_forward_bridge_enabled

logger = get_biz_logger_adapter(__name__)

router = APIRouter()


@router.get("/health")
async def health(request: Request) -> JSONResponse:
    """Basic health and counters."""
    logger.detail("收到健康检查请求")
    s = get_settings()
    worker: Optional[NotificationWorker] = getattr(request.app.state, "notifier_worker", None)
    ctx: Optional[AppContext] = getattr(request.app.state, "ctx", None)

    now_ts = datetime.now(timezone.utc).timestamp()
    cutoff = now_ts - 600

    def _count_recent(dq: deque) -> int:
        try:
            while dq and float(dq[0]) < cutoff:
                dq.popleft()
            return len(dq)
        except (ValueError, TypeError, IndexError) as e:
            logger.detail(f"最近计数统计失败 - 原因={type(e).__name__}")
            return 0

    notify_dq = getattr(ctx, "recent_notify_times", None) if ctx is not None else getattr(request.app.state, "_recent_notify_times", deque(maxlen=2000))
    attempt_dq = getattr(ctx, "recent_notify_attempt_times", None) if ctx is not None else getattr(request.app.state, "_recent_notify_attempt_times", deque(maxlen=2000))
    webhook_dq = getattr(ctx, "recent_webhook_times", None) if ctx is not None else getattr(request.app.state, "_recent_webhook_times", deque(maxlen=2000))

    recent_notify_10m = _count_recent(notify_dq or deque(maxlen=2000))
    recent_attempt_10m = _count_recent(attempt_dq or deque(maxlen=2000))
    recent_webhook_10m = _count_recent(webhook_dq or deque(maxlen=2000))

    return success_response(data={
        "status": "ok",
        "version": s.APP_VERSION,
        "worker": {
            "running": bool(worker and worker.running_workers > 0),
            "queue_size": worker.queue_size if worker else 0,
            "max_queue_size": worker.max_queue_size if worker else s.NOTIFIER_MAX_QUEUE_SIZE,
            "concurrency": s.NOTIFIER_WORKER_CONCURRENCY,
            "recent_10m": recent_notify_10m,
            "sent_10m": recent_notify_10m,
            "attempt_10m": recent_attempt_10m,
            "recent_attempt_10m": recent_attempt_10m,
            "recent_notify_10m": recent_notify_10m,
            "recent_webhook_10m": recent_webhook_10m,
        },
        "webhook": {"recent_10m": recent_webhook_10m},
        "forward": {"enabled": bool(get_forward_bridge_enabled())},
        "telegram": {"dry_run": s.NOTIFIER_DRY_RUN},
        "admin": {"credentials_ready": bool(getattr(request.app.state, "admin_credentials_ready", True))},
        "preflight": getattr(request.app.state, "preflight", None),
        "warnings": list(getattr(request.app.state, "health_warnings", []) or []),
        "metrics": metrics.snapshot(),
    })
