from __future__ import annotations

from typing import Optional

from fastapi import Request

from api.responses import ErrorCodes
from application.errors import TemporaryError
from core.exceptions.base import AppException
from core.logging import get_biz_logger_adapter
from core.context import AppContext
from notifier.worker import NotificationWorker

logger = get_biz_logger_adapter(__name__)

def get_ctx(request: Request) -> AppContext:
    """Get AppContext for the current request.

    Preferred source: ``request.app.state.ctx`` (bound during startup).
    Fallback: ``ports.app_context`` (for non-request/background contexts).
    """
    ctx = getattr(request.app.state, "ctx", None)
    if ctx is not None:
        return ctx

    try:
        from ports.app_context import get_ctx_optional

        ctx2 = get_ctx_optional()
        if ctx2 is not None:
            return ctx2  # type: ignore[return-value]
    except (ImportError, AttributeError, RuntimeError) as e:
        logger.detail(f"应用上下文备用获取失败（已忽略） - 原因={type(e).__name__}")

    raise TemporaryError(
        "Application context not ready",
        error_code=ErrorCodes.CONTEXT_NOT_READY,
        status_code=503,
    )


def get_worker(request: Request) -> Optional[NotificationWorker]:
    """Compatibility helper to fetch worker."""
    try:
        ctx = get_ctx(request)
        return getattr(ctx, "notifier_worker", None)
    except (AttributeError, AppException) as e:
        logger.detail(f"通知工作器获取失败（已忽略） - 原因={type(e).__name__}")
        return getattr(request.app.state, "notifier_worker", None)
