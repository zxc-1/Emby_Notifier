from __future__ import annotations

import asyncio
import os
import json
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse

from api.responses import success_response, ErrorCodes
from application.errors import AppError
from core.exceptions.base import ValidationError as AppValidationError
from core.logging import get_biz_logger_adapter
from core.runtime_env import get_env_path
from ports.settings_provider import get_settings
from notifier.services import process_emby_item

biz = get_biz_logger_adapter(__name__)
logger = get_biz_logger_adapter(__name__)

router = APIRouter(prefix="/debug")


def _ensure_debug_enabled() -> None:
    if not get_settings().DEBUG_ENABLE_DEBUG_API:
        raise AppError(
            "Debug API not enabled",
            error_code=ErrorCodes.DISABLED,
            status_code=404,
        )


@router.post("/render", response_class=JSONResponse)
async def debug_render(request: Request) -> JSONResponse:
    _ensure_debug_enabled()

    try:
        payload = await request.json()
    except Exception:
        raise AppValidationError(
            "Invalid JSON body",
            error_code=ErrorCodes.INVALID_JSON,
            status_code=400,
        )

    content = await process_emby_item(payload)
    if not content:
        return success_response(data={"rendered": False, "content": None})

    # Debug API should never 500 due to field drift.
    # Prefer pydantic's dump if available.
    try:
        dumped = content.model_dump()  # type: ignore[attr-defined]
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"model_dump 失败（使用手动字段提取） - 原因={type(e).__name__}")
        dumped = {
            "text": getattr(content, "text", None),
            "cover_url": getattr(content, "cover_url", None),
            "fanart_path": getattr(content, "fanart_path", None),
            "poster_path": getattr(content, "poster_path", None),
            "fanart_url": getattr(content, "fanart_url", None),
            "poster_url": getattr(content, "poster_url", None),
            "web_cover_url": getattr(content, "web_cover_url", None),
            "is_adult": getattr(content, "is_adult", None),
            "media_type": getattr(content, "media_type", None),
            "series_name": getattr(content, "series_name", None),
            "episode_name": getattr(content, "episode_name", None),
            "season_number": getattr(content, "season_number", None),
            "episode_number": getattr(content, "episode_number", None),
            "library_name": getattr(content, "library_name", None),
            "display_title": getattr(content, "display_title", None),
            "display_meta_line": getattr(content, "display_meta_line", None),
            "detail_url": getattr(content, "detail_url", None),
        }

    return success_response(data={"rendered": True, "content": dumped})


@router.get("/last-notifications", response_class=JSONResponse)
async def debug_last_notifications(request: Request, limit: int = 20) -> JSONResponse:
    _ensure_debug_enabled()

    # Prefer centralized ctx, fall back to legacy app.state
    try:
        from api.deps import get_ctx

        ctx = get_ctx(request)
        history = getattr(ctx, "notification_history", None)
    except (ValueError, TypeError, AttributeError, ImportError) as e:
        logger.detail(f"上下文获取失败（使用 app.state） - 原因={type(e).__name__}")
        history = getattr(request.app.state, "notification_history", None)
    if history is None:
        return success_response(data={"items": []})

    try:
        limit_val = int(limit)
    except (ValueError, TypeError) as e:
        logger.detail(f"limit 转换失败（使用默认值 20） - limit={limit}, 原因={type(e).__name__}")
        limit_val = 20

    limit_val = max(1, min(limit_val, 100))

    items = list(history)[-limit_val:]
    result = []
    for c in items:
        try:
            result.append(c.model_dump())  # type: ignore[attr-defined]
        except (ValueError, TypeError, AttributeError) as e:
            logger.detail(f"通知项 model_dump 失败（使用手动字段提取） - 原因={type(e).__name__}")
            result.append(
                {
                    "text": getattr(c, "text", None),
                    "cover_url": getattr(c, "cover_url", None),
                    "fanart_path": getattr(c, "fanart_path", None),
                    "poster_path": getattr(c, "poster_path", None),
                    "fanart_url": getattr(c, "fanart_url", None),
                    "poster_url": getattr(c, "poster_url", None),
                    "web_cover_url": getattr(c, "web_cover_url", None),
                    "is_adult": getattr(c, "is_adult", None),
                    "media_type": getattr(c, "media_type", None),
                    "series_name": getattr(c, "series_name", None),
                    "episode_name": getattr(c, "episode_name", None),
                    "season_number": getattr(c, "season_number", None),
                    "episode_number": getattr(c, "episode_number", None),
                    "library_name": getattr(c, "library_name", None),
                    "display_title": getattr(c, "display_title", None),
                    "display_meta_line": getattr(c, "display_meta_line", None),
                    "detail_url": getattr(c, "detail_url", None),
                }
            )

    return success_response(data={"items": result})


@router.get("/plugins", response_class=JSONResponse)
async def debug_plugins(request: Request) -> JSONResponse:
    """Show loaded plugins and what they contributed.

    This endpoint is intentionally behind DEBUG_ENABLE_DEBUG_API.
    """
    _ensure_debug_enabled()

    reg = getattr(request.app.state, "plugin_registry", None)
    loaded = list(getattr(request.app.state, "loaded_plugins", []) or [])

    infos: Dict[str, Any] = {}
    try:
        for mod, pi in getattr(reg, "plugin_infos", {}).items():
            try:
                infos[str(mod)] = pi.__dict__
            except (ValueError, TypeError, AttributeError) as e:
                logger.detail(f"插件信息字典转换失败（使用手动字段提取） - mod={mod}, 原因={type(e).__name__}")
                infos[str(mod)] = {
                    "module": getattr(pi, "module", str(mod)),
                    "api_version": getattr(pi, "api_version", None),
                    "name": getattr(pi, "name", None),
                    "version": getattr(pi, "version", None),
                    "description": getattr(pi, "description", None),
                    "homepage": getattr(pi, "homepage", None),
                    "author": getattr(pi, "author", None),
                    "dependencies": getattr(pi, "dependencies", None),
                }
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"插件信息遍历失败（使用空字典） - 原因={type(e).__name__}")
        infos = {}

    summary = {
        "loaded": loaded,
        "count": len(loaded),
        "registry": {
            "routers": len(getattr(reg, "routers", []) or []) if reg is not None else 0,
            "startup_hooks": len(getattr(reg, "startup_hooks", []) or []) if reg is not None else 0,
            "shutdown_hooks": len(getattr(reg, "shutdown_hooks", []) or []) if reg is not None else 0,
            "has_data": bool(getattr(reg, "data", None)) if reg is not None else False,
        },
    }

    return success_response(data={"summary": summary, "infos": infos})


def _is_sensitive_key(key: str) -> bool:
    k = (key or "").upper()
    return any(
        x in k
        for x in (
            "TOKEN",
            "SECRET",
            "PASSWORD",
            "PASSWD",
            "API_KEY",
            "ACCESS_KEY",
            "PRIVATE_KEY",
            "COOKIE",
            "SESSION",
            "AUTH",
        )
    )


def _mask_value(key: str, value: Any) -> Any:
    if value is None:
        return None
    if not _is_sensitive_key(key):
        return value
    # Keep shape without leaking secrets
    try:
        s = str(value)
    except (ValueError, TypeError) as e:
        logger.detail(f"值转字符串失败（返回 redacted） - value类型={type(value).__name__}, 原因={type(e).__name__}")
        return "<redacted>"
    if not s:
        return ""
    if len(s) <= 8:
        return "<redacted>"
    return f"<redacted:{len(s)}:{s[:2]}…{s[-2:]}>"


def _load_dotenv_sources() -> Tuple[Dict[str, str], str]:
    """Return (.env dict, env_path).

    Scheme A:
      ENV > .env (optional) > DEFAULT
    """
    from core.storage import load_env_file

    env_path = str(get_env_path())
    base = load_env_file(Path(env_path)) or {}
    return base, env_path

@router.get("/config", response_class=JSONResponse)
async def debug_config() -> JSONResponse:
    """Dump effective settings with redaction + origin (ENV/DOTENV/DEFAULT)."""
    s = get_settings()
    _ensure_debug_enabled()

    base, env_path = _load_dotenv_sources()

    try:
        data = s.model_dump()
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"设置 model_dump 失败（使用手动字段提取） - 原因={type(e).__name__}")
        data = {k: getattr(s, k) for k in dir(s) if k.isupper() and not k.startswith("_")}

    origins: Dict[str, str] = {}
    masked: Dict[str, Any] = {}
    
    for k, v in data.items():
        kk = str(k)
        # Scheme A precedence: ENV > .env > DEFAULT
        if os.getenv(kk) is not None:
            origins[kk] = "ENV"
        elif kk in base:
            origins[kk] = "DOTENV"
        else:
            origins[kk] = "DEFAULT"
        masked[kk] = _mask_value(kk, v)

    # Meta
    def _stat(p: str) -> Dict[str, Any]:
        try:
            st = Path(p).stat()
            return {"path": p, "mtime": int(st.st_mtime), "size": int(st.st_size)}
        except (OSError, ValueError, TypeError) as e:
            logger.detail(f"文件状态获取失败 - path={p}, 原因={type(e).__name__}")
            return {"path": p, "mtime": None, "size": None}

    return success_response(data={
        "env_files": {
            "env": _stat(env_path),
            "env_keys": sorted(list(base.keys())),
            "dotenv_present_but_overridden_by_env": sorted([k for k in base.keys() if os.getenv(k) is not None]),
        },
        "settings": masked,
        "origins": origins,
    })


def _tail_lines(path: Path, n: int = 50, max_bytes: int = 256 * 1024) -> List[str]:
    """Read last N lines from a (potentially large) text file."""
    try:
        n = max(1, min(int(n), 200))
    except (ValueError, TypeError) as e:
        logger.detail(f"tail 行数转换失败（使用默认值 50） - n={n}, 原因={type(e).__name__}")
        n = 50
    try:
        with path.open("rb") as f:
            f.seek(0, os.SEEK_END)
            size = f.tell()
            # Read at most max_bytes from the end
            read_size = min(size, max_bytes)
            f.seek(-read_size, os.SEEK_END)
            buf = f.read(read_size)
        text = buf.decode("utf-8", errors="replace")
        lines = [ln for ln in text.splitlines() if ln.strip()]
        return lines[-n:]
    except (OSError, UnicodeDecodeError, ValueError) as e:
        logger.detail(f"文件读取失败（返回空列表） - path={path}, 原因={type(e).__name__}")
        return []


@router.get("/deadletter", response_class=JSONResponse)
async def debug_deadletter(file: Optional[str] = None, tail: int = 50, limit_files: int = 30) -> JSONResponse:
    """List deadletter files and show last records summary."""
    _ensure_debug_enabled()
    s = get_settings()

    dl_dir = Path(str(s.NOTIFIER_DEADLETTER_DIR or "/data/deadletter"))
    files: List[Dict[str, Any]] = []
    total_size = 0

    try:
        cand = [p for p in dl_dir.glob("notify_deadletter_*.jsonl") if p.is_file()]
    except (OSError, ValueError) as e:
        logger.detail(f"deadletter 文件列表获取失败（使用空列表） - dl_dir={dl_dir}, 原因={type(e).__name__}")
        cand = []

    cand.sort(key=lambda p: p.stat().st_mtime if p.exists() else 0, reverse=True)
    try:
        limit_files_v = max(1, min(int(limit_files), 200))
    except (ValueError, TypeError) as e:
        logger.detail(f"limit_files 转换失败（使用默认值 30） - limit_files={limit_files}, 原因={type(e).__name__}")
        limit_files_v = 30

    for p in cand[:limit_files_v]:
        try:
            st = p.stat()
            total_size += int(st.st_size)
            files.append(
                {
                    "name": p.name,
                    "size": int(st.st_size),
                    "mtime": int(st.st_mtime),
                }
            )
        except (OSError, ValueError, TypeError) as e:
            logger.detail(f"文件状态获取失败（使用 None） - file={p.name}, 原因={type(e).__name__}")
            files.append({"name": p.name, "size": None, "mtime": None})

    target: Optional[Path] = None
    if file:
        fp = dl_dir / str(file)
        if fp.exists() and fp.is_file():
            target = fp
    if target is None and cand:
        target = cand[0]

    last_items: List[Dict[str, Any]] = []
    if target is not None:
        lines = await asyncio.to_thread(_tail_lines, target, n=tail)
        for ln in lines:
            try:
                obj = json.loads(ln)
            except (json.JSONDecodeError, ValueError) as e:
                logger.detail(f"JSON 解析失败（已跳过） - 原因={type(e).__name__}")
                continue
            # summarize
            last_items.append(
                {
                    "ts": obj.get("ts"),
                    "reason": obj.get("reason"),
                    "trace_id": obj.get("trace_id"),
                    "event": obj.get("event"),
                    "media_sig": obj.get("media_sig"),
                    "dedup_key": obj.get("dedup_key"),
                    "attempts": obj.get("attempts"),
                    "item_id": obj.get("item_id"),
                    "item_type": obj.get("item_type"),
                    "item_name": obj.get("item_name"),
                    "item_path": obj.get("item_path"),
                    "error_type": obj.get("error_type"),
                    "error_category": obj.get("error_category"),
                    "error": obj.get("error"),
                }
            )

    return success_response(data={
        "dir": str(dl_dir),
        "total_files": len(cand),
        "total_size": total_size,
        "files": files,
        "tail_file": target.name if target else None,
        "tail_items": last_items,
    })
