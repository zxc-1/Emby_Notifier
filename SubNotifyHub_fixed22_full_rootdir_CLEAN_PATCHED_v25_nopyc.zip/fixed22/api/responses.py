"""统一 API 响应格式模块。

提供标准化的 API 响应模型和辅助函数，确保所有端点返回一致的响应格式。

响应格式:
    成功: {"success": true, "data": ..., "timestamp": "...", "trace_id": "..."}
    失败: {"success": false, "error": {"code": "...", "message": "..."}, "timestamp": "...", "trace_id": "..."}
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Generic, Optional, TypeVar

from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field

T = TypeVar("T")


class ErrorDetail(BaseModel):
    """错误详情模型。

    Attributes:
        code: 错误码，大写下划线格式 (e.g., VALIDATION_ERROR)
        message: 人类可读的错误消息
        details: 额外错误信息，如字段级验证错误
    """

    code: str = Field(..., description="错误码，大写下划线格式")
    message: str = Field(..., description="错误消息")
    details: Optional[dict[str, Any]] = Field(None, description="额外错误信息")


class ApiResponse(BaseModel, Generic[T]):
    """统一 API 响应格式。

    Attributes:
        success: 请求是否成功
        data: 响应数据，失败时为 None
        error: 错误信息，成功时为 None
        timestamp: 响应时间戳 (ISO 8601)
        trace_id: 请求追踪 ID
    """

    success: bool = Field(..., description="请求是否成功")
    data: Optional[T] = Field(None, description="响应数据")
    error: Optional[ErrorDetail] = Field(None, description="错误信息")
    timestamp: str = Field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat(),
        description="响应时间戳 (ISO 8601)",
    )
    trace_id: Optional[str] = Field(None, description="请求追踪 ID")

    model_config = {"json_schema_extra": {"examples": []}}


def success_response(
    data: Any = None,
    trace_id: Optional[str] = None,
    status_code: int = 200,
) -> JSONResponse:
    """创建成功响应。

    Args:
        data: 响应数据
        trace_id: 请求追踪 ID
        status_code: HTTP 状态码，默认 200

    Returns:
        JSONResponse 对象
    """
    body = ApiResponse(
        success=True,
        data=data,
        trace_id=trace_id,
    )
    resp = JSONResponse(content=body.model_dump(), status_code=status_code)
    if trace_id:
        # 只设置 ASCII 兼容的 trace_id 到 header
        try:
            trace_id.encode("latin-1")
            resp.headers["X-Trace-Id"] = trace_id
        except UnicodeEncodeError:
            pass  # 非 ASCII trace_id 不设置到 header
    return resp


def error_response(
    code: str,
    message: str,
    trace_id: Optional[str] = None,
    details: Optional[dict[str, Any]] = None,
    status_code: int = 400,
) -> JSONResponse:
    """创建错误响应。

    Args:
        code: 错误码，大写下划线格式
        message: 错误消息
        trace_id: 请求追踪 ID
        details: 额外错误信息
        status_code: HTTP 状态码，默认 400

    Returns:
        JSONResponse 对象
    """
    body = ApiResponse(
        success=False,
        error=ErrorDetail(code=code, message=message, details=details),
        trace_id=trace_id,
    )
    resp = JSONResponse(content=body.model_dump(), status_code=status_code)
    if trace_id:
        # 只设置 ASCII 兼容的 trace_id 到 header
        try:
            trace_id.encode("latin-1")
            resp.headers["X-Trace-Id"] = trace_id
        except UnicodeEncodeError:
            pass  # 非 ASCII trace_id 不设置到 header
    return resp


def validation_error(
    message: str,
    field_errors: dict[str, str],
    trace_id: Optional[str] = None,
) -> JSONResponse:
    """创建验证错误响应。

    Args:
        message: 错误消息
        field_errors: 字段级错误，格式为 {field_name: error_message}
        trace_id: 请求追踪 ID

    Returns:
        JSONResponse 对象
    """
    return error_response(
        code="VALIDATION_ERROR",
        message=message,
        details={"fields": field_errors},
        trace_id=trace_id,
        status_code=400,
    )


# 标准错误码常量
class ErrorCodes:
    """标准错误码常量。"""

    VALIDATION_ERROR = "VALIDATION_ERROR"
    INVALID_JSON = "INVALID_JSON"
    UNAUTHORIZED = "UNAUTHORIZED"
    FORBIDDEN = "FORBIDDEN"
    NOT_FOUND = "NOT_FOUND"
    CONFLICT = "CONFLICT"
    QUEUE_FULL = "QUEUE_FULL"
    WORKER_NOT_STARTED = "WORKER_NOT_STARTED"
    TEMPORARY_ERROR = "TEMPORARY_ERROR"
    CONFIG_ERROR = "CONFIG_ERROR"
    INTERNAL_ERROR = "INTERNAL_ERROR"
    HTTP_ERROR = "HTTP_ERROR"
    CONTEXT_NOT_READY = "CONTEXT_NOT_READY"
    DISABLED = "DISABLED"
