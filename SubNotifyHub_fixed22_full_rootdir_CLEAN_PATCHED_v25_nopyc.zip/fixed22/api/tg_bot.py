from __future__ import annotations

from typing import Any, Dict

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse

from api.responses import success_response, ErrorCodes
from application.errors import AppError
from core.exceptions.base import ValidationError as AppValidationError
from core.logging import get_trace_id
from core.logging import get_biz_logger_adapter
from ports.settings_provider import get_settings
from tg_bot.app.dispatcher import process_update


logger = get_biz_logger_adapter(__name__)

router = APIRouter()


@router.post("/tg/webhook/{secret}")
async def tg_webhook(secret: str, request: Request) -> JSONResponse:
    s = get_settings()
    if not s.TG_BOT_INBOUND_ENABLED:
        raise AppError(
            "Telegram bot inbound disabled",
            error_code=ErrorCodes.DISABLED,
            status_code=404,
        )
    if str(getattr(s, "TG_BOT_MODE", "polling") or "polling").strip().lower() == "polling":
        # When polling is enabled, webhook is intentionally disabled.
        raise AppError(
            "Webhook disabled in polling mode",
            error_code=ErrorCodes.DISABLED,
            status_code=404,
        )
    if not s.TG_BOT_WEBHOOK_SECRET or secret != s.TG_BOT_WEBHOOK_SECRET:
        raise AppError(
            "Not found",
            error_code=ErrorCodes.NOT_FOUND,
            status_code=404,
        )

    try:
        payload: Dict[str, Any] = await request.json()
    except Exception:
        raise AppValidationError(
            "Invalid JSON body",
            error_code=ErrorCodes.INVALID_JSON,
            status_code=400,
        )

    # Fire-and-forget is not allowed here; process inline but be safe.
    try:
        await process_update(payload)
    except Exception:
        logger.fail("TG Webhook：process_update 失败", exc_info=True, trace_id=get_trace_id())
        # By default return 200 to avoid Telegram retry storms.
        # If you want Telegram to retry on failures, set TG_BOT_WEBHOOK_RETURN_OK_ON_ERROR=false
        if not bool(getattr(s, "TG_BOT_WEBHOOK_RETURN_OK_ON_ERROR", True)):
            raise AppError(
                "Process update failed",
                error_code=ErrorCodes.INTERNAL_ERROR,
                status_code=500,
            )
    return success_response(data={"processed": True})
