"""HTTP API routers.

All endpoints live under small focused routers so `app.py` stays tiny.
"""
