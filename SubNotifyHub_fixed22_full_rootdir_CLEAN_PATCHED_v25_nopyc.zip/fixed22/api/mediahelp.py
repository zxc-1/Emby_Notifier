from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse

from api.responses import success_response, ErrorCodes
from application.errors import AppError, TemporaryError
from core.logging import get_biz_logger_adapter, get_trace_id
from core.webhook_security import verify_mediahelp_notify
from notifier.mediahelp_notify import MediaHelpNotifyPayload, build_mediahelp_notification
from notifier.worker import NotificationWorker

logger = get_biz_logger_adapter(__name__)

router = APIRouter()


@router.post("/notify/mediahelp")
async def notify_mediahelp(
    request: Request,
    payload: MediaHelpNotifyPayload,
) -> JSONResponse:
    """Notification entrypoint for MediaHelp/Forward (push into worker queue)."""
    # Protected by MEDIAHELP_TOKEN (Authorization / X-MediaHelp-Token / X-Forward-Token / ?token=...).
    verify_mediahelp_notify(request, None)
    logger.detail("收到 MediaHelp 通知事件 - 事件=%s", payload.event, extra={"step": "mediahelp_notify", "phase": "recv"})

    # Prefer centralized ctx, fall back to legacy app.state
    try:
        from api.deps import get_ctx

        worker: Optional[NotificationWorker] = getattr(get_ctx(request), "notifier_worker", None)
    except (ImportError, AttributeError, RuntimeError) as e:
        logger.detail(f"上下文获取失败，使用备用方案 - 原因={type(e).__name__}")
        worker = getattr(request.app.state, "notifier_worker", None)

    if not worker:
        logger.warning(
            "MediaHelp 通知已拒绝：通知队列未启动",
            extra={"step": "mediahelp_notify", "phase": "drop"},
            trace_id=get_trace_id(),
        )
        raise TemporaryError(
            "Worker not started",
            error_code=ErrorCodes.WORKER_NOT_STARTED,
            status_code=503,
        )

    content = build_mediahelp_notification(payload)
    if content is None:
        logger.warning("MediaHelp 通知已忽略：事件无需处理 - 事件=%s", payload.event, extra={"step": "mediahelp_notify", "phase": "ignored"})
        return success_response(data={"ignored": True})

    res = await worker.enqueue(content)
    if not getattr(res, "ok", False):
        status = str(getattr(res, "status", ""))
        if "queue_full" in status:
            code = ErrorCodes.QUEUE_FULL
            message = "Notification queue is full"
            exc = TemporaryError(message, error_code=code, status_code=503)
        elif "stopped" in status:
            code = ErrorCodes.WORKER_NOT_STARTED
            message = "Worker stopped"
            exc = TemporaryError(message, error_code=code, status_code=503)
        else:
            code = ErrorCodes.INTERNAL_ERROR
            message = "Enqueue failed"
            exc = AppError(message, error_code=code, status_code=503)
        logger.warning(
            "MediaHelp 通知入队失败 - 原因=%s",
            code.lower(),
            extra={"step": "mediahelp_notify", "phase": "fail"},
            trace_id=get_trace_id(),
        )
        raise exc

    logger.ok("MediaHelp 通知已入队，等待处理", extra={"step": "mediahelp_notify", "phase": "enqueued"})
    return success_response(data={"enqueued": True})
