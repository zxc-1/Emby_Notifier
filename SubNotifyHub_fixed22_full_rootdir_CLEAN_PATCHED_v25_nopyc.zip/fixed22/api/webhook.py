from __future__ import annotations

import time
from typing import Optional

from fastapi import APIRouter, Request
from fastapi.responses import JSONResponse

from api.deps import get_ctx
from api.responses import success_response, ErrorCodes
from application.errors import AppError, TemporaryError
from core.exceptions.base import ValidationError as AppValidationError
from application.usecases.ingest_emby_webhook import ingest_emby_webhook
from core.logging import get_biz_logger, get_biz_logger_adapter, get_trace_id, log_fetch, log_ok, log_run
from core.webhook_security import get_remote_ip, verify_emby_webhook
from notifier.worker import NotificationWorker


logger = get_biz_logger_adapter(__name__)
router = APIRouter()


@router.post("/emby/webhook")
async def emby_webhook(request: Request) -> JSONResponse:
    """Emby webhook endpoint: validate + enqueue into worker."""
    t0 = time.monotonic()
    log_fetch(logger, "收到 Emby Webhook 请求")
    verify_emby_webhook(request)

    # Prefer centralized ctx wiring.
    try:
        ctx = get_ctx(request)
    except Exception:
        raise TemporaryError(
            "Application context not ready",
            error_code=ErrorCodes.CONTEXT_NOT_READY,
            status_code=503,
        )

    # Prefer ctx (centralized state). Allow app.state overrides for tests/runtime hacks.
    worker: Optional[NotificationWorker] = getattr(request.app.state, "notifier_worker", None) or getattr(ctx, "notifier_worker", None)
    deduper = getattr(request.app.state, "deduper", None) or getattr(ctx, "deduper", None)

    if not worker:
        logger.fail("Webhook 处理失败：通知队列未启动", trace_id=get_trace_id())
        raise TemporaryError(
            "Notification worker not started",
            error_code=ErrorCodes.WORKER_NOT_STARTED,
            status_code=503,
        )

    try:
        payload = await request.json()
    except Exception:
        logger.warning("Webhook 请求体不是合法 JSON", trace_id=get_trace_id())
        raise AppValidationError(
            "Invalid JSON body",
            error_code=ErrorCodes.INVALID_JSON,
            status_code=400,
        )

    client_host = get_remote_ip(request)
    path = str(request.url.path)

    log_run(logger, "开始解析并入队 Emby Webhook")
    result = await ingest_emby_webhook(
        payload,
        ctx=ctx,
        worker=worker,
        deduper=deduper,
        started_monotonic=t0,
    )

    if result.status == "DUPLICATE":
        logger.warning(
            "Webhook 重复请求已丢弃 - 远端IP=%s 路径=%s 条目ID=%s 条目名称=%s 创建时间=%s",
            client_host,
            path,
            result.item_id,
            result.item_name,
            result.created_raw,
            reason="duplicate_webhook",
        )
        return success_response(data={"status": "DUPLICATE", "item_id": result.item_id})

    if result.status != "ACCEPTED":
        if result.status == "STOPPED":
            logger.warning(
                "Webhook 入队失败：通知队列已停止 - 远端IP=%s 路径=%s 条目ID=%s 条目名称=%s",
                client_host,
                path,
                result.item_id,
                result.item_name,
                trace_id=get_trace_id(),
            )
            raise TemporaryError(
                "Notification worker stopped",
                error_code=ErrorCodes.WORKER_NOT_STARTED,
                status_code=503,
            )
        if result.status == "QUEUE_FULL":
            logger.warning(
                "Webhook 入队失败：队列已满 - 远端IP=%s 路径=%s 条目ID=%s 条目名称=%s",
                client_host,
                path,
                result.item_id,
                result.item_name,
                trace_id=get_trace_id(),
            )
            raise TemporaryError(
                "Notification queue is full",
                error_code=ErrorCodes.QUEUE_FULL,
                status_code=503,
            )
        logger.fail(
            "Webhook 入队失败：内部处理异常 - 远端IP=%s 路径=%s 条目ID=%s 条目名称=%s 状态=%s",
            client_host,
            path,
            result.item_id,
            result.item_name,
            result.status,
            trace_id=get_trace_id(),
        )
        raise AppError(
            "Enqueue failed",
            error_code=ErrorCodes.INTERNAL_ERROR,
            status_code=500,
        )

    log_ok(logger, f"Webhook 入队成功 - 远端IP={client_host} 路径={path} 条目ID={result.item_id} 条目名称={result.item_name}")
    return success_response(data={"status": "ACCEPTED", "item_id": result.item_id})


@router.post("/cd2/task")
async def cd2_task_webhook(request: Request) -> JSONResponse:
    """CD2 task status webhook (optional).

    This endpoint is safe to leave enabled even if CD2 doesn't support callbacks.
    If you configure a secret, you can require it via header `X-CD2-Token` or query `token`.
    Payload best-effort supports:
      {task_id|id, status|state, progress, error|message, result_paths}
    """
    biz = get_biz_logger(__name__)

    # auth optional (configured via crawler config)
    try:
        from crawler.config import load_crawler_config

        cfg = load_crawler_config()
        secret = str(getattr(cfg, "deliver_cd2_webhook_secret", "") or "").strip()
    except Exception:
        secret = ""

    if secret:
        token = (request.headers.get("X-CD2-Token") or request.query_params.get("token") or "").strip()
        if token != secret:
            return JSONResponse({"code": ErrorCodes.FORBIDDEN, "message": "forbidden"}, status_code=403)

    try:
        payload = await request.json()
    except Exception:
        return JSONResponse({"code": ErrorCodes.INVALID_JSON, "message": "invalid json"}, status_code=400)

    task_id = str(payload.get("task_id") or payload.get("taskId") or payload.get("id") or "").strip()
    status = str(payload.get("status") or payload.get("state") or payload.get("taskStatus") or "").lower().strip()
    progress = payload.get("progress") or payload.get("percent") or payload.get("percentDone")
    err = str(payload.get("error") or payload.get("message") or payload.get("errorMessage") or "").strip()
    result_paths = payload.get("result_paths") or payload.get("resultPaths") or payload.get("paths")

    if not task_id:
        return JSONResponse({"code": ErrorCodes.BAD_REQUEST, "message": "task_id_required"}, status_code=400)

    pool = getattr(request.app.state, "crawler_pg_pool", None)
    if not pool:
        return JSONResponse({"code": ErrorCodes.CONTEXT_NOT_READY, "message": "crawler_pg_pool_not_ready"}, status_code=503)

    # Find local delivery task by remote_task_id
    row = await pool.fetchone_optional(
        """
        SELECT id, item_id, save_path, remote_task_id, notify_success, notify_failed
        FROM crawler.crawler_delivery_tasks
        WHERE deliver_to='cd2' AND remote_task_id=$1
        ORDER BY created_at DESC
        LIMIT 1
        """,
        task_id,
    )
    if not row:
        return success_response(data={"status": "IGNORED", "reason": "local_task_not_found"})

    try:
        cfg = load_crawler_config()
    except Exception:
        cfg = None

    from crawler.queue.delivery import cd2_update_poll_result
    from crawler.delivery_notify import try_notify_delivery

    def _norm(s: str) -> str:
        s = (s or "").lower()
        if s in ("success", "succeed", "done", "finished", "complete", "completed"):
            return "success"
        if s in ("failed", "fail", "error", "aborted", "abort", "cancelled", "canceled"):
            return "failed"
        if s in ("running", "downloading"):
            return "running"
        if s in ("pending", "waiting", "queued", "queue", "created"):
            return "pending"
        return "unknown"

    st = _norm(status)
    try:
        prog_int = int(float(progress)) if progress is not None else None
    except Exception:
        prog_int = None

    terminal = st in ("success", "failed")
    await cd2_update_poll_result(
        pool,
        task_id=str(row.get("id")),
        remote_status=st,
        remote_progress=prog_int,
        remote_error_msg=err[:500] if err else None,
        result_paths=result_paths,
        terminal=terminal,
    )

    if terminal:
        # Best-effort enrich message with title
        title = ""
        try:
            item_id = row.get("item_id")
            if item_id is not None:
                r = await pool.fetchone_optional("SELECT title FROM public.article WHERE tid=$1", int(item_id))
                title = str((r or {}).get("title") or "").strip()
        except Exception:
            title = ""

        if st == "success":
            biz.ok("✅ CD2 webhook: 下载完成", remote_task_id=task_id, item_id=str(row.get("item_id") or ""))
            msg = f"✅ CD2 下载完成\n\n🧩 {title or ''}\n🆔 {task_id}\n📁 {row.get('save_path','')}"
        else:
            biz.fail(
                "🧨 CD2 webhook: 下载失败",
                remote_task_id=task_id,
                item_id=str(row.get("item_id") or ""),
                error=(err[:200] if err else ""),
            )
            msg = f"🧨 CD2 下载失败\n\n🧩 {title or ''}\n🆔 {task_id}\n📁 {row.get('save_path','')}\n💥 {err[:200]}"

        await try_notify_delivery(
            pool,
            cfg=cfg,
            task=row,
            terminal_status=st,
            message=msg,
            biz=biz,
        )

    return success_response(data={"status": "UPDATED", "remote_status": st, "terminal": terminal})
