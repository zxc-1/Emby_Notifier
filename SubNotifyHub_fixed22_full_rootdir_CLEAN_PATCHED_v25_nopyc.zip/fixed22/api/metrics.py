from __future__ import annotations

from core.logging import get_biz_logger_adapter
from core.exceptions import get_exception_counts, get_exception_summary
from core.metrics import metrics
from core.db.pool_manager import get_all_pool_stats
from fastapi import APIRouter
from fastapi.responses import JSONResponse, PlainTextResponse

from api.responses import success_response

logger = get_biz_logger_adapter(__name__)

router = APIRouter()


@router.get("/metrics", response_class=PlainTextResponse)
async def metrics_endpoint() -> PlainTextResponse:
    """Prometheus 格式指标端点，保持原格式不变。"""
    text = metrics.export_prometheus()
    return PlainTextResponse(content=text, media_type="text/plain; version=0.0.4; charset=utf-8")


@router.get("/metrics/exceptions", response_class=JSONResponse)
async def exception_metrics_endpoint() -> JSONResponse:
    """获取异常指标摘要。

    Returns:
        包含异常计数和摘要信息的 JSON 响应

    Requirements: 6.2
    """
    return success_response(data=get_exception_summary())


@router.get("/metrics/exceptions/counts", response_class=JSONResponse)
async def exception_counts_endpoint() -> JSONResponse:
    """获取异常计数详情。

    Returns:
        嵌套字典，结构为 {category: {module: count}}

    Requirements: 6.2
    """
    return success_response(data=get_exception_counts())


@router.get("/metrics/db-pools", response_class=JSONResponse)
async def db_pool_metrics_endpoint() -> JSONResponse:
    """获取数据库连接池指标。

    Returns:
        包含所有连接池统计信息的 JSON 响应，包括：
        - sync_pools: 同步连接池统计
        - async_pools: 异步连接池统计
        - summary: 汇总信息（总池数、总活跃连接、总空闲连接）

    Requirements: 7.2
    """
    return success_response(data=get_all_pool_stats())