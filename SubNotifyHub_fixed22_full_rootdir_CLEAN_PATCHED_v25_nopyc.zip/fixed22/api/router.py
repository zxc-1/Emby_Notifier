from __future__ import annotations

from fastapi import APIRouter

from .debug import router as debug_router
from .health import router as health_router
from .mediahelp import router as mediahelp_router
from .metrics import router as metrics_router
from .tg_bot import router as tg_bot_router
from .webhook import router as webhook_router


def build_api_router() -> APIRouter:
    router = APIRouter()
    router.include_router(health_router)
    router.include_router(metrics_router)
    router.include_router(webhook_router)
    router.include_router(mediahelp_router)
    router.include_router(tg_bot_router)
    router.include_router(debug_router)
    return router
