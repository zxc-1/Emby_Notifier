from __future__ import annotations

import json
from datetime import datetime
from typing import Any

from crawler.notify import send_tg


def _cfg_deliver_notify_enabled(cfg: Any) -> bool:
    """Global delivery notify switch.

    Compatibility:
    - prefer `deliver_notify_enabled`
    - fallback to legacy `deliver_cd2_notify_enabled`
    - default True
    """

    if cfg is None:
        return True
    try:
        v = getattr(cfg, "deliver_notify_enabled")
        if v is not None:
            return bool(v)
    except Exception:
        pass
    try:
        v = getattr(cfg, "deliver_cd2_notify_enabled")
        if v is not None:
            return bool(v)
    except Exception:
        pass
    return True


def _task_notify_allowed(task: dict[str, Any], terminal_status: str) -> bool:
    """Task-level notify flags.

    Columns on crawler.crawler_delivery_tasks:
    - notify_success: whether success notification is enabled
    - notify_failed: whether failure notification is enabled

    Historical default (when NULL): success=False, failed=True.
    """

    terminal_status = (terminal_status or "").strip().lower()
    if terminal_status == "success":
        v = task.get("notify_success")
        if v is None:
            return False
        return bool(v)
    if terminal_status == "failed":
        v = task.get("notify_failed")
        if v is None:
            return True
        return bool(v)
    # non-terminal states never notify
    return False


async def record_notify_result(
    pool: Any,
    *,
    task_id: str,
    ok: bool,
    channel: str = "tg",
    error: str | None = None,
    terminal_status: str | None = None,
) -> None:
    """Persist notification attempt result for troubleshooting."""

    try:
        payload = {
            "ok": bool(ok),
            "channel": str(channel or ""),
            "error": (str(error) if error else ""),
            "status": (str(terminal_status) if terminal_status else ""),
            "at": datetime.utcnow().isoformat(timespec="seconds"),
        }
        await pool.execute(
            """
            UPDATE crawler.crawler_delivery_tasks
            SET notified_at = now(),
                meta = jsonb_set(COALESCE(meta, '{}'::jsonb), '{notify}', $2::jsonb, true),
                updated_at = now()
            WHERE id = $1
            """,
            str(task_id),
            json.dumps(payload, ensure_ascii=False),
        )
    except Exception:
        # best-effort; never block delivery loops
        return


async def try_notify_delivery(
    pool: Any,
    *,
    cfg: Any,
    task: dict[str, Any],
    terminal_status: str,
    message: str,
    biz: Any,
) -> None:
    """Send TG notification for a delivery task (success/failure) with robust logging.

    This function is intentionally *best-effort*:
    - respects global + task-level switches
    - never raises (so it won't kill delivery loops)
    - records outcome to DB for troubleshooting
    """

    task_id = str(task.get("id") or "")
    if not task_id:
        return

    # Global switch
    if not _cfg_deliver_notify_enabled(cfg):
        try:
            biz.info("delivery.notify.skipped", reason="global_disabled", task_id=task_id)
        except Exception:
            pass
        return

    # Task-level flags (default: fail-only)
    if not _task_notify_allowed(task, terminal_status=terminal_status):
        try:
            biz.info(
                "delivery.notify.skipped",
                reason="task_disabled",
                task_id=task_id,
                status=str(terminal_status),
            )
        except Exception:
            pass
        return

    try:
        biz.step("delivery.notify.send", task_id=task_id, status=str(terminal_status))
    except Exception:
        pass

    try:
        await send_tg(message)
        await record_notify_result(
            pool,
            task_id=task_id,
            ok=True,
            channel="tg",
            terminal_status=str(terminal_status),
        )
        try:
            biz.ok("delivery.notify.sent", task_id=task_id, status=str(terminal_status))
        except Exception:
            pass
    except Exception as e:
        await record_notify_result(
            pool,
            task_id=task_id,
            ok=False,
            channel="tg",
            error=str(e)[:300],
            terminal_status=str(terminal_status),
        )
        try:
            biz.fail(
                "delivery.notify.failed",
                task_id=task_id,
                status=str(terminal_status),
                exc=e,
            )
        except Exception:
            # last resort: don't raise
            return
