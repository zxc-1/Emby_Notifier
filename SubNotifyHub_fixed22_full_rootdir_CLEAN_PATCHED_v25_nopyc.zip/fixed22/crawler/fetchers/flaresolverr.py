from __future__ import annotations

from typing import Any, Mapping, Optional

from core.http.clients import get_http_client
from core.http.retry import async_request_with_retry_json
from core.logging import get_biz_logger


biz = get_biz_logger(__name__)


class FlareSolverrFetcher:
    """Fetcher that delegates to FlareSolverr for Cloudflare/JS challenges."""

    def __init__(self, base_url: str):
        self.base_url = str(base_url or "").rstrip("/")

    def _api_url(self) -> str:
        api_url = self.base_url
        if not api_url.endswith("/v1"):
            api_url = f"{api_url}/v1"
        return api_url

    async def create_session(self, *, session: str | None = None, timeout_ms: int = 60000) -> str:
        """Create (or reuse) a FlareSolverr session.

        A session allows FlareSolverr to keep a persistent browser context and
        reuse clearance cookies/state across requests.
        """
        if not self.base_url:
            raise RuntimeError("未配置 FLARE_SOLVERR_URL：无法使用 FlareSolverr 处理 Cloudflare/JS 验证")

        api_url = self._api_url()
        payload: dict[str, Any] = {"cmd": "sessions.create", "maxTimeout": int(timeout_ms)}
        if session:
            payload["session"] = str(session)

        _status, resp, _snip = await async_request_with_retry_json(
            await get_http_client(),
            method="POST",
            url=api_url,
            json=payload,
            timeout=max(30.0, timeout_ms / 1000.0 + 5.0),
        )
        return str((resp or {}).get("session") or session or "")

    async def destroy_session(self, session: str, *, timeout_ms: int = 60000) -> None:
        if not self.base_url:
            return
        api_url = self._api_url()
        payload: dict[str, Any] = {"cmd": "sessions.destroy", "session": str(session), "maxTimeout": int(timeout_ms)}
        try:
            await async_request_with_retry_json(
                await get_http_client(),
                method="POST",
                url=api_url,
                json=payload,
                timeout=max(30.0, timeout_ms / 1000.0 + 5.0),
            )
        except Exception:
            return

    async def get_text(
        self,
        url: str,
        *,
        headers: Optional[Mapping[str, str]] = None,
        cookies: Optional[Mapping[str, str]] = None,
        timeout_ms: int = 60000,
    ) -> str:
        if not self.base_url:
            raise RuntimeError("未配置 FLARE_SOLVERR_URL：无法使用 FlareSolverr 处理 Cloudflare/JS 验证")

        # Most deployments expose the API at /v1. Allow both forms:
        #   FLARE_SOLVERR_URL=http://localhost:8191
        #   FLARE_SOLVERR_URL=http://localhost:8191/v1
        api_url = self._api_url()
        payload = {
            "cmd": "request.get",
            "url": url,
            "maxTimeout": int(timeout_ms),
        }
        if headers:
            payload["headers"] = dict(headers)
        if cookies:
            # FlareSolverr expects cookie string, but it also accepts list.
            payload["cookies"] = [
                {"name": k, "value": v}
                for k, v in dict(cookies).items()
                if str(k).strip()
            ]

        _status, resp, _snip = await async_request_with_retry_json(
            await get_http_client(),
            method="POST",
            url=api_url,
            json=payload,
            timeout=max(30.0, timeout_ms / 1000.0 + 5.0),
        )
        try:
            sol = resp.get("solution") or {}
            return str(sol.get("response") or "")
        except Exception as e:
            # Keep the payload small; the full resp may be huge.
            try:
                keys = list((resp or {}).keys()) if isinstance(resp, dict) else []
            except Exception:
                keys = []
            biz.fail(
                "❌ 解析 FlareSolverr 返回失败：未找到 solution.response。",
                返回字段=keys,
                建议="检查 FlareSolverr 服务是否正常、版本是否兼容；也可打开 BIZ_DETAIL 查看更详细日志。",
                exc=e,
            )
            raise

    async def get_text_and_cookies(
        self,
        url: str,
        *,
        headers: Optional[Mapping[str, str]] = None,
        cookies: Optional[Mapping[str, str]] = None,
        timeout_ms: int = 60000,
    ) -> tuple[str, dict[str, str]]:
        """Return (html, cookies) from FlareSolverr solution.

        FlareSolverr's response may include a list of cookies under solution.cookies.
        We normalize them into a simple {name: value} mapping.
        """
        if not self.base_url:
            raise RuntimeError("未配置 FLARE_SOLVERR_URL：无法使用 FlareSolverr 处理 Cloudflare/JS 验证")

        api_url = self._api_url()

        payload: dict[str, Any] = {
            "cmd": "request.get",
            "url": url,
            "maxTimeout": int(timeout_ms),
        }
        if headers:
            payload["headers"] = dict(headers)
        if cookies:
            payload["cookies"] = [
                {"name": k, "value": v}
                for k, v in dict(cookies).items()
                if str(k).strip()
            ]

        _status, resp, _snip = await async_request_with_retry_json(
            await get_http_client(),
            method="POST",
            url=api_url,
            json=payload,
            timeout=max(30.0, timeout_ms / 1000.0 + 5.0),
        )

        sol = (resp or {}).get("solution") or {}
        html = str(sol.get("response") or "")

        ck: dict[str, str] = {}
        try:
            cookies_list = sol.get("cookies") or []
            if isinstance(cookies_list, list):
                for c in cookies_list:
                    if not isinstance(c, dict):
                        continue
                    name = str(c.get("name") or "").strip()
                    value = str(c.get("value") or "")
                    if name:
                        ck[name] = value
        except Exception:
            # best-effort
            ck = {}

        return html, ck

    async def get_text_and_cookies_with_session(
        self,
        url: str,
        *,
        session: str,
        headers: Optional[Mapping[str, str]] = None,
        cookies: Optional[Mapping[str, str]] = None,
        timeout_ms: int = 60000,
    ) -> tuple[str, dict[str, str]]:
        """Same as get_text_and_cookies, but uses a persistent FlareSolverr session."""
        if not self.base_url:
            raise RuntimeError("未配置 FLARE_SOLVERR_URL：无法使用 FlareSolverr 处理 Cloudflare/JS 验证")

        api_url = self._api_url()
        payload: dict[str, Any] = {
            "cmd": "request.get",
            "url": url,
            "maxTimeout": int(timeout_ms),
            "session": str(session),
        }
        if headers:
            payload["headers"] = dict(headers)
        if cookies:
            payload["cookies"] = [
                {"name": k, "value": v}
                for k, v in dict(cookies).items()
                if str(k).strip()
            ]

        _status, resp, _snip = await async_request_with_retry_json(
            await get_http_client(),
            method="POST",
            url=api_url,
            json=payload,
            timeout=max(30.0, timeout_ms / 1000.0 + 5.0),
        )

        sol = (resp or {}).get("solution") or {}
        html = str(sol.get("response") or "")

        ck: dict[str, str] = {}
        try:
            cookies_list = sol.get("cookies") or []
            if isinstance(cookies_list, list):
                for c in cookies_list:
                    if not isinstance(c, dict):
                        continue
                    name = str(c.get("name") or "").strip()
                    value = str(c.get("value") or "")
                    if name:
                        ck[name] = value
        except Exception:
            ck = {}

        return html, ck
