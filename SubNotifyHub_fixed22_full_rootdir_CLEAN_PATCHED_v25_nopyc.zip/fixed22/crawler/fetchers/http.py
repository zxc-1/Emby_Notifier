from __future__ import annotations

from typing import Any, Mapping, Optional

from crawler.fetchers.http_client import get_crawler_http_client
from core.http.retry import (
    async_request_with_retry_bytes,
    async_request_with_retry_json,
    async_request_with_retry_text,
)
from core.logging import get_biz_logger


biz = get_biz_logger(__name__)


def _merge_cookie_header(headers: Mapping[str, str] | None, cookies: Mapping[str, str] | None) -> dict[str, str]:
    h = dict(headers or {})
    if cookies:
        # Merge into Cookie header (httpx cookies jar is not wired through core/http/retry)
        ck = "; ".join([f"{k}={v}" for k, v in dict(cookies).items() if str(k).strip()])
        if ck:
            if h.get("Cookie"):
                h["Cookie"] = h["Cookie"].rstrip(";") + "; " + ck
            else:
                h["Cookie"] = ck
    return h


class HttpFetcher:
    """HTTP fetcher with retry strategy.

    Supports runtime network settings (UA/proxy/timeout) from UI overrides.
    """

    def __init__(
        self,
        *,
        user_agent: str | None = None,
        proxy_url: str | None = None,
        timeout_s: float = 25.0,
    ):
        self.user_agent = str(user_agent or "").strip() or None
        self.proxy_url = str(proxy_url or "").strip() or None
        self.timeout_s = float(timeout_s or 0) if timeout_s else 25.0
        if self.timeout_s <= 0:
            self.timeout_s = 25.0

    async def get_text(
        self,
        url: str,
        *,
        headers: Optional[Mapping[str, str]] = None,
        cookies: Optional[Mapping[str, str]] = None,
        timeout: float | None = None,
    ) -> str:
        client = await get_crawler_http_client(
            user_agent=self.user_agent,
            proxy_url=self.proxy_url,
            timeout_s=float(timeout or self.timeout_s),
        )
        _status, txt, _snip = await async_request_with_retry_text(
            client,
            method="GET",
            url=url,
            headers=_merge_cookie_header(headers, cookies),
            timeout=float(timeout or self.timeout_s),
        )
        return txt

    async def get_json(
        self,
        url: str,
        *,
        headers: Optional[Mapping[str, str]] = None,
        cookies: Optional[Mapping[str, str]] = None,
        timeout: float | None = None,
    ) -> Any:
        client = await get_crawler_http_client(
            user_agent=self.user_agent,
            proxy_url=self.proxy_url,
            timeout_s=float(timeout or self.timeout_s),
        )
        _status, js, _snip = await async_request_with_retry_json(
            client,
            method="GET",
            url=url,
            headers=_merge_cookie_header(headers, cookies),
            timeout=float(timeout or self.timeout_s),
        )
        return js

    async def get_bytes(
        self,
        url: str,
        *,
        headers: Optional[Mapping[str, str]] = None,
        cookies: Optional[Mapping[str, str]] = None,
        timeout: float | None = None,
    ) -> bytes:
        client = await get_crawler_http_client(
            user_agent=self.user_agent,
            proxy_url=self.proxy_url,
            timeout_s=float(timeout or self.timeout_s),
        )
        _status, b = await async_request_with_retry_bytes(
            client,
            method="GET",
            url=url,
            headers=_merge_cookie_header(headers, cookies),
            timeout=float(timeout or self.timeout_s),
        )
        return b
