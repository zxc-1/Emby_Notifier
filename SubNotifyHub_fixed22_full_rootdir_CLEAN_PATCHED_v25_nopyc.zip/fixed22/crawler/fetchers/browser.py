from __future__ import annotations
import asyncio
from core.env_utils import env_bool, env_str

import json
from pathlib import Path
from typing import Any, Optional
from urllib.parse import urlparse, unquote

from core.logging import get_biz_logger
from core.suppress import suppress

biz = get_biz_logger(__name__)


class BrowserUnavailable(RuntimeError):
    pass


def _normalize_proxy(proxy_url: str | None) -> dict[str, str] | None:
    """Convert a proxy url into Playwright's proxy dict.

    Accepts formats like:
      - http://host:port
      - http://user:pass@host:port
      - socks5://host:port
    """

    raw = str(proxy_url or "").strip()
    if not raw:
        return None

    try:
        p = urlparse(raw)
        if p.scheme and p.hostname:
            server = f"{p.scheme}://{p.hostname}"
            if p.port:
                server += f":{p.port}"
            out: dict[str, str] = {"server": server}
            if p.username:
                out["username"] = unquote(p.username)
            if p.password:
                out["password"] = unquote(p.password)
            return out
    except Exception as e:
        # fall back to raw
        suppress(site="crawler/browser:normalize_proxy", exc=e, logger=biz, fallback=None)

    return {"server": raw}


class BrowserFetcher:
    """Playwright-based fetcher with persistent storage_state.

    - Reuses a single Browser + BrowserContext per instance.
    - Persists cookies/localStorage to disk (storage_state) so CF/age-gate can survive restarts.

    Env:
      - CRAWLER_BROWSER_STATE_DIR: directory to store *.json state files
      - CRAWLER_BROWSER_HEADLESS: 1/0 (default 1)
      - CRAWLER_BROWSER_UA: custom user-agent (optional)
    """

    def __init__(
        self,
        *,
        state_key: str,
        user_agent: str | None = None,
        proxy_url: str | None = None,
        timeout_s: int = 30,
    ):
        self.state_key = state_key.replace("/", "_").replace(":", "_")
        self._pw = None
        self._browser = None
        self._context = None
        self._state_dir = Path(env_str("CRAWLER_BROWSER_STATE_DIR", "data/crawler/browser_state"))
        self._state_dir.mkdir(parents=True, exist_ok=True)
        self._state_path = self._state_dir / f"{self.state_key}.json"
        self._headless = env_bool("CRAWLER_BROWSER_HEADLESS", True)
        # Prefer caller provided network settings (UI overrides), then env.
        self._ua = (str(user_agent or "").strip() or env_str("CRAWLER_BROWSER_UA", "").strip() or None)
        self._proxy_url = str(proxy_url or "").strip() or None
        self._proxy = _normalize_proxy(self._proxy_url)
        self._timeout_ms = max(5_000, int(timeout_s) * 1000)

    async def update_network(
        self,
        *,
        user_agent: str | None = None,
        proxy_url: str | None = None,
        timeout_s: int | None = None,
    ) -> None:
        """Update network settings; restart context if they changed."""

        new_ua = str(user_agent or "").strip() or None
        new_proxy_url = str(proxy_url or "").strip() or None
        new_timeout_ms = self._timeout_ms if timeout_s is None else max(5_000, int(timeout_s) * 1000)

        changed = (new_ua != self._ua) or (new_proxy_url != self._proxy_url) or (new_timeout_ms != self._timeout_ms)
        if not changed:
            return

        self._ua = new_ua
        self._proxy_url = new_proxy_url
        self._proxy = _normalize_proxy(self._proxy_url)
        self._timeout_ms = new_timeout_ms

        # Restart to apply new UA/proxy.
        if self._context is not None or self._browser is not None or self._pw is not None:
            await self.close()

    async def _ensure(self) -> None:
        if self._context is not None:
            return
        try:
            from playwright.async_api import async_playwright
        except Exception as e:
            raise BrowserUnavailable("Playwright 未安装：pip install playwright && playwright install chromium") from e

        self._pw = await async_playwright().start()
        launch_kwargs: dict[str, Any] = {"headless": self._headless}
        if self._proxy:
            launch_kwargs["proxy"] = self._proxy
        self._browser = await self._pw.chromium.launch(**launch_kwargs)
        storage_state = None
        if self._state_path.exists():
            try:
                storage_state = json.loads(await asyncio.to_thread(self._state_path.read_text, encoding="utf-8"))
            except Exception:
                storage_state = None

        kwargs: dict[str, Any] = {}
        if storage_state:
            kwargs["storage_state"] = storage_state
        if self._ua:
            kwargs["user_agent"] = self._ua
        self._context = await self._browser.new_context(**kwargs)

    async def close(self) -> None:
        try:
            if self._context is not None:
                await self._persist_state()
                await self._context.close()
        finally:
            self._context = None
        try:
            if self._browser is not None:
                await self._browser.close()
        finally:
            self._browser = None
        try:
            if self._pw is not None:
                await self._pw.stop()
        finally:
            self._pw = None

    async def _persist_state(self) -> None:
        if self._context is None:
            return
        try:
            state = await self._context.storage_state()
            await asyncio.to_thread(self._state_path.write_text, json.dumps(state, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception as e:
            biz.warning(
                "⚠️ 浏览器会话持久化失败：storage_state 未能写入磁盘（已忽略，不影响本次抓取）。",
                会话键=self.state_key,
                建议="检查 data/crawler/browser_state 目录是否可写，或磁盘空间是否不足。",
                exc=e,
            )

    async def get(self, url: str, *, timeout_ms: int | None = None, wait_until: str = "domcontentloaded", settle_ms: int = 500) -> str:
        await self._ensure()
        assert self._context is not None
        page = await self._context.new_page()
        try:
            await page.goto(url, timeout=int(timeout_ms or self._timeout_ms), wait_until=wait_until)
            # Give CF/age-gate a tiny chance to settle
            await page.wait_for_timeout(int(settle_ms))
            html = await page.content()
            await self._persist_state()
            return html
        finally:
            await page.close()

    async def download_bytes(self, url: str, *, timeout_ms: int | None = None) -> bytes:
        """Download bytes using the browser context (cookies attached)."""
        await self._ensure()
        assert self._context is not None
        # Use context.request to keep cookies/session
        resp = await self._context.request.get(url, timeout=int(timeout_ms or max(self._timeout_ms, 60_000)))
        try:
            if not resp.ok:
                raise RuntimeError(f"浏览器下载失败：HTTP {resp.status}")
            data = await resp.body()
            await self._persist_state()
            return data
        finally:
            await resp.dispose()


    async def export_cookies_dict(self, *, domain: str | None = None) -> dict[str, str]:
        """Export cookies as a simple name->value dict.

        If domain is provided, only cookies whose domain matches (suffix match) are included.
        """
        await self._ensure()
        assert self._context is not None
        try:
            state = await self._context.storage_state()
            cookies = state.get("cookies") if isinstance(state, dict) else None
            out: dict[str, str] = {}
            if isinstance(cookies, list):
                for ck in cookies:
                    if not isinstance(ck, dict):
                        continue
                    name = str(ck.get("name") or "").strip()
                    value = str(ck.get("value") or "")
                    dom = str(ck.get("domain") or "").lstrip(".").lower()
                    if not name:
                        continue
                    if domain:
                        d = str(domain).lstrip(".").lower()
                        if dom and (dom == d or d.endswith("." + dom) or dom.endswith("." + d)):
                            out[name] = value
                        else:
                            continue
                    else:
                        out[name] = value
            return out
        except Exception:
            return {}

    async def import_cookies(self, cookies: dict[str, str], *, domain: str) -> None:
        """Import cookies into the current browser context (best-effort)."""
        await self._ensure()
        assert self._context is not None
        dom = str(domain).strip().lower().lstrip(".")
        if not dom:
            return
        items = []
        for k, v in (cookies or {}).items():
            name = str(k).strip()
            if not name:
                continue
            items.append({"name": name, "value": str(v), "domain": dom, "path": "/"})
        if not items:
            return
        try:
            await self._context.add_cookies(items)
            await self._persist_state()
        except Exception:
            return

    async def pass_check(self, url: str, *, max_attempts: int = 6, wait_until: str = "networkidle") -> str:
        """Try to obtain a non-challenge HTML by retrying navigation with backoff.

        Returns the last HTML (may still be a challenge page) but persists storage_state.
        """
        html = ""
        for i in range(1, max_attempts + 1):
            html = await self.get(url, wait_until=wait_until, settle_ms=1500)
            # Heuristic: if looks like CF/blank, wait longer and retry
            if html and len(html) > 2_000 and ("Just a moment" not in html) and ("cf-challenge" not in html):
                return html
            await asyncio.sleep(min(2.0 * i, 8.0) + (0.2 * (i % 3)))
        return html

