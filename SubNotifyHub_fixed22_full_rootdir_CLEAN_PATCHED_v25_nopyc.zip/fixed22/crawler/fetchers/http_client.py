from __future__ import annotations

import asyncio
from collections import deque

import httpx

from core.logging import get_biz_logger
from core.suppress import suppress
from core.task_registry import create_task_logged


biz = get_biz_logger(__name__)


_CLIENTS: dict[tuple[int, str, str, float], httpx.AsyncClient] = {}
_LRU: deque[tuple[int, str, str, float]] = deque()
_LOCK = asyncio.Lock()


def _norm_str(v: str | None) -> str:
    return str(v or "").strip()


async def get_crawler_http_client(
    *,
    user_agent: str | None,
    proxy_url: str | None,
    timeout_s: float,
) -> httpx.AsyncClient:
    """Get an AsyncClient configured for crawler fetching.

    - Supports per-crawler proxy/UA/timeout (UI overrides).
    - Uses a small LRU cache keyed by (event_loop, ua, proxy, timeout) to avoid
      creating a new client per request.
    """

    ua = _norm_str(user_agent)
    proxy = _norm_str(proxy_url)
    timeout_s = float(timeout_s or 0) if timeout_s else 0.0
    if timeout_s <= 0:
        timeout_s = 25.0

    loop = asyncio.get_running_loop()
    key = (id(loop), ua, proxy, float(timeout_s))
    if key in _CLIENTS:
        try:
            _LRU.remove(key)
        except ValueError:
            pass
        _LRU.append(key)
        return _CLIENTS[key]

    async with _LOCK:
        # Double-check under lock.
        if key in _CLIENTS:
            try:
                _LRU.remove(key)
            except ValueError:
                pass
            _LRU.append(key)
            return _CLIENTS[key]

        headers: dict[str, str] = {}
        if ua:
            headers["User-Agent"] = ua

        # httpx 0.28 uses `proxy=` (not `proxies=`)
        proxy_arg = proxy or None

        client = httpx.AsyncClient(
            headers=headers or None,
            proxy=proxy_arg,
            timeout=httpx.Timeout(timeout_s),
            follow_redirects=True,
            limits=httpx.Limits(max_connections=100, max_keepalive_connections=20),
        )
        _CLIENTS[key] = client
        _LRU.append(key)

        # Keep the cache small to avoid leaking sockets across config changes.
        # (The crawler hot-reloads config; UA/proxy changes create a new key.)
        while len(_LRU) > 8:
            old = _LRU.popleft()
            old_client = _CLIENTS.pop(old, None)
            if old_client is not None:
                try:
                    # Close in background; don't block the hot path.
                    create_task_logged(old_client.aclose(), name="crawler_http_client_close", log=biz)
                except Exception as e:
                    suppress(site="crawler/http_client:close_old_client", exc=e, logger=biz, fallback=None)

        return client
