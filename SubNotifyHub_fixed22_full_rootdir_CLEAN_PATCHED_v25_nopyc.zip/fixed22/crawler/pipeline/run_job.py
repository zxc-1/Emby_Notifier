from __future__ import annotations

import asyncio
import hashlib
import json
import uuid
import random
import re
from datetime import datetime
from core.time_utils import utc_now_iso_z
from pathlib import Path
from typing import Any

from core.logging import get_biz_logger
from core.suppress import suppress

from crawler.db.pg import PgPool
from crawler.db.state import get_source_cursor, merge_source_cursor, update_source_cursor_max_int
from crawler.models.types import Candidate, CrawlJob, Item
from crawler.pipeline.dedup import magnet_hash
from crawler.plugins import get_plugins


biz = get_biz_logger(__name__)


_CTRL_RE = re.compile(r"[\x00-\x1F\x7F]")


def _clean_section_name(name: str) -> str:
    """Normalize section/category names before storing.

    - trims
    - removes control characters
    - collapses whitespace
    - caps length (avoid category pollution)
    """
    s = str(name or "").strip()
    if not s:
        return ""
    s = _CTRL_RE.sub("", s)
    s = re.sub(r"\s+", " ", s).strip()
    if len(s) > 64:
        s = s[:64]
    return s


def _stop_tid_scope(source: str, params: dict[str, Any]) -> str:
    """Build a stable cursor scope for stop_tid mode."""
    if source == "sehuatang":
        sec = params.get("section")
        if sec is not None and str(sec).strip():
            return f"section:{str(sec).strip()}"
    return ""


def _clean_meta_for_detail(meta: Any) -> dict[str, Any]:
    if not isinstance(meta, dict):
        return {}
    # Remove volatile/huge keys which would otherwise break dedup_key stability.
    drop = {"page", "time_field", "raw"}
    out: dict[str, Any] = {}
    for k, v in meta.items():
        if k in drop:
            continue
        out[k] = v
    return out


def _dedup_key(queue: str, source: str, kind: str, params: dict[str, Any]) -> str:
    payload = json.dumps({"q": queue, "s": source, "k": kind, "p": params}, ensure_ascii=False, sort_keys=True)
    return hashlib.sha1(payload.encode("utf-8")).hexdigest()


async def enqueue_job(pool: PgPool, *, queue: str, source: str, kind: str, params: dict[str, Any]) -> None:
    dk = _dedup_key(queue, source, kind, params)
    job_id = uuid.uuid4()
    await pool.execute(
        """
        INSERT INTO crawler.crawler_jobs (id, queue, source, kind, params, dedup_key, status)
        VALUES ($1,$2,$3,$4,$5::jsonb,$6,'pending')
        ON CONFLICT (dedup_key) DO NOTHING
        """,
        job_id,
        queue,
        source,
        kind,
        params,
        dk,
    )


async def ensure_discovered_table(pool: PgPool) -> None:
    """Staging table for discovered-but-not-yet-materialized items.

    设计目标：public.article 只存终态（magnet 已获取）。discover 阶段发现的候选（可能缺 magnet）
    先写入 crawler.discovered_items，便于：去重、重试、可观测。
    """

    await pool.execute(
        """
        CREATE TABLE IF NOT EXISTS crawler.discovered_items (
          key text PRIMARY KEY,
          detail_url text,
          external_id text,
          title text NOT NULL,
          publish_date date,
          website text,
          section text,
          category text,
          preview_images text,
          raw jsonb NOT NULL DEFAULT '{}'::jsonb,
          status text NOT NULL DEFAULT 'discovered',
          last_error text,
          tid bigint,
          discovered_at timestamptz NOT NULL DEFAULT now(),
          updated_at timestamptz NOT NULL DEFAULT now()
        );

        CREATE INDEX IF NOT EXISTS idx_discovered_status ON crawler.discovered_items(status);
        CREATE INDEX IF NOT EXISTS idx_discovered_updated ON crawler.discovered_items(updated_at);
        """
    )


def _discovered_key(*, detail_url: str | None, website: str | None, external_id: str | None, title: str, publish_date: Any) -> str:
    base = detail_url or f"{website or ''}|{external_id or ''}|{title}|{publish_date or ''}"
    return hashlib.sha1(base.encode('utf-8')).hexdigest()


async def upsert_discovered(
    pool: PgPool,
    *,
    key: str,
    detail_url: str | None,
    external_id: str | None,
    title: str,
    publish_date: Any,
    website: str | None,
    section: str | None,
    category: str | None,
    preview_images: str | None,
    raw: dict[str, Any] | None,
    status: str,
    tid: int | None = None,
    last_error: str | None = None,
) -> None:
    await pool.execute(
        """
        INSERT INTO crawler.discovered_items
          (key, detail_url, external_id, title, publish_date, website, section, category, preview_images, raw, status, last_error, tid, discovered_at, updated_at)
        VALUES
          ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10::jsonb,$11,$12,$13, now(), now())
        ON CONFLICT (key) DO UPDATE SET
          detail_url = COALESCE(EXCLUDED.detail_url, crawler.discovered_items.detail_url),
          external_id = COALESCE(EXCLUDED.external_id, crawler.discovered_items.external_id),
          title = EXCLUDED.title,
          publish_date = COALESCE(EXCLUDED.publish_date, crawler.discovered_items.publish_date),
          website = COALESCE(EXCLUDED.website, crawler.discovered_items.website),
          section = COALESCE(NULLIF(EXCLUDED.section,''), crawler.discovered_items.section),
          category = COALESCE(NULLIF(EXCLUDED.category,''), crawler.discovered_items.category),
          preview_images = COALESCE(NULLIF(EXCLUDED.preview_images,''), crawler.discovered_items.preview_images),
          raw = crawler.discovered_items.raw || EXCLUDED.raw,
          status = EXCLUDED.status,
          last_error = EXCLUDED.last_error,
          tid = COALESCE(EXCLUDED.tid, crawler.discovered_items.tid),
          updated_at = now()
        """,
        key,
        detail_url,
        external_id,
        title,
        publish_date,
        website,
        section,
        category,
        preview_images,
        raw or {},
        status,
        (last_error or None),
        tid,
    )


async def _download_cover_if_needed(ctx: dict[str, Any], item: Item) -> None:
    if (item.cover_path or "").strip():
        return
    cover_url = (item.cover_url or "").strip()
    if not cover_url:
        return
    if not ctx.get("cover_download_enabled"):
        return

    cover_dir = Path(ctx.get("cover_dir") or "data/crawler/covers")
    cover_dir.mkdir(parents=True, exist_ok=True)

    date_part = (item.publish_date or "").strip() or datetime.now().strftime("%Y-%m-%d")
    sec = (item.section or item.category or "unknown").strip() or "unknown"
    fname = hashlib.sha1((cover_url + (item.external_id or "") + date_part).encode("utf-8")).hexdigest()
    ext = ".jpg"
    out_dir = cover_dir / item.source / sec / date_part
    out_dir.mkdir(parents=True, exist_ok=True)
    out_path = out_dir / f"{fname}{ext}"
    if out_path.exists():
        item.cover_path = str(out_path)
        return

    # Download strategy:
    # - If plugin provided a browser_fetcher and marked cover_requires_browser, use it.
    # - Else use HTTP fetcher.
    try:
        if item.raw.get("cover_requires_browser") and ctx.get("browser_fetcher"):
            bf = ctx["browser_fetcher"]
            data = await bf.download_bytes(cover_url)
        else:
            from crawler.fetchers.http import HttpFetcher

            ua = str(ctx.get("network_user_agent") or "").strip() or None
            proxy = str(ctx.get("network_proxy_url") or "").strip() or None
            timeout_s = float(ctx.get("network_timeout_s") or 25)
            hf = HttpFetcher(user_agent=ua, proxy_url=proxy, timeout_s=timeout_s)
            cookies = item.raw.get("cover_cookies") if isinstance(item.raw, dict) else None
            data = await hf.get_bytes(cover_url, cookies=cookies)
        if data:
            await asyncio.to_thread(out_path.write_bytes, data)
            item.cover_path = str(out_path)
    except Exception as e:
        biz.warning(
            "⚠️ 封面下载失败：已跳过封面本地化，不影响条目入库。",
            来源=item.source,
            封面地址=cover_url,
            建议="检查封面地址是否可访问；如不需要封面落地，可设置 CRAWLER_COVER_DOWNLOAD=0。",
            exc=e,
        )


def next_backoff_sec(attempt: int) -> int:
    base = min(3600, int(10 * (2 ** max(0, attempt))))
    return base + random.randint(0, 3)


async def upsert_item(pool: PgPool, item: Item) -> str:
    """Upsert one crawler item into PostgreSQL (public.article).

    ✅ 数据唯一真源：article 数据库的 public.article 表（你现有的那张）。
    ✅ 字段严格对齐 public.article（tid/title/publish_date/...）。
    ✅ 富字段写入 public.article_meta.raw (jsonb) —— 方案 3.1。
    ✅ 不依赖 crawler.* 表；不做任何 DDL 初始化 crawler schema。

    幂等键优先使用 detail_url；若 detail_url 为空则降级为 (website,title,publish_date) 的组合，
    但这类记录可能无法完全避免重复（建议上游尽量提供 detail_url）。
    """

    import json as _json
    import hashlib as _hashlib

    # ------------------------ normalize ------------------------
    item.raw = item.raw or {}

    detail_url = (getattr(item, "detail_url", "") or "").strip() or None
    title = (getattr(item, "title", "") or "").strip() or ""

    publish_date = getattr(item, "publish_date", None)
    publish_time = getattr(item, "publish_time", None)
    if publish_date is None and publish_time:
        try:
            publish_date = getattr(publish_time, "date", lambda: None)()
        except Exception:
            publish_date = None

    magnet = (getattr(item, "magnet", "") or "").strip() or None
    if not magnet:
        # public.article 是“终态表”，只存可用数据（magnet 已获取）。
        # magnet 为空说明仍是半成品：应当留在 discovered/staging 或等待重试，而不是写入终态表。
        raise ValueError("missing magnet: refuse to write into public.article")

    preview_urls = getattr(item, "preview_urls", None) or []
    if not isinstance(preview_urls, list):
        preview_urls = []
    preview_urls = [str(x).strip() for x in preview_urls if str(x).strip()]
    preview_images = _json.dumps(preview_urls, ensure_ascii=False) if preview_urls else None

    section = _clean_section_name(getattr(item, "section", "") or "") or None
    category = _clean_section_name(getattr(item, "category", "") or "") or None
    # section 是 public.article 的必填字段（你现表中为 NOT NULL）。
    # 如果插件没给 section，则用 category 兜底；仍为空则拒绝写入终态表。
    if not section:
        section = category
    if not section:
        raise ValueError("missing section: refuse to write into public.article")

    website = (getattr(item, "website", "") or "").strip() or None
    if not website:
        website = (getattr(item, "source", "") or "").strip() or None

    # size: store MB as integer if possible
    size = None
    size_mb = getattr(item, "size_mb", None)
    try:
        if size_mb is not None:
            size = int(round(float(size_mb)))
    except Exception:
        size = None

    sub_type = (getattr(item, "sub_type", "") or "").strip() or None
    number = getattr(item, "number", None)
    try:
        if number is not None:
            number = int(number)
    except Exception:
        number = None

    # ------------------------ meta(raw) ------------------------
    meta = {
        "source": getattr(item, "source", None),
        "external_id": getattr(item, "external_id", None),
        "hash": getattr(item, "hash", None),
        "publish_time": str(publish_time) if publish_time is not None else None,
        "tags": getattr(item, "tags", None),
        "actors": getattr(item, "actors", None),
        "actors_text": getattr(item, "actors_text", None),
        "resolution": getattr(item, "resolution", None),
        "duration_sec": getattr(item, "duration_sec", None),
        "code": getattr(item, "code", None),
        "studio": getattr(item, "studio", None),
        "cover_url": getattr(item, "cover_url", None),
        "cover_path": getattr(item, "cover_path", None),
        "summary": getattr(item, "summary", None),
        "content": getattr(item, "content", None),
        "author": getattr(item, "author", None),
        "offline_status": getattr(item, "offline_status", None),
        "offline_method": getattr(item, "offline_method", None),
        "offline_job_id": getattr(item, "offline_job_id", None),
        "status": getattr(item, "status", None),
        "ingest_run_id": getattr(item, "ingest_run_id", None),
        "raw": item.raw,
    }
    meta = {k: v for k, v in meta.items() if v is not None}

    # -------------------------- upsert -------------------------
    fallback_key = f"{website or ''}|{title}|{publish_date or ''}"
    key = detail_url or fallback_key
    lk = int(_hashlib.sha1(key.encode("utf-8")).hexdigest()[:16], 16)

    async with pool.pool.acquire() as conn:
        async with conn.transaction():
            # 幂等：detail_url 优先；否则退化为 (website,title,publish_date)
            await conn.execute("SELECT pg_advisory_xact_lock($1)", lk)

            # ---- section governance (alias + directory) ----
            # 1) Resolve alias -> canonical (source-specific first, then global)
            try:
                r = await conn.fetchrow(
                    """
                    SELECT canonical_name
                    FROM public.crawler_section_alias
                    WHERE alias_name = $1
                      AND (source = $2 OR source = '')
                    ORDER BY (source = '') ASC
                    LIMIT 1
                    """,
                    section,
                    website or "",
                )
                if r and r.get("canonical_name"):
                    section = _clean_section_name(r["canonical_name"]) or section
            except Exception:
                # table might not exist on first boot; ignore
                pass

            # 2) Upsert directory record (enabled stays false by default)
            try:
                await conn.execute(
                    """
                    INSERT INTO public.crawler_section (source, name, last_seen_at)
                    VALUES ($1,$2,now())
                    ON CONFLICT (source, name) DO UPDATE SET last_seen_at = now()
                    """,
                    website or "",
                    section,
                )
            except Exception:
                pass

            tid: int | None = None

            if detail_url:
                # 最优路径：依赖 detail_url 的 UNIQUE 约束（在 crawler/db/ddl.sql 中已补齐）
                row = await conn.fetchrow(
                    """
                    INSERT INTO public.article
                      (title, publish_date, magnet, preview_images, detail_url, size,
                       section, category, website, create_time, update_time, sub_type, number)
                    VALUES
                      ($1, $2, $3, $4, $5, $6,
                       $7, $8, $9, now(), now(), $10, $11)
                    ON CONFLICT (detail_url) DO UPDATE SET
                      title = EXCLUDED.title,
                      publish_date = COALESCE(EXCLUDED.publish_date, public.article.publish_date),
                      magnet = EXCLUDED.magnet,
                      preview_images = COALESCE(NULLIF(EXCLUDED.preview_images,''), public.article.preview_images),
                      size = COALESCE(EXCLUDED.size, public.article.size),
                      section = COALESCE(NULLIF(EXCLUDED.section,''), public.article.section),
                      category = COALESCE(NULLIF(EXCLUDED.category,''), public.article.category),
                      website = COALESCE(NULLIF(EXCLUDED.website,''), public.article.website),
                      sub_type = COALESCE(NULLIF(EXCLUDED.sub_type,''), public.article.sub_type),
                      number = COALESCE(EXCLUDED.number, public.article.number),
                      update_time = now()
                    RETURNING tid
                    """,
                    title,
                    publish_date,
                    magnet,
                    preview_images or "",
                    detail_url,
                    size,
                    section or "",
                    category or "",
                    website or "",
                    sub_type or "",
                    number,
                )
                if row:
                    tid = int(row["tid"])

            if tid is None and not detail_url:
                # 退化路径：无 detail_url，尽量避免重复
                row = await conn.fetchrow(
                    """
                    UPDATE public.article
                    SET
                      magnet = $4,
                      preview_images = COALESCE(NULLIF($5,''), preview_images),
                      size = COALESCE($6, size),
                      section = COALESCE(NULLIF($7,''), section),
                      category = COALESCE(NULLIF($8,''), category),
                      website = COALESCE(NULLIF($9,''), website),
                      sub_type = COALESCE(NULLIF($10,''), sub_type),
                      number = COALESCE($11, number),
                      update_time = now()
                    WHERE title = $2
                      AND COALESCE(publish_date::text,'') = COALESCE($3::text,'')
                      AND COALESCE(website,'') = COALESCE($9,'')
                    RETURNING tid
                    """,
                    key,
                    title,
                    publish_date,
                    magnet,
                    preview_images or "",
                    size,
                    section or "",
                    category or "",
                    website or "",
                    sub_type or "",
                    number,
                )
                if row:
                    tid = int(row["tid"])

            if tid is None:
                row = await conn.fetchrow(
                    """
                    INSERT INTO public.article
                      (title, publish_date, magnet, preview_images, detail_url, size,
                       section, category, website, create_time, update_time, sub_type, number)
                    VALUES
                      ($1, $2, $3, $4, $5, $6,
                       $7, $8, $9, now(), now(), $10, $11)
                    RETURNING tid
                    """,
                    title,
                    publish_date,
                    magnet,
                    preview_images,
                    detail_url,
                    size,
                    section,
                    category,
                    website,
                    sub_type,
                    number,
                )
                tid = int(row["tid"])

            # Best-effort: write rich fields to public.article_meta.
            # Do NOT let meta write failures rollback the main `public.article` upsert.
            try:
                async with conn.transaction():  # savepoint
                    await conn.execute(
                        """
                        INSERT INTO public.article_meta (tid, raw, updated_time)
                        VALUES ($1, $2::jsonb, now())
                        ON CONFLICT (tid) DO UPDATE SET
                          raw = public.article_meta.raw || EXCLUDED.raw,
                          updated_time = now()
                        """,
                        tid,
                        meta,
                    )
            except Exception as e:
                biz.warning(
                    "article_meta upsert failed (ignored)",
                    extra={"tid": tid, "website": website, "detail_url": detail_url, "err": str(e)},
                )

            return str(tid)


async def run_discover_job(pool: PgPool, job: CrawlJob, ctx: dict[str, Any]) -> dict[str, Any]:
    """Run one discover job with human-readable, step-by-step business logs.

    Logs are designed for operators: what we did, why, what we got, and what to do if it fails.
    """
    plugins = get_plugins(ctx)
    plugin = plugins.get(job.source)
    if not plugin:
        return {"skipped": True, "reason": "plugin not found", "source": job.source}

    # Normalize params defensively (避免脏数据导致 worker 循环异常)
    raw_params = job.params or {}
    params: dict[str, Any] = raw_params if isinstance(raw_params, dict) else {"_raw": raw_params}

    # Inject stop_tid cursor from crawler_source_state (best-effort, only when not explicitly provided).
    discover_mode = str(params.get("discover_mode") or "stop_tid").strip()
    scope = _stop_tid_scope(job.source, params)
    if discover_mode == "stop_tid" and scope and not str(params.get("stop_tid") or "").strip():
        try:
            cursor = await get_source_cursor(pool, job.source, scope)
            last_tid = int(cursor.get("last_tid") or 0)
            if last_tid > 0:
                params["stop_tid"] = last_tid
                biz.detail("ℹ️ 已注入 stop_tid 游标：用于增量抓取（避免重复翻旧帖）。", 来源=job.source, scope=scope, stop_tid=last_tid)
        except Exception as e:
            biz.warning(
                "⚠️ 读取 stop_tid 游标失败：将退化为从第一页开始扫描（可能更慢，但仍可工作）。",
                来源=job.source,
                scope=scope,
                可能原因="crawler_source_state 表缺失/权限不足/数据库临时抖动。",
                建议="检查 crawler schema 是否完整，以及 PG 连接是否稳定。",
                exc=e,
            )

    plugin_ctx = dict(ctx)
    plugin_ctx["job"] = job
    plugin_ctx["params"] = params
    plugin_ctx["enqueue_job"] = lambda **kwargs: enqueue_job(pool, **kwargs)

    # Ensure staging table exists (idempotent)
    try:
        await ensure_discovered_table(pool)
    except Exception as e:
        suppress(site="crawler/run_job:ensure_discovered_table", exc=e, logger=biz, fallback=None)

    # Step 1: discover candidates
    with biz.group("步骤1/3：发现候选", 来源=job.source, 参数=params):
        biz.step("调用插件 discover() 拉取候选条目列表")
        cands: list[Candidate] = await plugin.discover(plugin_ctx)
        biz.ok(
            "✅ 候选列表已获取。",
            候选数=len(cands),
            说明="接下来会逐条抓取详情并入库；若候选缺少 magnet，将转入 detail 队列重试。",
        )

    # Step 2: fetch detail + persist
    saved = 0
    detail_enqueued = 0
    enqueued_offline = 0
    errors = 0
    total = len(cands)

    # Update progress total early (best-effort)
    try:
        from crawler.queue.jobs import mark_heartbeat
        await mark_heartbeat(pool, job.id, progress_done=0, progress_total=total)
    except Exception as e:
        suppress(site="crawler/run_job:heartbeat_init", exc=e, logger=biz, fallback=None)

    with biz.group("步骤2/3：处理候选并入库", 来源=job.source, 候选数=total):
        if total == 0:
            biz.warning(
                "⚠️ 本轮未发现任何候选：任务将直接结束。",
                可能原因="站点无新内容/站点结构改版导致解析失败/网络被拦截/代理失效。",
                建议="先在 UI 的日志页查看插件解析输出；必要时开启 BIZ_DETAIL=爬虫 查看更细节的请求/解析过程。",
            )

        for i, cand in enumerate(cands, 1):
            # sample per-item logs if huge (BizLogger 内部也有采样控制)
            biz.step("处理候选条目", i=i, total=total, 外部ID=str(getattr(cand, "external_id", "") or ""), 详情URL=str(getattr(cand, "detail_url", "") or ""))

            try:
                m = cand.meta or {}
                m_clean = _clean_meta_for_detail(m)

                # Staging record (discover)
                try:
                    title0 = str(m.get("title") or m.get("name") or m.get("subject") or cand.external_id or "").strip() or str(cand.external_id or "")
                    publish_date0 = m.get("publish_date") or m.get("date") or None
                    website0 = str(m.get("website") or job.source or "").strip() or None
                    section0 = str(m.get("section") or "").strip() or None
                    category0 = str(m.get("category") or "").strip() or None
                    previews = m.get("preview_urls") if isinstance(m.get("preview_urls"), list) else None
                    preview_images0 = json.dumps([str(x).strip() for x in (previews or []) if str(x).strip()], ensure_ascii=False) if previews else (str(m.get("preview_images") or "").strip() or None)
                    dkey = _discovered_key(detail_url=str(cand.detail_url or "").strip() or None, website=website0, external_id=str(cand.external_id or "").strip() or None, title=title0, publish_date=publish_date0)
                    await upsert_discovered(
                        pool,
                        key=dkey,
                        detail_url=str(cand.detail_url or "").strip() or None,
                        external_id=str(cand.external_id or "").strip() or None,
                        title=title0,
                        publish_date=publish_date0,
                        website=website0,
                        section=section0,
                        category=category0,
                        preview_images=preview_images0,
                        raw={"source": job.source, "candidate_meta": m_clean},
                        status="discovered",
                    )
                except Exception as e:
                    suppress(site="crawler/run_job:upsert_discovered", exc=e, logger=biz, fallback=None)

                # Candidate has no magnet yet: enqueue detail job
                if (not str(m.get("magnet") or "").strip()) and str(m.get("fetch_url") or "").strip():
                    # Update staging status
                    try:
                        await upsert_discovered(
                            pool,
                            key=dkey,
                            detail_url=str(cand.detail_url or "").strip() or None,
                            external_id=str(cand.external_id or "").strip() or None,
                            title=title0,
                            publish_date=publish_date0,
                            website=website0,
                            section=section0,
                            category=category0,
                            preview_images=preview_images0,
                            raw={"source": job.source, "candidate_meta": m_clean},
                            status="detail_queued",
                        )
                    except Exception as e:
                        suppress(site="crawler/run_job:mark_detail_queued", exc=e, logger=biz, fallback=None)
                    await enqueue_job(
                        pool,
                        queue=getattr(plugin, "prefer_detail_queue", "browser"),
                        source=job.source,
                        kind="detail",
                        params={"candidate": {"external_id": cand.external_id, "detail_url": cand.detail_url, "meta": m_clean}},
                    )
                    detail_enqueued += 1
                    biz.ok("✅ 已转入 detail 队列：候选缺少 magnet，需要详情页二次解析。", 外部ID=str(cand.external_id or ""), 队列=getattr(plugin, "prefer_detail_queue", "browser"))
                    continue

                # Fetch detail
                with biz.group("抓取详情并入库", 外部ID=str(getattr(cand, "external_id", "") or "")):
                    biz.step("调用插件 fetch_detail() 解析详情页", 详情URL=str(getattr(cand, "detail_url", "") or ""))
                    item: Item = await plugin.fetch_detail(plugin_ctx, cand)

                    biz.step("下载封面（如有）并写入数据库")
                    await _download_cover_if_needed(ctx, item)
                    tid_str = await upsert_item(pool, item)
                    saved += 1
                    biz.ok("✅ 入库完成。", 入库数=saved)

                    # 成功 materialize 到 public.article 后，回写 staging 状态（best-effort）
                    try:
                        await upsert_discovered(
                            pool,
                            key=dkey,
                            detail_url=str(cand.detail_url or "").strip() or None,
                            external_id=str(cand.external_id or "").strip() or None,
                            title=title0,
                            publish_date=publish_date0,
                            website=website0,
                            section=section0,
                            category=category0,
                            preview_images=preview_images0,
                            raw={"source": job.source, "candidate_meta": m_clean},
                            status="materialized",
                            tid=int(tid_str),
                        )
                    except Exception as e:
                        suppress(site="crawler/run_job:mark_materialized", exc=e, logger=biz, fallback=None)

                # progress heartbeat (best-effort, avoid too frequent writes)
                if i == total or i % 10 == 0:
                    try:
                        from crawler.queue.jobs import mark_heartbeat
                        await mark_heartbeat(pool, job.id, progress_done=i, progress_total=total)
                    except Exception as e:
                        suppress(site="crawler/run_job:heartbeat_progress", exc=e, logger=biz, fallback=None)

            except Exception as e:
                errors += 1
                # Mark staging as failed (best-effort)
                try:
                    if 'dkey' in locals():
                        await upsert_discovered(
                            pool,
                            key=dkey,
                            detail_url=str(getattr(cand, 'detail_url', '') or '').strip() or None,
                            external_id=str(getattr(cand, 'external_id', '') or '').strip() or None,
                            title=str((cand.meta or {}).get('title') or (cand.meta or {}).get('name') or cand.external_id or ''),
                            publish_date=(cand.meta or {}).get('publish_date') or None,
                            website=str((cand.meta or {}).get('website') or job.source or '').strip() or None,
                            section=str((cand.meta or {}).get('section') or '').strip() or None,
                            category=str((cand.meta or {}).get('category') or '').strip() or None,
                            preview_images=None,
                            raw={"source": job.source},
                            status='failed',
                            last_error=str(e)[:800],
                        )
                except Exception as e3:
                    suppress(site="crawler/run_job:mark_discovered_failed", exc=e3, logger=biz, fallback=None)
                # Fallback: enqueue a detail job so it can retry with job-level retries.
                try:
                    m = cand.meta or {}
                    m_clean = _clean_meta_for_detail(m)
                    await enqueue_job(
                        pool,
                        queue=getattr(plugin, "prefer_detail_queue", getattr(plugin, "prefer_queue", "browser")),
                        source=job.source,
                        kind="detail",
                        params={"candidate": {"external_id": cand.external_id, "detail_url": cand.detail_url, "meta": m_clean}},
                    )
                    detail_enqueued += 1
                except Exception as e2:
                    suppress(site="crawler/run_job:enqueue_detail_fallback", exc=e2, logger=biz, fallback=None)

                biz.warning(
                    "⚠️ 候选条目处理失败：已记录错误并尝试转入 detail 队列重试，其它候选将继续处理。",
                    来源=job.source,
                    外部ID=str(getattr(cand, "external_id", "") or ""),
                    可能原因="站点结构变化/网络波动/反爬拦截/解析规则不兼容。",
                    建议="查看异常栈定位具体字段；若持续失败，先手动打开详情页确认 HTML 是否变化。",
                    exc=e,
                )

    # Step 3: persist cursor (best-effort)
    with biz.group("步骤3/3：更新游标与扫描状态", 来源=job.source, 模式=discover_mode, scope=scope):
        if discover_mode == "stop_tid" and scope:
            try:
                max_tid = 0
                for c in cands:
                    if str(c.external_id or "").isdigit():
                        max_tid = max(max_tid, int(c.external_id))
                if max_tid > 0:
                    await update_source_cursor_max_int(pool, job.source, scope, "last_tid", max_tid)
                await merge_source_cursor(pool, job.source, scope, {"last_scan_at": utc_now_iso_z(timespec="seconds")})
                biz.ok("✅ 游标已更新：下次将从最新位置继续增量扫描。", last_tid=max_tid)
            except Exception as e:
                biz.warning(
                    "⚠️ 更新游标失败：不会影响本次入库结果，但下次可能会重复扫描旧内容。",
                    可能原因="crawler_source_state 表缺失/权限不足/数据库写入失败。",
                    建议="检查 PG 权限与 schema；修复后可再次运行以恢复增量扫描。",
                    exc=e,
                )
        else:
            biz.info("ℹ️ 本源未启用 stop_tid 游标模式：无需更新游标。", 说明="by_date 或其它模式通常无需维护 last_tid。")

    return {
        "source": job.source,
        "candidates": len(cands),
        "saved": saved,
        "detail_enqueued": detail_enqueued,
        "offline_enqueued": enqueued_offline,
        "errors": errors,
    }


async def run_detail_job(pool: PgPool, job: CrawlJob, ctx: dict[str, Any]) -> dict[str, Any]:
    """Run one detail job (retryable) with step-by-step logs."""
    plugins = get_plugins(ctx)
    plugin = plugins.get(job.source)
    if not plugin:
        return {"skipped": True, "reason": "plugin not found", "source": job.source}

    params = job.params or {}
    if not isinstance(params, dict):
        params = {"_raw": params}

    c = params.get("candidate") or {}
    if not isinstance(c, dict):
        c = {"_raw": c}

    cand = Candidate(
        external_id=str(c.get("external_id") or ""),
        detail_url=str(c.get("detail_url") or ""),
        meta=dict(c.get("meta") or {}) if isinstance(c.get("meta") or {}, dict) else {},
    )

    plugin_ctx = dict(ctx)
    plugin_ctx["job"] = job
    plugin_ctx["params"] = params
    plugin_ctx["enqueue_job"] = lambda **kwargs: enqueue_job(pool, **kwargs)

    # Ensure staging table exists (idempotent)
    try:
        await ensure_discovered_table(pool)
    except Exception as e:
        suppress(site="crawler/detail_job:ensure_discovered_table", exc=e, logger=biz, fallback=None)

    # Prepare staging key
    m0 = cand.meta or {}
    title0 = str(m0.get("title") or m0.get("name") or m0.get("subject") or cand.external_id or "").strip() or str(cand.external_id or "")
    publish_date0 = m0.get("publish_date") or m0.get("date") or None
    website0 = str(m0.get("website") or job.source or "").strip() or None
    dkey = _discovered_key(detail_url=str(cand.detail_url or "").strip() or None, website=website0, external_id=str(cand.external_id or "").strip() or None, title=title0, publish_date=publish_date0)

    with biz.group("详情任务：抓取并入库", 来源=job.source, 外部ID=cand.external_id or "", 详情URL=cand.detail_url or ""):
        try:
            biz.step("调用插件 fetch_detail() 解析详情页")
            item = await plugin.fetch_detail(plugin_ctx, cand)

            biz.step("下载封面（如有）并写入数据库")
            await _download_cover_if_needed(ctx, item)
            tid_str = await upsert_item(pool, item)

            # Mark staging as materialized
            try:
                await upsert_discovered(
                    pool,
                    key=dkey,
                    detail_url=str(cand.detail_url or "").strip() or None,
                    external_id=str(cand.external_id or "").strip() or None,
                    title=title0,
                    publish_date=publish_date0,
                    website=website0,
                    section=str(m0.get("section") or "").strip() or None,
                    category=str(m0.get("category") or "").strip() or None,
                    preview_images=None,
                    raw={"source": job.source, "candidate_meta": _clean_meta_for_detail(m0)},
                    status="materialized",
                    tid=int(tid_str),
                )
            except Exception as e:
                suppress(site="crawler/detail_job:mark_materialized", exc=e, logger=biz, fallback=None)

            biz.ok("✅ 详情入库完成。")
        except Exception as e:
            # Mark staging as failed then re-raise so job retry机制生效
            try:
                await upsert_discovered(
                    pool,
                    key=dkey,
                    detail_url=str(cand.detail_url or "").strip() or None,
                    external_id=str(cand.external_id or "").strip() or None,
                    title=title0,
                    publish_date=publish_date0,
                    website=website0,
                    section=str(m0.get("section") or "").strip() or None,
                    category=str(m0.get("category") or "").strip() or None,
                    preview_images=None,
                    raw={"source": job.source},
                    status="failed",
                    last_error=str(e)[:800],
                )
            except Exception as e2:
                suppress(site="crawler/detail_job:mark_failed", exc=e2, logger=biz, fallback=None)
            raise

    return {"source": job.source, "kind": "detail", "saved": 1, "offline_enqueued": 0}


async def run_job(pool: PgPool, job: CrawlJob, ctx: dict[str, Any]) -> dict[str, Any]:
    if job.kind == "discover":
        return await run_discover_job(pool, job, ctx)
    if job.kind == "detail":
        return await run_detail_job(pool, job, ctx)
    return {"skipped": True}
