from __future__ import annotations

import hashlib
import re
from urllib.parse import parse_qs, urlparse

from core.suppress import suppress

_BTIH_RE = re.compile(r"btih:([A-Fa-f0-9]{40}|[A-Za-z2-7]{32})")


def magnet_hash(magnet: str) -> str:
    """Extract btih hash from magnet link.

    Returns lowercase hex if possible; otherwise returns empty string.
    """
    m = (magnet or "").strip()
    if not m:
        return ""
    m2 = _BTIH_RE.search(m)
    if m2:
        h = m2.group(1)
        return h.lower()
    # Some magnets might hide btih in query params
    try:
        u = urlparse(m)
        qs = parse_qs(u.query)
        for k, vs in qs.items():
            if k.lower() in ("xt", "dn"):
                for v in vs:
                    mm = _BTIH_RE.search(v)
                    if mm:
                        return mm.group(1).lower()
    except Exception as e:
        suppress(site="crawler/dedup:magnet_hash_parse", exc=e, fallback=None)
    return ""


def stable_fingerprint(source: str, external_id: str, title: str) -> str:
    """Fallback fingerprint when no magnet_hash.

    This is only used for logging/debug; DB-level de-dup is enforced by
    UNIQUE(source, external_id).
    """
    s = f"{source}:{external_id}:{title}".encode("utf-8", "ignore")
    return hashlib.sha1(s).hexdigest()
