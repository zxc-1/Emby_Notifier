from __future__ import annotations

import json

from typing import Any, Optional

from core.logging import get_biz_logger

from crawler.db.pg import PgPool
from crawler.models.types import CrawlJob


biz = get_biz_logger(__name__)


def _safe_params(v: Any) -> dict[str, Any]:
    """Normalize job.params to a dict.

    Root-cause fix for: `dictionary update sequence element #0 has length 1; 2 is required`
    which happens when params is stored as list/str/etc.
    """
    if v is None:
        return {}
    if isinstance(v, dict):
        return v
    # asyncpg may return JSONB as str in some edge cases; try JSON parse
    if isinstance(v, (str, bytes)):
        try:
            s = v.decode("utf-8") if isinstance(v, bytes) else v
            s = (s or "").strip()
            if not s:
                return {}
            obj = json.loads(s)
            if isinstance(obj, dict):
                return obj
            return {"_raw": obj}
        except Exception as e:
            biz.detail("ignored exception in _safe_params", exc_info=True)
            return {"_raw": str(v)}
    # list/tuple -> wrap
    if isinstance(v, (list, tuple)):
        return {"_raw": list(v)}
    return {"_raw": str(v)}


PICK_JOB_SQL = """
WITH picked AS (
  SELECT id
  FROM crawler.crawler_jobs
  WHERE status='pending'
    AND run_after <= now()
    AND queue = $1
  ORDER BY run_after ASC, created_at ASC
  FOR UPDATE SKIP LOCKED
  LIMIT 1
)
UPDATE crawler.crawler_jobs j
SET status='running',
    locked_at=now(),
    heartbeat_at=now(),
    lock_owner=$2,
    updated_at=now()
FROM picked
WHERE j.id = picked.id
RETURNING j.*;
"""


async def pick_one_job(pool: PgPool, queue: str, worker_id: str) -> Optional[CrawlJob]:
    row = await pool.fetchrow(PICK_JOB_SQL, queue, worker_id)
    if not row:
        return None
    return CrawlJob(
        id=str(row.get("id")),
        queue=row.get("queue"),
        source=row.get("source"),
        kind=row.get("kind"),
        params=_safe_params(row.get("params")),
        attempt=int(row.get("attempt") or 0),
    )


async def mark_done(pool: PgPool, job_id: str, result: Any) -> None:
    sql = """
    UPDATE crawler.crawler_jobs
    SET status='done',
        updated_at=now(),
        last_error=NULL,
        progress_done=progress_total,

        -- reset runtime fields so the row can be safely re-used by planner
        attempt=0,
        locked_at=NULL,
        lock_owner=NULL,
        heartbeat_at=NULL
    WHERE id=$1;
    """
    await pool.execute(sql, job_id)


async def mark_heartbeat(
    pool: PgPool,
    job_id: str,
    *,
    progress_done: int | None = None,
    progress_total: int | None = None,
) -> None:
    """Refresh heartbeat for a running job.

    This prevents "stuck running" tasks when a worker is still alive but the
    job takes longer than the reaper threshold.
    """

    sql = """
    UPDATE crawler.crawler_jobs
    SET heartbeat_at=now(),
        updated_at=now(),
        progress_done=COALESCE($2, progress_done),
        progress_total=COALESCE($3, progress_total)
    WHERE id=$1 AND status='running';
    """
    await pool.execute(sql, job_id, progress_done, progress_total)


async def mark_failed(pool: PgPool, job_id: str, *, attempt: int, next_delay_sec: int, error: str) -> None:
    sql = """
    UPDATE crawler.crawler_jobs
    SET attempt=attempt+1,
        status=CASE WHEN (attempt+1) >= max_attempt THEN 'failed' ELSE 'pending' END,
        run_after=CASE WHEN (attempt+1) >= max_attempt THEN run_after ELSE now() + make_interval(secs => $2) END,
        locked_at=NULL,
        lock_owner=NULL,
        heartbeat_at=NULL,
        updated_at=now(),
        last_error=$3
    WHERE id=$1;
    """
    await pool.execute(sql, job_id, int(next_delay_sec), str(error)[:4000])
