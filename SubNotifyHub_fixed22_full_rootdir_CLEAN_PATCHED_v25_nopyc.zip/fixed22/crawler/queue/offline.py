from __future__ import annotations

from typing import Optional

from core.logging import get_biz_logger

from crawler.db.pg import PgPool

biz = get_biz_logger(__name__)

PICK_OFFLINE_SQL = """
WITH picked AS (
  SELECT id
  FROM crawler.crawler_offline_tasks
  WHERE status='pending'
    AND run_after <= now()
  ORDER BY run_after ASC, created_at ASC
  FOR UPDATE SKIP LOCKED
  LIMIT 1
)
UPDATE crawler.crawler_offline_tasks t
SET status='running',
    locked_at=now(),
    lock_owner=$1,
    updated_at=now()
FROM picked
WHERE t.id = picked.id
RETURNING t.*
"""


async def pick_one_offline_task(pool: PgPool, worker_id: str) -> Optional[dict]:
    row = await pool.fetchone(PICK_OFFLINE_SQL, worker_id)
    return row


async def mark_offline_success(pool: PgPool, task_id: str) -> None:
    await pool.execute(
        "UPDATE crawler.crawler_offline_tasks SET status='success', updated_at=now() WHERE id=$1",
        task_id,
    )


async def mark_offline_failed(pool: PgPool, task_id: str, *, error: str, next_run_after_sec: int, attempt_inc: int = 1) -> None:
    await pool.execute(
        """
        UPDATE crawler.crawler_offline_tasks
        SET status='pending',
            attempt=attempt+$2,
            run_after=now()+make_interval(secs => $3),
            last_error=$4,
            updated_at=now()
        WHERE id=$1
        """,
        task_id,
        attempt_inc,
        int(next_run_after_sec),
        error[:2000],
    )
