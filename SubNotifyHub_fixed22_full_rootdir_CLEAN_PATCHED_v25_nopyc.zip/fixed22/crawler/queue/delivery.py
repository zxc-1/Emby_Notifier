from __future__ import annotations

from typing import Any
import json
from datetime import datetime
from core.time_utils import utc_now_iso_z

from crawler.db.pg import PgPool


async def pick_one_delivery_task(pool: PgPool, *, deliver_to: str, owner: str) -> dict[str, Any] | None:
    sql = """
    UPDATE crawler.crawler_delivery_tasks t
    SET status='running', locked_at=now(), lock_owner=$2, updated_at=now()
    WHERE t.id = (
        SELECT id
        FROM crawler.crawler_delivery_tasks
        WHERE deliver_to=$1 AND status='pending' AND run_after <= now()
        ORDER BY created_at ASC
        FOR UPDATE SKIP LOCKED
        LIMIT 1
    )
    RETURNING t.*
    """
    row = await pool.fetchone_optional(sql, deliver_to, owner)
    return dict(row) if row else None


async def mark_delivery_success(pool: PgPool, task_id: str) -> None:
    await pool.execute(
        """
        UPDATE crawler.crawler_delivery_tasks
        SET status='success',
            attempt=0,
            locked_at=NULL,
            lock_owner=NULL,
            last_error=NULL,
            updated_at=now()
        WHERE id=$1
        """,
        task_id,
    )


async def mark_delivery_submitted(
    pool: PgPool,
    *,
    task_id: str,
    remote_kind: str,
    remote_backend: str,
    remote_task_id: str,
    remote_status: str = "pending",
    next_poll_after_sec: int = 5,
) -> None:
    """Mark a delivery task as "submitted" (accepted by external system).

    Important: submitted != success.
    This prevents the submit worker from re-submitting the same task.
    """

    await pool.execute(
        """
        UPDATE crawler.crawler_delivery_tasks
        SET status='submitted',
            locked_at=NULL,
            lock_owner=NULL,
            last_error=NULL,
            submitted_at=COALESCE(submitted_at, now()),
            remote_kind=$2,
            remote_backend=$3,
            remote_task_id=$4,
            remote_status=$5,
            remote_progress=COALESCE(remote_progress, 0),
            next_poll_at=now() + make_interval(secs => $6),
            poll_attempts=0,
            updated_at=now()
        WHERE id=$1
        """,
        task_id,
        str(remote_kind or ""),
        str(remote_backend or ""),
        str(remote_task_id or ""),
        str(remote_status or "pending"),
        int(next_poll_after_sec),
    )


async def pick_tasks_to_poll(pool: PgPool, *, deliver_to: str, limit: int = 50) -> list[dict[str, Any]]:
    """Pick submitted tasks that are due for polling.

    This is used by CD2/115 pollers (submitted -> success/failed).
    """
    rows = await pool.fetchall(
        """
        SELECT *
        FROM crawler.crawler_delivery_tasks
        WHERE deliver_to=$1
          AND status='submitted'
          AND remote_task_id IS NOT NULL AND remote_task_id <> ''
          AND COALESCE(next_poll_at, now()) <= now()
        ORDER BY COALESCE(next_poll_at, created_at) ASC
        LIMIT $2
        """,
        str(deliver_to or ""),
        int(limit),
    )
    return [dict(r) for r in rows]


async def cd2_pick_tasks_to_poll(pool: PgPool, *, limit: int = 50) -> list[dict[str, Any]]:
    """Pick CD2 submitted tasks that are due for polling."""
    return await pick_tasks_to_poll(pool, deliver_to='cd2', limit=limit)


async def cd2_update_poll_result(
    pool: PgPool,
    *,
    task_id: str,
    remote_status: str,
    remote_progress: int | None = None,
    remote_error_code: str | None = None,
    remote_error_msg: str | None = None,
    result_paths: Any | None = None,
    next_poll_after_sec: int | None = None,
    terminal: bool = False,
) -> None:
    # terminal: set status success/failed and finished_at
    sets = [
        "remote_status=$2",
        "last_polled_at=now()",
        "poll_attempts=poll_attempts+1",
        "updated_at=now()",
    ]
    args: list[Any] = [task_id, str(remote_status or "unknown")]
    idx = 3
    if remote_progress is not None:
        sets.append(f"remote_progress=${idx}")
        args.append(int(remote_progress))
        idx += 1
    if remote_error_code is not None:
        sets.append(f"remote_error_code=${idx}")
        args.append(str(remote_error_code))
        idx += 1
    if remote_error_msg is not None:
        sets.append(f"remote_error_msg=${idx}")
        args.append(str(remote_error_msg))
        idx += 1
    if result_paths is not None:
        sets.append(f"result_paths=${idx}::jsonb")
        args.append(json.dumps(result_paths, ensure_ascii=False))
        idx += 1
    if terminal:
        # map remote terminal to local terminal
        if str(remote_status) == "success":
            sets.append("status='success'")
        else:
            sets.append("status='failed'")
        sets.append("finished_at=now()")
        sets.append("next_poll_at=NULL")
    else:
        if next_poll_after_sec is not None:
            sets.append(f"next_poll_at=now() + make_interval(secs => ${idx})")
            args.append(int(next_poll_after_sec))
            idx += 1

    sql = f"UPDATE crawler.crawler_delivery_tasks SET {', '.join(sets)} WHERE id=$1"
    await pool.execute(sql, *args)



async def mark_delivery_failed(
    pool: PgPool,
    task_or_id: str | dict[str, Any],
    *,
    error: str,
    next_run_after_sec: int,
) -> None:
    """Reschedule a delivery task.

    - Accepts either a task_id (str) or a task dict.
    - If task.meta contains fallback candidates, it will automatically switch
      to the next candidate when the current one exceeds its retry budget.
    """

    if task_or_id is None:
        return

    task: dict[str, Any]
    if isinstance(task_or_id, str):
        task = {"id": task_or_id}
    else:
        task = task_or_id

    task_id = str(task.get("id"))
    meta = task.get("meta") or {}
    if isinstance(meta, str):
        try:
            meta = json.loads(meta) or {}
        except Exception:
            meta = {}
    candidates = meta.get("candidates") or []

    if not isinstance(candidates, list) or not candidates:
        await pool.execute(
            """
            UPDATE crawler.crawler_delivery_tasks
            SET attempt=attempt+1,
                status=CASE WHEN (attempt+1) >= max_attempt THEN 'failed' ELSE 'pending' END,
                run_after=CASE WHEN (attempt+1) >= max_attempt THEN run_after ELSE now() + make_interval(secs => $3) END,
                locked_at=NULL,
                lock_owner=NULL,
                last_error=$2,
                updated_at=now()
            WHERE id=$1
            """,
            task_id,
            error,
            int(next_run_after_sec),
        )
        return

    cand_idx = int(meta.get("candidate_index") or 0)
    cand_attempt = int(meta.get("candidate_attempt") or 0) + 1
    cand_max = int(meta.get("candidate_max_attempt") or 2)

    meta["candidate_attempt"] = cand_attempt
    attempts = meta.get("attempts")
    if not isinstance(attempts, list):
        attempts = []
    attempts.append({
        "ts": utc_now_iso_z(timespec="seconds"),
        "item_id": str(task.get("item_id") or ""),
        "result": "failed",
        "error": str(error or "")[:500],
    })
    meta["attempts"] = attempts

    # retry same candidate
    if cand_attempt < cand_max:
        await pool.execute(
            """
            UPDATE crawler.crawler_delivery_tasks
            SET attempt=attempt+1,
                status=CASE WHEN (attempt+1) >= max_attempt THEN 'failed' ELSE 'pending' END,
                run_after=CASE WHEN (attempt+1) >= max_attempt THEN run_after ELSE now() + make_interval(secs => $3) END,
                locked_at=NULL,
                lock_owner=NULL,
                last_error=$2,
                meta=$4::jsonb,
                updated_at=now()
            WHERE id=$1
            """,
            task_id,
            error,
            int(next_run_after_sec),
            json.dumps(meta, ensure_ascii=False),
        )
        return

    # switch candidate
    next_idx = cand_idx + 1
    deliver_to = str(task.get("deliver_to") or "")
    save_path = str(task.get("save_path") or "")

    while next_idx < len(candidates):
        cand = candidates[next_idx] or {}
        new_item_id = str(cand.get("item_id") or "")
        new_magnet = str(cand.get("magnet") or "")
        if not new_item_id or not new_magnet:
            next_idx += 1
            continue

        exists = await pool.fetchone_optional(
            """
            SELECT 1 FROM crawler.crawler_delivery_tasks
            WHERE item_id=$1 AND deliver_to=$2 AND save_path=$3 AND id<>$4
            LIMIT 1
            """,
            new_item_id, deliver_to, save_path, task_id
        )
        if exists:
            next_idx += 1
            continue

        meta["candidate_index"] = next_idx
        meta["candidate_attempt"] = 0

        await pool.execute(
            """
            UPDATE crawler.crawler_delivery_tasks
            SET attempt=attempt+1,
                status=CASE WHEN (attempt+1) >= max_attempt THEN 'failed' ELSE 'pending' END,
                run_after=CASE WHEN (attempt+1) >= max_attempt THEN run_after ELSE now() END,
                locked_at=NULL,
                lock_owner=NULL,
                last_error=$2,
                item_id=$3,
                magnet=$4,
                meta=$5::jsonb,
                updated_at=now()
            WHERE id=$1
            """,
            task_id,
            f"{error} | fallback_to_{next_idx}",
            new_item_id,
            new_magnet,
            json.dumps(meta, ensure_ascii=False),
        )
        return

    # exhausted
    await pool.execute(
        """
        UPDATE crawler.crawler_delivery_tasks
        SET status='failed',
            attempt=attempt+1,
            last_error=$2,
            meta=$3::jsonb,
            updated_at=now()
        WHERE id=$1
        """,
        task_id,
        f"{error} | fallback_exhausted",
        json.dumps(meta, ensure_ascii=False),
    )
