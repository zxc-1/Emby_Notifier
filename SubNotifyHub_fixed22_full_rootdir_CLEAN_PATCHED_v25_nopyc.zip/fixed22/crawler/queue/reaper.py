from __future__ import annotations

import asyncio

from core.logging import get_biz_logger

from crawler.config import load_crawler_config
from crawler.db.pg import PgPool


biz = get_biz_logger(__name__)


async def reap_stale_jobs(
    pool: PgPool,
    *,
    stale_after_s: int,
    reschedule_delay_s: int,
) -> list[dict]:
    """Reap crawler.crawler_jobs stuck in 'running' with stale heartbeat."""

    sql = """
    WITH stale AS (
      SELECT id
      FROM crawler.crawler_jobs
      WHERE status='running'
        AND heartbeat_at IS NOT NULL
        AND heartbeat_at < now() - make_interval(secs => $1)
      ORDER BY heartbeat_at ASC
      FOR UPDATE SKIP LOCKED
      LIMIT 200
    )
    UPDATE crawler.crawler_jobs j
    SET attempt=j.attempt+1,
        status=CASE WHEN (j.attempt+1) >= j.max_attempt THEN 'failed' ELSE 'pending' END,
        run_after=CASE WHEN (j.attempt+1) >= j.max_attempt THEN j.run_after ELSE now() + make_interval(secs => $2) END,
        locked_at=NULL,
        lock_owner=NULL,
        heartbeat_at=NULL,
        updated_at=now(),
        last_error=left(coalesce(j.last_error,'') || ' | reaped_stale_heartbeat', 4000)
    FROM stale
    WHERE j.id = stale.id
    RETURNING j.id, j.queue, j.source, j.kind, j.attempt, j.max_attempt;
    """

    rows = await pool.fetchall(sql, int(stale_after_s), int(reschedule_delay_s))
    return rows or []


async def reap_stale_delivery_tasks(
    pool: PgPool,
    *,
    stale_after_s: int,
    reschedule_delay_s: int,
) -> list[dict]:
    """Reap crawler.crawler_delivery_tasks stuck in 'running'."""

    # NOTE: use make_interval(secs => $2) so Postgres/asyncpg infer $2 as integer.
    # Avoid patterns like ($2 || ' seconds')::interval which infer TEXT and then
    # asyncpg throws: expected str, got int.
    sql = """
    WITH stale AS (
      SELECT id
      FROM crawler.crawler_delivery_tasks
      WHERE status='running'
        AND locked_at IS NOT NULL
        AND locked_at < now() - make_interval(secs => $1)
      ORDER BY locked_at ASC
      FOR UPDATE SKIP LOCKED
      LIMIT 200
    )
    UPDATE crawler.crawler_delivery_tasks t
    SET attempt=t.attempt+1,
        status=CASE WHEN (t.attempt+1) >= t.max_attempt THEN 'failed' ELSE 'pending' END,
        run_after=CASE WHEN (t.attempt+1) >= t.max_attempt THEN t.run_after ELSE now() + make_interval(secs => $2) END,
        locked_at=NULL,
        lock_owner=NULL,
        updated_at=now(),
        last_error=left(coalesce(t.last_error,'') || ' | reaped_stale_lock', 4000)
    FROM stale
    WHERE t.id = stale.id
    RETURNING t.id, t.deliver_to, t.item_id, t.attempt, t.max_attempt;
    """

    rows = await pool.fetchall(sql, int(stale_after_s), int(reschedule_delay_s))
    return rows or []


async def reaper_loop(pool: PgPool, *, stop_event: asyncio.Event) -> None:
    """Background reaper to recover 'running' tasks after worker crash/hang.

    - Uses crawler.runtime.* config (env + UI overrides).
    - Runs continuously; safe to keep enabled even on small instances.
    """

    while not stop_event.is_set():
        try:
            cfg = load_crawler_config()
            if not cfg.enabled:
                # Crawler is paused; don't touch job states.
                await asyncio.sleep(1.0)
                continue

            stale_jobs = await reap_stale_jobs(
                pool,
                stale_after_s=int(cfg.job_stale_timeout_s),
                reschedule_delay_s=max(10, int(cfg.poll_interval_ms // 1000) + 3),
            )
            stale_delivery = await reap_stale_delivery_tasks(
                pool,
                stale_after_s=int(cfg.delivery_stale_timeout_s),
                reschedule_delay_s=max(30, int(cfg.poll_interval_ms // 1000) + 10),
            )

            if stale_jobs:
                biz.warning(
                    "⚠️ Reaper 回收了卡死的爬虫任务（running 但 heartbeat 超时）。",
                    数量=len(stale_jobs),
                    超时秒=int(cfg.job_stale_timeout_s),
                )
            if stale_delivery:
                biz.warning(
                    "⚠️ Reaper 回收了卡死的投递任务（running 但锁超时）。",
                    数量=len(stale_delivery),
                    超时秒=int(cfg.delivery_stale_timeout_s),
                )

        except asyncio.CancelledError:
            raise
        except Exception as e:
            biz.warning(
                "⚠️ Reaper 循环执行失败（已忽略，将在下一轮继续）。",
                建议="若频繁出现请检查 PostgreSQL 连接是否正常、crawler schema 是否存在。",
                exc=e,
            )

        # sleep (hot reload interval)
        try:
            cfg = load_crawler_config()
            interval = max(10, int(getattr(cfg, "reaper_interval_s", 60) or 60))
        except Exception:
            interval = 60
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=float(interval))
        except asyncio.TimeoutError:
            continue