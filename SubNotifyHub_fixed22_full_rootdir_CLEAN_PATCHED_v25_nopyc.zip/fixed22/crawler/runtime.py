from __future__ import annotations

import asyncio
import os
import socket
from typing import Any

from core.logging import get_biz_logger
from core.suppress import suppress

from crawler.config import load_crawler_config
from crawler.db.pg import PgPool, PgUnavailable, create_pg_pool, run_ddl
from crawler.scheduler.planner import planner_tick
from crawler.pipeline.run_job import run_job, next_backoff_sec
from crawler.queue.jobs import pick_one_job, mark_done, mark_failed, mark_heartbeat
from crawler.fetchers.browser import BrowserFetcher, BrowserUnavailable

biz = get_biz_logger(__name__)


async def _ensure_pool(app_state: Any) -> PgPool:
    pool = getattr(app_state, "crawler_pg_pool", None)
    if pool is not None:
        return pool

    cfg = load_crawler_config()
    dsn = str(getattr(cfg, "pg_dsn", "") or "").strip()
    if not dsn:
        raise RuntimeError("CRAWLER_PG_DSN is empty; cannot run crawler")

    try:
        pool = await create_pg_pool(dsn, min_size=1, max_size=max(2, int(cfg.http_concurrency or 2)))
    except PgUnavailable as e:
        raise RuntimeError(f"PostgreSQL unavailable: {e}") from e

    ddl_path = os.path.join(os.path.dirname(__file__), "db", "ddl.sql")
    await run_ddl(pool, ddl_path)
    try:
        setattr(app_state, "crawler_pg_pool", pool)
    except Exception as e:
        suppress(site="crawler/runtime:expose_pg_pool", exc=e, logger=biz, fallback=None)
    return pool


def _build_ctx(cfg) -> dict[str, Any]:
    # Minimal runtime context for plugins/pipeline.
    ctx: dict[str, Any] = {
        "rsshub_host": cfg.rsshub_host,
        "t66y_sections": cfg.t66y_sections,
        "javbus_categories": cfg.javbus_categories,
        "flaresolverr_url": cfg.flaresolverr_url,
        "network_user_agent": cfg.network_user_agent,
        "network_proxy_url": cfg.network_proxy_url,
        "network_timeout_s": int(cfg.network_timeout_s),
        "heartbeat_interval_s": int(cfg.heartbeat_interval_s),
        "job_stale_timeout_s": int(cfg.job_stale_timeout_s),
        "delivery_stale_timeout_s": int(cfg.delivery_stale_timeout_s),
        "reaper_interval_s": int(cfg.reaper_interval_s),
        "sehuatang_page_limit": int(cfg.sehuatang_page_limit),
        "sehuatang_discover_mode": str(cfg.sehuatang_discover_mode or "").strip() or "stop_tid",
        # cover download
        "cover_download_enabled": True,
        "cover_dir": os.environ.get("CRAWLER_COVER_DIR", "data/crawler/covers"),
        # base urls (can be overridden by env)
        "sehuatang_domain": os.environ.get("CRAWLER_SEHUATANG_DOMAIN", "https://sehuatang.org").strip(),
        "sehuatang_section_map": {},
        "javbee_route": os.environ.get("CRAWLER_JAVBEE_ROUTE", ""),
        "javbee_base_url": os.environ.get("CRAWLER_JAVBEE_BASE_URL", "https://javbee.me").strip(),
        "javbus_base_url": os.environ.get("CRAWLER_JAVBUS_BASE_URL", "https://www.javbus.com").strip(),
        "t66y_base_url": os.environ.get("CRAWLER_T66Y_BASE_URL", "https://t66y.com").strip(),
    }
    return ctx


async def run_once(app_state: Any) -> None:
    """Run one crawler round immediately (admin UI button).

    Behavior:
    1) Plan discover jobs once (idempotent).
    2) Execute pending jobs until queues are empty or budget reached.

    This does NOT require the background CrawlerService to be running.
    """
    cfg = load_crawler_config()
    pool = await _ensure_pool(app_state)
    ctx = _build_ctx(cfg)

    # Plan jobs once (only if sources configured).
    if cfg.sources:
        attempted = await planner_tick(pool, cfg)
        biz.ok("✅ crawler run_once: planned discover jobs", attempted=attempted, sources=list(cfg.sources))
    else:
        biz.warning("⚠️ crawler run_once: no sources configured; nothing to run", tip="Set CRAWLER_SOURCES or use UI overrides.")

    worker_id = f"run_once:{socket.gethostname()}:{os.getpid()}"
    browser_fetcher: BrowserFetcher | None = None
    try:
        # Create browser fetcher if possible (needed for browser mode).
        try:
            state_key = str(ctx.get("sehuatang_domain") or "sehuatang")
            browser_fetcher = BrowserFetcher(
                state_key=state_key,
                user_agent=str(ctx.get("network_user_agent") or "").strip() or None,
                proxy_url=str(ctx.get("network_proxy_url") or "").strip() or None,
                timeout_s=int(ctx.get("network_timeout_s") or 30),
            )
            ctx["browser_fetcher"] = browser_fetcher
        except BrowserUnavailable as e:
            biz.warning("⚠️ run_once: browser fetcher unavailable; browser queue jobs will be skipped.", reason=str(e))

        # Budget: avoid blocking the admin request forever.
        max_jobs = int(os.environ.get("CRAWLER_RUN_ONCE_MAX_JOBS", "60"))
        max_seconds = float(os.environ.get("CRAWLER_RUN_ONCE_MAX_SECONDS", "120"))
        start = asyncio.get_event_loop().time()

        done = 0
        while done < max_jobs and (asyncio.get_event_loop().time() - start) < max_seconds:
            # Prefer http jobs, then browser jobs
            job = await pick_one_job(pool, "http", worker_id)
            if job is None:
                job = await pick_one_job(pool, "browser", worker_id)
            if job is None:
                break

            try:
                await mark_heartbeat(pool, job.id, progress_done=0, progress_total=0)
                result = await run_job(pool, job, ctx)
                await mark_done(pool, job.id, result)
                done += 1
            except Exception as e:
                try:
                    delay = next_backoff_sec(int(job.attempt or 0))
                except Exception:
                    delay = 30
                await mark_failed(pool, job.id, attempt=int(job.attempt or 0), next_delay_sec=int(delay), error=str(e))
                biz.warning("⚠️ run_once job failed", job_id=job.id, source=job.source, kind=job.kind, error=str(e))

        biz.ok("✅ crawler run_once finished", processed=done, max_jobs=max_jobs, max_seconds=max_seconds)
    finally:
        try:
            if browser_fetcher is not None:
                await browser_fetcher.close()
        except Exception as e:
            suppress(site="crawler/runtime:close_browser", exc=e, logger=biz, fallback=None)
