from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Literal, Optional


QueueName = Literal["http", "browser", "offline"]
JobKind = Literal["discover", "detail", "offline"]


@dataclass
class CrawlJob:
    id: str
    queue: QueueName
    source: str
    kind: JobKind
    params: dict[str, Any]
    attempt: int = 0


@dataclass
class Candidate:
    external_id: str
    detail_url: str
    meta: dict[str, Any] = field(default_factory=dict)


@dataclass
class Item:
    # Identity / trace
    source: str
    external_id: str = ""
    detail_url: str = ""
    hash: str = ""  # stable unique hash, filled by pipeline if empty

    # Display
    title: str = ""

    # Time
    publish_time: Optional[str] = None  # ISO datetime string
    publish_date: Optional[str] = None  # YYYY-MM-DD (optional convenience)

    # UI grouping
    section: str = ""
    category: str = ""
    tags: list[str] = field(default_factory=list)

    # Resource fields
    magnet: str = ""
    size_mb: Optional[int] = None
    resolution: str = ""
    duration_sec: Optional[int] = None
    code: str = ""
    actors: list[str] = field(default_factory=list)
    actors_text: str = ""  # optional pre-joined actor names for fuzzy search
    studio: str = ""

    # Images
    cover_url: str = ""
    cover_path: str = ""
    preview_urls: list[str] = field(default_factory=list)

    # Article fields
    website: str = ""
    summary: str = ""
    content: str = ""
    author: str = ""

    # Offline fields
    offline_status: str = ""
    offline_method: str = ""
    offline_job_id: str = ""

    # Ops
    status: str = "active"
    ingest_run_id: str = ""

    raw: dict[str, Any] = field(default_factory=dict)
