"""Crawler subsystem (PostgreSQL-backed).

This package is intentionally isolated from the main app's SQLite stores.
It can be enabled by setting:

  CRAWLER_ENABLED=1

The crawler runs only in worker role (APP_ROLE=worker or all) and is managed
via core.services.ServiceManager.
"""

__all__ = [
    "service",
]
