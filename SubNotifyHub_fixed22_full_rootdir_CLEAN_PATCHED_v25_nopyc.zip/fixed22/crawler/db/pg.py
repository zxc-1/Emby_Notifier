from __future__ import annotations

import asyncio
import json
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional, Sequence

from core.logging import get_biz_logger
from core.suppress import suppress


biz = get_biz_logger(__name__)

def _normalize_pg_dsn(dsn: str) -> str:
    """Normalize DSN for asyncpg.

    Some users provide SQLAlchemy-style schemes like `postgresql+asyncpg://`.
    asyncpg only accepts `postgresql://` or `postgres://`.
    """
    raw = str(dsn or "").strip()
    if raw.startswith("postgresql+asyncpg://"):
        return "postgresql://" + raw[len("postgresql+asyncpg://"):]
    if raw.startswith("postgres+asyncpg://"):
        return "postgres://" + raw[len("postgres+asyncpg://"):]
    return raw


class PgUnavailable(RuntimeError):
    pass


@dataclass
class PgPool:
    """A tiny asyncpg wrapper.

    We keep this small on purpose so the crawler can live next to the existing
    SQLite stores without forcing a full ORM migration.
    """

    dsn: str
    pool: Any

    @staticmethod
    def _bind_arg(v: Any) -> Any:
        """Normalize bind parameters for asyncpg.

        asyncpg does not accept raw Python dict/list for json/jsonb parameters
        by default. Our SQL uses explicit casts like `$4::jsonb`, so we bind a
        JSON string to keep behavior consistent across environments.
        """
        if isinstance(v, (dict, list)):
            return json.dumps(v, ensure_ascii=False)
        return v

    @staticmethod
    def _coerce_args(sql: str, args: Sequence[Any]) -> tuple[Any, ...]:
        """Best-effort coercion for common text/bigint mismatches.

        Only applies when the SQL explicitly specifies the parameter type
        (e.g., `$1::bigint`, `$2::text`). This prevents accidental coercion.
        """
        if not args:
            return tuple()
        out: list[Any] = list(args)
        for i, v in enumerate(out, start=1):
            # explicit casts on parameter placeholder
            if re.search(rf"\${i}::bigint\b", sql):
                if isinstance(v, str):
                    s = v.strip()
                    if s and s.isdigit():
                        out[i-1] = int(s)
                continue
            if re.search(rf"\${i}::text\b", sql) or re.search(rf"::text\s*=\s*\${i}\b", sql):
                if isinstance(v, int):
                    out[i-1] = str(v)
                continue
        return tuple(out)


    async def close(self) -> None:
        try:
            await self.pool.close()
        except Exception as e:
            biz.detail(
                "ℹ️ 关闭 PostgreSQL 连接池失败（已忽略，不影响进程退出）。",
                建议="若频繁出现，可能是连接已断开或被外部终止。",
                exc=e,
            )

    async def execute(self, sql: str, *args: Any) -> str:
        async with self.pool.acquire() as conn:
            if args:
                args = self._coerce_args(sql, args)
                args = tuple(self._bind_arg(a) for a in args)
            return await conn.execute(sql, *args)

    # --- Compatibility helpers (used across crawler + admin routes) ---
    async def fetchall(self, sql: str, *args: Any) -> list[dict[str, Any]]:
        return await self.fetch(sql, *args)

    async def fetchone_optional(self, sql: str, *args: Any) -> Optional[dict[str, Any]]:
        return await self.fetchrow(sql, *args)

    async def fetchone(self, sql: str, *args: Any) -> dict[str, Any]:
        row = await self.fetchrow(sql, *args)
        if not row:
            raise KeyError("row_not_found")
        return row

    async def fetch(self, sql: str, *args: Any) -> list[dict[str, Any]]:
        async with self.pool.acquire() as conn:
            if args:
                args = self._coerce_args(sql, args)
                args = tuple(self._bind_arg(a) for a in args)
            rows = await conn.fetch(sql, *args)
            out: list[dict[str, Any]] = []
            for r in rows:
                if r is None:
                    continue
                if isinstance(r, dict):
                    out.append(dict(r))
                    continue
                # asyncpg.Record implements .items(); dict(record) is usually fine,
                # but be defensive in case a driver returns tuple-like rows.
                if hasattr(r, "items"):
                    try:
                        out.append(dict(r.items()))  # type: ignore[attr-defined]
                        continue
                    except Exception as e:
                        suppress(site="crawler/pg:record_items_to_dict", exc=e, logger=biz, fallback=None)
                try:
                    out.append(dict(r))
                except Exception as e:
                    biz.warning(
                        "⚠️ PostgreSQL 行结果转换失败：无法转为 dict（已忽略该行）。",
                        建议="请检查 SQL 返回的列结构；期望是 (col,value) 形式或 mapping/Record。",
                        exc=e,
                    )
            return out

    async def fetchrow(self, sql: str, *args: Any) -> Optional[dict[str, Any]]:
        async with self.pool.acquire() as conn:
            if args:
                args = self._coerce_args(sql, args)
                args = tuple(self._bind_arg(a) for a in args)
            r = await conn.fetchrow(sql, *args)
            if not r:
                return None
            if isinstance(r, dict):
                return dict(r)
            if hasattr(r, "items"):
                try:
                    return dict(r.items())  # type: ignore[attr-defined]
                except Exception as e:
                    suppress(site="crawler/pg:record_items_to_dict(fetchrow)", exc=e, logger=biz, fallback=None)
            return dict(r)


async def create_pg_pool(dsn: str, *, min_size: int = 1, max_size: int = 10) -> PgPool:
    try:
        import asyncpg  # type: ignore
    except Exception as e:
        raise PgUnavailable("未安装 asyncpg：爬虫服务需要 asyncpg 连接 PostgreSQL") from e

    if not str(dsn or "").strip():
        raise PgUnavailable("未配置 CRAWLER_PG_DSN：无法连接 PostgreSQL")

    norm_dsn = _normalize_pg_dsn(dsn)
    if norm_dsn != str(dsn).strip():
        biz.info("ℹ️ 已自动规范化 PostgreSQL DSN 的 scheme（兼容 asyncpg）。", 原scheme=str(dsn).strip().split("://",1)[0], 新scheme=norm_dsn.split("://",1)[0])

    # asyncpg creates connections lazily; do a quick connect test
    pool = await asyncpg.create_pool(dsn=str(norm_dsn), min_size=min_size, max_size=max_size)
    return PgPool(dsn=str(dsn), pool=pool)


async def run_ddl(pool: PgPool, ddl_path: str | Path) -> None:
    ddl_path = Path(ddl_path)

    # "Perfect" behavior for real deployments:
    # 1) If crawler tables already exist, we are in "read existing DB" mode — do NOT re-run DDL.
    # 2) If multiple workers/admin requests race to init, serialize with an advisory lock.
    # 3) If CREATE EXTENSION still races, swallow the specific pgcrypto/pg_trgm unique violation.

    async with pool.pool.acquire() as conn:
        lock_key1 = 0x534E4801  # "SNH" namespace-ish
        lock_key2 = 0x43524C01  # "CRL" crawler-ish
        await conn.execute("SELECT pg_advisory_lock($1, $2)", lock_key1, lock_key2)
        try:
            # If already initialized, skip the heavy DDL, but still apply
            # forward-compatible patches to avoid environment drift.
            try:
                # If core tables already exist, skip DDL entirely (idempotent init).
                exists = await conn.fetchrow(
                    """
                    SELECT 1
                    FROM information_schema.tables
                    WHERE table_schema='crawler'
                      AND table_name IN (
                        'crawler_jobs',
                        'crawler_items',
                        'crawler_subscriptions',
                        'crawler_delivery_tasks'
                      )
                    LIMIT 1
                    """
                )
                if exists:
                    await _apply_forward_patches(conn)
                    return
            except Exception:
                # If we can't check (permissions/limited roles), fall back to running DDL.
                pass

            sql = await asyncio.to_thread(Path(ddl_path).read_text, encoding="utf-8")

            # Split by ';' safely enough for our small DDL file.
            stmts: list[str] = []
            buf = ""
            for line in sql.splitlines():
                if line.strip().startswith("--"):
                    continue
                buf += line + "\n"
                if ";" in line:
                    parts = buf.split(";")
                    for part in parts[:-1]:
                        if part.strip():
                            stmts.append(part.strip())
                    buf = parts[-1]
            if buf.strip():
                stmts.append(buf.strip())

            for s in stmts:
                try:
                    await conn.execute(s)
                except Exception as e:
                    msg = str(e)
                    is_ext_stmt = s.strip().lower().startswith("create extension")
                    is_unique_ext = (
                        type(e).__name__ == "UniqueViolationError"
                        and "pg_extension_name_index" in msg
                        and "extname" in msg
                        and ("pgcrypto" in msg or "pg_trgm" in msg)
                    )
                    if is_ext_stmt and is_unique_ext:
                        biz.warning(
                            "⚠️ PostgreSQL 扩展已存在：已忽略重复创建（避免初始化失败）。",
                            扩展=("pgcrypto" if "pgcrypto" in msg else "pg_trgm"),
                        )
                        continue

                    biz.fail(
                        "❌ 初始化爬虫数据库结构失败：执行 DDL 语句出错。",
                        SQL片段=s[:2000],
                        建议="请检查数据库权限（是否允许 CREATE/ALTER），以及 schema 是否可写。",
                        exc=e,
                    )
                    raise

            # After full init, also apply patches (idempotent).
            await _apply_forward_patches(conn)
        finally:
            try:
                await conn.execute("SELECT pg_advisory_unlock($1, $2)", lock_key1, lock_key2)
            except Exception:
                # Ignore unlock errors (e.g. connection dropped)
                pass


async def _apply_forward_patches(conn: Any) -> None:
    """Apply small, idempotent patches even when core crawler tables already exist.

    Why this exists:
    - Some installs created `crawler.*` tables earlier, then newer versions
      introduced additional helpers under `public.*` (e.g. `public.article_meta`).
      The old "skip DDL if crawler tables exist" logic caused drift and runtime
      500s in admin routes.
    - Newer admin/delivery code may enqueue tasks using legacy `public.article.tid`
      (a bigint) rather than `crawler.crawler_items.id` (a uuid). Old schemas
      used `uuid` for `crawler_delivery_tasks.item_id`, which breaks enqueue.
    """

    # ---- Patch 1: ensure public.article_meta exists (admin item_detail LEFT JOIN) ----
    try:
        await conn.execute(
            """
            CREATE TABLE IF NOT EXISTS public.article_meta (
              tid bigint PRIMARY KEY REFERENCES public.article(tid) ON DELETE CASCADE,
              raw jsonb NOT NULL DEFAULT '{}'::jsonb,
              updated_time timestamptz NOT NULL DEFAULT now()
            )
            """
        )
        await conn.execute(
            """CREATE INDEX IF NOT EXISTS idx_article_meta_updated_time
               ON public.article_meta (updated_time DESC)"""
        )
        await conn.execute(
            """CREATE INDEX IF NOT EXISTS idx_article_meta_raw_gin
               ON public.article_meta USING gin (raw)"""
        )
    except Exception as e:
        # Best-effort: do not block startup if user DB role can't write public schema.
        suppress(site="crawler/pg:patch_article_meta", exc=e, logger=biz, fallback=None)

    # ---- Patch 2: allow delivery tasks to reference legacy public.article.tid ----
    try:
        # Drop FK constraints on item_id if they exist (uuid->text migration).
        rows = await conn.fetch(
            """
            SELECT c.conname
            FROM pg_constraint c
            WHERE c.conrelid = 'crawler.crawler_delivery_tasks'::regclass
              AND c.contype = 'f'
              AND pg_get_constraintdef(c.oid) ILIKE '%(item_id)%'
            """
        )
        for r in rows or []:
            name = r.get("conname") if isinstance(r, dict) else getattr(r, "conname", None)
            if name:
                await conn.execute(f'ALTER TABLE crawler.crawler_delivery_tasks DROP CONSTRAINT IF EXISTS "{name}"')

        # Ensure column type is TEXT (so it can hold uuid or numeric tid).
        await conn.execute(
            """
            ALTER TABLE crawler.crawler_delivery_tasks
              ALTER COLUMN item_id TYPE text
              USING item_id::text
            """
        )

        # Recreate indexes (safe when already present).
        await conn.execute(
            """CREATE INDEX IF NOT EXISTS idx_delivery_poll
               ON crawler.crawler_delivery_tasks (deliver_to, status, run_after)"""
        )
        # Unique constraint for idempotent enqueue.
        await conn.execute(
            """CREATE UNIQUE INDEX IF NOT EXISTS uq_delivery_item_target_path
               ON crawler.crawler_delivery_tasks (item_id, deliver_to, save_path)"""
        )
    except Exception as e:
        suppress(site="crawler/pg:patch_delivery_item_id", exc=e, logger=biz, fallback=None)

    # ---- Patch 3: forward-compat columns for CD2 tracking / notifications ----
    # Older installs may have `crawler_delivery_tasks` without these columns.
    # Newer CD2 polling/webhook code queries them directly; missing columns will crash runtime.
    try:
        # NOTE: IF NOT EXISTS keeps this safe across versions.
        await conn.execute(
            "ALTER TABLE crawler.crawler_delivery_tasks ADD COLUMN IF NOT EXISTS meta jsonb NOT NULL DEFAULT '{}'::jsonb"
        )
        await conn.execute("ALTER TABLE crawler.crawler_delivery_tasks ADD COLUMN IF NOT EXISTS remote_kind text")
        await conn.execute("ALTER TABLE crawler.crawler_delivery_tasks ADD COLUMN IF NOT EXISTS remote_backend text")
        await conn.execute("ALTER TABLE crawler.crawler_delivery_tasks ADD COLUMN IF NOT EXISTS remote_task_id text")
        await conn.execute("ALTER TABLE crawler.crawler_delivery_tasks ADD COLUMN IF NOT EXISTS remote_status text")
        await conn.execute("ALTER TABLE crawler.crawler_delivery_tasks ADD COLUMN IF NOT EXISTS remote_progress int")
        await conn.execute("ALTER TABLE crawler.crawler_delivery_tasks ADD COLUMN IF NOT EXISTS remote_error_code text")
        await conn.execute("ALTER TABLE crawler.crawler_delivery_tasks ADD COLUMN IF NOT EXISTS remote_error_msg text")
        await conn.execute("ALTER TABLE crawler.crawler_delivery_tasks ADD COLUMN IF NOT EXISTS result_paths jsonb")
        await conn.execute("ALTER TABLE crawler.crawler_delivery_tasks ADD COLUMN IF NOT EXISTS next_poll_at timestamptz")
        await conn.execute(
            "ALTER TABLE crawler.crawler_delivery_tasks ADD COLUMN IF NOT EXISTS poll_attempts int NOT NULL DEFAULT 0"
        )
        await conn.execute("ALTER TABLE crawler.crawler_delivery_tasks ADD COLUMN IF NOT EXISTS last_polled_at timestamptz")
        await conn.execute("ALTER TABLE crawler.crawler_delivery_tasks ADD COLUMN IF NOT EXISTS submitted_at timestamptz")
        await conn.execute("ALTER TABLE crawler.crawler_delivery_tasks ADD COLUMN IF NOT EXISTS finished_at timestamptz")
        await conn.execute("ALTER TABLE crawler.crawler_delivery_tasks ADD COLUMN IF NOT EXISTS notified_at timestamptz")
        await conn.execute("ALTER TABLE crawler.crawler_delivery_tasks ADD COLUMN IF NOT EXISTS notify_success boolean")
        await conn.execute("ALTER TABLE crawler.crawler_delivery_tasks ADD COLUMN IF NOT EXISTS notify_failed boolean")

        await conn.execute(
            """CREATE INDEX IF NOT EXISTS idx_delivery_cd2_poll
               ON crawler.crawler_delivery_tasks (deliver_to, status, next_poll_at)
               WHERE deliver_to='cd2'"""
        )
    except Exception as e:
        suppress(site="crawler/pg:patch_delivery_cd2_cols", exc=e, logger=biz, fallback=None)