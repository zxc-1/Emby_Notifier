from __future__ import annotations

import json
from typing import Any

from crawler.db.pg import PgPool


def _as_dict(v: Any) -> dict[str, Any]:
    """Normalize a json/jsonb-ish value into a python dict."""
    if v is None:
        return {}
    if isinstance(v, dict):
        return dict(v)
    if isinstance(v, str):
        try:
            d = json.loads(v) or {}
            return dict(d) if isinstance(d, dict) else {}
        except Exception:
            return {}
    return {}


async def get_cursor(pool: PgPool, *, source: str, scope: str) -> dict[str, Any]:
    """Read crawler_source_state.cursor.

    Returns an empty dict when missing.
    """

    row = await pool.fetchone_optional(
        """
        SELECT cursor
        FROM crawler.crawler_source_state
        WHERE source=$1 AND scope=$2
        """,
        str(source),
        str(scope),
    )
    if not row:
        return {}
    return _as_dict(row.get("cursor"))


async def set_cursor(pool: PgPool, *, source: str, scope: str, cursor: dict[str, Any]) -> None:
    """Upsert crawler_source_state.cursor."""

    cursor = dict(cursor or {})
    await pool.execute(
        """
        INSERT INTO crawler.crawler_source_state (source, scope, cursor, updated_at)
        VALUES ($1, $2, $3::jsonb, now())
        ON CONFLICT (source, scope)
        DO UPDATE SET cursor=$3::jsonb, updated_at=now()
        """,
        str(source),
        str(scope),
        cursor,
    )


async def merge_cursor(pool: PgPool, *, source: str, scope: str, patch: dict[str, Any]) -> dict[str, Any]:
    """Shallow-merge a patch into cursor and persist."""

    patch = dict(patch or {})
    cur = await get_cursor(pool, source=source, scope=scope)
    cur.update(patch)
    await set_cursor(pool, source=source, scope=scope, cursor=cur)
    return cur


def _as_int(v: Any) -> int:
    try:
        if v is None:
            return 0
        if isinstance(v, bool):
            return int(v)
        return int(str(v).strip() or "0")
    except Exception:
        return 0


async def bump_max_int(
    pool: PgPool,
    *,
    source: str,
    scope: str,
    key: str,
    value: Any,
) -> int:
    """Update cursor[key] = max(cursor[key], value) and persist."""

    cur = await get_cursor(pool, source=source, scope=scope)
    old = _as_int(cur.get(key))
    new = max(old, _as_int(value))
    if new != old:
        cur[key] = new
        await set_cursor(pool, source=source, scope=scope, cursor=cur)
    return new


# ---------------------------------------------------------------------------
# Stable public API (contract)
# ---------------------------------------------------------------------------
#
# Several pipeline modules rely on a small, stable set of cursor helpers.
# Keep these names stable to avoid startup-time ImportError when refactoring.


async def get_source_cursor(pool: PgPool, source: str, scope: str) -> dict[str, Any]:
    """Stable API: read cursor dict for (source, scope)."""

    return await get_cursor(pool, source=str(source), scope=str(scope))


async def merge_source_cursor(pool: PgPool, source: str, scope: str, patch: dict[str, Any]) -> dict[str, Any]:
    """Stable API: shallow-merge patch into cursor and persist."""

    return await merge_cursor(pool, source=str(source), scope=str(scope), patch=dict(patch or {}))


async def update_source_cursor_max_int(
    pool: PgPool,
    source: str,
    scope: str,
    key: str,
    value: Any,
) -> int:
    """Stable API: cursor[key] = max(cursor[key], value) and persist."""

    return await bump_max_int(pool, source=str(source), scope=str(scope), key=str(key), value=value)


__all__ = [
    # internal building blocks
    "get_cursor",
    "set_cursor",
    "merge_cursor",
    "bump_max_int",
    # stable public contract
    "get_source_cursor",
    "merge_source_cursor",
    "update_source_cursor_max_int",
]
