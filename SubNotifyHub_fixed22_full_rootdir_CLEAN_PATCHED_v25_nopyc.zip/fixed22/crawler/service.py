from __future__ import annotations
from core.task_registry import create_task_logged

import asyncio
import os
from core.env_utils import env_bool, env_int, env_str
import socket
from typing import Any, Optional

from fastapi import FastAPI

from core.logging import get_biz_logger
from core.suppress import suppress
from core.services.base import Service
from core.task_registry import TaskRegistry

from crawler.config import load_crawler_config
from crawler.db.pg import PgPool, PgUnavailable, create_pg_pool, run_ddl
from crawler.pipeline.run_job import run_job, next_backoff_sec
from crawler.fetchers.browser import BrowserFetcher, BrowserUnavailable
from crawler.queue.jobs import pick_one_job, mark_done, mark_failed, mark_heartbeat
from crawler.queue.delivery import pick_one_delivery_task, mark_delivery_success, mark_delivery_failed
from crawler.queue.reaper import reaper_loop
from crawler.scheduler.planner import planner_loop
from crawler.subscriptions.loop import subscription_loop

from crawler.delivery_notify import try_notify_delivery

from services.dedup.factory import get_cloud115_client


biz = get_biz_logger(__name__)


_LOG_PG_UNAVAILABLE = (
    "⚠️ 爬虫服务未启动：PostgreSQL 连接不可用，将跳过启动。"
    "请检查 CRAWLER_PG_DSN 是否正确、数据库容器/网络是否可达。"
)

_LOG_BROWSER_UNAVAILABLE = (
    "⚠️ 浏览器抓取队列不可用：缺少 Playwright 运行环境。"
    "如需抓取 sehua 等浏览器源，请安装 Playwright 并执行 'playwright install'。"
)

_LOG_WORKER_LOOP_ERROR = (
    "⚠️ Worker 循环异常：执行过程中发生未捕获错误（已忽略，将继续轮询）。"
)

_LOG_JOB_FAILED = (
    "⚠️ 爬虫任务执行失败：已记录失败并将按退避策略自动重试。"
)

_LOG_JOB_DONE = "✅ 爬虫任务执行完成"


class CrawlerService:
    name = "crawler"

    def __init__(self, *, app: FastAPI, registry: TaskRegistry):
        self.app = app
        self.registry = registry
        self._stop_event = asyncio.Event()
        self._pool: Optional[PgPool] = None
        self._worker_id = f"{socket.gethostname()}:{os.getpid()}"
        self._tasks: list[asyncio.Task] = []

    async def start(self) -> None:
        cfg = load_crawler_config()
        if not cfg.enabled:
            return

        try:
            pool = await create_pg_pool(cfg.pg_dsn, min_size=1, max_size=max(2, cfg.http_concurrency))
        except PgUnavailable as e:
            biz.warning(
                _LOG_PG_UNAVAILABLE,
                原因=str(e),
                建议="确认 Postgres 已启动，并检查 CRAWLER_PG_DSN（主机/端口/用户名/密码/库名）。",
                exc=e,
            )
            return

        self._pool = pool
        # expose for admin routes (click subscribe)
        try:
            self.app.state.crawler_pg_pool = pool
        except Exception as e:
            suppress(site="crawler/service:expose_pg_pool", exc=e, logger=biz, fallback=None)

        # Ensure schema exists
        ddl_path = os.path.join(os.path.dirname(__file__), "db", "ddl.sql")
        await run_ddl(pool, ddl_path)

        ctx: dict[str, Any] = {
            "_crawler_service": self,
            "rsshub_host": cfg.rsshub_host,
            "t66y_sections": cfg.t66y_sections,
            "javbus_categories": cfg.javbus_categories,
            "flaresolverr_url": cfg.flaresolverr_url,
            # delivery save path: no implicit defaults (empty means "user must configure")
            "deliver_save_path_115": env_str("CRAWLER_DELIVER_SAVE_PATH_115", "").strip(),
            "deliver_save_path_cd2": env_str("CRAWLER_DELIVER_SAVE_PATH_CD2", "").strip(),
            "sehuatang_domain": env_str("CRAWLER_SEHUATANG_DOMAIN", "https://sehuatang.org").strip(),
            "sehuatang_section_map": {},  # parsed in SehuatangPlugin from env by default
            "javbee_route": env_str("CRAWLER_JAVBEE_ROUTE", ""),
            "javbee_base_url": env_str("CRAWLER_JAVBEE_BASE_URL", "https://javbee.me").strip(),
            "javbus_base_url": env_str("CRAWLER_JAVBUS_BASE_URL", "https://www.javbus.com").strip(),
            "t66y_base_url": env_str("CRAWLER_T66Y_BASE_URL", "https://t66y.com").strip(),

            # cover download
            "cover_download_enabled": env_bool("CRAWLER_COVER_DOWNLOAD", True),
            "cover_dir": env_str("CRAWLER_COVER_DIR", "data/crawler/covers"),

            # network/runtime (env + UI overrides)
            "network_user_agent": cfg.network_user_agent,
            "network_proxy_url": cfg.network_proxy_url,
            "network_timeout_s": int(cfg.network_timeout_s),
            "heartbeat_interval_s": int(cfg.heartbeat_interval_s),
            "job_stale_timeout_s": int(cfg.job_stale_timeout_s),
            "delivery_stale_timeout_s": int(cfg.delivery_stale_timeout_s),
            "reaper_interval_s": int(cfg.reaper_interval_s),

            # sehuatang runtime (read by plugin)
            "sehuatang_page_limit": int(cfg.sehuatang_page_limit),
            "sehuatang_discover_mode": str(cfg.sehuatang_discover_mode or "").strip() or "stop_tid",
        }

        # Planner
        self._tasks.append(
            await self.registry.create_task(
                planner_loop(pool, cfg, ctx, stop_event=self._stop_event),
                name="crawler_planner",
            )
        )

        # Subscription scanner (only after user clicks "订阅")
        subs_cron = env_str("CRAWLER_SUBS_CRON", "*/2 * * * *").strip()
        self._tasks.append(
            await self.registry.create_task(
                subscription_loop(pool, cron_expr=subs_cron, stop_event=self._stop_event),
                name="crawler_subscriptions",
            )
        )

        # Reaper (recover stuck running jobs / delivery tasks)
        self._tasks.append(
            await self.registry.create_task(
                reaper_loop(pool, stop_event=self._stop_event),
                name="crawler_reaper",
            )
        )

        # Workers
        for i in range(cfg.http_concurrency):
            self._tasks.append(
                await self.registry.create_task(
                    self._worker_loop(pool, queue="http", ctx=ctx, poll_interval_ms=cfg.poll_interval_ms),
                    name=f"crawler_http_{i}",
                )
            )
        for i in range(cfg.browser_concurrency):
            self._tasks.append(
                await self.registry.create_task(
                    self._worker_loop(pool, queue="browser", ctx=ctx, poll_interval_ms=cfg.poll_interval_ms),
                    name=f"crawler_browser_{i}",
                )
            )
        # Delivery workers
        for i in range(cfg.offline_concurrency):
            self._tasks.append(
                await self.registry.create_task(
                    self._deliver_115_loop(pool, poll_interval_ms=cfg.poll_interval_ms),
                    name=f"crawler_deliver_115_{i}",
                )
            )
        # CD2 usually needs fewer workers
        cd2_workers = max(1, env_int("CRAWLER_CD2_CONCURRENCY", 1, min_value=1))
        for i in range(cd2_workers):
            self._tasks.append(
                await self.registry.create_task(
                    self._deliver_cd2_loop(pool, poll_interval_ms=cfg.poll_interval_ms),
                    name=f"crawler_deliver_cd2_{i}",
                )
            )

        # CD2 final status poller (submitted -> success/failed)
        self._tasks.append(
            await self.registry.create_task(
                self._cd2_poll_loop(pool, poll_interval_ms=cfg.poll_interval_ms),
                name="crawler_cd2_poll",
            )
        )

        # 115 final status poller (submitted -> success/failed)
        self._tasks.append(
            await self.registry.create_task(
                self._115_poll_loop(pool, poll_interval_ms=cfg.poll_interval_ms),
                name="crawler_115_poll",
            )
        )

        biz.ok(
            "✅ 爬虫服务启动完成：已进入待命状态（仅两种触发：UI 立即跑一次 / cron）。",
            工作进程=self._worker_id,
            HTTP并发=cfg.http_concurrency,
            浏览器并发=cfg.browser_concurrency,
            投递并发=cfg.offline_concurrency,
        )

    async def stop(self) -> None:
        self._stop_event.set()
        # Tasks are owned by TaskRegistry, so registry.shutdown() will cancel them.
        # Here we only close PG pool.
        if self._pool:
            await self._pool.close()
            self._pool = None
        biz.ok("✅ 爬虫服务已停止：不再执行抓取/投递任务。")

    async def _worker_loop(self, pool: PgPool, *, queue: str, ctx: dict[str, Any], poll_interval_ms: int) -> None:
        # Per-worker resources
        browser_fetcher: BrowserFetcher | None = None
        if queue == "browser":
            try:
                # Persist cookies per site
                state_key = str(ctx.get("sehuatang_domain") or "sehuatang")
                browser_fetcher = BrowserFetcher(
                    state_key=state_key,
                    user_agent=str(ctx.get("network_user_agent") or "").strip() or None,
                    proxy_url=str(ctx.get("network_proxy_url") or "").strip() or None,
                    timeout_s=int(ctx.get("network_timeout_s") or 30),
                )
                ctx["browser_fetcher"] = browser_fetcher
            except BrowserUnavailable as e:
                biz.warning(
                    _LOG_BROWSER_UNAVAILABLE,
                    原因=str(e),
                    建议="若你不需要 browser 模式，可把订阅的 mode 设为 fast/compat；否则请安装 Playwright。",
                    exc=e,
                )
                return

        try:
            while not self._stop_event.is_set():
                # Hot-reload runtime config (UI overrides + env) so the crawler page changes take effect
                # without container restart: sources/sections/cron/poll interval etc.
                try:
                    cur_cfg = load_crawler_config()
                    ctx["rsshub_host"] = cur_cfg.rsshub_host
                    ctx["t66y_sections"] = cur_cfg.t66y_sections
                    ctx["javbus_categories"] = cur_cfg.javbus_categories
                    ctx["flaresolverr_url"] = cur_cfg.flaresolverr_url
                    ctx["network_user_agent"] = cur_cfg.network_user_agent
                    ctx["network_proxy_url"] = cur_cfg.network_proxy_url
                    ctx["network_timeout_s"] = int(cur_cfg.network_timeout_s)
                    ctx["heartbeat_interval_s"] = int(cur_cfg.heartbeat_interval_s)
                    ctx["job_stale_timeout_s"] = int(cur_cfg.job_stale_timeout_s)
                    ctx["delivery_stale_timeout_s"] = int(cur_cfg.delivery_stale_timeout_s)
                    ctx["reaper_interval_s"] = int(cur_cfg.reaper_interval_s)
                    ctx["sehuatang_page_limit"] = int(cur_cfg.sehuatang_page_limit)
                    ctx["sehuatang_discover_mode"] = str(cur_cfg.sehuatang_discover_mode or "").strip() or "stop_tid"
                    poll_interval_ms = int(cur_cfg.poll_interval_ms)

                    # live-update browser fetcher network settings (UA/proxy)
                    if browser_fetcher is not None:
                        try:
                            await browser_fetcher.update_network(
                                user_agent=str(cur_cfg.network_user_agent or "").strip() or None,
                                proxy_url=str(cur_cfg.network_proxy_url or "").strip() or None,
                                timeout_s=int(cur_cfg.network_timeout_s or 30),
                            )
                        except Exception as e:
                            suppress(site="crawler/service:browser_update_network", exc=e, logger=biz, fallback=None)
                    # allow pausing workers by disabling crawler
                    if not cur_cfg.enabled:
                        await asyncio.sleep(1.0)
                        continue
                except Exception as e:
                    # keep last ctx/poll_interval_ms
                    suppress(site="crawler/service:reload_config(worker)", exc=e, logger=biz, fallback=None)
                job = None
                try:
                    job = await pick_one_job(pool, queue, self._worker_id)
                    if not job:
                        await asyncio.sleep(max(0.1, poll_interval_ms / 1000.0))
                        continue

                    # Heartbeat task: keep updating heartbeat_at while the job is running.
                    hb_task: asyncio.Task | None = None
                    hb_interval = int(ctx.get("heartbeat_interval_s") or 20)
                    if hb_interval > 0:
                        async def _hb() -> None:
                            while not self._stop_event.is_set():
                                try:
                                    await asyncio.sleep(max(3, hb_interval))
                                    await mark_heartbeat(pool, job.id)
                                except asyncio.CancelledError:
                                    raise
                                except Exception:
                                    # best-effort; don't crash worker loop
                                    continue
                        hb_task = create_task_logged(_hb(), name="crawler_heartbeat", log=biz)

                    with biz.entry(
                        domain="爬虫",
                        action=f"任务执行/{queue}",
                        任务ID=job.id,
                        来源=job.source,
                        队列=queue,
                        类型=job.kind,
                    ):
                        biz.step(
                            "开始处理爬虫任务（发现/详情解析/入库）",
                            来源=job.source,
                            队列=queue,
                            类型=job.kind,
                        )
                        try:
                            result = await run_job(pool, job, ctx)
                            await mark_done(pool, job.id, result)
                        finally:
                            if hb_task is not None:
                                hb_task.cancel()
                                try:
                                    await hb_task
                                except asyncio.CancelledError:
                                    pass
                                except Exception as e:
                                    suppress(site="crawler/service:heartbeat_task_await", exc=e, logger=biz, fallback=None)

                        # Human-readable summary (keep it concise).
                        candidates = int(result.get("candidates") or 0) if isinstance(result, dict) else 0
                        saved = int(result.get("saved") or 0) if isinstance(result, dict) else 0
                        detail_enq = int(result.get("detail_enqueued") or 0) if isinstance(result, dict) else 0
                        skipped = bool(result.get("skipped")) if isinstance(result, dict) else False

                        if skipped:
                            biz.warning(
                                "⚠️ 爬虫任务已跳过：未执行抓取（通常是源未启用或插件缺失）。",
                                任务ID=job.id,
                                来源=job.source,
                                队列=queue,
                                原因=str(result.get("reason") or ""),
                                建议="检查 CRAWLER_SOURCES 是否包含该源，以及 plugins 是否加载成功。",
                            )
                        else:
                            biz.ok(
                                _LOG_JOB_DONE,
                                任务ID=job.id,
                                来源=job.source,
                                队列=queue,
                                候选数=candidates,
                                入库数=saved,
                                详情任务数=detail_enq,
                            )

                except asyncio.CancelledError:
                    raise
                except Exception as e:
                    if not job:
                        biz.warning(
                            _LOG_WORKER_LOOP_ERROR,
                            队列=queue,
                            建议="通常不影响服务，将继续轮询任务；若频繁出现请查看上一条异常栈定位原因。",
                            exc=e,
                        )
                    else:
                        delay = next_backoff_sec(job.attempt + 1)
                        await mark_failed(pool, job.id, attempt=job.attempt, next_delay_sec=delay, error=str(e))
                        biz.warning(
                            _LOG_JOB_FAILED,
                            任务ID=job.id,
                            来源=job.source,
                            队列=queue,
                            下次重试秒=delay,
                            建议="可在爬虫 UI 的任务列表里查看失败原因，并手动点击“重试失败任务”。",
                            exc=e,
                        )

        finally:
            if browser_fetcher is not None:
                try:
                    await browser_fetcher.close()
                except Exception as e:
                    biz.warning(
                        "⚠️ 关闭浏览器抓取器失败（已忽略，不影响服务停止）。",
                        建议="通常无需处理；若频繁出现，可能是 Playwright 被外部强制终止或页面卡死。",
                        exc=e,
                    )

    async def _deliver_115_loop(self, pool: PgPool, *, poll_interval_ms: int) -> None:
        """Drain crawler_delivery_tasks(deliver_to='115') and submit to 115 offline.

        IMPORTANT: tasks are created only by user "订阅" actions (subscription scanner or one-shot).
        """
        # Optional fallback: legacy env-configured offline folder id.
        wp_path_id_env = env_str("CRAWLER_OFFLINE_WP_PATH_ID", "").strip()
        wp_path_id_env_int = int(wp_path_id_env) if wp_path_id_env.isdigit() else None

        while not self._stop_event.is_set():
            task = None
            try:
                # Hot-reload poll interval & pause switch
                try:
                    cur_cfg = load_crawler_config()
                    poll_interval_ms = int(cur_cfg.poll_interval_ms)
                    if not cur_cfg.enabled:
                        await asyncio.sleep(1.0)
                        continue
                except Exception as e:
                    suppress(site="crawler/service:reload_config(deliver115)", exc=e, logger=biz, fallback=None)
                if not getattr(cur_cfg, "deliver_115_enabled", True):
                    await asyncio.sleep(1.0)
                    continue

                task = await pick_one_delivery_task(pool, deliver_to="115", owner=self._worker_id)
                if not task:
                    await asyncio.sleep(max(0.3, poll_interval_ms / 1000.0))
                    continue

                magnet = str(task.get("magnet") or "").strip()
                if not magnet:
                    biz.detail(
                        "ℹ️ 跳过 115 投递：该投递任务缺少磁力链接（已标记为完成，避免卡住队列）。",
                        投递任务ID=str(task.get("id")),
                    )
                    await mark_delivery_success(pool, str(task.get("id")))
                    continue

                client = get_cloud115_client()
                if client is None:
                    raise RuntimeError("Cloud115Client 未就绪：请配置 CLOUD115_COOKIE")

                with biz.entry(domain="爬虫", action="投递/115", 投递任务ID=str(task.get("id"))):
                    from crawler.pipeline.dedup import magnet_hash
                    from crawler.queue.delivery import mark_delivery_submitted

                    # Resolve wp_path_id from UI save_path when possible.
                    save_path = str(task.get("save_path") or getattr(cur_cfg, "deliver_115_save_path", "") or "").strip()
                    wp_path_id_int: int | None = None
                    if save_path.isdigit():
                        wp_path_id_int = int(save_path)
                    else:
                        sp = save_path.strip().strip("/")
                        if sp:
                            try:
                                dp = await client.get_downpath()
                                # exact match by name
                                for it in dp or []:
                                    name = str((it or {}).get("name") or "").strip()
                                    if name == sp:
                                        fid = (it or {}).get("file_id") or (it or {}).get("fileId") or (it or {}).get("id")
                                        if fid is not None and str(fid).isdigit():
                                            wp_path_id_int = int(str(fid))
                                            break
                                # fallback: contains match (avoid being too smart)
                                if wp_path_id_int is None:
                                    for it in dp or []:
                                        name = str((it or {}).get("name") or "").strip()
                                        if sp and name and sp in name:
                                            fid = (it or {}).get("file_id") or (it or {}).get("fileId") or (it or {}).get("id")
                                            if fid is not None and str(fid).isdigit():
                                                wp_path_id_int = int(str(fid))
                                                break
                            except Exception as e:
                                suppress(site="crawler/service:resolve_wp_path_id", exc=e, logger=biz, fallback=None)

                    # final fallback to env
                    if wp_path_id_int is None:
                        wp_path_id_int = wp_path_id_env_int

                    btih = magnet_hash(magnet) or ""
                    biz.step(
                        "开始提交 115 离线任务（仅受理；完成状态将由轮询确认后再标记 success 并通知）。",
                        投递任务ID=str(task.get("id")),
                        目标目录=str(save_path or ""),
                        工作目录ID=str(wp_path_id_int or ""),
                        BTIH=(btih[:12] + "…") if btih else "",
                    )
                    await client.add_offline_url(magnet, wp_path_id=wp_path_id_int)

                    # IMPORTANT: submitted != success. Poller will mark final result.
                    await mark_delivery_submitted(
                        pool,
                        task_id=str(task.get("id")),
                        remote_kind="115",
                        remote_backend=f"115:{wp_path_id_int or ''}",
                        remote_task_id=btih or str(task.get("item_id") or ""),
                        remote_status="pending",
                        next_poll_after_sec=10,
                    )
                    biz.ok(
                        "📨 115 已受理：已进入离线下载队列（等待轮询确认完成）。",
                        投递任务ID=str(task.get("id")),
                        工作目录ID=str(wp_path_id_int or ""),
                    )

            except asyncio.CancelledError:
                raise
            except Exception as e:
                if task:
                    delay = next_backoff_sec(int(task.get("attempt") or 0) + 1)
                    await mark_delivery_failed(pool, task, error=str(e), next_run_after_sec=delay)
                biz.warning(
                    "⚠️ 115 离线提交失败：已记录失败并将自动重试。",
                    投递任务ID=str(task.get("id")) if task else "",
                    下次重试秒=delay if task else "",
                    建议="请检查 CLOUD115_COOKIE 是否有效、115 是否可访问；也可在投递任务列表里手动重试。",
                    exc=e,
                )


    async def _deliver_cd2_loop(self, pool: PgPool, *, poll_interval_ms: int) -> None:
        """Drain crawler_delivery_tasks(deliver_to='cd2') and submit via CD2 bridge."""

        from integrations.cd2_bridge import submit_to_cd2
        from crawler.queue.delivery import mark_delivery_submitted

        while not self._stop_event.is_set():
            task = None
            try:
                # Hot-reload poll interval & pause switch
                try:
                    cur_cfg = load_crawler_config()
                    poll_interval_ms = int(cur_cfg.poll_interval_ms)
                    if not cur_cfg.enabled:
                        await asyncio.sleep(1.0)
                        continue
                except Exception as e:
                    suppress(site="crawler/service:reload_config(delivercd2)", exc=e, logger=biz, fallback=None)
                if not getattr(cur_cfg, "deliver_cd2_enabled", False):
                    await asyncio.sleep(1.0)
                    continue

                task = await pick_one_delivery_task(pool, deliver_to="cd2", owner=self._worker_id)
                if not task:
                    await asyncio.sleep(max(0.3, poll_interval_ms / 1000.0))
                    continue

                magnet = str(task.get("magnet") or "").strip()
                if not magnet:
                    biz.detail(
                        "ℹ️ 跳过 CD2 投递：该投递任务缺少磁力链接（已标记为完成，避免卡住队列）。",
                        投递任务ID=str(task.get("id")),
                    )
                    await mark_delivery_success(pool, str(task.get("id")))
                    continue

                # Do NOT fall back to any default save path. If the user didn't configure one,
                # fail loudly so UI can prompt for configuration.
                save_path = str(task.get("save_path") or getattr(cur_cfg, "deliver_cd2_save_path", "") or "")
                if not save_path.strip():
                    raise ValueError("save_path_required")
                cd2_mode = str(getattr(cur_cfg, "deliver_cd2_mode", "cloudapi") or "cloudapi").strip() or "cloudapi"
                cd2_base_url = str(getattr(cur_cfg, "deliver_cd2_base_url", "") or getattr(cur_cfg, "deliver_cd2_url", "") or "").strip()
                cd2_username = str(getattr(cur_cfg, "deliver_cd2_username", "") or "").strip()
                cd2_password = str(getattr(cur_cfg, "deliver_cd2_password", "") or "").strip()
                cd2_grpc_addr = str(getattr(cur_cfg, "deliver_cd2_grpc_addr", "") or "").strip()
                cd2_token = str(getattr(cur_cfg, "deliver_cd2_token", "") or getattr(cur_cfg, "deliver_cd2_api_key", "") or "").strip()
                cd2_auto_mkdir = bool(getattr(cur_cfg, "deliver_cd2_auto_mkdir", True))
                title = None
                with biz.entry(domain="爬虫", action="投递/CD2", 投递任务ID=str(task.get("id"))):
                    biz.step("开始提交 CD2 投递任务", 投递任务ID=str(task.get("id")), 保存路径=save_path)
                    resp = await submit_to_cd2(
                        magnet=magnet,
                        save_path=save_path,
                        title=title,
                        mode=cd2_mode,
                        base_url=cd2_base_url or None,
                        username=cd2_username or None,
                        password=cd2_password or None,
                        grpc_addr=cd2_grpc_addr or None,
                        token=cd2_token or None,
                        cloud_name=str(getattr(cur_cfg, "deliver_cd2_cloud_name", "") or "").strip() or None,
                        cloud_account_id=str(getattr(cur_cfg, "deliver_cd2_cloud_account_id", "") or "").strip() or None,
                        auto_mkdir=cd2_auto_mkdir,
                    )
                    remote_task_id = str(
                        (resp or {}).get("task_id")
                        or (resp or {}).get("fileId")
                        or (resp or {}).get("file_id")
                        or (resp or {}).get("infoHash")
                        or (resp or {}).get("info_hash")
                        or ""
                    ).strip()
                    if not remote_task_id:
                        # Fallback: use BTIH as a stable identifier for offline files.
                        # This enables polling on builds that only expose infoHash/fileId.
                        from crawler.pipeline.dedup import magnet_hash

                        remote_task_id = str(magnet_hash(magnet) or "").strip()
                    if not remote_task_id:
                        raise ValueError("cd2_missing_task_id")

                    await mark_delivery_submitted(
                        pool,
                        task_id=str(task.get("id")),
                        remote_kind="cd2",
                        remote_backend=str(cd2_mode or "cloudapi"),
                        remote_task_id=remote_task_id,
                        remote_status="pending",
                        next_poll_after_sec=5,
                    )
                    biz.ok(
                        "✅ CD2 已受理（submitted）。",
                        投递任务ID=str(task.get("id")),
                        CD2任务ID=remote_task_id,
                        保存路径=save_path,
                        说明="已写回 task_id，后续由后台轮询/回调更新最终 success/failed。",
                    )

            except asyncio.CancelledError:
                raise
            except Exception as e:
                if task:
                    delay = next_backoff_sec(int(task.get("attempt") or 0) + 1)
                    await mark_delivery_failed(pool, task, error=str(e), next_run_after_sec=delay)
                biz.warning(
                    "⚠️ CD2 投递失败：已记录失败并将自动重试。",
                    投递任务ID=str(task.get("id")) if task else "",
                    下次重试秒=delay if task else "",
                    建议="请检查 CD2 Bridge 服务是否在线、网络是否可达；也可在投递任务列表里手动重试。",
                    exc=e,
                )


    async def _cd2_poll_loop(self, pool: PgPool, *, poll_interval_ms: int) -> None:
        """Poll CD2 task status for submitted tasks.

        Design goals:
        - UI 'submit' is immediate; final state comes asynchronously.
        - Backoff polling to avoid spamming CD2.
        - Optional: when webhook is enabled, polling acts as a safety net.
        """

        import asyncio

        from crawler.queue.delivery import cd2_pick_tasks_to_poll, cd2_update_poll_result
        from integrations.cd2_bridge import Cd2BridgeError
        from integrations.cd2_client import Cd2Client, Cd2Config
        from crawler.config import load_crawler_config
        # notifications are handled via crawler.delivery_notify

        async def _fetch_title(item_id: object) -> str:
            try:
                tid = int(str(item_id))
            except Exception:
                return ""
            try:
                row = await pool.fetchrow("SELECT title FROM public.article WHERE tid=$1", tid)
                return str(row.get("title") or "").strip() if row else ""
            except Exception:
                return ""

        def _backoff(attempt: int) -> int:
            # 5s, 10s, 20s, 40s, 80s... cap 10min
            base = 5
            sec = base * (2 ** max(0, attempt))
            return int(min(sec, 600))

        while not self._stop_event.is_set():
            try:
                try:
                    cfg = load_crawler_config()
                    poll_interval_ms = int(cfg.poll_interval_ms)
                except Exception:
                    cfg = None

                if not cfg or not getattr(cfg, "deliver_cd2_enabled", False):
                    await asyncio.sleep(1.0)
                    continue

                due = await cd2_pick_tasks_to_poll(pool, limit=50)
                if not due:
                    await asyncio.sleep(max(0.5, poll_interval_ms / 1000.0))
                    continue

                cd2_mode = str(getattr(cfg, "deliver_cd2_mode", "cloudapi") or "cloudapi").strip() or "cloudapi"
                cd2_base_url = str(getattr(cfg, "deliver_cd2_base_url", "") or getattr(cfg, "deliver_cd2_url", "") or "").strip()
                cd2_username = str(getattr(cfg, "deliver_cd2_username", "") or "").strip()
                cd2_password = str(getattr(cfg, "deliver_cd2_password", "") or "").strip()
                cd2_grpc_addr = str(getattr(cfg, "deliver_cd2_grpc_addr", "") or "").strip()
                cd2_token = str(getattr(cfg, "deliver_cd2_token", "") or getattr(cfg, "deliver_cd2_api_key", "") or "").strip()

                cli = Cd2Client(
                    Cd2Config(
                        mode=cd2_mode,
                        base_url=cd2_base_url,
                        username=cd2_username,
                        password=cd2_password,
                        grpc_addr=cd2_grpc_addr,
                        token=cd2_token,
                        cloud_name=str(getattr(cfg, "deliver_cd2_cloud_name", "") or "").strip(),
                        cloud_account_id=str(getattr(cfg, "deliver_cd2_cloud_account_id", "") or "").strip(),
                        auto_mkdir=False,
                    )
                )

                for task in due:
                    tid = str(task.get("id") or "")
                    remote_task_id = str(task.get("remote_task_id") or "").strip()
                    if not tid or not remote_task_id:
                        continue

                    attempts = int(task.get("poll_attempts") or 0)
                    try:
                        info = await cli.get_download_task(task_id=remote_task_id)
                    except Exception as e:
                        # CD2 temporarily unavailable; backoff
                        await cd2_update_poll_result(
                            pool,
                            task_id=tid,
                            remote_status=str(task.get("remote_status") or "unknown"),
                            remote_error_msg=str(e)[:500],
                            next_poll_after_sec=_backoff(attempts + 1),
                            terminal=False,
                        )
                        continue

                    r_status = str((info or {}).get("status") or "unknown").lower()
                    r_prog = (info or {}).get("progress")
                    r_err = str((info or {}).get("error") or "")

                    if r_status in ("success", "failed"):
                        await cd2_update_poll_result(
                            pool,
                            task_id=tid,
                            remote_status=r_status,
                            remote_progress=int(r_prog) if isinstance(r_prog, (int, float)) else None,
                            remote_error_msg=r_err[:500] if r_err else None,
                            result_paths=(info or {}).get("result_paths"),
                            terminal=True,
                        )

                        title = await _fetch_title(task.get("item_id"))
                        msg = ""
                        if r_status == "success":
                            biz.ok(
                                "✅ CD2 下载完成",
                                item_id=str(task.get("item_id") or ""),
                                task_id=tid,
                                remote_task_id=remote_task_id,
                                save_path=str(task.get("save_path") or ""),
                                progress=int(r_prog) if isinstance(r_prog, (int, float)) else None,
                            )
                            msg = (
                                f"✅ CD2 下载完成\n\n🧩 {title or ''}\n🆔 {remote_task_id}\n📁 {task.get('save_path','')}"
                            )
                        else:
                            biz.fail(
                                "🧨 CD2 下载失败",
                                item_id=str(task.get("item_id") or ""),
                                task_id=tid,
                                remote_task_id=remote_task_id,
                                save_path=str(task.get("save_path") or ""),
                                error=(r_err[:200] if r_err else ""),
                            )
                            msg = (
                                f"🧨 CD2 下载失败\n\n🧩 {title or ''}\n🆔 {remote_task_id}\n📁 {task.get('save_path','')}\n💥 {r_err[:200]}"
                            )

                        await try_notify_delivery(
                            pool,
                            cfg=cfg,
                            task=task,
                            terminal_status=r_status,
                            message=msg,
                            biz=biz,
                        )
                        continue

                    # running/pending/unknown -> schedule next poll
                    await cd2_update_poll_result(
                        pool,
                        task_id=tid,
                        remote_status=r_status,
                        remote_progress=int(r_prog) if isinstance(r_prog, (int, float)) else None,
                        remote_error_msg=r_err[:500] if r_err else None,
                        next_poll_after_sec=_backoff(attempts + 1),
                        terminal=False,
                    )

            except asyncio.CancelledError:
                raise
            except Exception as e:
                suppress(site="crawler/service:cd2_poll_loop", exc=e, logger=biz, fallback=None)
                await asyncio.sleep(1.0)


    async def _115_poll_loop(self, pool: PgPool, *, poll_interval_ms: int) -> None:
        """Poll 115 offline task status for submitted tasks.

        Notes:
        - UI "投递成功" only means accepted/submitted.
        - This loop marks final success/failed when 115 offline finishes.
        - BTIH is used as the stable identifier (stored in remote_task_id).
        """

        import asyncio

        from crawler.config import load_crawler_config
        # notifications are handled via crawler.delivery_notify
        from crawler.pipeline.dedup import magnet_hash
        from crawler.queue.delivery import cd2_update_poll_result, pick_tasks_to_poll
        from services.dedup.factory import get_cloud115_client

        def _backoff(attempt: int) -> int:
            # 10s, 20s, 40s, 80s... cap 10min
            base = 10
            sec = base * (2 ** max(0, attempt))
            return int(min(sec, 600))

        def _parse_progress(v: object) -> int | None:
            if v is None:
                return None
            if isinstance(v, (int, float)):
                p = int(v)
                return max(0, min(100, p))
            s = str(v).strip()
            if not s:
                return None
            s = s.rstrip("%")
            if s.isdigit():
                p = int(s)
                return max(0, min(100, p))
            return None

        def _map_status(raw_status: object, progress: int | None) -> str:
            # 115 offline status codes are not officially stable across builds;
            # use tolerant mapping.
            if isinstance(raw_status, (int, float)):
                iv = int(raw_status)
                if iv <= 0:
                    return "pending"
                if iv == 1:
                    return "running"
                if iv == 2:
                    return "success"
                if iv == 3:
                    return "failed"
            if isinstance(raw_status, str):
                s = raw_status.strip().lower()
                if any(k in s for k in ("finish", "done", "complete", "success")):
                    return "success"
                if any(k in s for k in ("fail", "error")):
                    return "failed"
                if any(k in s for k in ("download", "run", "doing")):
                    return "running"
                if any(k in s for k in ("wait", "queue", "pend")):
                    return "pending"
            # Heuristic: 100% => success
            if progress is not None and progress >= 100:
                return "success"
            return "unknown"

        def _iter_115_tasks(resp: dict) -> list[dict]:
            if not isinstance(resp, dict):
                return []
            data = resp.get("data")
            if isinstance(data, dict):
                for k in ("tasks", "task", "list", "items", "data"):
                    seq = data.get(k)
                    if isinstance(seq, list):
                        return [x for x in seq if isinstance(x, dict)]
            if isinstance(data, list):
                return [x for x in data if isinstance(x, dict)]
            # some versions return tasks at top-level
            for k in ("tasks", "list", "items"):
                seq = resp.get(k)
                if isinstance(seq, list):
                    return [x for x in seq if isinstance(x, dict)]
            return []

        def _hash_bytes(v: str) -> bytes | None:
            """Convert BTIH/hash into raw bytes when possible.

            115/CD2 may represent infoHash as base32 (32 chars) or hex (40 chars).
            """
            v0 = (v or "").strip()
            if not v0:
                return None
            low = v0.lower()
            try:
                # 40 hex
                if len(low) == 40 and all(c in "0123456789abcdef" for c in low):
                    return bytes.fromhex(low)
            except Exception:
                pass
            # base32 (usually 32 chars) -> bytes
            try:
                import base64

                b32 = low.upper()
                if len(b32) == 32:
                    # add padding
                    pad = "=" * ((8 - (len(b32) % 8)) % 8)
                    return base64.b32decode(b32 + pad)
            except Exception:
                return None
            return None

        async def _fetch_title(item_id: object) -> str:
            try:
                tid = int(str(item_id))
            except Exception:
                return ""
            try:
                row = await pool.fetchrow("SELECT title FROM public.article WHERE tid=$1", tid)
                return str(row.get("title") or "").strip() if row else ""
            except Exception:
                return ""

        while not self._stop_event.is_set():
            try:
                try:
                    cfg = load_crawler_config()
                    poll_interval_ms = int(cfg.poll_interval_ms)
                except Exception:
                    cfg = None

                if not cfg or not getattr(cfg, "deliver_115_enabled", False):
                    await asyncio.sleep(1.0)
                    continue

                client = get_cloud115_client()
                if client is None:
                    await asyncio.sleep(1.0)
                    continue

                due = await pick_tasks_to_poll(pool, deliver_to="115", limit=50)
                if not due:
                    await asyncio.sleep(max(0.5, poll_interval_ms / 1000.0))
                    continue

                for task in due:
                    tid = str(task.get("id") or "").strip()
                    if not tid:
                        continue

                    attempts = int(task.get("poll_attempts") or 0)
                    btih = str(task.get("remote_task_id") or "").strip() or str(
                        magnet_hash(str(task.get("magnet") or "")) or ""
                    ).strip()

                    if not btih:
                        await cd2_update_poll_result(
                            pool,
                            task_id=tid,
                            remote_status="unknown",
                            remote_error_msg="missing_btih",
                            next_poll_after_sec=_backoff(attempts + 1),
                            terminal=False,
                        )
                        continue

                    found: dict | None = None
                    # Page 1 is usually enough because we only track recently submitted tasks.
                    max_pages = 3
                    for page in range(1, max_pages + 1):
                        try:
                            resp = await client.fetch_task_list(page=page)
                        except Exception as e:
                            await cd2_update_poll_result(
                                pool,
                                task_id=tid,
                                remote_status=str(task.get("remote_status") or "unknown"),
                                remote_error_msg=str(e)[:500],
                                next_poll_after_sec=_backoff(attempts + 1),
                                terminal=False,
                            )
                            resp = None
                        if not resp:
                            break
                        target_b = _hash_bytes(btih)
                        target_s = (btih or "").strip().lower()
                        for it in _iter_115_tasks(resp):
                            ih_raw = str(
                                it.get("info_hash")
                                or it.get("infohash")
                                or it.get("infoHash")
                                or it.get("hash")
                                or ""
                            ).strip()
                            if not ih_raw:
                                continue
                            # Prefer bytes-compare when possible (base32 vs hex)
                            ih_b = _hash_bytes(ih_raw)
                            if target_b is not None and ih_b is not None:
                                if ih_b == target_b:
                                    found = it
                                    break
                                continue
                            if ih_raw.strip().lower() == target_s:
                                found = it
                                break
                        if found is not None:
                            break

                    if found is None:
                        # Not found yet: keep polling with backoff; after many attempts, fail loudly.
                        if attempts >= 12:
                            await cd2_update_poll_result(
                                pool,
                                task_id=tid,
                                remote_status="failed",
                                remote_error_msg=f"115_task_not_found(btih={btih})",
                                terminal=True,
                            )
                            title = await _fetch_title(task.get("item_id"))
                            biz.fail(
                                "🧨 115 投递失败（任务未找到）",
                                item_id=str(task.get("item_id") or ""),
                                task_id=tid,
                                btih=(btih[:12] + "…" if btih else ""),
                            )
                            await try_notify_delivery(
                                pool,
                                cfg=cfg,
                                task=task,
                                terminal_status="failed",
                                message=f"🧨 115 投递失败（任务未找到）\n\n🧩 {title or ''}\n🧲 {btih[:12]}…\n🆔 {tid}",
                                biz=biz,
                            )
                        else:
                            await cd2_update_poll_result(
                                pool,
                                task_id=tid,
                                remote_status="not_found",
                                remote_error_msg=None,
                                next_poll_after_sec=_backoff(attempts + 1),
                                terminal=False,
                            )
                        continue

                    raw_status = found.get("status") if isinstance(found, dict) else None
                    prog = _parse_progress(
                        found.get("percent")
                        or found.get("progress")
                        or found.get("process")
                        or found.get("percentDone")
                        or found.get("percendDone")
                    )
                    r_status = _map_status(raw_status, prog)
                    r_err = str(
                        found.get("error")
                        or found.get("err")
                        or found.get("error_msg")
                        or found.get("message")
                        or ""
                    ).strip()

                    if r_status in ("success", "failed"):
                        await cd2_update_poll_result(
                            pool,
                            task_id=tid,
                            remote_status=r_status,
                            remote_progress=prog,
                            remote_error_msg=r_err[:500] if r_err else None,
                            terminal=True,
                        )

                        title = await _fetch_title(task.get("item_id"))
                        short = btih[:12] + "…" if btih else ""
                        msg = ""
                        if r_status == "success":
                            biz.ok(
                                "✅ 115 下载完成",
                                item_id=str(task.get("item_id") or ""),
                                task_id=tid,
                                btih=short,
                                progress=prog,
                            )
                            msg = f"✅ 115 下载完成\n\n🧩 {title or ''}\n🧲 {short}\n🆔 {tid}"
                        else:
                            biz.fail(
                                "🧨 115 下载失败",
                                item_id=str(task.get("item_id") or ""),
                                task_id=tid,
                                btih=short,
                                progress=prog,
                                error=(r_err[:200] if r_err else ""),
                            )
                            msg = f"🧨 115 下载失败\n\n🧩 {title or ''}\n🧲 {short}\n🆔 {tid}\n💥 {r_err[:200]}"

                        await try_notify_delivery(
                            pool,
                            cfg=cfg,
                            task=task,
                            terminal_status=r_status,
                            message=msg,
                            biz=biz,
                        )
                        continue

                    await cd2_update_poll_result(
                        pool,
                        task_id=tid,
                        remote_status=r_status,
                        remote_progress=prog,
                        remote_error_msg=r_err[:500] if r_err else None,
                        next_poll_after_sec=_backoff(attempts + 1),
                        terminal=False,
                    )

            except asyncio.CancelledError:
                raise
            except Exception as e:
                suppress(site="crawler/service:115_poll_loop", exc=e, logger=biz, fallback=None)
                await asyncio.sleep(1.0)