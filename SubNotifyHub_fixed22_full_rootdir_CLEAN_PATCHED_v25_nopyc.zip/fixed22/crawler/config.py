from __future__ import annotations

from dataclasses import dataclass

import json
from pathlib import Path

from core.env_utils import env_int, env_str


def _env_str(key: str, default: str = "") -> str:
    return str(env_str(key, default) or default).strip()


def _overrides_path() -> Path:
    # Keep consistent with admin/routes_crawler.py
    p = env_str("CRAWLER_OVERRIDES_FILE", "/data/crawler_overrides.json")
    return Path(p)


def _read_overrides() -> dict:
    path = _overrides_path()
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8") or "{}") or {}
    except Exception:
        return {}
    return {}


def _as_bool(v: object, default: bool = False) -> bool:
    if isinstance(v, bool):
        return v
    if isinstance(v, (int, float)):
        return int(v) != 0
    if isinstance(v, str):
        s = v.strip().lower()
        if s in {"1", "true", "yes", "y", "on"}:
            return True
        if s in {"0", "false", "no", "n", "off"}:
            return False
    return default


def _as_int(v: object, default: int) -> int:
    try:
        if v is None:
            return default
        return int(v)
    except Exception:
        return default


def _as_str_list(v: object) -> tuple[str, ...]:
    if v is None:
        return tuple()
    if isinstance(v, (list, tuple)):
        return tuple([str(x).strip() for x in v if str(x).strip()])
    if isinstance(v, str):
        return _parse_csv(v)
    return tuple()


def _as_int_list(v: object) -> tuple[int, ...]:
    if v is None:
        return tuple()
    if isinstance(v, (list, tuple)):
        out: list[int] = []
        for x in v:
            try:
                out.append(int(x))
            except Exception:
                continue
        return tuple(out)
    if isinstance(v, str):
        return _parse_int_csv(v)
    return tuple()


@dataclass(frozen=True)
class CrawlerConfig:
    enabled: bool

    pg_dsn: str
    pg_schema: str

    http_concurrency: int
    browser_concurrency: int
    offline_concurrency: int
    poll_interval_ms: int

    # network/runtime
    network_user_agent: str
    network_proxy_url: str
    network_timeout_s: int

    heartbeat_interval_s: int
    job_stale_timeout_s: int
    delivery_stale_timeout_s: int
    reaper_interval_s: int

    rsshub_host: str

    sources: tuple[str, ...]

    # sehuatang (色花堂) discover config
    # - sections: default section list for UI meta (planner will prefer enabled subscriptions)
    # - discover_mode: stop_tid (default) or by_date
    sehuatang_sections: tuple[str, ...]
    sehuatang_page_limit: int
    sehuatang_discover_mode: str
    # default discover mode (auto/fast/compat/browser) used when planning without subscriptions
    sehuatang_default_mode: str

    t66y_sections: tuple[str, ...]
    javbus_categories: tuple[str, ...]

    flaresolverr_url: str

    # planner scheduling
    planner_cron: str
    planner_run_on_start: bool
    planner_enabled: bool

    # delivery (used by delivery workers + UI)
    deliver_115_enabled: bool
    deliver_115_retry: int
    deliver_115_timeout_s: int
    deliver_115_save_path: str

    deliver_cd2_enabled: bool
    # DEPRECATED: deliver_cd2_url / deliver_cd2_api_key kept for migration only
    deliver_cd2_url: str
    deliver_cd2_api_key: str
    deliver_cd2_save_path: str

    # New CD2 config (route1): CloudAPI or gRPC (recommended: cloudapi via username/password)
    deliver_cd2_mode: str  # cloudapi | grpc
    deliver_cd2_base_url: str  # e.g. http://127.0.0.1:19798
    deliver_cd2_username: str
    deliver_cd2_password: str
    deliver_cd2_grpc_addr: str  # optional: host:port
    deliver_cd2_token: str  # optional: bearer token for grpc mode
    # optional (grpc): Some CD2 builds require cloud identity to query offline list.
    deliver_cd2_cloud_name: str
    deliver_cd2_cloud_account_id: str
    deliver_cd2_auto_mkdir: bool

    # Optional webhook secret for /cd2/task
    deliver_cd2_webhook_secret: str

    # Default TG notify policy for *delivery results* (global switch)
    # 开启：投递最终成功/失败都通知；关闭：都不通知（强制覆盖任务级别设置）
    # NOTE: This switch only affects delivery result notifications (115 + CD2)
    # and MUST NOT affect other notification categories (e.g.订阅更新/系统告警).
    deliver_notify_enabled: bool

    # Backward-compat: old name kept for existing code/DB; should mirror deliver_notify_enabled
    deliver_cd2_notify_enabled: bool

    # Backward-compat (kept for DB columns; UI uses notify_enabled)
    deliver_cd2_notify_success: bool
    deliver_cd2_notify_failed: bool



def _parse_csv(raw: str) -> tuple[str, ...]:
    raw = (raw or "").strip()
    if not raw:
        return tuple()
    parts = []
    for p in raw.replace(";", ",").split(","):
        p = p.strip()
        if p:
            parts.append(p)
    # de-dup
    out = []
    seen = set()
    for p in parts:
        if p in seen:
            continue
        seen.add(p)
        out.append(p)
    return tuple(out)


def _parse_int_csv(raw: str) -> tuple[int, ...]:
    out: list[int] = []
    for p in _parse_csv(raw):
        try:
            out.append(int(p))
        except Exception:
            continue
    return tuple(out)


def load_crawler_config() -> CrawlerConfig:
    # 默认开启 crawler：若 PG DSN 未配置，会在 service.start() 阶段判定不可用并跳过启动。
    # 默认关闭 crawler：仅在配置了 CRAWLER_ENABLED=1 且（配置 cron 或 UI 手动触发）时运行。
    # 默认开启：用于消费投递队列/后台任务；不会主动抓取外网（sources 默认空，planner 默认关闭）
    enabled = env_int("CRAWLER_ENABLED", 1) == 1

    # --- 源默认配置（尽量做到开箱即用；可用 env 覆盖） ---
    default_sehuatang_sections = "国产原创,亚洲无码原创,亚洲有码原创,高清中文字幕,素人有码系列,4K原版,VR视频区,欧美无码"
    default_t66y_sections = "亚洲无码原创,高清中文字幕,国产精品,动漫,亚洲有码原创,欧美无码"

    # env baseline
    cfg = {
        "crawler": {
            "enabled": enabled,
            "http_concurrency": max(1, env_int("CRAWLER_HTTP_CONCURRENCY", 10)),
            "browser_concurrency": max(1, env_int("CRAWLER_BROWSER_CONCURRENCY", 2)),
            "offline_concurrency": max(1, env_int("CRAWLER_OFFLINE_CONCURRENCY", 3)),
            "poll_interval_ms": max(100, env_int("CRAWLER_JOB_POLL_INTERVAL_MS", 500)),
            # 默认不配置 sources，避免未启用/未手动触发时产生外网请求；可通过 ENV 或 UI 覆盖。
            "sources": list(_parse_csv(_env_str("CRAWLER_SOURCES", ""))),
            # 可选：FlareSolverr 地址。留空则不启用。
            # 说明：以前默认是 http://flaresolverr:8191，若未部署会导致 ConnectError。
            "flaresolverr_url": _env_str("FLARE_SOLVERR_URL", ""),
        },
        "network": {
            # 可被 admin/crawler/config.json 覆盖
            "user_agent": _env_str(
                "CRAWLER_USER_AGENT",
                "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
            ),
            "proxy_url": _env_str("CRAWLER_PROXY_URL", ""),
            "timeout_s": max(3, env_int("CRAWLER_HTTP_TIMEOUT_S", 25)),
        },
        "runtime": {
            # worker 在执行 job 时会定期刷新 heartbeat；reaper 会回收卡死任务
            "heartbeat_interval_s": max(5, env_int("CRAWLER_HEARTBEAT_INTERVAL_S", 20)),
            "job_stale_timeout_s": max(30, env_int("CRAWLER_JOB_STALE_TIMEOUT_S", 180)),
            "delivery_stale_timeout_s": max(60, env_int("CRAWLER_DELIVERY_STALE_TIMEOUT_S", 900)),
            "reaper_interval_s": max(10, env_int("CRAWLER_REAPER_INTERVAL_S", 60)),
        },
        "planner": {
            # 默认不设 cron；仅当你明确配置 cron 时才会自动规划任务。
            "cron": _env_str("CRAWLER_PLANNER_CRON", ""),
            "run_on_start": env_int("CRAWLER_PLANNER_RUN_ON_START", 0) == 1,
            # 默认禁用 planner，避免“没配置也自动跑”。
            "enabled": env_int("CRAWLER_PLANNER_ENABLED", 0) == 1,
        },
        "deliver_115": {
            "enabled": env_int("CRAWLER_DELIVER_115_ENABLED", 0) == 1,
            "retry": max(0, env_int("CRAWLER_DELIVER_115_RETRY", 3)),
            "timeout_s": max(5, env_int("CRAWLER_DELIVER_115_TIMEOUT_S", 30)),
            # No implicit default path
            "save_path": _env_str("CRAWLER_SAVE_PATH_115", "").strip(),
        },
        "deliver_cd2": {
            "enabled": env_int("CRAWLER_DELIVER_CD2_ENABLED", 0) == 1,
            "url": _env_str("CD2_URL", ""),
            "api_key": _env_str("CD2_API_KEY", ""),
            "save_path": _env_str("CRAWLER_SAVE_PATH_CD2", "").strip(),
            # route1 (recommended)
            "mode": _env_str("CRAWLER_DELIVER_CD2_MODE", "cloudapi") or "cloudapi",
            "base_url": _env_str("CRAWLER_DELIVER_CD2_BASE_URL", "") or _env_str("CD2_URL", ""),
            "username": _env_str("CRAWLER_DELIVER_CD2_USERNAME", ""),
            "password": _env_str("CRAWLER_DELIVER_CD2_PASSWORD", ""),
            "grpc_addr": _env_str("CRAWLER_DELIVER_CD2_GRPC_ADDR", ""),
            "token": _env_str("CRAWLER_DELIVER_CD2_TOKEN", "") or _env_str("CD2_API_KEY", ""),
            "auto_mkdir": env_int("CRAWLER_DELIVER_CD2_AUTO_MKDIR", 1) == 1,
            # optional webhook/notify defaults
            "webhook_secret": _env_str("CRAWLER_DELIVER_CD2_WEBHOOK_SECRET", ""),
            # Notify switch: on => success+failed both notify; off => none.
            # Backward-compat: if CRAWLER_DELIVER_CD2_NOTIFY_ENABLED not set, fall back to old SUCCESS/FAILED envs.
            "notify_enabled": (lambda: (
                (env_int("CRAWLER_DELIVER_CD2_NOTIFY_ENABLED", -1) == 1)
                if env_int("CRAWLER_DELIVER_CD2_NOTIFY_ENABLED", -1) in (0, 1)
                else (
                    (env_int("CRAWLER_DELIVER_CD2_NOTIFY_SUCCESS", 0) == 1)
                    or (env_int("CRAWLER_DELIVER_CD2_NOTIFY_FAILED", 1) == 1)
                )
            ))(),
            "notify_success": (lambda ne: bool(ne))((lambda: (
                (env_int("CRAWLER_DELIVER_CD2_NOTIFY_ENABLED", -1) == 1)
                if env_int("CRAWLER_DELIVER_CD2_NOTIFY_ENABLED", -1) in (0, 1)
                else (
                    (env_int("CRAWLER_DELIVER_CD2_NOTIFY_SUCCESS", 0) == 1)
                    or (env_int("CRAWLER_DELIVER_CD2_NOTIFY_FAILED", 1) == 1)
                )
            ))()),
            "notify_failed": (lambda ne: bool(ne))((lambda: (
                (env_int("CRAWLER_DELIVER_CD2_NOTIFY_ENABLED", -1) == 1)
                if env_int("CRAWLER_DELIVER_CD2_NOTIFY_ENABLED", -1) in (0, 1)
                else (
                    (env_int("CRAWLER_DELIVER_CD2_NOTIFY_SUCCESS", 0) == 1)
                    or (env_int("CRAWLER_DELIVER_CD2_NOTIFY_FAILED", 1) == 1)
                )
            ))()),
        },
        "sehuatang": {
            # section list is primarily for UI meta; planner will prefer enabled subscriptions.
            "sections": list(_parse_csv(_env_str("CRAWLER_SEHUATANG_SECTIONS", default_sehuatang_sections))),
            "page_limit": max(1, env_int("CRAWLER_SEHUATANG_PAGE_LIMIT", 9)),
            "discover_mode": _env_str("CRAWLER_SEHUATANG_DISCOVER_MODE", "stop_tid") or "stop_tid",
            "default_mode": _env_str("CRAWLER_SEHUATANG_DEFAULT_MODE", "auto") or "auto",
        },
        "t66y": {
            "sections": list(_parse_csv(_env_str("CRAWLER_T66Y_SECTIONS", default_t66y_sections))),
        },
        "javbus": {
            "categories": list(_parse_csv(_env_str("CRAWLER_JAVBUS_CATEGORIES", "latest"))),
        },
    }

    # UI overrides: /admin/crawler/config.json writes into CRAWLER_OVERRIDES_FILE
    overrides = _read_overrides()
    if isinstance(overrides, dict):
        # NOTE:
        # Admin UI writes into overrides (CRAWLER_OVERRIDES_FILE) and expects settings to
        # survive refresh/restart.
        #
        # Previously we only merged a small whitelist, which caused "保存配置" to look
        # successful but be silently ignored on reload for delivery toggles/paths.
        for k in (
            "crawler",
            "planner",
            "network",
            "runtime",
            "deliver_115",
            "deliver_cd2",
            "deliver_saver",
            "sehuatang",
            "t66y",
            "javbus",
        ):
            if isinstance(overrides.get(k), dict) and isinstance(cfg.get(k), dict):
                cfg[k].update(overrides[k])

    return CrawlerConfig(
        enabled=_as_bool(cfg.get("crawler", {}).get("enabled"), default=enabled),
        pg_dsn=_env_str("CRAWLER_PG_DSN", ""),
        pg_schema=_env_str("CRAWLER_PG_SCHEMA", "crawler") or "crawler",
        http_concurrency=max(1, _as_int(cfg.get("crawler", {}).get("http_concurrency"), 10)),
        browser_concurrency=max(1, _as_int(cfg.get("crawler", {}).get("browser_concurrency"), 2)),
        offline_concurrency=max(1, _as_int(cfg.get("crawler", {}).get("offline_concurrency"), 3)),
        poll_interval_ms=max(100, _as_int(cfg.get("crawler", {}).get("poll_interval_ms"), 500)),
        network_user_agent=str((cfg.get("network", {}).get("user_agent") or "")).strip(),
        network_proxy_url=str((cfg.get("network", {}).get("proxy_url") or "")).strip(),
        network_timeout_s=max(3, _as_int(cfg.get("network", {}).get("timeout_s"), 25)),
        heartbeat_interval_s=max(5, _as_int(cfg.get("runtime", {}).get("heartbeat_interval_s"), 20)),
        job_stale_timeout_s=max(30, _as_int(cfg.get("runtime", {}).get("job_stale_timeout_s"), 180)),
        delivery_stale_timeout_s=max(60, _as_int(cfg.get("runtime", {}).get("delivery_stale_timeout_s"), 900)),
        reaper_interval_s=max(10, _as_int(cfg.get("runtime", {}).get("reaper_interval_s"), 60)),
        # 常见部署：docker-compose 里跑 rsshub/flaresolverr
        rsshub_host=_env_str("RSSHUB_HOST", "http://rsshub:1200"),
        sources=_as_str_list(cfg.get("crawler", {}).get("sources")),
        sehuatang_sections=_as_str_list(cfg.get("sehuatang", {}).get("sections")),
        sehuatang_page_limit=max(1, _as_int(cfg.get("sehuatang", {}).get("page_limit"), 9)),
        sehuatang_discover_mode=str((cfg.get("sehuatang", {}).get("discover_mode") or "stop_tid")).strip() or "stop_tid",
        sehuatang_default_mode=str((cfg.get("sehuatang", {}).get("default_mode") or "auto")).strip().lower() or "auto",
        t66y_sections=_as_str_list(cfg.get("t66y", {}).get("sections")),
        javbus_categories=_as_str_list(cfg.get("javbus", {}).get("categories")) or _parse_csv("latest"),
        # 允许通过 UI overrides（crawler.flaresolverr_url）配置；留空则不启用。
        flaresolverr_url=str(
            (
                cfg.get("crawler", {}).get("flaresolverr_url")
                or _env_str("FLARE_SOLVERR_URL", "")
                or ""
            )
        ).strip(),
        planner_cron=str((cfg.get("planner", {}).get("cron") or "0 3 * * *")).strip() or "0 3 * * *",
        planner_run_on_start=_as_bool(cfg.get("planner", {}).get("run_on_start"), default=False),
        planner_enabled=_as_bool(cfg.get("planner", {}).get("enabled"), default=True),
        deliver_115_enabled=_as_bool(cfg.get("deliver_115", {}).get("enabled"), default=False),
        deliver_115_retry=int(cfg.get("deliver_115", {}).get("retry") or 3),
        deliver_115_timeout_s=int(cfg.get("deliver_115", {}).get("timeout_s") or 30),
        deliver_115_save_path=str((cfg.get("deliver_115", {}).get("save_path") or "")).strip(),

        deliver_cd2_enabled=_as_bool(cfg.get("deliver_cd2", {}).get("enabled"), default=False),
        # DEPRECATED (kept for migration)
        deliver_cd2_url=str((cfg.get("deliver_cd2", {}).get("url") or "")).strip(),
        deliver_cd2_api_key=str((cfg.get("deliver_cd2", {}).get("api_key") or "")).strip(),
        deliver_cd2_save_path=str((cfg.get("deliver_cd2", {}).get("save_path") or "")).strip(),

        # New CD2 config
        deliver_cd2_mode=str((cfg.get("deliver_cd2", {}).get("mode") or "cloudapi")).strip() or "cloudapi",
        deliver_cd2_base_url=str((cfg.get("deliver_cd2", {}).get("base_url") or cfg.get("deliver_cd2", {}).get("url") or "")).strip(),
        deliver_cd2_username=str((cfg.get("deliver_cd2", {}).get("username") or "")).strip(),
        deliver_cd2_password=str((cfg.get("deliver_cd2", {}).get("password") or "")).strip(),
        deliver_cd2_grpc_addr=str((cfg.get("deliver_cd2", {}).get("grpc_addr") or "")).strip(),
        deliver_cd2_token=str((cfg.get("deliver_cd2", {}).get("token") or cfg.get("deliver_cd2", {}).get("api_key") or "")).strip(),
        deliver_cd2_cloud_name=str((cfg.get("deliver_cd2", {}).get("cloud_name") or cfg.get("deliver_cd2", {}).get("cloudName") or "")).strip(),
        deliver_cd2_cloud_account_id=str((cfg.get("deliver_cd2", {}).get("cloud_account_id") or cfg.get("deliver_cd2", {}).get("cloudAccountId") or "")).strip(),
        deliver_cd2_auto_mkdir=_as_bool(cfg.get("deliver_cd2", {}).get("auto_mkdir"), default=True),

        deliver_cd2_webhook_secret=str((cfg.get("deliver_cd2", {}).get("webhook_secret") or "")).strip(),

        # Global delivery result notify switch (115 + CD2)
        deliver_notify_enabled=_as_bool(
            cfg.get("deliver", {}).get("notify_enabled"),
            default=_as_bool(cfg.get("deliver_cd2", {}).get("notify_enabled"), default=True),
        ),
        # Backward compat: mirror to old field name
        deliver_cd2_notify_enabled=_as_bool(
            cfg.get("deliver", {}).get("notify_enabled"),
            default=_as_bool(cfg.get("deliver_cd2", {}).get("notify_enabled"), default=True),
        ),
        deliver_cd2_notify_success=_as_bool(cfg.get("deliver_cd2", {}).get("notify_success"), default=True),
        deliver_cd2_notify_failed=_as_bool(cfg.get("deliver_cd2", {}).get("notify_failed"), default=True),
    )
