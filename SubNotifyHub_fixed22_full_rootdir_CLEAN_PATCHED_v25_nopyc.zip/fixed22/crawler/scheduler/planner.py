from __future__ import annotations

import asyncio
import hashlib
import json
import uuid
from datetime import date, datetime, timedelta
from typing import Any

from core.logging import get_biz_logger
from core.suppress import suppress

from crawler.config import CrawlerConfig, load_crawler_config
from crawler.db.pg import PgPool
from crawler.scheduler.cron import next_run_after


biz = get_biz_logger(__name__)


def _dedup_key(queue: str, source: str, kind: str, params: dict[str, Any]) -> str:
    payload = json.dumps({"q": queue, "s": source, "k": kind, "p": params}, ensure_ascii=False, sort_keys=True)
    return hashlib.sha1(payload.encode("utf-8")).hexdigest()


async def _insert_job(pool: PgPool, *, queue: str, source: str, kind: str, params: dict[str, Any]) -> None:
    dk = _dedup_key(queue, source, kind, params)
    job_id = uuid.uuid4()
    sql = """
    INSERT INTO crawler.crawler_jobs (id, queue, source, kind, params, dedup_key, status, run_after)
    VALUES ($1, $2, $3, $4, $5::jsonb, $6, 'pending', now())
    ON CONFLICT (dedup_key) DO UPDATE
    SET queue=EXCLUDED.queue,
        source=EXCLUDED.source,
        kind=EXCLUDED.kind,
        params=EXCLUDED.params,
        updated_at=now(),
        status=CASE WHEN crawler.crawler_jobs.status='done' THEN 'pending' ELSE crawler.crawler_jobs.status END,
        run_after=CASE WHEN crawler.crawler_jobs.status='done' THEN now() ELSE crawler.crawler_jobs.run_after END,
        attempt=CASE WHEN crawler.crawler_jobs.status='done' THEN 0 ELSE crawler.crawler_jobs.attempt END,
        last_error=CASE WHEN crawler.crawler_jobs.status='done' THEN NULL ELSE crawler.crawler_jobs.last_error END,
        progress_done=CASE WHEN crawler.crawler_jobs.status='done' THEN 0 ELSE crawler.crawler_jobs.progress_done END,
        progress_total=CASE WHEN crawler.crawler_jobs.status='done' THEN 0 ELSE crawler.crawler_jobs.progress_total END
    WHERE crawler.crawler_jobs.status != 'running'
    """
    await pool.execute(sql, job_id, queue, source, kind, params, dk)


async def planner_tick(pool: PgPool, cfg: CrawlerConfig) -> int:
    """Plan one round of discover jobs (idempotent).

    Returns the number of *attempted* insertions (dedup may ignore duplicates).
    """
    today = date.today()
    days = [today, today - timedelta(days=1)]
    attempted = 0

    for source in cfg.sources:
        if source == "javbee":
            for d in days:
                await _insert_job(pool, queue="http", source=source, kind="discover", params={"date": d.isoformat()})
                attempted += 1

        elif source == "t66y":
            await _insert_job(pool, queue="http", source=source, kind="discover", params={"sections": list(cfg.t66y_sections)})
            attempted += 1

        elif source == "javbus":
            await _insert_job(pool, queue="http", source=source, kind="discover", params={"categories": list(cfg.javbus_categories)})
            attempted += 1

        elif source == "sehuatang":
            # Plan based on enabled subscriptions first.
            # If there are no subscriptions yet, fallback to UI-configured sections + default_mode.
            rows = await pool.fetchall(
                """
                SELECT DISTINCT
                    COALESCE(NULLIF(rule->>'section',''), '') AS section,
                    COALESCE(NULLIF(rule->>'mode',''), 'auto') AS mode
                FROM crawler.crawler_subscriptions
                WHERE sub_type='rule' AND is_enabled=true AND rule->>'source'='sehuatang'
                """
            )
            pairs: list[tuple[str, str]] = []
            for r in rows or []:
                sec = str((r or {}).get("section") or "").strip()
                md = str((r or {}).get("mode") or "auto").strip().lower() or "auto"
                pairs.append((sec, md))

            if not pairs and cfg.sehuatang_sections:
                md0 = str(getattr(cfg, "sehuatang_default_mode", "auto") or "auto").strip().lower() or "auto"
                pairs = [(str(s), md0) for s in (cfg.sehuatang_sections or ("",))]

            discover_mode = str(cfg.sehuatang_discover_mode or "stop_tid").strip() or "stop_tid"
            # normalize: expand empty section into default sections
            expanded: list[tuple[str, str]] = []
            for sec, md in pairs:
                if sec:
                    expanded.append((sec, md))
                else:
                    for s in (cfg.sehuatang_sections or ("",)):
                        expanded.append((str(s), md))

            # de-dup expanded list
            uniq = sorted(set(expanded))

            if discover_mode == "by_date":
                for d in days:
                    for sec, md in uniq:
                        await _insert_job(
                            pool,
                            queue="http",
                            source=source,
                            kind="discover",
                            params={"discover_mode": "by_date", "date": d.isoformat(), "section": sec, "mode": md},
                        )
                        attempted += 1
            else:
                for sec, md in uniq:
                    await _insert_job(
                        pool,
                        queue="http",
                        source=source,
                        kind="discover",
                        params={"discover_mode": "stop_tid", "section": sec, "mode": md},
                    )
                    attempted += 1

    return attempted


async def planner_loop(pool: PgPool, cfg: CrawlerConfig, ctx: dict[str, Any], *, stop_event: asyncio.Event) -> None:
    """Cron-driven job planner (idempotent).

    - Uses dedup_key to avoid infinite job accumulation.
    - Date-based sources: schedule today & yesterday discover jobs.
    - Page-based sources: schedule first page batch (plugins can enqueue next pages).
    """

    async def _tick(cur: CrawlerConfig) -> None:
        try:
            with biz.entry(domain="爬虫", action="任务规划", 触发="cron", cron表达式=cur.planner_cron, 启用=bool(getattr(cur,"planner_enabled",True))):
                if not getattr(cur, "planner_enabled", True):
                    biz.warning("⚠️ 已跳过本轮任务规划：Planner 已被禁用（enabled=false）。",
                             说明="你仍可以在 UI 点击“立即跑一次”手动触发。")
                    return
                biz.step("开始生成一轮 discover 任务（幂等插入，重复任务会自动忽略）", 源数量=len(cur.sources))
                attempted = await planner_tick(pool, cur)
                biz.ok(
                    "✅ 本轮爬虫任务规划完成：已尝试插入 discover 任务。",
                    源列表=list(cur.sources),
                    尝试插入数=attempted,
                    说明="若同参数任务已存在，会被 dedup_key 自动忽略（属正常行为）。",
                )
        except Exception as e:
            biz.fail(
                "❌ 生成爬虫 discover 任务失败：本轮已跳过，将在下一次 cron 继续尝试。",
                原因=str(e),
                建议="检查 PostgreSQL 是否可用、crawler schema 是否存在、以及 cron 表达式是否有效。",
                exc=e,
            )

    # run once at start (default), then follow cron
    try:
        cfg = load_crawler_config()
    except Exception as e:
        # keep initial cfg if reload fails
        suppress(site="crawler/planner:reload_config(start)", exc=e, logger=biz, fallback=None)

    if cfg.planner_run_on_start:
        await _tick(cfg)

    while not stop_event.is_set():
        # Hot-reload config on every cycle: cron expr / sources / sections etc.
        try:
            cfg = load_crawler_config()
        except Exception as e:
            # keep last cfg
            suppress(site="crawler/planner:reload_config(loop)", exc=e, logger=biz, fallback=None)

        # allow disabling planner without killing crawler
        if not getattr(cfg, "planner_enabled", True):
            try:
                await asyncio.wait_for(stop_event.wait(), timeout=2.0)
            except asyncio.TimeoutError:
                continue

        # compute next scheduled time
        # If cron expr is empty, planner is effectively disabled (UI can still run_once).
        if not str(getattr(cfg, 'planner_cron', '') or '').strip():
            try:
                await asyncio.wait_for(stop_event.wait(), timeout=2.0)
            except asyncio.TimeoutError:
                continue
        now = datetime.now()
        try:
            nxt = next_run_after(cfg.planner_cron, after=now)
        except Exception:
            # fallback to 5 minutes
            nxt = now + timedelta(minutes=5)

        delay = max(1.0, (nxt - now).total_seconds())
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=delay)
        except asyncio.TimeoutError:
            # allow pausing planner by disabling crawler
            if not getattr(cfg, "enabled", True):
                continue
            await _tick(cfg)
            continue
