from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta

_MONTH_NAMES = {
    "JAN": 1, "FEB": 2, "MAR": 3, "APR": 4, "MAY": 5, "JUN": 6,
    "JUL": 7, "AUG": 8, "SEP": 9, "OCT": 10, "NOV": 11, "DEC": 12,
}
_DOW_NAMES = {"SUN": 0, "MON": 1, "TUE": 2, "WED": 3, "THU": 4, "FRI": 5, "SAT": 6}

def _to_int(tok: str, *, names: dict[str, int] | None = None) -> int:
    t = (tok or "").strip()
    if not t:
        raise ValueError("empty token")
    up = t.upper()
    if names and up in names:
        return names[up]
    try:
        return int(t)
    except Exception as e:
        raise ValueError(f"invalid number: {tok}") from e

def _parse_field(raw: str, *, min_v: int, max_v: int, names: dict[str, int] | None = None, allow_sunday_7: bool = False) -> tuple[set[int], bool]:
    """Parse one cron field.

    Supports: *, ?, numbers, names (MON/JAN), ranges (a-b), steps (*/n, a-b/n, a/n),
    lists (a,b,c), and combined forms.
    Returns (values, is_any) where is_any is True when raw is '*' or '?'.
    """
    raw = (raw or "").strip()
    if raw in ("*", "?") or raw == "":
        return set(range(min_v, max_v + 1)), True

    out: set[int] = set()

    def add_range(start: int, end: int, step: int = 1) -> None:
        if step <= 0:
            raise ValueError("step must be > 0")
        if start > end:
            raise ValueError("range start > end")
        if start < min_v or end > max_v:
            raise ValueError(f"value out of bounds [{min_v},{max_v}]")
        for v in range(start, end + 1, step):
            out.add(v)

    for part in raw.split(","):
        part = part.strip()
        if not part:
            raise ValueError("empty list item")

        step = 1
        base = part
        if "/" in part:
            base, step_s = part.split("/", 1)
            base = base.strip()
            step_s = step_s.strip()
            step = _to_int(step_s)
            if step <= 0:
                raise ValueError("invalid step")

        if base in ("*", "?") or base == "":
            add_range(min_v, max_v, step)
            continue

        # range?
        if "-" in base:
            a, b = base.split("-", 1)
            start = _to_int(a, names=names)
            end = _to_int(b, names=names)
            # Sunday may be 7 in some crons
            if allow_sunday_7:
                if start == 7:
                    start = 0
                if end == 7:
                    end = 0
            # If user writes 5-0 (wrap), treat as invalid (explicitly).
            add_range(start, end, step)
            continue

        # single value with optional step "a/n" meaning a..max step n
        val = _to_int(base, names=names)
        if allow_sunday_7 and val == 7:
            val = 0
        if val < min_v or val > max_v:
            raise ValueError(f"value out of bounds [{min_v},{max_v}]: {val}")
        if "/" in part:
            add_range(val, max_v, step)
        else:
            out.add(val)

    if not out:
        raise ValueError("field matches nothing")
    return out, False


@dataclass(frozen=True)
class CronSpec:
    """Cron matcher (classic 5 fields).

    Fields: minute hour day_of_month month day_of_week

    Enhancements over the previous tiny parser:
    - ranges: 1-5
    - steps: */5, 1-10/2, 3/15
    - lists: 1,2,3
    - names: JAN..DEC and SUN..SAT
    - day_of_week allows 0 or 7 for Sunday

    **Matching rule (Vixie cron compatible)**:
    - If day_of_month and day_of_week are both restricted (not '*'),
      a datetime matches when EITHER dom matches OR dow matches.
    - If either field is '*', the other field alone is used.
    """

    minutes: set[int]
    hours: set[int]
    dom: set[int]
    months: set[int]
    dow: set[int]
    dom_any: bool
    dow_any: bool

    @classmethod
    def parse(cls, expr: str) -> "CronSpec":
        expr = (expr or "").strip()
        parts = [p for p in expr.split() if p.strip()]
        if len(parts) != 5:
            raise ValueError(f"invalid cron: expected 5 fields, got {len(parts)}")
        minute, hour, dom, month, dow = parts

        minutes, _ = _parse_field(minute, min_v=0, max_v=59)
        hours, _ = _parse_field(hour, min_v=0, max_v=23)
        dom_set, dom_any = _parse_field(dom, min_v=1, max_v=31)
        months, _ = _parse_field(month, min_v=1, max_v=12, names=_MONTH_NAMES)
        dow_set, dow_any = _parse_field(dow, min_v=0, max_v=6, names=_DOW_NAMES, allow_sunday_7=True)

        return cls(
            minutes=minutes,
            hours=hours,
            dom=dom_set,
            months=months,
            dow=dow_set,
            dom_any=dom_any,
            dow_any=dow_any,
        )

    def matches(self, dt: datetime) -> bool:
        # python weekday(): Monday=0..Sunday=6; cron: Sunday=0
        cron_dow = (dt.weekday() + 1) % 7

        if dt.minute not in self.minutes:
            return False
        if dt.hour not in self.hours:
            return False
        if dt.month not in self.months:
            return False

        dom_match = dt.day in self.dom
        dow_match = cron_dow in self.dow

        if self.dom_any and self.dow_any:
            return True
        if self.dom_any:
            return dow_match
        if self.dow_any:
            return dom_match
        return dom_match or dow_match


def next_run_after(expr: str, *, after: datetime | None = None, max_search_minutes: int = 60 * 24 * 400) -> datetime:
    """Compute next run time after `after`.

    Steps minute-by-minute. `max_search_minutes` prevents infinite loops.
    Raises on invalid cron (parse error).
    """
    spec = CronSpec.parse(expr)
    base = (after or datetime.now()).replace(second=0, microsecond=0)
    cur = base + timedelta(minutes=1)

    for _ in range(max_search_minutes):
        if spec.matches(cur):
            return cur
        cur += timedelta(minutes=1)

    raise ValueError("cron search exceeded max_search_minutes")


def validate_cron_expr(expr: str) -> tuple[bool, str | None]:
    """Validate a 5-field cron expression.

    Returns (ok, error_message).
    """
    try:
        CronSpec.parse(expr)
        return True, None
    except Exception as e:
        return False, str(e)
