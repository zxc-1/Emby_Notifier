
from datetime import datetime, timezone
from notifier.telegram import TelegramNotifier
from notifier.models import NotificationContent

def format_crawl_message(summary):
    return f"""🕷️【爬虫完成】

📡 源：{summary.get('sources','')}
⏱ 用时：{summary.get('duration',0)}s

🆕 新增 {summary.get('new',0)}
🔄 更新 {summary.get('updated',0)}
⏭ 跳过 {summary.get('skipped',0)}
❌ 失败 {summary.get('failed',0)}

━━━━━━━━━━━━━━
📂 板块统计

{summary.get('section_rows','')}

━━━━━━━━━━━━━━
{summary.get('tail_hint','')}
"""

def format_delivery_success(method, item):
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M")
    return f"""☁️ 投递成功

📥 {method}
🗂 {item.get('source','')}/{item.get('section','')}
🧩 {item.get('title','')[:40]}

🕒 {now}
"""

def format_delivery_failed(method, item, error):
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M")
    return f"""🧨 投递失败

📥 {method}
🗂 {item.get('source','')}/{item.get('section','')}
🧩 {item.get('title','')[:40]}

💥 {str(error)[:120]}
🕒 {now}
"""

async def send_tg(text: str):
    notifier = TelegramNotifier()
    content = NotificationContent(text=text)
    await notifier.send(content)
