# Crawler module (PostgreSQL)

This is a pluggable crawler subsystem for SubNotifyHub.

## Quick start

1) Enable crawler:

```bash
CRAWLER_ENABLED=1
CRAWLER_PG_DSN=postgresql://user:pass@host:5432/crawlerdb
```

2) Choose sources:

```bash
CRAWLER_SOURCES=sht,sehua,t66y,javbus,javbee
```

3) Run worker process (your existing worker entrypoint). The crawler is started only when enabled.

## How to add a new source

- Copy `crawler/plugins/_template.py` to `crawler/plugins/<source>.py`
- Register in `crawler/plugins/__init__.py`
- Add `<source>` to `CRAWLER_SOURCES`

## SHT modes

- `CRAWLER_SHT_MODE=stop_tid` (default): page batch crawl; plugin/enhancements handle stop conditions.
- `CRAWLER_SHT_MODE=by_date`: planner schedules jobs for today & yesterday; plugin stops paging when older than target date.
