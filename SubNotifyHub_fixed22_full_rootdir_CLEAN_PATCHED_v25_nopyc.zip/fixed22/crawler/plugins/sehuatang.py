from __future__ import annotations

import asyncio
import hashlib
import re
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

from core.env_utils import env_str
from core.exceptions.base import ConfigurationError
from core.logging import get_biz_logger

try:
    from bs4 import BeautifulSoup  # type: ignore
except ModuleNotFoundError:  # pragma: no cover
    BeautifulSoup = None  # type: ignore

from crawler.fetchers.browser import BrowserFetcher, BrowserUnavailable
from crawler.fetchers.flaresolverr import FlareSolverrFetcher
from crawler.fetchers.http import HttpFetcher
from crawler.models.types import Candidate, Item
from crawler.utils.anti_bot import build_browser_headers, extract_magnets, looks_like_challenge
from crawler.utils.media import choose_cover_and_gallery
from crawler.utils.time_parse import parse_date_only


biz = get_biz_logger(__name__)


def _require_bs4() -> None:
    if BeautifulSoup is None:
        raise ConfigurationError("Missing optional dependency: bs4 (beautifulsoup4)")


def _parse_date(s: str) -> str:
    return parse_date_only(s, now=datetime.now())


def _size_mb_from_text(text: str) -> Optional[int]:
    if not text:
        return None
    m = re.search(r"容量\D*(\d+(?:\.\d+)?)\s*(GB|MB)", text, re.IGNORECASE)
    if not m:
        return None
    val = float(m.group(1))
    unit = m.group(2).upper()
    return int(val * 1024) if unit == "GB" else int(val)


class SehuatangPlugin:
    """Sehuatang (色花堂) crawler plugin.

    Unified source name: `sehuatang`.

    UI-facing mode (human-friendly):
    - auto: try http → flaresolverr → browser (best-effort)
    - fast: http only (fastest, may fail on challenge/login wall)
    - compat: flaresolverr first (needs FLARE_SOLVERR_URL)
    - browser: playwright browser (slowest, most compatible)

    Internal discover pagination mode (not UI-facing by default):
    - stop_tid (default)
    - by_date
    """

    name = "sehuatang"
    prefer_queue = "http"  # all jobs can run on http queue; browser is spawned on-demand

    def __init__(self, ctx: dict[str, Any]):
        self.base_url = str(
            ctx.get("sehuatang_domain")
            or ctx.get("sehuatang_base_url")
            or env_str("CRAWLER_SEHUATANG_DOMAIN", "")
            or env_str("CRAWLER_SEHUATANG_BASE_URL", "")
            or ""
        ).strip()
        if not self.base_url:
            # reasonable default
            self.base_url = "https://sehuatang.org"
        self.base_url = self.base_url.rstrip("/")

        # section map: name -> fid
        self.section_map: dict[str, int] = {}
        raw_map = ctx.get("sehuatang_section_map")
        if isinstance(raw_map, dict) and raw_map:
            for k, v in raw_map.items():
                try:
                    self.section_map[str(k).strip()] = int(v)
                except Exception:
                    continue
        if not self.section_map:
            # env: "国产原创:2,中文字幕:103"
            raw = env_str("CRAWLER_SEHUATANG_SECTION_MAP", "").strip()
            mp: dict[str, int] = {}
            for part in [p.strip() for p in raw.split(",") if p.strip()]:
                if ":" in part:
                    k, v = part.split(":", 1)
                    try:
                        mp[k.strip()] = int(v.strip())
                    except Exception:
                        continue
            if not mp:
                # sane defaults (same as legacy)
                mp = {
                    "国产原创": 2,
                    "亚洲无码原创": 36,
                    "亚洲有码原创": 37,
                    "高清中文字幕": 103,
                    "素人有码系列": 104,
                    "4K原版": 151,
                    "VR视频区": 160,
                    "欧美无码": 38,
                }
            self.section_map = mp

        self.page_limit = int(ctx.get("sehuatang_page_limit") or env_str("CRAWLER_SEHUATANG_PAGE_LIMIT", "9"))
        self.discover_mode_default = str(ctx.get("sehuatang_discover_mode") or env_str("CRAWLER_SEHUATANG_DISCOVER_MODE", "stop_tid")).strip() or "stop_tid"

        self.cover_dir = Path(env_str("CRAWLER_COVER_DIR", "data/crawler/covers"))
        self.cover_dir.mkdir(parents=True, exist_ok=True)

    def _section_fid(self, section: str) -> Optional[int]:
        section = (section or "").strip()
        if not section:
            return None
        v = self.section_map.get(section)
        return int(v) if v is not None else None

    def _forum_url(self, fid: int, page: int) -> str:
        return f"{self.base_url}/forum.php?mod=forumdisplay&fid={fid}&page={page}"

    async def _get_browser_fetcher(self, ctx: dict[str, Any]) -> BrowserFetcher:
        bf = ctx.get("browser_fetcher")
        if isinstance(bf, BrowserFetcher):
            return bf
        # create an ephemeral browser fetcher if not present (http workers / run_once)
        state_key = str(self.base_url or "sehuatang")
        try:
            bf = BrowserFetcher(
                state_key=state_key,
                user_agent=str(ctx.get("network_user_agent") or "").strip() or None,
                proxy_url=str(ctx.get("network_proxy_url") or "").strip() or None,
                timeout_s=int(ctx.get("network_timeout_s") or 30),
            )
        except BrowserUnavailable as e:
            raise RuntimeError(f"browser mode unavailable: {e}")
        ctx["browser_fetcher"] = bf
        return bf

    async def _fetch_html(self, ctx: dict[str, Any], url: str, *, mode: str) -> str:
        mode = (mode or "auto").strip().lower() or "auto"
        ua = str(ctx.get("network_user_agent") or "").strip() or None
        proxy = str(ctx.get("network_proxy_url") or "").strip() or None
        timeout_s = float(ctx.get("network_timeout_s") or 25)
        headers = build_browser_headers(user_agent=ua or "Mozilla/5.0", referer=self.base_url)

        async def _http() -> str:
            hf = HttpFetcher(user_agent=ua, proxy_url=proxy, timeout_s=timeout_s)
            return await hf.get_text(url, headers=headers, cookies=None, timeout=timeout_s)

        async def _fs() -> str:
            fs_url = str(ctx.get("flaresolverr_url") or "").strip()
            if not fs_url:
                raise RuntimeError("FLARE_SOLVERR_URL not configured")
            fs = FlareSolverrFetcher(fs_url)
            return await fs.get_text(url, headers=headers, cookies=None, timeout_ms=int(max(30.0, timeout_s) * 1000))

        async def _browser() -> str:
            bf = await self._get_browser_fetcher(ctx)
            return await bf.get(url, wait_until="networkidle", settle_ms=1200)

        if mode == "fast":
            return await _http()
        if mode == "compat":
            return await _fs()
        if mode == "browser":
            return await _browser()

        # auto: try http -> flaresolverr -> browser
        html = ""
        try:
            html = await _http()
            if html and not looks_like_challenge(html):
                return html
        except Exception:
            pass
        try:
            html = await _fs()
            if html and not looks_like_challenge(html):
                return html
        except Exception:
            pass
        return await _browser()

    async def discover(self, ctx: dict[str, Any]) -> list[Candidate]:
        params = (ctx.get("params") or {}) if isinstance(ctx.get("params"), dict) else {}
        section = str(params.get("section") or ctx.get("section") or "").strip()
        mode = str(params.get("mode") or ctx.get("mode") or "auto").strip().lower() or "auto"

        discover_mode = str(params.get("discover_mode") or params.get("scan_mode") or self.discover_mode_default).strip() or self.discover_mode_default
        target_date = str(params.get("date") or ctx.get("date") or "").strip()
        stop_tid = int(params.get("stop_tid") or 0) if str(params.get("stop_tid") or "").isdigit() else 0

        fid = self._section_fid(section)
        if not fid:
            biz.warning("⚠️ sehuatang 版块未映射到 fid：已跳过该版块抓取。", 版块=section)
            return []

        _require_bs4()
        cands: list[Candidate] = []
        consecutive_no_new = 0
        saw_any_hit = False

        for page in range(1, self.page_limit + 1):
            url = self._forum_url(fid, page)
            html = await self._fetch_html(ctx, url, mode=mode)
            soup = BeautifulSoup(html, "lxml")
            rows = soup.select("tbody[id^='normalthread_']")
            page_hits = 0
            page_new = 0

            for row in rows:
                a = row.select_one("a.s.xst")
                if not a:
                    continue
                href = a.get("href") or ""
                title = (a.get_text() or "").strip()

                date_title = ""
                span = row.select_one("td.by em span[title]")
                if span and span.get("title"):
                    date_title = span.get("title") or ""
                else:
                    em = row.select_one("td.by em")
                    if em:
                        date_title = em.get_text(" ", strip=True)
                d = _parse_date(date_title)

                if discover_mode == "by_date" and target_date:
                    if d != target_date:
                        continue

                tid = ""
                m = re.search(r"tid=(\d+)", href)
                if m:
                    tid = m.group(1)
                else:
                    m2 = re.search(r"thread-(\d+)-", href)
                    if m2:
                        tid = m2.group(1)

                detail_url = href
                if detail_url and detail_url.startswith("./"):
                    detail_url = self.base_url + detail_url[1:]
                if detail_url.startswith("forum.php") or detail_url.startswith("thread-"):
                    detail_url = f"{self.base_url}/{detail_url.lstrip('/')}" if not detail_url.startswith("http") else detail_url

                if discover_mode == "stop_tid" and stop_tid:
                    if (tid or "").isdigit() and int(tid) <= stop_tid:
                        continue

                page_hits += 1
                page_new += 1
                saw_any_hit = True

                cands.append(
                    Candidate(
                        external_id=str(tid or ""),
                        detail_url=detail_url,
                        meta={
                            "section": section,
                            "publish_date": (target_date or d or ""),
                            "title": title,
                            "fid": fid,
                            "page": page,
                            "mode": mode,
                            "discover_mode": discover_mode,
                        },
                    )
                )

            if discover_mode == "stop_tid":
                if page_new == 0:
                    consecutive_no_new += 1
                    if consecutive_no_new >= 2:
                        break
                else:
                    consecutive_no_new = 0
            elif discover_mode == "by_date" and target_date:
                if page_hits == 0 and saw_any_hit:
                    consecutive_no_new += 1
                    if consecutive_no_new >= 2:
                        break
                elif page_hits > 0:
                    consecutive_no_new = 0

        return cands

    async def fetch_detail(self, ctx: dict[str, Any], cand: Candidate) -> Item:
        _require_bs4()
        mode = str((cand.meta or {}).get("mode") or (ctx.get("params") or {}).get("mode") or "auto").strip().lower() or "auto"
        html = await self._fetch_html(ctx, cand.detail_url, mode=mode)
        soup = BeautifulSoup(html, "lxml")

        title_el = soup.select_one("span#thread_subject")
        title = title_el.get_text(strip=True) if title_el else (cand.meta.get("title") or "")
        body = soup.select_one("td[id^='postmessage_']") or soup.select_one("td.t_f")
        body_text = body.get_text("\n", strip=True) if body else ""

        magnets = []
        for li in soup.select("div.blockcode li"):
            magnets = extract_magnets(li.get_text(" ", strip=True))
            if magnets:
                break
        if not magnets:
            magnets = extract_magnets(body_text)
        magnet = magnets[0] if magnets else ""

        if not magnet:
            page_txt = soup.get_text("\n", strip=True)
            gated_markers = ["需要登录", "请先登录", "登录后", "您必须登录"]
            if any(m in page_txt for m in gated_markers):
                raise RuntimeError("sehuatang 磁力解析失败：页面疑似被登录墙/隐藏内容拦截（cookie/storage_state 可能已失效）。")

        size_mb = _size_mb_from_text(body_text)

        urls: list[str] = []
        for i in soup.select("td[id^='postmessage_'] img[zoomfile], td[id^='postmessage_'] img[src], td.t_f img[zoomfile], td.t_f img[src]"):
            u = i.get("zoomfile") or i.get("src") or ""
            if u:
                urls.append(u)
        cover_url, gallery = choose_cover_and_gallery(urls)

        cover_path = ""
        if cover_url and bool(ctx.get("cover_download_enabled", True)):
            if cover_url.startswith("//"):
                cover_url = "https:" + cover_url
            if cover_url.startswith("/"):
                cover_url = self.base_url.rstrip("/") + cover_url

            date_part = (cand.meta.get("publish_date") or "").strip() or datetime.now().strftime("%Y-%m-%d")
            sec = (cand.meta.get("section", "") or "unknown").strip() or "unknown"
            fname = hashlib.sha1((cover_url + (cand.external_id or "") + date_part).encode("utf-8")).hexdigest() + ".jpg"
            out_dir = self.cover_dir / self.name / sec / date_part
            out_dir.mkdir(parents=True, exist_ok=True)
            out_path = out_dir / fname
            if not out_path.exists():
                try:
                    bf = await self._get_browser_fetcher(ctx)
                    data = await bf.download_bytes(cover_url)
                    await asyncio.to_thread(out_path.write_bytes, data)
                except Exception as e:
                    biz.warning("⚠️ sehuatang 封面下载失败：已跳过本地化封面，不影响条目入库。", 封面地址=cover_url, exc=e)
            cover_path = str(out_path) if out_path.exists() else ""

        return Item(
            source=self.name,
            external_id=cand.external_id,
            title=title,
            publish_date=cand.meta.get("publish_date") or None,
            detail_url=cand.detail_url,
            magnet=magnet or None,
            size_mb=size_mb,
            section=cand.meta.get("section", ""),
            category=None,
            cover_url=cover_url or None,
            cover_path=cover_path or None,
            raw={"candidate": asdict(cand), "body": body_text[:2000], "gallery": gallery, "mode": mode},
        )
