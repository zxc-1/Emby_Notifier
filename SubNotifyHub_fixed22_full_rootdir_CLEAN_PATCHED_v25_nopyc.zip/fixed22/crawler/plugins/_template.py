"""Crawler source plugin template.

To add a new source:
  1) Copy this file to `crawler/plugins/<source>.py`
  2) Implement `discover()` and `fetch_detail()`
  3) Register the plugin in `crawler/plugins/__init__.py`
  4) Add the source name to `CRAWLER_SOURCES`

Design goals:
  - Keep site-specific logic *only* in the plugin.
  - Reuse pipeline for: job queue, retries, upsert, dedup, cover download, offline queue.
"""

from __future__ import annotations

from typing import Any

from crawler.models.types import Candidate, Item


class ExamplePlugin:
    name = "example"
    prefer_queue = "http"  # or 'browser'

    def __init__(self, ctx: dict[str, Any]):
        # ctx includes config, and fetchers in worker context (http_fetcher / browser_fetcher)
        pass

    async def discover(self, ctx: dict) -> list[Candidate]:
        """Return candidates discovered from list/RSS pages."""
        return []

    async def fetch_detail(self, ctx: dict, cand: Candidate) -> Item:
        """Fetch detail page and return normalized item."""
        return Item(source=self.name, external_id=cand.external_id, title=cand.meta.get("title"), detail_url=cand.detail_url)
