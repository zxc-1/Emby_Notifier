from __future__ import annotations
from core.exceptions.base import ConfigurationError
import asyncio
from core.env_utils import env_int, env_str

import hashlib
import re
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from typing import Any, Optional

try:
    from bs4 import BeautifulSoup  # type: ignore
except ModuleNotFoundError:  # pragma: no cover
    BeautifulSoup = None  # type: ignore

def _require_bs4() -> None:
    if BeautifulSoup is None:
        raise ConfigurationError("Missing optional dependency: bs4 (beautifulsoup4)")



from core.logging import get_biz_logger

from crawler.fetchers.browser import BrowserFetcher
from crawler.models.types import Candidate, Item
from crawler.utils.media import choose_cover_and_gallery
from crawler.utils.time_parse import parse_date_only


biz = get_biz_logger(__name__)


def _parse_date(s: str) -> str:
    # backward compatible wrapper
    return parse_date_only(s, now=datetime.now())


def _magnet_in_text(text: str) -> str:
    if not text:
        return ""
    m = re.search(r"magnet:\?xt=urn:btih:[A-Za-z0-9]{32,40}[^\s\"'<]*", text)
    return m.group(0) if m else ""


def _size_mb_from_text(text: str) -> Optional[int]:
    if not text:
        return None
    # e.g. 【影片容量】4.2GB / 800MB
    m = re.search(r"容量\D*(\d+(?:\.\d+)?)\s*(GB|MB)", text, re.IGNORECASE)
    if not m:
        return None
    val = float(m.group(1))
    unit = m.group(2).upper()
    return int(val * 1024) if unit == "GB" else int(val)


class SehuaPlugin:
    """SeHua (涩花) crawler plugin (browser-first).

    Features aligned with your old Telegram-115bot implementation, plus upgrades:
    - strict date filter (list page per-thread publish date)
    - stable CF/age-gate via persistent Playwright storage_state
    - cover download to local path + write cover_path
    """

    name = "sehua"
    prefer_queue = "browser"

    def __init__(self, ctx: dict[str, Any]):
        self.base_url = (ctx.get("sehua_base_url") or env_str("CRAWLER_SEHUA_BASE_URL", "") or "").strip()
        # 默认给一个可用域名（可用 env 覆盖）。如果用户没跑该源或域名不可用，discover 会在缺配置时自动跳过。
        if not self.base_url:
            self.base_url = "https://sehuatang.org"
        self.section_map = ctx.get("sehua_section_map") or {}
        if not self.section_map:
            # env: "国产原创:36,中文字幕:2"
            raw = env_str("CRAWLER_SEHUA_SECTION_MAP", "").strip()
            mp: dict[str, int] = {}
            for part in [p.strip() for p in raw.split(",") if p.strip()]:
                if ":" in part:
                    k, v = part.split(":", 1)
                    try:
                        mp[k.strip()] = int(v.strip())
                    except Exception as e:
                        biz.detail("ignored exception in __init__", exc_info=True)
                        continue
            if not mp:
                # 兼容 Telegram-115bot / article_source 的默认版块映射
                mp = {
                    "国产原创": 2,
                    "亚洲无码原创": 36,
                    "亚洲有码原创": 37,
                    "高清中文字幕": 103,
                    "素人有码系列": 104,
                    "4K原版": 151,
                    "VR视频区": 160,
                    "欧美无码": 38,
                }
            self.section_map = mp

        # Prefer UI overrides (hot-reload), then env.
        self.page_limit = int(ctx.get("sehua_page_limit") or env_str("CRAWLER_SEHUA_PAGE_LIMIT", "9"))
        self.mode_default = str(ctx.get("sehua_mode") or env_str("CRAWLER_SEHUA_MODE", "stop_tid")).strip() or "stop_tid"
        self.cover_dir = Path(env_str("CRAWLER_COVER_DIR", "data/crawler/covers"))
        self.cover_dir.mkdir(parents=True, exist_ok=True)

    def _section_fid(self, section: str) -> Optional[int]:
        section = (section or "").strip()
        if not section:
            return None
        v = self.section_map.get(section)
        return int(v) if v is not None else None

    def _forum_url(self, fid: int, page: int) -> str:
        # Most sehuatang mirrors use this pattern
        return f"{self.base_url}/forum.php?mod=forumdisplay&fid={fid}&page={page}"

    async def discover(self, ctx: dict) -> list[Candidate]:
        if not self.base_url or not self.section_map:
            biz.warning(
                "⚠️ sehua 源配置不完整：缺少 base_url 或版块映射，已跳过抓取。",
                建议="请在环境变量中配置 CRAWLER_SEHUA_BASE_URL 与 CRAWLER_SEHUA_SECTION_MAP，或在爬虫 UI 的配置页补齐。",
            )
            return []

        params = (ctx.get("params") or {}) if isinstance(ctx.get("params"), dict) else {}
        section = params.get("section") or ctx.get("section") or ""
        target_date = (params.get("date") or ctx.get("date") or "").strip()
        mode = str(params.get("mode") or self.mode_default).strip() or self.mode_default
        stop_tid = int(params.get("stop_tid") or 0) if str(params.get("stop_tid") or "").isdigit() else 0

        fid = self._section_fid(section)
        if not fid:
            biz.warning(
                "⚠️ sehua 版块未映射到 fid：已跳过该版块抓取。",
                版块=section,
                建议="请在 CRAWLER_SEHUA_SECTION_MAP 中补充该版块的 fid 映射。",
            )
            return []

        fetcher: BrowserFetcher = ctx["browser_fetcher"]
        cands: list[Candidate] = []

        consecutive_no_new = 0
        saw_any_hit = False

        for page in range(1, self.page_limit + 1):
            url = self._forum_url(fid, page)
            html = await fetcher.get(url)
            _require_bs4()
            soup = BeautifulSoup(html, "lxml")
            rows = soup.select("tbody[id^='normalthread_']")
            page_hits = 0
            page_new = 0

            for row in rows:
                a = row.select_one("a.s.xst")
                if not a:
                    continue
                href = a.get("href") or ""
                title = (a.get_text() or "").strip()

                # publish date (Telegram-115bot logic)
                date_title = ""
                span = row.select_one("td.by em span[title]")
                if span and span.get("title"):
                    date_title = span.get("title") or ""
                else:
                    # fallback: some templates put time in td.by em
                    em = row.select_one("td.by em")
                    if em:
                        date_title = em.get_text(" ", strip=True)

                d = _parse_date(date_title)

                # by_date mode: only pick exact date
                if mode == "by_date" and target_date:
                    if d != target_date:
                        continue

                tid = ""
                m = re.search(r"tid=(\d+)", href)
                if m:
                    tid = m.group(1)
                else:
                    m2 = re.search(r"thread-(\d+)-", href)
                    if m2:
                        tid = m2.group(1)

                detail_url = href
                if detail_url and detail_url.startswith("./"):
                    detail_url = self.base_url + detail_url[1:]
                if detail_url.startswith("forum.php") or detail_url.startswith("thread-"):
                    detail_url = f"{self.base_url}/{detail_url.lstrip('/')}" if not detail_url.startswith("http") else detail_url

                # stop_tid mode: only emit newer than cursor
                if mode == "stop_tid" and stop_tid:
                    if (tid or "").isdigit() and int(tid) <= stop_tid:
                        continue

                page_hits += 1
                page_new += 1
                saw_any_hit = True

                cands.append(
                    Candidate(
                        external_id=str(tid or ""),
                        detail_url=detail_url,
                        meta={
                            "section": section,
                            "publish_date": (target_date or d or ""),
                            "title": title,
                            "fid": fid,
                            "page": page,
                        },
                    )
                )

            # Paging stop conditions:
            # - stop_tid: two consecutive pages without new threads
            # - by_date: only stop after we've already seen hits, and then two consecutive empty pages
            if mode == "stop_tid":
                if page_new == 0:
                    consecutive_no_new += 1
                    if consecutive_no_new >= 2:
                        break
                else:
                    consecutive_no_new = 0
            elif mode == "by_date" and target_date:
                if page_hits == 0 and saw_any_hit:
                    consecutive_no_new += 1
                    if consecutive_no_new >= 2:
                        break
                elif page_hits > 0:
                    consecutive_no_new = 0

        return cands

    async def fetch_detail(self, ctx: dict, cand: Candidate) -> Item:
        fetcher: BrowserFetcher = ctx["browser_fetcher"]
        html = await fetcher.get(cand.detail_url)
        soup = BeautifulSoup(html, "lxml")

        title = (soup.select_one("span#thread_subject") or {}).get_text(strip=True) if soup.select_one("span#thread_subject") else (cand.meta.get("title") or "")
        body = soup.select_one("td[id^='postmessage_']") or soup.select_one("td.t_f")
        body_text = body.get_text("\n", strip=True) if body else ""

        magnet = ""
        for li in soup.select("div.blockcode li"):
            m = _magnet_in_text(li.get_text(" ", strip=True))
            if m:
                magnet = m
                break
        if not magnet:
            magnet = _magnet_in_text(body_text)

        # Login/session health hint: if magnet is missing and page looks gated, fail fast with a useful error.
        if not magnet:
            page_txt = soup.get_text("\n", strip=True)
            gated_markers = ["需要登录", "请先登录", "登录后", "您必须登录"]
            if any(m in page_txt for m in gated_markers):
                raise RuntimeError(
                    "sehua 磁力解析失败：页面疑似被登录墙/隐藏内容拦截（storage_state 可能已失效）。"
                )

        size_mb = _size_mb_from_text(body_text)

        # images (cover + gallery)
        urls: list[str] = []
        for i in soup.select("td[id^='postmessage_'] img[zoomfile], td[id^='postmessage_'] img[src], td.t_f img[zoomfile], td.t_f img[src]"):
            u = i.get("zoomfile") or i.get("src") or ""
            if u:
                urls.append(u)
        cover_url, gallery = choose_cover_and_gallery(urls)

        cover_path = ""
        if cover_url:
            if cover_url.startswith("//"):
                cover_url = "https:" + cover_url
            if cover_url.startswith("/"):
                cover_url = self.base_url.rstrip("/") + cover_url

            # store by source/section/date
            date_part = (cand.meta.get("publish_date") or None or "").strip() or datetime.now().strftime("%Y-%m-%d")
            sec = (cand.meta.get("section", "") or "unknown").strip() or "unknown"
            fname = hashlib.sha1((cover_url + (cand.external_id or "") + date_part).encode("utf-8")).hexdigest() + ".jpg"
            out_dir = self.cover_dir / self.name / sec / date_part
            out_dir.mkdir(parents=True, exist_ok=True)
            out_path = out_dir / fname
            if not out_path.exists():
                try:
                    data = await fetcher.download_bytes(cover_url)
                    await asyncio.to_thread(out_path.write_bytes, data)
                except Exception as e:
                    biz.warning(
                        "⚠️ sehua 封面下载失败：已跳过本地化封面，不影响条目入库。",
                        封面地址=cover_url,
                        建议="检查封面地址是否可访问；如不需要封面落地，可设置 CRAWLER_COVER_DOWNLOAD=0。",
                        exc=e,
                    )
            cover_path = str(out_path) if out_path.exists() else ""

        return Item(
            source=self.name,
            external_id=cand.external_id,
            title=title,
            publish_date=cand.meta.get("publish_date") or None,
            detail_url=cand.detail_url,
            magnet=magnet or None,
            size_mb=size_mb,
            section=cand.meta.get("section", ""),
            category=None,
            cover_url=cover_url or None,
            cover_path=cover_path or None,
            raw={"candidate": asdict(cand), "body": body_text[:2000], "gallery": gallery},
        )
