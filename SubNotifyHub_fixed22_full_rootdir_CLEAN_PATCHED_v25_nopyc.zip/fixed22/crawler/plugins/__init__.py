from __future__ import annotations

from typing import Dict

from crawler.plugins.base import SourcePlugin
from crawler.plugins.javbee import JavbeePlugin
from crawler.plugins.javbus import JavbusPlugin
from crawler.plugins.t66y import T66yPlugin

# Anti-bot heavy source (unified)
from crawler.plugins.sehuatang import SehuatangPlugin


def build_plugins(ctx: dict) -> Dict[str, SourcePlugin]:
    """Instantiate enabled plugins.

    All plugins are lightweight; they should not start background tasks here.
    """

    plugins: Dict[str, SourcePlugin] = {
        "javbee": JavbeePlugin(ctx),
        "javbus": JavbusPlugin(ctx),
        "t66y": T66yPlugin(ctx),
        "sehuatang": SehuatangPlugin(ctx),
    }
    return plugins


_CACHED: dict[tuple, Dict[str, SourcePlugin]] = {}


def _cache_key(ctx: dict) -> tuple:
    """Build a cache key that changes when runtime config (UI overrides) changes.

    The crawler worker hot-reloads several fields into ctx on each poll loop.
    Without including them in the cache key, plugin instances would keep using
    stale config until the process restarts.
    """

    svc = ctx.get("_crawler_service")
    # Use id(svc) to avoid cross-service reuse.
    return (
        id(svc) if svc is not None else 0,
        str(ctx.get("rsshub_host") or ""),
        str(ctx.get("javbee_route") or ""),
        str(ctx.get("javbee_base_url") or ""),
        str(ctx.get("javbus_base_url") or ""),
        str(ctx.get("t66y_base_url") or ""),
        str(ctx.get("sehuatang_domain") or ""),
        str(ctx.get("flaresolverr_url") or ""),
        str(ctx.get("sehuatang_base_url") or ""),

        # network/runtime hot reload
        str(ctx.get("network_user_agent") or ""),
        str(ctx.get("network_proxy_url") or ""),
        str(ctx.get("network_timeout_s") or ""),

        # sehuatang runtime
        str(ctx.get("sehuatang_discover_mode") or ""),
        str(ctx.get("sehuatang_page_limit") or ""),
    )


def get_plugins(ctx: dict) -> Dict[str, SourcePlugin]:
    """Return plugin instances cached per-process.

    Plugins are stateless (or only hold lightweight cookies), so we reuse
    instances to reduce overhead.
    """
    key = _cache_key(ctx)
    if key not in _CACHED:
        _CACHED[key] = build_plugins(ctx)
    return _CACHED[key]
