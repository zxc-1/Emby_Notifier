from __future__ import annotations

from typing import Protocol

from crawler.models.types import Candidate, Item


class SourcePlugin(Protocol):
    """A crawler source plugin.

    Plugins implement only crawling rules.
    Orchestration (jobs, retries, de-dup, persistence, offline enqueue) is
    handled by the core crawler pipeline.
    """

    name: str
    prefer_queue: str  # "http" or "browser"

    async def discover(self, ctx: dict) -> list[Candidate]:
        ...

    async def fetch_detail(self, ctx: dict, cand: Candidate) -> Item:
        ...
