from __future__ import annotations

from typing import Any
from urllib.parse import urlparse

from core.exceptions.base import ConfigurationError

try:
    from bs4 import BeautifulSoup  # type: ignore
except ModuleNotFoundError:  # pragma: no cover
    BeautifulSoup = None  # type: ignore


def _require_bs4() -> None:
    if BeautifulSoup is None:
        raise ConfigurationError("Missing optional dependency: bs4 (beautifulsoup4)")


from core.logging import get_biz_logger

from crawler.fetchers.flaresolverr import FlareSolverrFetcher
from crawler.fetchers.http import HttpFetcher
from crawler.models.types import Candidate, Item
from crawler.utils.anti_bot import build_browser_headers, extract_magnets, looks_like_challenge
from crawler.utils.host_rate_limiter import HostRateLimiter, HostRatePolicy


biz = get_biz_logger(__name__)


class JavbusPlugin:
    """JavBus crawler plugin (direct scraping aligned with SHT anti-bot style).

    v36 improvements vs v35 direct mode:
    - Host pacing + periodic rest
    - Browser-like headers + referer
    - Challenge detection + FlareSolverr fallback
    - More robust magnet extraction (HTML entity unescape + base32/hex)

    RSSHub mode remains supported when rsshub_host is configured.
    """

    name = "javbus"
    prefer_queue = "http"

    def __init__(self, ctx: dict[str, Any]):
        ua = str(ctx.get("network_user_agent") or "").strip() or None
        proxy = str(ctx.get("network_proxy_url") or "").strip() or None
        timeout_s = float(ctx.get("network_timeout_s") or 25)

        self.ua = (
            ua
            or (
                "Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) "
                "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 "
                "Mobile/15E148 Safari/604.1"
            )
        )
        self.timeout_s = timeout_s

        self.fetcher = HttpFetcher(user_agent=self.ua, proxy_url=proxy, timeout_s=timeout_s)
        self.fs = FlareSolverrFetcher(str(ctx.get("flaresolverr_url") or "").rstrip("/"))

        self.rsshub_host = str(ctx.get("rsshub_host") or "").rstrip("/")
        self.route = str(ctx.get("javbus_route") or "").strip() or "/javbus"

        self.base_url = str(ctx.get("javbus_base_url") or "https://www.javbus.com").rstrip("/")
        self.list_path = str(ctx.get("javbus_list_path") or "/").strip() or "/"

        pol = HostRatePolicy(
            min_delay_s=float(ctx.get("crawler_min_delay_s") or 1.6),
            max_delay_s=float(ctx.get("crawler_max_delay_s") or 3.8),
            burst_every=int(ctx.get("crawler_burst_every") or 8),
            burst_rest_range_s=(
                float(ctx.get("crawler_burst_rest_min_s") or 5.0),
                float(ctx.get("crawler_burst_rest_max_s") or 10.0),
            ),
        )
        self.limiter = HostRateLimiter(pol)

    # ---------------- RSSHub mode ----------------
    async def _discover_via_rsshub(self, day: str) -> list[Candidate]:
        url = f"{self.rsshub_host}{self.route.rstrip('/')}/{day}?format=json"
        rss = await self.fetcher.get_json(url)
        cands: list[Candidate] = []
        for it in (rss or {}).get("items", []) or []:
            ch = it.get("content_html") or ""
            mags = extract_magnets(ch)
            magnet = mags[0] if mags else ""
            if not magnet:
                continue
            cands.append(
                Candidate(
                    external_id=str(it.get("id") or it.get("url") or it.get("title") or ""),
                    detail_url=str(it.get("url") or ""),
                    meta={
                        "title": str(it.get("title") or ""),
                        "publish_date": str(it.get("date_published") or "")[:10],
                        "magnet": magnet,
                        "cover_url": "",
                        "raw": it,
                    },
                )
            )
        return cands

    # ---------------- Direct mode ----------------
    async def _get_html(self, url: str, *, referer: str | None = None) -> str:
        await self.limiter.wait_url(url)
        headers = build_browser_headers(user_agent=self.ua, referer=referer)
        try:
            html = await self.fetcher.get_text(url, headers=headers, timeout=float(self.timeout_s))
        except Exception:
            html = ""

        if looks_like_challenge(html):
            try:
                html = await self.fs.get_text(url, headers=headers, timeout_ms=int(max(30.0, self.timeout_s) * 1000))
            except Exception:
                return html or ""

        return html or ""

    def _normalize_link(self, href: str) -> str:
        href = (href or "").strip()
        if not href:
            return ""
        if href.startswith("//"):
            href = "https:" + href
        if href.startswith("/"):
            href = self.base_url + href
        return href

    async def _discover_direct(self, day: str) -> list[Candidate]:
        try:
            _require_bs4()
        except Exception:
            return []

        list_url = f"{self.base_url}{self.list_path}"
        html = await self._get_html(list_url)
        if not html:
            return []

        soup = BeautifulSoup(html, "html.parser")
        base_host = (urlparse(self.base_url).hostname or "").lower()

        detail_links: list[str] = []
        # JavBus common detail links include "?v=" or "/ABC-123" forms; keep heuristics broad.
        for a in soup.find_all("a"):
            href = self._normalize_link(a.get("href") or "")
            if not href.startswith("http"):
                continue
            host = (urlparse(href).hostname or "").lower()
            if host != base_host:
                continue
            low = href.lower()
            if any(x in low for x in ["/genre/", "/actress/", "/magnet", "javascript:", "#", "/search/"]):
                continue
            # try to focus on video detail pages
            if ("?v=" not in low) and (len(urlparse(href).path.strip("/")) < 3):
                continue
            if href in detail_links:
                continue
            detail_links.append(href)
            if len(detail_links) >= 18:
                break

        cands: list[Candidate] = []
        for u in detail_links:
            detail_html = await self._get_html(u, referer=list_url)
            if not detail_html:
                continue

            mags = extract_magnets(detail_html)
            if not mags:
                # Some pages may render magnets via JS; best-effort: search in data-* attributes too.
                # (Still within same HTML text, so extract_magnets already covers if present.)
                continue
            magnet = mags[0]

            title = ""
            try:
                dsoup = BeautifulSoup(detail_html, "html.parser")
                h3 = dsoup.select_one("h3")
                if h3 and h3.get_text(strip=True):
                    title = h3.get_text(" ", strip=True)
                elif dsoup.title and dsoup.title.text:
                    title = dsoup.title.text.strip()
            except Exception:
                title = ""

            cands.append(
                Candidate(
                    external_id=u,
                    detail_url=u,
                    meta={
                        "title": title,
                        "publish_date": day,
                        "magnet": magnet,
                        "cover_url": "",
                        "raw": {"url": u},
                    },
                )
            )
            if len(cands) >= 12:
                break

        return cands

    async def discover(self, ctx: dict) -> list[Candidate]:
        job = ctx.get("job")
        params = getattr(job, "params", {}) if job else {}
        day = str(params.get("date") or "").strip()
        if not day:
            return []

        if self.rsshub_host:
            try:
                return await self._discover_via_rsshub(day)
            except Exception as e:
                biz.warn("⚠️ javbus RSSHub 模式失败，尝试直连抓取", exc=e)
                return await self._discover_direct(day)

        return await self._discover_direct(day)

    async def fetch_detail(self, ctx: dict, cand: Candidate) -> Item:
        m = cand.meta or {}
        return Item(
            source=self.name,
            external_id=str(cand.external_id or ""),
            title=str(m.get("title") or ""),
            publish_date=str(m.get("publish_date") or "") or None,
            detail_url=str(cand.detail_url or ""),
            magnet=str(m.get("magnet") or ""),
            cover_url=str(m.get("cover_url") or ""),
            extra=m,
        )
