from __future__ import annotations

import asyncio
from datetime import datetime, timedelta
from typing import Any

from core.logging import get_biz_logger

from services.dedup.core.quality_scorer import QualityScorer
from services.dedup.models import MediaFile
from services.dedup.models.scoring import ScoringConfig, AdultScoringWeights
from crawler import config as crawler_config
import re


from crawler.db.pg import PgPool
from crawler.scheduler.cron import next_run_after
from crawler.subscriptions.store import (
    enqueue_delivery_for_item,
    find_items_for_rule,
    list_enabled_rule_subscriptions,
    update_last_seen,
)


biz = get_biz_logger(__name__)


def _rule_get(rule: dict[str, Any], key: str) -> Any:
    # allow both snake/camel keys
    if key in rule:
        return rule.get(key)
    camel = "".join([key.split("_")[0]] + [p.title() for p in key.split("_")[1:]])
    return rule.get(camel)



_ID_STD = re.compile(r"\b([a-z]{2,6})[-_ ]?(\d{2,5})\b", re.I)
_ID_FC2 = re.compile(r"\bfc2[-_ ]?ppv[-_ ]?(\d{5,8})\b", re.I)

def _extract_group_key(title: str) -> str:
    t = (title or "").strip()
    if not t:
        return "t:empty"
    m = _ID_FC2.search(t)
    if m:
        return f"fc2ppv{m.group(1)}"
    m = _ID_STD.search(t)
    if m:
        return f"{m.group(1).lower()}{m.group(2)}"
    norm = re.sub(r"\[[^\]]*\]|\([^\)]*\)|\{[^\}]*\}", " ", t.lower())
    norm = re.sub(r"(2160p|4k|1080p|720p|480p|x265|x264|hevc|h\.265|h\.264|中字|中文字幕|双语|bilingual|无码|有码|uncensored|censored)", " ", norm)
    norm = re.sub(r"[^a-z0-9]+", " ", norm)
    norm = re.sub(r"\s+", " ", norm).strip()
    return "t:" + (norm[:64] if norm else "unknown")

def _build_scorer_from_overrides() -> QualityScorer:
    ov = crawler_config._read_overrides()
    muls = (ov.get("ranking_policy_overrides") or {})
    def _as_float(x, d):
        try:
            return float(x)
        except Exception as e:
            biz.detail("ignored exception in _as_float", exc_info=True)
            return float(d)
    mul_sub = _as_float(muls.get("mul_subtitle", 1.2), 1.2)
    mul_unc = _as_float(muls.get("mul_uncensored", 1.2), 1.2)
    mul_res = _as_float(muls.get("mul_resolution", 1.0), 1.0)

    base = AdultScoringWeights()
    w = AdultScoringWeights(
        subtitle = int(round(base.subtitle * mul_sub)),
        mosaic = int(round(base.mosaic * mul_unc)),
        resolution = int(round(base.resolution * mul_res)),
        source = base.source,
        studio = base.studio,
        special_tags = base.special_tags,
    )
    cfg = ScoringConfig(adult_weights=w)
    return QualityScorer(cfg)

def _score_item(scorer: QualityScorer, item: dict[str, Any]) -> float:
    title = str(item.get("title") or "")
    mf = MediaFile(
        file_id=str(item.get("id") or ""),
        path=title or "unknown",
        name=title or "unknown",
        size=0,
        is_adult=True,
        data_source="115",
    )
    score, _details = scorer.score(mf)
    return float(score or 0.0)

async def subscription_loop(
    pool: PgPool,
    *,
    cron_expr: str,
    stop_event: asyncio.Event,
) -> None:
    """Scan enabled rule subscriptions and enqueue delivery tasks.

    This loop is intentionally independent from crawler discover/detail.
    """

    async def _tick() -> None:
        subs = []
        try:
            deliver_notify_enabled_global = bool(getattr(crawler_config.load_crawler_config(), 'deliver_notify_enabled', getattr(crawler_config.load_crawler_config(), 'deliver_cd2_notify_enabled', True)))
            subs = await list_enabled_rule_subscriptions(pool)
        except Exception as e:
            biz.warning(
                "⚠️ 订阅扫描失败：读取订阅规则列表出错，本轮已跳过。",
                建议="检查 PostgreSQL 是否可用、crawler schema 是否初始化成功。",
                exc=e,
            )
            return

        if not subs:
            return

        total_new = 0
        with biz.entry(domain="爬虫", action="订阅扫描", cron表达式=cron_expr, 规则数=len(subs)):
            biz.step("开始按订阅规则匹配已入库条目，并生成投递任务。")
            for s in subs:
                try:
                    rule = dict(s.get("rule") or {})

                    # multi-source/section rule schema
                    sources = _rule_get(rule, "sources") or []
                    if isinstance(sources, str):
                        sources = [sources]
                    sources = [str(x).strip() for x in (sources or []) if str(x).strip()]
                    if not sources:
                        legacy_source = str(_rule_get(rule, "source") or "").strip()
                        if legacy_source:
                            sources = [legacy_source]

                    if not sources:
                        continue

                    sections_by_source = _rule_get(rule, "sections_by_source") or {}
                    if not isinstance(sections_by_source, dict):
                        sections_by_source = {}

                    # legacy fallback: single section
                    legacy_section = str(_rule_get(rule, "section") or "").strip() or None
                    if legacy_section and not sections_by_source:
                        sections_by_source = {sources[0]: [legacy_section]}

                    keywords = _rule_get(rule, "keywords") or []
                    if isinstance(keywords, str):
                        keywords = [keywords]

                    last_seen = s.get("last_seen_updated_at")
                    if not last_seen:
                        last_seen = datetime.now() - timedelta(days=2)

                    # aggregate candidate items across all selected sources/sections
                    items = []
                    for src in sources:
                        secs = sections_by_source.get(src)
                        if isinstance(secs, str):
                            secs = [secs]
                        secs = [str(x).strip() for x in (secs or []) if str(x).strip()]
                        if not secs:
                            secs = [None]
                        for sec in secs:
                            found = await find_items_for_rule(
                                pool,
                                source=str(src),
                                section=str(sec).strip() if sec else None,
                                keywords=list(keywords),
                                updated_after=last_seen,
                                limit=300,
                            )
                            if found:
                                items.extend(found)

                    if not items:
                        continue

                    deliver_to = str(s.get("deliver_to") or "115")
                    # No implicit default save path.
                    save_path = str(s.get("save_path") or "")
                    # Multi-deliver support
                    raw_targets = s.get("deliver_targets")
                    if isinstance(raw_targets, str):
                        # PG may return jsonb as str in some clients
                        try:
                            import json as _json
                            raw_targets = _json.loads(raw_targets)
                        except Exception:
                            raw_targets = None
                    targets = [deliver_to]
                    if isinstance(raw_targets, list) and raw_targets:
                        targets = [str(x).strip() for x in raw_targets if str(x).strip()]
                    targets = [t for t in ["115", "cd2"] if t in set(targets)] or ["115"]

                    raw_paths = s.get("save_paths")
                    if isinstance(raw_paths, str):
                        try:
                            import json as _json
                            raw_paths = _json.loads(raw_paths)
                        except Exception:
                            raw_paths = None
                    save_paths = raw_paths if isinstance(raw_paths, dict) else {}
                    sub_id = str(s.get("id"))

                    # Ranking (default enabled): per-group Top1 enqueue + internal fallback Top3 (stored in task.meta)
                    scorer = _build_scorer_from_overrides()
                    groups: dict[str, list[dict[str, Any]]] = {}
                    for it in items:
                        gk = _extract_group_key(str(it.get("title") or ""))
                        groups.setdefault(gk, []).append(it)

                    max_seen = last_seen
                    for gk, gitems in groups.items():
                        scored = []
                        for it in gitems:
                            try:
                                scored.append((it, _score_item(scorer, it)))
                            except Exception:
                                scored.append((it, 0.0))
                        scored.sort(key=lambda x: x[1], reverse=True)
                        top = scored[:3]
                        if not top:
                            continue
                        best_it, _best_score = top[0]
                        best_id = str(best_it.get("id"))
                        best_mag = str(best_it.get("magnet") or "")
                        candidates = []
                        for it, sc in top:
                            candidates.append({
                                "item_id": str(it.get("id")),
                                "magnet": str(it.get("magnet") or ""),
                                "score": float(sc),
                                "title": str(it.get("title") or ""),
                            })
                        meta = {
                            "group_key": gk,
                            "candidates": candidates,
                            "candidate_index": 0,
                            "candidate_attempt": 0,
                            "candidate_max_attempt": 2,
                        }
                        for tgt in targets:
                            # No implicit default save path; if empty, downstream delivery will fail loudly.
                            sp = str(save_paths.get(tgt) or (save_path if tgt == deliver_to else "") or save_path or "")
                            await enqueue_delivery_for_item(
                                pool,
                                item_id=best_id,
                                subscription_id=sub_id,
                                deliver_to=tgt,
                                magnet=best_mag,
                                save_path=sp,
                                meta=meta,
                                notify_enabled=(deliver_notify_enabled_global and bool(sub.get("notify_enabled", True))) if str(tgt).lower() in ("cd2", "115") else None,
                            )
                            total_new += 1
                        for it, _sc in top:
                            ts = it.get("updated_at")
                            if ts and ts > max_seen:
                                max_seen = ts

                    if max_seen and max_seen != last_seen:
                        await update_last_seen(pool, sub_id, last_seen=max_seen)

                except Exception as e:
                    biz.warning(
                        "⚠️ 处理单条订阅规则失败：该规则已跳过，其余规则继续处理。",
                        订阅ID=str(s.get("id") or ""),
                        建议="检查该订阅的 source/keywords/section 是否合法；必要时在 UI 中禁用后重新创建。",
                        exc=e,
                    )

            biz.ok(
                "✅ 订阅扫描完成：已根据订阅规则生成投递任务。",
                规则数=len(subs),
                新增投递任务数=total_new,
                cron表达式=cron_expr,
            )

    # run once quickly at start so "点了订阅"后无需等太久
    await _tick()

    while not stop_event.is_set():
        now = datetime.now()
        try:
            nxt = next_run_after(cron_expr, after=now)
        except Exception:
            nxt = now + timedelta(minutes=2)
        delay = max(1.0, (nxt - now).total_seconds())
        try:
            await asyncio.wait_for(stop_event.wait(), timeout=delay)
        except asyncio.TimeoutError:
            await _tick()
            continue
