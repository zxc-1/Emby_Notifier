from __future__ import annotations

from datetime import datetime
import uuid
import json
from typing import Any, Iterable

from crawler.db.pg import PgPool


async def create_subscription(
    pool: PgPool,
    *,
    user_key: str | None,
    name: str = "",
    sub_type: str,
    deliver_to: str,
    save_path: str,
    deliver_targets: list[str] | None = None,
    save_paths: dict[str, str] | None = None,
    notify_enabled: bool = True,
    rule: dict[str, Any] | None = None,
) -> str:
    """Create a subscription.

    - sub_type: 'item' or 'rule'
    - deliver_to: '115' or 'cd2'
    """
    sql = """
    INSERT INTO crawler.crawler_subscriptions (id, user_key, name, sub_type, deliver_to, save_path, deliver_targets, save_paths, notify_enabled, rule)
    VALUES ($1,$2,$3,$4,$5,$6,$7::jsonb,$8::jsonb,$9,$10::jsonb)
    RETURNING id
    """
    targets = deliver_targets or [deliver_to]
    targets = [str(x).strip() for x in targets if str(x).strip()]
    if not targets:
        targets = [deliver_to]
    paths = save_paths or {}
    sub_uuid = uuid.uuid4()
    row = await pool.fetchone(
        sql,
        sub_uuid,
        user_key,
        (name or "").strip(),
        sub_type,
        deliver_to,
        save_path,
        json.dumps(targets, ensure_ascii=False),
        json.dumps(paths, ensure_ascii=False),
        bool(notify_enabled),
        json.dumps(rule or {}, ensure_ascii=False),
    )
    sub_id = str(row["id"])
    # initialize state so rule subscriptions only deliver new items by default
    await pool.execute(
        """
        INSERT INTO crawler.crawler_subscription_state (subscription_id, last_seen_updated_at)
        VALUES ($1, now())
        ON CONFLICT (subscription_id) DO NOTHING
        """,
        sub_id,
    )
    return sub_id


async def enable_subscription(pool: PgPool, sub_id: str, *, enabled: bool) -> None:
    await pool.execute(
        "UPDATE crawler.crawler_subscriptions SET is_enabled=$2, updated_at=now() WHERE id=$1",
        sub_id,
        enabled,
    )


async def enqueue_delivery_for_item(
    pool: PgPool,
    *,
    item_id: str,
    subscription_id: str | None,
    deliver_to: str,
    magnet: str,
    save_path: str,
    meta: dict[str, Any] | None = None,
    notify_enabled: bool | None = None,
) -> None:
    magnet = (magnet or "").strip()
    if not magnet:
        return
    sql = """
    INSERT INTO crawler.crawler_delivery_tasks (
        id, subscription_id, item_id, deliver_to, magnet, save_path, status, meta,
        notify_success, notify_failed
    )
    VALUES ($1,$2,$3,$4,$5,$6,'pending',$7::jsonb,$8,$9)
    ON CONFLICT DO NOTHING
    """
    try:
        task_uuid = uuid.uuid4()
        # Defaults: only notify terminal failures (success optional)
        await pool.execute(
            sql,
            task_uuid,
            subscription_id,
            item_id,
            deliver_to,
            magnet,
            save_path,
            json.dumps(meta or {}, ensure_ascii=False),
            bool(notify_enabled) if notify_enabled is not None else False,
            bool(notify_enabled) if notify_enabled is not None else True,
        )
    except Exception as e:
        # Do NOT swallow errors: enqueue must be reliable for admin UX.
        # Caller (admin usecase) will convert this to a user-visible error.
        raise


async def list_enabled_rule_subscriptions(pool: PgPool) -> list[dict[str, Any]]:
    sql = """
    SELECT s.id, s.user_key, s.name, s.deliver_to, s.save_path, s.deliver_targets, s.save_paths, s.notify_enabled, s.rule,
           st.last_seen_updated_at
    FROM crawler.crawler_subscriptions s
    LEFT JOIN crawler.crawler_subscription_state st ON st.subscription_id=s.id
    WHERE s.is_enabled=true AND s.sub_type='rule'
    ORDER BY s.created_at ASC
    """
    rows = await pool.fetchall(sql)
    return [dict(r) for r in rows]


async def update_last_seen(pool: PgPool, sub_id: str, *, last_seen: datetime) -> None:
    await pool.execute(
        """
        INSERT INTO crawler.crawler_subscription_state (subscription_id, last_seen_updated_at, updated_at)
        VALUES ($1,$2,now())
        ON CONFLICT (subscription_id)
        DO UPDATE SET last_seen_updated_at=EXCLUDED.last_seen_updated_at, updated_at=now()
        """,
        sub_id,
        last_seen,
    )


async def find_items_for_rule(
    pool: PgPool,
    *,
    source: str,
    section: str | None,
    keywords: Iterable[str] | None,
    updated_after: datetime | None,
    limit: int = 200,
) -> list[dict[str, Any]]:
    """Find items matching a rule.

    Matching semantics:
    - source must match
    - section if provided must match
    - keywords: ANY keyword matches title (ILIKE)
    - only items with updated_at > updated_after (if provided)
    """

    where = ["source=$1"]
    args: list[Any] = [source]
    idx = 2

    if section:
        where.append(f"section=${idx}")
        args.append(section)
        idx += 1

    if updated_after is not None:
        where.append(f"updated_at > ${idx}")
        args.append(updated_after)
        idx += 1

    kw = [k.strip() for k in (keywords or []) if str(k or "").strip()]
    if kw:
        # (title ILIKE %kw1% OR title ILIKE %kw2% ...)
        or_parts = []
        for k in kw:
            or_parts.append(f"title ILIKE ${idx}")
            args.append(f"%{k}%")
            idx += 1
        where.append("(" + " OR ".join(or_parts) + ")")

    sql = """
    SELECT id, magnet, title, updated_at
    FROM crawler.crawler_items
    WHERE {where}
      AND magnet IS NOT NULL AND magnet <> ''
    ORDER BY updated_at ASC
    LIMIT {limit}
    """.format(where=" AND ".join(where), limit=int(limit))
    rows = await pool.fetchall(sql, *args)
    return [dict(r) for r in rows]


async def list_subscriptions(pool: PgPool) -> list[dict[str, Any]]:
    sql = """
    SELECT s.id, s.user_key, s.name, s.sub_type, s.deliver_to, s.save_path, s.deliver_targets, s.save_paths, s.notify_enabled, s.rule,
           s.is_enabled, s.created_at, s.updated_at,
           st.last_seen_updated_at
    FROM crawler.crawler_subscriptions s
    LEFT JOIN crawler.crawler_subscription_state st ON st.subscription_id=s.id
    ORDER BY s.created_at DESC
    """
    rows = await pool.fetchall(sql)
    return [dict(r) for r in rows]


async def delete_subscription(pool: PgPool, sub_id: str) -> None:
    # cascade will clean state/tasks if configured; still do best-effort clean.
    await pool.execute("DELETE FROM crawler.crawler_subscription_state WHERE subscription_id=$1", sub_id)
    await pool.execute("DELETE FROM crawler.crawler_subscriptions WHERE id=$1", sub_id)


async def update_subscription(
    pool: PgPool,
    *,
    sub_id: str,
    name: str | None = None,
    deliver_to: str | None = None,
    save_path: str | None = None,
    deliver_targets: list[str] | None = None,
    save_paths: dict[str, str] | None = None,
    notify_enabled: bool | None = None,
    rule: dict[str, Any] | None = None,
    enabled: bool | None = None,
) -> None:
    sets = ["updated_at=now()"]
    args: list[Any] = [sub_id]
    idx = 2

    if name is not None:
        sets.append(f"name=${idx}")
        args.append((name or "").strip())
        idx += 1
    if deliver_to is not None:
        sets.append(f"deliver_to=${idx}")
        args.append(deliver_to)
        idx += 1
    if save_path is not None:
        sets.append(f"save_path=${idx}")
        args.append(save_path)
        idx += 1
    if deliver_targets is not None:
        sets.append(f"deliver_targets=${idx}::jsonb")
        args.append(json.dumps(deliver_targets, ensure_ascii=False))
        idx += 1
    if save_paths is not None:
        sets.append(f"save_paths=${idx}::jsonb")
        args.append(json.dumps(save_paths, ensure_ascii=False))
        idx += 1
    if rule is not None:
        sets.append(f"rule=${idx}::jsonb")
        args.append(json.dumps(rule, ensure_ascii=False))
        idx += 1
    if notify_enabled is not None:
        sets.append(f"notify_enabled=${idx}")
        args.append(bool(notify_enabled))
        idx += 1
    if enabled is not None:
        sets.append(f"is_enabled=${idx}")
        args.append(bool(enabled))
        idx += 1

    if len(sets) == 1:
        return

    sql = f"UPDATE crawler.crawler_subscriptions SET {', '.join(sets)} WHERE id=$1"
    await pool.execute(sql, *args)


async def retry_delivery_task(pool: PgPool, task_id: str) -> None:
    await pool.execute(
        """
        UPDATE crawler.crawler_delivery_tasks
        SET status='pending',
            attempt=0,
            last_error=NULL,
            run_after=now(),
            -- reset external tracking (CD2)
            remote_task_id=NULL,
            remote_status=NULL,
            remote_progress=NULL,
            remote_error_code=NULL,
            remote_error_msg=NULL,
            result_paths=NULL,
            next_poll_at=NULL,
            poll_attempts=0,
            last_polled_at=NULL,
            submitted_at=NULL,
            finished_at=NULL,
            notified_at=NULL,
            updated_at=now()
        WHERE id=$1
        """,
        task_id,
    )


async def retry_failed_tasks(pool: PgPool, *, limit: int = 200) -> int:
    limit = max(1, int(limit or 200))
    row = await pool.fetchone(
        """
        WITH targets AS (
            SELECT id
            FROM crawler.crawler_delivery_tasks
            WHERE status='failed'
            ORDER BY updated_at DESC
            LIMIT $1
        ),
        updated AS (
            UPDATE crawler.crawler_delivery_tasks t
            SET status='pending',
                attempt=0,
                last_error=NULL,
                run_after=now(),
                remote_task_id=NULL,
                remote_status=NULL,
                remote_progress=NULL,
                remote_error_code=NULL,
                remote_error_msg=NULL,
                result_paths=NULL,
                next_poll_at=NULL,
                poll_attempts=0,
                last_polled_at=NULL,
                submitted_at=NULL,
                finished_at=NULL,
                notified_at=NULL,
                updated_at=now()
            FROM targets
            WHERE t.id = targets.id
            RETURNING 1
        )
        SELECT count(*) AS c FROM updated
        """,
        limit,
    )
    return int((row or {}).get("c") or 0)
