from __future__ import annotations

import hashlib
import json
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional, Tuple

from core.env_utils import env_float, env_int, env_str
from core.suppress import suppress

import httpx
try:
    from PIL import Image  # type: ignore
except ModuleNotFoundError:  # pragma: no cover
    Image = None  # type: ignore
from io import BytesIO


def _require_pil() -> None:
    """Ensure Pillow is available before image processing."""
    if Image is None:  # pragma: no cover
        raise RuntimeError(
            "Pillow (PIL) is required to process cover images. Install `pillow` or disable cover fetching."
        )


DEFAULT_UA = (
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
)

# ----------------------------
# Config
# ----------------------------

def cache_dir() -> Path:
    return Path(env_str("COVER_CACHE_DIR", "/app/data/cover_cache")).resolve()

def max_files() -> int:
    try:
        return env_int("COVER_CACHE_MAX_FILES", 20000, min_value=1)
    except Exception:
        return 20000

def max_gb() -> float:
    try:
        return env_float("COVER_CACHE_MAX_GB", 20.0, min_value=0.1)
    except Exception:
        return 20.0

def fetch_timeout() -> float:
    try:
        return env_float("COVER_FETCH_TIMEOUT", 6.0, min_value=1.0)
    except Exception:
        return 6.0

def fail_cooldown_sec() -> int:
    try:
        return env_int("COVER_FAIL_COOLDOWN_SEC", 1800, min_value=0)
    except Exception:
        return 1800

def img_format() -> str:
    fmt = (env_str("COVER_FMT", "webp") or "webp").strip().lower()
    return "webp" if fmt not in ("webp", "jpeg", "jpg", "png") else fmt

def img_quality() -> int:
    try:
        q = env_int("COVER_QUALITY", 75, min_value=1, max_value=100)
        return max(30, min(95, q))
    except Exception:
        return 75

def user_agent() -> str:
    return (env_str("COVER_FETCH_UA", DEFAULT_UA) or DEFAULT_UA).strip()

def _failures_path() -> Path:
    return cache_dir() / "failures.json"

def _read_failures() -> dict:
    p = _failures_path()
    try:
        if p.exists():
            return json.loads(p.read_text(encoding="utf-8") or "{}") or {}
    except Exception:
        return {}
    return {}

def _write_failures(d: dict) -> None:
    p = _failures_path()
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_suffix(".tmp")
    tmp.write_text(json.dumps(d, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(p)

def _now() -> int:
    return int(time.time())

def _in_cooldown(url: str) -> bool:
    if not url:
        return False
    d = _read_failures()
    ts = int(d.get(url, 0) or 0)
    return (_now() - ts) < fail_cooldown_sec()

def _mark_failed(url: str) -> None:
    if not url:
        return
    d = _read_failures()
    d[url] = _now()
    # keep the file from growing forever
    if len(d) > 20000:
        # drop oldest 10%
        items = sorted(d.items(), key=lambda kv: kv[1])
        for k, _ in items[: max(1, len(items)//10)]:
            d.pop(k, None)
    _write_failures(d)

def _touch(path: Path) -> None:
    try:
        os.utime(path, None)
    except Exception as e:
        suppress(site="crawler/cover_cache:touch", exc=e, fallback=None)


# ----------------------------
# Image helpers
# ----------------------------

def _resize_cover(img: Image.Image, w: int, h: int) -> Image.Image:
    """Center-crop to fill (cover)."""
    img = img.convert("RGB")
    iw, ih = img.size
    if iw <= 0 or ih <= 0:
        return img

    target_ratio = w / h
    src_ratio = iw / ih

    if src_ratio > target_ratio:
        # too wide -> crop width
        new_w = int(ih * target_ratio)
        left = (iw - new_w) // 2
        img = img.crop((left, 0, left + new_w, ih))
    else:
        # too tall -> crop height
        new_h = int(iw / target_ratio)
        top = (ih - new_h) // 2
        img = img.crop((0, top, iw, top + new_h))

    return img.resize((w, h), Image.LANCZOS)

def _safe_ext(fmt: str) -> str:
    if fmt == "jpg":
        return "jpeg"
    return fmt

def _make_cache_relpath(item_id: int | str, w: int, h: int, fmt: str) -> str:
    # shard by id to avoid huge single directory
    sid = str(item_id or "").replace("-", "")
    shard1 = (sid[:2] or "xx")
    shard2 = (sid[2:4] or "yy")
    return f"covers/{w}x{h}/{shard1}/{shard2}/{item_id}.{_safe_ext(fmt)}"

def _abs_from_rel(rel: str) -> Path:
    return cache_dir() / rel

def _ensure_parent(path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)


async def download_image(url: str, referer: Optional[str] = None) -> Optional[bytes]:
    if not url:
        return None
    timeout = httpx.Timeout(fetch_timeout(), connect=fetch_timeout())
    headers = {"User-Agent": user_agent()}
    if referer:
        headers["Referer"] = referer
    try:
        async with httpx.AsyncClient(timeout=timeout, follow_redirects=True) as client:
            r = await client.get(url, headers=headers)
            if r.status_code >= 400:
                return None
            ct = (r.headers.get("content-type") or "").lower()
            if "image" not in ct and len(r.content) < 32:
                return None
            return bytes(r.content)
    except Exception:
        return None


def ensure_cache_limits() -> None:
    """LRU eviction by atime/mtime. Cheap and effective."""
    base = cache_dir()
    base.mkdir(parents=True, exist_ok=True)
    max_f = max_files()
    max_b = int(max_gb() * (1024**3))

    files = []
    total = 0
    for p in base.rglob("*"):
        if not p.is_file():
            continue
        # ignore failures.json
        if p.name == "failures.json":
            continue
        try:
            st = p.stat()
        except Exception:
            continue
        total += st.st_size
        at = getattr(st, "st_atime", st.st_mtime)
        files.append((at, st.st_size, p))

    if (max_f and len(files) > max_f) or (max_b and total > max_b):
        files.sort(key=lambda t: t[0])  # oldest first
        # delete until under both limits
        i = 0
        while i < len(files) and ((max_f and len(files) - i > max_f) or (max_b and total > max_b)):
            _, sz, p = files[i]
            try:
                p.unlink(missing_ok=True)
            except Exception as e:
                suppress(site="crawler/cover_cache:evict_unlink", exc=e, fallback=None)
            total -= sz
            i += 1


@dataclass
class CoverResult:
    path: Path
    relpath: str
    mime: str


def placeholder_path(static_dir: Path) -> Path:
    # Reuse existing placeholder in static assets
    cand = static_dir / "img" / "poster_placeholder.svg"
    return cand


def mime_for_path(p: Path) -> str:
    suf = p.suffix.lower()
    if suf == ".webp":
        return "image/webp"
    if suf in (".jpg", ".jpeg"):
        return "image/jpeg"
    if suf == ".png":
        return "image/png"
    if suf == ".svg":
        return "image/svg+xml"
    return "application/octet-stream"


async def get_or_build_cover(
    *,
    pool,
    item_id: int | str,
    w: int,
    h: int,
    static_dir: Path,
) -> CoverResult:
    """Return cached cover path.

    方案B + 全对齐：不依赖 crawler.crawler_items。
    - item_id 为 public.article.tid（bigint），支持传入 str/int
    - cover_url 从 public.article.preview_images 推导（JSON 数组/逗号/空格分隔 best-effort）
    - 缓存文件仍然落到 COVER_CACHE_DIR（不写回数据库）
    """
    # sanity
    w = int(w or 360)
    h = int(h or 540)
    w = max(64, min(2000, w))
    h = max(64, min(2000, h))

    # normalize id: DB uses bigint tid; accept str/int from API
    try:
        tid = int(str(item_id).strip())
    except Exception:
        p = placeholder_path(static_dir)
        return CoverResult(path=p, relpath="", mime=mime_for_path(p))


    row = await pool.fetchrow(
        """
        SELECT detail_url, preview_images
        FROM public.article
        WHERE tid = $1::bigint
        """,
        tid,
    )
    if not row:
        p = placeholder_path(static_dir)
        return CoverResult(path=p, relpath="", mime=mime_for_path(p))

    preview_images = (row.get("preview_images") or "").strip()
    referer = (row.get("detail_url") or "").strip() or None

    cover_url = ""
    if preview_images:
        s = preview_images.strip()
        if s.startswith("["):
            try:
                import json as _json
                arr = _json.loads(s)
                if isinstance(arr, list) and arr:
                    cover_url = str(arr[0]).strip()
            except Exception:
                cover_url = ""
        if not cover_url:
            if "," in s:
                cover_url = s.split(",", 1)[0].strip()
            else:
                cover_url = s.split(" ", 1)[0].strip()

    fmt = img_format()
    desired_rel = _make_cache_relpath(item_id, w, h, fmt)
    desired_abs = _abs_from_rel(desired_rel)

    if desired_abs.exists():
        _touch(desired_abs)
        ensure_cache_limits()
        return CoverResult(path=desired_abs, relpath=desired_rel, mime=mime_for_path(desired_abs))

    if cover_url and _in_cooldown(cover_url):
        p = placeholder_path(static_dir)
        return CoverResult(path=p, relpath="", mime=mime_for_path(p))

    data = await download_image(cover_url, referer=referer)
    if not data:
        _mark_failed(cover_url)
        p = placeholder_path(static_dir)
        return CoverResult(path=p, relpath="", mime=mime_for_path(p))

    try:
        _require_pil()
        img = Image.open(BytesIO(data))
        img = _resize_cover(img, w, h)
        _ensure_parent(desired_abs)
        tmp = desired_abs.with_suffix(desired_abs.suffix + ".tmp")
        save_kwargs = {}
        if fmt == "webp":
            save_kwargs = {"quality": img_quality(), "method": 6}
        elif fmt in ("jpeg", "jpg"):
            save_kwargs = {"quality": img_quality(), "optimize": True}
        img.save(tmp, format=fmt.upper() if fmt != "jpg" else "JPEG", **save_kwargs)
        tmp.replace(desired_abs)
        _touch(desired_abs)
        ensure_cache_limits()
        return CoverResult(path=desired_abs, relpath=desired_rel, mime=mime_for_path(desired_abs))
    except Exception as e:
        suppress(site="crawler/cover_cache:download_or_process", exc=e, fallback=None)
        _mark_failed(cover_url)
        p = placeholder_path(static_dir)
        return CoverResult(path=p, relpath="", mime=mime_for_path(p))