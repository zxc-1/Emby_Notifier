from __future__ import annotations

import re
from typing import Iterable


def _is_probably_ad(url: str) -> bool:
    u = (url or "").lower()
    if not u:
        return True
    # filter common non-cover images
    bad_keywords = ("avatar", "logo", "banner", "icon", "ads", "advert", "static/image", "smilies")
    if any(k in u for k in bad_keywords):
        return True
    return False


def normalize_image_urls(urls: Iterable[str]) -> list[str]:
    out: list[str] = []
    seen = set()
    for u in urls:
        u = (u or "").strip()
        if not u:
            continue
        # discard obvious non-image
        if not re.search(r"\.(?:jpg|jpeg|png|webp)(?:\?|$)", u, re.IGNORECASE):
            # allow zoomfile style with no ext
            pass
        if u in seen:
            continue
        seen.add(u)
        out.append(u)
    return out


def choose_cover_and_gallery(urls: Iterable[str]) -> tuple[str, list[str]]:
    """Choose a cover image from a list, and return gallery (remaining).

    Strategy (safe defaults):
      1) keep order
      2) skip obvious ad/ui images
      3) pick first remaining as cover
    """
    normalized = normalize_image_urls(urls)
    filtered = [u for u in normalized if not _is_probably_ad(u)]
    if not filtered:
        return (normalized[0], normalized[1:]) if normalized else ("", [])
    cover = filtered[0]
    gallery = [u for u in normalized if u != cover]
    return cover, gallery
