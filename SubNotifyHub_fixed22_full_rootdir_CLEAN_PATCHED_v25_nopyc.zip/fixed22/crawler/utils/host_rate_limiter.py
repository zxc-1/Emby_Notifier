from __future__ import annotations

import asyncio
import random
import time
from dataclasses import dataclass
from typing import Dict, Tuple
from urllib.parse import urlparse


# Process-wide limiters keyed by a string (e.g. host group).
_GLOBAL_LIMITERS: Dict[str, "HostRateLimiter"] = {}


@dataclass
class HostRatePolicy:
    """A simple anti-bot pacing policy per host.

    This mirrors the spirit of the SHT / sehua spider logic:
    - Random delay between requests
    - Occasional longer rest after a small burst
    """

    min_delay_s: float = 1.6
    max_delay_s: float = 3.8
    burst_every: int = 8
    burst_rest_range_s: Tuple[float, float] = (5.0, 10.0)


class HostRateLimiter:
    """Per-host rate limiter for async crawlers.

    Notes:
    - Uses a global lock for simplicity (low contention in this project).
    - Tracks last request timestamp and a per-host counter.
    """

    def __init__(self, policy: HostRatePolicy | None = None):
        self.policy = policy or HostRatePolicy()
        self._lock = asyncio.Lock()
        self._last_ts: Dict[str, float] = {}
        self._count: Dict[str, int] = {}

    @staticmethod
    def host_of(url: str) -> str:
        try:
            return (urlparse(url).hostname or "").lower().strip()
        except Exception:
            return ""

    async def wait_url(self, url: str) -> None:
        host = self.host_of(url)
        if not host:
            # Still yield to event loop a bit
            await asyncio.sleep(random.uniform(0.2, 0.6))
            return
        await self.wait_host(host)

    async def wait_host(self, host: str) -> None:
        host = (host or "").lower().strip()
        if not host:
            await asyncio.sleep(random.uniform(0.2, 0.6))
            return

        async with self._lock:
            now = time.monotonic()
            last = self._last_ts.get(host, 0.0)
            # Random delay between requests
            delay = random.uniform(float(self.policy.min_delay_s), float(self.policy.max_delay_s))
            need = max(0.0, last + delay - now)

            # Burst rest
            cnt = int(self._count.get(host, 0)) + 1
            self._count[host] = cnt
            if self.policy.burst_every > 0 and (cnt % int(self.policy.burst_every) == 0):
                need += random.uniform(*self.policy.burst_rest_range_s)

            # Reserve timestamp slot
            self._last_ts[host] = now + need

        if need > 0:
            await asyncio.sleep(need)


def get_global_limiter(key: str, policy: HostRatePolicy | None = None) -> HostRateLimiter:
    """Return a process-global limiter.

    This helps avoid accidental QPS amplification when multiple plugins/workers
    hit the same host concurrently within the same process.
    """
    k = (key or "default").strip().lower()
    lim = _GLOBAL_LIMITERS.get(k)
    if lim is not None:
        # Keep the first policy (callers should agree on policy for a key).
        return lim
    lim = HostRateLimiter(policy)
    _GLOBAL_LIMITERS[k] = lim
    return lim
