from __future__ import annotations

import re
from datetime import datetime, timedelta

_DATE_RE = re.compile(r"(\d{4}-\d{2}-\d{2})")


def parse_date_only(text: str, *, now: datetime | None = None) -> str:
    """Parse text into a YYYY-MM-DD string (best-effort).

    Supports typical Discuz/Forum variants:
      - 'YYYY-MM-DD' or 'YYYY-MM-DD HH:MM'
      - '昨天', '前天'
      - 'x分钟前/小时前/秒前/半小时前'

    Returns '' if unknown.
    """
    s = (text or "").strip()
    if not s:
        return ""

    now = now or datetime.now()
    today = now.date()

    m = _DATE_RE.search(s)
    if m:
        return m.group(1)

    if "昨天" in s:
        return (today - timedelta(days=1)).isoformat()
    if "前天" in s:
        return (today - timedelta(days=2)).isoformat()

    # relative time => today
    if any(k in s for k in ("分钟前", "小时前", "秒前", "半小时前")):
        return today.isoformat()

    return ""
