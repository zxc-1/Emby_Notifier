from __future__ import annotations

import html as _html
import re
from typing import Mapping


_DEFAULT_ACCEPT = (
    "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8"
)


def build_browser_headers(*, user_agent: str, referer: str | None = None) -> dict[str, str]:
    h = {
        "User-Agent": user_agent,
        "Accept": _DEFAULT_ACCEPT,
        "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
        "Upgrade-Insecure-Requests": "1",
    }
    if referer:
        h["Referer"] = referer
    return h


def looks_like_challenge(html: str) -> bool:
    if not html:
        return True
    s = html[:30000].lower()
    # Cloudflare common markers
    if "just a moment" in s:
        return True
    if "attention required" in s and "cloudflare" in s:
        return True
    if "cf-chl" in s or "challenge" in s and "cloudflare" in s:
        return True
    if "verify you are human" in s or "human verification" in s:
        return True
    # Captcha markers
    if "g-recaptcha" in s or "hcaptcha" in s or "recaptcha" in s:
        return True
    # Generic WAF/deny pages
    if "access denied" in s or "permission denied" in s:
        return True
    if "request blocked" in s or "blocked due to" in s:
        return True
    # Very short HTML bodies are often error/challenge placeholders
    if len(s) < 200 and ("<html" in s or "<!doctype" in s):
        return True
    return False


_MAGNET_RE = re.compile(
    r"magnet:\?xt=urn:btih:([A-Za-z0-9]{32,40})(?:[^\s'\"<>]*)",
    re.IGNORECASE,
)


def extract_magnets(text: str) -> list[str]:
    """Extract magnet links in a more robust way than a single regex pass.

    - Unescapes HTML entities
    - Accepts 32 (base32) or 40 (hex) infohash
    """
    if not text:
        return []
    t = _html.unescape(text)
    out: list[str] = []
    for m in _MAGNET_RE.finditer(t):
        # keep full matched magnet URI
        full = m.group(0)
        # Trim trailing punctuation that often sticks in forum posts
        full = full.rstrip(")]}>,.。；;\n\r\t ")
        if full and full not in out:
            out.append(full)
    return out
