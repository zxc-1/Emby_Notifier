from __future__ import annotations

"""Minimal .torrent (bencode) utilities.

We only need the infohash to build a magnet link.

No external deps, compatible with pure-Python runtime.
"""

import hashlib
from typing import Any, Tuple


class BencodeError(ValueError):
    pass


def bdecode(data: bytes) -> Any:
    """Decode bencoded bytes."""

    if not isinstance(data, (bytes, bytearray)):
        raise BencodeError("bdecode expects bytes")

    buf = bytes(data)
    n = len(buf)
    i = 0

    def parse() -> Any:
        nonlocal i
        if i >= n:
            raise BencodeError("unexpected EOF")

        c = buf[i:i + 1]

        # integer: i<num>e
        if c == b"i":
            i += 1
            end = buf.find(b"e", i)
            if end < 0:
                raise BencodeError("unterminated int")
            raw = buf[i:end]
            i = end + 1
            try:
                return int(raw)
            except Exception as e:
                raise BencodeError(f"invalid int: {raw!r}") from e

        # list: l...e
        if c == b"l":
            i += 1
            out = []
            while True:
                if i >= n:
                    raise BencodeError("unterminated list")
                if buf[i:i + 1] == b"e":
                    i += 1
                    return out
                out.append(parse())

        # dict: d...e
        if c == b"d":
            i += 1
            out = {}
            while True:
                if i >= n:
                    raise BencodeError("unterminated dict")
                if buf[i:i + 1] == b"e":
                    i += 1
                    return out
                k = parse()
                v = parse()
                out[k] = v

        # byte string: <len>:<bytes>
        if c.isdigit():
            colon = buf.find(b":", i)
            if colon < 0:
                raise BencodeError("invalid string length")
            try:
                ln = int(buf[i:colon])
            except Exception as e:
                raise BencodeError("invalid string length") from e
            i = colon + 1
            if i + ln > n:
                raise BencodeError("truncated string")
            s = buf[i:i + ln]
            i += ln
            return s

        raise BencodeError(f"invalid token at {i}: {c!r}")

    val = parse()
    return val


def bencode(x: Any) -> bytes:
    """Encode python types into bencode."""

    if isinstance(x, bool):
        # bool is subclass of int; treat explicitly to avoid surprises.
        x = int(x)
    if isinstance(x, int):
        return b"i" + str(x).encode("ascii") + b"e"
    if isinstance(x, (bytes, bytearray)):
        b = bytes(x)
        return str(len(b)).encode("ascii") + b":" + b
    if isinstance(x, str):
        return bencode(x.encode("utf-8"))
    if isinstance(x, (list, tuple)):
        return b"l" + b"".join(bencode(i) for i in x) + b"e"
    if isinstance(x, dict):
        # keys must be bytes; sort lexicographically
        items: list[Tuple[bytes, Any]] = []
        for k, v in x.items():
            if isinstance(k, str):
                kb = k.encode("utf-8")
            elif isinstance(k, (bytes, bytearray)):
                kb = bytes(k)
            else:
                raise BencodeError(f"dict key must be bytes/str, got {type(k)}")
            items.append((kb, v))
        items.sort(key=lambda kv: kv[0])
        out = [b"d"]
        for k, v in items:
            out.append(bencode(k))
            out.append(bencode(v))
        out.append(b"e")
        return b"".join(out)

    raise BencodeError(f"unsupported type: {type(x)}")


def infohash_from_torrent_bytes(data: bytes) -> str:
    """Compute hex infohash from a .torrent file."""

    obj = bdecode(data)
    if not isinstance(obj, dict):
        raise BencodeError("torrent root is not a dict")

    info = None
    if b"info" in obj:
        info = obj[b"info"]
    elif "info" in obj:
        info = obj["info"]
    if not isinstance(info, dict):
        raise BencodeError("torrent has no info dict")

    h = hashlib.sha1(bencode(info)).hexdigest()
    return h


def magnet_from_infohash(infohash_hex: str) -> str:
    h = (infohash_hex or "").strip().lower()
    if not h:
        return ""
    return f"magnet:?xt=urn:btih:{h}"
