from __future__ import annotations

import asyncio
import random
import time
from dataclasses import dataclass
from typing import Dict


@dataclass
class CircuitPolicy:
    """Circuit breaker tuning."""

    fail_threshold: int = 4
    cool_down_s: float = 60.0
    cool_down_jitter_s: float = 30.0


class CircuitBreaker:
    """A lightweight per-host circuit breaker.

    When a host fails repeatedly (timeout/challenge/deny), we pause further
    requests for a cool-down window to reduce the chance of escalating
    rate limits / bans.
    """

    def __init__(self, policy: CircuitPolicy | None = None):
        self.policy = policy or CircuitPolicy()
        self._lock = asyncio.Lock()
        self._fails: Dict[str, int] = {}
        self._open_until: Dict[str, float] = {}

    async def wait_if_open(self, host: str) -> None:
        h = (host or "").lower().strip()
        if not h:
            return
        async with self._lock:
            until = float(self._open_until.get(h, 0.0))
        now = time.monotonic()
        if until > now:
            await asyncio.sleep(max(0.0, until - now))

    async def record_success(self, host: str) -> None:
        h = (host or "").lower().strip()
        if not h:
            return
        async with self._lock:
            self._fails.pop(h, None)
            self._open_until.pop(h, None)

    async def record_failure(self, host: str) -> None:
        h = (host or "").lower().strip()
        if not h:
            return
        async with self._lock:
            n = int(self._fails.get(h, 0)) + 1
            self._fails[h] = n
            if n >= int(self.policy.fail_threshold):
                cool = float(self.policy.cool_down_s) + random.uniform(0.0, float(self.policy.cool_down_jitter_s))
                self._open_until[h] = time.monotonic() + max(1.0, cool)
