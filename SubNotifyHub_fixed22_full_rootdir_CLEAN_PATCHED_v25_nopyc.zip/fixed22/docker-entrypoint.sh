#!/bin/sh
set -e

APP_PORT="${APP_PORT:-8000}"

# Default role: run both API + background services in one container unless overridden
export APP_ROLE="${APP_ROLE:-all}"

# Note: when /data is mounted as a Docker volume, it overrides the image
# directory and ownership. Fix permissions at container start.
mkdir -p /data /data/logs /data/poster_cache /data/deadletter /data/blob_store || true
chown -R appuser:appgroup /data || true

# If a previous run created /data/.env as root with 0600, appuser can't read it.
# Make sure appuser owns it (best-effort).
if [ -e /data/.env ]; then
  chown appuser:appgroup /data/.env || true
  chmod 600 /data/.env || true
fi

# 强制启用终端颜色支持
export TERM="${TERM:-xterm-256color}"
export FORCE_COLOR=1
export PYTHONUNBUFFERED=1

exec su -s /bin/sh appuser -c "python -m uvicorn app:app --host 0.0.0.0 --port ${APP_PORT} --workers 1 --no-access-log"
