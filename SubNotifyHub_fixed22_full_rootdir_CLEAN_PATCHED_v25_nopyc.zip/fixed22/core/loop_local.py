"""Loop-local helpers for asyncio primitives.

Asyncio primitives (Lock/Semaphore/Event/Future/Task/Queue) are bound to the
running event loop they were created in. Caching them globally (module-level
singletons) can cause cross-loop crashes in CLI tools, hot-reload, and some
unit-test setups.

This module provides a tiny "loop-local" storage: values are stored per
`asyncio.get_running_loop()` using a WeakKeyDictionary, so loops can be GC'd.
"""

from __future__ import annotations

import asyncio
import weakref
from typing import Any, Callable, Dict, TypeVar

T = TypeVar("T")

# name -> { loop -> value }
_STORE: Dict[str, "weakref.WeakKeyDictionary[asyncio.AbstractEventLoop, Any]"] = {}


def loop_local(name: str, factory: Callable[[], T]) -> T:
    """Return a value stored per running event loop.

    `factory()` is called at most once per loop.
    """
    loop = asyncio.get_running_loop()
    d = _STORE.get(name)
    if d is None:
        d = weakref.WeakKeyDictionary()
        _STORE[name] = d
    v = d.get(loop)
    if v is None:
        v = factory()
        d[loop] = v
    return v  # type: ignore[return-value]
