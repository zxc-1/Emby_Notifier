from __future__ import annotations

"""Media identity helpers (single source of truth).

Used by:
  - api/webhook.py: webhook-level dedup key
  - notifier/worker.py: enqueue-level dedup key
  - notifier/service/pipeline.py: NotificationContent.media_key

Design goals:
  - Suppress noisy duplicates: same file/folder reported multiple times with
    different item IDs.
  - Keep different versions/folders separate by default (especially AV-like).
  - Only fall back to AV "code" when path is missing.
"""
import logging
from core.logging import get_biz_logger_adapter
logger = get_biz_logger_adapter(__name__)


import re
from typing import Any, Optional

__all__ = [
    "normalize_event",
    "normalize_path",
    "extract_parent_folder",
    "extract_code",
    "is_av_style",
    "build_media_sig",
]


def normalize_event(ev: Any) -> str:
    """Normalize common Emby webhook event spellings/case."""
    s = str(ev or "").strip()
    if not s:
        return ""
    s = s.replace(" ", "")
    return s.lower()


def normalize_path(p: Any) -> str:
    """Normalize path for stable dedup keys."""
    s = str(p or "").strip().replace("\\", "/")
    while "//" in s:
        s = s.replace("//", "/")
    return s.rstrip("/")


def extract_parent_folder(p: Any) -> str:
    norm = normalize_path(p)
    if not norm:
        return ""
    return norm.rsplit("/", 1)[0] if "/" in norm else ""


# Heuristic: extract "番号/片号" from path or item name for better dedup.
_CODE_RE = re.compile(
    r"(?i)\b(fc2)\s*[-_ ]?\s*(?:ppv\s*[-_ ]?)?(\d{5,9})\b"
    r"|\b([a-z]{2,6})\s*[-_ ]\s*(\d{3,7})(?:\s*[-_ ]\s*(\d{1,3}))?\b"
)

_AV_CODE_PREFIXES = {
    "FC2",
    "MD",
    "MIAB",
    "DASS",
    "MADOU",
    "HEYZO",
    "IPX",
    "SSIS",
    "SSNI",
    "MIDE",
    "JUL",
    "ABP",
    "URE",
    "SUTE",
}


def extract_code(item_path: Any, item_name: Any = "") -> str:
    """Best-effort extract a stable media code for AV-like content."""
    cands: list[str] = []
    p = str(item_path or "").replace("\\", "/")
    if p:
        bn = p.rsplit("/", 1)[-1]
        if "." in bn:
            bn = bn.rsplit(".", 1)[0]
        cands.append(bn)
        parent = extract_parent_folder(p)
        if parent:
            cands.append(parent.rsplit("/", 1)[-1])
    if item_name:
        cands.append(str(item_name))

    for s in cands:
        if not s:
            continue
        m = _CODE_RE.search(str(s))
        if not m:
            continue
        if m.group(1) and m.group(2):
            # FC2 / FC2-PPV variants
            return f"FC2-{m.group(2)}"
        if m.group(3) and m.group(4):
            prefix = str(m.group(3)).upper()
            num = str(m.group(4))
            suffix = str(m.group(5) or "").strip()
            return f"{prefix}-{num}-{suffix}" if suffix else f"{prefix}-{num}"
    return ""


def is_av_style(item_path: Any, item_name: Any = "") -> bool:
    """Heuristic: treat as AV-like if path contains adult hints or has AV code."""
    norm = str(item_path or "").replace("\\", "/").lower()
    if re.search(r"(^|/)(av|jav)(/|$)", norm):
        return True
    for kw in ("fc2", "ppv", "onlyfans", "麻豆", "madou", "porn", "adult", "jav"):
        if kw and kw in norm:
            return True
    code = extract_code(item_path or "", item_name or "")
    if code:
        prefix = code.split("-", 1)[0].upper()
        if prefix in _AV_CODE_PREFIXES:
            return True
    return False


def _safe_int(v: Any) -> Optional[int]:
    if v is None:
        return None
    if isinstance(v, int):
        return v
    try:
        s = str(v).strip()
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"整数转换失败 - 输入值类型={type(v).__name__}, 原因={type(e).__name__}")
        return None
    if not s:
        return None
    m = re.search(r"(\d+)", s)
    if not m:
        return None
    try:
        return int(m.group(1))
    except (ValueError, TypeError) as e:
        logger.detail(f"整数解析失败 - 匹配值={m.group(1)!r}, 原因={type(e).__name__}")
        return None


def build_media_sig(
    *,
    item_id: Any = "",
    item_path: Any = "",
    item_name: Any = "",
    library_id: Any = "",
    is_adult_hint: bool = False,
    item_type: Any = "",
    series_id: Any = "",
    series_name: Any = "",
    season_number: Any = None,
    episode_number: Any = None,
    episode_strategy: str = "series",
) -> str:
    """Build a stable media signature.

    Returns something like:
      - lib:<id>|series:<sid>|S01E02
      - lib:<id>|folder:/path/to/folder
      - lib:<id>|path:/path/to/file.mkv
      - lib:<id>|item:<itemid>   (fallback)
      - lib:<id>|code:FC2-12345  (last-resort for AV-like when path missing)
    """
    iid = str(item_id or "").strip()
    name = str(item_name or "").strip()
    lib = str(library_id or "").strip()
    p = normalize_path(item_path or "")

    # Episodes: prefer series + SxxEyy (stable across URL changes and retries).
    # Strategy is configurable so operators can choose:
    # - "series": dedup by (series_id + season/episode)  (default)
    # - "path":   dedup by file path (keeps different versions separate)
    itype = str(item_type or "").strip().lower()
    if itype == "episode" and str(episode_strategy or "series").strip().lower() == "series":
        sid = str(series_id or "").strip() or str(series_name or "").strip()
        sn = _safe_int(season_number)
        en = _safe_int(episode_number)
        if sid and (sn is not None) and (en is not None):
            base = f"series:{sid}|S{sn:02d}E{en:02d}"
            return f"lib:{lib}|{base}" if lib else base

    av_like = bool(is_adult_hint) or is_av_style(p, name)
    code = extract_code(p, name) if av_like else ""

    base = ""
    if p:
        parent = extract_parent_folder(p)
        if parent:
            base = f"folder:{parent}" if av_like else f"path:{p}"
        else:
            base = f"path:{p}"

    if not base and iid:
        base = f"item:{iid}"

    # Only fall back to code when path is missing (avoid merging different versions).
    if not base and av_like and code:
        base = f"code:{code}"

    if not base:
        return ""
    return f"lib:{lib}|{base}" if lib else base
