from __future__ import annotations

"""Runtime context (AppContext) binding (compat shim).

Historically this project had two separate ContextVar implementations:
- ``core.runtime_ctx`` (Any-typed)
- ``ports.app_context`` (AppContextPort-typed + optional singleton fallback)

To avoid split-brain state and improve maintainability, ``ports.app_context`` is
the single source of truth. This module remains as a thin compatibility shim so
existing imports (e.g. middleware) keep working.
"""

import contextvars
from typing import Any, Optional

from ports.app_context import bind_ctx as _bind_ctx
from ports.app_context import get_ctx_optional as _get_ctx_optional
from ports.app_context import reset_ctx as _reset_ctx


def bind_ctx(ctx: Any | None) -> contextvars.Token:
    return _bind_ctx(ctx)  # type: ignore[arg-type]


def reset_ctx(token: contextvars.Token) -> None:
    _reset_ctx(token)


def get_ctx_optional() -> Optional[Any]:
    return _get_ctx_optional()  # type: ignore[return-value]
