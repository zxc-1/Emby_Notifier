from __future__ import annotations

import ipaddress
from core.logging import get_biz_logger
from typing import Optional

from fastapi import HTTPException, Request

from settings.runtime import get_settings

biz = get_biz_logger(__name__)

_WARNED_TRUST_PROXY_NO_ALLOWLIST = False


def _ip_in_cidrs(ip: str, cidrs: list[str]) -> bool:
    try:
        ip_obj = ipaddress.ip_address(ip)
    except (ValueError, TypeError) as e:
        biz.detail(f"IP 地址解析失败（已忽略） - ip={ip}, 原因={type(e).__name__}")
        return False
    for cidr in cidrs or []:
        try:
            net = ipaddress.ip_network(str(cidr), strict=False)
        except (ValueError, TypeError) as e:
            biz.detail(f"CIDR 网络解析失败（已忽略） - cidr={cidr}, 原因={type(e).__name__}")
            continue
        if ip_obj in net:
            return True
    return False



def get_remote_ip(request: Request) -> str:
    """Get request source IP (optionally trust proxy headers).

    Security model:
      - If WEBHOOK_TRUST_PROXY_HEADERS is enabled, we ONLY honor X-Forwarded-For / X-Real-IP
        when the immediate peer (request.client.host) is within WEBHOOK_TRUSTED_PROXY_IPS.
      - If the trusted proxy allowlist is empty, we fall back to the socket peer IP and
        log a warning once.

    This prevents attackers from spoofing XFF when the service is reachable directly.
    """
    client_ip = request.client.host if request.client else "unknown"

    s = get_settings()
    if not getattr(s, "WEBHOOK_TRUST_PROXY_HEADERS", False):
        return client_ip

    trusted = list(getattr(s, "WEBHOOK_TRUSTED_PROXY_IPS", []) or [])
    if not trusted:
        global _WARNED_TRUST_PROXY_NO_ALLOWLIST
        if not _WARNED_TRUST_PROXY_NO_ALLOWLIST:
            _WARNED_TRUST_PROXY_NO_ALLOWLIST = True
            biz.warning("⚠️ 已启用代理头信任但未配置可信代理 IP 列表：将忽略 X-Forwarded-For", stage="webhook_security", trust_proxy_headers=True, trusted_proxy_ips="", reason="missing_trusted_proxies")
        return client_ip

    # Only trust proxy headers if the direct peer is a trusted proxy
    if not _ip_in_cidrs(client_ip, trusted):
        return client_ip

    xff = request.headers.get("X-Forwarded-For") or request.headers.get("X-Real-IP")
    if not xff:
        return client_ip

    forwarded = xff.split(",")[0].strip()
    if not forwarded:
        return client_ip

    # Validate forwarded IP
    try:
        ipaddress.ip_address(forwarded)
    except (ValueError, TypeError) as e:
        biz.detail(f"转发 IP 验证失败（已忽略） - forwarded={forwarded}, 原因={type(e).__name__}")
        return client_ip
    return forwarded


def verify_emby_webhook(request: Request) -> None:
    """Verify /emby/webhook request.

    1) Optional source IP allowlist (WEBHOOK_ALLOWED_IPS)
    2) Optional query token match (?token=xxx) when WEBHOOK_SECRET is set
    """
    cur_settings = get_settings()
    remote_ip = get_remote_ip(request)

    if cur_settings.WEBHOOK_ALLOWED_IPS:
        try:
            ip_obj = ipaddress.ip_address(remote_ip)
        except Exception:
            raise HTTPException(status_code=403, detail="INVALID_REMOTE_IP")

        allowed = False
        for cidr in cur_settings.WEBHOOK_ALLOWED_IPS:
            try:
                net = ipaddress.ip_network(cidr, strict=False)
            except (ValueError, TypeError) as e:
                biz.detail(f"Webhook 允许 IP CIDR 解析失败（已忽略） - cidr={cidr}, 原因={type(e).__name__}")
                continue
            if ip_obj in net:
                allowed = True
                break

        if not allowed:
            biz.warning(f"⚠️ Webhook 请求被拒绝：来源 IP 不在允许列表中", 来源IP=remote_ip)
            raise HTTPException(status_code=403, detail="IP_NOT_ALLOWED")

    if not cur_settings.WEBHOOK_SECRET:
        return

    q_token = request.query_params.get("token")
    if not q_token:
        biz.warning(f"⚠️ Webhook 请求被拒绝：缺少 token 查询参数", 来源IP=remote_ip)
        raise HTTPException(status_code=403, detail="MISSING_TOKEN")

    if q_token != cur_settings.WEBHOOK_SECRET:
        # Do not log secrets/tokens.
        biz.warning(f"⚠️ Webhook 请求被拒绝：token 不匹配", 来源IP=remote_ip)
        raise HTTPException(status_code=403, detail="INVALID_TOKEN")


def _normalize_token(raw: str) -> str:
    """Normalize bearer tokens for comparison.

    Accepts:
      - "Bearer xxx"
      - "xxx"
    Returns the token value with any Bearer prefix stripped.
    """
    s = (raw or "").strip()
    if not s:
        return ""
    if s.lower().startswith("bearer "):
        return s[7:].strip()
    return s


def verify_mediahelp_notify(request: Request, provided_token: Optional[str]) -> None:
    """Protect /notify/mediahelp (MediaHelp/Forward callback) using MEDIAHELP_TOKEN.

    Forward callback is designed to reuse the same secret as MediaHelp (MEDIAHELP_TOKEN).
    We intentionally do **not** require a separate FORWARD_BRIDGE_TOKEN.

    Accepted token locations (first match wins):
      - Header: X-MediaHelp-Token: <token>
      - Header: X-Forward-Token: <token>      (backward compatibility)
      - Query : ?token=<token>
      - Header: Authorization: Bearer <token>  (or raw token)

    NOTE: Many reverse proxies/gateways inject an Authorization header
    (often Basic ...) for unrelated upstreams. To avoid accidental 401s,
    Authorization is treated as a *last resort* and Basic auth is ignored.

    Policy:
      - If MEDIAHELP_TOKEN is set (non-empty), require a matching token.
      - If MEDIAHELP_TOKEN is empty, DENY by default unless MEDIAHELP_ALLOW_PUBLIC_NOTIFY=true.

    Logs never include the token value.
    """
    s = get_settings()
    expected = _normalize_token(str(getattr(s, "MEDIAHELP_TOKEN", "") or ""))

    if not expected:
        if bool(getattr(s, "MEDIAHELP_ALLOW_PUBLIC_NOTIFY", False)):
            return
        remote_ip = get_remote_ip(request)
        biz.warning(f"⚠️ MediaHelp 通知请求被拒绝：未配置 MEDIAHELP_TOKEN（默认拒绝）", 来源IP=remote_ip)
        raise HTTPException(status_code=403, detail="MEDIAHELP_TOKEN_REQUIRED")

    hdr_auth = request.headers.get("Authorization")
    hdr_mh = request.headers.get("X-MediaHelp-Token")
    hdr_fw = request.headers.get("X-Forward-Token")
    q_token = request.query_params.get("token")

    auth_candidate = (hdr_auth or "").strip()
    if auth_candidate.lower().startswith("basic "):
        # Gateway-injected Basic auth is almost never intended for this endpoint.
        auth_candidate = ""

    # Prefer explicit tokens; fall back to Authorization only if nothing else is provided.
    provided = _normalize_token((provided_token or hdr_mh or hdr_fw or q_token or auth_candidate or ""))
    if not provided or provided != expected:
        remote_ip = get_remote_ip(request)
        biz.warning(f"⚠️ MediaHelp 通知请求被拒绝：token 不匹配或缺失", 来源IP=remote_ip)
        raise HTTPException(status_code=401, detail="invalid or missing mediahelp token")
