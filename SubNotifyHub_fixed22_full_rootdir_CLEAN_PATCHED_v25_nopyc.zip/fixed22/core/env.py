from __future__ import annotations

"""Backwards-compatible env parsing helpers.

.. deprecated::
    This module is deprecated. Use :mod:`core.env_utils` instead.

Historically the project had multiple implementations of env parsing helpers.
The canonical implementation now lives in :mod:`core.env_utils`.

This module remains as a thin wrapper to avoid breaking older imports.
"""

import warnings

warnings.warn(
    "core.env is deprecated; use core.env_utils instead",
    DeprecationWarning,
    stacklevel=2,
)

# Re-export all functions from env_utils for backwards compatibility
from core.env_utils import env_int, env_float, env_bool, env_str  # noqa: F401, E402

__all__ = ["env_int", "env_float", "env_bool", "env_str"]
