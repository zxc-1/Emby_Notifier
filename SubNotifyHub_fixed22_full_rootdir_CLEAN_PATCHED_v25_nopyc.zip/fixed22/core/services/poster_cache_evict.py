from __future__ import annotations

import asyncio
import logging
from core.logging import get_biz_logger_adapter
from core.env_utils import env_bool, env_float

from core.task_registry import TaskRegistry

logger = get_biz_logger_adapter(__name__)


class PosterCacheEvictService:
    name = "poster_cache_evict"

    def __init__(self, *, poster_cache, registry: TaskRegistry) -> None:
        self._pc = poster_cache
        self._reg = registry

        # allow runtime override without new deps
        try:
            self._enabled = env_bool("POSTER_CACHE_EVICT_BG_ENABLED", True)
            self._interval_s = env_float("POSTER_CACHE_EVICT_BG_INTERVAL_SEC", 600.0, min_value=1.0)
        except (ValueError, TypeError) as e:
            logger.detail(f"海报缓存清理配置读取失败，使用默认值 - 原因={type(e).__name__}")
            self._enabled = True
            self._interval_s = 600.0

        self._stop_evt: asyncio.Event | None = None
        self._task: asyncio.Task | None = None

    async def start(self) -> None:
        if not self._enabled or float(self._interval_s) <= 0:
            return

        stop_evt = asyncio.Event()
        self._stop_evt = stop_evt

        async def _loop() -> None:
            try:
                while not stop_evt.is_set():
                    try:
                        await asyncio.wait_for(stop_evt.wait(), timeout=max(1.0, float(self._interval_s)))
                        break
                    except asyncio.TimeoutError:
                        pass
                    try:
                        await asyncio.to_thread(self._pc.evict_if_needed)
                    except Exception:
                        logger.detail("poster_cache 清理循环：异常已抑制", exc_info=True)
            except asyncio.CancelledError:
                raise
            except Exception:
                logger.detail("poster_cache evict loop：操作异常：crashed", exc_info=True)

        self._task = await self._reg.create_task(_loop(), name=self.name)

    async def stop(self) -> None:
        try:
            if self._stop_evt is not None:
                self._stop_evt.set()
        except (AttributeError, RuntimeError) as e:
            logger.detail(f"海报缓存清理停止事件设置失败（已忽略） - 原因={type(e).__name__}")

        t = self._task
        if not t:
            return
        try:
            await asyncio.wait_for(t, timeout=10.0)
        except asyncio.TimeoutError:
            try:
                t.cancel()
            except (RuntimeError, AttributeError) as e:
                logger.detail(f"海报缓存清理任务取消失败（已忽略） - 原因={type(e).__name__}")
        except (asyncio.CancelledError, RuntimeError) as e:
            logger.detail(f"海报缓存清理任务等待失败（已忽略） - 原因={type(e).__name__}")