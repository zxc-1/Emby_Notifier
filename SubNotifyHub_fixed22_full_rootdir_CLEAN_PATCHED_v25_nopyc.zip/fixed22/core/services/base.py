from __future__ import annotations

"""Service lifecycle primitives.

This app starts a few long-running background loops (TG polling, poster cache
eviction, hotlist daemon, cookie health checker, etc.).

Historically those loops were started directly in bootstrap with scattered
stop/cancel logic. A small Service abstraction improves maintainability:
  - every background loop has a clear start/stop contract
  - bootstrap wiring is shorter and less error-prone
  - TaskRegistry remains the single place that owns/cancels tasks

No extra dependencies are introduced.
"""

from typing import Protocol


class Service(Protocol):
    """A managed background service."""

    name: str

    async def start(self) -> None:
        ...

    async def stop(self) -> None:
        ...
