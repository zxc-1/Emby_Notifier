from __future__ import annotations

from core.logging import get_biz_logger_adapter
from typing import Iterable, List

from .base import Service

logger = get_biz_logger_adapter(__name__)


class ServiceManager:
    """Start/stop a set of services with best-effort safety.

    - start_all(): start in registration order
    - stop_all(): stop in reverse order

    Start failures are logged and re-raised (fail-fast) unless
    `continue_on_error` is True.
    """

    def __init__(self, services: Iterable[Service] | None = None) -> None:
        self._services: List[Service] = list(services or [])

    @property
    def services(self) -> List[Service]:
        return list(self._services)

    def add(self, svc: Service) -> None:
        self._services.append(svc)

    async def start_all(self, *, continue_on_error: bool = False) -> None:
        for svc in self._services:
            try:
                await svc.start()
                logger.detail("服务已启动 - service=%s", getattr(svc, "name", type(svc).__name__))
            except Exception:
                logger.fail("服务启动失败 - service=%s", getattr(svc, "name", type(svc).__name__), exc_info=True)
                if not continue_on_error:
                    raise

    async def stop_all(self) -> None:
        for svc in reversed(self._services):
            try:
                await svc.stop()
                logger.detail("服务已停止 - service=%s", getattr(svc, "name", type(svc).__name__))
            except Exception:
                logger.fail("服务停止失败 - service=%s", getattr(svc, "name", type(svc).__name__), exc_info=True)