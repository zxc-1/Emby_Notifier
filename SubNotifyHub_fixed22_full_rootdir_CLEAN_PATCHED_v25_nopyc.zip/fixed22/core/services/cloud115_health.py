from __future__ import annotations

import asyncio
import importlib
import logging
from core.logging import get_biz_logger_adapter

from ports.telegram import TelegramCaller

from core.task_registry import TaskRegistry
from settings.runtime import get_settings

logger = get_biz_logger_adapter(__name__)


class Cloud115HealthService:
    name = "cloud115_cookie_health"

    def __init__(self, *, app, registry: TaskRegistry, tg: TelegramCaller | None = None) -> None:
        self._app = app
        self._reg = registry
        self._tg = tg
        self._stop_evt: asyncio.Event | None = None
        self._task: asyncio.Task | None = None

    def _add_warning(self, key: str) -> None:
        try:
            ws = getattr(self._app.state, "health_warnings", None)
            if ws is None:
                return
            if key not in ws:
                ws.append(key)
        except Exception:
            logger.detail("115 健康检查：add_warning 失败", exc_info=True)

    def _remove_warning(self, key: str) -> None:
        try:
            ws = getattr(self._app.state, "health_warnings", None)
            if ws is None:
                return
            while key in ws:
                ws.remove(key)
        except Exception:
            logger.detail("115 健康检查：remove_warning 失败", exc_info=True)

    async def start(self) -> None:
        s = get_settings()
        if not bool(getattr(s, "CLOUD115_HEALTHCHECK_ENABLED", True)):
            return

        # Optional integration: keep the dependency behind a dynamic import so
        # core stays infrastructure-only.
        try:
            mod = importlib.import_module("integrations.cloud115.health")
            Cloud115HealthState = getattr(mod, "Cloud115HealthState")
            run_cloud115_cookie_health_loop = getattr(mod, "run_cloud115_cookie_health_loop")
        except (ImportError, AttributeError) as e:
            logger.detail(f"115 云盘健康检查模块加载失败（已忽略） - 原因={type(e).__name__}")
            return

        stop_evt = asyncio.Event()
        self._stop_evt = stop_evt

        # Expose state on app.state for admin UI.
        try:
            self._app.state.cloud115_health_stop = stop_evt
            self._app.state.cloud115_health_state = Cloud115HealthState()
        except (AttributeError, TypeError) as e:
            logger.detail(f"115 云盘健康检查状态初始化失败（已忽略） - 原因={type(e).__name__}")


        async def _notify(text: str) -> None:
            """Best-effort notification hook."""
            tg = self._tg
            if tg is None:
                return

            try:
                s = get_settings()
                ids = list(getattr(s, "TG_BOT_ALLOWED_USER_IDS", []) or [])
            except (AttributeError, TypeError, ValueError) as e:
                logger.detail(f"Telegram 用户 ID 列表读取失败（已忽略） - 原因={type(e).__name__}")
                ids = []

            if not ids:
                return

            payload_base = {"text": str(text or ""), "disable_web_page_preview": True}
            for uid in ids:
                try:
                    payload = dict(payload_base)
                    payload["chat_id"] = int(uid)
                    await tg.call_json("sendMessage", params=payload)
                except Exception:
                    logger.detail("115 健康检查：notify 失败 uid=%s", uid, exc_info=True)

        self._task = await self._reg.create_task(
            run_cloud115_cookie_health_loop(
                stop_evt=stop_evt,
                state=getattr(self._app.state, "cloud115_health_state", Cloud115HealthState()),
                add_warning=self._add_warning,
                remove_warning=self._remove_warning,
                notify=_notify,
            ),
            name=self.name,
        )

    async def stop(self) -> None:
        try:
            if self._stop_evt is not None:
                self._stop_evt.set()
        except (AttributeError, RuntimeError) as e:
            logger.detail(f"115 云盘健康检查停止事件设置失败（已忽略） - 原因={type(e).__name__}")

        t = self._task
        if not t:
            return
        try:
            await asyncio.wait_for(t, timeout=20.0)
        except asyncio.TimeoutError:
            try:
                t.cancel()
            except (RuntimeError, AttributeError) as e:
                logger.detail(f"115 云盘健康检查任务取消失败（已忽略） - 原因={type(e).__name__}")
        except (asyncio.CancelledError, RuntimeError) as e:
            logger.detail(f"115 云盘健康检查任务等待失败（已忽略） - 原因={type(e).__name__}")
