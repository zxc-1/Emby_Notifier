from __future__ import annotations

import logging
from core.logging import get_biz_logger_adapter
logger = get_biz_logger_adapter(__name__)

import asyncio

from core.task_registry import TaskRegistry
from settings.runtime import get_settings


class HotlistService:
    name = "hotlist_daemon"

    def __init__(self, *, registry: TaskRegistry) -> None:
        self._reg = registry
        self._stop_evt: asyncio.Event | None = None
        self._task: asyncio.Task | None = None

    async def start(self) -> None:
        s = get_settings()
        if not bool(getattr(s, "HOTLIST_ENABLED", False)):
            return

        from douban_hotlist.runtime import run_hotlist_daemon

        stop_evt = asyncio.Event()
        self._stop_evt = stop_evt
        self._task = await self._reg.create_task(
            run_hotlist_daemon(stop_evt=stop_evt, task_registry=self._reg),
            name=self.name,
        )

    async def stop(self) -> None:
        try:
            if self._stop_evt is not None:
                self._stop_evt.set()
        except (AttributeError, RuntimeError) as e:
            logger.detail(f"热榜服务停止事件设置失败（已忽略） - 原因={type(e).__name__}")

        t = self._task
        if not t:
            return
        try:
            await asyncio.wait_for(t, timeout=20.0)
        except asyncio.TimeoutError:
            try:
                t.cancel()
            except (RuntimeError, AttributeError) as e:
                logger.detail(f"热榜服务任务取消失败（已忽略） - 原因={type(e).__name__}")
        except (asyncio.CancelledError, RuntimeError) as e:
            logger.detail(f"热榜服务任务等待失败（已忽略） - 原因={type(e).__name__}")
