from __future__ import annotations

import asyncio
import time
from datetime import datetime, timezone
from typing import Any, Dict, Tuple

from core.logging import get_biz_logger_adapter
from core.task_registry import TaskRegistry
from settings.runtime import get_settings
from core.http import get_http_client
from core.env_utils import env_float

logger = get_biz_logger_adapter(__name__)


def _iso_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _short_err(e: Exception, limit: int = 220) -> str:
    try:
        msg = str(e)
    except Exception:
        msg = ""
    msg = (msg or "").replace("\n", " ").strip()
    if len(msg) > limit:
        msg = msg[:limit] + "…"
    return f"{type(e).__name__}:{msg}" if msg else type(e).__name__


async def _check_emby() -> Tuple[bool, str, int]:
    s = get_settings()
    base = str(getattr(s, "EMBY_BASE_URL", "") or "").strip().rstrip("/")
    api_key = str(getattr(s, "EMBY_API_KEY", "") or "").strip()
    if not base or not api_key:
        return False, "not_configured", 0

    url = f"{base}/Items/Counts"
    params = {"api_key": api_key}
    client = await get_http_client()
    t0 = time.monotonic()
    try:
        resp = await client.get(url, params=params, timeout=10.0)
        dt = int((time.monotonic() - t0) * 1000)
        if resp.status_code == 200:
            return True, "", dt
        return False, f"http_{resp.status_code}", dt
    except Exception as e:
        dt = int((time.monotonic() - t0) * 1000)
        return False, _short_err(e), dt


async def _check_telegram() -> Tuple[bool, str, int]:
    s = get_settings()
    token = str(getattr(s, "TG_BOT_TOKEN", "") or "").strip()
    if not token:
        return False, "not_configured", 0

    from integrations.telegram_client import tg_call_json

    t0 = time.monotonic()
    try:
        data = await tg_call_json("getMe", token=token, timeout=10.0, max_attempts=2, backoff=(0.0, 0.6))
        dt = int((time.monotonic() - t0) * 1000)
        if not data:
            return False, "no_response", dt
        if bool(data.get("ok")):
            return True, "", dt
        desc = str((data.get("description") or "")).strip()
        return False, desc or "not_ok", dt
    except Exception as e:
        dt = int((time.monotonic() - t0) * 1000)
        return False, _short_err(e), dt


async def _check_cloud115() -> Tuple[bool, str, int]:
    s = get_settings()
    cookie = str(getattr(s, "CLOUD115_COOKIE", "") or "").strip()
    if not cookie:
        return False, "not_configured", 0

    t0 = time.monotonic()
    try:
        from integrations.cloud115.health import _check_cookie_once  # type: ignore
        ok, err = await _check_cookie_once(timeout=6.0)
        dt = int((time.monotonic() - t0) * 1000)
        if ok:
            return True, "", dt
        return False, err or "unauthorized", dt
    except Exception as e:
        dt = int((time.monotonic() - t0) * 1000)
        return False, _short_err(e), dt


async def _check_mediahelp() -> Tuple[bool, str, int]:
    base = ""
    try:
        from forward_bridge.config import get_mediahelp_base
        base = str(get_mediahelp_base() or "").strip()
    except Exception:
        base = ""

    try:
        from forward_bridge.http_client import have_token, mh_request_json
    except Exception as e:
        return False, f"import_failed:{type(e).__name__}", 0

    if not base:
        return False, "not_configured", 0
    if not have_token():
        return False, "token_missing", 0

    t0 = time.monotonic()
    try:
        status, _data, err, _snip = await mh_request_json(
            "GET",
            "/api/v1/subscription/config/defaults",
            ctx="dashboard_health",
            timeout=12.0,
            with_auth=True,
            retry_on_401=False,
        )
        dt = int((time.monotonic() - t0) * 1000)
        if int(status) == 200:
            return True, "", dt
        if int(status) == 401:
            return False, "unauthorized", dt
        return False, err or f"http_{status}", dt
    except Exception as e:
        dt = int((time.monotonic() - t0) * 1000)
        return False, _short_err(e), dt


def _init_state(app: Any) -> None:
    try:
        if getattr(app.state, "dashboard_health", None) is None:
            app.state.dashboard_health = {"updated_at": "", "services": {}}
    except Exception as e:
        biz.detail("ignored exception in _init_state", exc_info=True)
        pass


def _update_service(state: Dict[str, Any], name: str, *, ok: bool, err: str, latency_ms: int, configured: bool) -> None:
    services = state.setdefault("services", {})
    cur = services.get(name) or {}
    fail_count = int(cur.get("fail_count") or 0)

    if not configured:
        services[name] = {
            "configured": False,
            "ok": False,
            "status": "not_configured",
            "error": "",
            "latency_ms": 0,
            "checked_at": _iso_now(),
            "fail_count": 0,
        }
        return

    if ok:
        services[name] = {
            "configured": True,
            "ok": True,
            "status": "ok",
            "error": "",
            "latency_ms": int(latency_ms or 0),
            "checked_at": _iso_now(),
            "fail_count": 0,
        }
        return

    services[name] = {
        "configured": True,
        "ok": False,
        "status": "fail",
        "error": str(err or "fail"),
        "latency_ms": int(latency_ms or 0),
        "checked_at": _iso_now(),
        "fail_count": fail_count + 1,
    }


async def run_once(app: Any) -> Dict[str, Any]:
    _init_state(app)
    state = getattr(app.state, "dashboard_health", {"services": {}})

    s = get_settings()
    emby_cfg = bool(str(getattr(s, "EMBY_BASE_URL", "") or "").strip() and str(getattr(s, "EMBY_API_KEY", "") or "").strip())
    tg_cfg = bool(str(getattr(s, "TG_BOT_TOKEN", "") or "").strip())
    c115_cfg = bool(str(getattr(s, "CLOUD115_COOKIE", "") or "").strip())

    ok, err, dt = await _check_emby()
    _update_service(state, "emby", ok=ok, err=err, latency_ms=dt, configured=emby_cfg)

    ok, err, dt = await _check_telegram()
    _update_service(state, "telegram", ok=ok, err=err, latency_ms=dt, configured=tg_cfg)

    ok, err, dt = await _check_cloud115()
    _update_service(state, "cloud115", ok=ok, err=err, latency_ms=dt, configured=c115_cfg)

    ok, err, dt = await _check_mediahelp()
    if err == "not_configured":
        _update_service(state, "mediahelp", ok=False, err="", latency_ms=0, configured=False)
    else:
        _update_service(state, "mediahelp", ok=ok, err=err, latency_ms=dt, configured=True)

    state["updated_at"] = _iso_now()
    try:
        app.state.dashboard_health = state
    except Exception as e:
        biz.detail("ignored exception in _update_service", exc_info=True)
        pass
    return state


class DashboardHealthService:
    name = "dashboard_health"

    def __init__(self, *, app: Any, registry: TaskRegistry, interval_sec: float = 60.0) -> None:
        self._app = app
        self._reg = registry
        self._interval = float(interval_sec or 60.0)
        self._stop_evt: asyncio.Event | None = None

    async def start(self) -> None:
        _init_state(self._app)

        # Optional runtime override via ENV (do not use os.getenv directly; keep config access consistent).
        try:
            self._interval = max(10.0, float(env_float("DASHBOARD_HEALTHCHECK_INTERVAL_SEC", float(self._interval))))
        except Exception as e:
            biz.detail("ignored exception in __init__", exc_info=True)
            pass

        stop_evt = asyncio.Event()
        self._stop_evt = stop_evt

        async def _loop() -> None:
            try:
                await run_once(self._app)
            except Exception:
                logger.detail("Dashboard 健康检查：首次执行失败（已忽略）", exc_info=True)

            while not stop_evt.is_set():
                try:
                    await asyncio.wait_for(stop_evt.wait(), timeout=self._interval)
                    break
                except asyncio.TimeoutError:
                    pass
                try:
                    await run_once(self._app)
                except Exception:
                    logger.detail("Dashboard 健康检查：执行失败（已忽略）", exc_info=True)

        await self._reg.create_task(_loop(), name="svc:dashboard_health")

    async def stop(self) -> None:
        try:
            if self._stop_evt is not None:
                self._stop_evt.set()
        except Exception as e:
            biz.detail("ignored exception in __init__", exc_info=True)
            pass
        return
