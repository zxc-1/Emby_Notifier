"""Backward compatibility layer for core.exceptions.

This module re-exports all symbols from core.exceptions.base for backward compatibility.
New code should import directly from core.exceptions.

Migration Guide:
    Old: from core.exceptions import AppException, NetworkError
    New: from core.exceptions import AppException, NetworkError
"""

import warnings

warnings.warn(
    "Importing from 'core.exceptions' is deprecated. "
    "Use 'from core.exceptions import ...' instead.",
    DeprecationWarning,
    stacklevel=2,
)

from core.exceptions.base import (
    AppException,
    NetworkError,
    DatabaseError,
    ValidationError,
    ConfigurationError,
    ExternalServiceError,
)

__all__ = [
    "AppException",
    "NetworkError",
    "DatabaseError",
    "ValidationError",
    "ConfigurationError",
    "ExternalServiceError",
]
