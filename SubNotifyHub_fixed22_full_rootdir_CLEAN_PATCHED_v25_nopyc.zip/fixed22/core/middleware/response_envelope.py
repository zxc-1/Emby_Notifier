from __future__ import annotations

import json
from typing import Any, Optional

from starlette.types import ASGIApp, Receive, Scope, Send

from core.logging import get_trace_id, set_trace_id


def _ensure_trace_id() -> str:
    tid = (get_trace_id() or "").strip()
    if tid:
        return tid
    # If request logging middleware did not set it (edge cases), set one here.
    import uuid
    tid = uuid.uuid4().hex
    try:
        set_trace_id(tid)
    except Exception:
        pass
    return tid


def _is_enveloped(payload: Any) -> bool:
    return isinstance(payload, dict) and ("success" in payload and ("data" in payload or "error" in payload))


def _wrap_payload(payload: Any, *, success: bool, trace_id: str, status_code: int) -> dict[str, Any]:
    if success:
        return {"success": True, "data": payload, "error": None, "trace_id": trace_id}
    # error: keep original payload as data when it's not dict/detail
    err_obj: dict[str, Any] = {"code": "error", "message": "request failed"}
    if isinstance(payload, dict):
        # FastAPI/Starlette typical: {"detail": "..."}
        msg = payload.get("message") or payload.get("detail") or payload.get("error")
        if msg:
            err_obj["message"] = str(msg)
        # allow passing error codes
        code = payload.get("code") or payload.get("error_code")
        if code:
            err_obj["code"] = str(code)
    elif isinstance(payload, str) and payload.strip():
        err_obj["message"] = payload.strip()
    return {"success": False, "data": None, "error": err_obj, "trace_id": trace_id, "status_code": status_code}


class ResponseEnvelopeMiddleware:
    """ASGI middleware: wrap JSON responses into a consistent envelope.

    Why ASGI middleware (not BaseHTTPMiddleware):
    - Avoid known BaseHTTPMiddleware edge cases with streaming responses.
    - Preserve multi-value headers (especially Set-Cookie).

    Behavior:
    - Only wraps JSON responses under /admin + /api (configurable).
    - Leaves already-enveloped payloads intact, but ensures trace_id exists.
    - Does NOT wrap streaming responses.
    """

    def __init__(self, app: ASGIApp, *, path_prefixes: Optional[tuple[str, ...]] = None) -> None:
        self.app = app
        self._prefixes = path_prefixes or ("/admin", "/api")

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope.get("type") != "http":
            await self.app(scope, receive, send)
            return

        path = str(scope.get("path") or "")
        if not any(path.startswith(p) for p in self._prefixes):
            await self.app(scope, receive, send)
            return

        started = False
        start_message: dict[str, Any] | None = None
        body_chunks: list[bytes] = []
        is_json = False
        is_streaming = False

        async def _send(message: dict[str, Any]) -> None:
            nonlocal started, start_message, is_json, is_streaming

            if message["type"] == "http.response.start":
                start_message = message
                started = True
                # Decide JSON-ness by headers
                hdrs = message.get("headers") or []
                for k, v in hdrs:
                    if k.lower() == b"content-type" and b"application/json" in (v or b"").lower():
                        is_json = True
                        break
                # Delay sending start until we know whether to wrap.
                return

            if message["type"] == "http.response.body":
                # If already detected streaming, passthrough without buffering/wrapping.
                if is_streaming:
                    if start_message is not None and not getattr(_send, "_sent_start", False):
                        setattr(_send, "_sent_start", True)
                        await send(start_message)
                    await send(message)
                    return
                # If not JSON, pass through as-is.
                if not is_json or start_message is None:
                    if start_message is not None and not getattr(_send, "_sent_start", False):
                        setattr(_send, "_sent_start", True)
                        await send(start_message)
                    await send(message)
                    return

                chunk: bytes = message.get("body") or b""
                more_body = bool(message.get("more_body"))

                # Detect streaming: any more_body means streaming-ish.
                if more_body:
                    is_streaming = True
                    # Passthrough streaming responses; preserve headers and avoid buffering to prevent duplicate chunks.
                    if start_message is not None and not getattr(_send, "_sent_start", False):
                        setattr(_send, "_sent_start", True)
                        await send(start_message)
                    # Flush any previously buffered chunks (edge case) then forward current chunk.
                    while body_chunks:
                        b = body_chunks.pop(0)
                        await send({"type": "http.response.body", "body": b, "more_body": True})
                    await send(message)
                    return

                # Buffer non-streaming JSON responses so we can wrap them at the end.
                body_chunks.append(chunk)
                if more_body:
                    # Not streaming yet, keep buffering.
                    return

                # Final body chunk received, wrap now.
                full_body = b"".join(body_chunks)
                body_chunks.clear()

                # Parse JSON; if invalid, pass through.
                try:
                    payload = json.loads(full_body.decode("utf-8")) if full_body else None
                except Exception:
                    if start_message is not None and not getattr(_send, "_sent_start", False):
                        setattr(_send, "_sent_start", True)
                        await send(start_message)
                    await send({"type": "http.response.body", "body": full_body, "more_body": False})
                    return

                status_code = int(start_message.get("status") or 200)
                trace_id = _ensure_trace_id()

                if _is_enveloped(payload):
                    if isinstance(payload, dict) and not payload.get("trace_id"):
                        payload["trace_id"] = trace_id
                    wrapped_payload = payload
                else:
                    ok = 200 <= status_code < 400
                    wrapped_payload = _wrap_payload(payload, success=ok, trace_id=trace_id, status_code=status_code)

                out_body = json.dumps(wrapped_payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")

                # Preserve multi-value headers (Set-Cookie) by keeping raw header list.
                orig_headers: list[tuple[bytes, bytes]] = list(start_message.get("headers") or [])
                # Keep original content-type if present; otherwise default.
                ct = None
                for k, v in orig_headers:
                    if k.lower() == b"content-type":
                        ct = v
                        break
                if ct is None:
                    ct = b"application/json"

                filtered: list[tuple[bytes, bytes]] = [
                    (k, v)
                    for (k, v) in orig_headers
                    if k.lower() not in (b"content-length", b"content-type")
                ]
                filtered.append((b"content-type", ct))
                filtered.append((b"content-length", str(len(out_body)).encode("ascii")))

                new_start = dict(start_message)
                new_start["headers"] = filtered

                setattr(_send, "_sent_start", True)
                await send(new_start)
                await send({"type": "http.response.body", "body": out_body, "more_body": False})
                return

            # Other ASGI messages
            if start_message is not None and not getattr(_send, "_sent_start", False):
                setattr(_send, "_sent_start", True)
                await send(start_message)
            await send(message)

        await self.app(scope, receive, _send)


def add_response_envelope_middleware(app) -> None:
    app.add_middleware(ResponseEnvelopeMiddleware)
