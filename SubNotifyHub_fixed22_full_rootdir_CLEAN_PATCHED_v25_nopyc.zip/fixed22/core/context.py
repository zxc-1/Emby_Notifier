from __future__ import annotations

"""Runtime context container.

This module intentionally avoids importing feature-layer packages
(e.g. notifier/tg_bot/api/admin) and integrations to prevent reverse
dependencies.

Ports are used for type hints so that call sites can remain decoupled from
concrete adapters.
"""

from collections import deque
from dataclasses import dataclass
from typing import Any, Awaitable, Callable, Optional

from ports.contracts import (
    DeduperPort,
    NotifierPort,
    PosterCachePort,
    RecentStorePort,
    WorkerPort,
)

from core.storage import BlobStore, KVStore
from ports.http_client import AsyncHttpClient
from ports.share115 import Share115Gateway
from ports.share_resolver_repo import ShareResolverRepo
from ports.tmdb import TmdbGateway
from ports.tmdb_matcher import TmdbMatcher

OnSentCallback = Callable[[Any], Awaitable[None]]
HandlerFunc = Callable[[Any], Awaitable[None]]


@dataclass
class AppContext:
    """Central container for mutable runtime state."""

    # --- required, stable core fields ---
    poster_cache: PosterCachePort
    recent_store: RecentStorePort
    kv_store: KVStore
    blob_store: BlobStore
    deduper: DeduperPort
    notifier: NotifierPort
    notifier_worker: WorkerPort
    notifier_handler: HandlerFunc
    on_sent: Optional[OnSentCallback]
    recent_display_max: int
    recent_notify_times: deque
    recent_notify_attempt_times: deque
    recent_webhook_times: deque

    # --- optional adapters (ports) ---
    http_client: AsyncHttpClient | None = None
    tmdb_gateway: TmdbGateway | None = None
    tmdb_matcher: TmdbMatcher | None = None
    share115_gateway: Share115Gateway | None = None
    share_resolver_repo: ShareResolverRepo | None = None

    # --- debug helpers ---
    notification_history: Optional[deque] = None
