from __future__ import annotations

"""Lightweight smoke test.

Usage:
  python -m core.smoke

This intentionally avoids network calls. It mainly checks that:
  - critical modules can be imported
  - settings can be loaded
  - key runtime initializers don't trigger import-time side effects
"""
import logging
from core.logging import get_biz_logger_adapter
logger = get_biz_logger_adapter(__name__)


import sys

from settings.runtime import get_settings

from .selfcheck import run_selfcheck


def main() -> int:
    try:
        run_selfcheck()
    except Exception as e:
        print(f"SELF CHECK FAILED: {e}")
        return 2

    try:
        s = get_settings()
        # Touch some commonly used fields to ensure pydantic is happy
        _ = getattr(s, "SERVER_NAME", None)
    except Exception as e:
        print(f"SETTINGS FAILED: {e}")
        return 3

    # Optional: init MediaHelp runtime lazily (should not crash)
    try:
        from forward_bridge.http_client import init_mediahelp_runtime

        init_mediahelp_runtime(load_disk=False, load_settings=True)
    except (ImportError, RuntimeError) as e:
        # Non-fatal: forward bridge might be disabled in some deployments.
        logger.detail(f"MediaHelp运行时初始化失败（已忽略） - 原因={type(e).__name__}")

    print(f"OK emby-notifier {s.APP_VERSION}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
