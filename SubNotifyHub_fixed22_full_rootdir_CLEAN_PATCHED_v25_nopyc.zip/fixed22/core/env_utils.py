from __future__ import annotations

"""Small helpers for parsing environment variables safely.

We intentionally treat empty strings / invalid values as "unset" and fall back
to the provided default, so that a mis-edited .env won't crash the app
at import/startup time.
"""
import logging

# IMPORTANT:
# This module must stay dependency-light.
# It is imported by core.logging during logging bootstrap.
# Therefore, DO NOT import core.logging here (it creates circular imports).
logger = logging.getLogger(__name__)


def _detail(msg: str, *args, **kwargs) -> None:
    """Best-effort debug logging.

    Our structured BizLoggerAdapter provides .detail(), but env_utils must not
    depend on it. We degrade gracefully to stdlib logging.
    """
    try:
        if hasattr(logger, "detail"):
            # type: ignore[attr-defined]
            logger.detail(msg, *args, **kwargs)
            return
        exc_info = bool(kwargs.pop("exc_info", False))
        logger.debug(msg, *args, exc_info=exc_info)
    except Exception:
        return


import os
from typing import Optional


def env_int(name: str, default: int, *, min_value: Optional[int] = None, max_value: Optional[int] = None) -> int:
    raw = ("" if name is None else (str(os.getenv(name, "")))).strip()
    if raw == "":
        v = int(default)
    else:
        try:
            v = int(raw)
        except (ValueError, TypeError) as e:
            _detail(
                "环境变量解析失败，使用默认值 - 变量名=%s, 原始值=%r, 默认值=%s, 原因=%s",
                name,
                raw,
                default,
                type(e).__name__,
            )
            v = int(default)
    if min_value is not None and v < min_value:
        v = int(min_value)
    if max_value is not None and v > max_value:
        v = int(max_value)
    return v


def env_float(name: str, default: float, *, min_value: Optional[float] = None, max_value: Optional[float] = None) -> float:
    raw = ("" if name is None else (str(os.getenv(name, "")))).strip()
    if raw == "":
        v = float(default)
    else:
        try:
            v = float(raw)
        except (ValueError, TypeError) as e:
            _detail(
                "环境变量解析失败，使用默认值 - 变量名=%s, 原始值=%r, 默认值=%s, 原因=%s",
                name,
                raw,
                default,
                type(e).__name__,
            )
            v = float(default)
    if min_value is not None and v < float(min_value):
        v = float(min_value)
    if max_value is not None and v > float(max_value):
        v = float(max_value)
    return v


# Truthy/falsy string sets for boolean parsing
_TRUTHY_VALUES = frozenset({"1", "true", "yes", "on"})
_FALSY_VALUES = frozenset({"0", "false", "no", "off", ""})


def env_bool(name: str, default: bool) -> bool:
    """Parse boolean from environment variable.

    Truthy values: '1', 'true', 'yes', 'on' (case-insensitive)
    Falsy values: '0', 'false', 'no', 'off', '' (case-insensitive)

    If the value is not recognized, returns the default without crashing.
    Invalid values are logged at DEBUG level.
    
    Note: If the environment variable is not set (None), returns the default.
    """
    raw_value = os.getenv(name)
    if raw_value is None:
        # Environment variable not set - return default
        return default
    raw = raw_value.strip().lower()
    if raw in _TRUTHY_VALUES:
        return True
    if raw in _FALSY_VALUES:
        return False
    # Unrecognized value - log at DEBUG and return default
    _detail("env_bool：unrecognized value %r for %s, using default %s", raw, name, default)
    return default


def env_str(name: str, default: str) -> str:
    """Get string from environment variable with fallback.

    Returns the environment variable value if set and non-empty,
    otherwise returns the default value.
    """
    raw = "" if name is None else os.getenv(name, "")
    if raw == "":
        return default
    return raw
