"""DEPRECATED: Use core.logging.logging_setup instead.

This module is maintained for backward compatibility only.
Please update your imports to use the new path:

    # Old (deprecated):
    from core.logging_setup import init_logging, log_ok, log_run

    # New (recommended):
    from core.logging import init_logging, log_ok, log_run
"""

from __future__ import annotations

import warnings

warnings.warn(
    "Importing from 'core.logging_setup' is deprecated. "
    "Use 'from core.logging import init_logging, log_ok, log_run' instead.",
    DeprecationWarning,
    stacklevel=2,
)

# Re-export everything from the new location for backward compatibility
from core.logging.logging_setup import (
    init_logging,
    log_ok,
    log_run,
    log_fetch,
    BizTextFormatter,
    JsonLineFormatter,
    get_kind_colors,
    ContextKindFilter,
    ContextTraceFilter,
    ContextFlowFilter,
    ContextSpanFilter,
    ContextIndentFilter,
    AutoKVFilter,
    MaxLevelFilter,
    MinLevelFilter,
    # Internal symbols for test compatibility
    _ANSI,
    _KIND_COLORS,
    _format_ts,
    _format_kv,
    _clip,
    _wants_color,
    _env_flag,
    _style,
    _file_format,
    _load_color_scheme,
)

__all__ = [
    "init_logging",
    "log_ok",
    "log_run",
    "log_fetch",
    "BizTextFormatter",
    "JsonLineFormatter",
    "get_kind_colors",
    "ContextKindFilter",
    "ContextTraceFilter",
    "ContextFlowFilter",
    "ContextSpanFilter",
    "ContextIndentFilter",
    "AutoKVFilter",
    "MaxLevelFilter",
    "MinLevelFilter",
    # Internal symbols (for backward compatibility only)
    "_ANSI",
    "_KIND_COLORS",
    "_format_ts",
    "_format_kv",
    "_clip",
    "_wants_color",
    "_env_flag",
    "_style",
    "_file_format",
    "_load_color_scheme",
]
