from __future__ import annotations

import logging
from core.logging import get_biz_logger_adapter
logger = get_biz_logger_adapter(__name__)

from collections import defaultdict
from threading import Lock
from typing import Dict, Any, Mapping, Optional, Tuple
import math


# Prometheus label set (sorted tuples for stable hashing)
LabelSet = Tuple[Tuple[str, str], ...]


def _norm_labels(labels: Optional[Mapping[str, object]] = None) -> LabelSet:
    if not labels:
        return ()
    items: list[tuple[str, str]] = []
    for k, v in labels.items():
        kk = str(k or "").strip()
        if not kk:
            continue
        items.append((kk, str(v).strip()))
    items.sort(key=lambda x: x[0])
    return tuple(items)


def _render_labels(labels: LabelSet) -> str:
    if not labels:
        return ""
    # Prometheus text format: name{key="value",...}
    parts: list[str] = []
    for k, v in labels:
        vv = str(v).replace("\\", "\\\\").replace('"', '\\"').replace("\n", "\\n")
        parts.append(f"{k}=\"{vv}\"")
    return "{" + ",".join(parts) + "}"


class Metrics:
    """
    超轻量的内存指标收集器：
    - counters: 计数器，用 inc() 自增
    - gauges:   仪表盘，用 set_gauge() 设置当前值
    - hists:    极简观测值统计，用 observe() 记录 count/sum/max（用于时延等）
    仅用于 /health 里做简单观测，不依赖任何第三方库。
    """

    def __init__(self) -> None:
        # key = (name, labels)
        self._counters: Dict[tuple[str, LabelSet], int] = defaultdict(int)
        self._gauges: Dict[tuple[str, LabelSet], float] = {}
        self._hists: Dict[tuple[str, LabelSet], Dict[str, float]] = {}
        self._lock = Lock()

    def inc(self, name: str, value: int = 1, *, labels: Optional[Mapping[str, object]] = None) -> None:
        with self._lock:
            key = (str(name or "").strip(), _norm_labels(labels))
            self._counters[key] += int(value or 0)

    def set_gauge(self, name: str, value: float, *, labels: Optional[Mapping[str, object]] = None) -> None:
        with self._lock:
            key = (str(name or "").strip(), _norm_labels(labels))
            self._gauges[key] = float(value)

    def observe(self, name: str, value: float, *, labels: Optional[Mapping[str, object]] = None) -> None:
        """Record an observed value.

        We store minimal aggregate stats:
        - <name>_count
        - <name>_sum
        - <name>_max

        This keeps deps at zero but still makes latency regressions observable.
        """
        try:
            v = float(value)
        except (ValueError, TypeError) as e:
            logger.detail(f"指标观测值转换失败（已忽略） - 指标名={name}, 输入值={value!r}, 原因={type(e).__name__}")
            return
        if math.isnan(v) or math.isinf(v):
            return
        with self._lock:
            key = (str(name or "").strip(), _norm_labels(labels))
            h = self._hists.get(key)
            if h is None:
                h = {"count": 0.0, "sum": 0.0, "max": v}
                self._hists[key] = h
            h["count"] = float(h.get("count", 0.0)) + 1.0
            h["sum"] = float(h.get("sum", 0.0)) + v
            prev_max = float(h.get("max", v))
            h["max"] = v if v > prev_max else prev_max

    def snapshot(self) -> Dict[str, Any]:
        # 拷贝一份，避免外部修改内部状态
        with self._lock:
            return {
                "counters": {f"{k[0]}{_render_labels(k[1])}": int(v) for k, v in self._counters.items()},
                "gauges": {f"{k[0]}{_render_labels(k[1])}": float(v) for k, v in self._gauges.items()},
                "hists": {f"{k[0]}{_render_labels(k[1])}": dict(v) for k, v in self._hists.items()},
            }

    def export_prometheus(self) -> str:
        """
        导出成 Prometheus 文本格式（极简版）：

        counter 统一追加 `_total` 后缀
        gauge 原名输出，形如：

            enqueue_success_total 123
            enqueue_dropped_full_total 4
            queue_length 7
        """
        lines: list[str] = []
        with self._lock:
            # counters
            for (name, labels), value in self._counters.items():
                metric_name = name if name.endswith("_total") else f"{name}_total"
                lines.append(f"{metric_name}{_render_labels(labels)} {float(value)}")

            # gauges
            for (name, labels), value in self._gauges.items():
                lines.append(f"{name}{_render_labels(labels)} {float(value)}")

            # hists (count/sum/max)
            for (name, labels), h in self._hists.items():
                try:
                    lab = _render_labels(labels)
                    lines.append(f"{name}_count{lab} {float(h.get('count', 0.0))}")
                    lines.append(f"{name}_sum{lab} {float(h.get('sum', 0.0))}")
                    lines.append(f"{name}_max{lab} {float(h.get('max', 0.0))}")
                except (ValueError, TypeError, KeyError) as e:
                    # do not break export
                    logger.detail(f"指标导出失败（已跳过） - 指标名={name}, 原因={type(e).__name__}")
                    continue

        return "\n".join(lines) + "\n"


metrics = Metrics()