"""Backward compatibility layer for core.plugin_api.

This module re-exports all symbols from core.plugins.api for backward compatibility.
New code should import directly from core.plugins.

Migration Guide:
    Old: from core.plugins import PLUGIN_API_VERSION
    New: from core.plugins import PLUGIN_API_VERSION
"""

import warnings

warnings.warn(
    "Importing from 'core.plugin_api' is deprecated. "
    "Use 'from core.plugins import PLUGIN_API_VERSION' instead.",
    DeprecationWarning,
    stacklevel=2,
)

from core.plugins.api import (
    PLUGIN_API_VERSION,
)

__all__ = [
    "PLUGIN_API_VERSION",
]
