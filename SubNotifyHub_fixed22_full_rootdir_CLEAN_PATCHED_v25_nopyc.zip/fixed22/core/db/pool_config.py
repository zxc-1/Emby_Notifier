from __future__ import annotations
from core.exceptions.base import ValidationError

"""
连接池配置模块

支持通过环境变量覆盖默认配置:
- DB_POOL_MIN_SIZE: 最小连接数 (默认: 2)
- DB_POOL_MAX_SIZE: 最大连接数 (默认: 20)
- DB_POOL_MAX_IDLE_TIME: 空闲连接最大存活时间秒 (默认: 300)
- DB_POOL_TIMEOUT: 获取连接超时秒 (默认: 30)
- DB_POOL_HEALTH_CHECK_INTERVAL: 健康检查间隔秒 (默认: 60)
"""


from core.env_utils import env_float, env_int
from dataclasses import dataclass
from typing import Optional

from core.logging import get_biz_logger

biz = get_biz_logger("core.db.pool_config")


@dataclass(frozen=True)
class PoolConfig:
    """连接池配置"""

    min_size: int = 2  # 最小连接数
    max_size: int = 20  # 最大连接数（增加以支持并发）
    max_idle_time: float = 300.0  # 空闲连接最大存活时间（秒）
    connection_timeout: float = 30.0  # 获取连接超时（秒）
    health_check_interval: float = 60.0  # 健康检查间隔（秒）

    def __post_init__(self) -> None:
        """验证配置参数"""
        if self.min_size < 0:
            raise ValidationError(f"min_size must be >= 0, got {self.min_size}")
        if self.max_size < 1:
            raise ValidationError(f"max_size must be >= 1, got {self.max_size}")
        if self.min_size > self.max_size:
            raise ValidationError(
                f"min_size ({self.min_size}) cannot exceed max_size ({self.max_size})"
            )
        if self.max_idle_time <= 0:
            raise ValidationError(f"max_idle_time must be > 0, got {self.max_idle_time}")
        if self.connection_timeout <= 0:
            raise ValidationError(
                f"connection_timeout must be > 0, got {self.connection_timeout}"
            )

    @classmethod
    def from_env(cls) -> PoolConfig:
        """从环境变量加载配置，无效值回退到默认值"""
        defaults = cls()

        # Parse env using shared helpers (treat empty/invalid as default)
        min_size = env_int("DB_POOL_MIN_SIZE", defaults.min_size, min_value=0)
        max_size = env_int("DB_POOL_MAX_SIZE", defaults.max_size, min_value=1)
        max_idle_time = env_float("DB_POOL_MAX_IDLE_TIME", defaults.max_idle_time, min_value=0.000_001)
        connection_timeout = env_float("DB_POOL_TIMEOUT", defaults.connection_timeout, min_value=0.000_001)
        health_check_interval = env_float("DB_POOL_HEALTH_CHECK_INTERVAL", defaults.health_check_interval, min_value=0.000_001)

        # 验证配置，无效时回退到默认值
        try:
            return cls(
                min_size=min_size,
                max_size=max_size,
                max_idle_time=max_idle_time,
                connection_timeout=connection_timeout,
                health_check_interval=health_check_interval,
            )
        except (ValidationError, ValueError) as e:
            biz.warning(
                "数据库连接池配置验证失败，将使用默认配置",
                stage="db_pool",
                err=type(e).__name__,
                reason=str(e)[:200],
                exc_info=True,
            )
            return defaults
