from __future__ import annotations

from core.exceptions.base import ConfigurationError

"""
同步 SQLite 连接池

线程安全的连接池实现，支持连接复用、健康检查和优雅关闭。
"""


import sqlite3
import threading
import time
from contextlib import contextmanager
from queue import Empty, Queue
from typing import Any, Generator, Optional

from core.exceptions.base import DatabaseError
from core.logging import get_biz_logger
from core.db.pool_config import PoolConfig

biz = get_biz_logger("core.db.sync_pool")


class SyncConnectionPool:
    """线程安全的同步 SQLite 连接池"""

    def __init__(self, db_path: str, config: Optional[PoolConfig] = None):
        """
        初始化连接池

        Args:
            db_path: 数据库文件路径
            config: 连接池配置，None 时使用默认配置
        """
        self._db_path = db_path
        self._config = config or PoolConfig()
        self._pool: Queue[tuple[sqlite3.Connection, float]] = Queue()
        self._lock = threading.Lock()
        self._active_count = 0
        # sqlite3.Connection does NOT support weak references on CPython.
        # Track by id(conn) to avoid strong-referencing connections and to
        # prevent `TypeError: cannot create weak reference ...`.
        self._in_use: set[int] = set()
        self._total_created = 0
        self._total_reused = 0
        self._closed = False

        # 预创建最小连接数
        for _ in range(self._config.min_size):
            conn = self._create_connection()
            self._pool.put((conn, time.time()))

        biz.detail(
            f"同步连接池已初始化：{db_path}，预创建 {self._config.min_size} 个连接",
            db_path=db_path,
            min_size=self._config.min_size,
            max_size=self._config.max_size,
        )

    def _create_connection(self) -> sqlite3.Connection:
        """创建新连接"""
        # 检查是否是 URI 格式（用于内存数据库等）
        is_uri = self._db_path.startswith("file:")
        conn = sqlite3.connect(
            self._db_path,
            check_same_thread=False,
            timeout=self._config.connection_timeout,
            uri=is_uri,
        )
        # 设置 pragmas
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA synchronous=NORMAL;")
        conn.execute("PRAGMA foreign_keys=ON;")
        conn.execute(
            f"PRAGMA busy_timeout={int(self._config.connection_timeout * 1000)};"
        )

        with self._lock:
            self._total_created += 1

        biz.detail(
            f"创建新数据库连接：{self._db_path}，累计已创建 {self._total_created} 个",
            db_path=self._db_path,
            total_created=self._total_created,
        )
        return conn

    def _is_healthy(self, conn: sqlite3.Connection) -> bool:
        """检查连接是否健康"""
        try:
            conn.execute("SELECT 1").fetchone()
            return True
        except sqlite3.Error as e:
            biz.detail(f"连接健康检查失败：{e}")
            return False

    def acquire(self, timeout: Optional[float] = None) -> sqlite3.Connection:
        """
        获取连接

        Args:
            timeout: 等待超时时间（秒），None 时使用配置的 connection_timeout

        Returns:
            数据库连接

        Raises:
            RuntimeError: 池已关闭或等待超时
        """
        if self._closed:
            raise ConfigurationError("Pool is closed")

        wait_timeout = timeout if timeout is not None else self._config.connection_timeout
        deadline = time.time() + wait_timeout

        while True:
            # 尝试从池中获取
            while True:
                try:
                    conn, created_at = self._pool.get_nowait()
                    # 检查是否过期
                    if time.time() - created_at > self._config.max_idle_time:
                        biz.detail("连接已过期，关闭并丢弃")
                        try:
                            conn.close()
                        except (RuntimeError, ValueError, OSError):
                            pass
                        continue
                    # 健康检查
                    if not self._is_healthy(conn):
                        biz.detail("连接健康检查失败，关闭并丢弃")
                        try:
                            conn.close()
                        except (RuntimeError, ValueError, OSError):
                            pass
                        continue
                    with self._lock:
                        self._active_count += 1
                        self._total_reused += 1
                        self._in_use.add(id(conn))
                    return conn
                except Empty:
                    break

            # 尝试创建新连接
            can_create = False
            with self._lock:
                if self._active_count < self._config.max_size:
                    # 预留位置
                    self._active_count += 1
                    can_create = True

            if can_create:
                try:
                    conn = self._create_connection()
                    with self._lock:
                        self._in_use.add(id(conn))
                    return conn
                except Exception:
                    with self._lock:
                        self._active_count -= 1
                    raise

            # 池已满，检查是否超时
            remaining = deadline - time.time()
            if remaining <= 0:
                biz.warning(
                    f"同步连接池已耗尽且等待超时：当前活跃 {self._active_count}/{self._config.max_size}，等待 {wait_timeout} 秒后仍无可用连接",
                    active=self._active_count,
                    max_size=self._config.max_size,
                    db_path=self._db_path,
                    timeout=wait_timeout,
                )
                raise DatabaseError(
                    f"Pool exhausted: {self._active_count}/{self._config.max_size} (timeout={wait_timeout}s)"
                )

            # 等待连接释放（最多等待 0.1 秒或剩余时间）
            wait_time = min(0.1, remaining)
            try:
                conn, created_at = self._pool.get(timeout=wait_time)
                # 检查连接有效性
                if time.time() - created_at > self._config.max_idle_time:
                    try:
                        conn.close()
                    except (RuntimeError, ValueError, OSError):
                        pass
                    continue
                if not self._is_healthy(conn):
                    try:
                        conn.close()
                    except (RuntimeError, ValueError, OSError):
                        pass
                    continue
                with self._lock:
                    self._active_count += 1
                    self._total_reused += 1
                    self._in_use.add(id(conn))
                return conn
            except Empty:
                # 继续循环等待
                continue

    def release(self, conn: sqlite3.Connection, *, discard: bool = False) -> None:
        """
        释放连接回池

        Args:
            conn: 要释放的连接
            discard: 是否丢弃连接（不放回池中）
        """
        with self._lock:
            if id(conn) not in self._in_use:
                # Avoid corrupting pool counters / duplicating connections.
                # This can happen on double-release or when an external connection is passed in.
                biz.warning(
                    "⚠️ 连接释放异常：连接不在使用中（可能重复释放或外部连接）",
                    db_path=self._db_path,
                    active=self._active_count,
                )
                try:
                    conn.close()
                except (RuntimeError, ValueError, OSError):
                    pass
                return
            self._in_use.discard(id(conn))
            self._active_count = max(0, self._active_count - 1)

        if discard or self._closed:
            try:
                conn.close()
            except (RuntimeError, ValueError, OSError):
                pass
            return

        # 检查池是否已满
        if self._pool.qsize() >= self._config.max_size:
            try:
                conn.close()
            except (RuntimeError, ValueError, OSError):
                pass
            return

        self._pool.put((conn, time.time()))

    @contextmanager
    def connection(
        self, *, auto_commit: bool = True
    ) -> Generator[sqlite3.Connection, None, None]:
        """
        上下文管理器获取连接

        Args:
            auto_commit: 是否在正常退出时自动提交事务

        Yields:
            数据库连接

        Example:
            with pool.connection() as conn:
                conn.execute("INSERT INTO ...")
        """
        conn = self.acquire()
        discard = False
        try:
            yield conn
            if auto_commit:
                conn.commit()
        except Exception:
            try:
                conn.rollback()
            except (RuntimeError, ValueError, OSError):
                pass
            discard = True
            raise
        finally:
            self.release(conn, discard=discard)

    def close(self, timeout: float = 5.0) -> None:
        """
        关闭连接池

        Args:
            timeout: 等待活跃连接释放的超时时间（秒）
        """
        self._closed = True
        deadline = time.time() + timeout

        # 等待活跃连接释放
        while self._active_count > 0 and time.time() < deadline:
            time.sleep(0.1)

        if self._active_count > 0:
            biz.warning(
                f"关闭同步连接池时仍有 {self._active_count} 个活跃连接未释放，可能存在连接泄漏",
                active=self._active_count,
                db_path=self._db_path,
            )

        # 关闭池中所有连接
        closed_count = 0
        while True:
            try:
                conn, _ = self._pool.get_nowait()
                try:
                    conn.close()
                    closed_count += 1
                except (RuntimeError, ValueError, OSError):
                    pass
            except Empty:
                break

        biz.detail(
            f"同步连接池已关闭：{self._db_path}，共关闭 {closed_count} 个空闲连接",
            closed_connections=closed_count,
            db_path=self._db_path,
        )

    @property
    def stats(self) -> dict[str, Any]:
        """获取池统计信息"""
        return {
            "active": self._active_count,
            "idle": self._pool.qsize(),
            "total_created": self._total_created,
            "total_reused": self._total_reused,
            "db_path": self._db_path,
        }

    @property
    def is_closed(self) -> bool:
        """池是否已关闭"""
        return self._closed
