"""
数据库连接池模块

提供同步和异步 SQLite 连接池，支持连接复用、健康检查和优雅关闭。

注意：
- 异步连接池依赖 aiosqlite。若运行环境未安装 aiosqlite，导入 core.db 仍应可用（同步池可用），
  但调用 get_async_pool() / AsyncConnectionPool 将抛出可读错误。
"""

from __future__ import annotations

from core.db.pool_config import PoolConfig
from core.db.sync_pool import SyncConnectionPool
from core.db.pool_manager import (
    get_sync_pool,
    get_async_pool,
    close_all_pools,
    close_all_async_pools,
    get_all_pool_stats,
)

try:  # pragma: no cover
    from core.db.async_pool import AsyncConnectionPool  # type: ignore
except ModuleNotFoundError:  # pragma: no cover
    AsyncConnectionPool = None  # type: ignore

__all__ = [
    "PoolConfig",
    "SyncConnectionPool",
    "get_sync_pool",
    "get_async_pool",
    "close_all_pools",
    "close_all_async_pools",
    "get_all_pool_stats",
]

if AsyncConnectionPool is not None:
    __all__.append("AsyncConnectionPool")
