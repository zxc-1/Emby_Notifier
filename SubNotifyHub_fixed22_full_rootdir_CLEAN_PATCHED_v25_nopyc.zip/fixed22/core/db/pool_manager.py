"""
全局连接池管理器

提供连接池的全局管理，支持获取、关闭和统计功能。
"""

from __future__ import annotations

import threading
from typing import Any, Optional, TYPE_CHECKING

from core.logging import get_biz_logger
from core.db.pool_config import PoolConfig
from core.db.sync_pool import SyncConnectionPool
from core.exceptions.base import ConfigurationError

biz = get_biz_logger("core.db.pool_manager")

# 全局池字典
_sync_pools: dict[str, SyncConnectionPool] = {}
_async_pools: dict[str, Any] = {}
_lock = threading.Lock()


def get_sync_pool(
    db_path: str, config: Optional[PoolConfig] = None
) -> SyncConnectionPool:
    """
    获取或创建同步连接池

    Args:
        db_path: 数据库文件路径
        config: 连接池配置，None 时从环境变量加载

    Returns:
        同步连接池实例
    """
    with _lock:
        if db_path not in _sync_pools:
            cfg = config or PoolConfig.from_env()
            _sync_pools[db_path] = SyncConnectionPool(db_path, cfg)
            biz.ok(
                f"同步连接池已创建：数据库 {db_path}，最小连接数 {cfg.min_size}，最大连接数 {cfg.max_size}",
                db_path=db_path,
                min_size=cfg.min_size,
                max_size=cfg.max_size,
            )
        return _sync_pools[db_path]


def get_async_pool(
    db_path: str,
    config: Optional[PoolConfig] = None,
) -> Any:
    """
    获取或创建异步连接池

    Args:
        db_path: 数据库文件路径
        config: 连接池配置，None 时从环境变量加载

    Returns:
        异步连接池实例
    """
    with _lock:
        if db_path not in _async_pools:
            cfg = config or PoolConfig.from_env()
            try:
                from core.db.async_pool import AsyncConnectionPool
            except Exception as e:
                raise ConfigurationError(
                    "aiosqlite/异步连接池依赖未就绪，无法创建异步连接池",
                    cause=e,
                    context={"db_path": db_path},
                )
            _async_pools[db_path] = AsyncConnectionPool(db_path, cfg)
            biz.ok(
                f"异步连接池已创建：数据库 {db_path}，最小连接数 {cfg.min_size}，最大连接数 {cfg.max_size}",
                db_path=db_path,
                min_size=cfg.min_size,
                max_size=cfg.max_size,
            )
        return _async_pools[db_path]


def close_all_pools(timeout: float = 5.0) -> None:
    """
    关闭所有同步连接池

    Args:
        timeout: 每个池的关闭超时时间（秒）
    """
    with _lock:
        for db_path, pool in list(_sync_pools.items()):
            try:
                pool.close(timeout=timeout)
                biz.ok(f"同步连接池已关闭：{db_path}，所有连接已释放", db_path=db_path)
            except Exception as e:
                biz.fail(f"关闭同步连接池失败：{db_path}，原因：{e}", db_path=db_path, exc=e)
        _sync_pools.clear()


async def close_all_async_pools(timeout: float = 5.0) -> None:
    """
    关闭所有异步连接池

    Args:
        timeout: 每个池的关闭超时时间（秒）
    """
    pools_to_close = list(_async_pools.items())
    for db_path, pool in pools_to_close:
        try:
            await pool.close(timeout=timeout)
            biz.ok(f"异步连接池已关闭：{db_path}，所有连接已释放", db_path=db_path)
        except Exception as e:
            biz.fail(f"关闭异步连接池失败：{db_path}，原因：{e}", db_path=db_path, exc=e)
    
    with _lock:
        _async_pools.clear()


def get_all_pool_stats() -> dict[str, Any]:
    """
    获取所有连接池的统计信息

    Returns:
        包含所有池统计信息的字典
    """
    stats: dict[str, Any] = {
        "sync_pools": {},
        "async_pools": {},
        "summary": {
            "total_sync_pools": 0,
            "total_async_pools": 0,
            "total_active_connections": 0,
            "total_idle_connections": 0,
        },
    }

    with _lock:
        for db_path, pool in _sync_pools.items():
            pool_stats = pool.stats
            stats["sync_pools"][db_path] = pool_stats
            stats["summary"]["total_active_connections"] += pool_stats["active"]
            stats["summary"]["total_idle_connections"] += pool_stats["idle"]
        stats["summary"]["total_sync_pools"] = len(_sync_pools)

        for db_path, pool in _async_pools.items():
            pool_stats = pool.stats
            stats["async_pools"][db_path] = pool_stats
            stats["summary"]["total_active_connections"] += pool_stats["active"]
            stats["summary"]["total_idle_connections"] += pool_stats["idle"]
        stats["summary"]["total_async_pools"] = len(_async_pools)

    return stats


def remove_sync_pool(db_path: str, close: bool = True, timeout: float = 5.0) -> bool:
    """
    移除指定的同步连接池

    Args:
        db_path: 数据库文件路径
        close: 是否关闭池
        timeout: 关闭超时时间

    Returns:
        是否成功移除
    """
    with _lock:
        if db_path not in _sync_pools:
            return False
        pool = _sync_pools.pop(db_path)
        if close:
            try:
                pool.close(timeout=timeout)
            except Exception as e:
                biz.fail(f"关闭同步连接池失败：{db_path}，原因：{e}", db_path=db_path, exc=e)
        return True


async def remove_async_pool(
    db_path: str, close: bool = True, timeout: float = 5.0
) -> bool:
    """
    移除指定的异步连接池

    Args:
        db_path: 数据库文件路径
        close: 是否关闭池
        timeout: 关闭超时时间

    Returns:
        是否成功移除
    """
    with _lock:
        if db_path not in _async_pools:
            return False
        pool = _async_pools.pop(db_path)
    
    if close:
        try:
            await pool.close(timeout=timeout)
        except Exception as e:
            biz.fail(f"关闭异步连接池失败：{db_path}，原因：{e}", db_path=db_path, exc=e)
    return True
