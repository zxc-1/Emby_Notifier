"""Backward compatibility layer for core.exception_mapping.

This module re-exports all symbols from core.exceptions.mapping for backward compatibility.
New code should import directly from core.exceptions.

Migration Guide:
    Old: from core.exceptions import map_exception, get_exception_category
    New: from core.exceptions import map_exception, get_exception_category
"""

import warnings

warnings.warn(
    "Importing from 'core.exception_mapping' is deprecated. "
    "Use 'from core.exceptions import map_exception, get_exception_category' instead.",
    DeprecationWarning,
    stacklevel=2,
)

from core.exceptions.mapping import (
    EXCEPTION_MAPPING,
    map_exception,
    get_exception_category,
)

__all__ = [
    "EXCEPTION_MAPPING",
    "map_exception",
    "get_exception_category",
]
