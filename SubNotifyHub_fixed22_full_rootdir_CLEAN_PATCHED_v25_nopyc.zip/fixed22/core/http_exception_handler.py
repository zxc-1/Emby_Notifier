"""DEPRECATED: Use core.http.exception_handler instead.

This module is maintained for backward compatibility only.
Please update your imports to use the new path:

    # Old (deprecated):
    from core.http_exception_handler import is_retryable_http_exception, HttpRetryStrategy

    # New (recommended):
    from core.http import is_retryable_http_exception, HttpRetryStrategy
"""

from __future__ import annotations

import warnings

warnings.warn(
    "Importing from 'core.http_exception_handler' is deprecated. "
    "Use 'from core.http import is_retryable_http_exception, HttpRetryStrategy' instead.",
    DeprecationWarning,
    stacklevel=2,
)

# Re-export everything from the new location for backward compatibility
from core.http.exception_handler import (
    # Exception type checking
    is_retryable_http_exception,
    is_client_error,
    is_server_error,
    is_timeout_error,
    is_connection_error,
    # Exception type tuples
    RETRYABLE_HTTP_EXCEPTIONS,
    NON_RETRYABLE_HTTP_EXCEPTIONS,
    # Retry strategy
    HttpRetryStrategy,
    with_http_retry,
    # Context managers
    http_safe_context,
    async_http_safe_context,
)

__all__ = [
    # Exception type checking
    "is_retryable_http_exception",
    "is_client_error",
    "is_server_error",
    "is_timeout_error",
    "is_connection_error",
    # Exception type tuples
    "RETRYABLE_HTTP_EXCEPTIONS",
    "NON_RETRYABLE_HTTP_EXCEPTIONS",
    # Retry strategy
    "HttpRetryStrategy",
    "with_http_retry",
    # Context managers
    "http_safe_context",
    "async_http_safe_context",
]
