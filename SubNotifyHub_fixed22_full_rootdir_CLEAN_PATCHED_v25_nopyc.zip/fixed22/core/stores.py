"""Backward compatibility layer for core.stores.

This module re-exports all symbols from core.storage.blob_store for backward compatibility.
New code should import directly from core.storage.

Migration Guide:
    Old: from core.storage import BlobStore, get_kv_store
    New: from core.storage import BlobStore, get_kv_store
"""

import warnings

warnings.warn(
    "Importing from 'core.stores' is deprecated. "
    "Use 'from core.storage import ...' instead.",
    DeprecationWarning,
    stacklevel=2,
)

from core.storage.blob_store import (
    KVStore,
    BlobStore,
    DedupStore,
    SQLiteKVStore,
    MemoryKVStore,
    FSBlobStore,
    KVBackedDedupStore,
    get_kv_store,
    get_blob_store,
)

__all__ = [
    "KVStore",
    "BlobStore",
    "DedupStore",
    "SQLiteKVStore",
    "MemoryKVStore",
    "FSBlobStore",
    "KVBackedDedupStore",
    "get_kv_store",
    "get_blob_store",
]
