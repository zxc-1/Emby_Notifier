from __future__ import annotations

import logging
from core.logging import get_biz_logger_adapter
logger = get_biz_logger_adapter(__name__)

import asyncio
import time
import weakref
from typing import Optional

from settings.runtime import get_settings


class AsyncRateLimiter:
    """A simple global min-interval limiter (not token bucket).

    Useful for APIs like Telegram where bursts can trigger 429.
    """

    def __init__(self, min_interval_ms: int) -> None:
        self.min_interval = max(0.0, float(min_interval_ms) / 1000.0)
        # NOTE: asyncio.Lock is bound to the loop it was created in.
        # This limiter may be cached process-wide (e.g. get_telegram_limiter),
        # so keep per-loop locks to avoid cross-loop crashes under reload/tests.
        self._locks: "weakref.WeakKeyDictionary[asyncio.AbstractEventLoop, asyncio.Lock]" = weakref.WeakKeyDictionary()
        self._last: float = 0.0

    def _get_lock(self) -> asyncio.Lock:
        loop = asyncio.get_running_loop()
        lk = self._locks.get(loop)
        if lk is None:
            lk = asyncio.Lock()
            self._locks[loop] = lk
        return lk

    async def wait(self) -> None:
        if self.min_interval <= 0:
            return
        async with self._get_lock():
            now = time.monotonic()
            due = self._last + self.min_interval
            if due > now:
                await asyncio.sleep(due - now)
            self._last = time.monotonic()


_telegram_limiter: Optional[AsyncRateLimiter] = None
_telegram_limiter_min_ms: Optional[int] = None


def get_telegram_limiter() -> AsyncRateLimiter:
    """Get a process-wide Telegram rate limiter.

    Note: settings may be reloaded at runtime; if TG_RATE_LIMIT_MS changes,
    we update the existing limiter in-place so the admin panel reload takes effect.
    """
    global _telegram_limiter, _telegram_limiter_min_ms
    s = get_settings()
    # Default: 80ms between calls (~12.5 rps), tune with TG_RATE_LIMIT_MS
    try:
        min_ms = int(getattr(s, "TG_RATE_LIMIT_MS", 80) or 0)
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"速率限制配置解析失败，使用默认值 - 配置项=TG_RATE_LIMIT_MS, 默认值=80ms, 原因={type(e).__name__}")
        min_ms = 80

    if _telegram_limiter is None:
        _telegram_limiter = AsyncRateLimiter(min_ms)
        _telegram_limiter_min_ms = int(min_ms)
        return _telegram_limiter

    if _telegram_limiter_min_ms != int(min_ms):
        try:
            _telegram_limiter.min_interval = max(0.0, float(min_ms) / 1000.0)
        except (ValueError, TypeError) as e:
            logger.detail(f"速率限制更新失败（已忽略） - 新值={min_ms}ms, 原因={type(e).__name__}")
        _telegram_limiter_min_ms = int(min_ms)

    return _telegram_limiter
