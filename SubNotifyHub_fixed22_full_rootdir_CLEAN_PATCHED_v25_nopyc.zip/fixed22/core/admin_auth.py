from __future__ import annotations

from core.exceptions.base import ConfigurationError

import hashlib
import logging
from core.logging import get_biz_logger
import hmac
import json
import os
import secrets
import tempfile
from typing import Optional, Tuple

from settings.runtime import get_settings


biz = get_biz_logger(__name__)

def generate_random_password(length: int = 8) -> str:
    """Generate an admin password (avoid confusing glyphs like O/0, l/1)."""
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789"
    return "".join(secrets.choice(alphabet) for _ in range(length))


def _get_legacy_salt() -> str:
    """Legacy salt source (kept for backward compatibility)."""
    settings = get_settings()
    return settings.ADMIN_SESSION_SECRET or "emby-notifier-admin-default-salt"


_PBKDF2_PREFIX = "pbkdf2_sha256"
_PBKDF2_SALT_BYTES = 16


def _pbkdf2_iters_default() -> int:
    """Read ADMIN_PBKDF2_ITERATIONS safely.

    Value is provided via Settings (ENV > .env > DEFAULT).
    Invalid values fall back to default in settings source; we still clamp here
    for safety.
    """
    settings = get_settings()
    try:
        v = int(getattr(settings, 'ADMIN_PBKDF2_ITERATIONS', 210000) or 210000)
    except (ValueError, TypeError, AttributeError) as e:
        biz.detail(f"PBKDF2 迭代次数读取失败，使用默认值：原因={type(e).__name__}")
        v = 210000
    v = max(100_000, v)
    return min(2_000_000, v)


def hash_password(plain: str) -> str:
    """Hash password using PBKDF2-HMAC-SHA256.

    Stored format:
        pbkdf2_sha256$<iters>$<salt_hex>$<digest_hex>

    No extra dependencies required (stdlib only).
    """
    salt = secrets.token_bytes(_PBKDF2_SALT_BYTES)
    iters = _pbkdf2_iters_default()
    dk = hashlib.pbkdf2_hmac("sha256", plain.encode("utf-8"), salt, iters)
    return f"{_PBKDF2_PREFIX}${iters}${salt.hex()}${dk.hex()}"


def _hash_password_legacy_sha256(plain: str) -> str:
    """Legacy sha256(salt + password)."""
    salt = _get_legacy_salt()
    data = (salt + plain).encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def is_legacy_hash(hashed: str) -> bool:
    if not isinstance(hashed, str) or not hashed:
        return False
    if hashed.startswith(_PBKDF2_PREFIX + "$"):
        return False
    # legacy is a bare sha256 hex
    return len(hashed) == 64 and all(c in "0123456789abcdef" for c in hashed.lower())


def verify_password(plain: str, hashed: str) -> bool:
    """Verify password against stored hash (supports legacy sha256 and new PBKDF2)."""
    try:
        if not hashed:
            return False

        if hashed.startswith(_PBKDF2_PREFIX + "$"):
            # pbkdf2_sha256$iters$salt_hex$dk_hex
            parts = hashed.split("$")
            if len(parts) != 4:
                return False
            _, iters_s, salt_hex, dk_hex = parts
            iters = int(iters_s)
            salt = bytes.fromhex(salt_hex)
            dk_expected = bytes.fromhex(dk_hex)
            dk = hashlib.pbkdf2_hmac("sha256", plain.encode("utf-8"), salt, iters)
            return hmac.compare_digest(dk, dk_expected)

        # legacy
        legacy = _hash_password_legacy_sha256(plain)
        return hmac.compare_digest(legacy, hashed)
    except (ValueError, TypeError, AttributeError) as e:
        biz.detail(f"密码验证失败：hashed={hashed[:20] if hashed else None}...，原因={type(e).__name__}")
        return False


def load_admin_record(settings=None) -> Optional[dict]:
    """Load admin record from ADMIN_PASSWORD_FILE.

    Returns dict: {username, password_hash, must_change_password?}
    """
    if settings is None:
        settings = get_settings()
    path = settings.ADMIN_PASSWORD_FILE
    if not path:
        return None
    if not os.path.exists(path):
        return None
    try:
        biz.detail("加载管理员凭证文件", stage="admin_auth", path=str(path))
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        username = data.get("username")
        password_hash = data.get("password_hash")
        if not username or not password_hash:
            return None
        if "must_change_password" not in data:
            data["must_change_password"] = False
        return data
    except Exception:
        biz.detail(f"管理员凭证文件加载失败：{path}", exc_info=True)
        return None


def load_admin_credentials(settings=None) -> Optional[Tuple[str, str]]:
    rec = load_admin_record(settings=settings)
    if not rec:
        return None
    return rec.get("username"), rec.get("password_hash")


def save_admin_credentials(
    username: str,
    password_hash: str,
    settings=None,
    must_change_password: Optional[bool] = None,
) -> None:
    """Write admin credentials to ADMIN_PASSWORD_FILE."""
    if settings is None:
        settings = get_settings()
    path = settings.ADMIN_PASSWORD_FILE
    if not path:
        raise ConfigurationError("ADMIN_PASSWORD_FILE 未配置")

    os.makedirs(os.path.dirname(path), exist_ok=True)

    existing = None
    if os.path.exists(path):
        try:
            biz.detail("读取现有管理员凭证文件", stage="admin_auth", path=str(path))
            with open(path, "r", encoding="utf-8") as f:
                existing = json.load(f)
        except (OSError, json.JSONDecodeError, ValueError) as e:
            biz.detail(f"管理员凭证文件读取失败（已忽略）：path={path}，原因={type(e).__name__}")
            existing = None

    if must_change_password is None:
        if isinstance(existing, dict) and "must_change_password" in existing:
            must_change_password = bool(existing.get("must_change_password"))
        else:
            must_change_password = False

    data = {
        "username": username,
        "password_hash": password_hash,
        "must_change_password": bool(must_change_password),
    }

    # Atomic write: avoids file corruption under concurrent writers (e.g., multi-worker startup).
    biz.ok(f"保存管理员凭证文件：{path}（密码已隐藏）")
    dirn = os.path.dirname(path) or "."
    tmp_fd = None
    tmp_path = None
    try:
        tmp_fd, tmp_path = tempfile.mkstemp(prefix=".admin_auth.", suffix=".tmp", dir=dirn)
        with os.fdopen(tmp_fd, "w", encoding="utf-8") as f:
            tmp_fd = None
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.write("\n")
        try:
            os.chmod(tmp_path, 0o600)
        except (OSError, AttributeError) as e:
            biz.detail(f"临时文件权限设置失败（已忽略）：path={tmp_path}，原因={type(e).__name__}")
        os.replace(tmp_path, path)
        tmp_path = None
        try:
            os.chmod(path, 0o600)
        except (OSError, AttributeError) as e:
            biz.detail(f"凭证文件权限设置失败（已忽略）：path={path}，原因={type(e).__name__}")
    finally:
        if tmp_fd is not None:
            try:
                os.close(tmp_fd)
            except OSError as e:
                biz.detail(f"临时文件描述符关闭失败（已忽略）：fd={tmp_fd}，原因={type(e).__name__}")
        if tmp_path:
            try:
                os.remove(tmp_path)
            except OSError as e:
                biz.detail(f"临时文件删除失败（已忽略）：path={tmp_path}，原因={type(e).__name__}")
