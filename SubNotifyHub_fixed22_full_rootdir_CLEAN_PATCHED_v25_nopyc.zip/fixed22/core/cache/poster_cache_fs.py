from __future__ import annotations

import json
from core.logging import get_biz_logger_adapter
import threading
from pathlib import Path
from typing import Optional, Tuple

logger = get_biz_logger_adapter(__name__)


def meta_path(cache_dir: Path, key: str) -> Path:
    return cache_dir / f"{key}.meta.json"


def load_meta(cache_dir: Path, key: str) -> dict:
    try:
        p = meta_path(cache_dir, key)
        if not p.exists():
            return {}
        return json.loads(p.read_text(encoding="utf-8")) or {}
    except Exception:
        logger.detail("海报缓存：加载 meta 失败: %s", key, exc_info=True)
        return {}


def save_meta(cache_dir: Path, key: str, meta: dict) -> None:
    try:
        p = meta_path(cache_dir, key)
        tmp = p.with_suffix(p.suffix + ".tmp")
        tmp.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(p)
    except Exception:
        logger.detail("海报缓存：保存 meta 失败: %s", key, exc_info=True)


def probe_cached_hit_sync(
    *,
    cache_dir: Path,
    fs_lock: threading.Lock,
    key: str,
    tag_val: Optional[str],
) -> Optional[Tuple[str, int]]:
    """Check whether a given key already exists on disk and tag is still valid.

    Intended to be called in a worker thread.
    """
    try:
        with fs_lock:
            try:
                cached_files = [
                    p for p in cache_dir.glob(f"{key}.*") if p.is_file() and not p.name.endswith(".meta.json")
                ]
            except (OSError, PermissionError) as e:
                logger.detail(f"海报缓存文件扫描失败 - 缓存键={key}, 原因={type(e).__name__}")
                cached_files = []

            if not cached_files:
                return None

            def _mtime(p: Path) -> float:
                try:
                    return float(p.stat().st_mtime)
                except (OSError, PermissionError) as e:
                    logger.detail(f"文件修改时间读取失败 - 文件={p.name}, 原因={type(e).__name__}")
                    return 0.0

            cached_files.sort(key=_mtime, reverse=True)
            meta = load_meta(cache_dir, key)
            last_tag = meta.get("tag")
            if (tag_val is None) or (last_tag == tag_val):
                cand = cached_files[0]
                v = int(_mtime(cand) or 0)
                return cand.name, v
    except Exception:
        logger.detail("海报缓存：probe hit 失败: %s", key, exc_info=True)
    return None
