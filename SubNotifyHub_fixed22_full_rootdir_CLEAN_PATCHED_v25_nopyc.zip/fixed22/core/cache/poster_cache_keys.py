from __future__ import annotations

import hashlib
from core.logging import get_biz_logger_adapter
from pathlib import Path
from typing import Optional, Tuple
from urllib.parse import parse_qsl, urlencode, urlparse, urlsplit, urlunsplit

logger = get_biz_logger_adapter(__name__)


def safe_url_for_log(url: str) -> str:
    """Sanitize a URL for logs (avoid leaking tokens/api_key)."""
    try:
        u = urlsplit(str(url))
        return urlunsplit((u.scheme, u.netloc, u.path, "", ""))
    except Exception:
        logger.detail("safe_url_for_log 失败", exc_info=True)
        return "<invalid-url>"


def sha1_text(text: str) -> str:
    h = hashlib.sha1()
    h.update(str(text).encode("utf-8", errors="ignore"))
    return h.hexdigest()


def normalize_url_for_key(url: str) -> Tuple[str, Optional[str]]:
    """Normalize remote URL for stable cache keys.

    - Remove volatile query params: api_key/token/X-Emby-Token...
    - Remove tag from keying (but return its value for refresh detection)
    - Sort remaining query params to stabilize order

    Returns: (normalized_url, tag_value)
    """
    try:
        sp = urlsplit(url)
        pairs = list(parse_qsl(sp.query, keep_blank_values=True))
        tag_val: Optional[str] = None
        kept = []
        for k, v in pairs:
            kl = (k or "").lower()
            if kl in ("api_key", "apikey", "token", "x-emby-token", "emby_token"):
                continue
            if kl == "tag":
                tag_val = v
                continue
            kept.append((k, v))

        kept.sort(key=lambda x: (x[0], x[1]))
        q = urlencode(kept, doseq=True)
        normalized = urlunsplit((sp.scheme, sp.netloc, sp.path, q, ""))
        return normalized, tag_val
    except Exception:
        logger.detail("normalize_url_for_key 失败", exc_info=True)
        return (str(url), None)


def guess_image_ext(url: str, content_type: Optional[str] = None) -> str:
    """Best-effort guess image extension from content-type or URL path."""
    try:
        if content_type:
            ct = str(content_type).split(";", 1)[0].strip().lower()
            mapping = {
                "image/jpeg": ".jpg",
                "image/jpg": ".jpg",
                "image/png": ".png",
                "image/webp": ".webp",
                "image/gif": ".gif",
                "image/avif": ".avif",
            }
            if ct in mapping:
                return mapping[ct]
    except Exception:
        logger.detail("guess_image_ext：content-type 失败", exc_info=True)

    try:
        ext = Path(urlparse(url).path).suffix.lower()
        if ext in (".jpg", ".jpeg", ".png", ".webp", ".gif", ".avif"):
            return ".jpg" if ext == ".jpeg" else ext
    except Exception:
        logger.detail("guess_image_ext：url 解析 失败", exc_info=True)

    return ".jpg"
