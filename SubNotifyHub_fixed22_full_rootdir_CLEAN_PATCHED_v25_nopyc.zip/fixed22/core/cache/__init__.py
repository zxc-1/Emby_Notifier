"""Cache submodule - unified caching infrastructure.

This module provides a unified interface for caching, including:
- TTLCache: In-memory TTL cache with bounded size
- Persistent cache: SQLite-based key-value cache with TTL
- PosterCache: Disk-based image cache for poster/fanart

Usage:
    from core.cache import TTLCache, get_or_set, aget_or_set
    from core.cache import kv_cache_get_json, kv_cache_set_json
    from core.cache import PosterCache, PosterCacheConfig
"""

from __future__ import annotations

# Re-export from ttl_cache
from .ttl_cache import (
    TTLCache,
    get_or_set,
    aget_or_set,
)

# Re-export from persist_cache
from .persist_cache import (
    kv_cache_get_json,
    kv_cache_set_json,
    kv_cache_get_json_async,
    kv_cache_set_json_async,
    kv_cache_delete,
    kv_cache_purge_expired,
)

# Re-export from poster_cache
from .poster_cache import (
    PosterCache,
    PosterCacheConfig,
)

# Re-export poster_cache utilities
from .poster_cache_keys import (
    safe_url_for_log,
    sha1_text,
    normalize_url_for_key,
    guess_image_ext,
)

from .poster_cache_fs import (
    meta_path,
    load_meta,
    save_meta,
    probe_cached_hit_sync,
)

from .poster_cache_evict import (
    evict_cache,
)

from .poster_cache_fetch import (
    download_image_bytes,
)

__all__ = [
    # ttl_cache
    "TTLCache",
    "get_or_set",
    "aget_or_set",
    # persist_cache
    "kv_cache_get_json",
    "kv_cache_set_json",
    "kv_cache_get_json_async",
    "kv_cache_set_json_async",
    "kv_cache_delete",
    "kv_cache_purge_expired",
    # poster_cache
    "PosterCache",
    "PosterCacheConfig",
    # poster_cache_keys
    "safe_url_for_log",
    "sha1_text",
    "normalize_url_for_key",
    "guess_image_ext",
    # poster_cache_fs
    "meta_path",
    "load_meta",
    "save_meta",
    "probe_cached_hit_sync",
    # poster_cache_evict
    "evict_cache",
    # poster_cache_fetch
    "download_image_bytes",
]
