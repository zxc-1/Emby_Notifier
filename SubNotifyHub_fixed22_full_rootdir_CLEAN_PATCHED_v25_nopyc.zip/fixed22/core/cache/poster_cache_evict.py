from __future__ import annotations

from core.logging import get_biz_logger_adapter
from datetime import datetime, timezone
from pathlib import Path
from typing import Callable

logger = get_biz_logger_adapter(__name__)


def evict_cache(
    *,
    cache_dir: Path,
    max_age_days: int,
    max_total_mb: int,
    max_files: int,
    meta_path_for_stem: Callable[[str], Path],
) -> None:
    """Best-effort eviction based on age, count, and total size.

    This function never raises; it is safe to call from runtime code.
    """
    try:
        files = [p for p in cache_dir.glob("*") if p.is_file() and not p.name.endswith(".meta.json")]
        if not files:
            return

        now = datetime.now(timezone.utc).timestamp()
        max_age = float(max_age_days) * 86400.0

        # 1) age-based
        for p in list(files):
            try:
                age = now - p.stat().st_mtime
                if age > max_age:
                    p.unlink(missing_ok=True)
                    try:
                        meta_path_for_stem(p.stem).unlink(missing_ok=True)
                    except Exception:
                        logger.detail("海报缓存：删除文件 meta 失败", exc_info=True)
            except Exception:
                logger.detail("海报缓存：清理/淘汰 age loop suppressed", exc_info=True)
                continue

        files = [p for p in cache_dir.glob("*") if p.is_file() and not p.name.endswith(".meta.json")]
        if not files:
            return

        # sort oldest first (by mtime)
        files.sort(key=lambda x: x.stat().st_mtime)

        # 2) size-based
        max_total_bytes = int(max_total_mb) * 1024 * 1024
        total = 0
        sizes = []
        for p in files:
            try:
                s = p.stat().st_size
            except (OSError, PermissionError) as e:
                logger.detail(f"文件大小读取失败 - 文件={p.name}, 原因={type(e).__name__}")
                s = 0
            sizes.append((p, s))
            total += s

        idx = 0
        while total > max_total_bytes and idx < len(sizes):
            p, s = sizes[idx]
            idx += 1
            try:
                p.unlink(missing_ok=True)
                total -= s
                try:
                    meta_path_for_stem(p.stem).unlink(missing_ok=True)
                except Exception:
                    logger.detail("海报缓存：删除文件 meta 失败", exc_info=True)
            except Exception:
                logger.detail("海报缓存：删除文件 失败", exc_info=True)

        # 3) count-based
        files = [p for p in cache_dir.glob("*") if p.is_file() and not p.name.endswith(".meta.json")]
        if len(files) > int(max_files):
            files.sort(key=lambda x: x.stat().st_mtime)
            for p in files[: max(0, len(files) - int(max_files))]:
                try:
                    p.unlink(missing_ok=True)
                    try:
                        meta_path_for_stem(p.stem).unlink(missing_ok=True)
                    except Exception:
                        logger.detail("海报缓存：删除文件 meta 失败", exc_info=True)
                except Exception:
                    logger.detail("海报缓存：删除文件 失败", exc_info=True)
    except Exception:
        logger.detail("海报缓存：清理/淘汰 失败", exc_info=True)
