from __future__ import annotations

import asyncio
import json
import os
import sqlite3
import threading
import time
from pathlib import Path
from typing import Any, Optional

from core.logging import get_biz_logger
from core.db.pool_manager import get_sync_pool, remove_sync_pool
from core.db.pool_config import PoolConfig
from settings.runtime import get_settings
from settings.timeouts import TimeoutCategory, get_timeout, get_db_busy_timeout_ms

biz = get_biz_logger(__name__)


def _warn_if_running_in_event_loop(api_name: str) -> None:
    """Warn when a sync cache API is called from an async context.

    Calling SQLite sync IO on the event loop can stall the whole bot under load.
    Use kv_cache_get_json_async / kv_cache_set_json_async instead.
    """
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return
    try:
        biz.warning(
            "检测到在异步上下文中调用同步缓存 API（可能阻塞事件循环）",
            api=str(api_name),
        )
    except Exception:
        # Never raise from a warning helper
        pass



logger = biz  # backward-compatible alias

def _secure_sqlite_files(db_path: str) -> None:
    """Best-effort chmod(0600) for sqlite db and its sidecar files."""
    try:
        for suf in ("", "-wal", "-shm", "-journal"):
            p = str(db_path) + suf
            if os.path.exists(p):
                try:
                    os.chmod(p, 0o600)
                except (OSError, PermissionError) as e:
                    # OSError: 文件系统不支持权限修改
                    # PermissionError: 没有权限修改文件
                    biz.detail(
                        f"SQLite 文件权限设置失败：{p}，原因：{type(e).__name__}",
                        path=p,
                        exc_type=type(e).__name__,
                    )
    except (OSError, TypeError) as e:
        # OSError: 文件系统错误
        # TypeError: db_path 类型错误
        biz.detail(
            f"SQLite 文件安全设置失败：{db_path}，原因：{type(e).__name__}",
            db_path=str(db_path),
            exc_type=type(e).__name__,
        )


# This module centralizes *persistent* cache logic (SQLite kv_cache), so other modules
# don't need to re-implement DB-cache patterns.

_KV_PURGE_LOCK = threading.Lock()
_KV_LOG_LOCK = threading.Lock()
_KV_LOG_LAST: dict[str, float] = {}

_LAST_CHECKPOINT_TS: float = 0.0
_LAST_VACUUM_TS: float = 0.0


def _db_path() -> str:
    """SQLite DB path for persistent kv cache."""
    try:
        s = get_settings()
        v = str(getattr(s, "TG_BOT_DB_PATH", "") or "").strip()
        return v or "/data/tg_bot.db"
    except (AttributeError, TypeError, ValueError) as e:
        # AttributeError: settings 对象没有 TG_BOT_DB_PATH 属性
        # TypeError: 类型转换失败
        # ValueError: 值无效
        biz.detail(
            f"从配置获取数据库路径失败，使用默认值：{type(e).__name__}",
            exc_type=type(e).__name__,
        )
        return "/data/tg_bot.db"


def _conn() -> sqlite3.Connection:
    """获取数据库连接（从连接池）
    
    注意：此函数返回的连接需要手动释放回池。
    推荐使用 _get_pool().connection() 上下文管理器。
    """
    return _get_pool().acquire()


def _get_pool() -> Any:
    """获取 persist_cache 数据库连接池"""
    db_path = _db_path()
    
    # 确保目录存在
    try:
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    except Exception:
        biz.detail("persist_cache: 创建数据库目录失败", db_path=db_path, exc_info=True)
    
    # 使用自定义配置
    config = PoolConfig(
        min_size=0,
        max_size=10,
        max_idle_time=300.0,
        connection_timeout=get_timeout(TimeoutCategory.DB_CONNECT),
    )
    
    pool = get_sync_pool(db_path, config)
    
    # 首次获取池时设置文件权限
    _secure_sqlite_files(db_path)
    
    return pool


def close_cache_db() -> None:
    """关闭 persist_cache 数据库连接池
    
    应在应用关闭时调用。
    """
    db_path = _db_path()
    if remove_sync_pool(db_path, close=True, timeout=5.0):
        biz.ok(f"persist_cache 数据库连接池已关闭：{db_path}", db_path=db_path)

def _ensure_tables(c: sqlite3.Connection) -> None:
    c.execute(
        """
        CREATE TABLE IF NOT EXISTS kv_cache (
            k TEXT PRIMARY KEY,
            v TEXT,
            exp_ts INTEGER
        );
        """
    )
    c.execute("CREATE INDEX IF NOT EXISTS idx_kv_cache_exp_ts ON kv_cache(exp_ts);")


def _log_throttled(
    tag: str,
    msg: str,
    *args: Any,
    min_interval_sec: int = 60,
    exc_info: bool | BaseException | None = None,
    **kw: Any,
) -> None:
    """Rate-limited debug logging.

    - Supports standard logger-style formatting: logger.debug(msg, *args)
    - Supports passing exc_info, and optional extra kv pairs via **kw (shown as extra=...).
    """
    now = time.monotonic()
    with _KV_LOG_LOCK:
        last = _KV_LOG_LAST.get(tag) or 0.0
        if (now - last) < float(min_interval_sec):
            return
        _KV_LOG_LAST[tag] = now

    if kw:
        # Preserve structured context without breaking msg formatting.
        try:
            biz.detail(msg + " | extra=%s", *args, kw, exc_info=exc_info)
            return
        except (TypeError, ValueError):
            # TypeError: 格式化参数不匹配
            # ValueError: 格式字符串无效
            pass

    try:
        biz.detail(msg, *args, exc_info=exc_info)
    except (TypeError, ValueError):
        # Never let logging break cache paths.
        # TypeError: 格式化参数不匹配
        # ValueError: 格式字符串无效
        pass


def kv_cache_get_json(key: str) -> Optional[Any]:
    _warn_if_running_in_event_loop('kv_cache_get_json')
    """Get a JSON value from kv_cache, honoring exp_ts (best-effort)."""
    try:
        now = int(time.time())
        pool = _get_pool()
        with pool.connection(auto_commit=False) as c:
            _ensure_tables(c)
            row = c.execute("SELECT v, exp_ts FROM kv_cache WHERE k=?", (str(key),)).fetchone()
            if not row:
                return None
            v, exp_ts = row
            if exp_ts is not None and int(exp_ts) > 0 and int(exp_ts) < now:
                try:
                    c.execute("DELETE FROM kv_cache WHERE k=?", (str(key),))
                    c.commit()
                except sqlite3.Error as e:
                    # 删除过期条目失败，不影响返回结果
                    biz.detail(
                        f"删除过期缓存条目失败：key={key}，原因：{type(e).__name__}",
                        key=str(key),
                        exc_type=type(e).__name__,
                    )
                return None
            return json.loads(v) if v is not None else None
    except (sqlite3.Error, json.JSONDecodeError, TypeError, ValueError) as e:
        _log_throttled("get_failed", "kv_cache_get_json failed: key=%s err=%r", str(key), e, exc_info=True)
        return None


def kv_cache_set_json(key: str, value: Any, *, ttl_sec: int | None = None) -> None:
    _warn_if_running_in_event_loop('kv_cache_set_json')
    """Set JSON value into kv_cache with optional ttl (best-effort)."""
    try:
        s = get_settings()
        max_bytes = int(getattr(s, "KV_CACHE_MAX_BYTES", 256 * 1024) or 256 * 1024)
    except (AttributeError, TypeError, ValueError):
        # AttributeError: settings 对象没有 KV_CACHE_MAX_BYTES 属性
        # TypeError: 类型转换失败
        # ValueError: 值无效
        max_bytes = 256 * 1024
    max_bytes = max(8 * 1024, min(2 * 1024 * 1024, int(max_bytes)))

    try:
        payload = json.dumps(value, ensure_ascii=False)
        if len(payload.encode("utf-8")) > max_bytes:
            _log_throttled("payload_too_large", "kv_cache_set_json skip: payload too large key=%s bytes=%s max=%s", str(key), len(payload.encode("utf-8")), max_bytes)
            return

        exp_ts = None
        if ttl_sec is not None:
            try:
                ttl = int(ttl_sec)
                if ttl > 0:
                    exp_ts = int(time.time()) + ttl
            except (TypeError, ValueError):
                # TypeError: ttl_sec 不能转换为 int
                # ValueError: ttl_sec 值无效
                exp_ts = None

        pool = _get_pool()
        with pool.connection() as c:
            _ensure_tables(c)
            c.execute(
                "INSERT INTO kv_cache(k, v, exp_ts) VALUES(?,?,?) "
                "ON CONFLICT(k) DO UPDATE SET v=excluded.v, exp_ts=excluded.exp_ts",
                (str(key), payload, exp_ts),
            )
    except (sqlite3.Error, json.JSONDecodeError, TypeError, ValueError) as e:
        _log_throttled("set_failed", "kv_cache_set_json failed: key=%s err=%r", str(key), e, exc_info=True)




def kv_cache_delete(key: str) -> None:
    """Delete a key from kv_cache (best-effort)."""
    try:
        pool = _get_pool()
        with pool.connection() as c:
            _ensure_tables(c)
            c.execute("DELETE FROM kv_cache WHERE k=?", (str(key),))
    except sqlite3.Error as e:
        _log_throttled("del_failed", "kv_cache_delete failed: key=%s err=%r", str(key), e, exc_info=True)


def kv_cache_purge_expired(*, max_delete: int = 200) -> None:
    """Best-effort purge of expired cache entries (rate-limited by lock)."""
    if not _KV_PURGE_LOCK.acquire(blocking=False):
        return
    try:
        now = int(time.time())
        pool = _get_pool()
        with pool.connection() as c:
            _ensure_tables(c)
            rows = c.execute(
                "SELECT k FROM kv_cache WHERE exp_ts IS NOT NULL AND exp_ts>0 AND exp_ts<? ORDER BY exp_ts ASC LIMIT ?",
                (now, int(max_delete)),
            ).fetchall()
            keys = [r[0] for r in rows if r and r[0] is not None]
            if keys:
                c.executemany("DELETE FROM kv_cache WHERE k=?", [(k,) for k in keys])
        _maintenance_throttled()
    except sqlite3.Error as e:
        _log_throttled("purge_failed", "kv_cache_purge_expired failed: err=%r", e, exc_info=True)
    finally:
        try:
            _KV_PURGE_LOCK.release()
        except RuntimeError:
            # RuntimeError: 锁未被持有（不应该发生，但防御性处理）
            pass


def _maintenance_throttled() -> None:
    """Keep WAL size under control; optional VACUUM via setting."""
    global _LAST_CHECKPOINT_TS, _LAST_VACUUM_TS
    try:
        now = time.time()
    except (OSError, OverflowError):
        # OSError: 系统时间获取失败
        # OverflowError: 时间值溢出
        return

    pool = _get_pool()
    
    # checkpoint at most every 6 hours
    if (now - float(_LAST_CHECKPOINT_TS or 0)) >= 6 * 3600:
        try:
            with pool.connection(auto_commit=False) as c:
                _ensure_tables(c)
                c.execute("PRAGMA wal_checkpoint(TRUNCATE);")
        except sqlite3.Error:
            _log_throttled("checkpoint_failed", "kv_cache checkpoint failed", exc_info=True)
        _LAST_CHECKPOINT_TS = now

    # vacuum at most daily, opt-in only
    try:
        s = get_settings()
        vacuum = bool(getattr(s, "KV_CACHE_VACUUM", False))
    except (AttributeError, TypeError, ValueError):
        # AttributeError: settings 对象没有 KV_CACHE_VACUUM 属性
        # TypeError: 类型转换失败
        # ValueError: 值无效
        vacuum = False
    if vacuum and (now - float(_LAST_VACUUM_TS or 0)) >= 24 * 3600:
        try:
            with pool.connection(auto_commit=False) as c:
                _ensure_tables(c)
                c.execute("VACUUM;")
        except sqlite3.Error:
            _log_throttled("vacuum_failed", "kv_cache VACUUM failed", exc_info=True)
        _LAST_VACUUM_TS = now


async def kv_cache_get_json_async(key: str) -> Optional[Any]:
    """Async wrapper for kv_cache_get_json.

    Uses a thread offload to avoid blocking the event loop.
    Prefer this API from async handlers / FastAPI routes / bot updates.
    """
    return await asyncio.to_thread(kv_cache_get_json, key)


async def kv_cache_set_json_async(key: str, value: Any, *, ttl_sec: int | None = None) -> None:
    """Async wrapper for kv_cache_set_json (thread offload)."""
    await asyncio.to_thread(kv_cache_set_json, key, value, ttl_sec=ttl_sec)
