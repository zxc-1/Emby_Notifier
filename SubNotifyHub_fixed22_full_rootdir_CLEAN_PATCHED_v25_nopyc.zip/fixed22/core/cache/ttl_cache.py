from __future__ import annotations

"""Small in-process TTL cache.

This project previously had several ad-hoc TTL caches implemented in different
modules (TMDB match, metadata TMDB client, 115 share scanning, etc.).

To reduce maintenance issues (e.g. inconsistent eviction/TTL behavior), the TTL
cache implementation is centralized here.
"""
from core.logging import get_biz_logger_adapter

logger = get_biz_logger_adapter(__name__)


import time
import threading
from typing import Awaitable, Callable, Generic, Optional, TypeVar

K = TypeVar("K")
V = TypeVar("V")


class TTLCache(Generic[K, V]):
    """A tiny bounded TTL cache.

    - Thread-safe (coarse lock).
    - Eviction is opportunistic (cheap) + bounded size.
    - Supports per-item TTL override.
    """

    def __init__(self, *, maxsize: int, default_ttl: int) -> None:
        self.maxsize = int(max(1, maxsize))
        self.default_ttl = int(max(1, default_ttl))
        self._d: dict[K, tuple[float, V]] = {}
        self._lock = threading.Lock()

    def get(self, key: K) -> Optional[V]:
        now = time.monotonic()
        with self._lock:
            item = self._d.get(key)
            if not item:
                return None
            exp, val = item
            if exp < now:
                self._d.pop(key, None)
                return None
            return val

    def set(self, key: K, val: V, *, ttl: int | None = None) -> None:
        now = time.monotonic()
        exp = now + int(ttl if ttl is not None else self.default_ttl)
        with self._lock:
            # opportunistic prune
            if len(self._d) >= self.maxsize:
                self._prune_locked(now)
            self._d[key] = (exp, val)

    def pop(self, key: K) -> Optional[V]:
        with self._lock:
            item = self._d.pop(key, None)
        if not item:
            return None
        return item[1]

    def clear(self) -> None:
        with self._lock:
            self._d.clear()

    def _prune_locked(self, now: float) -> None:
        # Remove expired first.
        for k, (exp, _v) in list(self._d.items())[: max(1, self.maxsize // 4)]:
            if exp < now:
                self._d.pop(k, None)
        # If still oversized, evict arbitrary keys.
        while len(self._d) >= self.maxsize:
            try:
                self._d.pop(next(iter(self._d)))
            except StopIteration:
                # 字典为空，无需继续清理
                break
            except (KeyError, RuntimeError) as e:
                # KeyError: 键已被其他线程删除
                # RuntimeError: 字典在迭代过程中被修改
                logger.detail(
                    "cache prune 被中断",
                    exc_type=type(e).__name__,
                    cache_size=len(self._d),
                )
                break


def get_or_set(
    cache: TTLCache[K, V],
    key: K,
    loader: Callable[[], Optional[V]],
    *,
    ttl: int | None = None,
) -> Optional[V]:
    """Get from cache; otherwise compute with loader() and set."""
    v = cache.get(key)
    if v is not None:
        return v
    v2 = loader()
    if v2 is None:
        return None
    cache.set(key, v2, ttl=ttl)
    return v2


async def aget_or_set(
    cache: TTLCache[K, V],
    key: K,
    aloader: Callable[[], Awaitable[Optional[V]]],
    *,
    ttl: int | None = None,
) -> Optional[V]:
    """Async helper: get from cache; otherwise await aloader() and set."""
    v = cache.get(key)
    if v is not None:
        return v
    v2 = await aloader()
    if v2 is None:
        return None
    cache.set(key, v2, ttl=ttl)
    return v2
