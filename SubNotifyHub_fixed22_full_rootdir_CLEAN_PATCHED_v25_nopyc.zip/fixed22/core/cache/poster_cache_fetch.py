from __future__ import annotations

from core.logging import get_biz_logger
from typing import Dict, Optional, Tuple

import httpx

from .poster_cache_keys import guess_image_ext

biz = get_biz_logger(__name__)


logger = biz  # backward-compatible alias

async def download_image_bytes(
    *,
    client: httpx.AsyncClient,
    url: str,
    headers: Dict[str, str],
    allowed_mimes: set[str],
    max_bytes: int,
    chunk_size: int,
    timeout: httpx.Timeout,
) -> Optional[Tuple[bytes, str, str, int]]:
    """Stream-download an image with caps and MIME validation.

    Returns (content_bytes, ext, content_type, total_bytes) or None on failure.
    """

    try:
        async with client.stream(
            "GET",
            url,
            headers=headers,
            follow_redirects=True,
            timeout=timeout,
        ) as resp:
            if resp.status_code >= 400:
                biz.warning(f"海报下载失败：HTTP 状态码 {resp.status_code}", status=resp.status_code, url=url)
                return None

            ct = (resp.headers.get("content-type") or "").split(";", 1)[0].strip().lower()
            if not ct or ct not in allowed_mimes:
                biz.warning(f"海报下载失败：不支持的 MIME 类型 {ct or '(空)'}", mime=ct or "", url=url)
                return None

            # content-length upper bound
            try:
                cl = resp.headers.get("content-length")
                if cl:
                    n = int(cl)
                    if n > max_bytes:
                        biz.warning(f"海报下载失败：文件过大 {n} 字节（限制 {max_bytes} 字节）", size=n, max_bytes=max_bytes, url=url)
                        return None
            except (ValueError, TypeError) as e:
                biz.detail(f"Content-Length 解析失败（已忽略）：值={cl!r}, 原因={type(e).__name__}")

            ext = guess_image_ext(url, ct)

            total = 0
            buf = bytearray()
            async for chunk in resp.aiter_bytes(chunk_size=chunk_size):
                if not chunk:
                    continue
                total += len(chunk)
                if total > max_bytes:
                    biz.warning(f"海报下载失败：流式传输超过大小限制 {total} 字节（限制 {max_bytes} 字节）", size=total, max_bytes=max_bytes, url=url)
                    return None
                buf.extend(chunk)

            if total <= 0:
                biz.warning("海报下载失败：响应内容为空", url=url)
                return None

            return bytes(buf), ext, ct, total

    except Exception:
        biz.detail("海报下载异常", exc_info=True)
        return None
