from __future__ import annotations

import asyncio
import hashlib
import json
 
import shutil
import threading
import time
import httpx
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional
from urllib.parse import parse_qsl, urlencode, urlparse, urlsplit, urlunsplit

from settings.runtime import get_settings

# IMPORTANT: core must not depend on feature layers (e.g. notifier).
# The shared AsyncClient is implemented in core.http.clients.
from core.http import get_http_client
from core.env_utils import env_float, env_int, env_str
from core.storage.file_lock import file_lock
from core.logging import get_biz_logger_adapter
from .poster_cache_keys import safe_url_for_log as _safe_url_for_log, sha1_text, normalize_url_for_key, guess_image_ext
from .poster_cache_fs import meta_path as _meta_path_fs, load_meta as _load_meta_fs, save_meta as _save_meta_fs, probe_cached_hit_sync as _probe_cached_hit_sync_fs
from .poster_cache_evict import evict_cache as _evict_cache
from .poster_cache_fetch import download_image_bytes as _download_image_bytes

logger = get_biz_logger_adapter(__name__)




# NOTE: implementation moved to core.cache.poster_cache_keys.safe_url_for_log


@dataclass(frozen=True)
class PosterCacheConfig:
    mount_path: str = "/poster_cache"
    max_files: int = 500
    max_total_mb: int = 200
    max_age_days: int = 7
    max_single_mb: int = 25


class PosterCache:
    """Cache poster/fanart images to local disk so the admin UI can load them reliably.

    Key goals:
    - Browser should not need direct access to Emby/internal image URLs.
    - Cache should not grow without bound.

    Implementation notes:
    - FS mutations are protected by a threading.Lock because we may run FS work
      in a thread via asyncio.to_thread().
    - Eviction is throttled to avoid scanning the directory on every request.
    """

    def __init__(self, cache_dir: Path, config: Optional[PosterCacheConfig] = None) -> None:
        self.cache_dir = cache_dir
        self.cfg = config or PosterCacheConfig(
            mount_path=env_str("POSTER_CACHE_MOUNT_PATH", "/poster_cache"),
            max_files=env_int("POSTER_CACHE_MAX_FILES", 500, min_value=0),
            max_total_mb=env_int("POSTER_CACHE_MAX_TOTAL_MB", 200, min_value=0),
            max_age_days=env_int("POSTER_CACHE_MAX_AGE_DAYS", 7, min_value=0),
            max_single_mb=env_int("POSTER_CACHE_MAX_SINGLE_MB", 25, min_value=0),
        )

        self._fs_lock = threading.Lock()
        # Cross-process guard for cache directory mutations (best-effort).
        self._disk_lock_path = self.cache_dir / ".poster_cache.lock"
        self._last_evict_ts = 0.0
        self._evict_min_interval_s = env_float("POSTER_CACHE_EVICT_MIN_INTERVAL", 60.0, min_value=0.0)

        # Streaming download knobs (env overrides). Parsed once per instance to keep the
        # hot download path lightweight and to avoid crashing on invalid env values.
        allowed_env = env_str("POSTER_CACHE_ALLOWED_MIME", "").strip()
        if allowed_env:
            self._allowed_mimes = {m.strip().lower() for m in allowed_env.split(",") if m.strip()}
        else:
            self._allowed_mimes = {
                "image/jpeg",
                "image/jpg",
                "image/png",
                "image/webp",
                "image/gif",
                "image/avif",
            }

        self._stream_chunk_size = env_int(
            "POSTER_CACHE_STREAM_CHUNK_SIZE",
            65536,
            min_value=4096,
            max_value=1048576,
        )

        connect_to = env_float("POSTER_CACHE_CONNECT_TIMEOUT", 6.0, min_value=0.0, max_value=120.0)
        read_to = env_float("POSTER_CACHE_READ_TIMEOUT", 18.0, min_value=0.0, max_value=300.0)
        write_to = env_float("POSTER_CACHE_WRITE_TIMEOUT", 10.0, min_value=0.0, max_value=300.0)
        pool_to = env_float("POSTER_CACHE_POOL_TIMEOUT", 6.0, min_value=0.0, max_value=120.0)
        self._stream_timeout = httpx.Timeout(connect=connect_to, read=read_to, write=write_to, pool=pool_to)

        try:
            self.cache_dir.mkdir(parents=True, exist_ok=True)
        except Exception:
            logger.detail("海报缓存：创建目录 失败: %s", self.cache_dir, exc_info=True)

    @staticmethod
    def _sha1_text(text: str) -> str:
        return sha1_text(text)

    @staticmethod
    def _normalize_url_for_key(url: str) -> tuple[str, Optional[str]]:
        return normalize_url_for_key(url)

    def _meta_path(self, key: str) -> Path:
        return _meta_path_fs(self.cache_dir, key)

    def _load_meta(self, key: str) -> dict:
        return _load_meta_fs(self.cache_dir, key)

    def _save_meta(self, key: str, meta: dict) -> None:
        _save_meta_fs(self.cache_dir, key, meta)

    def _probe_cached_hit_sync(self, key: str, tag_val: Optional[str]) -> Optional[tuple[str, int]]:
        return _probe_cached_hit_sync_fs(cache_dir=self.cache_dir, fs_lock=self._fs_lock, key=key, tag_val=tag_val)


    @staticmethod
    def _guess_image_ext(url: str, content_type: Optional[str] = None) -> str:
        return guess_image_ext(url, content_type)

    @staticmethod
    def _is_allowed_local_media_path(p: Path) -> bool:
        """Self-hosted project: allow any existing file path inside container mounts."""
        try:
            return p.resolve().is_file()
        except Exception:
            logger.fail("路径检查异常 - path=%s", p, exc_info=True)
            return False

    def _build_url(self, filename: str, mtime: Optional[int] = None) -> str:
        base = self.cfg.mount_path.rstrip("/")
        if mtime is None:
            return f"{base}/{filename}"
        return f"{base}/{filename}?v={mtime}"

    def _maybe_evict_locked(self) -> None:
        now = time.time()
        if (now - self._last_evict_ts) < self._evict_min_interval_s:
            return
        self._last_evict_ts = now
        self._evict_impl_locked()

    def _evict_impl_locked(self) -> None:
        """Best-effort cache eviction based on age, count, and total size.

        Must be called under self._fs_lock.
        """
        _evict_cache(
            cache_dir=self.cache_dir,
            max_age_days=int(self.cfg.max_age_days),
            max_total_mb=int(self.cfg.max_total_mb),
            max_files=int(self.cfg.max_files),
            meta_path_for_stem=lambda stem: self._meta_path(stem),
        )

    def evict_if_needed(self) -> None:
        """Public eviction entrypoint (throttled)."""
        try:
            with self._fs_lock:
                with file_lock(self._disk_lock_path):
                    self._maybe_evict_locked()
        except Exception:
            logger.detail("海报缓存：清理/淘汰 锁 失败", exc_info=True)


    def cache_local_file(self, local_path: str) -> Optional[str]:
        """Copy a local image into the cache and return its web URL."""
        try:
            src = Path(local_path)
            if not src.is_file():
                return None
            if not self._is_allowed_local_media_path(src):
                return None

            key = self._sha1_text(str(src))
            ext = src.suffix.lower() if src.suffix else ".jpg"
            dst = self.cache_dir / f"{key}{ext}"

            with self._fs_lock:
                with file_lock(self._disk_lock_path):
                    if not dst.exists():
                        self.cache_dir.mkdir(parents=True, exist_ok=True)
                        tmp = dst.with_suffix(dst.suffix + ".tmp")
                        shutil.copyfile(src, tmp)
                        tmp.replace(dst)
                        self._maybe_evict_locked()

            v = int(src.stat().st_mtime)
            return self._build_url(dst.name, v)
        except Exception:
            logger.detail("海报缓存：cache_local_file 失败: %s", local_path, exc_info=True)
            return None



    async def cache_remote_url(self, url: str) -> Optional[str]:
        """Download a remote image into cache and return its web URL (best-effort)."""
        if not url:
            return None
        try:
            normalized, tag_val = self._normalize_url_for_key(str(url))
            key = self._sha1_text(normalized)

            # Fast path: cached hit and tag still valid
            hit = await asyncio.to_thread(self._probe_cached_hit_sync, key, tag_val)
            if hit:
                fname, v = hit
                return self._build_url(fname, v)

            # get_http_client() is async; missing await will create a coroutine
            # and trigger "was never awaited" warnings.
            client = await get_http_client()

            # Reasonable default headers; can be overridden via env for strict sites.
            ua = (env_str("POSTER_CACHE_UA", "") or env_str("HOTLIST_UA", "")).strip()
            if not ua:
                ua = "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0 Mobile Safari/537.36"
            headers = {
                "User-Agent": ua,
                "Accept": "image/avif,image/webp,image/apng,image/*,*/*;q=0.8",
                "Accept-Language": "zh-CN,zh;q=0.9,en;q=0.8",
                # Some CDNs/hosts rely on referer for hotlink protection; we keep it minimal.
                "Referer": url,
            }

            max_bytes = max(1, int(self.cfg.max_single_mb)) * 1024 * 1024
            dl = await _download_image_bytes(
                client=client,
                url=str(url),
                headers=headers,
                allowed_mimes=set(self._allowed_mimes),
                max_bytes=max_bytes,
                chunk_size=int(self._stream_chunk_size),
                timeout=self._stream_timeout,
            )
            if not dl:
                return None
            content_bytes, ext, content_type, total = dl

            fname, v = await asyncio.to_thread(
                self._write_remote_cached,
                key,
                ext,
                content_bytes,
                tag_val,
                normalized,
                str(url),
            )
            return self._build_url(fname, v)
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.detail("海报缓存：cache_remote_url 失败: %s", _safe_url_for_log(str(url)), exc_info=True)
            return None

    async def ensure_web_cover(self, content: object) -> None:
        """Ensure content.web_cover_url is set for admin UI (never raises)."""
        try:
            # Already prepared
            if getattr(content, "web_cover_url", None):
                return

            # Prefer poster for UI, fallback to fanart.
            local_path = getattr(content, "poster_path", None) or getattr(content, "fanart_path", None)
            if local_path:
                web = await asyncio.to_thread(self.cache_local_file, str(local_path))
                if web:
                    try:
                        setattr(content, "web_cover_url", web)
                    except Exception as e:
                        biz.detail("ignored exception in cache_local_file", exc_info=True)
                        pass
                    return

            remote_url = (
                getattr(content, "poster_url", None)
                or getattr(content, "cover_url", None)
                or getattr(content, "fanart_url", None)
            )
            if remote_url:
                web = await self.cache_remote_url(str(remote_url))
                if web:
                    try:
                        setattr(content, "web_cover_url", web)
                    except Exception as e:
                        biz.detail("ignored exception in cache_local_file", exc_info=True)
                        pass
        except asyncio.CancelledError:
            raise
        except Exception:
            # absolutely best-effort: never break notification path
            logger.detail("海报缓存：ensure_web_cover 失败", exc_info=True)
            return
    def _write_remote_cached(self, key: str, ext: str, content: bytes, tag_val: Optional[str], normalized: str, source_url: str) -> tuple[str, int]:
        """Write remote bytes to cache atomically (sync; intended for to_thread)."""
        with self._fs_lock:
            with file_lock(self._disk_lock_path):
                self.cache_dir.mkdir(parents=True, exist_ok=True)

                # remove old variants before writing new file
                for old in list(self.cache_dir.glob(f"{key}.*")):
                    try:
                        if old.is_file() and not old.name.endswith(".meta.json"):
                            old.unlink(missing_ok=True)
                    except Exception:
                        logger.detail("海报缓存：删除文件 meta 失败", exc_info=True)

                dst = self.cache_dir / f"{key}{ext}"
                tmp = dst.with_suffix(dst.suffix + ".tmp")
                tmp.write_bytes(content)
                tmp.replace(dst)

                # record tag to detect refresh needs
                self._save_meta(key, {"tag": tag_val, "normalized_url": normalized, "source_url": source_url})

                self._maybe_evict_locked()

                v = int(dst.stat().st_mtime)
                return dst.name, v


    def _commit_remote_tmp(self, key: str, ext: str, tmp_path: Path, tag_val: Optional[str], normalized: str, source_url: str) -> tuple[str, int]:
        """Commit a downloaded temp file into cache atomically (sync; intended for to_thread)."""
        with self._fs_lock:
            with file_lock(self._disk_lock_path):
                self.cache_dir.mkdir(parents=True, exist_ok=True)

                # remove old variants before writing new file
                for old in list(self.cache_dir.glob(f"{key}.*")):
                    try:
                        if old.is_file() and not old.name.endswith(".meta.json"):
                            old.unlink(missing_ok=True)
                    except Exception:
                        logger.detail("海报缓存：删除文件 meta 失败", exc_info=True)

                dst = self.cache_dir / f"{key}{ext}"
                # Ensure tmp is inside cache_dir for atomic replace
                try:
                    if tmp_path.resolve().parent != self.cache_dir.resolve():
                        local_tmp = dst.with_suffix(dst.suffix + ".tmp")
                        shutil.copyfile(tmp_path, local_tmp)
                        tmp_path = local_tmp
                except (OSError, PermissionError) as e:
                    logger.detail(f"临时文件移动失败（已忽略） - 源={tmp_path.name}, 目标={dst.name}, 原因={type(e).__name__}")

                tmp_path.replace(dst)

                # record tag to detect refresh needs
                self._save_meta(key, {"tag": tag_val, "normalized_url": normalized, "source_url": source_url})

                self._maybe_evict_locked()
                v = int(dst.stat().st_mtime)
                return dst.name, v
