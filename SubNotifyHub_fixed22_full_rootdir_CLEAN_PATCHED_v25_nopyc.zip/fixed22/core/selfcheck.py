from __future__ import annotations

from core.exceptions.base import ConfigurationError

"""Import-time smoke checks.

Goal: fail fast at startup if a refactor accidentally leaves a NameError /
missing symbol in a hot path (e.g. missing import in a callback handler).

Keep this fast and dependency-light (NO network calls).
"""

import importlib


# Modules that must import cleanly in production.
CRITICAL_MODULES = [
    # Web/admin/API
    "admin.routes",
    "api.router",
    "api.webhook",
    "api.debug",
    # Forward bridge
    "forward_bridge.routes",
    "forward_bridge.subscriptions",
    "forward_bridge.http_client",
    "forward_bridge.subscriptions_core",
    # TG bot hot paths
    "tg_bot.storage",
    "tg_bot.features.cloud115",
    "tg_bot.features.cloud115.qr_login",
    "tg_bot.features.cloud115.dir_browser",
    "tg_bot.features.cloud115.offdir_picker",
    "tg_bot.features.share.callbacks",
    # Notifier pipeline
    "notifier.notifiers.telegram",
    "notifier.service.process",
    "notifier.service.enrich",
]

# Extra symbol presence checks to catch "name 'xxx' is not defined" at runtime.
# These avoid executing the functions (so no side effects), but ensure the globals exist.
SYMBOL_CHECKS: dict[str, list[str]] = {
    "integrations.cloud115.qrcode": ["async_request_with_retry"],
    "integrations.share115": ["parse_share_url", "resolve_best_video_for_share"],
    "forward_bridge.http_client": ["async_request_with_retry"],
    "forward_bridge.subscriptions_core": ["async_request_with_retry"],
    # Settings entrypoint lives in tg_bot.settings; tg_bot.storage re-exports for backward-compat.
    "tg_bot.settings": ["get_settings"],
}


def run_selfcheck() -> None:
    # Import critical modules
    for m in CRITICAL_MODULES:
        importlib.import_module(m)

    # Validate required symbols exist (and are not None)
    for mod_name, names in SYMBOL_CHECKS.items():
        mod = importlib.import_module(mod_name)
        for n in names:
            if not hasattr(mod, n):
                raise ConfigurationError(f"selfcheck: {mod_name} missing symbol: {n}")
            v = getattr(mod, n)
            if v is None:
                raise ConfigurationError(f"selfcheck: {mod_name} symbol is None: {n}")
