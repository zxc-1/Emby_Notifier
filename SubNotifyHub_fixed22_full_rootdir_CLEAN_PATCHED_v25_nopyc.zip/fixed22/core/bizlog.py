"""DEPRECATED: Use core.logging.bizlog instead.

This module is maintained for backward compatibility only.
Please update your imports to use the new path:

    # Old (deprecated):
    from core.logging import BizLogger, get_biz_logger

    # New (recommended):
    from core.logging import BizLogger, get_biz_logger
"""

from __future__ import annotations

import warnings

warnings.warn(
    "Importing from 'core.bizlog' is deprecated. "
    "Use 'from core.logging import BizLogger, get_biz_logger' instead.",
    DeprecationWarning,
    stacklevel=2,
)

# Re-export everything from the new location for backward compatibility
from core.logging.bizlog import (
    BizLogger,
    get_biz_logger,
    is_detail_enabled,
    logger,
    # Internal symbols for test compatibility
    _throttle_map,
    _stack_var,
    _result_var,
    _should_log_item,
    _truthy_env,
    _top,
    _push,
    _pop,
    _inc_counter,
    _kv_merge,
    _sanitize_emit_kwargs,
    _throttle_allow,
)

__all__ = [
    "BizLogger",
    "get_biz_logger",
    "is_detail_enabled",
    "logger",
    # Internal symbols (for backward compatibility only)
    "_throttle_map",
    "_stack_var",
    "_result_var",
    "_should_log_item",
    "_truthy_env",
    "_top",
    "_push",
    "_pop",
    "_inc_counter",
    "_kv_merge",
    "_sanitize_emit_kwargs",
    "_throttle_allow",
]
