"""DEPRECATED: Use core.http.clients instead.

This module is maintained for backward compatibility only.
Please update your imports to use the new path:

    # Old (deprecated):
    from core.http_clients import get_http_client, create_http_client

    # New (recommended):
    from core.http import get_http_client, create_http_client
"""

from __future__ import annotations

import warnings

warnings.warn(
    "Importing from 'core.http_clients' is deprecated. "
    "Use 'from core.http import get_http_client, create_http_client' instead.",
    DeprecationWarning,
    stacklevel=2,
)

# Re-export everything from the new location for backward compatibility
from core.http.clients import (
    get_http_client,
    create_http_client,
    close_http_client,
    # Internal symbols for backward compatibility
    _clients,
    _locks,
    _loop_id,
    _get_lock,
    _inject_trace_id,
    _make_client,
)

__all__ = [
    "get_http_client",
    "create_http_client",
    "close_http_client",
    # Internal symbols (for backward compatibility only)
    "_clients",
    "_locks",
    "_loop_id",
    "_get_lock",
    "_inject_trace_id",
    "_make_client",
]
