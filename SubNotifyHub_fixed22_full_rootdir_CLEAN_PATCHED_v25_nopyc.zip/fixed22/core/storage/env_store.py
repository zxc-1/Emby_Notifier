from __future__ import annotations

from core.exceptions.base import ConfigurationError

"""Atomic, cross-module updates for .env.

Historically multiple modules performed: load -> modify -> dump on /data/.env
without a shared lock, causing lost updates under concurrency.

This module provides a single, lock-protected entrypoint.
"""

from contextlib import contextmanager
from pathlib import Path
from typing import Dict, Iterable, Optional

from core.logging import get_biz_logger
from core.storage.file_lock import file_lock
from core.runtime_env import get_env_path

biz = get_biz_logger(__name__)


@contextmanager
def _file_lock(lock_path: Path, *, timeout_sec: float = 10.0):
    """Backward-compatible alias for :func:`core.storage.file_lock.file_lock`."""
    with file_lock(lock_path, timeout_sec=timeout_sec):
        yield


def env_path() -> Path:
    """Path to the single supported dotenv file (.env).

    Scheme A: ENV > .env > DEFAULT
    """
    return get_env_path()


def env_local_path() -> Path:
    """Backward-compatible alias for older code paths.

    Deprecated: scheme A ignores .env.local.
    """
    return env_path()


def update_env_file(
    changes: Dict[str, Optional[str]],
    *,
    remove: Iterable[str] | None = None,
    verify: bool = True,
) -> bool:
    """Update /data/.env atomically-ish.

    - Serializes load->modify->dump under a lock.
    - Optionally verifies by reloading.
    - Best-effort; returns success bool.
    """
    from core.storage.fs import dump_env_file, load_env_file

    p = env_path()
    # NOTE: Path.with_suffix() behaves poorly for dotfiles like ".env" where
    # suffix == "" and would produce a generic ".lock" in the directory.
    # Use an explicit filename to avoid collisions.
    lock_p = p.parent / (p.name + ".lock")
    remove = list(remove or [])

    with _file_lock(lock_p):
        old: Dict[str, str] | None = None
        try:
            cur = load_env_file(p)
            old = dict(cur)

            # Apply removals first
            for k in remove:
                kk = str(k or "").strip()
                if kk:
                    cur.pop(kk, None)

            for k, v in (changes or {}).items():
                kk = str(k or "").strip()
                if not kk:
                    continue
                if v is None:
                    cur.pop(kk, None)
                else:
                    cur[kk] = str(v)

            dump_env_file(p, cur)

            if verify:
                chk = load_env_file(p)
                # Verify removals
                for k in remove:
                    kk = str(k or "").strip()
                    if kk and kk in chk:
                        raise ConfigurationError("env verify failed: remove")
                # Verify changes
                for k, v in (changes or {}).items():
                    kk = str(k or "").strip()
                    if not kk:
                        continue
                    if v is None:
                        if kk in chk:
                            raise ConfigurationError("env verify failed: delete")
                    else:
                        if str(chk.get(kk) or "") != str(v):
                            raise ConfigurationError("env verify failed: set")

            return True
        except (OSError, PermissionError, RuntimeError) as e:
            # Rollback must happen while still holding the lock, otherwise we can clobber
            # another process's successful update.
            biz.warning(f"⚠️ 环境变量更新失败（已回滚）：文件写入或验证失败", 文件=str(p), 原因=type(e).__name__, exc=e)
            if old is not None:
                try:
                    dump_env_file(p, old)
                except (OSError, PermissionError) as rollback_err:
                    biz.warning(f"⚠️ 环境变量回滚失败：无法恢复原始内容", 文件=str(p), 原因=type(rollback_err).__name__)
            return False



def update_env_local(
    changes: Dict[str, Optional[str]],
    *,
    remove: Iterable[str] | None = None,
    verify: bool = True,
) -> bool:
    """Backward-compatible wrapper. Prefer update_env_file()."""
    return update_env_file(changes, remove=remove, verify=verify)
