from __future__ import annotations

"""Storage ports (small, dependency-free).

This project historically used a few ad-hoc persistence patterns (SQLite kv_cache,
various small JSON files, and a couple in-memory fallbacks).

For future extensibility (e.g. Redis KV / S3 blob / multi-instance deployments),
business logic should depend on *interfaces* (ports) rather than concrete storage.

This module defines a tiny set of protocols and provides default implementations
that keep current behavior.

No third-party dependencies are introduced.

NOTE: This module must NOT import settings at module level to avoid circular imports.
      settings/base.py → core.storage → blob_store.py → settings.runtime → CIRCULAR!
      Use lazy imports inside functions that need settings.
"""

import hashlib
import asyncio
import threading
import time
import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any, Optional, Protocol, runtime_checkable

from core.logging import get_biz_logger

if TYPE_CHECKING:
    from settings.runtime import SettingsProxy

biz = get_biz_logger(__name__)


def _get_settings() -> "SettingsProxy":
    """Lazy import to avoid circular dependency with settings module."""
    from settings.runtime import get_settings
    return get_settings()


# ---------------------------------------------------------------------------
# Ports
# ---------------------------------------------------------------------------


@runtime_checkable
class KVStore(Protocol):
    """Key-value store for small JSON-serializable objects."""

    def get_json(self, key: str) -> Optional[Any]:
        ...

    def set_json(self, key: str, value: Any, *, ttl_sec: int | None = None) -> None:
        ...

    def delete(self, key: str) -> None:
        ...

    def purge_expired(self, *, max_delete: int = 200) -> None:
        ...


@runtime_checkable
class AsyncKVStore(Protocol):
    """Async key-value store for small JSON-serializable objects."""

    async def get_json(self, key: str) -> Optional[Any]:
        ...

    async def set_json(self, key: str, value: Any, *, ttl_sec: int | None = None) -> None:
        ...

    async def delete(self, key: str) -> None:
        ...

    async def purge_expired(self, *, max_delete: int = 200) -> None:
        ...


@runtime_checkable
class BlobStore(Protocol):
    """Blob store for bytes payloads (posters, attachments, etc.)."""

    def put_bytes(self, key: str, data: bytes) -> str:
        """Store bytes and return a stable identifier/path."""

    def get_bytes(self, key: str) -> Optional[bytes]:
        ...

    def delete(self, key: str) -> None:
        ...


@runtime_checkable
class DedupStore(Protocol):
    """A minimal "seen recently" store."""

    def is_duplicate(self, key: str) -> bool:
        ...

    def mark(self, key: str) -> None:
        ...


# ---------------------------------------------------------------------------
# Default implementations
# ---------------------------------------------------------------------------


class SQLiteKVStore:
    """KV store backed by core.persist_cache (SQLite table: kv_cache)."""

    def get_json(self, key: str) -> Optional[Any]:
        from core.cache import kv_cache_get_json

        return kv_cache_get_json(str(key))

    def set_json(self, key: str, value: Any, *, ttl_sec: int | None = None) -> None:
        from core.cache import kv_cache_set_json

        kv_cache_set_json(str(key), value, ttl_sec=ttl_sec)

    def delete(self, key: str) -> None:
        from core.cache import kv_cache_delete

        kv_cache_delete(str(key))

    def purge_expired(self, *, max_delete: int = 200) -> None:
        from core.cache import kv_cache_purge_expired

        kv_cache_purge_expired(max_delete=int(max_delete))


class AsyncSQLiteKVStore:
    """Async KV store backed by core.cache async wrappers.

    This prevents blocking the event loop when KV is used from async code paths.
    """

    async def get_json(self, key: str) -> Optional[Any]:
        from core.cache.persist_cache import kv_cache_get_json_async

        return await kv_cache_get_json_async(str(key))

    async def set_json(self, key: str, value: Any, *, ttl_sec: int | None = None) -> None:
        from core.cache.persist_cache import kv_cache_set_json_async

        await kv_cache_set_json_async(str(key), value, ttl_sec=ttl_sec)

    async def delete(self, key: str) -> None:
        from core.cache import kv_cache_delete

        await asyncio.to_thread(kv_cache_delete, str(key))

    async def purge_expired(self, *, max_delete: int = 200) -> None:
        from core.cache import kv_cache_purge_expired

        await asyncio.to_thread(kv_cache_purge_expired, max_delete=int(max_delete))


class MemoryKVStore:
    """Process-local KV store (best-effort fallback when SQLite isn't usable)."""

    def __init__(self, *, max_size: int = 5000) -> None:
        self._max = int(max_size or 0) if int(max_size or 0) > 0 else 5000
        self._lock = threading.Lock()
        # key -> (exp_ts, value)
        self._d: dict[str, tuple[float, Any]] = {}

    def _cleanup(self, now: float) -> None:
        # drop expired
        expired = [k for k, (exp, _) in self._d.items() if exp and exp <= now]
        for k in expired[:2000]:
            self._d.pop(k, None)
        # cap size
        if len(self._d) > self._max:
            # evict earliest-expiring first
            items = sorted(self._d.items(), key=lambda kv: kv[1][0] or float("inf"))
            for k, _ in items[: max(0, len(self._d) - self._max)]:
                self._d.pop(k, None)

    def get_json(self, key: str) -> Optional[Any]:
        k = str(key)
        now = time.time()
        with self._lock:
            self._cleanup(now)
            row = self._d.get(k)
            if not row:
                return None
            exp, v = row
            if exp and exp <= now:
                self._d.pop(k, None)
                return None
            return v

    def set_json(self, key: str, value: Any, *, ttl_sec: int | None = None) -> None:
        k = str(key)
        now = time.time()
        exp = 0.0
        if ttl_sec is not None:
            try:
                ttl = int(ttl_sec)
                if ttl > 0:
                    exp = now + float(ttl)
            except (ValueError, TypeError) as e:
                biz.detail(f"TTL 转换失败（已忽略）：ttl_sec={ttl_sec}，原因={type(e).__name__}")
                exp = 0.0
        with self._lock:
            self._cleanup(now)
            self._d[k] = (exp, value)

    def delete(self, key: str) -> None:
        with self._lock:
            self._d.pop(str(key), None)

    def purge_expired(self, *, max_delete: int = 200) -> None:
        # No-op-ish: cleanup already purges; still call it for symmetry.
        now = time.time()
        with self._lock:
            self._cleanup(now)


class AsyncMemoryKVStore:
    """Async façade over :class:`MemoryKVStore`.

    Operations are in-process and fast; we don't offload to threads.
    """

    def __init__(self, *, max_size: int = 5000) -> None:
        self._inner = MemoryKVStore(max_size=max_size)

    async def get_json(self, key: str) -> Optional[Any]:
        return self._inner.get_json(key)

    async def set_json(self, key: str, value: Any, *, ttl_sec: int | None = None) -> None:
        self._inner.set_json(key, value, ttl_sec=ttl_sec)

    async def delete(self, key: str) -> None:
        self._inner.delete(key)

    async def purge_expired(self, *, max_delete: int = 200) -> None:
        self._inner.purge_expired(max_delete=max_delete)


@dataclass
class FSBlobStore:
    """Filesystem blob store (best-effort)."""

    root: Path

    def _path_for(self, key: str) -> Path:
        h = hashlib.sha1(str(key).encode("utf-8", errors="ignore")).hexdigest()
        # shard into subdirs to avoid huge directory
        return self.root / h[:2] / h[2:4] / h

    def put_bytes(self, key: str, data: bytes) -> str:
        p = self._path_for(key)
        p.parent.mkdir(parents=True, exist_ok=True)
        # IMPORTANT: p is a sha1 hex filename without a suffix. Using
        # Path.with_suffix(".tmp") would produce a generic ".tmp" file in the
        # directory, causing collisions across different keys (and potential
        # corruption) under concurrency. Use an explicit temp filename.
        # Use a per-write unique temp file to avoid clobbering when the same key is written concurrently.
        tmp = p.parent / f"{p.name}.{uuid.uuid4().hex}.tmp"
        try:
            tmp.write_bytes(data)
            tmp.replace(p)
        finally:
            # If replace() fails, best-effort cleanup the temp file.
            try:
                tmp.unlink(missing_ok=True)
            except (OSError, PermissionError) as e:
                biz.detail(f"临时文件清理失败（已忽略）：文件={tmp}，原因={type(e).__name__}")
        return str(p)

    def get_bytes(self, key: str) -> Optional[bytes]:
        p = self._path_for(key)
        try:
            return p.read_bytes() if p.exists() else None
        except Exception:
            biz.detail(f"Blob 存储读取失败：{p}", exc_info=True)
            return None

    def delete(self, key: str) -> None:
        p = self._path_for(key)
        try:
            p.unlink(missing_ok=True)
        except Exception:
            biz.detail(f"Blob 存储删除失败：{p}", exc_info=True)


class KVBackedDedupStore:
    """Dedup store backed by a KVStore."""

    def __init__(self, kv: KVStore, *, ttl_seconds: int, key_prefix: str = "dedup:") -> None:
        self._kv = kv
        self._ttl = int(ttl_seconds)
        self._pfx = str(key_prefix or "dedup:")

    def _k(self, key: str) -> str:
        h = hashlib.sha1(str(key).encode("utf-8", errors="ignore")).hexdigest()
        return f"{self._pfx}{h}"

    def is_duplicate(self, key: str) -> bool:
        if not key or self._ttl == 0:
            return False
        try:
            return self._kv.get_json(self._k(key)) is not None
        except (ValueError, TypeError, KeyError) as e:
            biz.detail(f"去重检查失败（已忽略）：key={key}，原因={type(e).__name__}")
            return False

    def mark(self, key: str) -> None:
        if not key or self._ttl == 0:
            return
        ttl: int | None = None
        if self._ttl > 0:
            ttl = self._ttl
        try:
            self._kv.set_json(self._k(key), 1, ttl_sec=ttl)
        except (ValueError, TypeError) as e:
            biz.detail(f"去重标记失败（已忽略）：key={key}，原因={type(e).__name__}")


# ---------------------------------------------------------------------------
# Singletons (default wiring)
# ---------------------------------------------------------------------------


_KV_SINGLETON: KVStore | None = None
_ASYNC_KV_SINGLETON: AsyncKVStore | None = None
_BLOB_SINGLETON: BlobStore | None = None


def get_kv_store() -> KVStore:
    """Return the default KV store.

    Selection order:
      1) Settings.KV_STORE_BACKEND (ENV > .env > DEFAULT)
      2) Default: sqlite (auto-fallback to memory on failure)
    """

    # Prefer ctx-scoped stores (avoid module-level singletons).
    try:
        from ports.app_context import get_ctx_optional

        ctx = get_ctx_optional()
        if ctx is not None:
            v = getattr(ctx, "kv_store", None)
            if v is not None:
                return v
    except (AttributeError, RuntimeError) as e:
        biz.detail(f"获取上下文 KV 存储失败（已忽略）：原因={type(e).__name__}")

    global _KV_SINGLETON
    if _KV_SINGLETON is not None:
        return _KV_SINGLETON

    try:
        backend = str(getattr(_get_settings(), "KV_STORE_BACKEND", "") or "").strip().lower()
    except (AttributeError, ImportError) as e:
        biz.detail(f"获取 KV 存储配置失败（已忽略）：原因={type(e).__name__}")
        backend = ""
    backend = backend or "sqlite"

    if backend == "memory":
        _KV_SINGLETON = MemoryKVStore()
        return _KV_SINGLETON

    # Default: sqlite, but auto-fallback to memory if sqlite isn't usable.
    sqlite_store = SQLiteKVStore()
    try:
        # warm-up
        sqlite_store.get_json("__kv_probe__")
        _KV_SINGLETON = sqlite_store
        return _KV_SINGLETON
    except Exception:
        biz.warning("KV 存储：SQLite 后端不可用，回退到内存存储", exc_info=True)
        _KV_SINGLETON = MemoryKVStore()
        return _KV_SINGLETON


def get_kv_store_async() -> AsyncKVStore:
    """Return the default async KV store.

    This mirrors :func:`get_kv_store` selection logic but guarantees that
    underlying operations will not block the event loop.
    """

    # Prefer ctx-scoped stores (avoid module-level singletons).
    try:
        from ports.app_context import get_ctx_optional

        ctx = get_ctx_optional()
        if ctx is not None:
            v = getattr(ctx, "async_kv_store", None)
            if v is not None:
                return v
    except (AttributeError, RuntimeError) as e:
        biz.detail(f"获取上下文 Async KV 存储失败（已忽略）：原因={type(e).__name__}")

    global _ASYNC_KV_SINGLETON
    if _ASYNC_KV_SINGLETON is not None:
        return _ASYNC_KV_SINGLETON

    try:
        backend = str(getattr(_get_settings(), "KV_STORE_BACKEND", "") or "").strip().lower()
    except (AttributeError, ImportError) as e:
        biz.detail(f"获取 KV 存储配置失败（已忽略）：原因={type(e).__name__}")
        backend = ""
    backend = backend or "sqlite"

    if backend == "memory":
        _ASYNC_KV_SINGLETON = AsyncMemoryKVStore()
        return _ASYNC_KV_SINGLETON

    # Default: sqlite. No synchronous warm-up here to avoid accidentally
    # creating/running event loops in library code.
    _ASYNC_KV_SINGLETON = AsyncSQLiteKVStore()
    return _ASYNC_KV_SINGLETON


def get_blob_store() -> BlobStore:
    """Return a filesystem blob store (default)."""

    # Prefer ctx-scoped stores (avoid module-level singletons).
    try:
        from ports.app_context import get_ctx_optional

        ctx = get_ctx_optional()
        if ctx is not None:
            v = getattr(ctx, "blob_store", None)
            if v is not None:
                return v
    except (AttributeError, RuntimeError) as e:
        biz.detail(f"获取上下文 Blob 存储失败（已忽略）：原因={type(e).__name__}")

    global _BLOB_SINGLETON
    if _BLOB_SINGLETON is not None:
        return _BLOB_SINGLETON

    try:
        root = str(getattr(_get_settings(), "BLOB_STORE_DIR", "") or "").strip()
    except (AttributeError, ImportError) as e:
        biz.detail(f"获取 Blob 存储目录配置失败（已忽略）：原因={type(e).__name__}")
        root = ""
    root = root or "/data/blob_store"

    p = Path(root)
    try:
        p.mkdir(parents=True, exist_ok=True)
        # writability probe
        test = p / ".__writetest__"
        test.write_text("ok", encoding="utf-8")
        test.unlink(missing_ok=True)
    except Exception:
        fallback = Path("/tmp/emby_notifier_blob_store")
        try:
            fallback.mkdir(parents=True, exist_ok=True)
        except (OSError, PermissionError) as e:
            biz.detail(f"备用 Blob 目录创建失败（已忽略）：目录={fallback}，原因={type(e).__name__}")
        biz.warning("Blob 存储路径不可写，已回退", stage="blob_store", path=str(p), fallback=str(fallback), reason="not_writable")
        p = fallback

    _BLOB_SINGLETON = FSBlobStore(p)
    return _BLOB_SINGLETON
