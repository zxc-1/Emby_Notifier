"""Storage submodule - file system, blob store, and environment management.

This module consolidates storage-related functionality:
- Blob and KV stores (stores.py → blob_store.py)
- File system helpers (fs.py)
- File locking (file_lock.py)
- Environment file management (env_store.py)

Migration Guide:
    Old import path              → New import path
    ─────────────────────────────────────────────────
    from core.stores import ...  → from core.storage import ...
    from core.fs import ...      → from core.storage import ...
    from core.file_lock import ...  → from core.storage import ...
    from core.env_store import ...  → from core.storage import ...
"""

from core.storage.blob_store import (
    KVStore,
    AsyncKVStore,
    BlobStore,
    DedupStore,
    SQLiteKVStore,
    AsyncSQLiteKVStore,
    MemoryKVStore,
    AsyncMemoryKVStore,
    FSBlobStore,
    KVBackedDedupStore,
    get_kv_store,
    get_kv_store_async,
    get_blob_store,
)

from core.storage.fs import (
    load_json,
    save_json,
    load_env_file,
    dump_env_file,
)

from core.storage.file_lock import (
    file_lock,
)

from core.storage.env_store import (
    env_path,
    env_local_path,
    update_env_file,
    update_env_local,
)

__all__ = [
    # blob_store
    "KVStore",
    "AsyncKVStore",
    "BlobStore",
    "DedupStore",
    "SQLiteKVStore",
    "AsyncSQLiteKVStore",
    "MemoryKVStore",
    "AsyncMemoryKVStore",
    "FSBlobStore",
    "KVBackedDedupStore",
    "get_kv_store",
    "get_kv_store_async",
    "get_blob_store",
    # fs
    "load_json",
    "save_json",
    "load_env_file",
    "dump_env_file",
    # file_lock
    "file_lock",
    # env_store
    "env_path",
    "env_local_path",
    "update_env_file",
    "update_env_local",
]
