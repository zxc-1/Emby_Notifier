from __future__ import annotations

"""Cross-process advisory file lock.

We use this for small local persistence files (JSON, sqlite, cache metadata) to
avoid corruption when multiple processes may touch the same path.

Implementation (best-effort, cross-platform):
- POSIX: ``fcntl.flock`` on a dedicated lock file.
- Windows: ``msvcrt.locking`` on the first byte of the lock file.
- Fallback: no-op with a loud one-time warning.
"""

import time
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from core.logging import get_biz_logger

biz = get_biz_logger(__name__)
_WARNED_NO_LOCK = False


def _warn_no_lock_once(reason: str) -> None:
    global _WARNED_NO_LOCK
    if _WARNED_NO_LOCK:
        return
    _WARNED_NO_LOCK = True
    try:
        biz.warning(
            f"文件锁：建议性锁定已禁用（降级为无操作）。原因：{reason}。这可能导致并发写入损坏小型本地文件。",
            reason=reason,
        )
    except (OSError, ValueError) as e:
        biz.detail(f"文件锁警告日志输出失败（已忽略）：reason={reason}，原因={type(e).__name__}")


@contextmanager
def file_lock(lock_path: Path, *, timeout_sec: float = 10.0) -> Iterator[None]:
    """Acquire an exclusive advisory lock on ``lock_path`` (best-effort).

    ``timeout_sec``:
      - we spin with non-blocking lock first
      - when timeout elapses, we fall back to a blocking lock (to keep behavior deterministic)
    """
    lock_path.parent.mkdir(parents=True, exist_ok=True)

    # Use binary mode for Windows msvcrt locking compatibility.
    try:
        f = open(lock_path, "a+b")
    except OSError as e:
        _warn_no_lock_once(f"open_error={type(e).__name__}")
        yield
        return

    mode: str | None = None

    try:
        # 1) POSIX flock
        try:
            import fcntl  # type: ignore

            start = time.monotonic()
            while True:
                try:
                    fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                    mode = "fcntl"
                    break
                except BlockingIOError:
                    if (time.monotonic() - start) >= float(timeout_sec):
                        fcntl.flock(f.fileno(), fcntl.LOCK_EX)
                        mode = "fcntl"
                        break
                    time.sleep(0.05)
        except Exception as e_fcntl:
            # 2) Windows msvcrt locking on first byte
            try:
                import msvcrt  # type: ignore

                # Ensure file has at least 1 byte so we can lock that region.
                try:
                    f.seek(0, 2)
                    if f.tell() <= 0:
                        f.write(b"\0")
                        f.flush()
                except (OSError, ValueError) as e:
                    biz.detail(f"文件锁初始化失败（已忽略）：path={lock_path}，原因={type(e).__name__}")
                try:
                    f.seek(0)
                except (OSError, ValueError) as e:
                    biz.detail(f"文件指针重置失败（已忽略）：path={lock_path}，原因={type(e).__name__}")

                start = time.monotonic()
                while True:
                    try:
                        msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
                        mode = "msvcrt"
                        break
                    except OSError:
                        if (time.monotonic() - start) >= float(timeout_sec):
                            msvcrt.locking(f.fileno(), msvcrt.LK_LOCK, 1)
                            mode = "msvcrt"
                            break
                        time.sleep(0.05)
            except Exception as e2:
                _warn_no_lock_once(f"fcntl_error={type(e_fcntl).__name__}; msvcrt_error={type(e2).__name__}")
                mode = None

        yield

    finally:
        # Unlock (best-effort)
        try:
            if mode == "fcntl":
                try:
                    import fcntl  # type: ignore

                    fcntl.flock(f.fileno(), fcntl.LOCK_UN)
                except (OSError, ValueError) as e:
                    biz.detail(f"fcntl 文件锁释放失败（已忽略）：path={lock_path}，原因={type(e).__name__}")
            elif mode == "msvcrt":
                try:
                    import msvcrt  # type: ignore

                    try:
                        f.seek(0)
                    except (OSError, ValueError) as e:
                        biz.detail(f"msvcrt 文件指针重置失败（已忽略）：path={lock_path}，原因={type(e).__name__}")
                    msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
                except (OSError, ValueError) as e:
                    biz.detail(f"msvcrt 文件锁释放失败（已忽略）：path={lock_path}，原因={type(e).__name__}")
        finally:
            try:
                f.close()
            except OSError as e:
                biz.detail(f"文件锁文件关闭失败（已忽略）：path={lock_path}，原因={type(e).__name__}")
