from __future__ import annotations

from core.exceptions.base import ConfigurationError

import asyncio
import logging
from core.logging import get_biz_logger
from typing import Awaitable, Callable, Optional, Set

from core.logging import get_kind, get_trace_id

biz = get_biz_logger(__name__)


class TaskRegistry:
    """A lightweight background task registry.

    Motivation:
    - Collect background tasks created ad-hoc across the app (e.g. aggregator flush tasks)
    - Provide a single shutdown hook to cancel/await them to avoid dangling tasks on exit.

    This is intentionally simpler than asyncio.TaskGroup:
    - tasks can be created any time (not limited to a single 'async with' scope)
    - shutdown() cancels and awaits all known tasks
    """

    def __init__(self) -> None:
        self._tasks: Set[asyncio.Task] = set()
        self._lock = asyncio.Lock()
        self._closed = False

    async def create_task(self, coro: Awaitable, *, name: Optional[str] = None) -> asyncio.Task:
        if self._closed:
            raise ConfigurationError("TaskRegistry is closed")

        task = asyncio.create_task(coro, name=name)
        async with self._lock:
            self._tasks.add(task)

        def _done_cb(t: asyncio.Task) -> None:
            try:
                # Avoid 'Task exception was never retrieved' noise.
                exc = t.exception()
                if exc is not None and not isinstance(exc, asyncio.CancelledError):
                    biz.detail(f"后台任务失败：{exc}", exc_info=True)
            except asyncio.CancelledError:
                pass
            except Exception:
                biz.detail("后台任务完成回调异常", exc_info=True)
            finally:
                # Best-effort removal (non-async; lockless but ok because set.discard is atomic enough under GIL).
                try:
                    self._tasks.discard(t)
                except (RuntimeError, KeyError) as e:
                    biz.detail(f"后台任务移除失败（已忽略）：任务名={t.get_name() if hasattr(t, 'get_name') else 'unknown'}，原因={type(e).__name__}")

        task.add_done_callback(_done_cb)
        return task

    async def shutdown(self, *, timeout: float = 20.0) -> None:
        """Cancel and await all tasks."""
        self._closed = True

        async with self._lock:
            tasks = list(self._tasks)

        if not tasks:
            return

        for t in tasks:
            try:
                t.cancel()
            except Exception:
                biz.detail("任务取消失败", exc_info=True)

        try:
            await asyncio.wait_for(asyncio.gather(*tasks, return_exceptions=True), timeout=timeout)
        except asyncio.TimeoutError:
            biz.warning(f"TaskRegistry 关闭超时：仍有 {len(tasks)} 个任务未完成", task_count=len(tasks))
        except Exception:
            biz.detail("TaskRegistry 关闭异常", exc_info=True)

        async with self._lock:
            self._tasks.clear()


def create_task_logged(coro: Awaitable, *, name: Optional[str] = None, log: Optional[logging.Logger] = None) -> asyncio.Task:
    """Create a background task with exception logging.

    Use this for fire-and-forget tasks when you don't have easy access to a
    TaskRegistry instance.
    """

    # Capture current context at creation time (ContextVars are copied into the new task).
    user_flow = (get_kind() or '').lower() == 'user'
    trace_id = get_trace_id()

    async def _runner():
        if user_flow:
            title = str(name or '后台任务')
            with biz.entry(
                domain="Task",
                action=title,
                group_title=f"任务 {title}",
                task=name or '',
                trace_id=trace_id or None,
            ):
                return await coro
        return await coro

    task = asyncio.create_task(_runner(), name=name)
    _log = log or biz

    def _done_cb(t: asyncio.Task) -> None:
        try:
            exc = t.exception()
            if exc is not None and not isinstance(exc, asyncio.CancelledError):
                _log.detail(f"后台任务失败：{exc}", exc_info=True)
        except asyncio.CancelledError:
            pass
        except Exception:
            _log.detail("后台任务完成回调异常", exc_info=True)

    task.add_done_callback(_done_cb)
    return task
