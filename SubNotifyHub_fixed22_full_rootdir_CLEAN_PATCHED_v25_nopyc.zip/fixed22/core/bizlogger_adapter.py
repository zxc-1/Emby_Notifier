"""DEPRECATED: Use core.logging.bizlogger_adapter instead.

This module is maintained for backward compatibility only.
Please update your imports to use the new path:

    # Old (deprecated):
    from core.logging import BizLoggerAdapter, get_biz_logger_adapter

    # New (recommended):
    from core.logging import BizLoggerAdapter, get_biz_logger_adapter
"""

from __future__ import annotations

import warnings

warnings.warn(
    "Importing from 'core.bizlogger_adapter' is deprecated. "
    "Use 'from core.logging import BizLoggerAdapter, get_biz_logger_adapter' instead.",
    DeprecationWarning,
    stacklevel=2,
)

# Re-export everything from the new location for backward compatibility
from core.logging.bizlogger_adapter import (
    BizLoggerAdapter,
    get_biz_logger_adapter,
)

__all__ = [
    "BizLoggerAdapter",
    "get_biz_logger_adapter",
]
