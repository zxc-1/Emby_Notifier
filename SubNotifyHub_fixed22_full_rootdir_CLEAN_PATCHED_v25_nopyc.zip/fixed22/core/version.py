from __future__ import annotations

"""Single source of truth for the app version.

We intentionally keep version here (instead of scattering across pyproject/Settings)
to avoid drift.

- Build/packaging may set EMBY_NOTIFIER_VERSION to override at runtime.
- Otherwise fall back to __version__ below.
"""

from core.env_utils import env_str

__version__ = "1.6.17.86_tmdb_softcap_tiebreak_p0p1p2d2"


def get_version() -> str:
    # Prefer explicit env overrides (used by build/packaging).
    v = env_str("SUBNOTIFYHUB_VERSION", "").strip() or env_str("SUB_NOTIFY_HUB_VERSION", "").strip()
    if v:
        return v
    v = env_str("EMBY_NOTIFIER_VERSION", "").strip()
    if v:
        return v
    # Backward-compatible envs:
    v = env_str("APP_VERSION", "").strip()
    if v:
        return v
    return __version__
