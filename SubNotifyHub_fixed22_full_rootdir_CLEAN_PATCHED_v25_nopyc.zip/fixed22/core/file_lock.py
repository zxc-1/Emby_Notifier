"""Backward compatibility layer for core.file_lock.

This module re-exports all symbols from core.storage.file_lock for backward compatibility.
New code should import directly from core.storage.

Migration Guide:
    Old: from core.storage import file_lock
    New: from core.storage import file_lock
"""

import warnings

warnings.warn(
    "Importing from 'core.file_lock' is deprecated. "
    "Use 'from core.storage import file_lock' instead.",
    DeprecationWarning,
    stacklevel=2,
)

from core.storage.file_lock import (
    file_lock,
    _warn_no_lock_once,
    _WARNED_NO_LOCK,
)

__all__ = [
    "file_lock",
]
