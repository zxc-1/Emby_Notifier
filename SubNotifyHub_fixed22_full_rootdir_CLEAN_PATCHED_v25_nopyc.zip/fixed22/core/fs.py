from __future__ import annotations

"""Small file-system helpers.

Design goals:
- Defensive: never crash the runtime because of a bad/missing file.
- Atomic-ish writes: write to a tmp file then replace.
- Safe .env writing: minimal quoting/escaping so values with spaces/#/newlines won't break.

This module is intentionally dependency-free so it can be reused by both the API
layer (admin UI) and background workers.
"""

import json
import os
import logging
from core.logging import get_biz_logger_adapter
import re
from pathlib import Path
from typing import Any, Dict, List, Tuple

logger = get_biz_logger_adapter(__name__)

__all__ = [
    "load_json",
    "save_json",
    "load_env_file",
    "dump_env_file",
]


def load_json(path: Path, default: Any) -> Any:
    """Read JSON from disk.

    Defensive by default: returns *default* on any error.
    """
    try:
        if not path.exists():
            return default
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        logger.detail("load_json failed：操作异常：%s", path, exc_info=True)
        return default


def save_json(path: Path, data: Any) -> bool:
    """Atomic-ish JSON write (write tmp then replace).

    Returns:
        True if write succeeds, False otherwise.
    """
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_suffix(path.suffix + ".tmp")
        tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
        tmp.replace(path)
        try:
            os.chmod(path, 0o600)
        except (OSError, PermissionError) as e:
            logger.detail(f"文件权限设置失败（已忽略） - 文件={path}, 原因={type(e).__name__}")
        return True
    except Exception:
        # Best-effort; do not crash runtime by default.
        logger.detail("save_json failed：操作异常：%s", path, exc_info=True)
        return False


def _decode_env_value(v: str) -> str:
    """Decode a dotenv value into a plain string.

    Supports:
      - unquoted: KEY=value
      - quoted: KEY="value with spaces" or KEY='literal'
      - basic escapes in double quotes: \n \r \t \\ \"
    """
    raw = v.strip()
    if len(raw) >= 2 and ((raw[0] == raw[-1] == '"') or (raw[0] == raw[-1] == "'")):
        quote = raw[0]
        inner = raw[1:-1]
        if quote == '"':
            def _rep(m: re.Match[str]) -> str:
                ch = m.group(1)
                return {"n": "\n", "r": "\r", "t": "\t", "\\": "\\", '"': '"'}.get(ch, ch)

            inner = re.sub(r"\\([nrt\\\"])", _rep, inner)
        return inner
    return raw


def _encode_env_value(v: str) -> str:
    """Encode a value for safe dotenv writing.

    If the value contains characters that are meaningful in .env syntax
    (spaces, #, quotes, newlines, leading/trailing spaces), we wrap it in
    double quotes and escape a minimal set.
    """
    s = "" if v is None else str(v)
    if s == "":
        return ""

    needs_quote = False
    if s.strip() != s:
        needs_quote = True
    if any(c in s for c in [" ", "#", "\n", "\r", "\t", '"']):
        needs_quote = True

    if not needs_quote:
        return s

    escaped = (
        s.replace("\\", "\\\\")
        .replace("\n", "\\n")
        .replace("\r", "\\r")
        .replace("\t", "\\t")
        .replace('"', "\\\"")
    )
    return f'"{escaped}"'



def _strip_inline_comment(v: str) -> str:
    """Strip dotenv inline comments.

    Rules (aligned with common dotenv behavior and our requirements):
      - Only treat "#" as a comment delimiter when it's *not* inside quotes AND
        it is preceded by whitespace (so KEY=a#b is preserved).
      - For quoted values, keep "#" inside quotes (KEY="a#b" #comment -> a#b).
    """
    s = (v or "").rstrip()
    if not s:
        return s

    in_squote = False
    in_dquote = False
    escaped = False

    for i, ch in enumerate(s):
        # Escape handling is only relevant inside double quotes.
        if in_dquote and ch == "\\" and not escaped:
            escaped = True
            continue

        if escaped:
            escaped = False
            continue

        if ch == "'" and not in_dquote:
            in_squote = not in_squote
            continue
        if ch == '"' and not in_squote:
            in_dquote = not in_dquote
            continue

        if ch == "#" and not in_squote and not in_dquote:
            if i == 0 or s[i - 1].isspace():
                return s[:i].rstrip()

    return s

def load_env_file(path: Path) -> Dict[str, str]:
    """Load a dotenv-like file into a key-value mapping."""
    data: Dict[str, str] = {}
    if not path.exists():
        return data

    for raw in path.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        # support: export KEY=VALUE
        if line.lower().startswith("export "):
            line = line[7:].strip()
        k, v = line.split("=", 1)
        v_clean = _strip_inline_comment(v.strip())
        data[k.strip()] = _decode_env_value(v_clean)
    return data


def dump_env_file(path: Path, data: Dict[str, str]) -> None:
    """Write .env while preserving existing comments/blank lines/order.

    Strategy:
    - If file doesn't exist: write keys in deterministic order.
    - If exists: replace only known keys, delete removed keys, preserve unknown lines.
    - Append new keys at bottom with a marker comment.

    NOTE: values are encoded with minimal quoting/escaping to avoid breaking dotenv syntax.
    """
    try:
        path.parent.mkdir(parents=True, exist_ok=True)

        def _kv_line(k: str, v: str, prefix: str = "") -> str:
            return f"{prefix}{k}={_encode_env_value(v)}"

        if not path.exists():
            lines = [_kv_line(k, v) for k, v in sorted(data.items())]
            # NOTE: Path.with_suffix() is problematic for dotfiles like ".env"
            # where suffix == "" and would create a generic ".tmp". Use an
            # explicit temp filename to avoid collisions.
            tmp = path.parent / (path.name + ".tmp")
            tmp.write_text("\n".join(lines) + "\n", encoding="utf-8")
            try:
                os.chmod(tmp, 0o600)
            except (OSError, PermissionError) as e:
                logger.detail(f"临时文件权限设置失败（已忽略） - 文件={tmp}, 原因={type(e).__name__}")
            tmp.replace(path)
            try:
                os.chmod(path, 0o600)
            except (OSError, PermissionError) as e:
                logger.detail(f"文件权限设置失败（已忽略） - 文件={path}, 原因={type(e).__name__}")
            return

        try:
            os.chmod(path, 0o600)
        except (OSError, PermissionError) as e:
            # chmod failure should not abort rewriting the file; this can happen
            # on some filesystems (e.g. read-only mounts / Windows binds).
            logger.detail(f"文件权限设置失败（已忽略） - 文件={path}, 原因={type(e).__name__}")

        raw_lines = path.read_text(encoding="utf-8").splitlines(keepends=False)

        key_line_re = re.compile(
            r"^(?P<prefix>\s*(?:export\s+)?)(?P<key>[A-Za-z_][A-Za-z0-9_]*)\s*=\s*(?P<val>.*)$"
        )

        out: List[str] = []
        seen: Dict[str, bool] = {}
        for raw in raw_lines:
            m = key_line_re.match(raw)
            if not m:
                out.append(raw)
                continue

            key = m.group("key")
            prefix = m.group("prefix") or ""

            if key in data:
                out.append(_kv_line(key, data[key], prefix=prefix))
                seen[key] = True
            else:
                # key removed: drop line
                continue

        new_items: List[Tuple[str, str]] = [(k, v) for k, v in data.items() if not seen.get(k)]
        if new_items:
            if out and out[-1].strip() != "":
                out.append("")
            out.append("# Added by admin UI")
            for k, v in sorted(new_items):
                out.append(_kv_line(k, v))

        # See note above about dotfiles.
        tmp = path.parent / (path.name + ".tmp")
        tmp.write_text("\n".join(out) + "\n", encoding="utf-8")
        tmp.replace(path)
        try:
            os.chmod(path, 0o600)
        except (OSError, PermissionError) as e:
            logger.detail(f"文件权限设置失败（已忽略） - 文件={path}, 原因={type(e).__name__}")
    except Exception:
        logger.fail("dump_env_file failed：操作异常：%s", path, exc_info=True)
