"""DEPRECATED: Use core.cache.poster_cache_fetch instead.

This module is maintained for backward compatibility only.
Please update your imports to use the new path:

    # Old (deprecated):
    from core.cache import download_image_bytes

    # New (recommended):
    from core.cache import download_image_bytes
"""

from __future__ import annotations

import warnings

warnings.warn(
    "Importing from 'core.poster_cache_fetch' is deprecated. "
    "Use 'from core.cache import download_image_bytes' instead.",
    DeprecationWarning,
    stacklevel=2,
)

# Re-export everything from the new location for backward compatibility
from core.cache.poster_cache_fetch import (
    download_image_bytes,
    logger,
)

__all__ = [
    "download_image_bytes",
    "logger",
]
