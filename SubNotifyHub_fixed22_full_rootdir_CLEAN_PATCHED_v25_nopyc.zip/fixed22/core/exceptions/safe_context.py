"""安全上下文管理器模块。
from core.logging import get_biz_logger_adapter

_biz = get_biz_logger_adapter(__name__)

提供统一的异常处理上下文管理器，支持同步和异步代码块。
集成 BizLogger 记录异常，支持可配置的异常类型、默认值和回调函数。

Requirements: 1.2
"""

from __future__ import annotations

import logging
import time
import uuid
from contextlib import contextmanager, asynccontextmanager
from dataclasses import dataclass, field
from typing import Any, Callable, Iterator, Optional, Tuple, Type, TypeVar, AsyncIterator

from core.logging import get_biz_logger
from core.exceptions.mapping import get_exception_category
from core.logging import get_span_id, get_trace_id

T = TypeVar("T")

# 默认日志记录器
_logger = get_biz_logger(__name__)


def _generate_error_id() -> str:
    """生成唯一的错误 ID。"""
    return uuid.uuid4().hex[:8]


@dataclass
class ErrorContext:
    """异常上下文信息。
    
    包含异常发生时的完整上下文，用于日志记录和问题追踪。
    
    Attributes:
        error_id: 唯一错误 ID（8 字符十六进制）
        module: 模块路径
        function: 函数名或上下文名称
        category: 异常类别（network, database, validation 等）
        message: 错误消息
        timestamp: 时间戳（Unix 时间）
        span_id: 链路追踪 span ID
        trace_id: 追踪 ID
        extra: 额外业务上下文信息
    """
    error_id: str
    module: str
    function: str
    category: str
    message: str
    timestamp: float
    span_id: Optional[str] = None
    trace_id: Optional[str] = None
    extra: dict[str, Any] = field(default_factory=dict)
    
    def to_dict(self) -> dict[str, Any]:
        """转换为字典格式。"""
        return {
            "error_id": self.error_id,
            "module": self.module,
            "function": self.function,
            "category": self.category,
            "message": self.message,
            "timestamp": self.timestamp,
            "span_id": self.span_id,
            "trace_id": self.trace_id,
            **self.extra,
        }


def _build_error_context(
    exc: Exception,
    context_name: str,
    error_id: str,
    extra: Optional[dict[str, Any]] = None,
) -> ErrorContext:
    """构建异常上下文信息。
    
    Args:
        exc: 捕获的异常
        context_name: 上下文名称
        error_id: 唯一错误 ID
        extra: 额外上下文信息
        
    Returns:
        ErrorContext 实例
    """
    return ErrorContext(
        error_id=error_id,
        module=__name__,
        function=context_name,
        category=get_exception_category(exc),
        message=str(exc),
        timestamp=time.time(),
        span_id=get_span_id() or None,
        trace_id=get_trace_id() or None,
        extra=extra or {},
    )


def _handle_context_exception(
    exc: Exception,
    context_name: str,
    error_id: str,
    log_level: str,
    include_traceback: bool,
    on_error: Optional[Callable[[Exception], None]],
    extra: Optional[dict[str, Any]] = None,
) -> ErrorContext:
    """统一处理上下文管理器中的异常。
    
    Args:
        exc: 捕获的异常
        context_name: 上下文名称
        error_id: 唯一错误 ID
        log_level: 日志级别
        include_traceback: 是否包含堆栈跟踪
        on_error: 错误回调函数
        extra: 额外上下文信息
        
    Returns:
        ErrorContext 实例
    """
    # 构建错误上下文
    error_ctx = _build_error_context(exc, context_name, error_id, extra)
    
    # 获取异常类别
    category = error_ctx.category
    
    # 构建日志上下文
    log_kv = {
        "error_id": error_id,
        "module": error_ctx.module,
        "function": context_name,
        "category": category,
        "span_id": error_ctx.span_id or "",
        "trace_id": error_ctx.trace_id or "",
        "exc_type": type(exc).__name__,
    }
    
    # 合并额外上下文
    if extra:
        log_kv.update(extra)
    
    # 构建日志消息
    msg = f"异常捕获 [{error_id}] {context_name}: {type(exc).__name__}: {exc}"
    
    # 根据日志级别记录
    level = log_level.lower()
    if level == "debug":
        _biz.detail(msg, **log_kv, stage="safe_context")
    elif level == "info":
        _biz.detail(msg, **log_kv, stage="safe_context", severity="info")
    elif level == "warning":
        _logger.warning(msg, **log_kv)
    elif level == "critical":
        _biz.fail(msg, **log_kv, stage="safe_context", exc_info=include_traceback)
    else:  # error (default)
        if include_traceback:
            _logger.fail(msg, exc=exc, **log_kv)
        else:
            _logger.fail(msg, **log_kv)
    
    # 调用错误回调
    if on_error is not None:
        try:
            on_error(exc)
        except Exception as callback_exc:
            _biz.warning(
                f"错误回调执行失败 [{error_id}]: {callback_exc}",
                error_id=error_id,
                callback_error=str(callback_exc),
                stage="safe_context_callback",
            )
    
    return error_ctx


class SafeContextResult:
    """安全上下文的结果容器。
    
    用于在上下文管理器中传递结果和异常信息。
    
    Attributes:
        value: 上下文块的结果值
        exception: 捕获的异常（如果有）
        error_context: 异常上下文信息（如果有异常）
        success: 是否成功执行（无异常）
    """
    
    def __init__(self, default: Any = None) -> None:
        self._default = default
        self._value: Any = default
        self._exception: Optional[Exception] = None
        self._error_context: Optional[ErrorContext] = None
    
    @property
    def value(self) -> Any:
        """获取结果值。如果发生异常，返回默认值。"""
        return self._value
    
    @value.setter
    def value(self, val: Any) -> None:
        """设置结果值。"""
        self._value = val
    
    @property
    def exception(self) -> Optional[Exception]:
        """获取捕获的异常。"""
        return self._exception
    
    @property
    def error_context(self) -> Optional[ErrorContext]:
        """获取异常上下文信息。"""
        return self._error_context
    
    @property
    def success(self) -> bool:
        """是否成功执行（无异常）。"""
        return self._exception is None
    
    def _set_exception(self, exc: Exception, ctx: ErrorContext) -> None:
        """内部方法：设置异常和上下文。"""
        self._exception = exc
        self._error_context = ctx
        self._value = self._default


@contextmanager
def safe_context(
    *,
    catch: Tuple[Type[Exception], ...] = (Exception,),
    default: Any = None,
    on_error: Optional[Callable[[Exception], None]] = None,
    context_name: str = "unknown",
    log_level: str = "error",
    include_traceback: bool = True,
    extra: Optional[dict[str, Any]] = None,
) -> Iterator[SafeContextResult]:
    """安全上下文管理器，用于包装代码块。
    
    捕获指定类型的异常，记录日志，执行回调，并提供结果容器。
    
    Args:
        catch: 要捕获的异常类型元组，默认为 (Exception,)
        default: 异常时的默认返回值，默认为 None
        on_error: 异常时的回调函数，接收异常对象作为参数
        context_name: 上下文名称，用于日志记录
        log_level: 日志级别，可选 "debug", "info", "warning", "error", "critical"
        include_traceback: 是否在日志中包含堆栈跟踪，默认为 True
        extra: 额外的上下文信息字典
        
    Yields:
        SafeContextResult: 结果容器，可用于获取执行结果和异常信息
        
    Example:
        # 基本用法
        with safe_context(catch=(ValueError,), default=[], context_name="parse_data") as result:
            result.value = parse_data(raw)
        
        if result.success:
            print(f"解析成功: {result.value}")
        else:
            print(f"解析失败: {result.exception}")
        
        # 简单用法（不关心结果）
        with safe_context(catch=(IOError,), context_name="write_file"):
            write_to_file(data)
    
    Requirements:
        - 1.2: 提供 safe_context 上下文管理器
    """
    error_id = _generate_error_id()
    result = SafeContextResult(default=default)
    
    try:
        yield result
    except catch as e:
        error_ctx = _handle_context_exception(
            e, context_name, error_id, log_level, include_traceback, on_error, extra
        )
        result._set_exception(e, error_ctx)


@asynccontextmanager
async def async_safe_context(
    *,
    catch: Tuple[Type[Exception], ...] = (Exception,),
    default: Any = None,
    on_error: Optional[Callable[[Exception], None]] = None,
    context_name: str = "unknown",
    log_level: str = "error",
    include_traceback: bool = True,
    extra: Optional[dict[str, Any]] = None,
) -> AsyncIterator[SafeContextResult]:
    """异步版本的安全上下文管理器。
    
    与 safe_context 功能相同，但支持在异步代码中使用。
    
    Args:
        catch: 要捕获的异常类型元组，默认为 (Exception,)
        default: 异常时的默认返回值，默认为 None
        on_error: 异常时的回调函数，接收异常对象作为参数
        context_name: 上下文名称，用于日志记录
        log_level: 日志级别，可选 "debug", "info", "warning", "error", "critical"
        include_traceback: 是否在日志中包含堆栈跟踪，默认为 True
        extra: 额外的上下文信息字典
        
    Yields:
        SafeContextResult: 结果容器，可用于获取执行结果和异常信息
        
    Example:
        async with async_safe_context(catch=(httpx.TimeoutException,), 
                                       context_name="fetch_data") as result:
            result.value = await fetch_data(url)
        
        if result.success:
            process(result.value)
        else:
            use_fallback()
    
    Requirements:
        - 1.2: 提供 safe_context 上下文管理器（异步版本）
    """
    error_id = _generate_error_id()
    result = SafeContextResult(default=default)
    
    try:
        yield result
    except catch as e:
        error_ctx = _handle_context_exception(
            e, context_name, error_id, log_level, include_traceback, on_error, extra
        )
        result._set_exception(e, error_ctx)