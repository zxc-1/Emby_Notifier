"""Exceptions submodule - unified exception handling.

This module consolidates exception-related functionality:
- Base exceptions (exceptions.py → base.py)
- Exception mapping (exception_mapping.py → mapping.py)
- Exception metrics (exception_metrics.py → metrics.py)
- Safe call decorator (safe_call.py)
- Safe context manager (safe_context.py)
- Recovery strategies (recovery.py)
- Database exception handler (db_exception_handler.py → db_handler.py)

Migration Guide:
    Old import path                      → New import path
    ─────────────────────────────────────────────────────────────
    from core.exceptions import ...      → from core.exceptions import ...
    from core.exception_mapping import ...  → from core.exceptions import ...
    from core.exception_metrics import ...  → from core.exceptions import ...
    from core.safe_call import ...       → from core.exceptions import ...
    from core.safe_context import ...    → from core.exceptions import ...
    from core.recovery import ...        → from core.exceptions import ...
    from core.db_exception_handler import ...  → from core.exceptions import ...
"""

from core.exceptions.base import (
    AppException,
    NetworkError,
    DatabaseError,
    ValidationError,
    ConfigurationError,
    ExternalServiceError,
)

from core.exceptions.mapping import (
    EXCEPTION_MAPPING,
    map_exception,
    get_exception_category,
)

from core.exceptions.metrics import (
    ExceptionMetrics,
    exception_metrics,
    record_exception,
    get_exception_counts,
    get_exception_summary,
    EXCEPTION_THRESHOLD,
)

from core.exceptions.safe_call import (
    safe_call,
    _generate_error_id,
    _get_function_info,
)

from core.exceptions.safe_context import (
    ErrorContext,
    SafeContextResult,
    safe_context,
    async_safe_context,
    _build_error_context,
)

from core.exceptions.recovery import (
    CircuitState,
    RetryStrategy,
    CircuitBreaker,
    CircuitBreakerOpenError,
    with_retry,
)

from core.exceptions.db_handler import (
    RETRYABLE_DB_EXCEPTIONS,
    NON_RETRYABLE_DB_EXCEPTIONS,
    is_retryable_db_exception,
    is_integrity_error,
    DatabaseRetryStrategy,
    with_db_retry,
    db_safe_context,
    async_db_safe_context,
)


__all__ = [
    # base
    "AppException",
    "NetworkError",
    "DatabaseError",
    "ValidationError",
    "ConfigurationError",
    "ExternalServiceError",
    # mapping
    "EXCEPTION_MAPPING",
    "map_exception",
    "get_exception_category",
    # metrics
    "ExceptionMetrics",
    "exception_metrics",
    "record_exception",
    "get_exception_counts",
    "get_exception_summary",
    "EXCEPTION_THRESHOLD",
    # safe_call
    "safe_call",
    "_generate_error_id",
    "_get_function_info",
    # safe_context
    "ErrorContext",
    "SafeContextResult",
    "safe_context",
    "async_safe_context",
    "_build_error_context",
    # recovery
    "CircuitState",
    "RetryStrategy",
    "CircuitBreaker",
    "CircuitBreakerOpenError",
    "with_retry",
    # db_handler
    "RETRYABLE_DB_EXCEPTIONS",
    "NON_RETRYABLE_DB_EXCEPTIONS",
    "is_retryable_db_exception",
    "is_integrity_error",
    "DatabaseRetryStrategy",
    "with_db_retry",
    "db_safe_context",
    "async_db_safe_context",
]
