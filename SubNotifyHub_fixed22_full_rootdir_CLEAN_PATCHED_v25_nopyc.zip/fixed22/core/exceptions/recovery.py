from __future__ import annotations
from core.exceptions.base import ExternalServiceError

"""恢复策略模块。

提供重试策略、熔断器和重试装饰器，用于处理可恢复的异常。
支持指数退避、最大重试次数、熔断器状态管理等功能。

Requirements: 5.1, 5.2, 5.3
"""


import asyncio
import inspect
import time
from dataclasses import dataclass, field
from enum import Enum
from functools import wraps
from threading import Lock
from typing import Any, Callable, Optional, Tuple, Type, TypeVar

from core.logging import get_biz_logger
from core.exceptions.mapping import get_exception_category

T = TypeVar("T")
F = TypeVar("F", bound=Callable[..., Any])

_logger = get_biz_logger(__name__)


class CircuitState(Enum):
    """熔断器状态枚举。"""
    CLOSED = "closed"      # 正常状态，允许请求通过
    OPEN = "open"          # 熔断状态，拒绝所有请求
    HALF_OPEN = "half-open"  # 半开状态，允许部分请求测试


@dataclass
class RetryStrategy:
    """重试策略配置。"""
    max_retries: int = 3
    backoff_base: float = 1.0
    backoff_max: float = 30.0
    retryable_exceptions: Tuple[Type[Exception], ...] = (Exception,)
    
    def get_delay(self, attempt: int) -> float:
        """计算指数退避延迟。"""
        delay = self.backoff_base * (2 ** attempt)
        return min(delay, self.backoff_max)
    
    def should_retry(self, exc: Exception, attempt: int) -> bool:
        """判断是否应该重试。"""
        if attempt >= self.max_retries:
            return False
        return isinstance(exc, self.retryable_exceptions)


@dataclass
class CircuitBreaker:
    """熔断器实现。"""
    failure_threshold: int = 5
    recovery_timeout: float = 30.0
    name: str = "default"
    
    _failures: int = field(default=0, init=False, repr=False)
    _last_failure_time: Optional[float] = field(default=None, init=False, repr=False)
    _state: CircuitState = field(default=CircuitState.CLOSED, init=False, repr=False)
    _lock: Lock = field(default_factory=Lock, init=False, repr=False)
    
    @property
    def state(self) -> CircuitState:
        with self._lock:
            return self._state
    
    @property
    def failures(self) -> int:
        with self._lock:
            return self._failures
    
    def record_failure(self) -> None:
        with self._lock:
            self._failures += 1
            self._last_failure_time = time.time()
            if self._failures >= self.failure_threshold:
                if self._state != CircuitState.OPEN:
                    _logger.warning(f"熔断器 [{self.name}] 触发熔断",
                        circuit_name=self.name, failures=self._failures, threshold=self.failure_threshold)
                self._state = CircuitState.OPEN
    
    def record_success(self) -> None:
        with self._lock:
            old_state = self._state
            self._failures = 0
            self._state = CircuitState.CLOSED
            if old_state == CircuitState.HALF_OPEN:
                _logger.ok(f"✅ 熔断器 [{self.name}] 恢复正常：测试请求成功，已切换回正常状态", circuit_name=self.name)
    
    def can_execute(self) -> bool:
        with self._lock:
            if self._state == CircuitState.CLOSED:
                return True
            if self._state == CircuitState.OPEN:
                if self._last_failure_time is not None:
                    elapsed = time.time() - self._last_failure_time
                    if elapsed >= self.recovery_timeout:
                        self._state = CircuitState.HALF_OPEN
                        _logger.detail(f"ℹ️ 熔断器 [{self.name}] 进入半开状态：恢复超时已过，将尝试测试请求", circuit_name=self.name, 已等待秒数=round(elapsed, 1), stage="circuit_half_open")
                        return True
                return False
            return True
    
    def reset(self) -> None:
        with self._lock:
            self._failures = 0
            self._last_failure_time = None
            self._state = CircuitState.CLOSED


class CircuitBreakerOpenError(Exception):
    """熔断器打开时抛出的异常。"""
    def __init__(self, circuit_name: str):
        super().__init__(f"Circuit breaker '{circuit_name}' is open")
        self.circuit_name = circuit_name


def with_retry(
    *,
    strategy: Optional[RetryStrategy] = None,
    circuit_breaker: Optional[CircuitBreaker] = None,
    on_retry: Optional[Callable[[Exception, int], None]] = None,
    on_failure: Optional[Callable[[Exception], None]] = None,
) -> Callable[[F], F]:
    """重试装饰器。"""
    if strategy is None:
        strategy = RetryStrategy()
    
    def decorator(func: F) -> F:
        if inspect.iscoroutinefunction(func):
            @wraps(func)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                if circuit_breaker is not None and not circuit_breaker.can_execute():
                    raise CircuitBreakerOpenError(circuit_breaker.name)
                last_exception: Optional[Exception] = None
                for attempt in range(strategy.max_retries + 1):
                    try:
                        result = await func(*args, **kwargs)
                        if circuit_breaker is not None:
                            circuit_breaker.record_success()
                        return result
                    except strategy.retryable_exceptions as e:
                        last_exception = e
                        if circuit_breaker is not None:
                            circuit_breaker.record_failure()
                        if not strategy.should_retry(e, attempt):
                            break
                        delay = strategy.get_delay(attempt)
                        if on_retry is not None:
                            try:
                                on_retry(e, attempt)
                            except (RuntimeError, ValueError, TypeError):
                                pass
                        _logger.warning(f"重试 [{func.__name__}] 第 {attempt + 1} 次，延迟 {delay:.2f}s",
                            function=func.__name__, attempt=attempt + 1, delay=delay, exc_type=type(e).__name__)
                        await asyncio.sleep(delay)
                if last_exception is not None:
                    if on_failure is not None:
                        try:
                            on_failure(last_exception)
                        except (RuntimeError, ValueError, TypeError):
                            pass
                    _logger.fail(f"重试耗尽 [{func.__name__}]", function=func.__name__,
                        max_retries=strategy.max_retries, exc=last_exception)
                    raise last_exception
                raise ExternalServiceError("Unexpected state in retry logic")
            return async_wrapper  # type: ignore[return-value]
        else:
            @wraps(func)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                if circuit_breaker is not None and not circuit_breaker.can_execute():
                    raise CircuitBreakerOpenError(circuit_breaker.name)
                last_exception: Optional[Exception] = None
                for attempt in range(strategy.max_retries + 1):
                    try:
                        result = func(*args, **kwargs)
                        if circuit_breaker is not None:
                            circuit_breaker.record_success()
                        return result
                    except strategy.retryable_exceptions as e:
                        last_exception = e
                        if circuit_breaker is not None:
                            circuit_breaker.record_failure()
                        if not strategy.should_retry(e, attempt):
                            break
                        delay = strategy.get_delay(attempt)
                        if on_retry is not None:
                            try:
                                on_retry(e, attempt)
                            except (RuntimeError, ValueError, TypeError):
                                pass
                        _logger.warning(f"重试 [{func.__name__}] 第 {attempt + 1} 次，延迟 {delay:.2f}s",
                            function=func.__name__, attempt=attempt + 1, delay=delay, exc_type=type(e).__name__)
                        time.sleep(delay)
                if last_exception is not None:
                    if on_failure is not None:
                        try:
                            on_failure(last_exception)
                        except (RuntimeError, ValueError, TypeError):
                            pass
                    _logger.fail(f"重试耗尽 [{func.__name__}]", function=func.__name__,
                        max_retries=strategy.max_retries, exc=last_exception)
                    raise last_exception
                raise ExternalServiceError("Unexpected state in retry logic")
            return sync_wrapper  # type: ignore[return-value]
    return decorator
