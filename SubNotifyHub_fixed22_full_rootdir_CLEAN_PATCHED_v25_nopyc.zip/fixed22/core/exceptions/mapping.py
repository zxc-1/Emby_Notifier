"""异常映射模块。

将第三方库异常映射为内部异常类别，便于统一处理。

Requirements: 2.3
"""

from __future__ import annotations

import sqlite3
from typing import Type

import httpx

from core.exceptions.base import (
    AppException,
    ConfigurationError,
    DatabaseError,
    ExternalServiceError,
    NetworkError,
    ValidationError,
)

# 第三方异常到内部异常的映射表
# 映射顺序很重要：更具体的异常类型应该放在前面
EXCEPTION_MAPPING: dict[Type[Exception], Type[AppException]] = {
    # HTTP/网络异常 (httpx)
    httpx.TimeoutException: NetworkError,
    httpx.ConnectError: NetworkError,
    httpx.ReadTimeout: NetworkError,
    httpx.WriteTimeout: NetworkError,
    httpx.ConnectTimeout: NetworkError,
    httpx.PoolTimeout: NetworkError,
    httpx.NetworkError: NetworkError,
    # HTTP 协议错误映射为外部服务错误
    httpx.HTTPStatusError: ExternalServiceError,
    httpx.DecodingError: ExternalServiceError,
    httpx.InvalidURL: ValidationError,
    # 标准库网络异常
    ConnectionError: NetworkError,
    ConnectionRefusedError: NetworkError,
    ConnectionResetError: NetworkError,
    ConnectionAbortedError: NetworkError,
    TimeoutError: NetworkError,
    BrokenPipeError: NetworkError,
    # 数据库异常 (sqlite3)
    sqlite3.IntegrityError: DatabaseError,
    sqlite3.OperationalError: DatabaseError,
    sqlite3.ProgrammingError: DatabaseError,
    sqlite3.InterfaceError: DatabaseError,
    sqlite3.DataError: DatabaseError,
    sqlite3.DatabaseError: DatabaseError,
    # 标准库验证异常
    ValueError: ValidationError,
    TypeError: ValidationError,
    KeyError: ValidationError,
    IndexError: ValidationError,
    AttributeError: ValidationError,
    # 配置相关异常
    FileNotFoundError: ConfigurationError,
    PermissionError: ConfigurationError,
    # JSON 解析错误
    # json.JSONDecodeError 继承自 ValueError，已被覆盖
}


def map_exception(exc: Exception) -> AppException:
    """将第三方异常映射为内部异常类别。

    遍历 EXCEPTION_MAPPING 查找匹配的异常类型，返回对应的内部异常实例。
    如果没有找到匹配的映射，返回 AppException 实例。

    Args:
        exc: 要映射的原始异常

    Returns:
        对应的 AppException 子类实例，包含原始异常作为 cause

    Example:
        >>> try:
        ...     raise httpx.TimeoutException("Connection timed out")
        ... except Exception as e:
        ...     app_exc = map_exception(e)
        ...     print(app_exc.category)  # "network"
    """
    # 如果已经是 AppException，直接返回
    if isinstance(exc, AppException):
        return exc

    # 遍历映射表查找匹配的异常类型
    for exc_type, app_exc_type in EXCEPTION_MAPPING.items():
        if isinstance(exc, exc_type):
            return app_exc_type(str(exc), cause=exc)

    # 未找到映射，返回基类 AppException
    return AppException(str(exc), cause=exc)


def get_exception_category(exc: Exception) -> str:
    """获取异常的类别标识符。

    Args:
        exc: 要获取类别的异常

    Returns:
        异常类别字符串
    """
    if isinstance(exc, AppException):
        return exc.category
    mapped = map_exception(exc)
    return mapped.category
