"""异常指标收集器。

本模块实现异常指标的收集、统计和阈值检查功能。
采用单例模式确保全局唯一的指标收集器实例。

Requirements: 6.1, 6.2, 6.3, 6.4
"""

from __future__ import annotations

import time
from collections import defaultdict
from threading import Lock
from typing import Any, Dict, Optional

from core.logging import get_biz_logger
from core.env_utils import env_int
from core.metrics import metrics

biz = get_biz_logger(__name__)

# 环境变量配置的异常阈值
# 当某类别异常数量超过此阈值时，会记录 WARNING 日志
DEFAULT_EXCEPTION_THRESHOLD = 100
EXCEPTION_THRESHOLD = env_int(
    "EXCEPTION_RATE_THRESHOLD",
    DEFAULT_EXCEPTION_THRESHOLD,
    min_value=1,
)


class ExceptionMetrics:
    """异常指标收集器（单例模式）。

    收集和统计异常发生次数，按类别和模块分组。
    支持阈值检查，当异常频率超过阈值时记录警告。

    Attributes:
        counts: 嵌套字典，结构为 {category: {module: count}}
        last_reset: 上次重置时间戳
    """

    _instance: Optional["ExceptionMetrics"] = None
    _lock = Lock()

    def __new__(cls) -> "ExceptionMetrics":
        """单例模式实现。"""
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    instance = super().__new__(cls)
                    instance._init()
                    cls._instance = instance
        return cls._instance

    def _init(self) -> None:
        """初始化实例属性。"""
        self.counts: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
        self.last_reset: float = time.time()
        self._instance_lock = Lock()
        self._threshold_warnings: Dict[str, float] = {}  # 记录上次警告时间，避免重复警告

    def record(self, category: str, module: str) -> None:
        """记录一次异常。

        Args:
            category: 异常类别（如 "network", "database" 等）
            module: 发生异常的模块路径

        Requirements: 6.1
        """
        category = str(category or "unknown").strip()
        module = str(module or "unknown").strip()

        with self._instance_lock:
            self.counts[category][module] += 1

        # 同步到 Prometheus 指标
        metrics.inc(
            "exception",
            labels={"category": category, "module": module},
        )

        # 检查是否���过阈值
        self._check_and_warn(category)

    def get_counts(self) -> Dict[str, Dict[str, int]]:
        """获取所有异常计数。

        Returns:
            嵌套字典，结构为 {category: {module: count}}

        Requirements: 6.2
        """
        with self._instance_lock:
            # 返回深拷贝，避免外部修改内部状态
            return {
                category: dict(modules)
                for category, modules in self.counts.items()
            }

    def check_threshold(self, category: str, threshold: Optional[int] = None) -> bool:
        """检查指定类别的异常是否超过阈值。

        Args:
            category: 异常类别
            threshold: 阈值，默认使用环境变量配置的值

        Returns:
            True 如果超过阈值，否则 False

        Requirements: 6.3
        """
        if threshold is None:
            threshold = EXCEPTION_THRESHOLD

        category = str(category or "").strip()
        if not category:
            return False

        with self._instance_lock:
            total = sum(self.counts.get(category, {}).values())
            return total >= threshold

    def get_total_by_category(self, category: str) -> int:
        """获取指定类别的异常总数。

        Args:
            category: 异常类别

        Returns:
            该类别的异常总数
        """
        category = str(category or "").strip()
        with self._instance_lock:
            return sum(self.counts.get(category, {}).values())

    def get_summary(self) -> Dict[str, Any]:
        """获取异常指标摘要。

        Returns:
            包含各类别总数和详细信息的字典

        Requirements: 6.2
        """
        with self._instance_lock:
            summary: Dict[str, Any] = {
                "last_reset": self.last_reset,
                "uptime_seconds": time.time() - self.last_reset,
                "categories": {},
            }

            for category, modules in self.counts.items():
                total = sum(modules.values())
                summary["categories"][category] = {
                    "total": total,
                    "modules": dict(modules),
                    "threshold_exceeded": total >= EXCEPTION_THRESHOLD,
                }

            return summary

    def reset(self) -> None:
        """重置所有计数器。

        主要用于测试或定期重置。
        """
        with self._instance_lock:
            self.counts.clear()
            self.last_reset = time.time()
            self._threshold_warnings.clear()

    def _check_and_warn(self, category: str) -> None:
        """检查阈值并在超过时记录警告。

        为避免日志泛滥，同一类别的警告每 60 秒最多记录一次。

        Args:
            category: 异常类别

        Requirements: 6.3
        """
        if not self.check_threshold(category):
            return

        now = time.time()
        last_warn = self._threshold_warnings.get(category, 0.0)

        # 每 60 秒最多警告一次
        if now - last_warn < 60.0:
            return

        with self._instance_lock:
            total = sum(self.counts.get(category, {}).values())
            modules = self.counts.get(category, {})
            top_modules = sorted(modules.items(), key=lambda x: x[1], reverse=True)[:5]
            self._threshold_warnings[category] = now

        biz.warning(
            f"异常频率超过阈值：类别={category}，总数={total}，阈值={EXCEPTION_THRESHOLD}",
            category=category,
            total=total,
            threshold=EXCEPTION_THRESHOLD,
            top_modules=dict(top_modules),
        )


# 全局单例实例
exception_metrics = ExceptionMetrics()


def record_exception(category: str, module: str) -> None:
    """便捷函数：记录一次异常。

    Args:
        category: 异常类别
        module: 发生异常的模块路径
    """
    exception_metrics.record(category, module)


def get_exception_counts() -> Dict[str, Dict[str, int]]:
    """便捷函数：获取所有异常计数。

    Returns:
        嵌套字典，结构为 {category: {module: count}}
    """
    return exception_metrics.get_counts()


def get_exception_summary() -> Dict[str, Any]:
    """便捷函数：获取异常指标摘要。

    Returns:
        包含各类别总数和详细信息的字典
    """
    return exception_metrics.get_summary()
