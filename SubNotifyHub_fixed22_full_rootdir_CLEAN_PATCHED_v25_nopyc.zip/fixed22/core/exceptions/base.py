"""统一异常类别定义。

本模块定义应用层异常基类和各类别异常，用于替换宽泛的 Exception 捕获。
每个异常类包含 category、cause、context 属性，便于分类处理和日志记录。

Requirements: 2.1
"""

from __future__ import annotations

from typing import Any, Optional


class AppException(Exception):
    """应用异常基类。

    所有应用层异常都应继承此类，提供统一的异常处理接口。

    Attributes:
        category: 异常类别标识符
        cause: 原始异常（如果是包装的第三方异常）
        context: 异常发生时的上下文信息字典
    """

    category: str = "unknown"

    def __init__(
        self,
        message: str,
        *,
        cause: Optional[Exception] = None,
        context: Optional[dict[str, Any]] = None,
        error_code: Optional[str] = None,
        status_code: Optional[int] = None,
    ) -> None:
        """初始化应用异常。

        Args:
            message: 异常消息
            cause: 原始异常（可选）
            context: 上下文信息字典（可选）
        """
        super().__init__(message)
        self.cause = cause
        self.context = context or {}
        self.error_code = error_code
        self.status_code = status_code

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}({self.args[0]!r}, category={self.category!r})"


class NetworkError(AppException):
    """网络相关错误。

    包括：连接超时、DNS 解析失败、连接被拒绝、读取超时等。
    """

    category = "network"


class DatabaseError(AppException):
    """数据库相关错误。

    包括：连接失败、查询超时、完整性错误、锁定错误等。
    """

    category = "database"


class ValidationError(AppException):
    """数据验证错误。

    包括：格式错误、类型错误、缺少必需字段、值超出范围等。
    """

    category = "validation"


class ConfigurationError(AppException):
    """配置错误。

    包括：缺少必需配置、配置值无效、配置文件格式错误等。
    """

    category = "configuration"


class ExternalServiceError(AppException):
    """外部服务错误。

    包括：第三方 API 调用失败、服务不可用、响应格式错误等。
    """

    category = "external_service"
