"""安全调用装饰器模块。
from core.logging import get_biz_logger_adapter

_biz = get_biz_logger_adapter(__name__)

提供统一的异常处理装饰器，支持同步和异步函数。
集成 BizLogger 记录异常，支持可配置的异常类型、默认值和回调函数。

Requirements: 1.1, 1.3, 1.4, 1.5, 1.6
"""

from __future__ import annotations

import inspect
import logging
import uuid
from functools import wraps
from typing import Any, Callable, Optional, Tuple, Type, TypeVar, Union, overload

from core.logging import get_biz_logger
from core.exceptions.mapping import get_exception_category, map_exception
from core.logging import get_span_id, get_trace_id

T = TypeVar("T")
F = TypeVar("F", bound=Callable[..., Any])

# 默认日志记录器
_logger = get_biz_logger(__name__)


def _generate_error_id() -> str:
    """生成唯一的错误 ID。"""
    return uuid.uuid4().hex[:8]


def _get_function_info(func: Callable[..., Any]) -> Tuple[str, str]:
    """获取函数的模块路径和函数名。

    Args:
        func: 目标函数

    Returns:
        (module_path, function_name) 元组
    """
    module = getattr(func, "__module__", "unknown")
    name = getattr(func, "__qualname__", getattr(func, "__name__", "unknown"))
    return module, name


def _handle_exception(
    exc: Exception,
    func: Union[Callable[..., Any], str],
    error_id: str,
    log_level: str,
    include_traceback: bool,
    on_error: Optional[Callable[[Exception], None]],
) -> None:
    """统一处理异常。

    Args:
        exc: 捕获的异常
        func: 原始函数或上下文名称
        error_id: 唯一错误 ID
        log_level: 日志级别
        include_traceback: 是否包含堆栈跟踪
        on_error: 错误回调函数
    """
    # 获取函数信息
    if callable(func):
        module, func_name = _get_function_info(func)
    else:
        module = "unknown"
        func_name = str(func)

    # 获取异常类别
    category = get_exception_category(exc)

    # 获取追踪信息
    span_id = get_span_id() or ""
    trace_id = get_trace_id() or ""

    # 构建日志上下文
    log_kv = {
        "error_id": error_id,
        "module": module,
        "function": func_name,
        "category": category,
        "span_id": span_id,
        "trace_id": trace_id,
        "exc_type": type(exc).__name__,
    }

    # 构建日志消息
    msg = f"异常捕获 [{error_id}] {module}.{func_name}: {type(exc).__name__}: {exc}"

    # 根据日志级别记录
    level = log_level.lower()
    if level == "debug":
        _biz.detail(msg, **log_kv, stage="safe_call")
    elif level == "info":
        _biz.detail(msg, **log_kv, stage="safe_call", severity="info")
    elif level == "warning":
        _logger.warning(msg, **log_kv)
    elif level == "critical":
        _biz.fail(msg, **log_kv, stage="safe_call", exc_info=include_traceback)
    else:  # error (default)
        if include_traceback:
            _logger.fail(msg, exc=exc, **log_kv)
        else:
            _logger.fail(msg, **log_kv)

    # 调用错误回调
    if on_error is not None:
        try:
            on_error(exc)
        except Exception as callback_exc:
            _biz.warning(
                f"错误回调执行失败 [{error_id}]: {callback_exc}",
                error_id=error_id,
                callback_error=str(callback_exc),
                stage="safe_call_callback",
            )


@overload
def safe_call(
    func: F,
) -> F: ...


@overload
def safe_call(
    *,
    catch: Tuple[Type[Exception], ...] = ...,
    default: Any = ...,
    on_error: Optional[Callable[[Exception], None]] = ...,
    log_level: str = ...,
    include_traceback: bool = ...,
) -> Callable[[F], F]: ...


def safe_call(
    func: Optional[F] = None,
    *,
    catch: Tuple[Type[Exception], ...] = (Exception,),
    default: Any = None,
    on_error: Optional[Callable[[Exception], None]] = None,
    log_level: str = "error",
    include_traceback: bool = True,
) -> Union[F, Callable[[F], F]]:
    """安全调用装饰器，统一处理异常。

    支持同步和异步函数。当函数抛出指定类型的异常时，
    装饰器会捕获异常、记录日志、执行回调，并返回默认值。

    Args:
        func: 要装饰的函数（用于无参数装饰器语法）
        catch: 要捕获的异常类型元组，默认为 (Exception,)
        default: 异常时的默认返回值，默认为 None
        on_error: 异常时的回调函数，接收异常对象作为参数
        log_level: 日志级别，可选 "debug", "info", "warning", "error", "critical"
        include_traceback: 是否在日志中包含堆栈跟踪，默认为 True

    Returns:
        装饰后的函数，或装饰器函数

    Example:
        # 基本用法
        @safe_call
        def risky_operation():
            ...

        # 带参数用法
        @safe_call(catch=(ValueError, TypeError), default=[])
        def parse_data(raw):
            ...

        # 异步函数
        @safe_call(on_error=lambda e: notify_admin(e))
        async def fetch_data():
            ...

    Requirements:
        - 1.1: 提供 @safe_call 装饰器
        - 1.3: 记录异常时包含完整上下文
        - 1.4: 支持可配置的异常类型
        - 1.5: 支持可配置的默认返回值
        - 1.6: 支持可选的回调函数
    """

    def decorator(fn: F) -> F:
        if inspect.iscoroutinefunction(fn):
            @wraps(fn)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                error_id = _generate_error_id()
                try:
                    return await fn(*args, **kwargs)
                except catch as e:
                    _handle_exception(
                        e, fn, error_id, log_level, include_traceback, on_error
                    )
                    return default

            return async_wrapper  # type: ignore[return-value]
        else:
            @wraps(fn)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                error_id = _generate_error_id()
                try:
                    return fn(*args, **kwargs)
                except catch as e:
                    _handle_exception(
                        e, fn, error_id, log_level, include_traceback, on_error
                    )
                    return default

            return sync_wrapper  # type: ignore[return-value]

    # 支持 @safe_call 和 @safe_call(...) 两种语法
    if func is not None:
        return decorator(func)
    return decorator