from __future__ import annotations

from core.exceptions.base import ExternalServiceError

"""数据库异常处理模块。

提供专门的数据库异常处理逻辑，包括：
- 连接错误重试（指数退避）
- 完整性错误不重试
- 确保连接正确关闭

Requirements: 7.1, 7.2, 7.3, 7.4
"""


import asyncio
import inspect
import sqlite3
import time
from contextlib import contextmanager, asynccontextmanager
from functools import wraps
from typing import Any, Callable, Generator, Optional, Tuple, Type, TypeVar

from core.logging import get_biz_logger
from core.exceptions.base import DatabaseError
from core.exceptions.recovery import RetryStrategy

T = TypeVar("T")
F = TypeVar("F", bound=Callable[..., Any])

_logger = get_biz_logger(__name__)

RETRYABLE_DB_EXCEPTIONS: Tuple[Type[Exception], ...] = (
    sqlite3.OperationalError, sqlite3.InterfaceError, ConnectionError, TimeoutError,
)

NON_RETRYABLE_DB_EXCEPTIONS: Tuple[Type[Exception], ...] = (
    sqlite3.IntegrityError, sqlite3.ProgrammingError, sqlite3.DataError,
)


def is_retryable_db_exception(exc: Exception) -> bool:
    """判断数据库异常是否可重试。"""
    if isinstance(exc, NON_RETRYABLE_DB_EXCEPTIONS):
        return False
    if isinstance(exc, RETRYABLE_DB_EXCEPTIONS):
        if isinstance(exc, sqlite3.OperationalError):
            error_msg = str(exc).lower()
            retryable_patterns = ["database is locked", "unable to open database", "disk i/o error", "connection", "timeout"]
            return any(pattern in error_msg for pattern in retryable_patterns)
        return True
    return False


def is_integrity_error(exc: Exception) -> bool:
    """判断是否为数据库完整性错误。"""
    return isinstance(exc, sqlite3.IntegrityError)


class DatabaseRetryStrategy(RetryStrategy):
    """数据库专用重试策略。"""
    def __init__(self, max_retries: int = 3, backoff_base: float = 0.5, backoff_max: float = 10.0) -> None:
        super().__init__(max_retries=max_retries, backoff_base=backoff_base, backoff_max=backoff_max,
            retryable_exceptions=RETRYABLE_DB_EXCEPTIONS)
    
    def should_retry(self, exc: Exception, attempt: int) -> bool:
        if attempt >= self.max_retries:
            return False
        return is_retryable_db_exception(exc)


def with_db_retry(
    *, strategy: Optional[DatabaseRetryStrategy] = None,
    on_retry: Optional[Callable[[Exception, int], None]] = None,
    on_failure: Optional[Callable[[Exception], None]] = None,
) -> Callable[[F], F]:
    """数据库操作重试装饰器。"""
    if strategy is None:
        strategy = DatabaseRetryStrategy()
    
    def decorator(func: F) -> F:
        if inspect.iscoroutinefunction(func):
            @wraps(func)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                last_exception: Optional[Exception] = None
                for attempt in range(strategy.max_retries + 1):
                    try:
                        return await func(*args, **kwargs)
                    except Exception as e:
                        last_exception = e
                        if is_integrity_error(e):
                            _logger.fail(f"数据库完整性错误 [{func.__name__}]，不重试",
                                function=func.__name__, exc_type=type(e).__name__, exc=e)
                            raise DatabaseError(str(e), cause=e)
                        if not strategy.should_retry(e, attempt):
                            break
                        delay = strategy.get_delay(attempt)
                        if on_retry is not None:
                            try:
                                on_retry(e, attempt)
                            except (RuntimeError, ValueError, TypeError):
                                pass
                        _logger.warning(f"数据库操作重试 [{func.__name__}] 第 {attempt + 1} 次，延迟 {delay:.2f}s",
                            function=func.__name__, attempt=attempt + 1, delay=delay, exc_type=type(e).__name__)
                        await asyncio.sleep(delay)
                if last_exception is not None:
                    if on_failure is not None:
                        try:
                            on_failure(last_exception)
                        except (RuntimeError, ValueError, TypeError):
                            pass
                    _logger.fail(f"数据库操作重试耗尽 [{func.__name__}]", function=func.__name__,
                        max_retries=strategy.max_retries, exc=last_exception)
                    raise DatabaseError(str(last_exception), cause=last_exception)
                raise ExternalServiceError("Unexpected state in db retry logic")
            return async_wrapper  # type: ignore[return-value]
        else:
            @wraps(func)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                last_exception: Optional[Exception] = None
                for attempt in range(strategy.max_retries + 1):
                    try:
                        return func(*args, **kwargs)
                    except Exception as e:
                        last_exception = e
                        if is_integrity_error(e):
                            _logger.fail(f"数据库完整性错误 [{func.__name__}]，不重试",
                                function=func.__name__, exc_type=type(e).__name__, exc=e)
                            raise DatabaseError(str(e), cause=e)
                        if not strategy.should_retry(e, attempt):
                            break
                        delay = strategy.get_delay(attempt)
                        if on_retry is not None:
                            try:
                                on_retry(e, attempt)
                            except (RuntimeError, ValueError, TypeError):
                                pass
                        _logger.warning(f"数据库操作重试 [{func.__name__}] 第 {attempt + 1} 次，延迟 {delay:.2f}s",
                            function=func.__name__, attempt=attempt + 1, delay=delay, exc_type=type(e).__name__)
                        time.sleep(delay)
                if last_exception is not None:
                    if on_failure is not None:
                        try:
                            on_failure(last_exception)
                        except (RuntimeError, ValueError, TypeError):
                            pass
                    _logger.fail(f"数据库操作重试耗尽 [{func.__name__}]", function=func.__name__,
                        max_retries=strategy.max_retries, exc=last_exception)
                    raise DatabaseError(str(last_exception), cause=last_exception)
                raise ExternalServiceError("Unexpected state in db retry logic")
            return sync_wrapper  # type: ignore[return-value]
    return decorator


@contextmanager
def db_safe_context(connection: Optional[Any] = None, *, close_on_error: bool = True,
    context_name: str = "db_operation") -> Generator[None, None, None]:
    """数据库安全上下文管理器。"""
    try:
        yield
    except sqlite3.IntegrityError as e:
        _logger.fail(f"数据库完整性错误 [{context_name}]", context=context_name, exc_type=type(e).__name__, exc=e)
        if close_on_error and connection is not None:
            try:
                connection.close()
            except (RuntimeError, ValueError, OSError):
                pass
        raise DatabaseError(str(e), cause=e)
    except (sqlite3.OperationalError, sqlite3.DatabaseError) as e:
        _logger.fail(f"数据库操作错误 [{context_name}]", context=context_name, exc_type=type(e).__name__, exc=e)
        if close_on_error and connection is not None:
            try:
                connection.close()
            except (RuntimeError, ValueError, OSError):
                pass
        raise DatabaseError(str(e), cause=e)
    except Exception as e:
        _logger.fail(f"数据库未知错误 [{context_name}]", context=context_name, exc_type=type(e).__name__, exc=e)
        if close_on_error and connection is not None:
            try:
                connection.close()
            except (RuntimeError, ValueError, OSError):
                pass
        raise


@asynccontextmanager
async def async_db_safe_context(connection: Optional[Any] = None, *, close_on_error: bool = True,
    context_name: str = "db_operation"):
    """异步数据库安全上下文管理器。"""
    try:
        yield
    except sqlite3.IntegrityError as e:
        _logger.fail(f"数据库完整性错误 [{context_name}]", context=context_name, exc_type=type(e).__name__, exc=e)
        if close_on_error and connection is not None:
            try:
                if hasattr(connection, "close"):
                    close_result = connection.close()
                    if asyncio.iscoroutine(close_result):
                        await close_result
            except (RuntimeError, ValueError, OSError):
                pass
        raise DatabaseError(str(e), cause=e)
    except (sqlite3.OperationalError, sqlite3.DatabaseError) as e:
        _logger.fail(f"数据库操作错误 [{context_name}]", context=context_name, exc_type=type(e).__name__, exc=e)
        if close_on_error and connection is not None:
            try:
                if hasattr(connection, "close"):
                    close_result = connection.close()
                    if asyncio.iscoroutine(close_result):
                        await close_result
            except (RuntimeError, ValueError, OSError):
                pass
        raise DatabaseError(str(e), cause=e)
    except Exception as e:
        _logger.fail(f"数据库未知错误 [{context_name}]", context=context_name, exc_type=type(e).__name__, exc=e)
        if close_on_error and connection is not None:
            try:
                if hasattr(connection, "close"):
                    close_result = connection.close()
                    if asyncio.iscoroutine(close_result):
                        await close_result
            except (RuntimeError, ValueError, OSError):
                pass
        raise
