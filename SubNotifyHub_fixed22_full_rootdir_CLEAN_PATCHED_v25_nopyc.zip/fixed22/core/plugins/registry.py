from __future__ import annotations

"""Plugin registry (P1).

Goal
----
Enable extensions without relying on import side-effects.

A plugin module can expose::

    def register(registry: PluginRegistry, *, app: FastAPI | None = None, settings: Any | None = None) -> None:
        ...

The loader will import the module and (if present) call ``register``.
Plugins may still work via import side-effects for backward compatibility.

What can be registered
----------------------
- Extra FastAPI routers (included during app creation)
- Startup / shutdown hooks (executed during lifespan)
- Arbitrary key/value contributions (for advanced use-cases)

Observability
-------------
We also keep best-effort plugin metadata so /debug/plugins can show what is
loaded and what each plugin contributed.

This module is dependency-light and safe to import early.
"""

import inspect
from dataclasses import dataclass, field
from typing import Any, Callable, Iterable, List, Mapping, Optional

from fastapi import FastAPI
from fastapi.routing import APIRouter

from core.logging import get_biz_logger

biz = get_biz_logger(__name__)

Hook = Callable[..., Any]


@dataclass
class RouterSpec:
    router: APIRouter
    kwargs: dict[str, Any] = field(default_factory=dict)
    # By default, extra HTTP endpoints should only be exposed in API role.
    api_only: bool = True


@dataclass
class PluginInfo:
    """Best-effort metadata for a loaded plugin."""

    module: str
    api_version: int
    name: Optional[str] = None
    version: Optional[str] = None
    description: Optional[str] = None
    homepage: Optional[str] = None
    author: Optional[str] = None
    dependencies: list[str] = field(default_factory=list)

    @classmethod
    def from_mapping(cls, module: str, api_version: int, m: Mapping[str, Any]) -> "PluginInfo":
        def _s(k: str) -> Optional[str]:
            v = m.get(k)
            if v is None:
                return None
            try:
                s = str(v).strip()
            except (ValueError, TypeError) as e:
                biz.detail(f"插件元数据字段读取失败（已忽略）：key={k}，原因={type(e).__name__}")
                return None
            return s or None

        deps: list[str] = []
        raw_deps = m.get("dependencies") or m.get("deps") or []
        if isinstance(raw_deps, (list, tuple, set)):
            for x in raw_deps:
                try:
                    ss = str(x).strip()
                except (ValueError, TypeError) as e:
                    biz.detail(f"插件依赖项读取失败（已忽略）：value={x!r}，原因={type(e).__name__}")
                    continue
                if ss:
                    deps.append(ss)
        elif raw_deps:
            try:
                deps = [str(raw_deps).strip()]
            except (ValueError, TypeError) as e:
                biz.detail(f"插件依赖项读取失败（已忽略）：raw_deps={raw_deps!r}，原因={type(e).__name__}")
                deps = []

        return cls(
            module=module,
            api_version=int(api_version),
            name=_s("name") or module,
            version=_s("version"),
            description=_s("description") or _s("desc"),
            homepage=_s("homepage") or _s("url"),
            author=_s("author"),
            dependencies=deps,
        )


class PluginRegistry:
    """Collects plugin contributions.

    The registry is created once during app construction and stored at
    ``app.state.plugin_registry``.
    """

    def __init__(self) -> None:
        self.routers: List[RouterSpec] = []
        self.startup_hooks: List[Hook] = []
        self.shutdown_hooks: List[Hook] = []
        self.data: dict[str, Any] = {}
        # module -> PluginInfo
        self.plugin_infos: dict[str, PluginInfo] = {}

    # --- plugin meta ------------------------------------------------------
    def set_plugin_info(self, module: str, info: PluginInfo) -> None:
        """Attach metadata for a plugin module."""
        if not module:
            return
        self.plugin_infos[str(module)] = info

    # --- router -----------------------------------------------------------
    def add_router(self, router: APIRouter, *, api_only: bool = True, **include_router_kwargs: Any) -> None:
        """Register a router to be included in the main app.

        api_only=True means the router will not be exposed when running in
        worker-only role.
        """
        self.routers.append(RouterSpec(router=router, kwargs=dict(include_router_kwargs), api_only=bool(api_only)))

    # --- hooks ------------------------------------------------------------
    def on_startup(self, fn: Hook) -> Hook:
        self.startup_hooks.append(fn)
        return fn

    def on_shutdown(self, fn: Hook) -> Hook:
        self.shutdown_hooks.append(fn)
        return fn

    async def run_startup(self, *, app: FastAPI, settings: Any | None = None) -> None:
        await _run_hooks(self.startup_hooks, app=app, settings=settings, phase="startup")

    async def run_shutdown(self, *, app: FastAPI, settings: Any | None = None) -> None:
        await _run_hooks(self.shutdown_hooks, app=app, settings=settings, phase="shutdown")


async def _maybe_await(v: Any) -> Any:
    if inspect.isawaitable(v):
        return await v
    return v


async def _run_hooks(hooks: Iterable[Hook], *, app: FastAPI, settings: Any | None, phase: str) -> None:
    for fn in hooks:
        try:
            # Prefer keyword injection; hooks can accept any subset of these.
            kwargs: dict[str, Any] = {"app": app, "settings": settings}
            sig = inspect.signature(fn)
            call_kwargs = {k: v for k, v in kwargs.items() if k in sig.parameters}
            await _maybe_await(fn(**call_kwargs))
            biz.ok(f"插件钩子执行成功：{getattr(fn, '__name__', str(fn))}（{phase}）")
        except Exception:
            biz.fail(f"插件钩子执行失败：{getattr(fn, '__name__', str(fn))}（{phase}）", exc_info=True)
            # Do not raise here; strictness is controlled by the loader / settings.
