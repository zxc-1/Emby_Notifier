from __future__ import annotations

from core.exceptions.base import ConfigurationError

"""Plugin loader.

Compatibility
-------------
Historically a "plugin" was just a module imported for side-effects.
This is still supported.

Preferred protocol (P1)
-----------------------
A plugin module may expose a callable ``register``. The loader will call it
after import::

    def register(registry: PluginRegistry, *, app: FastAPI | None = None, settings: Any | None = None) -> None:
        ...

The loader injects a subset of arguments based on the function signature.

Strictness
----------
- ``Settings.CONFIG_STRICT`` controls whether missing/broken plugins fail startup.
"""

import importlib
import inspect
from typing import Any

from fastapi import FastAPI
from collections.abc import Mapping

from core.logging import get_biz_logger
from core.plugins.registry import PluginInfo, PluginRegistry
from core.plugins.api import PLUGIN_API_VERSION

biz = get_biz_logger(__name__)


def _parse_plugins(raw: Any) -> list[str]:
    if raw is None:
        return []
    if isinstance(raw, (list, tuple, set)):
        items = [str(x).strip() for x in raw if str(x).strip()]
        return items
    s = str(raw or "").strip()
    if not s:
        return []
    # split by comma/space/semicolon
    out: list[str] = []
    cur = ""
    for ch in s:
        if ch in ",;\n\t ":
            if cur.strip():
                out.append(cur.strip())
            cur = ""
        else:
            cur += ch
    if cur.strip():
        out.append(cur.strip())
    # de-dup preserving order
    seen = set()
    uniq: list[str] = []
    for m in out:
        if m in seen:
            continue
        seen.add(m)
        uniq.append(m)
    return uniq


def _invoke_register(
    fn: Any,
    *,
    registry: PluginRegistry,
    app: FastAPI | None,
    settings: Any,
    module_name: str,
) -> None:
    # Build kwargs only for parameters that exist.
    try:
        sig = inspect.signature(fn)
        candidate_kwargs: dict[str, Any] = {
            "registry": registry,
            "reg": registry,
            "app": app,
            "settings": settings,
            "logger": biz,
            "module": module_name,
        }
        kwargs = {k: v for k, v in candidate_kwargs.items() if k in sig.parameters}
        if kwargs:
            fn(**kwargs)
            return
        # If no kwargs matched, try positional fallbacks
        params = list(sig.parameters.values())
        arity = len([p for p in params if p.kind in (p.POSITIONAL_ONLY, p.POSITIONAL_OR_KEYWORD) and p.default is p.empty])
        if arity <= 0:
            fn()
        elif arity == 1:
            fn(registry)
        elif arity == 2:
            fn(registry, app)
        else:
            fn(registry, app, settings)
    except TypeError:
        # Last resort: try the most common call patterns
        try:
            fn(registry=registry, app=app, settings=settings)
        except (TypeError, AttributeError) as e:
            biz.detail(f"插件注册函数调用失败，尝试简化参数：模块={module_name}，原因={type(e).__name__}")
            fn(registry)
    except Exception:
        raise


def load_plugins(
    settings: Any,
    *,
    registry: PluginRegistry | None = None,
    app: FastAPI | None = None,
) -> list[str]:
    """Import and initialize configured plugins.

    Returns a list of imported module paths.
    """

    strict = bool(getattr(settings, "CONFIG_STRICT", False))
    modules = _parse_plugins(getattr(settings, "PLUGINS", ""))

    if registry is None:
        registry = PluginRegistry()

    loaded: list[str] = []
    for mod in modules:
        try:
            m = importlib.import_module(mod)
            # Version gate (optional but recommended)
            pv = getattr(m, "PLUGIN_API_VERSION", None)
            if pv is None:
                msg = f"插件 '{mod}' 缺少 PLUGIN_API_VERSION 声明"
                if strict:
                    raise ConfigurationError(msg)
                biz.warning(msg, stage="plugin_load", module=mod, strict=strict)
            else:
                try:
                    pv_int = int(pv)
                except (ValueError, TypeError) as e:
                    biz.detail(f"插件 API 版本解析失败：插件={mod}，版本值={pv!r}，原因={type(e).__name__}")
                    pv_int = -1
                if pv_int != int(PLUGIN_API_VERSION):
                    msg = f"插件 '{mod}' API 版本不兼容：当前版本={pv_int}，期望版本={PLUGIN_API_VERSION}"
                    if strict:
                        raise ConfigurationError(msg)
                    biz.warning(msg, stage="plugin_load", module=mod, strict=strict)
                    continue
            loaded.append(mod)
            # Best-effort plugin metadata for /debug/plugins.
            try:
                raw_info = getattr(m, 'PLUGIN_INFO', None)
                if isinstance(raw_info, Mapping):
                    pi = PluginInfo.from_mapping(mod, int(PLUGIN_API_VERSION), raw_info)
                else:
                    pi = PluginInfo(
                        module=mod,
                        api_version=int(PLUGIN_API_VERSION),
                        name=getattr(m, 'PLUGIN_NAME', None) or getattr(m, '__name__', None) or mod,
                        version=str(getattr(m, '__version__', '') or getattr(m, 'VERSION', '') or '').strip() or None,
                        description=str(getattr(m, '__doc__', '') or '').strip().splitlines()[0] or None,
                    )
                registry.set_plugin_info(mod, pi)
            except Exception:
                biz.detail(f"插件元数据解析失败：{mod}", exc_info=True)

            # Preferred: explicit register() hook.
            reg_fn = getattr(m, "register", None)
            if callable(reg_fn):
                _invoke_register(reg_fn, registry=registry, app=app, settings=settings, module_name=mod)
                biz.ok(f"插件已注册：{mod}")
            else:
                biz.ok(f"插件已加载（副作用模式）：{mod}")
        except Exception:
            biz.fail(f"插件加载失败：{mod}", exc_info=True)
            if strict:
                raise

    return loaded
