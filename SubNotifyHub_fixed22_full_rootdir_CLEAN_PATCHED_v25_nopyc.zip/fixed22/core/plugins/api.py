from __future__ import annotations

"""Plugin API contract.

Plugins are optional extension modules loaded at startup. To avoid "silent"
breakages when the internal plugin registry evolves, plugins can declare
``PLUGIN_API_VERSION``.

- If a plugin declares ``PLUGIN_API_VERSION`` and it does not match
  :data:`PLUGIN_API_VERSION`, the loader will treat the plugin as incompatible.
- In strict mode (Settings.CONFIG_STRICT), missing or incompatible versions
  fail startup.
"""

PLUGIN_API_VERSION = 1
