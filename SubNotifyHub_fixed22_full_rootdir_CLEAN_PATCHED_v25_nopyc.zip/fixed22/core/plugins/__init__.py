"""Plugins submodule - plugin system for extensibility.

This module consolidates plugin-related functionality:
- Plugin API version (plugin_api.py → api.py)
- Plugin loader (plugin_loader.py → loader.py)
- Plugin registry (plugin_registry.py → registry.py)

Migration Guide:
    Old import path                    → New import path
    ─────────────────────────────────────────────────────────
    from core.plugin_api import ...    → from core.plugins import ...
    from core.plugin_loader import ... → from core.plugins import ...
    from core.plugin_registry import ...  → from core.plugins import ...
"""

from core.plugins.api import (
    PLUGIN_API_VERSION,
)

from core.plugins.loader import (
    load_plugins,
)

from core.plugins.registry import (
    Hook,
    RouterSpec,
    PluginInfo,
    PluginRegistry,
)

__all__ = [
    # api
    "PLUGIN_API_VERSION",
    # loader
    "load_plugins",
    # registry
    "Hook",
    "RouterSpec",
    "PluginInfo",
    "PluginRegistry",
]
