"""DEPRECATED: Use core.http.retry instead.

This module is maintained for backward compatibility only.
Please update your imports to use the new path:

    # Old (deprecated):
    from core.http_retry import async_request_with_retry

    # New (recommended):
    from core.http import async_request_with_retry
"""

from __future__ import annotations

import warnings

warnings.warn(
    "Importing from 'core.http_retry' is deprecated. "
    "Use 'from core.http import async_request_with_retry' instead.",
    DeprecationWarning,
    stacklevel=2,
)

# Re-export everything from the new location for backward compatibility
from core.http.retry import (
    async_request_with_retry,
    async_request_with_retry_json,
    async_request_with_retry_text,
    async_request_with_retry_bytes,
    # Internal symbols for backward compatibility
    _RETRYABLE_STATUS,
    _RETRYABLE_EXC,
    _parse_retry_after,
)

__all__ = [
    "async_request_with_retry",
    "async_request_with_retry_json",
    "async_request_with_retry_text",
    "async_request_with_retry_bytes",
    # Internal symbols (for backward compatibility only)
    "_RETRYABLE_STATUS",
    "_RETRYABLE_EXC",
    "_parse_retry_after",
]
