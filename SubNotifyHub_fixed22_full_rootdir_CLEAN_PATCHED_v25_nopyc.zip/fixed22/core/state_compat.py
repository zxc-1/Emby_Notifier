from __future__ import annotations

"""Compatibility layer for runtime state.

Historically this project stored many unrelated globals on ``app.state``.
We now centralize the mutable runtime state in :class:`core.context.AppContext`.

To keep backward compatibility (admin pages / older endpoints / extensions), we still
expose a minimal, stable subset on ``app.state`` derived from the context.
New code should prefer :func:`api.deps.get_ctx` and read state from ``ctx``.
"""
import logging
from core.logging import get_biz_logger_adapter
logger = get_biz_logger_adapter(__name__)


from typing import Any

from fastapi import FastAPI

from core.context import AppContext


def expose_ctx(app: FastAPI, ctx: AppContext) -> None:
    """Expose selected context fields on ``app.state`` for backward compatibility."""
    app.state.ctx = ctx

    # Also expose via a dependency-light port so non-request code paths can
    # access ctx without importing FastAPI.
    try:
        from ports.app_context import set_ctx

        set_ctx(ctx)
    except (ImportError, AttributeError) as e:
        # Avoid startup failure when optional port is unavailable.
        logger.detail(f"上下文端口设置失败（已忽略） - 原因={type(e).__name__}")

    # Compatibility: legacy code expects these names.
    app.state.poster_cache = ctx.poster_cache
    app.state.recent_store = ctx.recent_store
    app.state.recent_display_max = ctx.recent_display_max

    app.state.deduper = ctx.deduper
    app.state.notifier = ctx.notifier
    app.state.notifier_worker = ctx.notifier_worker
    app.state.notifier_handler = ctx.notifier_handler

    # Infra adapters (ports)
    if getattr(ctx, "http_client", None) is not None:
        app.state.http_client = ctx.http_client
    if getattr(ctx, "tmdb_gateway", None) is not None:
        app.state.tmdb_gateway = ctx.tmdb_gateway
    if getattr(ctx, "tmdb_matcher", None) is not None:
        app.state.tmdb_matcher = ctx.tmdb_matcher
    if getattr(ctx, "share115_gateway", None) is not None:
        app.state.share115_gateway = ctx.share115_gateway

    # Recent stats (old names used by debug routes)
    app.state._recent_notify_times = ctx.recent_notify_times
    app.state._recent_notify_attempt_times = ctx.recent_notify_attempt_times
    app.state._recent_webhook_times = ctx.recent_webhook_times

    # Optional debug history
    if ctx.notification_history is not None:
        app.state.notification_history = ctx.notification_history


def get_state(app: Any, name: str, default: Any = None) -> Any:
    """Best-effort getter for app.state values.

    Prefer accessing fields on :class:`core.context.AppContext`.
    """
    try:
        return getattr(app.state, name)
    except (AttributeError, TypeError) as e:
        logger.detail(f"状态获取失败，返回默认值 - 属性名={name}, 默认值={default!r}, 原因={type(e).__name__}")
        return default
