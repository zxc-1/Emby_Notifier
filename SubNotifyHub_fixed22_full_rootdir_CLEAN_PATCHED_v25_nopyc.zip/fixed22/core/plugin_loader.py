"""Backward compatibility layer for core.plugin_loader.

This module re-exports all symbols from core.plugins.loader for backward compatibility.
New code should import directly from core.plugins.

Migration Guide:
    Old: from core.plugins import load_plugins
    New: from core.plugins import load_plugins
"""

import warnings

warnings.warn(
    "Importing from 'core.plugin_loader' is deprecated. "
    "Use 'from core.plugins import load_plugins' instead.",
    DeprecationWarning,
    stacklevel=2,
)

from core.plugins.loader import (
    load_plugins,
    _parse_plugins,
    _invoke_register,
)

__all__ = [
    "load_plugins",
]
