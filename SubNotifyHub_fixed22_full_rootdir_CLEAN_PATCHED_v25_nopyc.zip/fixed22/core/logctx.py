"""DEPRECATED: Use core.logging.logctx instead.

This module is maintained for backward compatibility only.
Please update your imports to use the new path:

    # Old (deprecated):
    from core.logging import get_trace_id, set_trace_id

    # New (recommended):
    from core.logging import get_trace_id, set_trace_id
"""

from __future__ import annotations

import warnings

warnings.warn(
    "Importing from 'core.logctx' is deprecated. "
    "Use 'from core.logging import get_trace_id, set_trace_id, ...' instead.",
    DeprecationWarning,
    stacklevel=2,
)

# Re-export everything from the new location for backward compatibility
from core.logging.logctx import (
    get_kind,
    set_kind,
    get_trace_id,
    set_trace_id,
    get_step,
    set_step,
    get_phase,
    set_phase,
    get_req_path,
    get_req_method,
    set_request,
    get_span_id,
    get_parent_span_id,
    set_span,
    get_indent,
    set_indent,
    inc_indent,
    is_user_path,
)

__all__ = [
    "get_kind",
    "set_kind",
    "get_trace_id",
    "set_trace_id",
    "get_step",
    "set_step",
    "get_phase",
    "set_phase",
    "get_req_path",
    "get_req_method",
    "set_request",
    "get_span_id",
    "get_parent_span_id",
    "set_span",
    "get_indent",
    "set_indent",
    "inc_indent",
    "is_user_path",
]
