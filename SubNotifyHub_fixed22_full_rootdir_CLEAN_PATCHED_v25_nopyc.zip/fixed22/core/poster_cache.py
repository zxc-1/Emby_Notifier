"""DEPRECATED: Use core.cache.poster_cache instead.

This module is maintained for backward compatibility only.
Please update your imports to use the new path:

    # Old (deprecated):
    from core.cache import PosterCache, PosterCacheConfig

    # New (recommended):
    from core.cache import PosterCache, PosterCacheConfig
"""

from __future__ import annotations

import warnings

warnings.warn(
    "Importing from 'core.poster_cache' is deprecated. "
    "Use 'from core.cache import PosterCache, PosterCacheConfig' instead.",
    DeprecationWarning,
    stacklevel=2,
)

# Re-export everything from the new location for backward compatibility
from core.cache.poster_cache import (
    PosterCache,
    PosterCacheConfig,
    logger,
)

__all__ = [
    "PosterCache",
    "PosterCacheConfig",
    "logger",
]
