"""Process-level runtime configuration.

This module provides access to runtime/process configuration that is NOT
part of the business Settings class. Use this for:

- File paths (data directories, log files, cache locations)
- Process settings (worker counts, debug flags)
- Log configuration (colors, file paths)

**When to use this module:**
    - You need a path to a data file or directory
    - You need process-level settings like worker counts
    - You need log configuration settings

**When NOT to use this module (use Settings instead):**
    - API keys, tokens, secrets
    - Feature flags for business logic
    - Timeouts, retry counts, rate limits
    - External service URLs (Telegram, TMDB, Emby, etc.)

**Boundary with Settings:**
    - Runtime_Env: Process-level, infrastructure concerns
    - Settings: Business-level, application behavior

For business configuration (API keys, feature flags, timeouts),
import get_settings from settings.runtime module instead.

Example usage:
    from core.runtime_env import get_env_path, get_poster_cache_dir
    
    env_file = get_env_path()
    cache_dir = get_poster_cache_dir()
"""
from __future__ import annotations

import os
from pathlib import Path


def _env_str(key: str, default: str = "") -> str:
    """Read an environment variable as a string.

    Contract: This module MUST ONLY use ``os.getenv`` for config access.
    Do NOT import Settings or helper modules here.
    """

    value = os.getenv(key)
    if value is None:
        return default
    return str(value)


def _env_bool(key: str, default: bool = False) -> bool:
    """Read an environment variable as a boolean.

    Truthy values: 1/true/yes/on
    Falsy values: 0/false/no/off

    Any other non-empty value falls back to ``default`` to keep behavior
    stable and avoid surprising coercions.
    """

    value = os.getenv(key)
    if value is None:
        return default
    v = str(value).strip().lower()
    if v in ("1", "true", "yes", "on"):
        return True
    if v in ("0", "false", "no", "off"):
        return False
    return default


# Public aliases (kept for internal readability within this module).
# NOTE: Keeping the implementation in this file avoids importing any helper
# modules, which is enforced by contract tests.
env_str = _env_str
env_bool = _env_bool


# =============================================================================
# Path Configuration
# =============================================================================
# Functions that return file or directory paths for data storage.
# Naming convention: get_*_path() for files, get_*_dir() for directories.


def get_env_path() -> Path:
    """Path to the .env configuration file.
    
    Returns:
        Path to .env file, defaults to /data/.env
    """
    return Path(env_str("ENV_PATH", "/data/.env"))


def get_ui_prefs_path() -> Path:
    """Path to the UI preferences JSON file.
    
    Returns:
        Path to ui_prefs.json, defaults to /data/ui_prefs.json
    """
    return Path(env_str("UI_PREFS_PATH", "/data/ui_prefs.json"))


def get_admin_session_secret_path() -> Path:
    """Path to the admin session secret file.
    
    Returns:
        Path to session secret file, defaults to /data/.admin_session_secret
    """
    return Path(env_str("ADMIN_SESSION_SECRET_PATH", "/data/.admin_session_secret"))


def get_admin_init_password_path() -> Path:
    """Path to the admin initial password file.
    
    Returns:
        Path to init password file, defaults to /data/.admin_init_password
    """
    return Path(env_str("ADMIN_INIT_PASSWORD_PATH", "/data/.admin_init_password"))


def get_poster_cache_dir() -> Path:
    """Directory for poster image cache.
    
    Returns:
        Path to poster cache directory, defaults to /data/poster_cache
    """
    return Path(env_str("POSTER_CACHE_DIR", "/data/poster_cache"))


def get_recent_store_path() -> Path:
    """Path to the recent entries store JSON file.
    
    Returns:
        Path to recent_entries.json, defaults to /data/recent_entries.json
    """
    return Path(env_str("RECENT_STORE_PATH", "/data/recent_entries.json"))


def get_data_fallback_root() -> Path:
    """Fallback root directory for data storage when primary is unavailable.
    
    Returns:
        Path to fallback data root, defaults to /tmp/emby_notifier_data
    """
    return Path(env_str("DATA_FALLBACK_ROOT", "/tmp/emby_notifier_data"))


# =============================================================================
# Process Configuration
# =============================================================================
# Functions for process-level settings like worker counts and debug flags.


def debug_imports_enabled() -> bool:
    """Whether to emit optional import-time deprecation warnings.
    
    Controlled by EMBY_NOTIFIER_DEBUG_IMPORTS environment variable.
    Set to "1" to enable debug import warnings.
    
    Returns:
        True if debug imports are enabled, False otherwise
    """
    # Keep legacy semantics: only "1" enables.
    return env_str("EMBY_NOTIFIER_DEBUG_IMPORTS", "").strip() == "1"


def get_web_concurrency_raw() -> str:
    """Raw worker count from environment variables.
    
    Checks WEB_CONCURRENCY, UVICORN_WORKERS, and WORKERS in order.
    
    Returns:
        Raw string value of worker count, or empty string if not set
    """
    v = env_str("WEB_CONCURRENCY", "").strip()
    if v:
        return v
    v = env_str("UVICORN_WORKERS", "").strip()
    if v:
        return v
    return env_str("WORKERS", "").strip()


def allow_multi_worker() -> bool:
    """Whether multi-worker mode is allowed.
    
    Controlled by ALLOW_MULTI_WORKER environment variable.
    Accepts truthy values: '1', 'true', 'yes', 'on' (case-insensitive).
    
    Returns:
        True if multi-worker mode is allowed, False otherwise
    """
    return env_bool("ALLOW_MULTI_WORKER", False)


# =============================================================================
# Log Configuration
# =============================================================================
# Functions for logging-related settings.


def should_use_log_color() -> bool:
    """Whether console logging should use ANSI colors.
    
    Priority (highest to lowest):
    1. LOG_COLOR=0/false/no/off → disable colors
    2. NO_COLOR (any non-empty value) → disable colors (standard)
    3. LOG_FORCE_COLOR=1/true/yes/on → force enable colors (useful in Docker)
    4. Default: enable colors by default (Docker/log-panel friendly)
    
    To disable colors in Docker, set LOG_COLOR=0 or NO_COLOR=1.
    
    Returns:
        True if colors should be used, False otherwise
    """
    # 1) LOG_COLOR explicit disable (highest priority)
    v = env_str("LOG_COLOR", "").strip().lower()
    if v in ("0", "false", "no", "off"):
        return False

    # (Optional) LOG_COLOR explicit enable.
    if v in ("1", "true", "yes", "on"):
        return True

    # 2) NO_COLOR standard - any non-empty value disables colors
    if env_str("NO_COLOR", "").strip():
        return False

    # 3) LOG_FORCE_COLOR - force enable (for Docker/non-TTY)
    fc = env_str("LOG_FORCE_COLOR", "").strip().lower()
    if fc in ("1", "true", "yes", "on"):
        return True

    # 4) Default: enable colors by default (Docker/log-panel friendly)
    # Still can be disabled by LOG_COLOR=0/false/no/off or NO_COLOR=1.
    return True


def get_log_file() -> str:
    """Path to the application log file.

    Returns:
        Path string to log file, empty means disabled by default.
    """
    return env_str("LOG_FILE", "").strip()


def get_access_log_flag_raw() -> str:
    """Raw access log flag from environment.
    
    Checks SHOW_ACCESS_LOG and ACCESS_LOG environment variables.
    
    Returns:
        Raw string value of access log flag, or empty string if not set
    """
    v = env_str("SHOW_ACCESS_LOG", "").strip()
    if v:
        return v
    return env_str("ACCESS_LOG", "").strip()
