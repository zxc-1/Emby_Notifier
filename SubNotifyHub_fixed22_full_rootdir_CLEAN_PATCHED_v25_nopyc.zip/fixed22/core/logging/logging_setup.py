from __future__ import annotations

import json
import logging
import logging.handlers
import os
import sys
from datetime import datetime

from core.env_utils import env_bool, env_int, env_str
from typing import Any, Dict, Optional

from core.runtime_env import get_access_log_flag_raw, get_log_file, should_use_log_color

from .logctx import (
    get_kind,
    get_trace_id,
    get_step,
    get_phase,
    get_req_method,
    get_req_path,
    get_indent,
    get_span_id,
    get_parent_span_id,
)


def _format_ts(record: logging.LogRecord, *, ms: bool) -> str:
    """Format timestamp for human+json logs.

    When LOG_TS_MS=1, include milliseconds (...). We avoid strftime from
    `time` since it doesn't support %f reliably.
    """
    dt = datetime.fromtimestamp(record.created)
    base = dt.strftime("%Y-%m-%d %H:%M:%S")
    if not ms:
        return base
    try:
        return f"{base}.{int(getattr(record, 'msecs', 0) or 0):03d}"
    except Exception:
        return base


_ANSI = {
    "reset": "\x1b[0m",
    "green": "\x1b[32m",      # 成功
    "yellow": "\x1b[33m",     # 警告
    "red": "\x1b[31m",        # 错误
    "cyan": "\x1b[36m",       # 详细/调试
    "blue": "\x1b[34m",       # 元信息
    "dim": "\x1b[2m",         # 暗淡（辅助信息）
    "bold": "\x1b[1m",        # 粗体
}

# Kind 到颜色的映射
_KIND_COLORS: dict[str, str] = {
    # 绿色：成功操作
    "ok": "green",
    "success": "green",
    "user_action": "green",
    "user": "green",
    "run": "green",
    "fetch": "green",
    # 黄色：警告信息
    "warn": "yellow",
    "skip": "yellow",
    # 红色：错误信息
    "fail": "red",
    "error": "red",
    # 青色：调试/详细信息
    "detail": "cyan",
    "debug": "cyan",
    # 蓝色：元信息
    "meta": "blue",
}


def _load_color_scheme() -> dict[str, str]:
    """加载颜色方案，支持通过 LOG_COLOR_SCHEME 环境变量自定义。
    
    环境变量格式：kind1:color1,kind2:color2,...
    例如：LOG_COLOR_SCHEME=ok:cyan,warn:red,meta:green
    
    有效颜色：green, yellow, red, cyan, blue, dim
    
    Returns:
        合并后的颜色映射字典
    """
    # 从默认映射开始
    colors = _KIND_COLORS.copy()
    
    # 读取环境变量
    scheme_str = env_str("LOG_COLOR_SCHEME", "").strip()
    if not scheme_str:
        return colors
    
    # 有效颜色列表（排除 reset 和 bold）
    valid_colors = {"green", "yellow", "red", "cyan", "blue", "dim"}
    
    # 解析自定义方案
    for pair in scheme_str.split(","):
        pair = pair.strip()
        if not pair or ":" not in pair:
            continue
        try:
            kind, color = pair.split(":", 1)
            kind = kind.strip().lower()
            color = color.strip().lower()
            if kind and color in valid_colors:
                colors[kind] = color
        except Exception:
            # 静默忽略格式错误
            continue
    
    return colors


def get_kind_colors() -> dict[str, str]:
    """获取当前生效的 kind 到颜色的映射。
    
    此函数会考虑 LOG_COLOR_SCHEME 环境变量的自定义配置。
    """
    return _load_color_scheme()


def _wants_color() -> bool:
    """Whether to use ANSI colors in console output.
    
    Delegates to should_use_log_color() which handles all priority logic:
    LOG_COLOR=0 > NO_COLOR > LOG_FORCE_COLOR=1 > TTY check
    """
    return should_use_log_color()


def _env_flag(name: str, default: bool = False) -> bool:
    return env_bool(name, bool(default))


def _style() -> str:
    s = env_str("LOG_STYLE", "").strip().lower()
    return s or "pipe"


def _file_format() -> str:
    s = env_str("LOG_FILE_FORMAT", "").strip().lower()
    return s or "text"


def _clip(s: str, n: int = 220) -> str:
    if s is None:
        return ""
    t = str(s)
    t = t.replace("\n", " ").replace("\r", " ")
    if len(t) <= n:
        return t
    return t[: max(1, n - 1)] + "…"


def _format_kv(kv: Optional[Dict[str, Any]]) -> str:
    if not isinstance(kv, dict) or not kv:
        return ""
    parts = []
    for k in sorted(kv.keys(), key=lambda x: str(x)):
        try:
            v = kv.get(k)
        except Exception:
            continue
        if v is None:
            continue
        if isinstance(v, (dict, list, tuple)):
            vv = _clip(json.dumps(v, ensure_ascii=False, separators=(",", ":")))
        else:
            vv = _clip(v)
        kk = str(k)
        parts.append(f"{kk}={vv}")
    return " ".join(parts)


class BizTextFormatter(logging.Formatter):
    """Human-friendly business log formatter.

    Styles:
      - pipe: 2026-... | INFO | module:func:line | message | k=v ...
      - classic: retains old bracket-like look but still appends kv
    """

    def __init__(self, *, style: str, use_color: bool) -> None:
        super().__init__()
        self.style = (style or "pipe").lower()
        self.use_color = bool(use_color)
        self.show_trace = _env_flag("LOG_SHOW_TRACE", False)
        self.show_req = _env_flag("LOG_SHOW_REQ", False)
        self.fixed_cols = _env_flag("LOG_PIPE_FIXED_COLS", False)
        self.ts_ms = _env_flag("LOG_TS_MS", False)
        self.ts_ms = _env_flag("LOG_TS_MS", False)

    def _colorize(self, record: logging.LogRecord, text: str) -> str:
        """根据日志级别和 kind 字段应用 ANSI 颜色。
        
        颜色优先级：
        1. ERROR 级别 → 红色
        2. WARNING 级别 → 黄色
        3. kind 字段映射 → 对应颜色（支持 LOG_COLOR_SCHEME 自定义）
        4. 无匹配 → 不着色
        """
        if not self.use_color:
            return text
        
        kind = str(getattr(record, "kind", "") or "").lower()
        color_name: str = ""
        
        # 优先根据日志级别着色
        if record.levelno >= logging.ERROR:
            color_name = "red"
        elif record.levelno >= logging.WARNING:
            color_name = "yellow"
        else:
            # 根据 kind 字段查找颜色（支持自定义方案）
            kind_colors = get_kind_colors()
            if kind in kind_colors:
                color_name = kind_colors[kind]
        
        if not color_name:
            return text
        
        color = _ANSI.get(color_name, "")
        if not color:
            return text
        return f"{color}{text}{_ANSI['reset']}"
    
    def _colorize_field(self, field: str, color: str) -> str:
        """为单个字段应用指定颜色。"""
        if not self.use_color:
            return field
        ansi_code = _ANSI.get(color, "")
        if not ansi_code:
            return field
        return f"{ansi_code}{field}{_ANSI['reset']}"

    def _format_exc(self, record: logging.LogRecord, *, indent: int) -> str:
        if not record.exc_info:
            return ""
        try:
            exc_txt = self.formatException(record.exc_info)
        except Exception:
            return ""
        if not exc_txt:
            return ""
        pad = "  " * max(0, int(indent or 0))
        # Keep traceback aligned with the message indentation.
        lines = [pad + ln if ln else ln for ln in str(exc_txt).splitlines()]
        exc_output = "\n" + "\n".join(lines)
        # 给 traceback 也加上红色
        if self.use_color:
            return f"{_ANSI['red']}{exc_output}{_ANSI['reset']}"
        return exc_output

    def format(self, record: logging.LogRecord) -> str:
        ts = _format_ts(record, ms=self.ts_ms)
        lvl = record.levelname
        loc = f"{record.name}:{record.funcName}:{record.lineno}"
        indent = 0
        try:
            indent = int(getattr(record, "indent", 0) or 0)
        except Exception:
            indent = 0
        msg = record.getMessage()
        if indent > 0:
            msg = ("  " * indent) + msg

        kv = getattr(record, "kv", None)
        kv_str = _format_kv(kv if isinstance(kv, dict) else None)

        phase = str(getattr(record, "phase", "") or "").strip() or "-"
        step = str(getattr(record, "step", "") or "").strip() or "-"
        flow = f"{phase}/{step}" if (self.fixed_cols or phase != '-' or step != '-') else ""

        tid = str(getattr(record, "trace_id", "") or "").strip() or "-"
        req = ""
        rm = str(getattr(record, "req_method", "") or "").strip() or "-"
        rp = str(getattr(record, "req_path", "") or "").strip() or "-"
        if self.fixed_cols or self.show_req:
            req = f"{rm} {rp}" if (rm != "-" or rp != "-") else "-"


        if self.style == "classic":
            base = f"{ts} [{lvl}] {loc}: {msg}"
            if self.show_trace and tid not in {"-", ""}:
                base = f"{ts} [{lvl}] [{tid}] {loc}: {msg}"
            if req:
                base = f"{base} [{req}]"
            if flow:
                base = f"{base} [{flow}]"
            if kv_str:
                base = f"{base} | {kv_str}"
            base = self._colorize(record, base)
            base += self._format_exc(record, indent=indent)
            return base

        # pipe style
        cols = [ts, lvl]
        if self.fixed_cols:
            cols.append(tid)
            cols.append(loc)
            cols.append(req or "-")
            cols.append(flow or "-")
        else:
            if self.show_trace and tid not in {"-", ""}:
                cols.append(tid)
            cols.append(loc)
            if req and req != "-":
                cols.append(req)
            if flow:
                cols.append(flow)
        cols.append(msg)
        out = " | ".join(cols)
        if kv_str:
            out = f"{out} | {kv_str}"
        out = self._colorize(record, out)
        out += self._format_exc(record, indent=indent)
        return out


class JsonLineFormatter(logging.Formatter):
    """One JSON object per line for file logging."""

    def format(self, record: logging.LogRecord) -> str:
        ts_ms = _env_flag("LOG_TS_MS", False)
        payload = {
            "ts": _format_ts(record, ms=ts_ms),
            "level": record.levelname,
            "logger": record.name,
            "func": record.funcName,
            "line": record.lineno,
            "message": record.getMessage(),
            "kind": str(getattr(record, "kind", "") or ""),
            "trace_id": str(getattr(record, "trace_id", "") or ""),
            "req_method": str(getattr(record, "req_method", "") or ""),
            "req_path": str(getattr(record, "req_path", "") or ""),
            "phase": str(getattr(record, "phase", "") or ""),
            "step": str(getattr(record, "step", "") or ""),
            "indent": int(getattr(record, "indent", 0) or 0),
            "span_id": str(getattr(record, "span_id", "") or ""),
            "parent_span_id": str(getattr(record, "parent_span_id", "") or ""),
        }
        kv = getattr(record, "kv", None)
        if isinstance(kv, dict) and kv:
            payload["kv"] = kv
        if record.exc_info:
            payload["exc_info"] = self.formatException(record.exc_info)
        return json.dumps(payload, ensure_ascii=False, separators=(",", ":"))




class ContextKindFilter(logging.Filter):
    """Inject request/task context kind into records.

    If the current context kind is 'user', we force the record kind to 'user' so that
    every step of the user-triggered operation is colored green.
    """

    def filter(self, record: logging.LogRecord) -> bool:
        ctx_kind = str(get_kind() or "")
        if ctx_kind.lower() == "user":
            setattr(record, "kind", "user")
        else:
            # Only set kind if not already present
            if not hasattr(record, "kind"):
                setattr(record, "kind", "")
        return True


class ContextTraceFilter(logging.Filter):
    """Inject trace_id into every log record."""

    def filter(self, record: logging.LogRecord) -> bool:
        tid = str(get_trace_id() or "-")
        if not hasattr(record, "trace_id"):
            setattr(record, "trace_id", tid)
        else:
            # Prefer explicit record.trace_id, but fill if empty
            if not getattr(record, "trace_id", ""):
                setattr(record, "trace_id", tid)
        return True



class ContextFlowFilter(logging.Filter):
    """Inject step/phase + request method/path into every log record."""

    def filter(self, record: logging.LogRecord) -> bool:
        # step/phase
        step = getattr(record, "step", "") or get_step() or "-"
        phase = getattr(record, "phase", "") or get_phase() or "-"
        if not hasattr(record, "step") or not getattr(record, "step", ""):
            setattr(record, "step", step)
        if not hasattr(record, "phase") or not getattr(record, "phase", ""):
            setattr(record, "phase", phase)

        # request context
        rm = getattr(record, "req_method", "") or get_req_method() or "-"
        rp = getattr(record, "req_path", "") or get_req_path() or "-"
        if not hasattr(record, "req_method") or not getattr(record, "req_method", ""):
            setattr(record, "req_method", rm)
        if not hasattr(record, "req_path") or not getattr(record, "req_path", ""):
            setattr(record, "req_path", rp)
        return True


class ContextSpanFilter(logging.Filter):
    """Inject span ids (span_id, parent_span_id) into every log record."""

    def filter(self, record: logging.LogRecord) -> bool:
        sid = str(get_span_id() or "")
        psid = str(get_parent_span_id() or "")
        if not hasattr(record, "span_id") or not getattr(record, "span_id", ""):
            setattr(record, "span_id", sid)
        if not hasattr(record, "parent_span_id") or not getattr(record, "parent_span_id", ""):
            setattr(record, "parent_span_id", psid)
        return True



class AutoKVFilter(logging.Filter):
    """Merge non-standard LogRecord attributes into record.kv for display.

    Many legacy call-sites pass business fields via `extra={...}` without nesting
    under `kv`. This filter makes those fields visible in pipe logs as `k=v`.
    """
    _STD = set(logging.LogRecord("", 0, "", 0, "", (), None).__dict__.keys())
    _RESERVED = {
        # our own fields
        "kv", "kind", "trace_id", "req_method", "req_path", "phase", "step", "indent",
        "span_id", "parent_span_id",
        # logging internals we sometimes add
        "asctime",
    }

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            kv = getattr(record, "kv", None)
            if not isinstance(kv, dict):
                kv = {}
                setattr(record, "kv", kv)

            for k, v in list(record.__dict__.items()):
                if k in self._STD or k in self._RESERVED:
                    continue
                if k.startswith("_"):
                    continue
                if v is None:
                    continue
                # Avoid overwriting explicit kv.
                if k not in kv:
                    kv[k] = v
        except Exception:
            # Never break logging.
            return True
        return True

class ContextIndentFilter(logging.Filter):
    """Inject business indentation level into every log record."""

    def filter(self, record: logging.LogRecord) -> bool:
        if not hasattr(record, "indent") or getattr(record, "indent", None) is None:
            setattr(record, "indent", get_indent())
        else:
            try:
                if int(getattr(record, "indent") or 0) == 0:
                    setattr(record, "indent", get_indent())
            except Exception:
                setattr(record, "indent", get_indent())
        return True


class MaxLevelFilter(logging.Filter):
    """Allow records strictly below max_level."""

    def __init__(self, max_level: int) -> None:
        super().__init__()
        self.max_level = int(max_level)

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            return int(record.levelno) < self.max_level
        except Exception:
            return True


class MinLevelFilter(logging.Filter):
    """Allow records at/above min_level."""

    def __init__(self, min_level: int) -> None:
        super().__init__()
        self.min_level = int(min_level)

    def filter(self, record: logging.LogRecord) -> bool:
        try:
            return int(record.levelno) >= self.min_level
        except Exception:
            return True


def init_logging(level_name: str) -> None:
    """Initialize logging once.

    This module is the single place to control logging side-effects.
    """
    level = getattr(logging, str(level_name or "INFO").upper(), logging.INFO)
    use_color = _wants_color()

    root = logging.getLogger()
    root.setLevel(level)

    # Replace any default handlers to ensure our formatter applies.
    for h in list(root.handlers):
        root.removeHandler(h)

    style = _style()
    text_formatter = BizTextFormatter(style=style, use_color=use_color)

    # Console handlers (human-friendly):
    # - INFO/DEBUG -> stdout (good for "业务回显")
    # - WARNING/ERROR -> stderr (better for Docker/platform log routing)

    def _attach_common_filters(h: logging.Handler) -> None:
        h.addFilter(ContextKindFilter())
        h.addFilter(ContextTraceFilter())
        h.addFilter(ContextFlowFilter())
        h.addFilter(ContextSpanFilter())
        h.addFilter(ContextIndentFilter())
        h.addFilter(AutoKVFilter())

    sh_out = logging.StreamHandler(stream=sys.stdout)
    sh_out.setLevel(level)
    sh_out.setFormatter(text_formatter)
    sh_out.addFilter(MaxLevelFilter(logging.WARNING))
    _attach_common_filters(sh_out)
    root.addHandler(sh_out)

    sh_err = logging.StreamHandler(stream=sys.stderr)
    sh_err.setLevel(level)
    sh_err.setFormatter(text_formatter)
    sh_err.addFilter(MinLevelFilter(logging.WARNING))
    _attach_common_filters(sh_err)
    root.addHandler(sh_err)

    # Optional file handler (so users can "看到日志" even when stdout isn't captured).
    # Default path is /data/logs/app.log (docker volume). Can override via LOG_FILE.
    log_file = get_log_file()
    if log_file:
        try:
            os.makedirs(os.path.dirname(log_file) or ".", exist_ok=True)
            fh = logging.handlers.RotatingFileHandler(
                log_file,
                maxBytes=env_int("LOG_FILE_MAX_BYTES", 5242880, min_value=1024),  # 5MB default
                backupCount=env_int("LOG_FILE_BACKUP", 3, min_value=0, max_value=100),
                encoding="utf-8",
            )
            fh.setLevel(level)
            if _file_format() == "json":
                fh.setFormatter(JsonLineFormatter())
            else:
                fh.setFormatter(BizTextFormatter(style=style, use_color=False))
            fh.addFilter(ContextKindFilter())
            fh.addFilter(ContextTraceFilter())
            fh.addFilter(ContextFlowFilter())
            fh.addFilter(ContextSpanFilter())
            fh.addFilter(ContextIndentFilter())
            fh.addFilter(AutoKVFilter())
            root.addHandler(fh)
        except Exception as e:
            # Best-effort; never crash on logging setup, but make it visible.
            root.warning("logging_setup: file logging disabled path=%s err=%s", log_file, type(e).__name__)

    # Quiet some noisy third-party loggers to avoid leaking secrets.
    for name in ("httpx", "httpcore"):
        logging.getLogger(name).setLevel(logging.WARNING)

    # 让 uvicorn 的日志也使用我们的 formatter（带颜色）
    for uvi_name in ("uvicorn", "uvicorn.error"):
        uvi_logger = logging.getLogger(uvi_name)
        uvi_logger.handlers.clear()  # 移除 uvicorn 默认的 handler
        uvi_logger.propagate = True  # 让日志传播到 root logger

    # Uvicorn access log is noisy (only GET/POST lines). Default: silence it.
    # Set SHOW_ACCESS_LOG=true (or ACCESS_LOG=true) to re-enable.
    access_flag = get_access_log_flag_raw().strip().lower()
    if access_flag in ('1', 'true', 'yes', 'on'):
        logging.getLogger('uvicorn.access').setLevel(level)
    else:
        logging.getLogger('uvicorn.access').setLevel(logging.ERROR)


def log_run(logger: logging.Logger, message: str, **extra: Any) -> None:
    """Green action log (run/execute)."""
    logger.info(message, extra={"kind": "run", **extra})


def log_fetch(logger: logging.Logger, message: str, **extra: Any) -> None:
    """Green action log (fetch/get)."""
    logger.info(message, extra={"kind": "fetch", **extra})


def log_ok(logger: logging.Logger, message: str, **extra: Any) -> None:
    """Green action log (success)."""
    logger.info(message, extra={"kind": "ok", **extra})
