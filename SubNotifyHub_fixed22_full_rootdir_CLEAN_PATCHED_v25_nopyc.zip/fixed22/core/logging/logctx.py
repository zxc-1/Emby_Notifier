from __future__ import annotations

import contextvars
from contextlib import contextmanager
from typing import Iterator

# Request/task scoped log context:
# - kind: when set to "user", all INFO logs are colored green.
# - trace_id: correlation id to grep a whole flow (request -> queue -> worker -> notifier).
_kind_var: contextvars.ContextVar[str] = contextvars.ContextVar("log_kind", default="")
_trace_var: contextvars.ContextVar[str] = contextvars.ContextVar("trace_id", default="")
_step_var: contextvars.ContextVar[str] = contextvars.ContextVar("log_step", default="")
_phase_var: contextvars.ContextVar[str] = contextvars.ContextVar("log_phase", default="")
_req_path_var: contextvars.ContextVar[str] = contextvars.ContextVar("req_path", default="")
_req_method_var: contextvars.ContextVar[str] = contextvars.ContextVar("req_method", default="")

# Span context (for JSONL trace visualization):
# - span_id: current logical span
# - parent_span_id: immediate parent span (empty for root)
_span_id_var: contextvars.ContextVar[str] = contextvars.ContextVar("span_id", default="")
_parent_span_id_var: contextvars.ContextVar[str] = contextvars.ContextVar("parent_span_id", default="")

# Business-log indentation level (for grouped flows).
_indent_var: contextvars.ContextVar[int] = contextvars.ContextVar("log_indent", default=0)

def get_kind() -> str:
    return _kind_var.get()

def get_trace_id() -> str:
    return _trace_var.get()

@contextmanager
def set_kind(kind: str) -> Iterator[None]:
    token = _kind_var.set(kind or "")
    try:
        yield
    finally:
        _kind_var.reset(token)

@contextmanager
def set_trace_id(trace_id: str) -> Iterator[None]:
    token = _trace_var.set(trace_id or "")
    try:
        yield
    finally:
        _trace_var.reset(token)



def get_step() -> str:
    return _step_var.get()

def get_phase() -> str:
    return _phase_var.get()

def get_req_path() -> str:
    return _req_path_var.get()

def get_req_method() -> str:
    return _req_method_var.get()


def get_span_id() -> str:
    return _span_id_var.get()


def get_parent_span_id() -> str:
    return _parent_span_id_var.get()


@contextmanager
def set_span(span_id: str, parent_span_id: str = "") -> Iterator[None]:
    """Set span context for the current logical operation."""
    t1 = _span_id_var.set(span_id or "")
    t2 = _parent_span_id_var.set(parent_span_id or "")
    try:
        yield
    finally:
        _parent_span_id_var.reset(t2)
        _span_id_var.reset(t1)


def get_indent() -> int:
    try:
        return int(_indent_var.get() or 0)
    except Exception:
        return 0


@contextmanager
def set_indent(level: int) -> Iterator[None]:
    """Set indentation level for the current context."""
    try:
        lvl = max(0, int(level or 0))
    except Exception:
        lvl = 0
    token = _indent_var.set(lvl)
    try:
        yield
    finally:
        _indent_var.reset(token)


@contextmanager
def inc_indent(delta: int = 1) -> Iterator[None]:
    """Increase indentation level for the current context."""
    cur = get_indent()
    try:
        d = int(delta or 0)
    except Exception:
        d = 0
    with set_indent(cur + d):
        yield

@contextmanager
def set_step(step: str) -> Iterator[None]:
    token = _step_var.set(step or "")
    try:
        yield
    finally:
        _step_var.reset(token)

@contextmanager
def set_phase(phase: str) -> Iterator[None]:
    token = _phase_var.set(phase or "")
    try:
        yield
    finally:
        _phase_var.reset(token)

@contextmanager
def set_request(method: str, path: str) -> Iterator[None]:
    t1 = _req_method_var.set(method or "")
    t2 = _req_path_var.set(path or "")
    try:
        yield
    finally:
        _req_path_var.reset(t2)
        _req_method_var.reset(t1)


def is_user_path(path: str) -> bool:
    # User-triggered actions:
    # - admin UI / auth
    # - UI prefs (theme/background)
    # - forward bridge client calls
    # - debug endpoints
    return (
        path.startswith("/admin")
        or path.startswith("/api/ui_prefs")
        or path.startswith("/forward")
        or path.startswith("/debug")
    )
