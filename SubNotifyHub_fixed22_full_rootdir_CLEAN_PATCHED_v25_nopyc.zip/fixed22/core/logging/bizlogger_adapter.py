from __future__ import annotations

"""A drop-in stdlib-logging adapter for "business log" style.

This project already contains lots of classic logging calls with printf-style args
and custom `extra=...` fields (step/phase, etc.). Converting every call-site to
`core.bizlog.BizLogger` DSL is time-consuming and risky.

Instead, we provide a logger adapter that:
1) Infers `record.kind` when missing (user_action/warn/fail) so the formatter can
   render / colorize consistently.
2) Adds minimal emoji prefixes (⚠️/❌) for warning/error when not present.
3) Preserves existing args and `extra` dicts (does not break `%s` formatting).

Use it by replacing:
    logger = logging.getLogger(__name__)
with:
    from core.logging import get_biz_logger_adapter
    logger = get_biz_logger_adapter(__name__)

NOTE: This does not replace the BizLogger DSL (`core.logging.bizlog`). BizLogger is still
recommended for step-based flows and grouped operations where you want automatic
summary lines and counters.
"""

import logging
from typing import Any, Dict, Optional

from .bizlog import is_detail_enabled
from .logctx import get_kind


def _ensure_extra(kwargs: Dict[str, Any]) -> Dict[str, Any]:
    extra = kwargs.get("extra")
    if isinstance(extra, dict):
        return extra
    if extra is None:
        extra = {}
        kwargs["extra"] = extra
        return extra
    # Unexpected type: drop it (avoid crashes).
    kwargs["extra"] = {}
    return kwargs["extra"]


def _prefix_if_needed(msg: Any, prefix: str) -> Any:
    """Best-effort emoji prefix.

    Keep msg type (usually str). For non-str messages, avoid coercing.
    """
    try:
        s = str(msg)
    except Exception:
        return msg
    s_strip = s.lstrip()
    if s_strip.startswith(("✅", "⚠️", "❌", "▶️", "ℹ️")):
        return msg
    return f"{prefix}{s}"


class BizLoggerAdapter(logging.LoggerAdapter):
    """A LoggerAdapter that injects business-log semantics."""

    def _move_custom_kwargs_to_extra(self, kwargs: Dict[str, Any]) -> None:
        """Move non-stdlib logging kwargs into `extra`.

        Stdlib logging only accepts a small set of keyword args (exc_info,
        stack_info, stacklevel, extra). A lot of call-sites in this project
        pass business fields like trace_id/user_id/... as keyword args.

        If we pass those through, stdlib will raise:
            TypeError: Logger._log() got an unexpected keyword argument ...

        So we normalize them into `extra` to preserve information without
        breaking logging.
        """

        if not kwargs:
            return
        extra = _ensure_extra(kwargs)
        standard_kwargs = {"exc_info", "stack_info", "stacklevel", "extra"}
        for key in list(kwargs.keys()):
            if key not in standard_kwargs:
                extra[key] = kwargs.pop(key)

    def _guard_positional_args(self, msg: Any, args: tuple[Any, ...], kwargs: Dict[str, Any]) -> tuple[Any, tuple[Any, ...]]:
        """Prevent accidental stdlib-logging `%` formatting crashes.

        If a caller passes positional `args`, the stdlib logger will attempt:

            msg % args

        That is correct for classic printf-style logging, but it will raise
        TypeError when msg has no placeholders (a common mistake), which hides
        the original exception.

        Strategy:
        - If msg is a string and appears to use printf placeholders (`%`), keep args.
        - Otherwise, move the args into `extra['args_raw']` and clear args.
        """
        if not args:
            return msg, args

        try:
            s = msg if isinstance(msg, str) else str(msg)
        except Exception:
            s = ""

        if isinstance(msg, str) and "%" in s:
            # Caller likely intends printf formatting.
            return msg, args

        extra = _ensure_extra(kwargs)
        # Preserve any existing args_raw (append)
        existing = extra.get("args_raw")
        if existing is None:
            extra["args_raw"] = list(args)
        else:
            try:
                extra["args_raw"] = list(existing) + list(args)
            except Exception:
                extra["args_raw"] = list(args)
        return msg, ()

    def _inject_kind(self, kwargs: Dict[str, Any], *, default_kind: str) -> None:
        extra = _ensure_extra(kwargs)
        # Do not override explicit kind.
        if "kind" not in extra or not extra.get("kind"):
            # Only treat logs as "business" when context kind indicates user flow.
            if (get_kind() or "").lower() == "user":
                extra["kind"] = default_kind

    # ---- overrides ----
    def info(self, msg: Any, *args: Any, **kwargs: Any) -> None:  # type: ignore[override]
        self._inject_kind(kwargs, default_kind="user_action")
        msg, args2 = self._guard_positional_args(msg, args, kwargs)
        self._move_custom_kwargs_to_extra(kwargs)
        return super().info(msg, *args2, **kwargs)

    def detail(self, msg: Any, *args: Any, **kwargs: Any) -> None:
        """Detail log line (human-readable debug).

        Spec alignment:
        - Controlled by BIZ_DETAIL (like BizLogger.detail).
        - Emits at INFO so it is visible even when LOG_LEVEL=INFO.
        """
        if not is_detail_enabled():
            return None
        self._inject_kind(kwargs, default_kind="detail")
        msg, args2 = self._guard_positional_args(msg, args, kwargs)
        self._move_custom_kwargs_to_extra(kwargs)
        return super().info(msg, *args2, **kwargs)

    def warning(self, msg: Any, *args: Any, **kwargs: Any) -> None:  # type: ignore[override]
        self._inject_kind(kwargs, default_kind="warn")
        msg2 = _prefix_if_needed(msg, "⚠️ ")
        msg2, args2 = self._guard_positional_args(msg2, args, kwargs)
        self._move_custom_kwargs_to_extra(kwargs)
        return super().warning(msg2, *args2, **kwargs)

    def error(self, msg: Any, *args: Any, **kwargs: Any) -> None:  # type: ignore[override]
        self._inject_kind(kwargs, default_kind="fail")
        msg2 = _prefix_if_needed(msg, "❌ ")
        msg2, args2 = self._guard_positional_args(msg2, args, kwargs)
        self._move_custom_kwargs_to_extra(kwargs)
        return super().error(msg2, *args2, **kwargs)

    def exception(self, msg: Any, *args: Any, exc_info: Any = True, **kwargs: Any) -> None:  # type: ignore[override]
        # exception() is always error-level + traceback.
        self._inject_kind(kwargs, default_kind="fail")
        msg2 = _prefix_if_needed(msg, "❌ ")
        # Defensive: avoid TypeError if caller passes exc_info via **kwargs.
        if 'exc_info' in kwargs:
            exc_info = kwargs.pop('exc_info')
        msg2, args2 = self._guard_positional_args(msg2, args, kwargs)
        self._move_custom_kwargs_to_extra(kwargs)
        return super().exception(msg2, *args2, exc_info=exc_info, **kwargs)

    def fail(self, msg: Any, *args: Any, exc: Optional[BaseException] = None, **kwargs: Any) -> None:
        """Alias for error() to match BizLogger API.
        
        This method provides compatibility with BizLogger.fail() calls.
        If exc is provided, it will be logged with traceback.
        """
        self._inject_kind(kwargs, default_kind="fail")
        msg2 = _prefix_if_needed(msg, "❌ ")

        msg2, args2 = self._guard_positional_args(msg2, args, kwargs)
        
        # Extract extra dict and move all non-standard kwargs into it
        extra = _ensure_extra(kwargs)
        
        # Standard logging kwargs that should NOT go into extra
        standard_kwargs = {'exc_info', 'stack_info', 'stacklevel', 'extra'}
        
        # Move all custom kwargs (like trace_id, etc.) into extra
        custom_keys = [k for k in kwargs.keys() if k not in standard_kwargs]
        for key in custom_keys:
            extra[key] = kwargs.pop(key)
        
        # If exc is provided, log with traceback
        if exc is not None:
            # Store exc in extra for potential use by formatters
            extra['exc'] = exc
            # Use exception() to get traceback
            return super().exception(msg2, *args2, exc_info=exc, **kwargs)
        else:
            # No exception, just log as error
            return super().error(msg2, *args2, **kwargs)


def get_biz_logger_adapter(name: str, *, extra: Optional[Dict[str, Any]] = None) -> BizLoggerAdapter:
    """Get a logger that behaves like stdlib logging but renders like business logs."""
    base = logging.getLogger(name)
    return BizLoggerAdapter(base, extra or {})
