from __future__ import annotations

"""Business logging helpers.

Goal: make user-facing operational logs readable like a CLI UI:
- step-based
- grouped (nested) with indentation
- consistent result markers (✅/⚠️/❌)
- structured key-value fields (kv=...)

This module does NOT replace stdlib logging; it provides a thin DSL on top of it.
"""

import contextvars
import logging
import sys
import time
from uuid import uuid4
from contextlib import contextmanager
from typing import Any, Dict, Iterator, Mapping, Optional, Tuple

from .logctx import inc_indent, set_phase, set_step, get_phase, get_span_id, set_span

from core.env_utils import env_bool, env_int, env_str


logger = logging.getLogger(__name__)

def _truthy_env(name: str) -> bool:
    v = env_str(name, '').strip().lower()
    return v in {'1', 'true', 'yes', 'y', 'on'}


def is_detail_enabled(domain: str | None = None) -> bool:
    """Whether to emit verbose business-detail logs.

    BIZ_DETAIL supports:
      - 1/true/on/all : enable for all domains
      - comma-separated domains (matching `logctx.phase`), e.g. "TMDB,115"
    """
    raw = env_str('BIZ_DETAIL', '').strip()
    if not raw:
        return False
    low = raw.lower()
    if low in {'1','true','yes','y','on','all'}:
        return True
    dom = str(domain or (get_phase() or '')).strip()
    if not dom:
        return False
    allowed = {s.strip() for s in raw.split(',') if s.strip()}
    return dom in allowed


def _should_log_item(i: int, total: int) -> bool:
    """Decide whether to log per-item lines.

    By default we log everything. If BIZ_ITEM_SAMPLE is enabled, we only log
    the head/tail items to avoid spamming huge loops. Fail items should still
    be emitted by callers regardless of sampling.
    """
    try:
        if not env_bool('BIZ_ITEM_SAMPLE', False):
            return True
        head = env_int('BIZ_ITEM_HEAD', 3, min_value=0, max_value=50)
        tail = env_int('BIZ_ITEM_TAIL', 1, min_value=0, max_value=50)
        head = max(0, min(50, head))
        tail = max(0, min(50, tail))
        if total <= head + tail:
            return True
        return (i <= head) or (i > total - tail)
    except Exception:
        return True


# A per-context stack of active biz groups.
# A per-context stack of active biz groups.
_stack_var: contextvars.ContextVar[Tuple[Dict[str, Any], ...]] = contextvars.ContextVar(
    "bizlog_stack", default=()
)

# Optional per-group result override (set by callers via set_result()).
_result_var: contextvars.ContextVar[Optional[Dict[str, Any]]] = contextvars.ContextVar(
    "bizlog_result", default=None
)

# Simple throttle state for high-frequency warnings.
_throttle_map: Dict[str, float] = {}

def _throttle_allow(key: str, *, seconds: int) -> bool:
    try:
        now = time.monotonic()
        last = float(_throttle_map.get(key) or 0.0)
        if now - last < float(seconds):
            return False
        _throttle_map[key] = now
        # best-effort size cap
        if len(_throttle_map) > 4096:
            _throttle_map.clear()
        return True
    except Exception:
        return True



def _top() -> Optional[Dict[str, Any]]:
    st = _stack_var.get()
    if not st:
        return None
    return st[-1]


def _push(ent: Dict[str, Any]) -> None:
    st = _stack_var.get()
    _stack_var.set((*st, ent))


def _pop() -> Optional[Dict[str, Any]]:
    st = _stack_var.get()
    if not st:
        return None
    ent = st[-1]
    _stack_var.set(st[:-1])
    return ent


def _inc_counter(kind: str) -> None:
    """Increment counters for the current biz group.

    We intentionally *propagate* counts to all active parent groups so the
    outermost summary reflects the whole flow.
    """
    st = _stack_var.get()
    if not st:
        return

    k = (kind or "").lower()
    field = None
    if k in {"ok", "success"}:
        field = "ok"
    elif k in {"warn", "warning", "skip"}:
        field = "skip"
    elif k in {"fail", "error"}:
        field = "fail"
    if not field:
        return

    # Propagate upwards.
    for ent in st:
        ent[field] = int(ent.get(field) or 0) + 1



def _kv_merge(base: Optional[Mapping[str, Any]], extra: Mapping[str, Any]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    if base:
        out.update(dict(base))
    for k, v in (extra or {}).items():
        # Keep None values out to reduce noise.
        if v is None:
            continue
        out[str(k)] = v
    return out

# Reserved keyword names for BizLogger._emit(). If user kv contains these keys and we forward
# them as **kwargs while also passing explicit named args (kind/kv/exc/count), Python will
# raise "got multiple values for keyword argument ...". We transparently rename them.
_EMIT_RESERVED_KW_RENAMES = {
    "kind": "user_kind",
    "kv": "user_kv",
    "exc": "user_exc",
    "count": "user_count",
}

def _sanitize_emit_kwargs(kv: Mapping[str, Any] | None) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    if not kv:
        return out
    for k, v in dict(kv).items():
        kk = _EMIT_RESERVED_KW_RENAMES.get(str(k), str(k))
        out[str(kk)] = v
    return out


class BizLogger:
    """A tiny DSL wrapper around stdlib logging."""

    def __init__(self, name: str) -> None:
        self._logger = logging.getLogger(name)

    def _fmt_msg(self, msg: Any, args: Tuple[Any, ...]) -> str:
        """logging 风格的 printf 格式化：logger.debug("x=%s", x)"""
        if not args:
            try:
                return str(msg)
            except Exception:
                return "<?>"
        try:
            return str(msg) % args
        except Exception:
            # 兜底：避免格式化异常反过来把业务流程打崩
            try:
                return f"{msg} {args}"
            except Exception:
                return "<?>"

    def _exc_from_exc_info(self, exc_info: Any) -> Optional[BaseException]:
        """兼容 logging 的 exc_info=True/tuple/Exception"""
        if not exc_info:
            return None
        if exc_info is True:
            return sys.exc_info()[1]
        if isinstance(exc_info, BaseException):
            return exc_info
        if isinstance(exc_info, tuple) and len(exc_info) >= 2 and isinstance(exc_info[1], BaseException):
            return exc_info[1]
        return None

    def _emit(
        self,
        level: int,
        msg: str,
        *,
        kind: str = "user_action",
        kv: Optional[Mapping[str, Any]] = None,
        exc: Optional[BaseException] = None,
        count: bool = True,
        **more_kv: Any,
    ) -> None:
        merged = _kv_merge(kv, more_kv)
        extra = {"kind": kind, "kv": merged}
        if exc is not None:
            # Use the provided exception traceback (not only the current one).
            merged.setdefault('err', f"{type(exc).__name__}: {exc}")
            tb = getattr(exc, '__traceback__', None)
            self._logger.log(level, '%s', msg, extra=extra, exc_info=(type(exc), exc, tb))
        else:
            self._logger.log(level, "%s", msg, extra=extra)

        if count:
            _inc_counter(kind)

    # ---- public APIs ----
    def set_result(self, level: str, msg: str = '完成', **kv: Any) -> None:
        """Set the final conclusion line for the current biz group.

        This is useful for entry wrappers (HTTP/TG/Task) to record an overall
        result (e.g., HTTP status) while still letting the group print a single
        consistent conclusion line.
        
        level: ok|warn|fail
        """
        try:
            _result_var.set({'level': str(level or '').lower(), 'msg': str(msg or '').strip(), 'kv': dict(kv or {})})
        except Exception:
            return

    def step(self, msg: str, *, i: Optional[int] = None, total: Optional[int] = None, **kv: Any) -> None:
        if i is not None and total is not None:
            prefix = f"第{i}步/共{total}步 "
        elif i is not None:
            prefix = f"第{i}步 "
        else:
            prefix = "步骤 "
        self._emit(logging.INFO, f"{prefix}{msg}", kind="user_action", **_sanitize_emit_kwargs(kv))

    def detail_step(self, msg: str, *, i: Optional[int] = None, total: Optional[int] = None, **kv: Any) -> None:
        """A step log that is emitted only when BIZ_DETAIL is enabled."""
        if not is_detail_enabled():
            return
        self.step(msg, i=i, total=total, **kv)

    def detail(self, msg: str, **kv: Any) -> None:
        """A business-detail log line (gated by BIZ_DETAIL)."""
        if not is_detail_enabled():
            return
        self._emit(logging.INFO, msg, kind="user_action", **_sanitize_emit_kwargs(kv))

    def detail_item(self, msg: str, *, i: int, total: int, **kv: Any) -> None:
        """A per-item business-detail line.

        - gated by BIZ_DETAIL
        - respects sampling (BIZ_ITEM_SAMPLE)
        - does NOT affect ok/skip/fail counters
        """
        if not is_detail_enabled():
            return
        if not _should_log_item(int(i), int(total)):
            return
        self._emit(
            logging.INFO,
            f"· ({i}/{total}) {msg}",
            kind="user_action",
            count=False,
            **_sanitize_emit_kwargs(kv),
        )

    # ---- stdlib logging compatibility layer ----
    def debug(self, msg: Any, *args: Any, **kv: Any) -> None:
        """Compatible with logging.Logger.debug.

        We treat debug as business-detail logs:
        - gated by BIZ_DETAIL
        - kind=debug (cyan)
        """
        if not is_detail_enabled():
            return
        exc = self._exc_from_exc_info(kv.pop('exc_info', None))
        extra = kv.pop('extra', None)
        if isinstance(extra, dict):
            kv = {**extra, **kv}
        text = self._fmt_msg(msg, args)
        self._emit(logging.INFO, text, kind='debug', exc=exc, count=False, **_sanitize_emit_kwargs(kv))

    def exception(self, msg: Any, *args: Any, **kv: Any) -> None:
        """Compatible with logging.Logger.exception (ERROR + traceback)."""
        exc_info = kv.pop('exc_info', True)
        exc = self._exc_from_exc_info(exc_info) or sys.exc_info()[1]
        extra = kv.pop('extra', None)
        if isinstance(extra, dict):
            kv = {**extra, **kv}
        text = self._fmt_msg(msg, args)
        # keep emoji style consistent with BizLogger.fail()
        if not str(text).lstrip().startswith(('❌', '⚠️', '✅', '▶️', 'ℹ️')):
            text = f"❌ {text}"
        self._emit(logging.ERROR, text, kind='fail', exc=exc, **_sanitize_emit_kwargs(kv))

    def warning(self, msg: Any, *args: Any, **kv: Any) -> None:
        """Compatible with logging.Logger.warning."""
        exc = self._exc_from_exc_info(kv.pop('exc_info', None))
        extra = kv.pop('extra', None)
        if isinstance(extra, dict):
            kv = {**extra, **kv}
        text = self._fmt_msg(msg, args)
        if not str(text).lstrip().startswith(('❌', '⚠️', '✅', '▶️', 'ℹ️')):
            text = f"⚠️ {text}"
        self._emit(logging.WARNING, text, kind='warn', exc=exc, **_sanitize_emit_kwargs(kv))

    def error(self, msg: Any, *args: Any, **kv: Any) -> None:
        """Compatible with logging.Logger.error."""
        exc = self._exc_from_exc_info(kv.pop('exc_info', None))
        extra = kv.pop('extra', None)
        if isinstance(extra, dict):
            kv = {**extra, **kv}
        text = self._fmt_msg(msg, args)
        if not str(text).lstrip().startswith(('❌', '⚠️', '✅', '▶️', 'ℹ️')):
            text = f"❌ {text}"
        self._emit(logging.ERROR, text, kind='fail', exc=exc, **_sanitize_emit_kwargs(kv))

    def critical(self, msg: Any, *args: Any, **kv: Any) -> None:
        """Compatible with logging.Logger.critical."""
        self.error(msg, *args, **kv)

    def info(self, msg: Any, *args: Any, **kv: Any) -> None:
        """Compatible with logging.Logger.info.

        Supports printf-style formatting (logger.info("x=%s", x)),
        and logging-style `extra={...}` / `exc_info=...`.
        """
        exc = self._exc_from_exc_info(kv.pop('exc_info', None))
        extra = kv.pop('extra', None)
        if isinstance(extra, dict):
            kv = {**extra, **kv}
        text = self._fmt_msg(msg, args)
        if not str(text).lstrip().startswith(('❌', '⚠️', '✅', '▶️', 'ℹ️')):
            text = f"ℹ️ {text}"
        self._emit(logging.INFO, text, kind="user_action", exc=exc, **_sanitize_emit_kwargs(kv))

    def ok(self, msg: Any, *args: Any, **kv: Any) -> None:
        """Success marker line (✅), logging-compatible formatting."""
        extra = kv.pop('extra', None)
        if isinstance(extra, dict):
            kv = {**extra, **kv}
        text = self._fmt_msg(msg, args)
        if not str(text).lstrip().startswith(('❌', '⚠️', '✅', '▶️', 'ℹ️')):
            text = f"✅ {text}"
        self._emit(logging.INFO, text, kind="ok", **_sanitize_emit_kwargs(kv))

    def ok_item(self, msg: Any, *args: Any, i: int, total: int, **kv: Any) -> None:
        """Per-item success line (✅ (i/total) ...), supports printf-style formatting."""
        if not _should_log_item(int(i), int(total)):
            _inc_counter('ok')
            return
        extra = kv.pop('extra', None)
        if isinstance(extra, dict):
            kv = {**extra, **kv}
        text = self._fmt_msg(msg, args)
        self._emit(logging.INFO, f"✅ ({i}/{total}) {text}", kind='ok', **_sanitize_emit_kwargs(kv))

    def warn_item(self, msg: Any, *args: Any, i: int, total: int, **kv: Any) -> None:
        """Per-item warning line (⚠️ (i/total) ...), supports printf-style formatting."""
        if not _should_log_item(int(i), int(total)):
            _inc_counter('warn')
            return
        exc = self._exc_from_exc_info(kv.pop('exc_info', None))
        extra = kv.pop('extra', None)
        if isinstance(extra, dict):
            kv = {**extra, **kv}
        text = self._fmt_msg(msg, args)
        self._emit(logging.WARNING, f"⚠️ ({i}/{total}) {text}", kind='warn', exc=exc, **_sanitize_emit_kwargs(kv))

    def fail_item(
        self,
        msg: Any,
        *args: Any,
        i: int,
        total: int,
        exc: Optional[BaseException] = None,
        **kv: Any,
    ) -> None:
        """Per-item failure line (❌ (i/total) ...), supports printf-style formatting."""
        exc = exc or self._exc_from_exc_info(kv.pop('exc_info', None))
        extra = kv.pop('extra', None)
        if isinstance(extra, dict):
            kv = {**extra, **kv}
        text = self._fmt_msg(msg, args)
        self._emit(logging.ERROR, f"❌ ({i}/{total}) {text}", kind="fail", exc=exc, **_sanitize_emit_kwargs(kv))

    def warn(self, msg: Any, *args: Any, **kv: Any) -> None:
        """Warning marker line (⚠️), logging-compatible formatting + optional throttling."""
        exc = self._exc_from_exc_info(kv.pop('exc_info', None))
        extra = kv.pop('extra', None)
        if isinstance(extra, dict):
            kv = {**extra, **kv}

        # Optional throttle for high-frequency reasons.
        try:
            if (env_str('BIZ_THROTTLE_REASON', '').strip() == '' or _truthy_env('BIZ_THROTTLE_REASON')) and 'reason' in kv:
                sec = env_int('BIZ_THROTTLE_SECONDS', 30, min_value=1, max_value=3600)
                key = f"{get_phase() or ''}|{kv.get('reason')}"
                if not _throttle_allow(key, seconds=sec):
                    _inc_counter('warn')
                    return
        except (ValueError, TypeError, KeyError):
            pass

        text = self._fmt_msg(msg, args)
        if not str(text).lstrip().startswith(('❌', '⚠️', '✅', '▶️', 'ℹ️')):
            text = f"⚠️ {text}"
        self._emit(logging.WARNING, text, kind="warn", exc=exc, **_sanitize_emit_kwargs(kv))

    def fail(self, msg: Any, *args: Any, exc: Optional[BaseException] = None, **kv: Any) -> None:
        """Failure marker line (❌), logging-compatible formatting."""
        exc = exc or self._exc_from_exc_info(kv.pop('exc_info', None))
        extra = kv.pop('extra', None)
        if isinstance(extra, dict):
            kv = {**extra, **kv}
        text = self._fmt_msg(msg, args)
        if not str(text).lstrip().startswith(('❌', '⚠️', '✅', '▶️', 'ℹ️')):
            text = f"❌ {text}"
        self._emit(logging.ERROR, text, kind="fail", exc=exc, **_sanitize_emit_kwargs(kv))
    @contextmanager
    def group(self, group_title: str, **kv: Any) -> Iterator[None]:
        """A grouped operation with indentation + automatic conclusion line.

        The conclusion line is always emitted exactly once:
        - normal completion: ✅/⚠️ based on counters or an explicit set_result()
        - exception: ❌ (and re-raises)
        """
        parent_span = str(get_span_id() or "")
        span_id = uuid4().hex[:12]
        ent: Dict[str, Any] = {
            "title": group_title,
            "t0": time.perf_counter(),
            "ok": 0,
            "skip": 0,
            "fail": 0,
            "span_id": span_id,
            "parent_span_id": parent_span,
        }
        _push(ent)
        res_tok = _result_var.set(None)
        try:
            with set_span(span_id, parent_span):
                self._emit(logging.INFO, f"▶️ {group_title}", kind="user_action", **_sanitize_emit_kwargs(kv))
                with inc_indent(1):
                    yield
        except Exception as e:
            dt = int((time.perf_counter() - float(ent.get("t0") or 0.0)) * 1000)
            ok = int(ent.get("ok") or 0)
            skip = int(ent.get("skip") or 0)
            fail = int(ent.get("fail") or 0)
            res = _result_var.get() or {}
            res_kv = dict(res.get("kv") or {}) if isinstance(res, dict) else {}
            msg = str(res.get("msg") or "失败").strip() if isinstance(res, dict) else "失败"
            final = msg if group_title in msg else f"{msg} {group_title}"
            if not final.lstrip().startswith(("✅", "⚠️", "❌")):
                final = f"❌ {final}"
            merged_kv: Dict[str, Any] = dict(kv or {})
            merged_kv.update(res_kv or {})
            # Ensure meta fields are authoritative and avoid duplicate-kw crashes.
            merged_kv.update(
                {
                    "duration_ms": dt,
                    "ok": ok,
                    "skip": skip,
                    "fail": fail,
                    "span_id": span_id,
                    "parent_span_id": parent_span,
                }
            )
            self._emit(
                logging.ERROR,
                final,
                kind="meta",
                count=False,
                exc=e,
                **_sanitize_emit_kwargs(merged_kv),
            )
            _pop()
            _result_var.reset(res_tok)
            raise
        else:
            dt = int((time.perf_counter() - float(ent.get("t0") or 0.0)) * 1000)
            ok = int(ent.get("ok") or 0)
            skip = int(ent.get("skip") or 0)
            fail = int(ent.get("fail") or 0)

            res = _result_var.get()
            level_s = ""
            msg = ""
            res_kv: Dict[str, Any] = {}
            if isinstance(res, dict) and res:
                level_s = str(res.get("level") or "").lower()
                msg = str(res.get("msg") or "").strip()
                res_kv = dict(res.get("kv") or {})
            if not msg:
                # Derive a reasonable default from counters.
                if fail > 0:
                    level_s = "warn"
                    msg = "完成（部分失败）"
                elif skip > 0:
                    level_s = "warn"
                    msg = "完成（含跳过）"
                else:
                    level_s = "ok"
                    msg = "完成"

            marker = {"ok": "✅", "warn": "⚠️", "fail": "❌"}.get(level_s, "✅")
            lvl = {"ok": logging.INFO, "warn": logging.WARNING, "fail": logging.ERROR}.get(level_s, logging.INFO)
            final = msg if group_title in msg else f"{msg} {group_title}"
            if not final.lstrip().startswith(("✅", "⚠️", "❌")):
                final = f"{marker} {final}"

            merged_kv: Dict[str, Any] = dict(kv or {})
            merged_kv.update(res_kv or {})
            # Ensure meta fields are authoritative and avoid duplicate-kw crashes.
            merged_kv.update(
                {
                    "duration_ms": dt,
                    "ok": ok,
                    "skip": skip,
                    "fail": fail,
                    "span_id": span_id,
                    "parent_span_id": parent_span,
                }
            )
            self._emit(
                lvl,
                final,
                kind="meta",
                count=False,
                **_sanitize_emit_kwargs(merged_kv),
            )
            _pop()
            _result_var.reset(res_tok)


    @contextmanager
    def entry(
        self,
        *,
        domain: str,
        action: str,
        group_title: str | None = None,
        **kv: Any,
    ) -> Iterator[None]:
        """A standardized entry group for a business flow.

        - Sets logctx phase/step so the formatter shows a consistent flow column.
        - Uses a consistent title format: "{domain} {action}" (unless overridden).
        - Delegates to `group()` for indentation + summary.
        """
        d = str(domain or "").strip() or "biz"
        a = str(action or "").strip() or "run"
        ttl = str(group_title or "").strip() or f"{d} {a}"
        with set_phase(d), set_step(a):
            with self.group(ttl, domain=d, action=a, **kv):
                yield


def get_biz_logger(name: str) -> BizLogger:
    return BizLogger(name)
