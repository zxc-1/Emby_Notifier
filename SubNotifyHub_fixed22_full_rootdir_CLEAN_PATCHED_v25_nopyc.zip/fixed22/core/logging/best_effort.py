from __future__ import annotations

from typing import Any, Mapping, Optional

from .bizlog import _throttle_allow
from .logctx import get_trace_id, get_req_path, get_req_method
from .bizlogger_adapter import BizLoggerAdapter


def best_effort_log(
    logger: BizLoggerAdapter,
    message: str,
    *,
    throttle_key: Optional[str] = None,
    throttle_seconds: int = 60,
    extra: Optional[Mapping[str, Any]] = None,
    exc_info: bool = True,
) -> None:
    """Log a best-effort failure with sane defaults.

    Used for dashboard/admin endpoints where we intentionally degrade instead of
    failing hard. This helper ensures we always log with trace_id and request
    context, and prevents log spam via throttling.

    Args:
        logger: BizLoggerAdapter
        message: log message (human readable)
        throttle_key: if set, throttle by this key for ``throttle_seconds``
        throttle_seconds: throttle window seconds
        extra: extra kv fields
        exc_info: include exception stack when called from except
    """
    try:
        key = throttle_key or f"best_effort:{message}"
        if throttle_seconds and (not _throttle_allow(key, seconds=int(throttle_seconds))):
            return
        kv = dict(extra or {})
        kv.setdefault("trace_id", get_trace_id())
        kv.setdefault("req_path", get_req_path())
        kv.setdefault("req_method", get_req_method())
        logger.detail(message, exc_info=exc_info, **kv)
    except Exception:
        # never break caller
        return
