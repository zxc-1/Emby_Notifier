"""Logging submodule - unified logging infrastructure.

This module provides a unified interface for business logging, including:
- BizLogger: A DSL wrapper for step-based, grouped business logs
- BizLoggerAdapter: A stdlib-compatible adapter for existing logging calls
- Logging setup utilities: init_logging, log_ok, log_run
- Log context management: trace_id, span_id, phase, step, etc.

Usage:
    from core.logging import BizLogger, get_biz_logger
    from core.logging import get_biz_logger_adapter
    from core.logging import init_logging, log_ok, log_run
    from core.logging import get_trace_id, set_trace_id, logctx
"""

from __future__ import annotations

import logging

# Re-export from bizlog
from .bizlog import (
    BizLogger,
    get_biz_logger,
    is_detail_enabled,
    _throttle_map,
    _should_log_item,
    _top,
    _stack_var,
)

# Re-export from bizlogger_adapter
from .bizlogger_adapter import (
    BizLoggerAdapter,
    get_biz_logger_adapter,
)

# Re-export from logging_setup
from .logging_setup import (
    init_logging,
    log_ok,
    log_run,
    log_fetch,
    BizTextFormatter,
    JsonLineFormatter,
    get_kind_colors,
    AutoKVFilter,
    ContextKindFilter,
    ContextTraceFilter,
    ContextFlowFilter,
    ContextSpanFilter,
    ContextIndentFilter,
    _ANSI,
    _KIND_COLORS,
    _style,
)

# Re-export from logctx
from .logctx import (
    get_kind,
    set_kind,
    get_trace_id,
    set_trace_id,
    get_step,
    set_step,
    get_phase,
    set_phase,
    get_req_path,
    get_req_method,
    set_request,
    get_span_id,
    get_parent_span_id,
    set_span,
    get_indent,
    set_indent,
    inc_indent,
    is_user_path,
)

# Alias for convenience
logctx = None  # Module-level marker, actual functions are exported above


def get_logger(name: str | None = None) -> logging.Logger:
    """Return a standard library logger.

    Most modules in this repository prefer :func:`get_biz_logger_adapter` to
    enrich logs with business fields (kind/step/phase/trace_id...). However,
    some integrations still rely on a classic ``logging.getLogger`` call.

    Keeping this helper preserves backward compatibility and avoids startup
    failures when legacy modules import ``get_logger`` from ``core.logging``.
    """

    return logging.getLogger(name)

# Best-effort logging helper
from .best_effort import best_effort_log

__all__ = [
    # bizlog
    "BizLogger",
    "get_biz_logger",
    "is_detail_enabled",
    "_throttle_map",
    "_should_log_item",
    "_top",
    "_stack_var",
    # bizlogger_adapter
    "BizLoggerAdapter",
    "get_biz_logger_adapter",
    "get_logger",
    # logging_setup
    "init_logging",
    "log_ok",
    "log_run",
    "log_fetch",
    "BizTextFormatter",
    "JsonLineFormatter",
    "get_kind_colors",
    "AutoKVFilter",
    "ContextKindFilter",
    "ContextTraceFilter",
    "ContextFlowFilter",
    "ContextSpanFilter",
    "ContextIndentFilter",
    "_ANSI",
    "_KIND_COLORS",
    "_style",
    # logctx
    "get_kind",
    "set_kind",
    "get_trace_id",
    "set_trace_id",
    "get_step",
    "set_step",
    "get_phase",
    "set_phase",
    "get_req_path",
    "get_req_method",
    "set_request",
    "get_span_id",
    "get_parent_span_id",
    "set_span",
    "get_indent",
    "set_indent",
    "inc_indent",
    "is_user_path",
    "best_effort_log",
]