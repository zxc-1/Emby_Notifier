"""Admin-style logging helpers.

Historically, admin routes used `admin.routes_base.logger/log_fetch/log_run/log_ok`.
Some service-layer modules reused those helpers, which created an undesirable
`services -> admin` dependency.

This module provides compatible helpers from the core layer so services can log
consistently while keeping dependency direction clean.

Compatibility:
- Accepts both legacy call style: `log_run(logger, "...")`
- And new style: `log_run("...")`
"""

from __future__ import annotations

from typing import Any, Optional, Tuple

from core.logging import (
    get_biz_logger_adapter,
    get_trace_id,
    log_fetch as _log_fetch,
    log_ok as _log_ok,
    log_run as _log_run,
)

# Keep the same logger name used by admin routes for continuity.
logger = get_biz_logger_adapter("emby_notifier.admin")


def _normalize_args(args: Tuple[Any, ...]) -> Tuple[str, dict]:
    """Normalize (message, extra) from legacy/new call styles."""
    if not args:
        return "", {}
    # Legacy: (logger, message, **extra)
    if len(args) >= 2 and hasattr(args[0], "detail") and isinstance(args[1], str):
        return str(args[1]), {}
    # New: (message,)
    return str(args[0]), {}


def log_fetch(*args: Any, **extra: Any) -> None:
    message, _ = _normalize_args(args)
    extra.setdefault("trace_id", get_trace_id())
    _log_fetch(logger, message, **extra)


def log_run(*args: Any, **extra: Any) -> None:
    message, _ = _normalize_args(args)
    extra.setdefault("trace_id", get_trace_id())
    _log_run(logger, message, **extra)


def log_ok(*args: Any, **extra: Any) -> None:
    message, _ = _normalize_args(args)
    extra.setdefault("trace_id", get_trace_id())
    _log_ok(logger, message, **extra)
