"""Backward compatibility layer for core.safe_call.

This module re-exports all symbols from core.exceptions.safe_call for backward compatibility.
New code should import directly from core.exceptions.

Migration Guide:
    Old: from core.exceptions import safe_call
    New: from core.exceptions import safe_call
"""

import warnings

warnings.warn(
    "Importing from 'core.safe_call' is deprecated. "
    "Use 'from core.exceptions import safe_call' instead.",
    DeprecationWarning,
    stacklevel=2,
)

from core.exceptions.safe_call import (
    safe_call,
    _generate_error_id,
    _get_function_info,
    _handle_exception,
)

__all__ = [
    "safe_call",
]
