from __future__ import annotations

"""Shared regex patterns used across multiple layers.

Why this lives in :mod:`core` (instead of :mod:`tg_bot`):

- Integrations (e.g. cloud115 URL extraction) must NOT depend on interface layers.
- These patterns are simple, stable utilities with no runtime side effects.

Keep this file dependency-light.
"""

import re

# magnet links
MAGNET_RE = re.compile(r"(magnet:\?xt=urn:btih:[0-9a-fA-F]{32,}[^\s]*)")

# ed2k links
# NOTE: ed2k file-name part can contain spaces; match the canonical '|/' terminator.
ED2K_RE = re.compile(r"(ed2k://\|file\|[^\n]*?\|\d+\|[0-9A-Fa-f]{16,64}\|/)", re.I)

# generic URL
URL_RE = re.compile(r"((?:https?|ftp)://[^\s]+)", re.I)

# 115 share URLs (include anxia.com as some links are served there)
SHARE_RE = re.compile(r"(https?://(?:[A-Za-z0-9-]+\.)*(?:115\.com|115cdn\.com|anxia\.com)/[^\s]+)", re.I)
