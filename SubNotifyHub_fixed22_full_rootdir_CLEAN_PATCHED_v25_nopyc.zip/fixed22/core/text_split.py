from __future__ import annotations

from typing import List, Sequence


# Safe breakpoints for URLs / query-like strings.
# Keep "&"/"=" early so long query strings split at param boundaries.
_URL_BREAKS: Sequence[str] = ("&", "=", "?", "/", "#", "-", "_", ":", ".", ",", ";")

# Safe breakpoints for normal text.
_TEXT_BREAKS: Sequence[str] = (" ", "，", "。", "、", "；", ";", "：", ":", "！", "!", "？", "?", ")", "）", "]", "】")


def _is_urlish(s: str) -> bool:
    """Heuristic: does the *whole* line look like a URL / resource link?"""
    if not s:
        return False
    low = s.lower()
    return (
        "http://" in low
        or "https://" in low
        or "www." in low
        or "magnet:?" in low
        or "ed2k://" in low
        or "ftp://" in low
        or "%2" in low
        or "%3" in low
    )


def _looks_like_query_fragment(window: str) -> bool:
    """Heuristic: even without scheme, does this window look like a query-string fragment?"""
    if not window:
        return False
    # Dense "&"/"=" strongly indicates a URL/query continuation.
    if window.count("&") >= 2:
        return True
    if window.count("=") >= 2:
        return True
    # magnet params often have "xt=urn:" / "dn=" / "tr="
    low = window.lower()
    if "xt=urn:" in low or "dn=" in low or "tr=" in low:
        return True
    return False


def _split_huge_line(line: str, cap: int) -> List[str]:
    """Split a single very long line into chunks <= cap.

    Prefer splitting at safe breakpoints. Hard-cut only as last resort.

    IMPORTANT:
      For long URLs, we must keep treating subsequent windows as URL-ish even after the
      scheme prefix has been cut off; otherwise we regress to text breaks and can split
      "k22=22" into "...&k22" + "=22&k23..." which is unreadable.
    """
    if not line:
        return []

    out: List[str] = []
    s = line

    # Decide url-ish once for the entire line (state inheritance).
    line_urlish = _is_urlish(s)

    while len(s) > cap:
        window = s[: cap + 1]
        is_urlish = bool(line_urlish or _looks_like_query_fragment(window))
        breaks = _URL_BREAKS if is_urlish else _TEXT_BREAKS

        cut = -1
        for b in breaks:
            pos = window.rfind(b)
            if pos > 0:
                # For spaces, cut before the space; otherwise keep the delimiter at the end
                # of the chunk to avoid dropping URL punctuation.
                cut = pos + (0 if b == " " else 1)
                break

        if cut <= 0 or cut > cap:
            cut = cap

        out.append(s[:cut].rstrip("\n"))
        s = s[cut:]

    if s:
        out.append(s.rstrip("\n"))

    return [c for c in out if c]


def split_text(text: str, *, limit: int, hard_limit: int | None = None) -> List[str]:
    """Split text into chunks <= limit, preferring newline boundaries.

    - Never break inside a line unless the line itself exceeds the cap.
    - For an overlong line, use safe breakpoints; hard-cut only as last resort.
    """
    if text is None:
        return []
    s = str(text)
    cap = int(hard_limit or limit or 0)
    if cap <= 0:
        return [s] if s else []

    lines = s.splitlines()
    out: List[str] = []
    buf = ""

    def flush() -> None:
        nonlocal buf
        if buf:
            out.append(buf)
            buf = ""

    for ln in lines:
        ln = str(ln)
        if ln == "":
            if buf and len(buf) + 1 <= cap:
                buf += "\n"
            else:
                flush()
            continue

        if len(ln) <= cap:
            if not buf:
                buf = ln
            else:
                cand = buf + "\n" + ln
                if len(cand) <= cap:
                    buf = cand
                else:
                    flush()
                    buf = ln
            continue

        flush()
        out.extend(_split_huge_line(ln, cap))

    flush()
    return [c for c in out if c]
