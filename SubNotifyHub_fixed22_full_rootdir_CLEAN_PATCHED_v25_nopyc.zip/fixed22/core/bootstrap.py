"""App bootstrap.

This module remains as a stable import path (``core.bootstrap:create_app``), while
the actual implementation is split into smaller modules for maintainability.
"""

from __future__ import annotations

from bootstrap.bootstrap_app_factory import create_app  # noqa: F401

__all__ = ["create_app"]
