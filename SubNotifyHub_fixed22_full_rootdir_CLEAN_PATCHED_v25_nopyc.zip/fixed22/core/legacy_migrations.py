from __future__ import annotations

"""Small, best-effort migrations for backward compatibility.

Why this exists
--------------
v1.5.x used two dotenv files:
  - /data/.env (ENV_PATH)
  - /data/.env.local (ENV_LOCAL_PATH)

v1.6.x simplified to a single supported file (.env). Some deployments still
have their persisted configuration in the legacy .env.local, so after upgrade
the UI appears "reset".

We keep the single-file scheme, but we *migrate* legacy values into .env on
startup (one-way, best-effort):
  - If .env is missing/empty and .env.local exists -> copy all keys.
  - If both exist -> copy keys that are missing in .env.

We do NOT delete .env.local automatically.
"""

import logging
from core.logging import get_biz_logger
from pathlib import Path

from core.env_utils import env_str
from typing import Dict

from core.storage import dump_env_file, load_env_file
from core.runtime_env import get_env_path

biz = get_biz_logger(__name__)


def migrate_env_local_to_env() -> None:
    """Best-effort migration from legacy ENV_LOCAL_PATH/.env.local -> ENV_PATH/.env."""

    env_path = Path(get_env_path())

    # v1.5.x supported ENV_LOCAL_PATH (default: /data/.env.local)
    legacy_path = Path(env_str("ENV_LOCAL_PATH", str(env_path.parent / ".env.local")))

    try:
        if not legacy_path.exists():
            return

        legacy = load_env_file(legacy_path) or {}
        if not legacy:
            return

        cur: Dict[str, str] = {}
        if env_path.exists():
            cur = load_env_file(env_path) or {}

        # Determine if .env is effectively empty
        env_effectively_empty = (not env_path.exists()) or (not cur)

        merged = dict(cur)
        copied = 0
        for k, v in legacy.items():
            kk = str(k or "").strip()
            if not kk:
                continue
            # If .env is empty, copy everything; otherwise only fill missing keys
            if env_effectively_empty or kk not in merged:
                merged[kk] = str(v)
                copied += 1

        if copied <= 0:
            return

        dump_env_file(env_path, merged)
        biz.ok(
            f"配置迁移完成：从 {legacy_path} 迁移 {copied} 个配置项到 {env_path}",
            copied=copied,
            legacy_path=str(legacy_path),
            env_path=str(env_path),
        )
    except Exception:
        # Never block startup on migration
        biz.detail("配置迁移失败（已忽略）", exc_info=True)
