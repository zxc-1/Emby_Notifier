"""DEPRECATED: Use core.cache.persist_cache instead.

This module is maintained for backward compatibility only.
Please update your imports to use the new path:

    # Old (deprecated):
    from core.cache import kv_cache_get_json, kv_cache_set_json

    # New (recommended):
    from core.cache import kv_cache_get_json, kv_cache_set_json
"""

from __future__ import annotations

import warnings

warnings.warn(
    "Importing from 'core.persist_cache' is deprecated. "
    "Use 'from core.cache import kv_cache_get_json, kv_cache_set_json' instead.",
    DeprecationWarning,
    stacklevel=2,
)

# Re-export everything from the new location for backward compatibility
from core.cache.persist_cache import (
    kv_cache_get_json,
    kv_cache_set_json,
    kv_cache_delete,
    kv_cache_purge_expired,
    close_cache_db,
    # Internal symbols for backward compatibility
    _db_path,
    _conn,
    _get_pool,
    _ensure_tables,
    _log_throttled,
    _maintenance_throttled,
    _secure_sqlite_files,
    _KV_PURGE_LOCK,
    _KV_LOG_LOCK,
    _KV_LOG_LAST,
    logger,
)

__all__ = [
    "kv_cache_get_json",
    "kv_cache_set_json",
    "kv_cache_delete",
    "kv_cache_purge_expired",
    "close_cache_db",
    # Internal symbols (for backward compatibility only)
    "_db_path",
    "_conn",
    "_get_pool",
    "_ensure_tables",
    "_log_throttled",
    "_maintenance_throttled",
    "_secure_sqlite_files",
    "_KV_PURGE_LOCK",
    "_KV_LOG_LOCK",
    "_KV_LOG_LAST",
    "logger",
]
