from __future__ import annotations

import logging
from core.logging import get_biz_logger_adapter
logger = get_biz_logger_adapter(__name__)

from pathlib import Path


def dir_writable(p: Path) -> bool:
    """Return True if directory exists (created if needed) and is writable."""
    try:
        p.mkdir(parents=True, exist_ok=True)
        test = p / ".__writetest__"
        test.write_text("ok", encoding="utf-8")
        test.unlink(missing_ok=True)
        return True
    except (OSError, PermissionError) as e:
        logger.detail(f"目录写入权限检查失败 - 路径={p}, 原因={type(e).__name__}")
        return False


def path_writable(path: Path, *, is_dir: bool = False) -> bool:
    """Return True if path (file or directory) can be written.

    For files, checks the parent directory.
    """
    target = path if is_dir else path.parent
    return dir_writable(target)
