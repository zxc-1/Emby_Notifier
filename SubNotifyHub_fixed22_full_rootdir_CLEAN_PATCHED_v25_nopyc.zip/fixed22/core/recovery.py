"""Backward compatibility layer for core.recovery.

This module re-exports all symbols from core.exceptions.recovery for backward compatibility.
New code should import directly from core.exceptions.

Migration Guide:
    Old: from core.exceptions import CircuitBreaker, RetryStrategy, with_retry
    New: from core.exceptions import CircuitBreaker, RetryStrategy, with_retry
"""

import warnings

warnings.warn(
    "Importing from 'core.recovery' is deprecated. "
    "Use 'from core.exceptions import CircuitBreaker, RetryStrategy, with_retry' instead.",
    DeprecationWarning,
    stacklevel=2,
)

from core.exceptions.recovery import (
    CircuitState,
    RetryStrategy,
    CircuitBreaker,
    CircuitBreakerOpenError,
    with_retry,
)

__all__ = [
    "CircuitState",
    "RetryStrategy",
    "CircuitBreaker",
    "CircuitBreakerOpenError",
    "with_retry",
]
