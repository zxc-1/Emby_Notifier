"""DEPRECATED: Use core.cache.poster_cache_keys instead.

This module is maintained for backward compatibility only.
Please update your imports to use the new path:

    # Old (deprecated):
    from core.cache import safe_url_for_log, sha1_text

    # New (recommended):
    from core.cache import safe_url_for_log, sha1_text
"""

from __future__ import annotations

import warnings

warnings.warn(
    "Importing from 'core.poster_cache_keys' is deprecated. "
    "Use 'from core.cache import safe_url_for_log, sha1_text' instead.",
    DeprecationWarning,
    stacklevel=2,
)

# Re-export everything from the new location for backward compatibility
from core.cache.poster_cache_keys import (
    safe_url_for_log,
    sha1_text,
    normalize_url_for_key,
    guess_image_ext,
    logger,
)

__all__ = [
    "safe_url_for_log",
    "sha1_text",
    "normalize_url_for_key",
    "guess_image_ext",
    "logger",
]
