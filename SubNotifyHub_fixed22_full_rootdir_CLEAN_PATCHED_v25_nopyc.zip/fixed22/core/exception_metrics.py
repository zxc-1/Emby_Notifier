"""Backward compatibility layer for core.exception_metrics.

This module re-exports all symbols from core.exceptions.metrics for backward compatibility.
New code should import directly from core.exceptions.

Migration Guide:
    Old: from core.exceptions import exception_metrics, record_exception
    New: from core.exceptions import exception_metrics, record_exception
"""

import warnings

warnings.warn(
    "Importing from 'core.exception_metrics' is deprecated. "
    "Use 'from core.exceptions import exception_metrics, record_exception' instead.",
    DeprecationWarning,
    stacklevel=2,
)

from core.exceptions.metrics import (
    ExceptionMetrics,
    exception_metrics,
    record_exception,
    get_exception_counts,
    get_exception_summary,
    EXCEPTION_THRESHOLD,
    DEFAULT_EXCEPTION_THRESHOLD,
)

__all__ = [
    "ExceptionMetrics",
    "exception_metrics",
    "record_exception",
    "get_exception_counts",
    "get_exception_summary",
    "EXCEPTION_THRESHOLD",
    "DEFAULT_EXCEPTION_THRESHOLD",
]
