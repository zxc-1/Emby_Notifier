from __future__ import annotations

"""Dedup key builders (core).

This module centralizes "enqueue dedup" signature calculation so webhook,
worker, and direct notification flows share exactly the same semantics.

Why under :mod:`core`?
- The logic depends on :mod:`core.media_identity` (path normalization + media sig).
- Both :mod:`application` and :mod:`notifier` are allowed to depend on :mod:`core`.
- Keeping it out of :mod:`notifier` avoids application->notifier reverse deps.
"""

import zlib
from typing import Any, Tuple

from core.media_identity import build_media_sig, normalize_event

try:
    # Canonical model lives in domain.
    from domain.models import NotificationContent
except Exception:  # pragma: no cover
    class _NotificationContentSentinel:  # noqa: D401
        """Sentinel type used when NotificationContent import is unavailable."""

    NotificationContent = _NotificationContentSentinel  # type: ignore


def _is_library_like_event(ev: str) -> bool:
    """Whether *ev* represents an Emby 'library import/add/update' style event.

    Emby can emit multiple events for the same media during import (e.g.
    Library.New / ItemAdded / ItemUpdated). If we include the raw event in the
    dedup key, the same media may be enqueued twice and produce duplicate TG
    notifications. For these library-ish events we dedup by media signature only.
    """
    s = str(ev or "").strip().lower()
    if not s:
        return False
    # normalize_event() only strips spaces; keep this tolerant.
    if s in {"itemadded", "itemupdated", "librarynew", "libraryupdated"}:
        return True
    if s.startswith("library") or "library." in s or "library_" in s:
        return True
    return False




def compute_enqueue_dedup(
    payload: Any,
    *,
    episode_strategy: str = "default",
) -> Tuple[str, str, str]:
    """Compute (dedup_key, event, media_sig) for an enqueue payload.

    Args:
        payload: webhook dict or :class:`domain.models.NotificationContent`.
        episode_strategy: passed to :func:`core.media_identity.build_media_sig`.

    Returns:
        (key, event, media_sig)
    """

    key = ""
    media_sig = ""
    event = ""

    if isinstance(payload, dict):
        event = normalize_event(payload.get("Event") or payload.get("event") or "")
        library_id = str(payload.get("LibraryId") or payload.get("libraryId") or "").strip()

        item = payload.get("Item") or payload.get("item") or {}
        if isinstance(item, dict):
            item_id = str(item.get("Id") or item.get("id") or "").strip()
            item_name = str(item.get("Name") or item.get("name") or "").strip()
            item_path = str(item.get("Path") or item.get("path") or "").strip()
            media_sig = build_media_sig(
                item_id=item_id,
                item_path=item_path,
                item_name=item_name,
                library_id=library_id,
                item_type=item.get("Type") or item.get("type") or "",
                series_id=item.get("SeriesId") or item.get("seriesId") or "",
                series_name=item.get("SeriesName") or item.get("seriesName") or "",
                season_number=item.get("ParentIndexNumber") or item.get("parentIndexNumber"),
                episode_number=item.get("IndexNumber") or item.get("indexNumber"),
                episode_strategy=episode_strategy,
            )
            if media_sig:
                key = (f"lib:{media_sig}" if _is_library_like_event(event) else (f"ev:{event}|{media_sig}" if event else media_sig))
        return key, event, media_sig

    # NotificationContent payloads
    if isinstance(payload, NotificationContent):
        event = normalize_event(getattr(payload, "event", "") or "")
        media_key = str(getattr(payload, "media_key", "") or "").strip()
        if media_key:
            key = (f"lib:{media_key}" if _is_library_like_event(event) else (f"ev:{event}|{media_key}" if event else media_key))
            media_sig = media_key
            return key, event, media_sig

        # System/subscription notifications: hash stable content lines.
        txt = str(getattr(payload, "text", "") or "").strip()
        sig_lines: list[str] = []
        for ln in (txt.splitlines() if txt else []):
            s2 = " ".join(str(ln or "").split()).strip()
            if not s2:
                continue
            if s2.startswith("🕒"):
                continue
            sig_lines.append(s2)
            if len(sig_lines) >= 5:
                break
        sig = "|".join(sig_lines).lower()
        if sig:
            h = zlib.crc32(sig.encode("utf-8")) & 0xFFFFFFFF
            key = f"sys:{h:08x}"
        return key, event, media_sig

    return "", "", ""
