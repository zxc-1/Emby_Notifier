from __future__ import annotations

"""Telegram error helpers.

Kept in :mod:`core` so both integrations and application layers can reuse it
without introducing reverse dependencies.
"""
import logging
from core.logging import get_biz_logger_adapter
logger = get_biz_logger_adapter(__name__)


from typing import Any, Mapping


def tg_extract_error(data: Mapping[str, Any] | None, *, fallback: str = "") -> str:
    """Extract human-readable description from Telegram API JSON."""
    if not data:
        return str(fallback or "")
    try:
        desc = str(data.get("description") or "")
        if desc:
            return desc
    except (AttributeError, TypeError, KeyError) as e:
        logger.detail(f"Telegram错误信息提取失败 - 数据类型={type(data).__name__}, 原因={type(e).__name__}")
    return str(fallback or "")


def tg_extract_retry_after(data: Mapping[str, Any] | None) -> float | None:
    """Extract Telegram `parameters.retry_after` (seconds) from error JSON.

    Telegram 429 responses often include:
        {"ok": false, "error_code": 429, "description": "...", "parameters": {"retry_after": 3}}
    """
    if not data:
        return None
    try:
        params = data.get("parameters") if isinstance(data, Mapping) else None
        if not params or not isinstance(params, Mapping):
            return None
        ra = params.get("retry_after")
        if ra is None:
            return None
        # Telegram uses seconds (int)
        sec = float(ra)
        if sec < 0:
            sec = 0.0
        return sec
    except (ValueError, TypeError, KeyError, AttributeError) as e:
        logger.detail(f"Telegram重试时间提取失败 - 数据类型={type(data).__name__}, 原因={type(e).__name__}")
        return None

