from __future__ import annotations

from typing import Any


def mask_sensitive(value: Any, show_chars: int = 4) -> str:
    """Mask sensitive values, showing only first and last N characters.

    Examples:
      - long:  "abcd....wxyz" -> "abcd****wxyz"
      - short: length <= 8 -> "****"
      - empty -> ""
    """
    if value is None:
        return ""
    s = str(value)
    if not s:
        return ""
    if len(s) <= 8:
        return "****"
    n = max(1, int(show_chars or 4))
    if len(s) <= n * 2:
        return s[:1] + "****"
    return f"{s[:n]}****{s[-n:]}"
