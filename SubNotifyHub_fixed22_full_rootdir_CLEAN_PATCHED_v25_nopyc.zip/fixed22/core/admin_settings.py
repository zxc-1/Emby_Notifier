"""Shared admin settings schema helpers.

Centralizes the ENV file location and a small set of form-key categories used by
admin settings pages.

Why this module exists:
- Services must not import admin routes (clean dependency direction).
- Routes + services still need to agree on which form keys are booleans/lists.

Keep these keys in sync with the admin HTML form names.
"""

from __future__ import annotations

from typing import Set

from core.storage import env_path


# Where the admin UI persists settings (ENV style).
ENV_PATH = env_path()


# These keys must match the HTML form names.
ADMIN_BOOL_KEYS: Set[str] = {
    "EMBY_WAIT_FOR_IMAGE_ENABLED",
    "WEBHOOK_TRUST_PROXY_HEADERS",
    "NOTIFIER_DRY_RUN",
    # 115 cookie health check
    "CLOUD115_HEALTHCHECK_ENABLED",
    # NOTE: TG Bot 入站 / 115 轮询开关属于 /admin/tg-bot-settings 表单，
    # 不应在 /admin/settings 保存时被“未勾选 => false”误覆盖。
}

FORWARD_BOOL_KEYS: Set[str] = {
    "ENABLE_SEASON_FILTER",
    "FORWARD_BRIDGE_DEBUG",
}

ADMIN_LIST_KEYS: Set[str] = {
    "WEBHOOK_ALLOWED_IPS",
    "ADULT_FORCE_LIBRARIES",
    "ADULT_IGNORE_LIBRARIES",
    "ADULT_FORCE_PATH_PREFIXES",
    "ADULT_IGNORE_PATH_PREFIXES",
    "TG_BOT_ALLOWED_USER_IDS",
}
