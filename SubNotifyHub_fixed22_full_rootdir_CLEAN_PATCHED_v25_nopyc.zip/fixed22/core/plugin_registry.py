"""Backward compatibility layer for core.plugin_registry.

This module re-exports all symbols from core.plugins.registry for backward compatibility.
New code should import directly from core.plugins.

Migration Guide:
    Old: from core.plugins import PluginRegistry, PluginInfo
    New: from core.plugins import PluginRegistry, PluginInfo
"""

import warnings

warnings.warn(
    "Importing from 'core.plugin_registry' is deprecated. "
    "Use 'from core.plugins import PluginRegistry, PluginInfo' instead.",
    DeprecationWarning,
    stacklevel=2,
)

from core.plugins.registry import (
    Hook,
    RouterSpec,
    PluginInfo,
    PluginRegistry,
    _maybe_await,
    _run_hooks,
)

__all__ = [
    "Hook",
    "RouterSpec",
    "PluginInfo",
    "PluginRegistry",
]
