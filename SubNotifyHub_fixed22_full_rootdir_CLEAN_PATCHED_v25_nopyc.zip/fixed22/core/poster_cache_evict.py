"""DEPRECATED: Use core.cache.poster_cache_evict instead.

This module is maintained for backward compatibility only.
Please update your imports to use the new path:

    # Old (deprecated):
    from core.cache import evict_cache

    # New (recommended):
    from core.cache import evict_cache
"""

from __future__ import annotations

import warnings

warnings.warn(
    "Importing from 'core.poster_cache_evict' is deprecated. "
    "Use 'from core.cache import evict_cache' instead.",
    DeprecationWarning,
    stacklevel=2,
)

# Re-export everything from the new location for backward compatibility
from core.cache.poster_cache_evict import (
    evict_cache,
    logger,
)

__all__ = [
    "evict_cache",
    "logger",
]
