"""UI inline-hint detection.

The admin UI sometimes places instructional text directly inside input values
(e.g. "当前已设置…" / "留空表示不修改"). These strings must never be persisted
into .env or validated as real config values.

This helper is shared between admin routes and service-layer usecases.
"""

from __future__ import annotations


def is_ui_inline_hint_text(val: str) -> bool:
    """Detect inline-hint / masked text injected by the UI."""
    v = (val or "").strip()
    if not v:
        return False

    if (
        v.startswith("当前已设置")
        or v.startswith("例如：")
        or v.startswith("例如:")
        or v.startswith("示例：")
        or v.startswith("示例:")
        or v.startswith("形如：")
        or v.startswith("形如:")
    ):
        return True

    exact_hints = {
        "留空表示不修改",
        "可选，用于简单签名校验",
        "TMDB v3 API Key",
        "未设置（请点击下方“登录”）",
        "未设置(请点击下方“登录”)",
    }
    if v in exact_hints:
        return True

    if "不回显" in v and ("当前" in v or "已设置" in v):
        return True
    if v.startswith("未设置") and "请点击" in v:
        return True
    return False
