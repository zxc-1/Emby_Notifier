"""HTTP submodule - unified HTTP client infrastructure.

This module provides a unified interface for HTTP operations, including:
- HTTP client management: get_http_client, create_http_client, close_http_client
- Retry utilities: async_request_with_retry, async_request_with_retry_json
- Exception handling: is_retryable_http_exception, HttpRetryStrategy, with_http_retry

Usage:
    from core.http import get_http_client, async_request_with_retry
    from core.http import is_retryable_http_exception, HttpRetryStrategy
    from core.http import http_safe_context, async_http_safe_context
"""

from __future__ import annotations

# Re-export from clients
from .clients import (
    get_http_client,
    create_http_client,
    close_http_client,
)

# Re-export from retry
from .retry import (
    async_request_with_retry,
    async_request_with_retry_json,
    async_request_with_retry_text,
    async_request_with_retry_bytes,
)

# Re-export from exception_handler
from .exception_handler import (
    # Exception type checking
    is_retryable_http_exception,
    is_client_error,
    is_server_error,
    is_timeout_error,
    is_connection_error,
    # Exception type tuples
    RETRYABLE_HTTP_EXCEPTIONS,
    NON_RETRYABLE_HTTP_EXCEPTIONS,
    # Retry strategy
    HttpRetryStrategy,
    with_http_retry,
    # Context managers
    http_safe_context,
    async_http_safe_context,
)

__all__ = [
    # clients
    "get_http_client",
    "create_http_client",
    "close_http_client",
    # retry
    "async_request_with_retry",
    "async_request_with_retry_json",
    "async_request_with_retry_text",
    "async_request_with_retry_bytes",
    # exception_handler - type checking
    "is_retryable_http_exception",
    "is_client_error",
    "is_server_error",
    "is_timeout_error",
    "is_connection_error",
    # exception_handler - exception tuples
    "RETRYABLE_HTTP_EXCEPTIONS",
    "NON_RETRYABLE_HTTP_EXCEPTIONS",
    # exception_handler - retry strategy
    "HttpRetryStrategy",
    "with_http_retry",
    # exception_handler - context managers
    "http_safe_context",
    "async_http_safe_context",
]
