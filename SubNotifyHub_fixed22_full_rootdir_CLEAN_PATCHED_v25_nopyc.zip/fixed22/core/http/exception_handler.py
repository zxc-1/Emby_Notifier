from __future__ import annotations

"""HTTP 异常处理模块。

提供专门的 HTTP 异常处理逻辑，包括：
- 超时/连接错误重试（指数退避）
- 4xx 错误不重试
- 5xx 错误重试
- 确保连接正确关闭

Requirements: 8.1, 8.2, 8.3, 8.4, 8.5
"""


import asyncio
import inspect
import time
from contextlib import contextmanager, asynccontextmanager
from functools import wraps
from typing import (
    Any,
    Callable,
    Generator,
    Optional,
    Tuple,
    Type,
    TypeVar,
    Union,
)

import httpx

from core.logging import get_biz_logger
from core.exceptions.base import NetworkError, ExternalServiceError
from core.exceptions.recovery import RetryStrategy

T = TypeVar("T")
F = TypeVar("F", bound=Callable[..., Any])

_logger = get_biz_logger(__name__)


# 可重试的 HTTP 异常类型（网络/连接错误）
RETRYABLE_HTTP_EXCEPTIONS: Tuple[Type[Exception], ...] = (
    httpx.TimeoutException,    # 所有超时异常
    httpx.ConnectError,        # 连接错误
    httpx.ReadTimeout,         # 读取超时
    httpx.WriteTimeout,        # 写入超时
    httpx.ConnectTimeout,      # 连接超时
    httpx.PoolTimeout,         # 连接池超时
    httpx.NetworkError,        # 网络错误
    ConnectionError,           # 通用连接错误
    TimeoutError,              # 通用超时错误
)

# 不可重试的 HTTP 异常类型（客户端错误）
NON_RETRYABLE_HTTP_EXCEPTIONS: Tuple[Type[Exception], ...] = (
    httpx.InvalidURL,          # 无效 URL
    httpx.UnsupportedProtocol, # 不支持的协议
)


def is_retryable_http_exception(exc: Exception) -> bool:
    """判断 HTTP 异常是否可重试。
    
    超时、连接错误、5xx 服务器错误可重试。
    4xx 客户端错误不可重试。
    
    Args:
        exc: 要判断的异常
        
    Returns:
        True 如果异常可重试，False 否则
        
    Requirements: 8.2, 8.3, 8.4
    """
    # 不可重试的异常类型
    if isinstance(exc, NON_RETRYABLE_HTTP_EXCEPTIONS):
        return False
    
    # HTTP 状态错误需要检查状态码
    if isinstance(exc, httpx.HTTPStatusError):
        status_code = exc.response.status_code
        # 4xx 客户端错误不重试
        if 400 <= status_code < 500:
            return False
        # 5xx 服务器错误重试
        if 500 <= status_code < 600:
            return True
        return False
    
    # 网络/连接/超时错误可重试
    if isinstance(exc, RETRYABLE_HTTP_EXCEPTIONS):
        return True
    
    return False


def is_client_error(exc: Exception) -> bool:
    """判断是否为 HTTP 4xx 客户端错误。
    
    Args:
        exc: 要判断的异常
        
    Returns:
        True 如果是 4xx 错误，False 否则
        
    Requirements: 8.3
    """
    if isinstance(exc, httpx.HTTPStatusError):
        return 400 <= exc.response.status_code < 500
    return False


def is_server_error(exc: Exception) -> bool:
    """判断是否为 HTTP 5xx 服务器错误。
    
    Args:
        exc: 要判断的异常
        
    Returns:
        True 如果是 5xx 错误，False 否则
        
    Requirements: 8.4
    """
    if isinstance(exc, httpx.HTTPStatusError):
        return 500 <= exc.response.status_code < 600
    return False


def is_timeout_error(exc: Exception) -> bool:
    """判断是否为超时错误。
    
    Args:
        exc: 要判断的异常
        
    Returns:
        True 如果是超时错误，False 否则
        
    Requirements: 8.1
    """
    return isinstance(exc, (httpx.TimeoutException, TimeoutError))


def is_connection_error(exc: Exception) -> bool:
    """判断是否为连接错误。
    
    Args:
        exc: 要判断的异常
        
    Returns:
        True 如果是连接错误，False 否则
        
    Requirements: 8.2
    """
    return isinstance(exc, (httpx.ConnectError, httpx.NetworkError, ConnectionError))


class HttpRetryStrategy(RetryStrategy):
    """HTTP 专用重试策略。
    
    继承自 RetryStrategy，针对 HTTP 操作优化：
    - 默认最大重试 3 次
    - 基础退避 1.0 秒
    - 最大退避 30.0 秒
    - 只重试网络错误和 5xx 错误
    
    Requirements: 8.2, 8.4
    """
    
    def __init__(
        self,
        max_retries: int = 3,
        backoff_base: float = 1.0,
        backoff_max: float = 30.0,
    ) -> None:
        super().__init__(
            max_retries=max_retries,
            backoff_base=backoff_base,
            backoff_max=backoff_max,
            retryable_exceptions=RETRYABLE_HTTP_EXCEPTIONS,
        )
    
    def should_retry(self, exc: Exception, attempt: int) -> bool:
        """判断是否应该重试 HTTP 操作。
        
        Args:
            exc: 捕获的异常
            attempt: 当前尝试次数（从 0 开始）
            
        Returns:
            True 如果应该重试，False 否则
        """
        if attempt >= self.max_retries:
            return False
        return is_retryable_http_exception(exc)


def with_http_retry(
    *,
    strategy: Optional[HttpRetryStrategy] = None,
    on_retry: Optional[Callable[[Exception, int], None]] = None,
    on_failure: Optional[Callable[[Exception], None]] = None,
) -> Callable[[F], F]:
    """HTTP 操作重试装饰器。
    
    为 HTTP 操作添加重试逻辑：
    - 超时/连接错误自动重试（指数退避）
    - 4xx 客户端错误不重试
    - 5xx 服务器错误重试
    - 记录详细日志
    
    Args:
        strategy: 重试策略，默认使用 HttpRetryStrategy()
        on_retry: 重试时的回调函数
        on_failure: 最终失败时的回调函数
        
    Returns:
        装饰后的函数
        
    Example:
        @with_http_retry()
        def fetch_api():
            ...
        
        @with_http_retry(strategy=HttpRetryStrategy(max_retries=5))
        async def async_fetch():
            ...
    
    Requirements: 8.1, 8.2, 8.3, 8.4
    """
    if strategy is None:
        strategy = HttpRetryStrategy()
    
    def decorator(func: F) -> F:
        if inspect.iscoroutinefunction(func):
            @wraps(func)
            async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
                last_exception: Optional[Exception] = None
                
                for attempt in range(strategy.max_retries + 1):
                    try:
                        return await func(*args, **kwargs)
                    except Exception as e:
                        last_exception = e
                        
                        # 4xx 客户端错误不重试
                        if is_client_error(e):
                            _logger.fail(
                                f"HTTP 客户端错误 [{func.__name__}]，不重试",
                                function=func.__name__,
                                exc_type=type(e).__name__,
                                status_code=getattr(getattr(e, 'response', None), 'status_code', None),
                                exc=e,
                            )
                            raise ExternalServiceError(str(e), cause=e)
                        
                        # 检查是否应该重试
                        if not strategy.should_retry(e, attempt):
                            break
                        
                        # 计算延迟
                        delay = strategy.get_delay(attempt)
                        
                        # 记录日志
                        log_extra = {
                            "function": func.__name__,
                            "attempt": attempt + 1,
                            "delay": delay,
                            "exc_type": type(e).__name__,
                        }
                        
                        # 添加超时信息
                        if is_timeout_error(e):
                            _logger.warning(
                                f"HTTP 超时重试 [{func.__name__}] 第 {attempt + 1} 次，延迟 {delay:.2f}s",
                                **log_extra,
                            )
                        elif is_connection_error(e):
                            _logger.warning(
                                f"HTTP 连接错误重试 [{func.__name__}] 第 {attempt + 1} 次，延迟 {delay:.2f}s",
                                **log_extra,
                            )
                        elif is_server_error(e):
                            status_code = getattr(getattr(e, 'response', None), 'status_code', None)
                            _logger.warning(
                                f"HTTP 5xx 错误重试 [{func.__name__}] 第 {attempt + 1} 次，状态码 {status_code}，延迟 {delay:.2f}s",
                                status_code=status_code,
                                **log_extra,
                            )
                        else:
                            _logger.warning(
                                f"HTTP 错误重试 [{func.__name__}] 第 {attempt + 1} 次，延迟 {delay:.2f}s",
                                **log_extra,
                            )
                        
                        # 调用重试回调
                        if on_retry is not None:
                            try:
                                on_retry(e, attempt)
                            except (RuntimeError, ValueError, TypeError):
                                pass
                        
                        await asyncio.sleep(delay)
                
                # 所有重试都失败
                if last_exception is not None:
                    if on_failure is not None:
                        try:
                            on_failure(last_exception)
                        except (RuntimeError, ValueError, TypeError):
                            pass
                    
                    _logger.fail(
                        f"HTTP 操作重试耗尽 [{func.__name__}]",
                        function=func.__name__,
                        max_retries=strategy.max_retries,
                        exc=last_exception,
                    )
                    
                    # 根据异常类型返回不同的包装异常
                    if is_timeout_error(last_exception) or is_connection_error(last_exception):
                        raise NetworkError(str(last_exception), cause=last_exception)
                    else:
                        raise ExternalServiceError(str(last_exception), cause=last_exception)
                
                raise ExternalServiceError("Unexpected state in http retry logic")
            
            return async_wrapper  # type: ignore[return-value]
        
        else:
            @wraps(func)
            def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
                last_exception: Optional[Exception] = None
                
                for attempt in range(strategy.max_retries + 1):
                    try:
                        return func(*args, **kwargs)
                    except Exception as e:
                        last_exception = e
                        
                        # 4xx 客户端错误不重试
                        if is_client_error(e):
                            _logger.fail(
                                f"HTTP 客户端错误 [{func.__name__}]，不重试",
                                function=func.__name__,
                                exc_type=type(e).__name__,
                                status_code=getattr(getattr(e, 'response', None), 'status_code', None),
                                exc=e,
                            )
                            raise ExternalServiceError(str(e), cause=e)
                        
                        # 检查是否应该重试
                        if not strategy.should_retry(e, attempt):
                            break
                        
                        # 计算延迟
                        delay = strategy.get_delay(attempt)
                        
                        # 记录日志
                        log_extra = {
                            "function": func.__name__,
                            "attempt": attempt + 1,
                            "delay": delay,
                            "exc_type": type(e).__name__,
                        }
                        
                        # 添加超时信息
                        if is_timeout_error(e):
                            _logger.warning(
                                f"HTTP 超时重试 [{func.__name__}] 第 {attempt + 1} 次，延迟 {delay:.2f}s",
                                **log_extra,
                            )
                        elif is_connection_error(e):
                            _logger.warning(
                                f"HTTP 连接错误重试 [{func.__name__}] 第 {attempt + 1} 次，延迟 {delay:.2f}s",
                                **log_extra,
                            )
                        elif is_server_error(e):
                            status_code = getattr(getattr(e, 'response', None), 'status_code', None)
                            _logger.warning(
                                f"HTTP 5xx 错误重试 [{func.__name__}] 第 {attempt + 1} 次，状态码 {status_code}，延迟 {delay:.2f}s",
                                status_code=status_code,
                                **log_extra,
                            )
                        else:
                            _logger.warning(
                                f"HTTP 错误重试 [{func.__name__}] 第 {attempt + 1} 次，延迟 {delay:.2f}s",
                                **log_extra,
                            )
                        
                        # 调用重试回调
                        if on_retry is not None:
                            try:
                                on_retry(e, attempt)
                            except (RuntimeError, ValueError, TypeError):
                                pass
                        
                        time.sleep(delay)
                
                # 所有重试都失败
                if last_exception is not None:
                    if on_failure is not None:
                        try:
                            on_failure(last_exception)
                        except (RuntimeError, ValueError, TypeError):
                            pass
                    
                    _logger.fail(
                        f"HTTP 操作重试耗尽 [{func.__name__}]",
                        function=func.__name__,
                        max_retries=strategy.max_retries,
                        exc=last_exception,
                    )
                    
                    # 根据异常类型返回不同的包装异常
                    if is_timeout_error(last_exception) or is_connection_error(last_exception):
                        raise NetworkError(str(last_exception), cause=last_exception)
                    else:
                        raise ExternalServiceError(str(last_exception), cause=last_exception)
                
                raise ExternalServiceError("Unexpected state in http retry logic")
            
            return sync_wrapper  # type: ignore[return-value]
    
    return decorator


@contextmanager
def http_safe_context(
    client: Optional[Any] = None,
    *,
    close_on_error: bool = True,
    context_name: str = "http_operation",
    url: Optional[str] = None,
    timeout: Optional[float] = None,
) -> Generator[None, None, None]:
    """HTTP 安全上下文管理器。
    
    确保 HTTP 客户端在异常时正确关闭。
    
    Args:
        client: HTTP 客户端对象（可选）
        close_on_error: 是否在错误时关闭客户端，默认 True
        context_name: 上下文名称，用于日志
        url: 请求 URL，用于日志
        timeout: 超时值，用于日志
        
    Yields:
        None
        
    Example:
        with httpx.Client() as client:
            with http_safe_context(client, context_name="fetch_user", url=url):
                response = client.get(url)
    
    Requirements: 8.1, 8.5
    """
    try:
        yield
    except httpx.TimeoutException as e:
        _logger.fail(
            f"HTTP 超时 [{context_name}]",
            context=context_name,
            url=url,
            timeout=timeout,
            exc_type=type(e).__name__,
            exc=e,
        )
        if close_on_error and client is not None:
            try:
                client.close()
            except (RuntimeError, ValueError, OSError):
                pass
        raise NetworkError(str(e), cause=e)
    except httpx.ConnectError as e:
        _logger.fail(
            f"HTTP 连接错误 [{context_name}]",
            context=context_name,
            url=url,
            exc_type=type(e).__name__,
            exc=e,
        )
        if close_on_error and client is not None:
            try:
                client.close()
            except (RuntimeError, ValueError, OSError):
                pass
        raise NetworkError(str(e), cause=e)
    except httpx.HTTPStatusError as e:
        status_code = e.response.status_code
        if 400 <= status_code < 500:
            _logger.fail(
                f"HTTP 4xx 客户端错误 [{context_name}]",
                context=context_name,
                url=url,
                status_code=status_code,
                exc_type=type(e).__name__,
                exc=e,
            )
        else:
            _logger.fail(
                f"HTTP 5xx 服务器错误 [{context_name}]",
                context=context_name,
                url=url,
                status_code=status_code,
                exc_type=type(e).__name__,
                exc=e,
            )
        if close_on_error and client is not None:
            try:
                client.close()
            except (RuntimeError, ValueError, OSError):
                pass
        raise ExternalServiceError(str(e), cause=e)
    except Exception as e:
        _logger.fail(
            f"HTTP 未知错误 [{context_name}]",
            context=context_name,
            url=url,
            exc_type=type(e).__name__,
            exc=e,
        )
        if close_on_error and client is not None:
            try:
                client.close()
            except (RuntimeError, ValueError, OSError):
                pass
        raise


@asynccontextmanager
async def async_http_safe_context(
    client: Optional[Any] = None,
    *,
    close_on_error: bool = True,
    context_name: str = "http_operation",
    url: Optional[str] = None,
    timeout: Optional[float] = None,
):
    """异步 HTTP 安全上下文管理器。
    
    确保 HTTP 客户端在异常时正确关闭（异步版本）。
    
    Args:
        client: HTTP 客户端对象（可选）
        close_on_error: 是否在错误时关闭客户端，默认 True
        context_name: 上下文名称，用于日志
        url: 请求 URL，用于日志
        timeout: 超时值，用于日志
        
    Yields:
        None
    
    Requirements: 8.1, 8.5
    """
    try:
        yield
    except httpx.TimeoutException as e:
        _logger.fail(
            f"HTTP 超时 [{context_name}]",
            context=context_name,
            url=url,
            timeout=timeout,
            exc_type=type(e).__name__,
            exc=e,
        )
        if close_on_error and client is not None:
            try:
                if hasattr(client, "aclose"):
                    await client.aclose()
                elif hasattr(client, "close"):
                    close_result = client.close()
                    if asyncio.iscoroutine(close_result):
                        await close_result
            except (RuntimeError, ValueError, OSError):
                pass
        raise NetworkError(str(e), cause=e)
    except httpx.ConnectError as e:
        _logger.fail(
            f"HTTP 连接错误 [{context_name}]",
            context=context_name,
            url=url,
            exc_type=type(e).__name__,
            exc=e,
        )
        if close_on_error and client is not None:
            try:
                if hasattr(client, "aclose"):
                    await client.aclose()
                elif hasattr(client, "close"):
                    close_result = client.close()
                    if asyncio.iscoroutine(close_result):
                        await close_result
            except (RuntimeError, ValueError, OSError):
                pass
        raise NetworkError(str(e), cause=e)
    except httpx.HTTPStatusError as e:
        status_code = e.response.status_code
        if 400 <= status_code < 500:
            _logger.fail(
                f"HTTP 4xx 客户端错误 [{context_name}]",
                context=context_name,
                url=url,
                status_code=status_code,
                exc_type=type(e).__name__,
                exc=e,
            )
        else:
            _logger.fail(
                f"HTTP 5xx 服务器错误 [{context_name}]",
                context=context_name,
                url=url,
                status_code=status_code,
                exc_type=type(e).__name__,
                exc=e,
            )
        if close_on_error and client is not None:
            try:
                if hasattr(client, "aclose"):
                    await client.aclose()
                elif hasattr(client, "close"):
                    close_result = client.close()
                    if asyncio.iscoroutine(close_result):
                        await close_result
            except (RuntimeError, ValueError, OSError):
                pass
        raise ExternalServiceError(str(e), cause=e)
    except Exception as e:
        _logger.fail(
            f"HTTP 未知错误 [{context_name}]",
            context=context_name,
            url=url,
            exc_type=type(e).__name__,
            exc=e,
        )
        if close_on_error and client is not None:
            try:
                if hasattr(client, "aclose"):
                    await client.aclose()
                elif hasattr(client, "close"):
                    close_result = client.close()
                    if asyncio.iscoroutine(close_result):
                        await close_result
            except (RuntimeError, ValueError, OSError):
                pass
        raise
