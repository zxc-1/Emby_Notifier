from __future__ import annotations

from core.exceptions.base import ExternalServiceError

import asyncio
import json
import logging
from core.logging import get_biz_logger, get_trace_id
import time
from typing import Any, Dict, Optional, Tuple

import httpx

from .clients import get_http_client
from settings.retries import RetryCategory, get_retry_config

biz = get_biz_logger(__name__)

# Get default retry config at module level for use in function signatures
_DEFAULT_RETRY = get_retry_config(RetryCategory.HTTP_DEFAULT)

_RETRYABLE_STATUS = {429, 500, 502, 503, 504}
_RETRYABLE_EXC = (
    httpx.ConnectTimeout,
    httpx.ReadTimeout,
    httpx.ConnectError,
    httpx.RemoteProtocolError,
    httpx.ReadError,
    httpx.WriteError,
    httpx.PoolTimeout,
)


async def async_request_with_retry_json(
    client: httpx.AsyncClient | None,
    method: str,
    url: str,
    *,
    params: Optional[Dict[str, Any]] = None,
    json: Any = None,
    data: Any = None,
    files: Any = None,
    headers: Optional[Dict[str, str]] = None,
    timeout: Optional[float] = None,
    max_attempts: int = _DEFAULT_RETRY.max_retries,
    backoff: Tuple[float, float] = _DEFAULT_RETRY.backoff,
    retry_statuses: Optional[set[int]] = None,
    log_ctx: str = "",
    text_snip_len: int = 0,
) -> tuple[int, Any, str]:
    """Retry request, parse JSON, and ALWAYS close the response.

    Returns: (status_code, parsed_json_or_None, text_snip)

    This is a "mechanical leak-proof" wrapper. Prefer this over using
    `async_request_with_retry()` directly unless you truly need the raw Response.
    """
    resp: httpx.Response | None = None
    try:
        resp = await async_request_with_retry(
            client,
            method,
            url,
            params=params,
            json=json,
            data=data,
            files=files,
            headers=headers,
            timeout=timeout,
            max_attempts=max_attempts,
            backoff=backoff,
            retry_statuses=retry_statuses,
            log_ctx=log_ctx,
        )

        snip = ""
        if text_snip_len > 0:
            try:
                snip = (resp.text or "")[:text_snip_len]
            except (ValueError, TypeError, AttributeError, UnicodeDecodeError) as e:
                biz.detail(f"响应文本片段读取失败（返回空字符串）：{type(e).__name__}")
                snip = ""

        data_json: Any = None
        try:
            data_json = resp.json()
        except (ValueError, TypeError, json.JSONDecodeError) as e:
            biz.detail(f"JSON 解析失败（返回 None）：{type(e).__name__}")
            data_json = None
        return resp.status_code, data_json, snip
    finally:
        if resp is not None:
            try:
                await resp.aclose()
            except (httpx.HTTPError, RuntimeError) as e:
                biz.detail(f"响应关闭失败（已忽略）：{type(e).__name__}")


async def async_request_with_retry_text(
    client: httpx.AsyncClient | None,
    method: str,
    url: str,
    *,
    params: Optional[Dict[str, Any]] = None,
    json: Any = None,
    data: Any = None,
    files: Any = None,
    headers: Optional[Dict[str, str]] = None,
    timeout: Optional[float] = None,
    max_attempts: int = _DEFAULT_RETRY.max_retries,
    backoff: Tuple[float, float] = _DEFAULT_RETRY.backoff,
    retry_statuses: Optional[set[int]] = None,
    log_ctx: str = "",
    text_snip_len: int = 0,
) -> tuple[int, str, str]:
    """Retry request, read text, and ALWAYS close the response.

    Returns: (status_code, text, text_snip)
    """
    resp: httpx.Response | None = None
    try:
        resp = await async_request_with_retry(
            client,
            method,
            url,
            params=params,
            json=json,
            data=data,
            files=files,
            headers=headers,
            timeout=timeout,
            max_attempts=max_attempts,
            backoff=backoff,
            retry_statuses=retry_statuses,
            log_ctx=log_ctx,
        )
        txt = ""
        try:
            txt = resp.text or ""
        except (ValueError, TypeError, AttributeError, UnicodeDecodeError) as e:
            biz.detail(f"响应文本读取失败（返回空字符串）：{type(e).__name__}")
            txt = ""
        snip = txt[:text_snip_len] if text_snip_len > 0 else ""
        return resp.status_code, txt, snip
    finally:
        if resp is not None:
            try:
                await resp.aclose()
            except (httpx.HTTPError, RuntimeError) as e:
                biz.detail(f"响应关闭失败（已忽略）：{type(e).__name__}")


async def async_request_with_retry_bytes(
    client: httpx.AsyncClient | None,
    method: str,
    url: str,
    *,
    params: Optional[Dict[str, Any]] = None,
    json: Any = None,
    data: Any = None,
    files: Any = None,
    headers: Optional[Dict[str, str]] = None,
    timeout: Optional[float] = None,
    max_attempts: int = _DEFAULT_RETRY.max_retries,
    backoff: Tuple[float, float] = _DEFAULT_RETRY.backoff,
    retry_statuses: Optional[set[int]] = None,
    log_ctx: str = "",
) -> tuple[int, bytes]:
    """Retry request, read bytes, and ALWAYS close the response."""
    resp: httpx.Response | None = None
    try:
        resp = await async_request_with_retry(
            client,
            method,
            url,
            params=params,
            json=json,
            data=data,
            files=files,
            headers=headers,
            timeout=timeout,
            max_attempts=max_attempts,
            backoff=backoff,
            retry_statuses=retry_statuses,
            log_ctx=log_ctx,
        )
        b = b""
        try:
            b = resp.content
        except (ValueError, TypeError, AttributeError) as e:
            biz.detail(f"响应内容读取失败（返回空字节）：{type(e).__name__}")
            b = b""
        return resp.status_code, b
    finally:
        if resp is not None:
            try:
                await resp.aclose()
            except (httpx.HTTPError, RuntimeError) as e:
                biz.detail(f"响应关闭失败（已忽略）：{type(e).__name__}")

def _parse_retry_after(resp: httpx.Response) -> Optional[float]:
    ra = resp.headers.get("Retry-After")
    if not ra:
        return None
    try:
        v = float(ra.strip())
        if v >= 0:
            return v
    except (ValueError, TypeError, AttributeError) as e:
        biz.detail(f"Retry-After 解析失败（返回 None）：value={ra}, 原因={type(e).__name__}")
        return None
    return None


async def async_request_with_retry(
    client: httpx.AsyncClient | None,
    method: str,
    url: str,
    *,
    params: Optional[Dict[str, Any]] = None,
    json: Any = None,
    data: Any = None,
    files: Any = None,
    headers: Optional[Dict[str, str]] = None,
    timeout: Optional[float] = None,
    max_attempts: int = _DEFAULT_RETRY.max_retries,
    backoff: Tuple[float, float] = _DEFAULT_RETRY.backoff,
    retry_statuses: Optional[set[int]] = None,
    log_ctx: str = "",
) -> httpx.Response:
    """
    A small, shared httpx retry helper.

    - Retries transient network errors in `_RETRYABLE_EXC`.
    - Retries status codes in `_RETRYABLE_STATUS` (or `retry_statuses` if provided).
    - Backoff is exponential: sleep = backoff[1] * 2**attempt (+ optional Retry-After).
      `backoff[0]` is the initial delay for attempt=0 (normally 0.0).

    NOTE: This helper returns the final Response even for non-200; callers decide how to handle.
    """
    retry_statuses = retry_statuses or _RETRYABLE_STATUS
    if client is None:
        client = await get_http_client()
    last_exc: Optional[Exception] = None
    trace_id = get_trace_id() or "-"

    for attempt in range(max_attempts):
        try:
            t0 = time.monotonic()
            resp = await client.request(
                method,
                url,
                params=params,
                json=json,
                data=data,
                files=files,
                headers=headers,
                timeout=timeout,
            )
            dt = int((time.monotonic() - t0) * 1000)

            if resp.status_code in retry_statuses and attempt < (max_attempts - 1):
                ra = _parse_retry_after(resp)
                delay = ra if ra is not None else (backoff[0] if attempt == 0 else backoff[1] * (2 ** (attempt - 1)))
                delay = max(0.0, float(delay))
                biz.warning(
                    f"HTTP 请求重试：{method} {log_ctx or url} 返回状态码 {resp.status_code}，耗时 {dt}ms，第 {attempt + 1}/{max_attempts} 次尝试，{delay:.2f} 秒后重试",
                    trace_id=trace_id,
                    method=method,
                    url=log_ctx or url,
                    status=resp.status_code,
                    duration_ms=dt,
                    attempt=attempt + 1,
                    max_attempts=max_attempts,
                    delay=delay,
                )
                try:
                    await resp.aclose()
                except (httpx.HTTPError, RuntimeError) as e:
                    biz.detail(f"响应关闭失败（已忽略）：{type(e).__name__}")
                if delay:
                    await asyncio.sleep(delay)
                continue

            return resp

        except _RETRYABLE_EXC as exc:
            last_exc = exc
            if attempt < (max_attempts - 1):
                delay = backoff[0] if attempt == 0 else backoff[1] * (2 ** (attempt - 1))
                delay = max(0.0, float(delay))
                biz.warning(
                    f"HTTP 请求重试：{method} {log_ctx or url} 遇到临时网络错误 {type(exc).__name__}，第 {attempt + 1}/{max_attempts} 次尝试，{delay:.2f} 秒后重试",
                    trace_id=trace_id,
                    method=method,
                    url=log_ctx or url,
                    error=type(exc).__name__,
                    attempt=attempt + 1,
                    max_attempts=max_attempts,
                    delay=delay,
                )
                if delay:
                    await asyncio.sleep(delay)
                continue
            # IMPORTANT: Do NOT spam full tracebacks for expected transient errors when
            # higher-level callers implement their own retry loops (e.g. Telegram client).
            # Keep logs readable while still surfacing the failure reason.
            biz.warning(
                f"HTTP 请求重试失败：{method} {log_ctx or url} 在 {max_attempts} 次尝试后仍失败，最后错误：{type(exc).__name__}",
                trace_id=trace_id,
                method=method,
                url=log_ctx or url,
                error=type(exc).__name__,
            )
            raise
        except httpx.HTTPError:
            # non-retryable httpx error
            biz.fail(
                f"HTTP 请求失败：{method} {log_ctx or url} 遇到不可重试的 httpx 错误",
                trace_id=trace_id,
                method=method,
                url=log_ctx or url,
            )
            raise

    # Should not reach; defensive.
    if last_exc:
        raise last_exc
    raise ExternalServiceError("http_retry: unexpected fallthrough")
