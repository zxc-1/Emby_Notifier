from __future__ import annotations

import asyncio
import weakref
from typing import Dict, Optional

import httpx

from core.logging import get_biz_logger, get_trace_id
from settings.timeouts import TimeoutCategory, get_timeout

biz = get_biz_logger(__name__)

# NOTE: asyncio/httpx objects are event-loop bound.
# Uvicorn typically runs a single loop per process, but tools/tests may import
# modules outside a running loop and later run under a different loop.
# Keep per-loop clients/locks to avoid "bound to a different event loop" errors.
_clients: "weakref.WeakKeyDictionary[asyncio.AbstractEventLoop, httpx.AsyncClient]" = weakref.WeakKeyDictionary()
_locks: "weakref.WeakKeyDictionary[asyncio.AbstractEventLoop, asyncio.Lock]" = weakref.WeakKeyDictionary()


def _loop() -> asyncio.AbstractEventLoop:
    try:
        return asyncio.get_running_loop()
    except RuntimeError:
        # In our async APIs this shouldn't happen; keep a deterministic fallback
        # for tooling that calls into this module outside a running loop.
        return asyncio.get_event_loop()


def _get_lock() -> asyncio.Lock:
    loop = _loop()
    lk = _locks.get(loop)
    if lk is None:
        lk = asyncio.Lock()
        _locks[loop] = lk
    return lk


async def _inject_trace_id(request: httpx.Request) -> None:
    """Best-effort propagation of trace id to outbound HTTP requests."""
    try:
        if request.headers.get("X-Trace-Id"):
            return
        tid = str(get_trace_id() or "").strip()
        if tid:
            request.headers["X-Trace-Id"] = tid
    except (AttributeError, TypeError, KeyError) as e:
        # AttributeError: request.headers 不存在
        # TypeError: get_trace_id() 返回不可转换为字符串的类型
        # KeyError: headers 操作失败
        biz.detail(
            f"trace_id 注入跳过：{type(e).__name__}",
            exc_type=type(e).__name__,
            url=str(request.url) if hasattr(request, 'url') else "unknown",
        )
        return


def _make_client() -> httpx.AsyncClient:
    # A single shared AsyncClient for the whole process:
    # - keeps connections warm (better latency)
    # - reduces file descriptors / TLS handshakes
    http_timeout = get_timeout(TimeoutCategory.HTTP_DEFAULT)
    timeout = httpx.Timeout(http_timeout, connect=6.0)
    limits = httpx.Limits(max_connections=100, max_keepalive_connections=30, keepalive_expiry=45.0)
    headers = {
        # Some servers behave better with an explicit UA (also helpful for debugging).
        "User-Agent": "emby-notifier/async-httpx",
    }
    return httpx.AsyncClient(timeout=timeout, limits=limits, headers=headers, follow_redirects=True, event_hooks={"request": [_inject_trace_id]})


async def create_http_client() -> httpx.AsyncClient:
    """Create (or return) the shared httpx client for the current event loop."""
    loop = _loop()
    c = _clients.get(loop)
    if c is not None:
        return c

    async with _get_lock():
        c = _clients.get(loop)
        if c is None:
            http_timeout = get_timeout(TimeoutCategory.HTTP_DEFAULT)
            biz.ok(f"HTTP 客户端已创建：默认超时 {http_timeout} 秒，最大连接数 100，保活连接数 30")
            c = _make_client()
            _clients[loop] = c
    return c

async def get_http_client() -> httpx.AsyncClient:
    loop = _loop()
    c = _clients.get(loop)
    if c is None:
        c = await create_http_client()
    return c


async def close_http_client() -> None:
    """Close the client for the current event loop (best-effort)."""
    loop = _loop()
    c = _clients.pop(loop, None)
    if c is None:
        return
    try:
        await c.aclose()
    finally:
        # lock can also be dropped to prevent unbounded growth when tools spawn
        # multiple short-lived loops.
        _locks.pop(loop, None)
