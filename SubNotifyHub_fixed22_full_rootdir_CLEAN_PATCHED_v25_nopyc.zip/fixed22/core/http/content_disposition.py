from __future__ import annotations

import re
from urllib.parse import quote

_CTL_RE = re.compile(r"[\x00-\x1f\x7f]")
_BAD_RE = re.compile(r"[\\/\r\n\t]")


def _sanitize_filename(name: str) -> str:
    # Prevent header injection / path tricks. Keep it simple & predictable.
    name = (name or "").strip() or "download"
    name = _CTL_RE.sub("", name)
    name = _BAD_RE.sub("_", name)
    return name[:180]  # keep within common limits


def attachment_headers(filename: str) -> dict[str, str]:
    """Build safe Content-Disposition headers for attachments.

    Uses both filename= (ASCII fallback) and filename*= (RFC 5987 UTF-8) to
    maximize browser compatibility while preventing header injection.
    """
    fn = _sanitize_filename(filename)
    ascii_fn = fn.encode("ascii", "replace").decode("ascii").replace("?", "_")
    utf8_fn = quote(fn, safe="")
    return {
        "Content-Disposition": f'attachment; filename="{ascii_fn}"; filename*=UTF-8\'\'{utf8_fn}',
    }
