"""Backward compatibility layer for core.safe_context.

This module re-exports all symbols from core.exceptions.safe_context for backward compatibility.
New code should import directly from core.exceptions.

Migration Guide:
    Old: from core.exceptions import safe_context, async_safe_context
    New: from core.exceptions import safe_context, async_safe_context
"""

import warnings

warnings.warn(
    "Importing from 'core.safe_context' is deprecated. "
    "Use 'from core.exceptions import safe_context, async_safe_context' instead.",
    DeprecationWarning,
    stacklevel=2,
)

from core.exceptions.safe_context import (
    ErrorContext,
    SafeContextResult,
    safe_context,
    async_safe_context,
    _generate_error_id,
    _build_error_context,
    _handle_context_exception,
)

__all__ = [
    "ErrorContext",
    "SafeContextResult",
    "safe_context",
    "async_safe_context",
]
