"""DEPRECATED: Use core.cache.poster_cache_fs instead.

This module is maintained for backward compatibility only.
Please update your imports to use the new path:

    # Old (deprecated):
    from core.cache import meta_path, load_meta, save_meta

    # New (recommended):
    from core.cache import meta_path, load_meta, save_meta
"""

from __future__ import annotations

import warnings

warnings.warn(
    "Importing from 'core.poster_cache_fs' is deprecated. "
    "Use 'from core.cache import meta_path, load_meta, save_meta' instead.",
    DeprecationWarning,
    stacklevel=2,
)

# Re-export everything from the new location for backward compatibility
from core.cache.poster_cache_fs import (
    meta_path,
    load_meta,
    save_meta,
    probe_cached_hit_sync,
    logger,
)

__all__ = [
    "meta_path",
    "load_meta",
    "save_meta",
    "probe_cached_hit_sync",
    "logger",
]
