from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Optional


UTC = timezone.utc


def utc_now() -> datetime:
    """Return a timezone-aware UTC datetime."""
    return datetime.now(UTC)


def utc_now_iso_z(*, timespec: str = "seconds") -> str:
    """Return an ISO-8601 string in UTC with a trailing 'Z'.

    We use 'Z' for storage/transport when required by external systems.
    """
    s = utc_now().isoformat(timespec=timespec)
    # s ends with '+00:00' for UTC-aware datetimes
    if s.endswith("+00:00"):
        return s[:-6] + "Z"
    return s


def _coerce_iso_string(s: str) -> str:
    ss = (s or "").strip()
    # Python's fromisoformat() doesn't accept a trailing 'Z'
    if ss.endswith("Z"):
        return ss[:-1] + "+00:00"
    return ss


def parse_iso_datetime(value: Any) -> Optional[datetime]:
    """Parse a datetime from common ISO formats.

    - Accepts datetime objects (returned as-is)
    - Accepts strings with a trailing 'Z'
    - Returns None on parse failure
    """
    if value is None:
        return None
    if isinstance(value, datetime):
        return value
    try:
        s = _coerce_iso_string(str(value))
        if not s:
            return None
        return datetime.fromisoformat(s)
    except (ValueError, TypeError):
        return None


def ensure_utc(dt: datetime, *, assume_utc_if_naive: bool = True) -> datetime:
    """Return a timezone-aware UTC datetime.

    If dt is naive and assume_utc_if_naive is True, we treat it as UTC.
    """
    if dt.tzinfo is None:
        return dt.replace(tzinfo=UTC) if assume_utc_if_naive else dt
    return dt.astimezone(UTC)


def parse_iso_datetime_utc(value: Any, *, assume_utc_if_naive: bool = True) -> Optional[datetime]:
    """See parse_iso_datetime(), then normalize to UTC."""
    dt = parse_iso_datetime(value)
    if dt is None:
        return None
    return ensure_utc(dt, assume_utc_if_naive=assume_utc_if_naive)
