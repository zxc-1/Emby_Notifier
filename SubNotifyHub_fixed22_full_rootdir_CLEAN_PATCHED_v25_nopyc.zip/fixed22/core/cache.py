"""DEPRECATED: Use core.cache.ttl_cache instead.

This module is maintained for backward compatibility only.
Please update your imports to use the new path:

    # Old (deprecated):
    from core.cache import TTLCache, get_or_set

    # New (recommended):
    from core.cache import TTLCache, get_or_set
"""

from __future__ import annotations

import warnings

warnings.warn(
    "Importing from 'core.cache' is deprecated. "
    "Use 'from core.cache import TTLCache, get_or_set' instead.",
    DeprecationWarning,
    stacklevel=2,
)

# Re-export everything from the new location for backward compatibility
from core.cache.ttl_cache import (
    TTLCache,
    get_or_set,
    aget_or_set,
    logger,
    K,
    V,
)

__all__ = [
    "TTLCache",
    "get_or_set",
    "aget_or_set",
    "logger",
    "K",
    "V",
]
