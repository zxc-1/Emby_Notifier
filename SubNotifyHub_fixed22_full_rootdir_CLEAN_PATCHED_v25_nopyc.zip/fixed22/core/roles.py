from __future__ import annotations

"""Process role helpers.

We support split deployment (recommended):
- api   : serve admin + public API routes; **no** background loops.
- worker: run background loops (tg polling / hotlist / health); minimal HTTP surface.
- all   : legacy single-process mode.

This prevents duplicated background tasks under multi-worker ASGI deployments.
"""
import logging
from core.logging import get_biz_logger_adapter
logger = get_biz_logger_adapter(__name__)


from settings.runtime import get_settings


def get_app_role() -> str:
    try:
        s = get_settings()
        role = str(getattr(s, "APP_ROLE", "api") or "api").strip().lower()
    except (AttributeError, TypeError) as e:
        logger.detail(f"应用角色配置解析失败，使用默认值 - 配置项=APP_ROLE, 默认值=api, 原因={type(e).__name__}")
        role = "api"
    if role not in {"api", "worker", "all"}:
        role = "api"
    return role


def is_api_role() -> bool:
    """Whether this process should expose admin/API HTTP routes."""
    r = get_app_role()
    return r in {"api", "all"}


def is_worker_role() -> bool:
    """Whether this process should run background loops (tg polling / hotlist / health)."""
    r = get_app_role()
    return r in {"worker", "all"}
