"""Backward compatibility layer for core.env_store.

This module re-exports all symbols from core.storage.env_store for backward compatibility.
New code should import directly from core.storage.

Migration Guide:
    Old: from core.storage import update_env_file, env_path
    New: from core.storage import update_env_file, env_path
"""

import warnings

warnings.warn(
    "Importing from 'core.env_store' is deprecated. "
    "Use 'from core.storage import ...' instead.",
    DeprecationWarning,
    stacklevel=2,
)

from core.storage.env_store import (
    env_path,
    env_local_path,
    update_env_file,
    update_env_local,
    _file_lock,
)

__all__ = [
    "env_path",
    "env_local_path",
    "update_env_file",
    "update_env_local",
]
