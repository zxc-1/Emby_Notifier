from __future__ import annotations

"""Helpers for *intentional* exception suppression.

This codebase has many best-effort / fail-open paths (metrics collection,
optional integrations, UI convenience helpers). In those places we *want* to
continue running even when a non-critical step fails.

However, plain ``except Exception: ...`` blocks easily become a source of
"logic silently not working": callers get a default value but have no
structured signal that something went wrong.

This module centralizes two things:

1) A suppression helper that **never raises** (even if logging is misconfigured)
2) A consistent log message prefix ("suppressed") so ops can grep reliably.
"""

import hashlib
import logging
from typing import Any, Optional


def suppress(
    *,
    site: str,
    exc: BaseException | None = None,
    logger: Any | None = None,
    fallback: Any = None,
) -> Any:
    """Log and suppress an exception, returning ``fallback``.

    - ``site``: a stable identifier (e.g. "tg_bot/parser_share:parse_year")
    - ``exc``: the exception object (optional)
    - ``logger``: optional logger (stdlib logger or BizLoggerAdapter)

    This helper must *never* throw.
    """
    try:
        lg = logger
        if lg is None:
            # Prefer BizLoggerAdapter for human-readable logs, but always fall back to stdlib logging.
            try:
                from core.logging import get_biz_logger_adapter  # local import: keep this module fail-safe

                lg = get_biz_logger_adapter(__name__)
            except Exception:
                lg = logging.getLogger(__name__)

        # Use exc_info=True when exc is None (we are already in an except block).
        ei: Any = exc if exc is not None else True

        # If we have BizLoggerAdapter, log in human-readable style (never log sensitive payloads here).
        if hasattr(lg, "warn"):
            try:
                lg.warning(
                    "已忽略异常并继续执行",
                    stage="suppressed",
                    event="suppressed_exception",
                    site=site,
                    exc_type=type(exc).__name__ if exc is not None else "",
                    exc=str(exc) if exc is not None else "",
                    exc_info=ei,
                )
                return fallback
            except TypeError:
                # Some adapters may not accept exc_info keyword.
                try:
                    lg.warning(
                        "已忽略异常并继续执行",
                        stage="suppressed",
                        event="suppressed_exception",
                        site=site,
                        exc_type=type(exc).__name__ if exc is not None else "",
                        exc=str(exc) if exc is not None else "",
                    )
                    return fallback
                except Exception:
                    pass

        # Fallback: stdlib logging, keep a stable grep-friendly prefix.
        try:
            lg.exception("suppressed_exception site=%s", site, exc_info=ei)
        except TypeError:
            lg.exception("suppressed_exception site=%s", site)
    except Exception:
        # Last resort: swallow everything; do not print to stdout/stderr here.
        pass
    return fallback


def safe_str(x: Any, *, site: str = "safe_str", default: str = "") -> str:
    try:
        return str(x)
    except Exception as e:
        suppress(site=site, exc=e, fallback=None)
        return default


def safe_int(x: Any, *, site: str = "safe_int", default: Optional[int] = None) -> Optional[int]:
    """Safely convert value to int, returning default on failure.
    
    Handles: None, bool, str, int, float.
    Returns default for invalid values without raising.
    
    Usage:
        safe_int("123")        # 123
        safe_int("abc")        # None
        safe_int(None)         # None
        safe_int("", default=0) # 0
    """
    try:
        if x is None or isinstance(x, bool):
            return default
        if isinstance(x, int):
            return int(x)
        if isinstance(x, float):
            return int(x)
        s = str(x).strip()
        if not s:
            return default
        return int(s)
    except (ValueError, TypeError):
        return default


def safe_float(x: Any, *, site: str = "safe_float", default: Optional[float] = None) -> Optional[float]:
    """Safely convert value to float, returning default on failure."""
    try:
        if x is None or isinstance(x, bool):
            return default
        if isinstance(x, (int, float)):
            return float(x)
        s = str(x).strip()
        if not s:
            return default
        return float(s)
    except (ValueError, TypeError):
        return default


def safe_get(d: Any, key: str, *, default: Any = None) -> Any:
    """Safely get value from dict-like object."""
    try:
        if not isinstance(d, dict):
            return default
        return d.get(key, default)
    except (KeyError, TypeError, AttributeError):
        return default


def safe_call(fn: Any, *args: Any, site: str = "safe_call", default: Any = None, **kwargs: Any) -> Any:
    """Safely call a function, returning default on any exception.
    
    Note: This is different from core.exceptions.safe_call which is a decorator.
    This is a direct call wrapper for one-off safe calls.
    
    Usage:
        result = safe_call(risky_func, arg1, arg2, default=[])
    """
    try:
        return fn(*args, **kwargs)
    except Exception as e:
        suppress(site=site, exc=e, fallback=None)
        return default


def safe_hash8(s: Any, *, default: str = "") -> str:
    """Short stable SHA1 hash (8 chars) for logging, avoiding leaking sensitive data.
    
    Usage:
        safe_hash8("share_code_123")  # "a1b2c3d4"
        safe_hash8(None)              # ""
        safe_hash8("")                # ""
    """
    try:
        v = str(s or "").strip()
        if not v:
            return default
        return hashlib.sha1(v.encode("utf-8", errors="ignore")).hexdigest()[:8]
    except (ValueError, TypeError, AttributeError):
        return default
