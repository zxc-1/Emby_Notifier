"""Backward compatibility layer for core.db_exception_handler.

This module re-exports all symbols from core.exceptions.db_handler for backward compatibility.
New code should import directly from core.exceptions.

Migration Guide:
    Old: from core.exceptions import with_db_retry, db_safe_context
    New: from core.exceptions import with_db_retry, db_safe_context
"""

import warnings

warnings.warn(
    "Importing from 'core.db_exception_handler' is deprecated. "
    "Use 'from core.exceptions import with_db_retry, db_safe_context' instead.",
    DeprecationWarning,
    stacklevel=2,
)

from core.exceptions.db_handler import (
    RETRYABLE_DB_EXCEPTIONS,
    NON_RETRYABLE_DB_EXCEPTIONS,
    is_retryable_db_exception,
    is_integrity_error,
    DatabaseRetryStrategy,
    with_db_retry,
    db_safe_context,
    async_db_safe_context,
)

__all__ = [
    "RETRYABLE_DB_EXCEPTIONS",
    "NON_RETRYABLE_DB_EXCEPTIONS",
    "is_retryable_db_exception",
    "is_integrity_error",
    "DatabaseRetryStrategy",
    "with_db_retry",
    "db_safe_context",
    "async_db_safe_context",
]
