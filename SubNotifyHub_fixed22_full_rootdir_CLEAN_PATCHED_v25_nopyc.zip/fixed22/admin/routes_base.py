from __future__ import annotations

"""Shared presentation-layer helpers for admin routes.

Design goal: keep admin routes thin. Business logic, side effects, and external
integrations must live under services/* and integrations/*.

This module intentionally provides only:
- template wiring
- request/session helpers
- small, pure helper utilities
- thin logging wrappers (adds trace_id)
"""

import logging
from pathlib import Path
from typing import Any, Dict, Set

from fastapi import HTTPException, Request, Depends, APIRouter
from fastapi.templating import Jinja2Templates
from fastapi.responses import JSONResponse, RedirectResponse

from core.logging import (
    get_biz_logger_adapter,
    get_trace_id,
    log_fetch as _log_fetch,
    log_ok as _log_ok,
    log_run as _log_run,
)
from core.runtime_env import get_ui_prefs_path
from ports.settings_provider import get_settings, reload_settings
from core.admin_auth import (
    generate_random_password,
    hash_password,
    is_legacy_hash,
    load_admin_credentials,
    load_admin_record,
    save_admin_credentials,
    verify_password,
)
from core.secret_mask import mask_sensitive
from core.storage import env_path, load_env_file, dump_env_file, load_json, save_json, update_env_file

# Backward-compat wrappers (some modules may still import these names).
from services.runtime.usecases import (  # noqa: F401
    apply_runtime_settings as _apply_runtime_settings,
    apply_tg_polling as _apply_tg_polling,
    stop_task as _stop_task,
)

logger = get_biz_logger_adapter("emby_notifier.admin")

# Keep a 'logging' symbol for callers expecting admin.routes_base.logging
logging = logging

BASE_DIR = Path(__file__).resolve().parents[1]
templates = Jinja2Templates(directory=str(BASE_DIR / "templates"))


def log_fetch(logger, message: str, **extra: Any) -> None:
    extra.setdefault("trace_id", get_trace_id())
    _log_fetch(logger, message, **extra)


def log_run(logger, message: str, **extra: Any) -> None:
    extra.setdefault("trace_id", get_trace_id())
    _log_run(logger, message, **extra)


def log_ok(logger, message: str, **extra: Any) -> None:
    extra.setdefault("trace_id", get_trace_id())
    _log_ok(logger, message, **extra)


def get_app_info(request: Request) -> Dict[str, str]:
    """Return app branding info for templates (name/version)."""
    try:
        s = getattr(request.app.state, "settings", None)
        name = str(getattr(s, "APP_NAME", "SubNotifyHub") or "SubNotifyHub")
        ver = str(getattr(s, "APP_VERSION", "") or "")
    except (AttributeError, TypeError):
        logger.detail("获取应用信息失败，使用默认值", trace_id=get_trace_id())
        name, ver = "SubNotifyHub", ""
    return {"app_name": name, "app_version": ver}


def _is_ui_inline_hint_text(val: str) -> bool:
    """Detect inline-hint / masked text injected by the UI (never persist)."""
    v = (val or "").strip()
    if not v:
        return False

    if (
        v.startswith("当前已设置")
        or v.startswith("例如：")
        or v.startswith("例如:")
        or v.startswith("示例：")
        or v.startswith("示例:")
        or v.startswith("形如：")
        or v.startswith("形如:")
    ):
        return True

    exact_hints = {
        "留空表示不修改",
        "可选，用于简单签名校验",
        "TMDB v3 API Key",
        "未设置（请点击下方“登录”）",
        "未设置(请点击下方“登录”)",
    }
    if v in exact_hints:
        return True

    if "不回显" in v and ("当前" in v or "已设置" in v):
        return True
    if v.startswith("未设置") and "请点击" in v:
        return True
    return False


def _mask_secret(value: Any, keep: int = 12) -> str:
    """Return a stable masked representation for UI display (never raw secret)."""
    if value is None:
        return ""
    s = str(value)
    if not s:
        return ""
    if len(s) <= keep:
        return s[:1] + "*******"
    return s[:keep] + "*******"


UI_PREFS_PATH = get_ui_prefs_path()
ENV_PATH = env_path()
ENV_LOCAL_PATH = ENV_PATH  # deprecated alias (scheme A), kept for backward compat

# These keys must match the HTML form names.
ADMIN_BOOL_KEYS: Set[str] = {
    "EMBY_WAIT_FOR_IMAGE_ENABLED",
    "WEBHOOK_TRUST_PROXY_HEADERS",
    "NOTIFIER_DRY_RUN",
    # 115 cookie health check
    "CLOUD115_HEALTHCHECK_ENABLED",
    # NOTE: TG Bot 入站 / 115 轮询开关属于 /admin/tg-bot-settings 表单，
    # 不应在 /admin/settings 保存时被“未勾选 => false”误覆盖。
}

FORWARD_BOOL_KEYS: Set[str] = {
    "ENABLE_SEASON_FILTER",
    "FORWARD_BRIDGE_DEBUG",
}

ADMIN_TEXT_KEYS: Set[str] = {
    "TG_BOT_TOKEN",
    "TG_CHAT_ID",
    "EMBY_BASE_URL",
    "EMBY_API_KEY",
    "EMBY_WAIT_FOR_IMAGE_MAX_WAIT",
    "TMDB_API_KEY",
    "MEDIAINFO_TIMEOUT",
    "MEDIAINFO_INTERVAL",
    "ADULT_DETAIL_BASE_URL",
    "NOTIFIER_MAX_QUEUE_SIZE",
    "NOTIFIER_WORKER_CONCURRENCY",
    "NOTIFIER_MAX_RETRY",
    "NOTIFIER_RETRY_BACKOFF_BASE",
    "LOG_LEVEL",
    "WEBHOOK_SECRET",
    "WEBHOOK_ALLOWED_IPS",
    "DEDUP_TTL_SECONDS",
    "DEDUP_MAX_SIZE",
    "DEBUG_NOTIFICATION_HISTORY_SIZE",
    "MEDIAHELP_BASE",
    "FORWARD_BRIDGE_SUB_CACHE_TTL",
    "EMBY_WAIT_FOR_IMAGE_INTERVAL",
    "TG_PARSE_MODE",
    "NOTIFIER_AGGREGATE_WINDOW",
    "NOTIFIER_AGGREGATE_MAX_ITEMS",
    "TMDB_CACHE_TTL",
    "TMDB_CACHE_MAX_SIZE",
    "ADULT_FORCE_LIBRARIES",
    "ADULT_IGNORE_LIBRARIES",
    "ADULT_FORCE_PATH_PREFIXES",
    "ADULT_IGNORE_PATH_PREFIXES",
    # TG Bot (inbound) + 115 cloud
    "TG_BOT_WEBHOOK_SECRET",
    "TG_BOT_ALLOWED_USER_IDS",
    "CLOUD115_COOKIE",
    "CLOUD115_QR_APP",
    "CLOUD115_DIR_MODE",
    "CLOUD115_TARGET_WP_PATH_ID",
    "CLOUD115_DUP_MODE",
    "CLOUD115_DUP_WINDOW_MINUTES",
    # 115 health check tuning
    "CLOUD115_HEALTHCHECK_INTERVAL_SEC",
    "CLOUD115_HEALTHCHECK_TIMEOUT_SEC",
    "CLOUD115_HEALTHCHECK_FAIL_THRESHOLD",
    "CLOUD115_HEALTHCHECK_NOTIFY_COOLDOWN_SEC",
}

ADMIN_LIST_KEYS: Set[str] = {
    "WEBHOOK_ALLOWED_IPS",
    "ADULT_FORCE_LIBRARIES",
    "ADULT_IGNORE_LIBRARIES",
    "ADULT_FORCE_PATH_PREFIXES",
    "ADULT_IGNORE_PATH_PREFIXES",
    "TG_BOT_ALLOWED_USER_IDS",
}


def get_admin_user(request: Request) -> str:
    user = request.session.get("admin_logged_in")
    if user:
        return str(user)
    raise HTTPException(status_code=401, detail="UNAUTHORIZED")
