from __future__ import annotations

from typing import Any, Dict

"""Admin routes: Cloud115 QR/login helpers & APIs (thin routes)."""

from . import routes_base as _routes_base

# --- explicit re-exports from .routes_base (replacing star import) ---
Depends = _routes_base.Depends
JSONResponse = _routes_base.JSONResponse
Request = _routes_base.Request
get_admin_user = _routes_base.get_admin_user

router = _routes_base.APIRouter()

from services.cloud115 import usecases as cloud115_uc


@router.get("/admin/tg-bot/115/test", response_class=JSONResponse)
async def admin_test_cloud115(user: str = Depends(get_admin_user)) -> Dict[str, Any]:
    return await cloud115_uc.test_cookie()


@router.post("/admin/tg-bot/115/qrcode/start", response_class=JSONResponse)
async def admin_cloud115_qrcode_start(request: Request, user: str = Depends(get_admin_user)) -> Dict[str, Any]:
    try:
        payload = await request.json()
    except Exception:
        payload = None
    return await cloud115_uc.qrcode_start(payload if isinstance(payload, dict) else None)


@router.get("/admin/tg-bot/115/qrcode/poll", response_class=JSONResponse)
async def admin_cloud115_qrcode_poll(qid: str = "", qtoken: str = "", user: str = Depends(get_admin_user)) -> Dict[str, Any]:
    return await cloud115_uc.qrcode_poll(qid=qid, qtoken=qtoken)


@router.get("/admin/tg-bot/115/downpath", response_class=JSONResponse)
async def admin_cloud115_downpath(user: str = Depends(get_admin_user)) -> Dict[str, Any]:
    return await cloud115_uc.list_downpath()
