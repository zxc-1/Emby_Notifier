from __future__ import annotations

import asyncio

"""Admin routes: authentication (login/password).

Thin presentation layer:
- parse request payload
- manage session cookies/flags
- delegate business rules to services.admin_auth.AdminAuthUsecase
"""

from . import routes_base as _routes_base

from services.admin_auth import get_admin_auth_usecase

router = _routes_base.APIRouter()

HTTPException = _routes_base.HTTPException
Request = _routes_base.Request
Depends = _routes_base.Depends

logger = _routes_base.logger
log_run = _routes_base.log_run
log_ok = _routes_base.log_ok
get_admin_user = _routes_base.get_admin_user


@router.post("/admin/login")
async def admin_login(request: Request):
    log_run(logger, "admin: login attempt")
    try:
        data = await request.json()
    except ValueError:
        data = dict(await request.form())

    username = (data.get("username") or "").strip()
    password = (data.get("password") or "").strip()

    uc = get_admin_auth_usecase()
    try:
        res = await uc.login(username=username, password=password)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except RuntimeError:
        raise HTTPException(status_code=500, detail="admin credentials not initialized")

    if not res.ok:
        raise HTTPException(status_code=401, detail="invalid credentials")

    request.session["admin_logged_in"] = username
    request.session["must_change_password"] = bool(res.must_change_password)
    log_ok(logger, "admin: login ok")
    return {"ok": True, "must_change_password": bool(res.must_change_password)}


@router.post("/admin/reset-password")
async def admin_reset_password(request: Request, user: str = Depends(get_admin_user)):
    log_run(logger, "admin: reset password")
    uc = get_admin_auth_usecase()
    new_password = await uc.reset_password()

    # Keep current session in sync with the persisted record.
    try:
        request.session["must_change_password"] = True
    except Exception:
        logger.detail("admin: 更新会话 must_change_password 失败", exc_info=True)

    log_ok(logger, "admin: reset password ok")
    return {"ok": True, "new_password": new_password}


@router.post("/admin/change-password")
async def admin_change_password(request: Request, user: str = Depends(get_admin_user)):
    """Change admin password.

    - Normal changes require current_password verification.
    - First-login forced change allows omitting current_password (session flag).
    """
    log_run(logger, "admin: change password")
    try:
        data = await request.json()
    except ValueError:
        data = dict(await request.form())

    new_password = (data.get("new_password") or "").strip()
    current_password = (data.get("current_password") or "").strip()

    must_change = bool(request.session.get("must_change_password", False))

    uc = get_admin_auth_usecase()
    try:
        await uc.change_password(
            new_password=new_password,
            current_password=current_password,
            allow_skip_current=must_change,
        )
    except ValueError as e:
        detail = str(e)
        if detail == "NEW_PASSWORD_TOO_SHORT":
            raise HTTPException(status_code=400, detail=detail)
        if detail == "CURRENT_PASSWORD_REQUIRED":
            raise HTTPException(status_code=400, detail=detail)
        raise HTTPException(status_code=400, detail="BAD_REQUEST")
    except PermissionError as e:
        raise HTTPException(status_code=401, detail=str(e))
    except RuntimeError:
        raise HTTPException(status_code=500, detail="admin credentials not initialized")

    request.session["must_change_password"] = False
    log_ok(logger, "admin: change password ok")
    return {"ok": True}


__all__ = ["router"]
