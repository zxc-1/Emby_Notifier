"""Dashboard API routes (thin).

All aggregation/business logic lives in services.dashboard.usecases so routes stay
small, testable, and consistent with large-project conventions.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, Query, Request
from fastapi.responses import JSONResponse

from core.logging.logctx import get_trace_id

from . import routes_base as _routes_base

logger = _routes_base.logger
log_fetch = _routes_base.log_fetch
get_admin_user = _routes_base.get_admin_user

router = APIRouter(prefix="/api/dashboard", tags=["dashboard"])


def _success_response(
    data: Any,
    timestamp: Optional[str] = None,
    *,
    partial: bool = False,
    degraded_components: Optional[list[str]] = None,
) -> Dict[str, Any]:
    degraded_components = list(degraded_components or [])
    return {
        "success": True,
        "data": data,
        "timestamp": timestamp or datetime.now(timezone.utc).isoformat(),
        "trace_id": get_trace_id(),
        "partial": bool(partial or degraded_components),
        "degraded_components": degraded_components,
    }


def _error_response(code: str, message: str) -> Dict[str, Any]:
    return {
        "success": False,
        "error": {"code": code, "message": message},
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "trace_id": get_trace_id(),
    }


@router.get("/stats", response_class=JSONResponse)
async def dashboard_stats(request: Request, user: str = Depends(get_admin_user)) -> Dict[str, Any]:
    log_fetch(logger, "获取仪表盘统计数据")
    from services.dashboard.usecases import get_dashboard_usecase

    uc = get_dashboard_usecase(logger=logger)
    r = await uc.get_stats(app=request.app, trace_id=get_trace_id())
    return _success_response(r["payload"], partial=r.get("partial", False), degraded_components=r.get("degraded_components", []))


@router.get("/services", response_class=JSONResponse)
async def dashboard_services(
    request: Request,
    refresh: int = 0,
    user: str = Depends(get_admin_user),
) -> Dict[str, Any]:
    log_fetch(logger, "获取服务连接状态")
    from services.dashboard.usecases import get_dashboard_usecase

    uc = get_dashboard_usecase(logger=logger)
    r = await uc.get_services(app=request.app, refresh=int(refresh or 0) == 1, trace_id=get_trace_id())
    return _success_response(r["payload"], partial=r.get("partial", False), degraded_components=r.get("degraded_components", []))


@router.get("/hotlist", response_class=JSONResponse)
async def dashboard_hotlist(request: Request, user: str = Depends(get_admin_user)) -> Dict[str, Any]:
    log_fetch(logger, "获取热榜订阅概览")
    from services.dashboard.usecases import get_dashboard_usecase

    uc = get_dashboard_usecase(logger=logger)
    r = await uc.get_hotlist_preview(trace_id=get_trace_id())
    return _success_response(r["payload"], partial=r.get("partial", False), degraded_components=r.get("degraded_components", []))


@router.get("/chart", response_class=JSONResponse)
async def dashboard_chart(
    request: Request,
    time_range: str = Query("week", alias="range"),
    user: str = Depends(get_admin_user),
) -> Dict[str, Any]:
    log_fetch(logger, f"获取趋势图数据 - 范围={time_range}")
    from services.dashboard.usecases import get_dashboard_usecase

    uc = get_dashboard_usecase(logger=logger)
    r = await uc.get_chart(app=request.app, time_range=time_range, trace_id=get_trace_id())
    if "error" in r:
        return JSONResponse(status_code=400, content=_error_response(r["error"]["code"], r["error"]["message"]))
    return _success_response(r["payload"], partial=r.get("partial", False), degraded_components=r.get("degraded_components", []))
