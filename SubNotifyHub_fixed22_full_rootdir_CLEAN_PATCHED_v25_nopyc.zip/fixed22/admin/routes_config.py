"""Admin routes: Unified configuration API.

This module implements the unified config endpoints used by the *通知与推送设置*
page (templates/pages/admin_config.html + static/js/config.js).

Endpoints:
  - GET  /admin/config.json : fetch all config groups and status
  - POST /admin/config      : save config changes (with rollback on reload error)

The unit tests patch several symbols from this module (get_settings, load_env_file,
reload_settings, _apply_runtime_settings), so we explicitly re-export those
symbols from admin.routes_base and reference them via this module namespace.
"""

from __future__ import annotations

import asyncio
from typing import Any, Dict, Iterable, List, Optional

import core.storage as storage
import forward_bridge.http_client

from . import routes_base as _routes_base


# ---------------------------------------------------------------------------
# Router + re-exports (required by tests)
# ---------------------------------------------------------------------------

router = _routes_base.APIRouter()

Request = _routes_base.Request
Depends = _routes_base.Depends
JSONResponse = _routes_base.JSONResponse

logger = _routes_base.logger
log_fetch = _routes_base.log_fetch
log_ok = _routes_base.log_ok
log_run = _routes_base.log_run

ENV_PATH = _routes_base.ENV_PATH

get_admin_user = _routes_base.get_admin_user

# These are patched in tests; keep them as module-level symbols.
get_settings = _routes_base.get_settings
reload_settings = _routes_base.reload_settings
load_env_file = _routes_base.load_env_file
_apply_runtime_settings = _routes_base._apply_runtime_settings
mask_sensitive = _routes_base.mask_sensitive
_is_ui_inline_hint_text = _routes_base._is_ui_inline_hint_text


# ---------------------------------------------------------------------------
# Field mapping (UI field name -> ENV key)
# ---------------------------------------------------------------------------

CONFIG_KEY_MAPPING: Dict[str, Dict[str, str]] = {
    "settings": {
        "emby_base_url": "EMBY_BASE_URL",
        "emby_api_key": "EMBY_API_KEY",
        "emby_wait_image": "EMBY_WAIT_FOR_IMAGE_ENABLED",
        "emby_wait_image_max": "EMBY_WAIT_FOR_IMAGE_MAX_WAIT",
        "tmdb_api_key": "TMDB_API_KEY",
        "webhook_secret": "WEBHOOK_SECRET",
        "webhook_allowed_ips": "WEBHOOK_ALLOWED_IPS",
        "webhook_trust_proxy": "WEBHOOK_TRUST_PROXY_HEADERS",
    },
    "notifier": {
        "notifier_types": "NOTIFIER_TYPES",
        "notifier_queue_size": "NOTIFIER_MAX_QUEUE_SIZE",
        "notifier_concurrency": "NOTIFIER_WORKER_CONCURRENCY",
        "notifier_timeout": "NOTIFIER_TIMEOUT",
        "notifier_enqueue_timeout": "NOTIFIER_ENQUEUE_TIMEOUT",
        "notifier_parallel": "NOTIFIER_PARALLEL",
        "notifier_require_all": "NOTIFIER_REQUIRE_ALL",
        "notifier_dry_run": "NOTIFIER_DRY_RUN",
        "notifier_max_retry": "NOTIFIER_MAX_RETRY",
        "notifier_backoff_base": "NOTIFIER_RETRY_BACKOFF_BASE",
        "notifier_backoff_max": "NOTIFIER_RETRY_BACKOFF_MAX",
        "notifier_jitter": "NOTIFIER_RETRY_JITTER",
        "notifier_agg_window": "NOTIFIER_AGGREGATE_WINDOW",
        "notifier_agg_max": "NOTIFIER_AGGREGATE_MAX_ITEMS",
        "episode_dedup_strategy": "EPISODE_DEDUP_STRATEGY",
        "dedup_ttl": "DEDUP_TTL_SECONDS",
        "dedup_max_size": "DEDUP_MAX_SIZE",
        "dedup_persistent": "DEDUP_PERSISTENT",
    },
    "telegram": {
        "bot_token": "TG_BOT_TOKEN",
        "chat_id": "TG_CHAT_ID",
        "bot_mode": "TG_BOT_MODE",
        "poll_timeout": "TG_BOT_POLL_TIMEOUT",
        "inbound_enabled": "TG_BOT_INBOUND_ENABLED",
        "outbox_enabled": "TG_BOT_OUTBOX_ENABLED",
        "allowed_user_ids": "TG_BOT_ALLOWED_USER_IDS",
        "webhook_secret": "TG_BOT_WEBHOOK_SECRET",
    },
    "cloud115": {
        "cookie": "CLOUD115_COOKIE",
        "qr_app": "CLOUD115_QR_APP",
        "dup_mode": "CLOUD115_DUP_MODE",
        "dup_window": "CLOUD115_DUP_WINDOW_MINUTES",
        "health_enabled": "CLOUD115_HEALTHCHECK_ENABLED",
        "poll_on_submit": "CLOUD115_POLL_ON_SUBMIT",
    },
    "forward": {
        "enabled": "FORWARD_BRIDGE_ENABLED",
        "debug": "FORWARD_BRIDGE_DEBUG",
        "season_filter": "ENABLE_SEASON_FILTER",
        "sub_cache_ttl": "FORWARD_BRIDGE_SUB_CACHE_TTL",
        "mediahelp_base": "MEDIAHELP_BASE",
        "mediahelp_username": "MEDIAHELP_LOGIN_USERNAME",
        "mediahelp_password": "MEDIAHELP_LOGIN_PASSWORD",
        "token": "FORWARD_BRIDGE_TOKEN",
        "allow_no_token": "FORWARD_BRIDGE_ALLOW_NO_TOKEN",
        "allow_public_notify": "FORWARD_BRIDGE_ALLOW_PUBLIC_NOTIFY",
    },
}


SENSITIVE_FIELDS: set[tuple[str, str]] = {
    ("settings", "emby_api_key"),
    ("settings", "tmdb_api_key"),
    ("settings", "webhook_secret"),
    ("telegram", "bot_token"),
    ("telegram", "webhook_secret"),
    ("cloud115", "cookie"),
    ("forward", "mediahelp_password"),
    ("forward", "token"),
}


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_str(s: Any, attr: str, default: str = "") -> str:
    try:
        return str(getattr(s, attr, default) or default)
    except (AttributeError, TypeError):
        return default


def _get_int(s: Any, attr: str, default: int = 0) -> int:
    try:
        return int(getattr(s, attr, default) or default)
    except (AttributeError, TypeError, ValueError):
        return default


def _get_float(s: Any, attr: str, default: float = 0.0) -> float:
    try:
        return float(getattr(s, attr, default) or default)
    except (AttributeError, TypeError, ValueError):
        return default


def _get_bool(s: Any, attr: str, default: bool = False) -> bool:
    try:
        return bool(getattr(s, attr, default))
    except (AttributeError, TypeError):
        return default


def _parse_int_list(v: Any) -> List[int]:
    if v is None:
        return []
    if isinstance(v, list):
        out: List[int] = []
        for x in v:
            try:
                out.append(int(x))
            except (TypeError, ValueError):
                continue
        return out
    s = str(v).strip()
    if not s:
        return []
    out2: List[int] = []
    for part in s.replace(";", ",").split(","):
        part = part.strip()
        if not part:
            continue
        try:
            out2.append(int(part))
        except (TypeError, ValueError):
            continue
    return out2


def _to_env_value(value: Any) -> Optional[str]:
    """Convert JSON payload values into .env string values.

    - bool -> "1"/"0"
    - list/tuple -> comma-separated
    - int/float -> normalized string
    - None -> None (delete key)
    """
    if value is None:
        return None
    if isinstance(value, bool):
        return "1" if value else "0"
    if isinstance(value, int):
        return str(value)
    if isinstance(value, float):
        if value.is_integer():
            return str(int(value))
        return str(value)
    if isinstance(value, (list, tuple)):
        parts = [str(x).strip() for x in value if str(x).strip()]
        return ",".join(parts)
    return str(value)


def _mask_if_needed(group: str, field: str, raw: str) -> str:
    if (group, field) in SENSITIVE_FIELDS:
        return mask_sensitive(raw)
    return raw


def _build_config(settings: Any) -> Dict[str, Dict[str, Any]]:
    return {
        "settings": {
            "emby_base_url": _get_str(settings, "EMBY_BASE_URL"),
            "emby_api_key": mask_sensitive(_get_str(settings, "EMBY_API_KEY")),
            "emby_wait_image": _get_bool(settings, "EMBY_WAIT_FOR_IMAGE_ENABLED", True),
            "emby_wait_image_max": _get_int(settings, "EMBY_WAIT_FOR_IMAGE_MAX_WAIT", 15),
            "tmdb_api_key": mask_sensitive(_get_str(settings, "TMDB_API_KEY")),
            "webhook_secret": mask_sensitive(_get_str(settings, "WEBHOOK_SECRET")),
            "webhook_allowed_ips": _get_str(settings, "WEBHOOK_ALLOWED_IPS"),
            "webhook_trust_proxy": _get_bool(settings, "WEBHOOK_TRUST_PROXY_HEADERS"),
        },
        "notifier": {
            "notifier_types": _get_str(settings, "NOTIFIER_TYPES"),
            "notifier_queue_size": _get_int(settings, "NOTIFIER_MAX_QUEUE_SIZE", 100),
            "notifier_concurrency": _get_int(settings, "NOTIFIER_WORKER_CONCURRENCY", 3),
            "notifier_timeout": _get_float(settings, "NOTIFIER_TIMEOUT", 15.0),
            "notifier_enqueue_timeout": _get_float(settings, "NOTIFIER_ENQUEUE_TIMEOUT", 2.0),
            "notifier_parallel": _get_bool(settings, "NOTIFIER_PARALLEL"),
            "notifier_require_all": _get_bool(settings, "NOTIFIER_REQUIRE_ALL", True),
            "notifier_dry_run": _get_bool(settings, "NOTIFIER_DRY_RUN"),
            "notifier_max_retry": _get_int(settings, "NOTIFIER_MAX_RETRY", 3),
            "notifier_backoff_base": _get_float(settings, "NOTIFIER_RETRY_BACKOFF_BASE", 2.0),
            "notifier_backoff_max": _get_float(settings, "NOTIFIER_RETRY_BACKOFF_MAX", 60.0),
            "notifier_jitter": _get_float(settings, "NOTIFIER_RETRY_JITTER", 0.1),
            "notifier_agg_window": _get_float(settings, "NOTIFIER_AGGREGATE_WINDOW", 30.0),
            "notifier_agg_max": _get_int(settings, "NOTIFIER_AGGREGATE_MAX_ITEMS", 20),
            "episode_dedup_strategy": _get_str(settings, "EPISODE_DEDUP_STRATEGY", "series"),
            "dedup_ttl": _get_int(settings, "DEDUP_TTL_SECONDS", 600),
            "dedup_max_size": _get_int(settings, "DEDUP_MAX_SIZE", 5000),
            "dedup_persistent": _get_bool(settings, "DEDUP_PERSISTENT"),
        },
        "telegram": {
            "bot_token": mask_sensitive(_get_str(settings, "TG_BOT_TOKEN")),
            "chat_id": _get_str(settings, "TG_CHAT_ID"),
            "bot_mode": _get_str(settings, "TG_BOT_MODE", "polling"),
            "poll_timeout": _get_int(settings, "TG_BOT_POLL_TIMEOUT", 20),
            "inbound_enabled": _get_bool(settings, "TG_BOT_INBOUND_ENABLED"),
            "outbox_enabled": _get_bool(settings, "TG_BOT_OUTBOX_ENABLED", True),
            "allowed_user_ids": _parse_int_list(_get_str(settings, "TG_BOT_ALLOWED_USER_IDS")),
            "webhook_secret": mask_sensitive(_get_str(settings, "TG_BOT_WEBHOOK_SECRET")),
        },
        "cloud115": {
            "cookie": mask_sensitive(_get_str(settings, "CLOUD115_COOKIE")),
            "qr_app": _get_str(settings, "CLOUD115_QR_APP"),
            "dup_mode": _get_str(settings, "CLOUD115_DUP_MODE"),
            "dup_window": _get_int(settings, "CLOUD115_DUP_WINDOW_MINUTES", 60),
            "health_enabled": _get_bool(settings, "CLOUD115_HEALTHCHECK_ENABLED"),
            "poll_on_submit": _get_bool(settings, "CLOUD115_POLL_ON_SUBMIT"),
        },
        "forward": {
            "enabled": _get_bool(settings, "FORWARD_BRIDGE_ENABLED"),
            "sub_cache_ttl": _get_int(settings, "FORWARD_BRIDGE_SUB_CACHE_TTL", 300),
            "debug": _get_bool(settings, "FORWARD_BRIDGE_DEBUG"),
            "season_filter": _get_bool(settings, "ENABLE_SEASON_FILTER"),
            "allow_public_notify": _get_bool(settings, "FORWARD_BRIDGE_ALLOW_PUBLIC_NOTIFY"),
            "token": mask_sensitive(_get_str(settings, "FORWARD_BRIDGE_TOKEN")),
            "allow_no_token": _get_bool(settings, "FORWARD_BRIDGE_ALLOW_NO_TOKEN", True),
            "mediahelp_base": _get_str(settings, "MEDIAHELP_BASE"),
            "mediahelp_username": _get_str(settings, "MEDIAHELP_LOGIN_USERNAME"),
            "mediahelp_password": mask_sensitive(_get_str(settings, "MEDIAHELP_LOGIN_PASSWORD")),
        },
    }


def _build_status(settings: Any) -> Dict[str, bool]:
    emby_url = _get_str(settings, "EMBY_BASE_URL").strip()
    emby_key = _get_str(settings, "EMBY_API_KEY").strip()
    tg_token = _get_str(settings, "TG_BOT_TOKEN").strip()
    tg_chat = _get_str(settings, "TG_CHAT_ID").strip()
    tmdb_key = _get_str(settings, "TMDB_API_KEY").strip()
    cloud115_cookie = _get_str(settings, "CLOUD115_COOKIE").strip()

    emby_connected = bool(emby_url and emby_key)
    tg_connected = bool(tg_token and tg_chat)
    tmdb_configured = bool(tmdb_key)
    cloud115_configured = bool(cloud115_cookie)

    try:
        forward_ok = bool(forward_bridge.http_client.have_token())
    except Exception:
        forward_ok = False

    return {
        "emby_connected": emby_connected,
        "tg_connected": tg_connected,
        "tmdb_configured": tmdb_configured,
        "cloud115_configured": cloud115_configured,
        "forward_ok": forward_ok,
    }


def _iter_payload_fields(payload: Dict[str, Any]) -> Iterable[tuple[str, str, Any]]:
    """Yield (group, field, value) from payload; ignores invalid shapes."""
    for group, group_data in (payload or {}).items():
        if not isinstance(group, str):
            continue
        if not isinstance(group_data, dict):
            continue
        for field, value in group_data.items():
            if not isinstance(field, str):
                continue
            yield group, field, value


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@router.get("/admin/config.json", response_class=JSONResponse)
async def admin_config_all(request: Request, user: str = Depends(get_admin_user)) -> Dict[str, Any]:
    """Return all configuration data in a unified response."""

    log_fetch(logger, "config: unified fetch")

    s = get_settings()
    config = _build_config(s)
    status = _build_status(s)

    log_ok(logger, "config: unified fetch")
    return {"ok": True, "config": config, "status": status}


@router.post("/admin/config", response_class=JSONResponse)
async def save_admin_config(request: Request, user: str = Depends(get_admin_user)) -> Dict[str, Any]:
    """Persist unified config changes into .env and hot-reload runtime.

    Implements a rollback mechanism: if reload/apply fails after writing `.env`,
    revert changed keys back to the previous values.
    """

    log_run(logger, "config: unified save")
    payload = await request.json()
    if not isinstance(payload, dict):
        return {"ok": False, "detail": "invalid payload"}

    # Read current env snapshot (tests patch this symbol for determinism).
    old_env: Dict[str, str] = {}
    try:
        old_env = dict(load_env_file(ENV_PATH) or {})
    except Exception as e:
        # Non-fatal: we can still attempt to write using update_env_file.
        logger.detail("读取 .env 失败（已忽略）", error=type(e).__name__)
        old_env = {}

    changes: Dict[str, Optional[str]] = {}
    changed_keys: List[str] = []

    for group, field, value in _iter_payload_fields(payload):
        mapping = CONFIG_KEY_MAPPING.get(group)
        if not mapping:
            continue
        env_key = mapping.get(field)
        if not env_key:
            continue

        # Guard: UI placeholders / masked values should never be persisted.
        if isinstance(value, str):
            v0 = value.strip()
            if not v0:
                # allow clearing (empty string)
                pass
            else:
                if _is_ui_inline_hint_text(v0):
                    continue
                if "*" in v0:
                    # masked secret from UI
                    continue

        env_val = _to_env_value(value)
        old_val = old_env.get(env_key)
        if (old_val is None and env_val is None) or (str(old_val or "") == str(env_val or "")):
            continue

        changes[env_key] = env_val
        changed_keys.append(env_key)

    if not changed_keys:
        return {"ok": True, "flash": {"title": "无变更", "body": "未检测到配置变更"}}

    # 1) persist .env (call via core.storage so tests can patch it)
    ok = False
    try:
        ok = bool(storage.update_env_file(changes, verify=True))
    except Exception as e:
        logger.detail("写入 .env 失败", exc_info=True)
        return {"ok": False, "detail": f"写入配置失败: {type(e).__name__}: {e}"}

    if not ok:
        return {"ok": False, "detail": "写入配置失败: update_env_file returned false"}

    # 2) reload + apply runtime settings; rollback on failure
    try:
        reload_settings()
        try:
            await _apply_runtime_settings(getattr(request, "app", None), changed_keys)
        except TypeError:
            # Backward-compat: some implementations only accept (app)
            await _apply_runtime_settings(getattr(request, "app", None))
    except Exception as e:
        # rollback
        rollback: Dict[str, Optional[str]] = {k: old_env.get(k) for k in changed_keys}
        try:
            storage.update_env_file(rollback, verify=False)
        except Exception:
            logger.detail("回滚 .env 失败", exc_info=True)
        try:
            reload_settings()
        except Exception:
            # ignore secondary failures
            pass
        return {"ok": False, "detail": f"配置校验失败: {type(e).__name__}: {e}"}

    return {
        "ok": True,
        "flash": {"title": "已保存", "body": f"配置已保存（更新 {len(changed_keys)} 项）"},
    }


# Backward-compatible alias (older code might still import this name).
admin_config_save = save_admin_config
