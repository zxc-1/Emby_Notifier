"""Admin routes: Dedup page (thin)."""

from __future__ import annotations

from . import routes_base as _routes_base

router = _routes_base.APIRouter(tags=["dedup"])

Request = _routes_base.Request
Depends = _routes_base.Depends
from fastapi.responses import HTMLResponse

templates = _routes_base.templates
get_admin_user = _routes_base.get_admin_user


@router.get("/admin/dedup")
async def admin_dedup_page(request: Request, _user: str = Depends(get_admin_user)):
    return templates.TemplateResponse("admin_dedup.html", {"request": request, **_routes_base.get_app_info(request)})


__all__ = ["router"]
