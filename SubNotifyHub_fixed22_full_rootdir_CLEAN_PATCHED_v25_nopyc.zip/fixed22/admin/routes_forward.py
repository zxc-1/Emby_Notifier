"""Admin routes: Forward Bridge configuration and status APIs (thin)."""

from __future__ import annotations

from typing import Any, Dict

from . import routes_base as _routes_base
from services.forward import get_forward_usecase

router = _routes_base.APIRouter()
Request = _routes_base.Request
Depends = _routes_base.Depends
JSONResponse = _routes_base.JSONResponse

logger = _routes_base.logger
log_fetch = _routes_base.log_fetch
get_admin_user = _routes_base.get_admin_user


@router.get("/admin/forward/config.json", response_class=JSONResponse)
async def admin_forward_config(request: Request, user: str = Depends(get_admin_user)) -> Dict[str, Any]:
    log_fetch(logger, "forward: config fetch")
    uc = get_forward_usecase()
    cfg = uc.get_config()
    return {
        "ok": True,
        "config": {
            "enabled": cfg.enabled,
            "sub_cache_ttl": cfg.sub_cache_ttl,
            "debug": cfg.debug,
            "season_filter": cfg.season_filter,
            "allow_public_notify": cfg.allow_public_notify,
            "token": cfg.token,
            "allow_no_token": cfg.allow_no_token,
            "mediahelp_base": cfg.mediahelp_base,
            "mediahelp_username": cfg.mediahelp_username,
            "mediahelp_password": cfg.mediahelp_password_masked,
        },
    }


@router.get("/admin/forward/status.json", response_class=JSONResponse)
async def admin_forward_status(request: Request, user: str = Depends(get_admin_user)) -> Dict[str, Any]:
    log_fetch(logger, "forward: status fetch")
    uc = get_forward_usecase()
    st = uc.get_status()
    return {
        "ok": True,
        "status": {
            "bridge_ok": st.bridge_ok,
            "mh_connected": st.mh_connected,
            "token_expires": st.token_expires,
            "cached_subs": st.cached_subs,
        },
    }


__all__ = ["router"]
