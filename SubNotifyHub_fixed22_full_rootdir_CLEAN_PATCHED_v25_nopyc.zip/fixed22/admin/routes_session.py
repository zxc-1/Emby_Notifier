from __future__ import annotations

"""Admin routes: session probe (thin).

Delegates persisted-record logic to services.admin_auth.
"""

from . import routes_base as _routes_base
from services.admin_auth import get_admin_auth_usecase

router = _routes_base.APIRouter()

Request = _routes_base.Request
Depends = _routes_base.Depends
JSONResponse = _routes_base.JSONResponse

logger = _routes_base.logger
log_fetch = _routes_base.log_fetch
get_admin_user = _routes_base.get_admin_user


@router.get("/admin/session", response_class=JSONResponse)
async def admin_session(request: Request, user: str = Depends(get_admin_user)):
    log_fetch(logger, "admin: session probe")

    current_flag = bool(request.session.get("must_change_password", False))
    uc = get_admin_auth_usecase()
    rec_flag = await uc.session_probe(current_flag=current_flag)

    if rec_flag != current_flag:
        try:
            request.session["must_change_password"] = rec_flag
        except Exception:
            logger.detail("admin: sync must_change_password session flag failed", exc_info=True)

    return {"ok": True, "user": user, "must_change_password": bool(rec_flag)}


__all__ = ["router"]
