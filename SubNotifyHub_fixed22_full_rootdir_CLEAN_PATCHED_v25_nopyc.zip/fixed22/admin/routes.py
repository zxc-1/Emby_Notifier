"""Admin router entrypoint.

This module exports a single `router` object consumed by core.bootstrap.

v1.5.7.14 refactor:
- Avoid "import side effects" for route registration.
- Each routes_*.py owns an independent APIRouter.
- This entrypoint composes them via include_router(), which is more explicit
  and reduces cyclic-import risks.
"""

from fastapi import APIRouter

from .routes_pages import router as pages_router
from .routes_ui import router as ui_router
from .routes_auth import router as auth_router
from .routes_session import router as session_router
from .routes_settings import router as settings_router
from .routes_tg_bot import router as tg_router
from .routes_cloud115 import router as cloud115_router
from .routes_mediahelp import router as mediahelp_router
from .routes_forward import router as forward_router
from .routes_failed_updates import router as failed_updates_router
from .routes_hotlist import router as hotlist_router
from .routes_dashboard_api import router as dashboard_api_router
from .routes_dedup import router as dedup_router
from .routes_dedup_api import router as dedup_api_router
from .routes_config import router as config_router
from .routes_crawler import router as crawler_router


router = APIRouter()

# Order matters only for route matching precedence (static over dynamic).
router.include_router(pages_router)
router.include_router(ui_router)
router.include_router(auth_router)
router.include_router(session_router)
router.include_router(settings_router)
router.include_router(tg_router)
router.include_router(cloud115_router)
router.include_router(mediahelp_router)
router.include_router(forward_router)
router.include_router(failed_updates_router)
router.include_router(hotlist_router)
router.include_router(dashboard_api_router)
router.include_router(dedup_router)
router.include_router(dedup_api_router)
router.include_router(config_router)
router.include_router(crawler_router)


__all__ = ["router"]
