from __future__ import annotations

"""Admin routes: failed update inspection.

These routes expose the bot's dead-letter table for troubleshooting.
Read-only.
"""

from . import routes_base as _routes_base

from tg_bot.storage import get_failed_update_detail, list_failed_updates

router = _routes_base.APIRouter()

Depends = _routes_base.Depends
JSONResponse = _routes_base.JSONResponse
Request = _routes_base.Request
get_admin_user = _routes_base.get_admin_user
log_fetch = _routes_base.log_fetch
logger = _routes_base.logger


@router.get("/admin/failed-updates", response_class=JSONResponse)
async def admin_failed_updates(request: Request, user: str = Depends(get_admin_user), limit: int = 30):
    log_fetch(logger, "admin: failed updates")
    limit = int(limit or 30)
    limit = max(1, min(200, limit))
    rows = list_failed_updates(limit=limit)
    return {"ok": True, "rows": rows}


@router.get("/admin/failed-updates/{update_id}", response_class=JSONResponse)
async def admin_failed_update_detail(request: Request, update_id: int, user: str = Depends(get_admin_user)):
    log_fetch(logger, "admin: failed update detail")
    row = get_failed_update_detail(int(update_id or 0))
    return {"ok": bool(row), "row": row}


__all__ = ["router"]
