from __future__ import annotations

from typing import Any, Dict

"""Admin routes: MediaHelp admin APIs (thin routes)."""

from . import routes_base as _routes_base

Depends = _routes_base.Depends
JSONResponse = _routes_base.JSONResponse
Request = _routes_base.Request
get_admin_user = _routes_base.get_admin_user

router = _routes_base.APIRouter()

from services.mediahelp import usecases as mediahelp_uc


@router.post("/admin/tg-bot/mediahelp/login", response_class=JSONResponse)
async def admin_mediahelp_login(request: Request, user: str = Depends(get_admin_user)) -> Dict[str, Any]:
    try:
        payload = await request.json()
    except Exception:
        payload = None
    return await mediahelp_uc.login(payload if isinstance(payload, dict) else None)


@router.get("/admin/tg-bot/mediahelp/test", response_class=JSONResponse)
async def admin_mediahelp_test(user: str = Depends(get_admin_user)) -> Dict[str, Any]:
    return await mediahelp_uc.test()
