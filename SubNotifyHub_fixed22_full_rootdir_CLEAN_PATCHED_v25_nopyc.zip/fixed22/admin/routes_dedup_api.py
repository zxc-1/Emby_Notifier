"""Dedup API compatibility entrypoint.

The media-management UI ("媒体管理") relies on a fairly large set of APIs
under the `/api/dedup/*` namespace. The canonical implementation lives in
`services.dedup.api`.

This module exists so the admin router can keep a stable import path:

    from .routes_dedup_api import router

It simply re-exports the canonical router.
"""

from __future__ import annotations

# The canonical router already includes prefix "/api/dedup".
from services.dedup.api import router  # noqa: F401

__all__ = ["router"]
