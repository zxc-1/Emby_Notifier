"""Admin UI view-models.

This module is kept for backward compatibility.

The implementation lives in :mod:`services.pages.view_models` so that service
layers can build dashboard contexts without importing admin routes.
"""

from __future__ import annotations

# Re-export all view-models and builders.
from services.pages.view_models import *  # noqa: F401,F403
