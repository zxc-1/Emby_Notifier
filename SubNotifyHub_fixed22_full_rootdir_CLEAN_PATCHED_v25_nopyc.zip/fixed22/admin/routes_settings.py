from __future__ import annotations

import re
from typing import Any, Dict, List, Optional
from fastapi import status
from core.exceptions.base import ConfigurationError

from urllib.parse import urlparse

"""Admin routes: settings forms (/admin/settings, /admin/forward-settings)."""

from . import routes_base as _routes_base
import asyncio as _asyncio
# --- explicit re-exports from .routes_base (replacing star import) ---
ADMIN_BOOL_KEYS = _routes_base.ADMIN_BOOL_KEYS
ADMIN_LIST_KEYS = _routes_base.ADMIN_LIST_KEYS
ADMIN_TEXT_KEYS = _routes_base.ADMIN_TEXT_KEYS
FORWARD_BOOL_KEYS = _routes_base.FORWARD_BOOL_KEYS
Depends = _routes_base.Depends
ENV_PATH = _routes_base.ENV_PATH

# Standalone router for this module (included by admin.routes)
router = _routes_base.APIRouter()

# Re-exported symbols used below
HTTPException = _routes_base.HTTPException
Request = _routes_base.Request
Depends = _routes_base.Depends
JSONResponse = _routes_base.JSONResponse
RedirectResponse = _routes_base.RedirectResponse

logger = _routes_base.logger
log_run = _routes_base.log_run
log_ok = _routes_base.log_ok
log_fetch = _routes_base.log_fetch

UI_PREFS_PATH = _routes_base.UI_PREFS_PATH

get_settings = _routes_base.get_settings
reload_settings = _routes_base.reload_settings
load_env_file = _routes_base.load_env_file
dump_env_file = _routes_base.dump_env_file
load_json = _routes_base.load_json
save_json = _routes_base.save_json

get_admin_user = _routes_base.get_admin_user
_is_ui_inline_hint_text = _routes_base._is_ui_inline_hint_text
_apply_tg_polling = _routes_base._apply_tg_polling
_apply_runtime_settings = _routes_base._apply_runtime_settings
mask_sensitive = _routes_base.mask_sensitive



@router.post("/admin/settings")
async def save_admin_settings(request: Request, user: str = Depends(get_admin_user)):
    """Persist settings into .env and hot-reload runtime."""
    return await _uc.save_admin_settings(request)

@router.post("/admin/forward-settings")
async def save_forward_settings(request: Request, user: str = Depends(get_admin_user)):
    """Persist Forward settings into .env and hot-reload runtime."""
    return await _uc.save_forward_settings(request)

@router.get("/admin/settings/config.json", response_class=JSONResponse)
async def admin_settings_config(request: Request, user: str = Depends(get_admin_user)) -> Dict[str, Any]:
    """Return Settings page configuration data.
    
    Returns all configuration fields needed by the Settings page frontend.
    Sensitive fields (API keys, secrets, cookies) are masked.
    
    _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 1.10, 1.11_
    """
    log_fetch(logger, "settings: config fetch")
    
    settings = get_settings()
    
    def get_str(attr: str, default: str = "") -> str:
        try:
            return str(getattr(settings, attr, default) or default)
        except (AttributeError, TypeError):
            return default
    
    def get_int(attr: str, default: int = 0) -> int:
        try:
            return int(getattr(settings, attr, default) or default)
        except (AttributeError, TypeError, ValueError):
            return default
    
    def get_float(attr: str, default: float = 0.0) -> float:
        try:
            return float(getattr(settings, attr, default) or default)
        except (AttributeError, TypeError, ValueError):
            return default
    
    def get_bool(attr: str, default: bool = False) -> bool:
        try:
            return bool(getattr(settings, attr, default))
        except (AttributeError, TypeError):
            return default
    
    config = {
        # Emby 配置
        "emby_base_url": get_str("EMBY_BASE_URL"),
        "emby_api_key": mask_sensitive(get_str("EMBY_API_KEY")),
        "emby_wait_image": get_bool("EMBY_WAIT_FOR_IMAGE_ENABLED", True),
        "emby_wait_image_max": get_int("EMBY_WAIT_FOR_IMAGE_MAX_WAIT", 15),
        
        # Webhook 配置
        "webhook_secret": mask_sensitive(get_str("WEBHOOK_SECRET")),
        "webhook_allowed_ips": get_str("WEBHOOK_ALLOWED_IPS"),
        "webhook_trust_proxy": get_bool("WEBHOOK_TRUST_PROXY_HEADERS"),
        
        # 通知器配置
        "notifier_types": get_str("NOTIFIER_TYPES"),
        "notifier_queue_size": get_int("NOTIFIER_MAX_QUEUE_SIZE", 100),
        "notifier_concurrency": get_int("NOTIFIER_WORKER_CONCURRENCY", 3),
        "notifier_timeout": get_float("NOTIFIER_TIMEOUT", 15.0),
        "notifier_enqueue_timeout": get_float("NOTIFIER_ENQUEUE_TIMEOUT", 2.0),
        "notifier_parallel": get_bool("NOTIFIER_PARALLEL"),
        "notifier_require_all": get_bool("NOTIFIER_REQUIRE_ALL", True),
        "notifier_dry_run": get_bool("NOTIFIER_DRY_RUN"),
        
        # 重试策略
        "notifier_max_retry": get_int("NOTIFIER_MAX_RETRY", 3),
        "notifier_backoff_base": get_float("NOTIFIER_RETRY_BACKOFF_BASE", 2.0),
        "notifier_backoff_max": get_float("NOTIFIER_RETRY_BACKOFF_MAX", 60.0),
        "notifier_jitter": get_float("NOTIFIER_RETRY_JITTER", 0.1),
        
        # 消息聚合
        "notifier_agg_window": get_float("NOTIFIER_AGGREGATE_WINDOW", 30.0),
        "notifier_agg_max": get_int("NOTIFIER_AGGREGATE_MAX_ITEMS", 20),
        
        # Pipeline 配置
        "pipeline_steps": get_str("PIPELINE_STEPS", "extract,enrich,render,covers,content"),
        "pipeline_strict": get_bool("PIPELINE_STRICT"),
        
        # 去重配置
        "episode_dedup_strategy": get_str("EPISODE_DEDUP_STRATEGY", "series"),
        "dedup_ttl": get_int("DEDUP_TTL_SECONDS", 600),
        "dedup_max_size": get_int("DEDUP_MAX_SIZE", 5000),
        "dedup_persistent": get_bool("DEDUP_PERSISTENT"),
        
        # 高级配置
        "tmdb_api_key": mask_sensitive(get_str("TMDB_API_KEY")),
        "cloud115_cookie": mask_sensitive(get_str("CLOUD115_COOKIE")),
        "log_level": get_str("LOG_LEVEL", "INFO"),
        "debug_history_size": get_int("DEBUG_NOTIFICATION_HISTORY_SIZE", 100),
        "debug_enable_api": get_bool("DEBUG_ENABLE_API"),
    }
    
    return {"ok": True, "config": config}


# ========================================
# Settings Status API
# ========================================

@router.get("/admin/settings/status.json", response_class=JSONResponse)
async def admin_settings_status(request: Request, user: str = Depends(get_admin_user)) -> Dict[str, Any]:
    """Return system component status for Settings page.
    
    Returns:
        - emby_connected: bool - Emby 是否已配置且可连接
        - tmdb_configured: bool - TMDB API Key 是否已配置
        - notifier_ready: bool - 通知器是否就绪
        - webhook_configured: bool - Webhook Secret 是否已配置
        - cloud115_configured: bool - 115 Cookie 是否已配置
    
    _Requirements: 2.1, 2.2, 8.4, 8.5_
    """
    log_fetch(logger, "settings: status check")
    
    settings = get_settings()
    
    # Emby 连接状态：检查是否配置了 URL 和 API Key
    emby_connected = False
    try:
        emby_url = str(getattr(settings, "EMBY_BASE_URL", "") or "").strip()
        emby_key = str(getattr(settings, "EMBY_API_KEY", "") or "").strip()
        emby_connected = bool(emby_url and emby_key)
    except (AttributeError, TypeError):
        logger.detail("设置：检查 emby config 失败")
    
    # TMDB 配置状态
    tmdb_configured = False
    try:
        tmdb_key = str(getattr(settings, "TMDB_API_KEY", "") or "").strip()
        tmdb_configured = bool(tmdb_key)
    except (AttributeError, TypeError):
        logger.detail("设置：检查 tmdb config 失败")
    
    # 通知器就绪状态：检查是否配置了通知类型
    notifier_ready = False
    try:
        notifier_types = str(getattr(settings, "NOTIFIER_TYPES", "") or "").strip()
        notifier_ready = bool(notifier_types)
    except (AttributeError, TypeError):
        logger.detail("设置：检查 notifier config 失败")
    
    # Webhook 配置状态
    webhook_configured = False
    try:
        webhook_secret = str(getattr(settings, "WEBHOOK_SECRET", "") or "").strip()
        webhook_configured = bool(webhook_secret)
    except (AttributeError, TypeError):
        logger.detail("设置：检查 webhook config 失败")
    
    # 115 云盘配置状态
    cloud115_configured = False
    try:
        cloud115_cookie = str(getattr(settings, "CLOUD115_COOKIE", "") or "").strip()
        cloud115_configured = bool(cloud115_cookie)
    except (AttributeError, TypeError):
        logger.detail("设置：检查 cloud115 config 失败")
    
    return {
        "ok": True,
        "status": {
            "emby_connected": emby_connected,
            "tmdb_configured": tmdb_configured,
            "notifier_ready": notifier_ready,
            "webhook_configured": webhook_configured,
            "cloud115_configured": cloud115_configured,
        }
    }
from services.settings.usecases import AdminSettingsUsecase
_uc = AdminSettingsUsecase()
