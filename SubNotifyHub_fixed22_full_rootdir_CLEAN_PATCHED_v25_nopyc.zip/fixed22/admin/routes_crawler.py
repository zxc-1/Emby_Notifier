from __future__ import annotations

from typing import Any, Literal, Optional

from fastapi import APIRouter, Depends, Request, Body
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from .routes_base import get_admin_user
from services.crawler.usecases import CrawlerAdminUsecase

router = APIRouter(prefix="/admin/crawler", tags=["crawler"])


def _uc(request: Request) -> CrawlerAdminUsecase:
    return CrawlerAdminUsecase(request)


class SubscribeBody(BaseModel):
    name: str = Field(default="", description="UI name")
    deliver_to: Literal["115", "cd2"] = "115"
    # No implicit default path: empty means user must configure or pass explicitly.
    save_path: str = Field(default="", description="remote save path")
    notify_enabled: bool = True
    # New: multi deliver (can select both 115 and CD2)
    deliver_targets: list[Literal["115", "cd2"]] = Field(default_factory=list, description="deliver targets")
    save_paths: dict[str, str] = Field(default_factory=dict, description="{target: save_path}")
    # New: multi-source + multi-section
    sources: list[str] = Field(default_factory=list, description="crawler sources")
    sections_by_source: dict[str, list[str]] = Field(default_factory=dict, description="{source:[section,...]}")
    mode: Literal["auto", "fast", "compat", "browser"] = "auto"
    keywords: list[str] = Field(default_factory=list)
    user_key: str | None = Field(default=None, description="optional owner")

    # Backward-compat (optional): single source/section
    source: str | None = None
    section: str | None = None


class DeliverBody(BaseModel):
    deliver_to: Literal["115", "cd2"] = "115"
    # No implicit default path.
    save_path: str = ""


class UpdateSubscriptionBody(BaseModel):
    name: Optional[str] = None
    is_enabled: Optional[bool] = None
    notify_enabled: Optional[bool] = None
    deliver_to: Optional[Literal["115", "cd2"]] = None
    save_path: Optional[str] = None
    deliver_targets: Optional[list[Literal["115", "cd2"]]] = None
    save_paths: Optional[dict[str, str]] = None
    sources: Optional[list[str]] = None
    sections_by_source: Optional[dict[str, list[str]]] = None
    source: Optional[str] = None
    section: Optional[str] = None
    mode: Optional[Literal["auto", "fast", "compat", "browser"]] = None
    keywords: Optional[list[str]] = None


class ValidateCronBody(BaseModel):
    expr: str = Field(..., description="cron expr")


class Test115Body(BaseModel):
    cookie: str = Field(default="", description="115 cookie (optional; fallback to CLOUD115_COOKIE)")


class TestCD2Body(BaseModel):
    # New (route1)
    mode: str = "cloudapi"
    base_url: str = ""
    username: str = ""
    password: str = ""
    grpc_addr: str = ""
    token: str = ""
    # Backward-compat
    url: str = ""
    api_key: str = ""


@router.post("/subscribe")
async def subscribe(request: Request, body: SubscribeBody, user: str = Depends(get_admin_user)) -> dict[str, Any]:
    return await _uc(request).subscribe(user=user, body=body.model_dump())


@router.get("/meta")
async def crawler_meta(request: Request, _user: str = Depends(get_admin_user)) -> dict[str, Any]:
    return await _uc(request).meta()


@router.post("/deliver/{item_id}")
async def deliver_item(
    request: Request, item_id: int, body: DeliverBody, _user: str = Depends(get_admin_user)
) -> dict[str, Any]:
    return await _uc(request).deliver_item(item_id=item_id, body=body.model_dump())


@router.get("/status")
async def crawler_status(request: Request, _user: str = Depends(get_admin_user)) -> dict[str, Any]:
    return await _uc(request).status()


@router.get("/health")
async def crawler_health(request: Request, _user: str = Depends(get_admin_user)) -> dict[str, Any]:
    return await _uc(request).health()


@router.get("/home.json")
async def crawler_home_json(
    request: Request,
    range: str = "all",
    _user: str = Depends(get_admin_user),
) -> dict[str, Any]:
    return await _uc(request).home_json(range=range)


@router.post("/run_once")
async def crawler_run_once(request: Request, _user: str = Depends(get_admin_user)) -> dict[str, Any]:
    return await _uc(request).run_once()


@router.post("/validate_cron")
async def crawler_validate_cron(
    request: Request, body: ValidateCronBody, _user: str = Depends(get_admin_user)
) -> dict[str, Any]:
    return await _uc(request).validate_cron(expr=body.expr)


@router.post("/test/115")
async def crawler_test_115(request: Request, body: Test115Body, _user: str = Depends(get_admin_user)) -> dict[str, Any]:
    return await _uc(request).test_115(cookie=body.cookie)


@router.post("/test/cd2")
async def crawler_test_cd2(request: Request, body: TestCD2Body, _user: str = Depends(get_admin_user)) -> dict[str, Any]:
    data = body.model_dump()
    return await _uc(request).test_cd2(cfg=data)


@router.post("/cleanup")
async def crawler_cleanup(
    request: Request, days: int = Body(default=30, embed=True), _user: str = Depends(get_admin_user)
) -> dict[str, Any]:
    return await _uc(request).cleanup(days=days)


@router.get("/subscriptions")
async def crawler_subscriptions(request: Request, _user: str = Depends(get_admin_user)) -> dict[str, Any]:
    return await _uc(request).list_subscriptions()


@router.delete("/subscriptions/{sub_id}")
async def crawler_delete_subscription(request: Request, sub_id: str, _user: str = Depends(get_admin_user)) -> dict[str, Any]:
    return await _uc(request).delete_subscription(sub_id=sub_id)


@router.patch("/subscriptions/{sub_id}")
async def crawler_update_subscription(
    request: Request,
    sub_id: str,
    body: UpdateSubscriptionBody,
    _user: str = Depends(get_admin_user),
) -> dict[str, Any]:
    data = body.model_dump(exclude_none=True)
    rule: dict[str, Any] | None = None
    if any(k in data for k in ("sources","sections_by_source","source","section","keywords","mode")):
        sources = data.get("sources") or ([] if not data.get("source") else [data.get("source")])
        sources = [str(s).strip() for s in (sources or []) if str(s).strip()]
        if not sources:
            sources = ["sehuatang"]
        sections_by_source = data.get("sections_by_source") or {}
        if not isinstance(sections_by_source, dict):
            sections_by_source = {}
        if (not sections_by_source) and data.get("section"):
            sections_by_source = { (data.get("source") or sources[0] or "sehuatang"): [data.get("section")] }
        rule = {
            "sources": sources,
            "sections_by_source": sections_by_source,
            "mode": data.get("mode") or "auto",
            "keywords": data.get("keywords") or [],
        }
    return await _uc(request).update_subscription(
        sub_id=sub_id,
        name=data.get("name"),
        deliver_to=data.get("deliver_to"),
        save_path=data.get("save_path"),
        deliver_targets=data.get("deliver_targets"),
        save_paths=data.get("save_paths"),
        notify_enabled=data.get("notify_enabled"),
        rule=rule,
        enabled=data.get("is_enabled"),
    )


@router.get("/items")
async def crawler_items(
    request: Request,
    limit: int = 50,
    offset: int = 0,
    cursor: str = "",
    q: str = "",
    source: str = "",
    section: str = "",
    status: str = "",
    range: str = "all",
    _user: str = Depends(get_admin_user),
) -> dict[str, Any]:
    return await _uc(request).items(
        limit=limit,
        offset=offset,
        cursor=cursor,
        q=q,
        source=source,
        section=section,
        status=status,
        range=range,
    )


@router.get("/items/{item_id}")
async def crawler_item_detail(request: Request, item_id: int, _user: str = Depends(get_admin_user)) -> dict[str, Any]:
    return await _uc(request).item_detail(item_id=item_id)


@router.get("/cover/{item_id}")
async def crawler_cover(request: Request, item_id: str, _user: str = Depends(get_admin_user)):
    path = await _uc(request).cover(item_id=item_id)
    # Provide a correct Content-Type to improve browser/admin UX.
    try:
        from crawler.cover_cache import mime_for_path

        mime = mime_for_path(path)
    except Exception:
        mime = None
    return FileResponse(path, media_type=mime, filename=getattr(path, "name", None))


@router.get("/tasks")
async def crawler_tasks(
    request: Request,
    limit: int = 50,
    offset: int = 0,
    status: str = "",
    deliver_to: str = "",
    _user: str = Depends(get_admin_user),
) -> dict[str, Any]:
    return await _uc(request).tasks(limit=limit, offset=offset, status=status, deliver_to=deliver_to)


@router.post("/tasks/{task_id}/retry")
async def crawler_retry_task(request: Request, task_id: str, _user: str = Depends(get_admin_user)) -> dict[str, Any]:
    return await _uc(request).retry_task(task_id=task_id)


@router.post("/tasks/retry_failed")
async def crawler_retry_failed(
    request: Request, limit: int = 200, _user: str = Depends(get_admin_user)
) -> dict[str, Any]:
    return await _uc(request).retry_failed(limit=limit)


@router.get("/logs")
async def crawler_logs(request: Request, limit: int = 200, _user: str = Depends(get_admin_user)) -> dict[str, Any]:
    return await _uc(request).logs(limit=limit)


@router.get("/config.json")
async def crawler_config_json(request: Request, _user: str = Depends(get_admin_user)) -> dict[str, Any]:
    return await _uc(request).config_get()


@router.post("/config.json")
async def crawler_update_config_json(
    request: Request, patch: dict[str, Any] = Body(default_factory=dict), _user: str = Depends(get_admin_user)
) -> dict[str, Any]:
    return await _uc(request).config_update(patch=patch)
