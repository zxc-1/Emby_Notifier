from __future__ import annotations

"""Admin routes: Douban hotlist subscriptions (Web Admin tab)."""

import asyncio
from typing import Any, Dict, Optional

from fastapi.responses import HTMLResponse

from . import routes_base as _routes_base
from services.hotlist.usecases import HotlistUsecase

router = _routes_base.APIRouter()

Request = _routes_base.Request
JSONResponse = _routes_base.JSONResponse
Depends = _routes_base.Depends
HTTPException = _routes_base.HTTPException

get_admin_user = _routes_base.get_admin_user
log_fetch = _routes_base.log_fetch
log_run = _routes_base.log_run
log_ok = _routes_base.log_ok
logger = _routes_base.logger

_uc = HotlistUsecase()


@router.get("/admin/hotlist", response_class=HTMLResponse)
def admin_hotlist_page(request: Request, user: str = Depends(get_admin_user)):
    """热榜管理页。"""
    from settings import get_settings

    cur_settings = get_settings()
    pref_chat_id = getattr(cur_settings, "TG_CHAT_ID", "") or ""
    return _routes_base.templates.TemplateResponse(
        "pages/admin_hotlist.html",
        {"request": request, "user": user, "active_nav": "hotlist", "pref_chat_id": pref_chat_id},
    )


@router.get("/admin/hotlist.json", response_class=JSONResponse)
async def admin_hotlist_json(
    request: Request,
    user: str = Depends(get_admin_user),
    chat_id: Optional[int] = None,
) -> Dict[str, Any]:
    """Return hotlist admin data: builtins + subscriptions + snapshots."""
    log_fetch(logger, "获取热榜订阅列表")
    try:
        from douban_hotlist.builtins import get_builtin_lists
        from douban_hotlist.store import list_subscriptions, get_snapshot, count_ignores_bulk
    except Exception as e:
        logger.detail("hotlist import failed", exc_info=True)
        raise HTTPException(status_code=500, detail="IMPORT_FAILED") from e

    subs = await asyncio.to_thread(list_subscriptions, chat_id=chat_id)
    snaps: Dict[str, Any] = {}
    ignores: Dict[str, int] = {}
    try:
        for s in subs:
            lk = str(s.get("list_key") or "")
            if not lk:
                continue
            snaps[lk] = await asyncio.to_thread(get_snapshot, list_key=lk)
        ignores = await asyncio.to_thread(count_ignores_bulk, list_keys=[str(s.get("list_key") or "") for s in subs])
    except Exception:
        # best-effort: allow UI to render without these enrichments
        logger.detail("hotlist snapshot/ignore enrich failed", exc_info=True)

    log_ok(logger, "获取热榜订阅列表成功")
    return {"builtins": get_builtin_lists(), "subscriptions": subs, "snapshots": snaps, "ignores": ignores}


@router.post("/admin/hotlist/add", response_class=JSONResponse)
async def admin_hotlist_add(request: Request, user: str = Depends(get_admin_user)) -> Dict[str, Any]:
    body = await request.json()
    chat_id = int(body.get("chat_id") or 0)
    if not chat_id:
        raise HTTPException(status_code=400, detail="BAD_REQUEST: missing chat_id")
    list_url = str(body.get("url") or body.get("list_url") or body.get("list_key") or "")
    mode = str(body.get("mode") or "incremental")
    filters = body.get("filters") if isinstance(body.get("filters"), dict) else None
    return await _uc.add_subscription(chat_id=chat_id, list_url=list_url, mode=mode, filters=filters)


@router.post("/admin/hotlist/delete", response_class=JSONResponse)
async def admin_hotlist_delete(request: Request, user: str = Depends(get_admin_user)) -> Dict[str, Any]:
    body = await request.json()
    chat_id = int(body.get("chat_id") or 0)
    list_key = str(body.get("list_key") or body.get("url") or "")
    if not chat_id or not list_key:
        raise HTTPException(status_code=400, detail="BAD_REQUEST")
    return await _uc.delete_subscription(chat_id=chat_id, list_key=list_key)


@router.post("/admin/hotlist/patch", response_class=JSONResponse)
async def admin_hotlist_patch(request: Request, user: str = Depends(get_admin_user)) -> Dict[str, Any]:
    body = await request.json()
    chat_id = int(body.get("chat_id") or 0)
    list_key = str(body.get("list_key") or "")
    patch = body.get("patch") if isinstance(body.get("patch"), dict) else {}
    if not chat_id or not list_key:
        raise HTTPException(status_code=400, detail="BAD_REQUEST")
    return await _uc.patch_subscription(chat_id=chat_id, list_key=list_key, patch=patch)


@router.post("/admin/hotlist/backfill_next", response_class=JSONResponse)
async def admin_hotlist_backfill_next(request: Request, user: str = Depends(get_admin_user)) -> Dict[str, Any]:
    body = await request.json()
    chat_id = int(body.get("chat_id") or 0)
    list_key = str(body.get("list_key") or "")
    if not chat_id or not list_key:
        raise HTTPException(status_code=400, detail="BAD_REQUEST")
    return await _uc.backfill_next(chat_id=chat_id, list_key=list_key)
