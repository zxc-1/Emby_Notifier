from __future__ import annotations

import asyncio
import json
import re
from typing import Any, Dict, List
from fastapi import status

from urllib.parse import urlparse

"""Admin routes: pages (admin home + recent)."""

import logging
from . import routes_base as _routes_base
from .view_models import build_dashboard_context
from services.pages.usecases import PagesUsecase
# --- explicit re-exports from .routes_base (replacing star import) ---
ADMIN_BOOL_KEYS = _routes_base.ADMIN_BOOL_KEYS
ADMIN_LIST_KEYS = _routes_base.ADMIN_LIST_KEYS
ADMIN_TEXT_KEYS = _routes_base.ADMIN_TEXT_KEYS
Depends = _routes_base.Depends
ENV_PATH = _routes_base.ENV_PATH



def _split_scheme_host(url: str) -> tuple[str, str]:
    url = (url or '').strip()
    if not url:
        return ('http', '')
    if '://' not in url:
        # treat as host[:port][/path]
        return ('http', url)
    p = urlparse(url)
    scheme = (p.scheme or 'http').lower()
    host = p.netloc
    # keep optional path for reverse proxies
    if p.path and p.path != '/':
        host = host + p.path
    return (scheme, host)

FORWARD_BOOL_KEYS = _routes_base.FORWARD_BOOL_KEYS
HTTPException = _routes_base.HTTPException
JSONResponse = _routes_base.JSONResponse
RedirectResponse = _routes_base.RedirectResponse
Request = _routes_base.Request
UI_PREFS_PATH = _routes_base.UI_PREFS_PATH
_apply_runtime_settings = _routes_base._apply_runtime_settings
_is_ui_inline_hint_text = _routes_base._is_ui_inline_hint_text
_mask_secret = _routes_base._mask_secret
dump_env_file = _routes_base.dump_env_file
generate_random_password = _routes_base.generate_random_password
get_admin_user = _routes_base.get_admin_user
get_settings = _routes_base.get_settings
get_app_info = _routes_base.get_app_info
hash_password = _routes_base.hash_password
is_legacy_hash = _routes_base.is_legacy_hash
load_admin_credentials = _routes_base.load_admin_credentials
load_admin_record = _routes_base.load_admin_record
load_env_file = _routes_base.load_env_file
load_json = _routes_base.load_json
log_fetch = _routes_base.log_fetch
log_ok = _routes_base.log_ok
log_run = _routes_base.log_run
logger = _routes_base.logger

_pages_uc = PagesUsecase()
reload_settings = _routes_base.reload_settings
# Standalone router for this module (included by admin.routes)
router = _routes_base.APIRouter()
save_admin_credentials = _routes_base.save_admin_credentials
save_json = _routes_base.save_json
templates = _routes_base.templates
verify_password = _routes_base.verify_password





@router.get("/admin/login")
async def admin_login_page(request: Request):
    """Render admin login page."""
    log_fetch(logger, "ui: render login page")
    flash = request.session.pop("flash", None)
    flash_json = json.dumps(flash, ensure_ascii=False) if flash else ""
    # If already logged in, go home.
    if request.session.get("admin_logged_in"):
        return RedirectResponse(url="/admin", status_code=status.HTTP_302_FOUND)
    return templates.TemplateResponse(
        "login.html",
        {
            "request": request,
            "flash_json": flash_json,
            "default_username": getattr(get_settings(), "ADMIN_USERNAME", "admin") or "admin",
            **get_app_info(request),
        },
    )


@router.get("/admin/logout")
async def admin_logout_page(request: Request):
    """Logout and redirect to login."""
    log_run(logger, "admin: logout")
    try:
        request.session.clear()
    except Exception:
        # best-effort
        request.session.pop("admin_logged_in", None)
        request.session.pop("must_change_password", None)
    return RedirectResponse(url="/admin/login", status_code=status.HTTP_302_FOUND)


@router.get("/admin/password")
async def admin_password_page(request: Request, user: str = Depends(get_admin_user)):
    """Render change password page."""
    log_fetch(logger, "ui: render password page")
    flash = request.session.pop("flash", None)
    flash_json = json.dumps(flash, ensure_ascii=False) if flash else ""
    must_change_password = bool(request.session.get("must_change_password", False))
    return templates.TemplateResponse(
        "password.html",
        {
            "request": request,
            "user": user,
            "must_change_password": must_change_password,
            "flash_json": flash_json,
            **get_app_info(request),
        },
    )


@router.get("/admin")
@router.get("/")
async def admin_page(request: Request):
    log_fetch(logger, "ui: render admin page")

    is_authed = bool(request.session.get("admin_logged_in"))
    if not is_authed:
        return RedirectResponse(url="/admin/login", status_code=status.HTTP_302_FOUND)

    flash = request.session.pop("flash", None)
    flash_json = json.dumps(flash, ensure_ascii=False) if flash else ""

    # Delegate heavy lifting to usecase (recent_store, admin record sync, dashboard context).
    ctx = await _pages_uc.build_admin_page_context(request=request)

    # Admin landing page uses the main dashboard template.
    # (There is no templates/pages/admin.html in this repo.)
    return templates.TemplateResponse(
        "dashboard.html",
        {
            "request": request,
            "flash_json": flash_json,
            "is_authed": True,
            # Keep compatibility: some templates reference `settings`.
            "settings": get_settings(),
            # Default hotlist preview (the page loads via API later).
            "hotlists": [],
            **get_app_info(request),
            **ctx,
        },
    )

@router.get("/admin/recent.json", response_class=JSONResponse)
async def admin_recent_json(
    request: Request,
    limit: int = 10,
    user: str = Depends(get_admin_user),
) -> Dict[str, Any]:
    """Recent items for dashboard polling.

    Prefer Emby recent items (with posters) when configured; fallback to recent_store.
    """
    return await _pages_uc.get_recent_json(request=request, limit=limit)

@router.get("/admin/settings")
async def admin_settings_page(request: Request, user: str = Depends(get_admin_user)):
    """设置页面 - Emby/Telegram/通知/高级配置"""
    log_fetch(logger, "ui: render settings page")
    
    cur_settings = get_settings()
    flash = request.session.pop("flash", None)
    flash_json = json.dumps(flash, ensure_ascii=False) if flash else ""
    
    return templates.TemplateResponse(
        "pages/admin_settings.html",
        {
            "request": request,
            "settings": cur_settings,
            "active_nav": "settings",
            "flash_json": flash_json,
            "is_authed": True,
            **get_app_info(request),
        },
    )


@router.get("/admin/forward")
async def admin_forward_page(request: Request, user: str = Depends(get_admin_user)):
    """联动设置页面 - MediaHelp 配置"""
    log_fetch(logger, "ui: render forward page")
    
    cur_settings = get_settings()
    flash = request.session.pop("flash", None)
    flash_json = json.dumps(flash, ensure_ascii=False) if flash else ""
    
    # 检查 MediaHelp 连接状态
    mediahelp_connected = False
    try:
        from forward_bridge import http_client as _mhc
        mediahelp_connected = bool(_mhc.have_token())
    except Exception:
        logger.detail("管理后台：检查 mediahelp connection 失败", exc_info=True)
    
    return templates.TemplateResponse(
        "pages/admin_forward.html",
        {
            "request": request,
            "settings": cur_settings,
            "active_nav": "forward",
            "flash_json": flash_json,
            "is_authed": True,
            "mediahelp_connected": mediahelp_connected,
            "cache_stats": {
                "total": 0,
                "today": 0,
                "last_update": "--",
            },
            **get_app_info(request),
        },
    )


@router.get("/admin/bot")
async def admin_bot_page(request: Request, user: str = Depends(get_admin_user)):
    """Bot 配置页面 - TG Bot 和 115 云盘"""
    log_fetch(logger, "ui: render bot page")
    
    cur_settings = get_settings()
    flash = request.session.pop("flash", None)
    flash_json = json.dumps(flash, ensure_ascii=False) if flash else ""
    
    # 检查 115 登录状态
    cloud115_logged_in = False
    try:
        cookie = getattr(cur_settings, "CLOUD115_COOKIE", "") or ""
        cloud115_logged_in = bool(cookie.strip())
    except Exception:
        logger.detail("管理后台：检查 cloud115 login 失败", exc_info=True)
    
    return templates.TemplateResponse(
        "pages/admin_bot.html",
        {
            "request": request,
            "settings": cur_settings,
            "active_nav": "bot",
            "flash_json": flash_json,
            "is_authed": True,
            "cloud115_logged_in": cloud115_logged_in,
            **get_app_info(request),
        },
    )


@router.get("/admin/tgbot")
async def admin_tgbot_page(request: Request, user: str = Depends(get_admin_user)):
    """TG Bot 配置页面"""
    log_fetch(logger, "ui: render tgbot page")
    
    cur_settings = get_settings()
    flash = request.session.pop("flash", None)
    flash_json = json.dumps(flash, ensure_ascii=False) if flash else ""
    
    # 检查 Bot 状态
    bot_configured = bool(getattr(cur_settings, "TG_BOT_TOKEN", ""))
    bot_mode = getattr(cur_settings, "TG_BOT_MODE", "polling") or "polling"
    
    return templates.TemplateResponse(
        "pages/admin_tgbot.html",
        {
            "request": request,
            "settings": cur_settings,
            "active_nav": "tgbot",
            "flash_json": flash_json,
            "is_authed": True,
            "bot_configured": bot_configured,
            "bot_mode": bot_mode,
            **get_app_info(request),
        },
    )


@router.get("/admin/login")
async def admin_login_page(request: Request):
    """登录页面"""
    log_fetch(logger, "ui: render login page")
    
    # 如果已登录，重定向到首页
    if request.session.get("admin_logged_in"):
        return RedirectResponse(url="/admin", status_code=status.HTTP_303_SEE_OTHER)
    
    return templates.TemplateResponse(
        "pages/admin_login.html",
        {
            "request": request,
        },
    )


@router.get("/admin/config")
async def admin_config_page(request: Request, user: str = Depends(get_admin_user)):
    """统一配置页面 - 合并 Settings/TG Bot/Forward 配置"""
    log_fetch(logger, "ui: render unified config page")
    
    cur_settings = get_settings()
    flash = request.session.pop("flash", None)
    flash_json = json.dumps(flash, ensure_ascii=False) if flash else ""
    
    return templates.TemplateResponse(
        "pages/admin_config.html",
        {
            "request": request,
            "settings": cur_settings,
            "active_nav": "config",
            "flash_json": flash_json,
            "is_authed": True,
            **get_app_info(request),
        },
    )