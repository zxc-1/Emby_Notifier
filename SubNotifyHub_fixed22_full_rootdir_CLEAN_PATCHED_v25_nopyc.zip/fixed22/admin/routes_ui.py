from __future__ import annotations

"""Admin routes: UI preferences API (thin)."""

from . import routes_base as _routes_base
from services.ui_prefs import get_ui_prefs_usecase

router = _routes_base.APIRouter()

HTTPException = _routes_base.HTTPException
Request = _routes_base.Request
JSONResponse = _routes_base.JSONResponse

logger = _routes_base.logger
log_fetch = _routes_base.log_fetch
log_run = _routes_base.log_run
log_ok = _routes_base.log_ok
get_admin_user = _routes_base.get_admin_user


@router.get("/api/ui_prefs", response_class=JSONResponse)
async def api_get_ui_prefs(request: Request):
    log_fetch(logger, "ui_prefs: get")
    uc = get_ui_prefs_usecase()
    prefs = await uc.get_prefs()
    return {"ok": True, "prefs": prefs}


@router.post("/api/ui_prefs", response_class=JSONResponse)
async def api_save_ui_prefs(request: Request):
    get_admin_user(request)
    log_run(logger, "ui_prefs: save")
    try:
        body = await request.json()
    except (ValueError, TypeError):
        logger.detail("ui_prefs: parse JSON body failed, using {}", exc_info=True)
        body = {}
    uc = get_ui_prefs_usecase()
    try:
        await uc.save_prefs(body)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except RuntimeError as e:
        raise HTTPException(status_code=500, detail=str(e))
    log_ok(logger, "ui_prefs: saved")
    return {"ok": True}


__all__ = ["router"]
