"""Hypothesis configuration (optional dev dependency).

This file is safe to import even when hypothesis is not installed."""

try:
    from hypothesis import settings, HealthCheck

    settings.register_profile(
        "default",
        suppress_health_check=[HealthCheck.function_scoped_fixture],
    )
    settings.load_profile("default")
except ModuleNotFoundError:  # pragma: no cover
    # Optional in CI/production images.
    pass
