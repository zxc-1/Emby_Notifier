from __future__ import annotations

"""HTTP error handling registration.

Centralizes all exception handlers to avoid duplicated registration and schema drift.

JSON response schema (standardized):

    {
      "success": false,
      "data": null,
      "error": {
        "code": "ERROR_CODE",
        "message": "...",
        "details": {...}?
      },
      "timestamp": "...",
      "trace_id": "..."
    }

The trace id is also mirrored to header ``X-Trace-Id``.
"""

from core.logging import get_biz_logger
import uuid
from typing import Any, Optional

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse, RedirectResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from api.responses import error_response, ErrorCodes
from core.exceptions.base import AppException
from core.logging import is_user_path, set_kind, set_request, set_trace_id
from domain.errors import ConflictError, NotFoundError, ValidationError

biz = get_biz_logger(__name__)


def _get_trace_id(request: Request) -> str:
    try:
        return str(
            getattr(getattr(request, "state", None), "trace_id", "")
            or request.headers.get("X-Trace-Id")
            or ""
        )
    except (AttributeError, TypeError) as e:
        biz.detail(f"trace_id 读取失败（已忽略） - 原因={type(e).__name__}")
        return ""


def register_exception_handlers(*, app: FastAPI, settings: Any) -> None:
    """Register all exception handlers on *app*.

    This function should be called exactly once during app creation.
    """

    @app.exception_handler(ValidationError)
    async def _domain_validation_handler(request: Request, exc: ValidationError):
        trace_id = _get_trace_id(request) or uuid.uuid4().hex[:12]
        with set_trace_id(trace_id), set_kind("user" if is_user_path(request.url.path) else ""), set_request(
            request.method, request.url.path
        ):
            biz.warning("请求参数校验失败", stage="http_validation", error=str(exc)[:300])
        return error_response(
            code=ErrorCodes.VALIDATION_ERROR,
            message=str(exc),
            trace_id=trace_id,
            status_code=400,
        )

    @app.exception_handler(NotFoundError)
    async def _domain_not_found_handler(request: Request, exc: NotFoundError):
        trace_id = _get_trace_id(request) or uuid.uuid4().hex[:12]
        return error_response(
            code=ErrorCodes.NOT_FOUND,
            message=str(exc),
            trace_id=trace_id,
            status_code=404,
        )

    @app.exception_handler(ConflictError)
    async def _domain_conflict_handler(request: Request, exc: ConflictError):
        trace_id = _get_trace_id(request) or uuid.uuid4().hex[:12]
        return error_response(
            code=ErrorCodes.CONFLICT,
            message=str(exc),
            trace_id=trace_id,
            status_code=409,
        )

    def _map_app_exception(exc: AppException) -> tuple[str, int, str]:
        category = str(getattr(exc, "category", "unknown") or "unknown")
        message = str(exc)
        code = ErrorCodes.INTERNAL_ERROR
        status_code = 500
        if category == "validation":
            code, status_code = ErrorCodes.VALIDATION_ERROR, 400
        elif category == "permission":
            code, status_code = ErrorCodes.FORBIDDEN, 403
        elif category == "configuration":
            code, status_code = ErrorCodes.CONFIG_ERROR, 500
        elif category in ("temporary", "network", "external_service"):
            code, status_code = ErrorCodes.TEMPORARY_ERROR, 503
        elif category == "database":
            code, status_code = ErrorCodes.INTERNAL_ERROR, 500

        error_code = getattr(exc, "error_code", None)
        if error_code:
            code = str(error_code)
        override_status = getattr(exc, "status_code", None)
        if override_status is not None:
            try:
                status_code = int(override_status)
            except (TypeError, ValueError):
                pass
        return code, status_code, message

    @app.exception_handler(AppException)
    async def _app_exception_handler(request: Request, exc: AppException):
        trace_id = _get_trace_id(request) or uuid.uuid4().hex[:12]
        code, status_code, message = _map_app_exception(exc)
        with set_trace_id(trace_id), set_kind("user" if is_user_path(request.url.path) else ""), set_request(
            request.method, request.url.path
        ):
            if status_code >= 500:
                biz.fail(
                    f"❌ 应用异常：{message[:300]}",
                    trace_id=trace_id,
                    error_code=code,
                    http_status=status_code,
                )
            else:
                biz.warning(
                    f"⚠️ 请求异常：{message[:300]}",
                    trace_id=trace_id,
                    error_code=code,
                    http_status=status_code,
                )
        return error_response(
            code=code,
            message=message,
            trace_id=trace_id,
            status_code=status_code,
        )

    @app.exception_handler(StarletteHTTPException)
    async def _http_exception_handler(request: Request, exc: StarletteHTTPException):
        # Redirect browser form submits to /admin on 401 for HTML accepts.
        try:
            accept = str(request.headers.get("accept", "") or "")
        except (AttributeError, TypeError) as e:
            biz.detail(f"Accept 头读取失败（已忽略） - 原因={type(e).__name__}")
            accept = ""

        if exc.status_code == 401 and str(request.url.path).startswith("/admin") and "text/html" in accept:
            try:
                request.session["flash"] = {
                    "title": "未登录或登录已过期",
                    "body": "请重新登录后再保存/操作。",
                }
            except Exception:
                biz.detail("异常已抑制", exc_info=True)
            return RedirectResponse(url="/admin", status_code=303)

        trace_id = _get_trace_id(request) or uuid.uuid4().hex[:12]
        return error_response(
            code=ErrorCodes.HTTP_ERROR,
            message=str(exc.detail),
            trace_id=trace_id,
            status_code=int(exc.status_code),
        )

    @app.exception_handler(Exception)
    async def _unhandled_exception_handler(request: Request, exc: Exception):
        """Catch-all exception handler that returns trace_id for support correlation."""
        trace_id = _get_trace_id(request)
        if not trace_id:
            try:
                trace_id = uuid.uuid4().hex[:12]
            except (AttributeError, ValueError) as e:
                biz.detail(f"trace_id 生成失败（已忽略） - 原因={type(e).__name__}")
                trace_id = ""

        with set_trace_id(trace_id), set_kind("user" if is_user_path(request.url.path) else ""), set_request(
            request.method, request.url.path
        ):
            biz.exception(
                "❌ 未处理异常",
                trace_id=trace_id,
                path=request.url.path,
                method=request.method,
            )

        debug = False
        try:
            debug = bool(getattr(settings, "DEBUG_ENABLE_DEBUG_API", False))
        except (AttributeError, TypeError) as e:
            biz.detail(f"调试模式读取失败（已忽略） - 原因={type(e).__name__}")
            debug = False

        details: dict[str, Any] | None = None
        if debug:
            details = {"error_type": type(exc).__name__, "error": str(exc)[:500]}

        return error_response(
            code=ErrorCodes.INTERNAL_ERROR,
            message="Internal server error",
            trace_id=trace_id,
            details=details,
            status_code=500,
        )
