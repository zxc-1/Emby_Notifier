from __future__ import annotations

import asyncio
import logging
from core.logging import get_biz_logger_adapter
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from typing import Any, Optional

from fastapi import FastAPI

from bootstrap.bootstrap_preflight import run_preflight_checks
from core.logging import log_ok, log_run
from core.task_registry import TaskRegistry
from settings.runtime import get_settings
from core.http import close_http_client, create_http_client
from notifier.mediahelp_notify import set_enqueue_func

from bootstrap.bootstrap_wiring import (
    build_context_and_expose,
    build_handler,
    build_notifier_chain,
    build_on_sent,
    init_admin_credentials_or_raise,
    init_deduper,
    init_persistence,
    start_worker,
)

from core.roles import is_worker_role


logger = get_biz_logger_adapter(__name__)


def build_lifespan(
    *,
    settings: Any,
    poster_cache_dir,
    recent_store_path,
    store_max: int,
    display_max: int,
    api_max: int,
):
    @asynccontextmanager
    async def lifespan(app: FastAPI):
        # Startup
        log_run(logger, "startup", step="bootstrap", phase="start")
        log_run(logger, "http_client: init")
        await create_http_client()

        # Init MediaHelp runtime (lazy token restore) after logging is ready
        try:
            from forward_bridge.http_client import init_mediahelp_runtime

            await asyncio.to_thread(init_mediahelp_runtime, load_disk=True, load_settings=True)
        except Exception:
            logger.detail("mediahelp runtime init 失败", exc_info=True)

        log_ok(logger, "http_client: ready")

        # Build info metric for easier debugging across deployments.
        try:
            from core.metrics import metrics

            metrics.set_gauge("app_build_info", 1.0, labels={"version": str(settings.APP_VERSION)})
        except (ImportError, AttributeError, TypeError) as e:
            logger.detail(f"指标初始化失败（已忽略） - 版本={getattr(settings, 'APP_VERSION', 'unknown')}, 原因={type(e).__name__}")

        # Self-check: ensure critical modules import cleanly.
        try:
            from core.selfcheck import run_selfcheck

            run_selfcheck()
            log_ok(logger, "bootstrap: selfcheck")
        except Exception:
            logger.fail("启动：selfcheck 失败", exc_info=True)
            raise

        # Preflight checks
        try:
            run_preflight_checks(
                app=app,
                settings=settings,
                poster_cache_dir=poster_cache_dir,
                recent_store_path=recent_store_path,
            )
            log_ok(logger, "preflight")
        except Exception:
            logger.fail("preflight 失败", exc_info=True)
            raise

        poster_cache, recent_store, history = await init_persistence(
            app=app,
            settings=settings,
            poster_cache_dir=poster_cache_dir,
            recent_store_path=recent_store_path,
            store_max=store_max,
            display_max=display_max,
            api_max=api_max,
        )

        # Admin credentials (critical)
        init_admin_credentials_or_raise(app=app, settings=settings)

        # Deduper
        deduper = init_deduper(app=app, settings=settings)

        # Health counters helpers
        def _push_recent_notify() -> None:
            try:
                app.state._recent_notify_times.append(datetime.now(timezone.utc).timestamp())
            except Exception:
                logger.fail("❌ 发生未预期异常", exc_info=True)

        def _push_recent_notify_attempt() -> None:
            try:
                app.state._recent_notify_attempt_times.append(datetime.now(timezone.utc).timestamp())
            except Exception:
                logger.fail("❌ 发生未预期异常", exc_info=True)

        on_sent = build_on_sent(
            app=app,
            recent_store=recent_store,
            history=history,
            push_notify=_push_recent_notify,
        )

        # Background tasks (aggregator flush etc.)
        task_registry = TaskRegistry()
        app.state.task_registry = task_registry

        # Services: unify lifecycle for background loops (P2-7).
        from core.services import PosterCacheEvictService, ServiceManager

        svc_mgr = ServiceManager()
        app.state.service_manager = svc_mgr

        svc_mgr.add(PosterCacheEvictService(poster_cache=poster_cache, registry=task_registry))

        # Dashboard health (API + Worker): real connectivity status for UI.
        try:
            from core.services import DashboardHealthService
            svc_mgr.add(DashboardHealthService(app=app, registry=task_registry, interval_sec=60.0))
        except Exception:
            logger.detail("dashboard health service init 失败（已忽略）", exc_info=True)


        notifier = build_notifier_chain(app=app, settings=settings, task_registry=task_registry, on_sent=on_sent)
        handler = build_handler(app=app, push_attempt=_push_recent_notify_attempt)

        worker = await start_worker(app=app, handler=handler)

        # Central runtime context (preferred)
        build_context_and_expose(
            app=app,
            poster_cache=poster_cache,
            recent_store=recent_store,
            deduper=deduper,
            notifier=notifier,
            worker=worker,
            handler=handler,
            on_sent=on_sent,
            display_max=display_max,
            history=history,
        )

        # Plugin startup hooks (P1).
        try:
            reg = getattr(app.state, 'plugin_registry', None)
            if reg is not None:
                await reg.run_startup(app=app, settings=settings)
        except Exception:
            # Strictness is controlled by CONFIG_STRICT during plugin load; do not crash here.
            logger.fail('plugin startup hooks 失败', exc_info=True)

        # Forward bridge uses worker.enqueue
        set_enqueue_func(worker.enqueue)

        # Background loops are started only in worker role.
        if is_worker_role():
            from core.services import Cloud115HealthService, HotlistService
            from tg_bot.services import TgPollingService

            # Cloud115 health checker uses TelegramCaller injection (ports) to
            # avoid core->integrations dependency.
            tg_health = None
            try:
                from integrations.telegram_client import TelegramBotCaller

                token = str(getattr(get_settings(), "TG_BOT_TOKEN", "") or "").strip()
                if token:
                    tg_health = TelegramBotCaller(token=token, timeout=20.0)
            except (ImportError, AttributeError, TypeError, ValueError) as e:
                logger.detail(f"Telegram健康检查客户端初始化失败（已忽略） - 原因={type(e).__name__}")
                tg_health = None

            svc_mgr.add(TgPollingService(registry=task_registry))
            svc_mgr.add(HotlistService(registry=task_registry))
            svc_mgr.add(Cloud115HealthService(app=app, registry=task_registry, tg=tg_health))

            # Crawler module (PostgreSQL-backed). This is intentionally isolated
            # from the main SQLite stores so it can be enabled/disabled safely.
            #
            # IMPORTANT: Use crawler.config as the single source of truth.
            # Do not read ENV here with a different default, otherwise users can
            # see "默认开启" in UI but crawler never starts.
            try:
                from crawler.config import load_crawler_config

                cfg = load_crawler_config()
                if cfg.enabled:
                    from crawler.service import CrawlerService

                    svc_mgr.add(CrawlerService(app=app, registry=task_registry))
                    log_ok(logger, "crawler", step="bootstrap", phase="enabled")
                else:
                    log_ok(logger, "crawler", step="bootstrap", phase="disabled")
            except Exception:
                logger.fail("Crawler：初始化失败（已忽略）", exc_info=True)

            # TG Bot inbound: webhook mode bootstrap (one-shot, not a loop)
            try:
                cur = get_settings()
                mode = str(getattr(cur, "TG_BOT_MODE", "polling") or "polling").strip().lower()
                if mode == "webhook":
                    from tg_bot.infra.webhook_setup import ensure_webhook

                    await ensure_webhook()
            except Exception:
                logger.fail("TG Webhook：ensure_webhook 失败", exc_info=True)
        else:
            log_ok(logger, "bg_loops", step="bootstrap", phase="skipped", detail="APP_ROLE=api")

        # Start services best-effort.
        try:
            await svc_mgr.start_all(continue_on_error=True)
        except Exception:
            logger.detail("服务管理：启动全部 失败", exc_info=True)

        try:
            log_ok(logger, "startup", step="bootstrap", phase="done")
            yield
        finally:
            log_run(logger, "shutdown", step="bootstrap", phase="start")

            # Plugin shutdown hooks (P1).
            try:
                reg = getattr(app.state, 'plugin_registry', None)
                if reg is not None:
                    await reg.run_shutdown(app=app, settings=settings)
            except Exception:
                logger.fail('plugin shutdown hooks 失败', exc_info=True)

            # Stop managed services early.
            try:
                sm = getattr(app.state, "service_manager", None)
                if sm is not None:
                    await sm.stop_all()
            except Exception:
                logger.detail("服务管理：停止全部 失败", exc_info=True)

            # Prevent new recent writes during shutdown.
            try:
                recent_store.stop_accepting()
            except Exception:
                logger.detail("最近入库记录：stop_accepting 失败", exc_info=True)

            # Stop worker early.
            worker_final: Optional[Any] = getattr(app.state, "notifier_worker", None)
            if worker_final:
                try:
                    await worker_final.stop()
                except Exception:
                    logger.fail("日志：Failed to stop worker during shutdown", exc_info=True)

            # Stop background tasks.
            try:
                tr = getattr(app.state, "task_registry", None)
                if tr is not None:
                    await tr.shutdown(timeout=25)
            except Exception:
                logger.detail("任务注册表：shutdown 失败", exc_info=True)

            # Close recent store.
            try:
                await recent_store.close()
            except Exception:
                logger.detail("最近入库记录：关闭 失败", exc_info=True)

            await close_http_client()

            # Close shared MediaHelp http client (forward_bridge)
            try:
                from forward_bridge.http_client import close_client as close_mediahelp_client

                await close_mediahelp_client()
            except Exception:
                logger.detail("mediahelp client close 失败", exc_info=True)

            # Close database connection pools
            try:
                from core.db.pool_manager import close_all_pools, close_all_async_pools

                close_all_pools(timeout=5.0)
                await close_all_async_pools(timeout=5.0)
                log_ok(logger, "db_pools: closed")
            except Exception:
                logger.detail("db pools close 失败", exc_info=True)

            log_ok(logger, "shutdown", step="bootstrap", phase="done")

    return lifespan