from __future__ import annotations

"""Request logging + metrics middleware.

Keep middleware construction out of bootstrap_app_factory to reduce noise and
make it easier to reuse in alternate entrypoints.
"""

import logging
import time
from core.logging import get_biz_logger_adapter
import uuid
from datetime import datetime, timezone

from fastapi import FastAPI, Request

from core.logging import get_biz_logger
from core.logging import is_user_path, set_kind, set_request, set_trace_id
from core.metrics import metrics
from core.runtime_ctx import bind_ctx, reset_ctx
from settings.runtime import bind_settings, reset_settings
from core.suppress import suppress

logger = get_biz_logger_adapter(__name__)
biz = get_biz_logger(__name__)


def add_request_logging_middleware(*, app: FastAPI) -> None:
    @app.middleware("http")
    async def _request_logger(request: Request, call_next):
        start = datetime.now(timezone.utc)
        start_perf = time.perf_counter()
        kind = "user" if is_user_path(request.url.path) else ""
        trace_id = request.headers.get("X-Trace-Id") or uuid.uuid4().hex[:12]
        try:
            request.state.trace_id = trace_id
        except (AttributeError, RuntimeError) as e:
            logger.detail(f"请求 trace_id 设置失败（已忽略） - trace_id={trace_id}, 原因={type(e).__name__}")

        # Bind per-request context to ContextVars (best-effort).
        tok_s = None
        tok_c = None
        try:
            tok_s = bind_settings(getattr(request.app.state, "settings", None))
        except (AttributeError, TypeError, RuntimeError) as e:
            logger.detail(f"请求设置绑定失败（已忽略） - trace_id={trace_id}, 原因={type(e).__name__}")
            tok_s = None
        try:
            tok_c = bind_ctx(getattr(request.app.state, "ctx", None))
        except (AttributeError, TypeError, RuntimeError) as e:
            logger.detail(f"请求上下文绑定失败（已忽略） - trace_id={trace_id}, 原因={type(e).__name__}")
            tok_c = None

        try:
            # Derive a stable route template for grouping/metrics labels.
            try:
                r = request.scope.get("route")
                route_tmpl = str(getattr(r, "path", None) or request.url.path)
            except Exception:
                route_tmpl = request.url.path

            with set_trace_id(trace_id), set_kind(kind), set_request(request.method, request.url.path):
                # For user-triggered HTTP requests, wrap the whole flow in a BizLog group.
                grp = (
                    biz.entry(
                        domain="HTTP",
                        action=str(request.method or "").upper(),
                        group_title=f"HTTP {request.method} {route_tmpl}",
                        method=request.method,
                        path=route_tmpl,
                        trace_id=trace_id,
                    )
                    if kind == "user"
                    else None
                )

                async def _run_request() -> object:
                    """Run request + metrics + optional business log under a (possibly None) group."""

                    try:
                        if grp is None:
                            response = await call_next(request)
                        else:
                            with grp:
                                response = await call_next(request)
                                # NOTE: keep group open until after status/duration lines.

                                dur_ms = int((time.perf_counter() - start_perf) * 1000)
                                status = getattr(response, "status_code", 500)
                                try:
                                    labels = {"method": request.method, "path": route_tmpl, "status": str(status)}
                                    metrics.inc("http_requests", labels=labels)
                                    metrics.observe("http_request_duration_ms", float(dur_ms), labels=labels)
                                except Exception as e:
                                    suppress(
                                        site="bootstrap/request_logging:metrics_user",
                                        exc=e,
                                        logger=logger,
                                        fallback=None,
                                    )
                                try:
                                    response.headers["X-Trace-Id"] = trace_id
                                except Exception as e:
                                    suppress(
                                        site="bootstrap/request_logging:set_trace_header_user",
                                        exc=e,
                                        logger=logger,
                                        fallback=None,
                                    )
                                # Business conclusion line (rendered by group exit).
                                try:
                                    st = int(status)
                                except Exception:
                                    st = 500
                                if st >= 500:
                                    biz.set_result('fail', 'HTTP 响应', status=st, duration_ms=dur_ms, path=route_tmpl)
                                elif st >= 400:
                                    biz.set_result('warn', 'HTTP 响应', status=st, duration_ms=dur_ms, path=route_tmpl)
                                else:
                                    biz.set_result('ok', 'HTTP 响应', status=st, duration_ms=dur_ms, path=route_tmpl)
                                return response

                        # Non-user request path (no group)
                        dur_ms = int((time.perf_counter() - start_perf) * 1000)
                        status = getattr(response, "status_code", 500)
                        try:
                            labels = {"method": request.method, "path": route_tmpl, "status": str(status)}
                            metrics.inc("http_requests", labels=labels)
                            metrics.observe("http_request_duration_ms", float(dur_ms), labels=labels)
                        except (ValueError, TypeError, AttributeError) as e:
                            logger.detail(f"HTTP 请求指标记录失败（已忽略） - path={route_tmpl}, 原因={type(e).__name__}")
                        try:
                            response.headers["X-Trace-Id"] = trace_id
                        except (AttributeError, TypeError) as e:
                            logger.detail(f"HTTP 响应头设置失败（已忽略） - trace_id={trace_id}, 原因={type(e).__name__}")
                        return response

                    except Exception:
                        dur_ms = int((time.perf_counter() - start_perf) * 1000)
                        try:
                            labels = {"method": request.method, "path": route_tmpl, "status": "500"}
                            metrics.inc("http_requests", labels=labels)
                            metrics.observe("http_request_duration_ms", float(dur_ms), labels=labels)
                        except Exception as e:
                            suppress(
                                site="bootstrap/request_logging:metrics_on_crash",
                                exc=e,
                                logger=logger,
                                fallback=None,
                            )
                        # IMPORTANT: do NOT pass positional args here.
                        # Positional args trigger stdlib logging's `%` formatting which can
                        # raise TypeError when msg has no placeholders, hiding the real error.
                        logger.fail(
                            "❌ 请求处理崩溃（已记录异常）",
                            path=request.url.path,
                            dur_ms=dur_ms,
                            exc_info=True,
                        )
                        raise

                response = await _run_request()
                return response
        finally:
            if tok_c is not None:
                reset_ctx(tok_c)
            if tok_s is not None:
                reset_settings(tok_s)
