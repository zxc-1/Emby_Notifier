from __future__ import annotations

from core.logging import get_biz_logger
import os
import secrets
import time
from pathlib import Path

from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from starlette.types import Scope
from starlette.middleware.sessions import SessionMiddleware

from admin.routes import router as admin_router
from api.router import build_api_router
from bootstrap.bootstrap_lifespan import build_lifespan
from bootstrap.bootstrap_preflight import compute_runtime_paths
from core.env_utils import env_int
from core.logging import init_logging, log_ok, log_run
from core.plugins import load_plugins
from core.roles import is_api_role, is_worker_role
from settings.runtime import get_settings, set_settings
from ports.settings_provider import set_settings_provider

from bootstrap.http_errors import register_exception_handlers
from bootstrap.request_logging import add_request_logging_middleware
from core.middleware.response_envelope import add_response_envelope_middleware
from core.legacy_migrations import migrate_env_local_to_env



biz = get_biz_logger(__name__)


class NoCacheStaticFiles(StaticFiles):
    """StaticFiles with aggressive no-cache headers.

    Some browsers (especially iOS Safari / in-app webviews) are extremely
    aggressive in caching HTML fetched from a static mount like /templates.
    This breaks "I replaced the package but UI didn't change".
    """

    async def get_response(self, path: str, scope: Scope):
        resp = await super().get_response(path, scope)
        if resp.status_code == 200:
            resp.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
            resp.headers["Pragma"] = "no-cache"
            resp.headers["Expires"] = "0"
        return resp


def _get_or_create_admin_session_secret() -> str:
    """Return a stable, strong secret for SessionMiddleware."""
    s = get_settings()
    if getattr(s, "ADMIN_SESSION_SECRET", None):
        return str(s.ADMIN_SESSION_SECRET)

    # bootstrap-only rescue switch: keep getenv here so session secret path can be overridden even if settings/env wiring is broken
    secret_path = Path(os.getenv("ADMIN_SESSION_SECRET_PATH", "/data/.admin_session_secret"))

    def _read_existing() -> str | None:
        try:
            if secret_path.exists():
                raw = secret_path.read_text(encoding="utf-8").strip()
                if raw:
                    return raw
        except Exception:
            biz.detail("启动：read admin session secret 失败", exc_info=True)
        return None

    existing = _read_existing()
    if existing:
        try:
            os.chmod(secret_path, 0o600)
        except (OSError, AttributeError) as e:
            biz.detail(f"管理员会话密钥文件权限设置失败（已忽略） - path={secret_path}, 原因={type(e).__name__}")
        return existing

    # Create once, atomically, to avoid multi-worker races.
    new_secret = secrets.token_urlsafe(48)
    try:
        secret_path.parent.mkdir(parents=True, exist_ok=True)
        try:
            with secret_path.open("x", encoding="utf-8") as f:
                f.write(new_secret)
                f.write("\n")
            try:
                os.chmod(secret_path, 0o600)
            except (OSError, AttributeError) as e:
                biz.detail(f"管理员会话密钥文件权限设置失败（已忽略） - path={secret_path}, 原因={type(e).__name__}")
            return new_secret
        except FileExistsError:
            for _ in range(5):
                v = _read_existing()
                if v:
                    return v
                time.sleep(0.05)
    except Exception:
        biz.detail("启动：写入 admin session secret 失败", exc_info=True)
    return new_secret


def create_app() -> FastAPI:
    """Create the FastAPI app (logging, wiring, routers, lifespan)."""

    # Backward-compat: v1.5.x used ENV_LOCAL_PATH (.env.local). v1.6.x uses a
    # single ENV_PATH (.env). Migrate legacy keys so upgrades don't look like a
    # "fresh install".
    migrate_env_local_to_env()

    s = get_settings()
    # Explicitly bind the singleton instance so all modules share the same object
    # (and tests can inject a Settings instance via set_settings()).
    set_settings(s)
    # Bind settings provider port (P1): deeper layers depend on ports.settings_provider.
    set_settings_provider(get_settings)
    init_logging(s.LOG_LEVEL)

    # Forward bridge (optional)
    forward_app_local = None
    try:
        from forward_bridge.main import app as _forward_app

        forward_app_local = _forward_app
        log_ok(biz, "forward_bridge: import ok")
    except Exception:
        biz.exception("forward_bridge: import failed (forward disabled)")
        forward_app_local = None

    log_run(biz, "bootstrap: create_app")
    try:
        role = "all" if (is_worker_role() and is_api_role()) else ("worker" if is_worker_role() else "api")
    except (AttributeError, TypeError) as e:
        biz.detail(f"应用角色判断失败，使用默认值 - 原因={type(e).__name__}")
        role = "api"
    log_run(biz, f"app_role={role}")

    base_dir = Path(__file__).resolve().parents[1]

    poster_cache_dir, recent_store_path, _ = compute_runtime_paths()

    # Recent entries limits
    store_max = env_int("RECENT_ENTRIES_STORE_MAX", 50)
    display_max = env_int("RECENT_ENTRIES_DISPLAY_MAX", 12)
    api_max = env_int("RECENT_ENTRIES_API_MAX", store_max)

    lifespan = build_lifespan(
        settings=s,
        poster_cache_dir=poster_cache_dir,
        recent_store_path=recent_store_path,
        store_max=store_max,
        display_max=display_max,
        api_max=api_max,
    )

    app = FastAPI(title=s.APP_NAME, version=s.APP_VERSION, lifespan=lifespan)
    # Make Settings discoverable for dependency injection / debugging.
    app.state.settings = s

    # Plugin registry: plugins can add routers and lifecycle hooks.
    from core.plugins import PluginRegistry

    plugin_registry = PluginRegistry()
    app.state.plugin_registry = plugin_registry

    # Load optional plugins (registry extensions, extra routes, etc.)
    loaded_plugins = []
    try:
        loaded_plugins = load_plugins(s, registry=plugin_registry, app=app)
    except Exception:
        # Do not silently swallow: plugin failures are a common "隐形 bug" source.
        biz.exception("plugin load failed")
        if getattr(s, "CONFIG_STRICT", False):
            raise
    app.state.loaded_plugins = loaded_plugins

    # Consistent error responses + safe trace_id propagation
    register_exception_handlers(app=app, settings=s)

    # Request logging + metrics + ContextVar binding
    add_request_logging_middleware(app=app)

    # Consistent API response envelope for /admin + /api
    add_response_envelope_middleware(app)

    # Split deployment:

    if is_api_role():
        app.add_middleware(
            SessionMiddleware,
            secret_key=_get_or_create_admin_session_secret(),
            session_cookie=str(getattr(s, "ADMIN_SESSION_COOKIE_NAME", "emby_admin_session") or "emby_admin_session"),
            max_age=int(getattr(s, "ADMIN_SESSION_MAX_AGE_SEC", 7 * 24 * 3600) or (7 * 24 * 3600)),
            same_site=str(getattr(s, "ADMIN_SESSION_SAMESITE", "lax") or "lax"),
            https_only=bool(getattr(s, "ADMIN_SESSION_HTTPS_ONLY", True)),
        )

        log_run(biz, "mount_static", step="mount_static", phase="start")
        app.mount("/static", StaticFiles(directory=str(base_dir / "static")), name="static")
        # /templates serves HTML fragments for the admin UI. Force no-cache to
        # avoid iOS/webview stale HTML after upgrades.
        app.mount("/templates", NoCacheStaticFiles(directory=str(base_dir / "templates")), name="templates")
        log_ok(biz, "mount_static", step="mount_static", phase="done")

        # Poster cache mount (robust)
        try:
            poster_cache_dir.mkdir(parents=True, exist_ok=True)
        except Exception:
            biz.warning(f"⚠️ 海报缓存目录不可用（跳过严格检查）", 目录=str(poster_cache_dir), exc_info=True)
        log_run(biz, "mount_poster_cache", step="mount_poster_cache", phase="start")
        app.mount("/poster_cache", StaticFiles(directory=str(poster_cache_dir), check_dir=False), name="poster_cache")
        log_ok(biz, "mount_poster_cache", step="mount_poster_cache", phase="done")

        if forward_app_local is not None:
            log_run(biz, "mount_forward", step="mount_forward", phase="start")
            app.mount("/forward", forward_app_local)
            log_ok(biz, "mount_forward", step="mount_forward", phase="done")

        log_run(biz, "router_admin", step="router_admin", phase="start")
        app.include_router(admin_router)
        log_ok(biz, "router_admin", step="router_admin", phase="done")
        log_run(biz, "router_api", step="router_api", phase="start")
        app.include_router(build_api_router())
        log_ok(biz, "router_api", step="router_api", phase="done")

        # Include routers contributed by plugins (API role only by default).
        # Add these AFTER core/admin routers so built-in routes take precedence.
        for spec in getattr(plugin_registry, "routers", []):
            try:
                if getattr(spec, "api_only", True) is False or is_api_role():
                    app.include_router(spec.router, **(spec.kwargs or {}))
                    biz.ok(f"✅ 插件路由已加载", 前缀=getattr(spec.router, "prefix", ""))
            except Exception:
                biz.exception("plugin router include failed")
    else:
        if forward_app_local is not None:
            app.mount("/forward", forward_app_local)
        log_ok(biz, "router", step="router", phase="skipped", detail="APP_ROLE=worker")

        # In worker-only role we avoid exposing extra HTTP endpoints by default.
        # Plugins can override via registry.add_router(..., api_only=False).
        for spec in getattr(plugin_registry, "routers", []):
            try:
                if getattr(spec, "api_only", True) is False:
                    app.include_router(spec.router, **(spec.kwargs or {}))
                    biz.ok(f"✅ 插件路由已加载（worker）", 前缀=getattr(spec.router, "prefix", ""))
            except Exception:
                biz.exception("plugin router include failed")

    return app
