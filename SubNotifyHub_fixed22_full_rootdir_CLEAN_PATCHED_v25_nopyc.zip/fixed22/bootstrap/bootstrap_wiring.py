from __future__ import annotations

from core.exceptions.base import ConfigurationError

import asyncio
import os
from core.env_utils import env_str
from collections import deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional, Tuple

from core.context import AppContext
from core.logging import get_biz_logger, get_biz_logger_adapter, log_ok, log_run, log_fetch
from core.cache import PosterCache
from application.recent_entries import RecentEntriesConfig, RecentEntriesStore
from core.state_compat import expose_ctx
from core.task_registry import TaskRegistry

from notifier.dedup import Deduper
from notifier.hooked_notifier import HookedNotifier
from notifier.models import NotificationContent
from notifier.notifiers.base import DummyNotifier, Notifier
from notifier.notifier_factory import build_base_notifier, build_notifier
from notifier.notifiers.registry import NotifierRegistry, register_builtins
from core.admin_auth import (
    generate_random_password,
    hash_password,
    load_admin_credentials,
    save_admin_credentials,
)
from notifier.services import process_emby_item
from notifier.worker import NotificationWorker
from core.media_identity import normalize_event


biz = get_biz_logger(__name__)
logger = get_biz_logger_adapter(__name__)


async def init_persistence(
    *,
    app: Any,
    settings: Any,
    poster_cache_dir: Path,
    recent_store_path: Path,
    store_max: int,
    display_max: int,
    api_max: int,
) -> Tuple[PosterCache, RecentEntriesStore, Optional[deque]]:
    poster_cache = PosterCache(poster_cache_dir)
    log_run(biz, "poster_cache: evict_if_needed")
    await asyncio.to_thread(poster_cache.evict_if_needed)
    log_ok(biz, "poster_cache: ready")

    recent_cfg = RecentEntriesConfig(store_max=store_max, display_max=display_max, api_max=api_max)
    recent_store = RecentEntriesStore(recent_store_path, poster_cache, recent_cfg)
    log_run(biz, "recent_entries: load")
    await recent_store.load()
    log_ok(biz, "recent_entries: ready")

    # Debug history (optional)
    history: Optional[deque] = None
    try:
        if settings.DEBUG_ENABLE_DEBUG_API:
            size_raw = getattr(settings, "DEBUG_NOTIFICATION_HISTORY_SIZE", None)
            try:
                size = int(size_raw) if size_raw is not None else 100
            except (ValueError, TypeError) as e:
                logger.detail(f"历史大小转换失败（使用默认值 100） - size_raw={size_raw}, 原因={type(e).__name__}")
                size = 100
            if size > 0:
                history = deque(maxlen=size)
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"调试历史初始化失败（已忽略） - 原因={type(e).__name__}")
        history = None


    return poster_cache, recent_store, history


def _register_share_resolver_repo_best_effort() -> Any:
    """Register share resolver repo adapter (tg_bot storage) if available.

    This keeps application layer decoupled from tg_bot.storage.
    """

    try:
        from tg_bot.infra.share_resolver_repo import register_default_share_resolver_repo

        return register_default_share_resolver_repo()
    except Exception:
        logger.detail("分享解析：register 失败 (ignored)", exc_info=True)
        return None


def init_admin_credentials_or_raise(*, app: Any, settings: Any) -> None:
    """Initialize admin creds on first run.

    If credentials cannot be read/created (e.g., /data not writable), admin UI is unusable.
    Fail-fast so health isn't misleading.
    """

    try:
        creds = load_admin_credentials(settings)
        if creds is None:
            log_run(biz, "admin: init credentials")
            pw = env_str('ADMIN_INITIAL_PASSWORD', 'admin').strip() or 'admin'
            save_admin_credentials(
                settings.ADMIN_USERNAME,
                hash_password(pw),
                settings=settings,
                must_change_password=True,
            )
            biz.ok(f"✅ 管理员账号初始化完成", 用户名=settings.ADMIN_USERNAME)
            # Write initial password to a local file (avoid logs)
            try:
                p = Path(env_str("ADMIN_INIT_PASSWORD_PATH", "/data/.admin_init_password"))
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_text(pw + "\n", encoding="utf-8")
                try:
                    os.chmod(str(p), 0o600)
                except (OSError, ValueError) as e:
                    logger.detail(f"文件权限设置失败（已忽略） - path={p}, 原因={type(e).__name__}")
                    pass
                biz.ok(f"✅ 初始密码已写入本地文件（请尽快登录并修改密码）", 文件路径=str(p))
            except (OSError, ValueError, UnicodeEncodeError) as e:
                logger.detail(f"初始密码文件写入失败 - path={p}, 原因={type(e).__name__}")
                biz.warning("⚠️ 初始密码生成成功，但写入本地文件失败", stage="bootstrap", module="admin_auth", path="/data", reason="write_failed")
            log_ok(biz, "admin: credentials initialized")
        app.state.admin_credentials_ready = True
    except Exception as exc:
        app.state.admin_credentials_ready = False
        biz.exception("admin credentials not initialized (startup aborted)")
        raise ConfigurationError("admin credentials not initialized") from exc


def init_deduper(*, app: Any, settings: Any) -> Deduper:
    log_run(biz, "deduper: init")
    d = Deduper(
        ttl_seconds=settings.DEDUP_TTL_SECONDS,
        max_size=settings.DEDUP_MAX_SIZE,
        persistent=bool(getattr(settings, "DEDUP_PERSISTENT", False)),
    )
    log_ok(biz, "deduper: ready")
    try:
        app.state.deduper = d
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"deduper 状态设置失败（已忽略） - 原因={type(e).__name__}")
        pass
    return d


def build_on_sent(
    *,
    app: Any,
    recent_store: RecentEntriesStore,
    history: Optional[deque],
    push_notify: callable,
) -> callable:
    async def _on_sent(content: NotificationContent) -> None:
        try:
            if history is not None:
                history.append(content)
        except Exception:
            logger.detail("_on_sent：append history 失败", exc_info=True)

        # Mark a successful send for health counters
        try:
            push_notify()
        except Exception:
            logger.detail("_on_sent：push notify counter 失败", exc_info=True)

        try:
            mt = str(getattr(content, "media_type", "") or "").lower().strip()
            ev = "unknown"
            try:
                ev = normalize_event(getattr(content, "event", "") or "") or "unknown"
                from core.metrics import metrics

                metrics.inc("notify_sent_total", labels={"event": ev, "media_type": (mt or "unknown")})
            except (ValueError, TypeError, AttributeError, ImportError) as e:
                logger.detail(f"指标记录失败（已忽略） - event={ev}, media_type={mt}, 原因={type(e).__name__}")
                ev = ev or "unknown"

            # "最近入库" should ONLY contain real library media.
            has_library_sig = bool(
                (getattr(content, "item_id", None) or "")
                or (getattr(content, "series_id", None) or "")
                or (getattr(content, "item_path", None) or "")
            )

            # If provenance exists, keep recent_entries limited to Emby ingest only.
            try:
                se = getattr(content, "source_event", None)
                src = (getattr(se, "source", "") or "").strip().lower() if se is not None else ""
                if src and src != "emby":
                    logger.detail("_on_sent：操作异常：skip recent_entries (source=%s)", src)
                    return
            except Exception:
                logger.detail("_on_sent：provenance 检查 失败", exc_info=True)

            if str(ev).startswith("mediahelp_"):
                logger.detail("_on_sent：操作异常：skip recent_entries (system event) ev=%s", ev)
                return

            if has_library_sig and mt in {"movie", "episode", "series", "season"}:
                await recent_store.push(content)
            else:
                logger.detail("_on_sent：操作异常：skip recent_entries (non-media) mt=%s", mt)

        except Exception:
            logger.detail("_on_sent：recent_entries update 失败", exc_info=True)

    return _on_sent


def build_notifier_chain(*, app: Any, settings: Any, task_registry: TaskRegistry, on_sent: callable) -> Notifier:
    log_run(biz, "notifier: build")
    # Wire notifier dependencies (ports -> integrations) once, then build channels.
    reg = NotifierRegistry()

    # Notifier channels can be registered via core.plugin_loader (preferred).
    try:
        plugin_reg = getattr(getattr(app, "state", None), "plugin_registry", None)
        m = getattr(plugin_reg, "data", {}).get("notifiers") if plugin_reg is not None else None
        if isinstance(m, dict):
            for name, cls in m.items():
                try:
                    if name and cls is not None:
                        reg.register(str(name))(cls)
                except Exception:
                    logger.detail("plugin notifier register failed：操作异常：%s", name, exc_info=True)
    except Exception:
        logger.detail("plugin notifier registry read 失败", exc_info=True)

    # Backward compatible fallback: built-in channels via import side-effects.
    register_builtins(reg)


    try:
        from integrations.telegram_client import TelegramBotCaller

        tok = str(getattr(settings, "TG_BOT_TOKEN", "") or "").strip()
        if tok:
            caller = TelegramBotCaller(token=tok, timeout=20.0)
            # Provide multiple keys for compatibility with different notifiers.
            reg.set_deps(tg=caller, telegram=caller, telegram_caller=caller, tg_caller=caller)
    except Exception:
        biz.warning("⚠️ Telegram 适配器初始化失败：Telegram 通知功能可能不可用", exc_info=True)

    base_notifier = build_base_notifier(settings, registry=reg)
    hooked_base: Notifier = HookedNotifier(base_notifier, on_sent)
    notifier: Notifier = build_notifier(settings, downstream=hooked_base, task_registry=task_registry, registry=reg)
    try:
        app.state.notifier = notifier
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"notifier 状态设置失败（已忽略） - 原因={type(e).__name__}")
        pass
    log_ok(biz, "notifier: ready")
    return notifier


def build_handler(*, app: Any, push_attempt: callable) -> callable:
    # P2: registry dispatch (source -> parser -> pipeline -> channels)
    from notifier.service.dispatch import process_inbound, register_plugin_parsers_and_handlers
    try:
        register_plugin_parsers_and_handlers(app)
    except Exception:
        logger.detail("分发器：plugin 注册表 加载 失败", exc_info=True)
    async def handler(payload: Any) -> None:
        try:
            if isinstance(payload, NotificationContent):
                log_run(biz, "notify: send (direct)")
                push_attempt()
                await getattr(app.state, "notifier", DummyNotifier()).send(payload)
                log_ok(biz, "notify: sent (direct)")
                return

            if not isinstance(payload, dict):
                biz.warning("⚠️ handler 收到未知 payload 类型", stage="webhook_handler", payload_type=type(payload).__name__)
                return

            log_fetch(biz, "webhook: process payload")
            content = await process_inbound(payload)
            if not content:
                biz.warning("⚠️ 处理 Webhook payload 后未生成通知内容", stage="webhook_handler", reason="no_notification_content")
                return

            log_ok(biz, "webhook: content built")
            log_run(biz, "notify: send")
            push_attempt()
            await getattr(app.state, "notifier", DummyNotifier()).send(content)
            log_ok(biz, "notify: sent")
        except Exception:
            logger.fail("handler 处理通知时发生异常", exc_info=True)
            raise

    return handler


async def start_worker(*, app: Any, handler: callable) -> NotificationWorker:
    worker = NotificationWorker(handler)
    log_run(biz, "worker: start")
    await worker.start()
    log_ok(biz, "worker: running")
    try:
        app.state.notifier_worker = worker
        app.state.notifier_handler = handler
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"worker 状态设置失败（已忽略） - 原因={type(e).__name__}")
        pass
    return worker


def build_context_and_expose(
    *,
    app: Any,
    poster_cache: PosterCache,
    recent_store: RecentEntriesStore,
    deduper: Deduper,
    notifier: Notifier,
    worker: NotificationWorker,
    handler: callable,
    on_sent: callable,
    display_max: int,
    history: Optional[deque],
) -> AppContext:
    share_repo = _register_share_resolver_repo_best_effort()
    # Create runtime deques inside ctx (single source of truth).
    recent_notify_times = deque(maxlen=2000)
    recent_notify_attempt_times = deque(maxlen=2000)
    recent_webhook_times = deque(maxlen=2000)

    # Storage adapters: attach to ctx to avoid module-level singletons.
    try:
        from core.storage import get_blob_store, get_kv_store
        kv_store = get_kv_store()
        blob_store = get_blob_store()
    except (ValueError, TypeError, AttributeError, ImportError) as e:
        logger.detail(f"存储适配器初始化失败（已忽略） - 原因={type(e).__name__}")
        kv_store = None
        blob_store = None


    # Infra adapters (ports -> integrations)
    http_client = None
    tmdb_gateway = None
    tmdb_matcher = None
    share115_gateway = None
    try:
        from integrations.httpx_adapter import HttpxAsyncClientAdapter

        http_client = HttpxAsyncClientAdapter()
    except (ValueError, TypeError, AttributeError, ImportError) as e:
        logger.detail(f"HTTP 客户端初始化失败（已忽略） - 原因={type(e).__name__}")
        http_client = None

    try:
        from integrations.tmdb_gateway import DefaultTmdbGateway
        from settings.runtime import get_settings as _get_settings

        if http_client is not None:
            tmdb_gateway = DefaultTmdbGateway(http=http_client, settings=_get_settings())
    except (ValueError, TypeError, AttributeError, ImportError) as e:
        logger.detail(f"TMDB 网关初始化失败（已忽略） - 原因={type(e).__name__}")
        tmdb_gateway = None


    # TMDB matcher + 115 gateway ports (used by application share_resolver)
    try:
        from integrations.tmdb_matcher_adapter import DefaultTmdbMatcher

        tmdb_matcher = DefaultTmdbMatcher()
    except (ValueError, TypeError, AttributeError, ImportError) as e:
        logger.detail(f"TMDB 匹配器初始化失败（已忽略） - 原因={type(e).__name__}")
        tmdb_matcher = None

    try:
        from integrations.share115_gateway import DefaultShare115Gateway
        from settings.runtime import get_settings as _get_settings

        share115_gateway = DefaultShare115Gateway(settings=_get_settings())
    except (ValueError, TypeError, AttributeError, ImportError) as e:
        logger.detail(f"115 网关初始化失败（已忽略） - 原因={type(e).__name__}")
        share115_gateway = None

    ctx = AppContext(
        poster_cache=poster_cache,
        recent_store=recent_store,
        http_client=http_client,
        tmdb_gateway=tmdb_gateway,
        tmdb_matcher=tmdb_matcher,
        share115_gateway=share115_gateway,
        kv_store=kv_store,
        blob_store=blob_store,
        deduper=deduper,
        notifier=notifier,
        notifier_worker=worker,
        notifier_handler=handler,
        on_sent=on_sent,
        recent_display_max=display_max,
        recent_notify_times=recent_notify_times,
        recent_notify_attempt_times=recent_notify_attempt_times,
        recent_webhook_times=recent_webhook_times,
        notification_history=history,
        share_resolver_repo=share_repo,
    )

    # Forward bridge auth state (bind into ctx to avoid module-level split-brain).
    try:
        from forward_bridge.auth_state import get_mediahelp_state, bind_mediahelp_state

        st = get_mediahelp_state()
        ctx.mediahelp_auth = st
        bind_mediahelp_state(st)
    except (ValueError, TypeError, AttributeError, ImportError) as e:
        logger.detail(f"mediahelp 认证状态绑定失败（已忽略） - 原因={type(e).__name__}")
        pass

    expose_ctx(app, ctx)
    return ctx
