"""Composition root / wiring.

All high-level wiring and application bootstrap lives here to keep :mod:`core`
infrastructure-only.
"""
