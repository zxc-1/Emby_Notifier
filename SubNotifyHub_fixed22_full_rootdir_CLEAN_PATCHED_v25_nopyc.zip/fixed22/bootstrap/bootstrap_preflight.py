from __future__ import annotations

from core.exceptions.base import ConfigurationError

from core.logging import get_biz_logger
import os

from core.env_utils import env_str
from pathlib import Path

from core.preflight_helpers import dir_writable, path_writable
from core.runtime_env import (
    allow_multi_worker,
    get_admin_session_secret_path,
    get_data_fallback_root,
    get_env_path,
    get_poster_cache_dir,
    get_recent_store_path,
    get_web_concurrency_raw,
)
from typing import Any, Dict, Tuple


biz = get_biz_logger(__name__)


def is_path_under(path: Path, prefix: str) -> bool:
    try:
        return str(path.resolve()).startswith(prefix)
    except (OSError, ValueError, RuntimeError) as e:
        biz.detail(f"路径解析失败（使用原始路径） - path={path}, prefix={prefix}, 原因={type(e).__name__}")
        return str(path).startswith(prefix)



def compute_runtime_paths() -> Tuple[Path, Path, Path]:
    """Compute persistence paths with a safe fallback when /data is not writable."""
    poster_cache_dir = get_poster_cache_dir()
    recent_store_path = get_recent_store_path()
    data_fallback_root = get_data_fallback_root()

    # Only fall back when the user did not explicitly set a custom path (i.e., still under /data).
    if is_path_under(poster_cache_dir, "/data") and not dir_writable(poster_cache_dir):
        fallback = data_fallback_root / "poster_cache"
        biz.warning(f"⚠️ /data 目录不可写：海报缓存将使用备用路径", 备用路径=str(fallback))
        poster_cache_dir = fallback

    if is_path_under(recent_store_path, "/data") and not dir_writable(recent_store_path.parent):
        fallback = data_fallback_root / "recent_entries.json"
        biz.warning(f"⚠️ /data 目录不可写：最近入库记录将使用备用路径", 备用路径=str(fallback))
        recent_store_path = fallback

    return poster_cache_dir, recent_store_path, data_fallback_root



def _parse_workers_from_args(arg_str: str) -> int | None:
    """Best-effort parse workers count from a command args string.

    Supports:
      - uvicorn: --workers N
      - gunicorn: --workers N, -w N
    """
    import shlex

    raw = str(arg_str or "").strip()
    if not raw:
        return None
    try:
        parts = shlex.split(raw)
    except (ValueError, TypeError) as e:
        biz.detail(f"命令参数解析失败（使用简单分割） - args={raw}, 原因={type(e).__name__}")
        parts = raw.split()

    def _grab(flag: str) -> int | None:
        try:
            if flag in parts:
                i = parts.index(flag)
                if i + 1 < len(parts):
                    return int(parts[i + 1])
        except (ValueError, TypeError, IndexError) as e:
            biz.detail(f"worker 数量提取失败（已忽略） - flag={flag}, 原因={type(e).__name__}")
            return None
        return None

    for f in ("--workers", "-w"):
        v = _grab(f)
        if v is not None:
            return v
    return None


def _detect_configured_workers() -> int:
    """Detect configured worker count (best-effort).

    Priority:
      1) explicit envs: WEB_CONCURRENCY / UVICORN_WORKERS / WORKERS
      2) command args envs: UVICORN_CMD_ARGS / GUNICORN_CMD_ARGS
      3) default 1
    """
    workers_env = get_web_concurrency_raw()
    try:
        if str(workers_env or "").strip():
            return max(1, int(str(workers_env).strip()))
    except (ValueError, TypeError) as e:
        biz.detail(f"worker 数量解析失败（已忽略） - value={workers_env}, 原因={type(e).__name__}")

    for k in ("UVICORN_CMD_ARGS", "GUNICORN_CMD_ARGS"):
        try:
            v = env_str(k, default="")
            n = _parse_workers_from_args(v)
            if n is not None:
                return max(1, int(n))
        except (ValueError, TypeError) as e:
            biz.detail(f"命令参数 worker 数量解析失败（已忽略） - env={k}, 原因={type(e).__name__}")
            continue
    return 1


def run_preflight_checks(
    *,
    app: Any,
    settings: Any,
    poster_cache_dir: Path,
    recent_store_path: Path,
) -> Tuple[Dict[str, Any], list[str]]:
    """Populate app.state.preflight + app.state.health_warnings.

    This is best-effort except for critical config validation and multi-worker protection.
    """

    warnings: list[str] = []
    preflight: Dict[str, Any] = {"storage_issues": [], "deps": {}}

    # Optional dependency: guessit (match quality degrades if missing)
    try:
        import guessit  # type: ignore  # noqa: F401

        preflight["deps"]["guessit"] = True
    except ImportError as e:
        biz.detail(f"依赖库缺失（匹配质量可能下降） - module=guessit, 原因={type(e).__name__}")
        preflight["deps"]["guessit"] = False
        warnings.append("dependency_missing: guessit (TMDB match may degrade)")

    # Preflight: validate pipeline step config early so typos fail fast.
    from notifier.service.step_runner import preflight_validate_pipeline
    from notifier.service.dispatch import preflight_validate_dispatch

    preflight_validate_pipeline()
    preflight_validate_dispatch()
    # Settings schema gate (P2): fail fast when .env is from a different major schema.
    try:
        sv = int(getattr(settings, "CONFIG_SCHEMA_VERSION", 1) or 1)
    except (ValueError, TypeError, AttributeError) as e:
        biz.detail(f"配置版本解析失败（使用默认值 1） - 原因={type(e).__name__}")
        sv = 1
    if sv != 1:
        msg = f"CONFIG_SCHEMA_VERSION mismatch: got {sv}, expected 1"
        biz.fail(f"❌ 配置版本不匹配：当前版本 {sv}，期望版本 1", stage="preflight_config_schema", schema_version=sv, expected_version=1, config_strict=bool(getattr(settings, "CONFIG_STRICT", False)))
        if getattr(settings, "CONFIG_STRICT", False):
            raise ConfigurationError(msg)
        warnings.append(msg)

    # Layering guard (P2): notifier/* must not import integrations/* directly.
    # Enforce at runtime in addition to any static CI hooks to prevent drift.
    try:
        root = Path(__file__).resolve().parents[1]
        notifier_root = root / "notifier"
        bad: list[str] = []
        if notifier_root.exists():
            for p in notifier_root.rglob("*.py"):
                try:
                    txt = p.read_text(encoding="utf-8", errors="ignore")
                except (OSError, UnicodeDecodeError) as e:
                    biz.detail(f"文件读取失败（跳过） - path={p}, 原因={type(e).__name__}")
                    continue
                for ln in txt.splitlines():
                    s = ln.strip()
                    if s.startswith("#"):
                        continue
                    if s.startswith("from integrations") or s.startswith("import integrations"):
                        bad.append(str(p.relative_to(root)))
                        break
        if bad:
            msg = "layering_violation: notifier imports integrations: " + ", ".join(sorted(set(bad))[:20])
            biz.fail(f"❌ 分层违规：notifier 模块直接导入了 integrations 模块", 违规文件=", ".join(sorted(set(bad))[:5]))
            if getattr(settings, "CONFIG_STRICT", False):
                raise ConfigurationError(msg)
            warnings.append(msg)
    except Exception:
        biz.detail("分层预检扫描失败（已忽略）", stage="preflight_layering_scan", exc_info=True)



    def _check_path_writable(label: str, path: Path, *, is_dir: bool = False) -> None:
        try:
            ok = path_writable(path, is_dir=is_dir)
            if not ok:
                preflight["storage_issues"].append({"label": label, "path": str(path), "writable": False})
                warnings.append(f"storage_not_writable: {label} -> {path}")
        except (OSError, ValueError, TypeError) as e:
            biz.detail(f"存储可写性检查失败 - label={label}, path={path}, 原因={type(e).__name__}")
            preflight["storage_issues"].append({"label": label, "path": str(path), "writable": False})
            warnings.append(f"storage_check_failed: {label} -> {path}")

    # Admin/password/session persistence
    _check_path_writable("admin_password_file", Path(str(settings.ADMIN_PASSWORD_FILE)))
    secret_path = get_admin_session_secret_path()
    _check_path_writable("admin_session_secret", secret_path)

    # Worker deadletter
    _check_path_writable(
        "deadletter_dir",
        Path(str(getattr(settings, "NOTIFIER_DEADLETTER_DIR", "/data/deadletter"))),
        is_dir=True,
    )

    # TG bot persistence
    _check_path_writable("tg_bot_db", Path(str(getattr(settings, "TG_BOT_DB_PATH", "/data/tg_bot.db"))))
    _check_path_writable(
        "tg_bot_poll_offset",
        Path(str(getattr(settings, "TG_BOT_POLL_OFFSET_PATH", "/data/tg_bot_offset.json"))),
    )

    # UI/admin persistence
    # bootstrap-only rescue switch: keep getenv here to allow UI prefs path override even if settings/env_utils are partially broken
    _check_path_writable("ui_prefs", Path(os.getenv("UI_PREFS_PATH", "/data/ui_prefs.json")))
    _check_path_writable("env", get_env_path())

    # Recent entries + poster cache persistence
    _check_path_writable("recent_store", recent_store_path)
    _check_path_writable("poster_cache_dir", poster_cache_dir, is_dir=True)

    # Multi-worker protection
    workers = _detect_configured_workers()
    allow_multi = allow_multi_worker()
    role = str(getattr(settings, "APP_ROLE", "api") or "api").strip().lower()
    if workers > 1 and not allow_multi:
        msg = (
            f"multi-worker not supported (detected workers={workers}, APP_ROLE={role}). "
            "This app keeps local state (recent entries/poster cache/outbox) and background loops; "
            "use workers=1 or deploy split roles (APP_ROLE=api + APP_ROLE=worker). "
            "Set ALLOW_MULTI_WORKER=1 to bypass (NOT recommended)."
        )
        biz.fail(f"❌ 不支持多 worker 模式：检测到 workers={workers}，APP_ROLE={role}。请使用 workers=1 或拆分角色部署", stage="preflight_multi_worker", workers=workers, app_role=role, allow_multi_worker=bool(allow_multi))
        raise ConfigurationError(msg)
    if workers > 1:
        warnings.append(f"multi_worker_detected: {workers} (local state may be inconsistent)")

    # Write to app.state for health/debug endpoints (and older code)
    try:
        app.state.preflight = preflight
        app.state.health_warnings = warnings
    except (ValueError, TypeError, AttributeError) as e:
        biz.detail(f"预检状态设置失败（已忽略） - 原因={type(e).__name__}")

    return preflight, warnings
