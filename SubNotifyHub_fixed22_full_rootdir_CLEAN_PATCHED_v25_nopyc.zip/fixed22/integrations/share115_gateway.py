from __future__ import annotations

import logging
from core.logging import get_biz_logger_adapter
from typing import Any

from ports.share115 import Share115Gateway

logger = get_biz_logger_adapter(__name__)


class DefaultShare115Gateway(Share115Gateway):
    """115 share gateway adapter using :mod:`integrations.share115`."""

    def __init__(self, *, settings: Any) -> None:
        self._settings = settings

    def parse_share_url(self, share_url: str) -> tuple[str, str]:
        try:
            from integrations.share115 import parse_share_url as _parse
            sc, rc = _parse(str(share_url or ""))
            return str(sc or "").strip(), str(rc or "").strip()
        except Exception:
            logger.detail("115 分享：parse_share_url 失败", exc_info=True)
            return "", ""

    def _cookie(self) -> str:
        try:
            return str(getattr(self._settings, "CLOUD115_COOKIE", "") or "").strip()
        except (AttributeError, TypeError) as e:
            logger.detail(f"115 Cookie配置读取失败 - 原因={type(e).__name__}")
            return ""

    async def resolve_best_video_for_share(
        self,
        *,
        share_code: str,
        receive_code: str | None,
        max_depth: int,
        max_dir_scans: int,
    ) -> dict[str, Any]:
        from integrations.share115 import Share115Client, resolve_best_video_for_share

        cookie = self._cookie()
        async with Share115Client(cookie=cookie) as cl:
            return await resolve_best_video_for_share(
                cl,
                share_code=str(share_code or ""),
                receive_code=str(receive_code or "") or None,
                max_depth=int(max_depth),
                max_dir_scans=int(max_dir_scans),
            )
