from __future__ import annotations

from typing import Any

from .cd2_client import Cd2Client, Cd2Config, Cd2Error


class Cd2BridgeError(RuntimeError):
    pass


async def submit_to_cd2(
    *,
    magnet: str,
    save_path: str,
    title: str | None = None,
    # Backward-compat params (old UI)
    url: str | None = None,
    api_key: str | None = None,
    # New params
    mode: str | None = None,
    base_url: str | None = None,
    username: str | None = None,
    password: str | None = None,
    grpc_addr: str | None = None,
    token: str | None = None,
    cloud_name: str | None = None,
    cloud_account_id: str | None = None,
    auto_mkdir: bool = True,
) -> dict[str, Any]:
    """Submit a magnet task to CloudDrive2.

    新版：优先走 python-clouddrive2（CloudDrive2 官方 gRPC/CloudAPI），
    通过 FindFileByPath/CreateFolder/AddOfflineFiles 实现「目录容错 + mkdirp + 添加离线」。

    旧版 url/api_key（HTTP endpoint/bridge）已废弃：仍保留参数是为了兼容旧 UI，
    但不会再自动推断未知 HTTP endpoint（避免 0 成功率的“瞎补 URL”）。
    """

    cfg = Cd2Config(
        mode=(mode or "cloudapi").strip() or "cloudapi",
        base_url=(base_url or url or "").strip(),
        username=(username or "").strip(),
        password=(password or "").strip(),
        grpc_addr=(grpc_addr or "").strip(),
        token=(token or api_key or "").strip(),
        default_dir="",
        auto_mkdir=bool(auto_mkdir),
        cloud_name=(cloud_name or "").strip(),
        cloud_account_id=(cloud_account_id or "").strip(),
    )
    try:
        cli = Cd2Client(cfg)
        return await cli.add_offline(magnet=magnet, save_path=save_path, title=title or "")
    except Cd2Error as e:
        raise Cd2BridgeError(str(e)) from e
