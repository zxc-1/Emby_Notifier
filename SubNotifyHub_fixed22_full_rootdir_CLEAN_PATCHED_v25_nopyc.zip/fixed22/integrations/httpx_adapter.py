from __future__ import annotations

"""httpx -> ports.http_client adapter (P1)."""

import logging
from core.logging import get_biz_logger_adapter
from typing import Any, Mapping

import httpx

from core.http import get_http_client as _get_shared_httpx_client
from ports.http_client import (
    AsyncHttpClient,
    HttpRequestError,
    HttpResponse,
    HttpTimeoutError,
)

logger = get_biz_logger_adapter(__name__)


class HttpxAsyncClientAdapter(AsyncHttpClient):
    """Adapter that wraps a shared :class:`httpx.AsyncClient`.

    We rely on :mod:`core.http_clients` for client lifecycle and pooling.
    """

    def __init__(self, client: httpx.AsyncClient | None = None) -> None:
        self._client = client

    async def _get_client(self) -> httpx.AsyncClient:
        if self._client is not None:
            return self._client
        return await _get_shared_httpx_client()

    async def get(
        self,
        url: str,
        *,
        params: Mapping[str, Any] | None = None,
        headers: Mapping[str, str] | None = None,
        timeout: float | None = None,
    ) -> HttpResponse:
        client = await self._get_client()
        resp: httpx.Response | None = None
        try:
            resp = await client.get(url, params=dict(params or {}), headers=dict(headers or {}), timeout=timeout)
            # Copy out data before closing response to avoid leaking the connection.
            hdrs = {str(k).lower(): str(v) for k, v in (resp.headers or {}).items()}
            content = bytes(resp.content or b"")

            return HttpResponse(status_code=int(resp.status_code), headers=hdrs, content=content)
        except httpx.TimeoutException as exc:
            raise HttpTimeoutError(str(exc)) from exc
        except httpx.RequestError as exc:
            raise HttpRequestError(str(exc)) from exc
        finally:
            if resp is not None:
                try:
                    await resp.aclose()
                except Exception:
                    logger.detail("httpx response close 失败", exc_info=True)
