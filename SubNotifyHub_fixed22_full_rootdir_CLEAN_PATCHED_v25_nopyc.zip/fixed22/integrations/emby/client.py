from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional

from core.time_utils import parse_iso_datetime_utc


@dataclass
class EmbyConfig:
    base_url: str
    api_key: str

    @property
    def configured(self) -> bool:
        return bool(self.base_url and self.api_key)


class EmbyClient:
    """Minimal Emby client for dashboard usecases.

    Keeps HTTP + parsing details out of route handlers.
    """

    def __init__(self, *, logger: Any):
        self._logger = logger

    async def _http(self):
        from core.http import get_http_client
        return await get_http_client()

    async def first_user_id(self, cfg: EmbyConfig) -> str:
        if not cfg.configured:
            return ""
        try:
            http = await self._http()
            r = await http.get(f"{cfg.base_url}/Users", params={"api_key": cfg.api_key}, timeout=6.0)
            if int(getattr(r, "status_code", 500)) >= 400:
                return ""
            users = r.json() or []
            if not isinstance(users, list) or not users:
                return ""
            uid = users[0].get("Id") if isinstance(users[0], dict) else None
            uid = uid or (users[0].get("id") if isinstance(users[0], dict) else None)
            return str(uid or "").strip()
        except Exception:
            # Caller decides best-effort behavior; keep client quiet by default.
            return ""

    async def item_counts(self, cfg: EmbyConfig) -> Dict[str, int]:
        if not cfg.configured:
            return {}
        try:
            http = await self._http()
            r = await http.get(f"{cfg.base_url}/Items/Counts", params={"api_key": cfg.api_key}, timeout=8.0)
            if int(getattr(r, "status_code", 500)) >= 400:
                return {}
            raw = r.json() or {}
            out: Dict[str, int] = {}
            if isinstance(raw, dict):
                for k, v in raw.items():
                    try:
                        out[str(k)] = int(v)
                    except Exception:
                        continue
            return out
        except Exception:
            return {}

    async def recent_items(self, cfg: EmbyConfig, *, days: int, limit: int = 2000) -> List[Dict[str, Any]]:
        """Return recent Movie/Episode/Series items created within `days` days."""
        if not cfg.configured:
            return []
        uid = await self.first_user_id(cfg)
        if not uid:
            return []
        try:
            http = await self._http()
            params = {
                "SortBy": "DateCreated",
                "SortOrder": "Descending",
                "Limit": int(limit),
                "Fields": "DateCreated,Type,ParentId,SeriesName,SeasonName,ProviderIds,ImageTags",
                "IncludeItemTypes": "Movie,Episode,Series",
                "Recursive": "true",
                "Filters": "IsNotFolder",
                "api_key": cfg.api_key,
            }
            r = await http.get(f"{cfg.base_url}/Users/{uid}/Items", params=params, timeout=12.0)
            if int(getattr(r, "status_code", 500)) >= 400:
                return []
            data = r.json() or {}
            items = data.get("Items") if isinstance(data, dict) else []
            if not isinstance(items, list):
                return []
            cutoff = datetime.now(timezone.utc) - timedelta(days=int(days))
            out: List[Dict[str, Any]] = []
            for it in items:
                if not isinstance(it, dict):
                    continue
                dc = it.get("DateCreated")
                if not dc:
                    continue
                dt = parse_iso_datetime_utc(dc)
                if dt is None:
                    continue
                if dt < cutoff:
                    break
                out.append(it)
            return out
        except Exception:
            return []
