from __future__ import annotations

"""Shared Telegram Bot API client.

This module is intentionally dependency-light so it can be used by:

- ``notifier/notifiers/telegram.py`` (outbound notifications)
- ``tg_bot/telegram_api.py`` (inbound bot replies / edits)

Common capabilities:

- rate limiting (``core.rate_limiter``)
- retry on transient network errors, 5xx and 429
- text splitting helpers
- parse_mode fallback (drop parse_mode when Telegram can't parse entities)
- consistent error extraction for logging / metrics
"""

import asyncio
from typing import Any, Dict, Optional, Tuple, Mapping

import httpx

from core.http import get_http_client
from core.http import async_request_with_retry_json
from core.logging import get_biz_logger
from core.rate_limiter import get_telegram_limiter
from core.text_split import split_text
from settings.urls import get_telegram_api_url


biz = get_biz_logger(__name__)


# -----------------------------------------------------------------------------
# Port adapter
# -----------------------------------------------------------------------------

try:
    from ports.telegram import TelegramCaller
except Exception:  # pragma: no cover
    TelegramCaller = Any  # type: ignore


class TelegramBotCaller(TelegramCaller):
    """A small adapter that implements :class:`ports.telegram.TelegramCaller`.

    This keeps notifier/application code depending on the *port* only.
    """

    def __init__(self, *, token: str, timeout: float = 20.0) -> None:
        self._token = str(token or "").strip()
        self._timeout = float(timeout or 20.0)

    async def call_json(
        self,
        method: str,
        *,
        params: Mapping[str, Any] | None = None,
        files: Mapping[str, Any] | None = None,
    ) -> Any:
        return await tg_call_json(
            str(method or "").strip(),
            token=self._token,
            json_payload=dict(params or {}) if not files else None,
            data=dict(params or {}) if files else None,
            files=dict(files or {}) if files else None,
            timeout=self._timeout,
            parse_mode_fallback=True,
            log_ctx=f"port:{method}",
        )


# Telegram limits (approx.)
TG_TEXT_LIMIT = 4096
TG_CAPTION_LIMIT = 1024
TG_TEXT_SOFT_LIMIT = 3900  # keep some room for markup / emoji


_RETRYABLE_STATUS = {429, 500, 502, 503, 504}
_RETRYABLE_EXC = (
    httpx.ConnectTimeout,
    httpx.ReadTimeout,
    httpx.ConnectError,
    httpx.RemoteProtocolError,
    httpx.ReadError,
    httpx.WriteError,
    httpx.PoolTimeout,
)


def split_tg_text(text: str, *, limit: int = TG_TEXT_SOFT_LIMIT) -> list[str]:
    """Split a long Telegram message into safe chunks."""
    return split_text(str(text or ""), limit=int(limit or TG_TEXT_SOFT_LIMIT))


def tg_extract_error(data: Optional[Dict[str, Any]], fallback: str = "") -> str:
    """Extract a human-readable error description from Telegram JSON."""
    if not data:
        return str(fallback or "")
    try:
        desc = str(data.get("description") or "")
        if desc:
            return desc
    except (ValueError, TypeError, AttributeError) as e:
        biz.detail("Telegram 错误描述提取失败", error=type(e).__name__)
    return str(fallback or "")


def _is_parse_mode_entity_error(desc: str) -> bool:
    d = (desc or "").lower()
    return "can't parse entities" in d or "can\'t parse entities" in d or "cant parse entities" in d


def _compute_backoff(attempt: int, backoff: Tuple[float, float]) -> float:
    """Exponential backoff used for transient failures."""
    init, step = backoff
    if attempt <= 0:
        return max(0.0, float(init))
    return max(0.0, float(step) * (2 ** (attempt - 1)))


async def tg_call_json(
    method: str,
    *,
    token: str,
    json_payload: Dict[str, Any] | None = None,
    data: Dict[str, Any] | None = None,
    files: Dict[str, Any] | None = None,
    timeout: float = 20.0,
    max_attempts: int = 3,
    backoff: Tuple[float, float] = (0.0, 1.0),
    parse_mode_fallback: bool = False,
    log_ctx: str = "",
) -> Optional[Dict[str, Any]]:
    """Call Telegram Bot API and return parsed JSON.

    Returns:
      - dict: Telegram response JSON (including on non-200 when parsable)
      - None: hard failure (httpx error, unexpected exception)

    When ``parse_mode_fallback`` is enabled and Telegram returns an entity parse error,
    we retry once with ``parse_mode`` removed.

    IMPORTANT: httpx responses MUST be closed (``await resp.aclose()``) to avoid
    exhausting the connection pool under sustained traffic / retries.
    """

    tok = str(token or "").strip()
    if not tok:
        biz.warning("Telegram API 调用缺少 token", method=method)
        return None

    url = get_telegram_api_url(tok, method)
    client = await get_http_client()
    limiter = get_telegram_limiter()

    # Normalize payloads.
    jp: Dict[str, Any] = dict(json_payload or {})
    dp: Dict[str, Any] = dict(data or {})
    fp: Dict[str, Any] = dict(files or {})

    last_text = ""
    attempts = max(1, int(max_attempts or 1))

    for attempt in range(attempts):
        await limiter.wait()
        try:
            # Use the leak-proof wrapper (always closes response).
            status_code, data_any, text_snip = await async_request_with_retry_json(
                client,
                "POST",
                url,
                json=jp if not (fp or dp) else None,
                data=dp if (fp or dp) else None,
                files=fp if (fp or dp) else None,
                timeout=float(timeout or 20.0),
                max_attempts=1,  # outer loop controls retries
                backoff=backoff,
                retry_statuses=set(),  # outer loop handles 429/5xx with Telegram-aware logic
                log_ctx=log_ctx or f"tg:{method}",
                text_snip_len=500,
            )
            last_text = text_snip or ""

            data_json: Dict[str, Any] = data_any if isinstance(data_any, dict) else {}
            try:
                data_json["_status"] = int(status_code)
            except (ValueError, TypeError, KeyError) as e:
                biz.detail("Telegram 响应状态码设置失败", status_code=status_code, error=type(e).__name__)

            ok = (status_code == 200) and (data_json.get("ok") is True)
            if ok:
                return data_json

            desc = tg_extract_error(data_json, fallback=last_text)

            # Parse-mode fallback (one extra try).
            if (
                parse_mode_fallback
                and ("parse_mode" in jp or "parse_mode" in dp)
                and _is_parse_mode_entity_error(desc)
            ):
                biz.warning(
                    "Telegram parse_mode 实体解析错误，将移除 parse_mode 重试",
                    method=method,
                    ctx=log_ctx,
                )
                jp2 = dict(jp)
                dp2 = dict(dp)
                jp2.pop("parse_mode", None)
                dp2.pop("parse_mode", None)

                # Disable recursive fallback to avoid loops.
                return await tg_call_json(
                    method,
                    token=tok,
                    json_payload=jp2 if not (fp or dp) else None,
                    data=dp2 if (fp or dp) else None,
                    files=fp if (fp or dp) else None,
                    timeout=timeout,
                    max_attempts=max(1, min(2, attempts)),
                    backoff=backoff,
                    parse_mode_fallback=False,
                    log_ctx=log_ctx or f"tg:{method}",
                )

            # Respect Telegram JSON retry_after when rate limited.
            if status_code == 429 and attempt < (attempts - 1):
                try:
                    ra = float(((data_json or {}).get("parameters") or {}).get("retry_after") or 0)
                except (ValueError, TypeError, KeyError) as e:
                    biz.detail("Telegram retry_after 读取失败", error=type(e).__name__)
                    ra = 0.0
                delay = ra if ra > 0 else _compute_backoff(attempt, backoff)
                # Telegram can return retry_after up to ~60s for bursts; honor it.
                delay = min(max(0.0, float(delay)), 60.0)
                biz.warning(
                    "Telegram API 被限流，等待后重试",
                    method=method,
                    ctx=log_ctx,
                    attempt=attempt + 1,
                    max_attempts=attempts,
                    retry_after_sec=round(delay, 2),
                    desc=(desc or "")[:160],
                )
                if delay:
                    await asyncio.sleep(delay)
                continue

            # Retry on 5xx.
            if status_code in {500, 502, 503, 504} and attempt < (attempts - 1):
                delay = _compute_backoff(attempt, backoff)
                biz.warning(
                    "Telegram 服务器错误，等待后重试",
                    method=method,
                    ctx=log_ctx,
                    status=status_code,
                    attempt=attempt + 1,
                    max_attempts=attempts,
                    delay_sec=round(delay, 2),
                )
                if delay:
                    await asyncio.sleep(delay)
                continue

            # Not OK and no more retries -> return parsed JSON if any; else minimal dict.
            if data_json:
                return data_json
            return {"ok": False, "description": desc, "_status": status_code}

        except _RETRYABLE_EXC as exc:
            if attempt < (attempts - 1):
                delay = _compute_backoff(attempt, backoff)
                biz.warning(
                    "Telegram 请求临时失败，等待后重试",
                    method=method,
                    ctx=log_ctx,
                    error=type(exc).__name__,
                    attempt=attempt + 1,
                    max_attempts=attempts,
                    delay_sec=round(delay, 2),
                )
                if delay:
                    await asyncio.sleep(delay)
                continue
            biz.fail("Telegram 请求在多次重试后仍然失败", method=method, ctx=log_ctx, exc_info=True)
            return None
        except httpx.HTTPError:
            biz.fail("Telegram 请求发生 httpx 错误", method=method, ctx=log_ctx, exc_info=True)
            return None
        except Exception:
            biz.fail("Telegram 请求发生意外错误", method=method, ctx=log_ctx, exc_info=True)
            return None


    # Should not reach, but be defensive.
    return {"ok": False, "description": tg_extract_error(None, last_text)}
