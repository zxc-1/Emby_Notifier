from __future__ import annotations

"""Wrappers for similarity/scoring primitives.

Pure implementation lives in :mod:`domain.tmdb_match.similarity`.
"""
import logging
from core.logging import get_biz_logger_adapter
logger = get_biz_logger_adapter(__name__)


from typing import Dict, List, Optional, Tuple

from ports.settings_provider import get_settings

from domain.tmdb_match import similarity as _sim


def _cleanup_mode() -> str:
    try:
        mode = str(getattr(get_settings(), "TMDB_CN_TAG_CLEANUP_MODE", "conservative") or "conservative")
        mode = mode.strip().lower()
    except (ValueError, TypeError, AttributeError):
        mode = "conservative"
    return mode if mode in {"conservative", "aggressive", "off"} else "conservative"


def _key_tokens(s: str) -> List[str]:
    return _sim.key_tokens(s, cn_tag_cleanup_mode=_cleanup_mode())


def _compute_idf_weights(query_tokens: List[str], candidate_titles: List[str]) -> Dict[str, float]:
    return _sim.compute_idf_weights(query_tokens, candidate_titles, cn_tag_cleanup_mode=_cleanup_mode())


def _match_meta(query_title: str, cand_title: str, *, idf: Optional[Dict[str, float]] = None) -> Tuple[float, float]:
    return _sim.match_meta(query_title, cand_title, idf=idf, cn_tag_cleanup_mode=_cleanup_mode())


def _title_similarity(a: str, b: str) -> float:
    return _sim.title_similarity(a, b, cn_tag_cleanup_mode=_cleanup_mode())
