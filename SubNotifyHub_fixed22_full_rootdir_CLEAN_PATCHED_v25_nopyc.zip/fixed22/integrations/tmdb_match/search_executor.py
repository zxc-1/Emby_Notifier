"""TMDB search execution strategies.

This module handles the multi-stage search strategy for TMDB matching,
including recall limits, batch execution, and early-stop logic.
"""
from __future__ import annotations

import asyncio
import re
from typing import Any, Callable, Dict, List, Optional, Tuple

import httpx

from core.logging import get_biz_logger
from ports.settings_provider import get_settings

from .tmdb_match_api import (
    search_candidates_via_tmdb,
    search_candidates_multi_via_tmdb,
)
from core.task_registry import create_task_logged
from .tmdb_match_core import Candidate, score_candidate_meta
from .query_variants import is_collision_prone, token_count

biz = get_biz_logger(__name__)


def compute_recall_limits(
    query: str,
    *,
    widened: bool = False,
    strict_tv: bool = False,
    year_for_search: Optional[int] = None,
) -> Tuple[Optional[int], Optional[int]]:
    """Compute recall limits for a TMDB search.
    
    Args:
        query: The search query
        widened: Whether this is a widened (fallback) search
        strict_tv: Whether TV is strongly implied
        year_for_search: The year filter being used (if any)
        
    Returns:
        Tuple of (max_candidates, max_pages_override)
        - max_candidates controls fetch_n (how many raw TMDB results we collect)
        - max_pages_override allows bypassing TMDB_SEARCH_MAX_PAGES for this request
    """
    cap = None
    try:
        tc = token_count(query)
    except (ValueError, TypeError, AttributeError):
        biz.detail(
            "ℹ️ [TMDB搜索]token 计数失败：无法统计查询字符串的 token 数量。"
            "可能原因：查询字符串格式异常、token 计数函数逻辑错误、或字符编码问题。"
            "影响：使用默认值 6 继续处理,可能影响召回限制的准确性",
            query=query[:80],
            exc_info=True
        )
        tc = 6

    collision = is_collision_prone(query)

    # When TV is strongly implied and we have a reliable year, keep search tight
    if strict_tv and isinstance(year_for_search, int):
        max_pages_override = 2
    else:
        max_pages_override = None

    if widened:
        # Low-quality recall path: fetch more + allow deeper pages
        if tc <= 2 or collision:
            cap = 240
        elif tc <= 4:
            cap = 160
        else:
            cap = 120
    else:
        # Normal path: keep costs bounded
        if tc <= 2:
            cap = 120 if collision else 80
        elif tc <= 4:
            cap = 80
        else:
            cap = None

    mpo = max_pages_override
    if cap is not None and int(cap) >= 120:
        try:
            mpo = int(min(12, max(4, (int(cap) + 19) // 20)))
        except (ValueError, TypeError):
            biz.detail(
                "ℹ️ [TMDB搜索]max_pages 计算失败：无法计算最大页数覆盖值。"
                "可能原因：cap 参数类型异常、数值计算溢出、或类型转换失败。"
                "影响：使用默认页数限制,可能影响搜索结果的完整性",
                cap=cap,
                exc_info=True
            )
            mpo = None
    
    return cap, mpo


def safe_early_stop_ok(
    merged: Dict[Any, Any],
    title: str,
    year: Optional[int],
) -> bool:
    """Check if it's safe to stop searching early.
    
    Args:
        merged: Dictionary of merged candidates
        title: The query title
        year: The query year
        
    Returns:
        True if early stopping is safe
    """
    try:
        if not bool(getattr(get_settings(), "TMDB_SAFE_EARLY_STOP", True)):
            return False
    except (ValueError, TypeError, AttributeError):
        biz.detail(
            "ℹ️ [TMDB搜索]early stop 配置检查失败：无法读取安全提前停止配置。"
            "可能原因：配置项缺失、配置值类型错误、或 settings 对象访问失败。"
            "影响：禁用提前停止优化,继续完整搜索流程",
            exc_info=True
        )
        return False
    
    if not merged:
        return False
    
    try:
        tmp = sorted(list(merged.values()), key=lambda x: float(x[1]), reverse=True)
    except (ValueError, TypeError):
        biz.detail(
            "ℹ️ [TMDB搜索]候选排序失败：无法按分数对候选结果进行排序。"
            "可能原因：候选数据结构异常、分数值类型错误、或排序键访问失败。"
            "影响：无法判断是否可以提前停止搜索,继续完整搜索流程",
            exc_info=True
        )
        return False
    
    if not tmp:
        return False
    
    best_c, best_sc, _q0 = tmp[0]
    second_sc = float(tmp[1][1]) if len(tmp) > 1 else 0.0
    gap = float(best_sc) - float(second_sc)
    
    # Recompute coverage on the best candidate
    try:
        _sc2, cov2, _ = score_candidate_meta(title, year, best_c)
    except (ValueError, TypeError, AttributeError):
        biz.detail(
            "ℹ️ [TMDB搜索]score 计算失败：无法计算最佳候选的覆盖率分数。"
            "可能原因：候选数据不完整、标题或年份格式异常、或评分函数逻辑错误。"
            "影响：使用默认覆盖率 0.0,可能影响提前停止判断的准确性",
            title=title,
            year=year,
            exc_info=True
        )
        cov2 = 0.0
    
    # If year is known, don't early-stop on a far year mismatch
    try:
        if isinstance(year, int) and isinstance(best_c.year, int):
            if abs(int(best_c.year) - int(year)) > 1:
                return False
    except (ValueError, TypeError, AttributeError):
        biz.detail(
            "ℹ️ [TMDB搜索]year mismatch 检查失败：无法比较查询年份和候选年份。"
            "可能原因：年份数据类型异常、候选对象结构不完整、或年份值缺失。"
            "影响：跳过年份匹配检查,可能允许年份差异较大的结果提前停止",
            exc_info=True
        )
    
    return (float(best_sc) >= 0.92) and (gap >= 0.18) and (float(cov2) >= 0.62)


async def search_one(
    media_type: str,
    query: str,
    year_for_search: Optional[int],
    strict_tv: bool = False,
) -> Tuple[str, str, List[Candidate]]:
    """Execute a single TMDB search.
    
    Args:
        media_type: "movie" or "tv"
        query: The search query
        year_for_search: Year filter (may be None)
        strict_tv: Whether TV is strongly implied
        
    Returns:
        Tuple of (media_type, query, candidates)
    """
    fetch_cap, mpo = compute_recall_limits(
        query,
        widened=False,
        strict_tv=strict_tv,
        year_for_search=year_for_search,
    )
    try:
        got = await search_candidates_via_tmdb(
            query,
            media_type,
            year=year_for_search,
            max_candidates=fetch_cap,
            max_pages_override=mpo,
        )
    except (httpx.HTTPError, OSError, asyncio.TimeoutError, RuntimeError):
        biz.detail(
            "ℹ️ [TMDB搜索]TMDB 搜索失败：无法从 TMDB API 获取搜索结果。"
            "可能原因：网络连接异常、TMDB API 暂时不可用、请求超时、或 API 密钥无效。"
            "影响：该查询返回空结果,可能影响识别准确性",
            query=query[:80],
            media_type=media_type,
            year=year_for_search,
            exc_info=True
        )
        got = []
    return media_type, query, got or []


async def execute_staged_search(
    variants: List[str],
    mt_order: List[str],
    title: str,
    year: Optional[int],
    year_for_search: Optional[int],
    media_type: str,
    fm: str,
    tv_hint: bool,
    strict_tv: bool,
    max_variants: int,
    max_merged: int,
    merge_callback: Callable[[List[Candidate], str], None],
) -> Tuple[Dict[Tuple[int, str], Tuple[Candidate, float, str]], str]:
    """Execute the multi-stage TMDB search strategy.
    
    Args:
        variants: List of query variants
        mt_order: Order of media types to search
        title: Original parsed title
        year: Parsed year
        year_for_search: Year to use for TMDB filtering
        media_type: Primary media type
        fm: Forced media type (empty if not forced)
        tv_hint: Whether TV hints were detected
        strict_tv: Whether TV is strongly implied
        max_variants: Maximum number of variants to search
        max_merged: Maximum number of merged candidates
        merge_callback: Callback to merge candidates into the pool
        
    Returns:
        Tuple of (merged_dict, used_query)
    """
    merged: Dict[Tuple[int, str], Tuple[Candidate, float, str]] = {}
    used_q = title
    
    def _merge_candidates(got: List[Candidate], q: str) -> None:
        for c in got:
            sc, _cov, _mn = score_candidate_meta(title, year, c)
            # If media type is forced, prefer it but do NOT hard-drop the opposite type
            if fm and str(c.media_type) != str(media_type):
                try:
                    sc = max(0.0, float(sc) - 0.25)
                except (ValueError, TypeError):
                    biz.detail(
                        "ℹ️ [TMDB搜索]media type penalty 计算失败：无法对非匹配媒体类型应用分数惩罚。"
                        "可能原因：分数值类型异常、数值计算错误、或类型转换失败。"
                        "影响：该候选不会被降低分数,可能影响排序准确性",
                        exc_info=True
                    )
            # Small media-type bonus when tv_hint is strong
            if tv_hint and c.media_type == "tv":
                sc = min(1.0, sc + 0.04)
            if (not tv_hint) and c.media_type == "movie":
                sc = min(1.0, sc + 0.02)
            key = (int(c.tmdb_id), str(c.media_type))
            prev = merged.get(key)
            if prev is None or sc > prev[1]:
                merged[key] = (c, sc, q)
    
    # Stage 1: most-likely query (fast path)
    q0 = (variants[0] if variants else title)
    mt0 = mt_order[0]
    _mt, _q, got0 = await search_one(mt0, q0, year_for_search, strict_tv)
    if got0:
        used_q = q0
        _merge_candidates(got0, q0)
    
    # If the best candidate is extremely strong, safely skip the rest
    if (len(merged) >= 1) and safe_early_stop_ok(merged, title, year):
        return merged, used_q
    
    # Stage 2: remaining (mt, query-variant) searches in parallel
    combos: List[Tuple[str, str]] = []
    for mt in mt_order:
        for q in variants[:max_variants]:
            if mt == mt0 and q == q0:
                continue
            combos.append((mt, q))
    
    first_hit_q: Optional[str] = used_q if got0 else None
    
    # Run in small batches to avoid spawning too many tasks at once
    batch_size = 4
    for i0 in range(0, len(combos), batch_size):
        batch = combos[i0 : i0 + batch_size]
        tasks = [
            create_task_logged(search_one(mt, q, year_for_search, strict_tv))
            for mt, q in batch
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        for _r in results:
            if isinstance(_r, Exception):
                biz.detail(f"并行任务失败（已忽略）：{type(_r).__name__}", error=str(_r))
        
        for res in results:
            if isinstance(res, Exception):
                biz.detail(
                    "ℹ️ [TMDB搜索]并行搜索任务失败：并行搜索返回异常。"
                    "可能原因：TMDB API 连接失败、请求超时、响应解析异常。"
                    "影响：该批次的部分候选无法获取,可能降低召回率",
                    exc_info=res,
                )
                continue
            _mt, _q, got = res
            if not got:
                continue
            if first_hit_q is None:
                first_hit_q = _q
            _merge_candidates(got, _q)
            if len(merged) >= max_merged:
                break
        
        if first_hit_q is not None:
            used_q = first_hit_q
        
        # Safe early-stop even within stage2
        if (len(merged) >= 1) and safe_early_stop_ok(merged, title, year):
            break
        if len(merged) >= max_merged:
            break
    
    return merged, used_q


async def execute_yearless_fallback(
    merged: Dict[Tuple[int, str], Tuple[Candidate, float, str]],
    variants: List[str],
    mt_order: List[str],
    title: str,
    year: Optional[int],
    media_type: str,
    fm: str,
    tv_hint: bool,
    strict_tv: bool,
    max_variants: int,
    max_merged: int,
) -> None:
    """Execute a yearless fallback search when initial results are low quality.
    
    Modifies merged dict in place.
    """
    def _merge_candidates(got: List[Candidate], q: str) -> None:
        for c in got:
            sc, _cov, _mn = score_candidate_meta(title, year, c)
            if fm and str(c.media_type) != str(media_type):
                try:
                    sc = max(0.0, float(sc) - 0.25)
                except (ValueError, TypeError):
                    pass
            if tv_hint and c.media_type == "tv":
                sc = min(1.0, sc + 0.04)
            if (not tv_hint) and c.media_type == "movie":
                sc = min(1.0, sc + 0.02)
            key = (int(c.tmdb_id), str(c.media_type))
            prev = merged.get(key)
            if prev is None or sc > prev[1]:
                merged[key] = (c, sc, q)
    
    async def _search_one_yearless(mt: str, q: str):
        fetch_cap, mpo = compute_recall_limits(q, widened=True, strict_tv=strict_tv)
        try:
            got = await search_candidates_via_tmdb(
                q, mt, year=None, max_candidates=fetch_cap, max_pages_override=mpo
            )
        except (httpx.HTTPError, OSError, asyncio.TimeoutError, RuntimeError):
            biz.detail(
                "ℹ️ [TMDB搜索]yearless search 失败：无法执行无年份限制的回退搜索。"
                "可能原因：网络连接异常、TMDB API 暂时不可用、请求超时、或 API 密钥无效。"
                "影响：该回退查询返回空结果,可能影响低质量结果的改善",
                query=q[:80],
                media_type=mt,
                exc_info=True
            )
            got = []
        return mt, q, got or []
    
    yr_variants = variants[: min(len(variants), max(4, min(max_variants, 6)))]
    combos2 = [(mt, q) for mt in mt_order for q in yr_variants]
    
    batch_size2 = 4
    for j0 in range(0, len(combos2), batch_size2):
        batch2 = combos2[j0 : j0 + batch_size2]
        tasks2 = [create_task_logged(_search_one_yearless(mt, q)) for mt, q in batch2]
        results2 = await asyncio.gather(*tasks2, return_exceptions=True)
        for _r in results2:
            if isinstance(_r, Exception):
                biz.detail(f"并行任务失败（已忽略）：{type(_r).__name__}", error=str(_r))
        for res2 in results2:
            if isinstance(res2, Exception):
                biz.detail(
                    "ℹ️ [TMDB搜索]yearless 并行搜索任务失败：并行回退搜索返回异常。"
                    "可能原因：TMDB API 连接失败、请求超时、响应解析异常。"
                    "影响：该批次的部分回退候选无法获取,可能降低召回率",
                    exc_info=res2,
                )
                continue
            _mt2, _q2, got2 = res2
            if not got2:
                continue
            _merge_candidates(got2, _q2)
            if len(merged) >= max_merged:
                break
        if (len(merged) >= 1) and safe_early_stop_ok(merged, title, year):
            break
        if len(merged) >= max_merged:
            break


async def execute_multi_search_fallback(
    merged: Dict[Tuple[int, str], Tuple[Candidate, float, str]],
    variants: List[str],
    title: str,
    year: Optional[int],
    media_type: str,
    fm: str,
    tv_hint: bool,
    strict_tv: bool,
) -> None:
    """Execute multi-search fallback for low quality results.
    
    Modifies merged dict in place.
    """
    q0 = variants[0] if variants else title
    fetch_cap_m, mpo_m = compute_recall_limits(q0, widened=True, strict_tv=strict_tv)
    gotm = []

    try:
        gotm = await search_candidates_multi_via_tmdb(
            q0, year=None, max_candidates=fetch_cap_m, max_pages_override=mpo_m
        )
    except (httpx.HTTPError, OSError, asyncio.TimeoutError, RuntimeError):
        biz.detail(
            "ℹ️ [TMDB搜索]multi-search 失败：无法执行 multi-search 回退查询。"
            "可能原因：网络连接异常、TMDB API 暂时不可用、请求超时、或 API 密钥无效。"
            "影响：该回退查询返回空结果,可能影响低质量结果的改善",
            query=q0[:80],
            exc_info=True,
        )
        gotm = []

    if strict_tv:
        gotm = [c for c in (gotm or []) if getattr(c, "media_type", None) == "tv"]
    for c in gotm or []:
        sc, cov, _mn = score_candidate_meta(title, year, c)
        if fm and str(c.media_type) != str(media_type):
            try:
                sc = max(0.0, float(sc) - 0.25)
            except (ValueError, TypeError):
                pass
        if tv_hint and c.media_type == "tv":
            sc = min(1.0, sc + 0.04)
        if (not tv_hint) and c.media_type == "movie":
            sc = min(1.0, sc + 0.02)
        key = (int(c.tmdb_id), str(c.media_type))
        prev = merged.get(key)
        if prev is None or sc > prev[1]:
            merged[key] = (c, sc, q0)