from __future__ import annotations

"""Wrappers for auto-pick heuristics.

Pure implementation lives in :mod:`domain.tmdb_match.autopick`.
"""

from typing import Any, Dict, List, Optional, Tuple

from domain.tmdb_match.autopick import should_auto_pick as _should_auto_pick
from domain.tmdb_match.types import Candidate


def should_auto_pick(scores: List[Tuple[Candidate, float]], *, ctx: Optional[Dict[str, Any]] = None) -> bool:
    return _should_auto_pick(scores, ctx=ctx)
