from __future__ import annotations

"""Wrappers for candidate scoring.

Pure implementation lives in :mod:`domain.tmdb_match.scoring`.
"""
import logging
from core.logging import get_biz_logger_adapter
logger = get_biz_logger_adapter(__name__)


from typing import Dict, Optional, Tuple

from ports.settings_provider import get_settings

from domain.tmdb_match import scoring as _sc
from domain.tmdb_match.types import Candidate


def _cleanup_mode() -> str:
    try:
        mode = str(getattr(get_settings(), "TMDB_CN_TAG_CLEANUP_MODE", "conservative") or "conservative")
        mode = mode.strip().lower()
    except (ValueError, TypeError, AttributeError):
        mode = "conservative"
    return mode if mode in {"conservative", "aggressive", "off"} else "conservative"


def score_candidate_meta(
    query_title: str,
    query_year: Optional[int],
    cand: Candidate,
    *,
    idf: Optional[Dict[str, float]] = None,
) -> Tuple[float, float, str]:
    return _sc.score_candidate_meta(
        query_title,
        query_year,
        cand,
        idf=idf,
        cn_tag_cleanup_mode=_cleanup_mode(),
    )


def score_candidate(query_title: str, query_year: Optional[int], cand: Candidate) -> float:
    return _sc.score_candidate(query_title, query_year, cand, cn_tag_cleanup_mode=_cleanup_mode())
