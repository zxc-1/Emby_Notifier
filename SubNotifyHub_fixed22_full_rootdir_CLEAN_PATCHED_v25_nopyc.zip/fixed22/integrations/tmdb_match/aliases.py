from __future__ import annotations

"""TMDB alias enrichment.

Why this exists
--------------
TMDB search can miss titles that only exist in:
  * /{mt}/{id}/alternative_titles  (aka titles by region)
  * /{mt}/{id}/translations       (localized titles; for many non-English shows, English title is here)

This module returns a *deduped* list of alias strings and is deliberately defensive:
  - Correctly wires the shared HTTP client + api_key
  - Caches even empty results (via cache.py fix) to avoid repeated fetches
  - Adds a small circuit breaker for repeated 401/403/429/no-key scenarios
  - Avoids treating language names (e.g., "English") as titles
  - Handles both TV/Movie response shapes
"""

import time
from typing import Any, Dict, List, Set, Tuple

from core.logging import get_biz_logger
from settings.timeouts import TimeoutCategory, get_timeout
from settings.retries import RetryCategory, get_retry_config
from settings.urls import get_tmdb_api_url

from .cache import alias_cache_get, alias_cache_put
from .client import _http_get_json_with_retry
from .tmdb_match_core import get_http_client, get_settings


biz = get_biz_logger(__name__)

# Get default retry config for TMDB API
_TMDB_RETRY = get_retry_config(RetryCategory.EXTERNAL_SERVICE)


# ──────────────────────────────────────────────────────────────────────────────
# Circuit breaker (avoid log spam + wasted HTTP on persistent failures)
# ──────────────────────────────────────────────────────────────────────────────

_ALIAS_DISABLE_UNTIL_TS: float = 0.0
_ALIAS_DISABLE_REASON: str = ""


def _now() -> float:
    return time.time()


def _disabled() -> bool:
    return _now() < _ALIAS_DISABLE_UNTIL_TS


def _disable_for(sec: int, reason: str) -> None:
    global _ALIAS_DISABLE_UNTIL_TS, _ALIAS_DISABLE_REASON
    _ALIAS_DISABLE_UNTIL_TS = _now() + max(1, int(sec))
    _ALIAS_DISABLE_REASON = reason or "unknown"


# ──────────────────────────────────────────────────────────────────────────────


def _norm_media_type(mt: str) -> str:
    mt = (mt or "").strip().lower()
    return "movie" if mt == "movie" else "tv"


def _norm_alias(s: str) -> str:
    # keep it simple: don't lower-case here (scoring handles case)
    return (s or "").strip()


def _extend(out: Set[str], items: List[str]) -> None:
    for x in items or []:
        x = _norm_alias(x)
        if x:
            out.add(x)


async def _tmdb_get_json(url: str, *, log_ctx: str) -> Tuple[int, Any, str]:
    """TMDB GET wrapper.

    - Requires TMDB_API_KEY; if missing, disables alias fetching for 30 min.
    - Uses shared HTTP client + retry wrapper.
    - Circuit-breaks for auth errors / rate limiting.
    """

    if _disabled():
        return 0, None, f"alias_disabled:{_ALIAS_DISABLE_REASON}"

    s = get_settings()
    api_key = str(getattr(s, "TMDB_API_KEY", "") or "").strip()
    if not api_key:
        _disable_for(30 * 60, "no_api_key")
        return 0, None, "no_api_key"

    params: Dict[str, Any] = {"api_key": api_key}
    client = await get_http_client()

    status, data, snip = await _http_get_json_with_retry(
        client,
        url,
        params=params,
        timeout=get_timeout(TimeoutCategory.TMDB_API),
        max_attempts=_TMDB_RETRY.max_retries,
        backoff=_TMDB_RETRY.backoff,
        log_ctx=log_ctx,
    )

    if status in (401, 403):
        _disable_for(30 * 60, f"http_{status}")
    elif status == 429:
        _disable_for(60, "rate_limited")

    return status, data, snip


async def _fetch_alt_titles(media_type: str, tmdb_id: int) -> List[str]:
    mt = _norm_media_type(media_type)
    url = get_tmdb_api_url(f"/{mt}/{tmdb_id}/alternative_titles")
    status, data, snip = await _tmdb_get_json(url, log_ctx=f"tmdb_alias_alt:{mt}")
    if status != 200:
        biz.warning(
            "TMDB 别名 alt 请求失败，状态码非 200",
            tmdb_id=tmdb_id,
            media_type=mt,
            status=status,
            snip=snip,
        )
        return []

    if not isinstance(data, dict):
        return []

    # TV typically: {"results": [...]}; Movie often: {"titles": [...]}
    rows = data.get("results") or data.get("titles") or []
    titles: List[str] = []
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        t = row.get("title") or row.get("name")
        if t:
            titles.append(str(t))
    return titles


async def _fetch_trans_titles(media_type: str, tmdb_id: int) -> List[str]:
    mt = _norm_media_type(media_type)
    url = get_tmdb_api_url(f"/{mt}/{tmdb_id}/translations")
    status, data, snip = await _tmdb_get_json(url, log_ctx=f"tmdb_alias_trans:{mt}")
    if status != 200:
        biz.warning(
            "TMDB 别名 trans 请求失败，状态码非 200",
            tmdb_id=tmdb_id,
            media_type=mt,
            status=status,
            snip=snip,
        )
        return []

    if not isinstance(data, dict):
        return []

    titles: List[str] = []
    for row in (data.get("translations") or []) or []:
        if not isinstance(row, dict):
            continue
        d = row.get("data") or {}
        if not isinstance(d, dict):
            continue

        # IMPORTANT:
        # Do NOT fall back to row["name"], that's commonly the language name ("English").
        if mt == "tv":
            t = d.get("name") or d.get("title")
        else:
            t = d.get("title") or d.get("name")

        if t:
            titles.append(str(t))

    return titles


async def fetch_tmdb_alias_titles(
    *,
    tmdb_id: int,
    media_type: str,
    lang: str = "en-US",
    # Kept for backward compatibility; current in-memory cache has its own TTL.
    cache_ttl: int = 24 * 3600,
) -> List[str]:
    # NOTE: keep lang in cache key for backward compatibility; responses may differ.
    mt = _norm_media_type(media_type)
    cache_key = (str(mt), int(tmdb_id), str(lang))
    cached = alias_cache_get(cache_key)
    if cached is not None:
        return cached

    aliases: Set[str] = set()

    try:
        alt = await _fetch_alt_titles(mt, int(tmdb_id))
        _extend(aliases, alt)
    except Exception as e:  # pragma: no cover
        biz.warning(
            "TMDB 别名 alt 获取失败",
            tmdb_id=tmdb_id,
            media_type=mt,
            error=str(e),
        )

    try:
        trans = await _fetch_trans_titles(mt, int(tmdb_id))
        _extend(aliases, trans)
    except Exception as e:  # pragma: no cover
        biz.warning(
            "TMDB 别名 trans 获取失败",
            tmdb_id=tmdb_id,
            media_type=mt,
            error=str(e),
        )

    out = sorted(aliases)
    alias_cache_put(cache_key, out)
    return out
