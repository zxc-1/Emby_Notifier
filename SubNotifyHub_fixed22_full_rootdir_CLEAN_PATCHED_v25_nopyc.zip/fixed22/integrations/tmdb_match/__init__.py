"""TMDB helpers package.

This package contains TMDB matching / guessing utilities.
Public API mirrors the former `tg_bot.tmdb_match` module surface.

Design goal:
- No star-imports.
- Explicit, stable public surface.
"""

from .tmdb_match import (
    Candidate,
    detect_tv_hint,
    extract_imdb_id_from_text,
    extract_tmdb_id_from_text,
    fetch_tmdb_alias_titles,
    fetch_tmdb_detail,
    fetch_tv_season_episode_count,
    find_by_external_id,
    guess_tmdb_from_filename,
    has_tv_hints,
    load_candidates_from_storage,
    make_series_fingerprints,
    make_title_fingerprint,
    normalize_title,
    parse_title_year_from_filename,
    score_candidate,
    score_candidate_meta,
    search_candidates_via_tmdb,
    should_auto_pick,
    dump_candidates_for_storage,
    IMDB_ID_RE,
    logger,
)

__all__ = [
    "Candidate",
    "IMDB_ID_RE",
    "detect_tv_hint",
    "dump_candidates_for_storage",
    "extract_imdb_id_from_text",
    "extract_tmdb_id_from_text",
    "fetch_tmdb_alias_titles",
    "fetch_tmdb_detail",
    "fetch_tv_season_episode_count",
    "find_by_external_id",
    "guess_tmdb_from_filename",
    "has_tv_hints",
    "load_candidates_from_storage",
    "logger",
    "make_title_fingerprint",
    "make_series_fingerprints",
    "normalize_title",
    "parse_title_year_from_filename",
    "score_candidate",
    "score_candidate_meta",
    "search_candidates_via_tmdb",
    "should_auto_pick",
]
