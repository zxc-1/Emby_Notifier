from __future__ import annotations

import asyncio
from dataclasses import dataclass
import hashlib
import json
import re
import time
from typing import Any, Dict, List, Optional, Tuple

from core.cache import TTLCache
from core.loop_local import loop_local
from core.logging import get_biz_logger
from ports.stores import get_kv_store, get_kv_store_async
from settings.timeouts import TimeoutCategory, get_timeout
from settings.retries import RetryCategory, get_retry_config
from settings.urls import get_tmdb_api_url

from .tmdb_match_core import (
    Candidate,
    async_request_with_retry,
    get_http_client,
    get_settings,
    log_fetch,
)

biz = get_biz_logger(__name__)

# Get default retry config for TMDB API
_TMDB_RETRY = get_retry_config(RetryCategory.EXTERNAL_SERVICE)

_YEAR_IN_TITLE_RE = re.compile(r"\((19\d{2}|20\d{2})\)")


_DETAIL_CACHE: TTLCache[tuple, object] = TTLCache(maxsize=2048, default_ttl=86400)  # 24h
_HTTP_RAW_CACHE: TTLCache[tuple, object] = TTLCache(maxsize=1024, default_ttl=60)
_SEASON_CACHE: TTLCache[tuple, object] = TTLCache(maxsize=4096, default_ttl=86400)  # 24h


@dataclass
class _LoopState:
    inflight: Dict[tuple, asyncio.Future]
    inflight_lock: asyncio.Lock
    sem: Optional[asyncio.Semaphore] = None
    sem_n: int = 0


def _state() -> _LoopState:
    return loop_local(
        "tg_bot:tmdb_client_state",
        lambda: _LoopState(inflight={}, inflight_lock=asyncio.Lock()),
    )


def _get_tmdb_http_sem() -> asyncio.Semaphore:
    st = _state()
    s = get_settings()
    try:
        n = int(getattr(s, "TMDB_HTTP_CONCURRENCY", 10) or 10)
    except (ValueError, TypeError, AttributeError):
        biz.detail(
            "ℹ️ [TMDB客户端]HTTP 并发数配置读取失败：无法读取 TMDB HTTP 并发数配置。"
            "可能原因：配置项缺失、配置值类型错误、或 settings 对象访问失败。"
            "影响：使用默认值 10,可能影响 TMDB API 请求的并发性能",
            exc_info=True
        )
        n = 10
    n = max(1, min(32, n))
    if st.sem is None or st.sem_n != n:
        st.sem = asyncio.Semaphore(n)
        st.sem_n = n
    return st.sem


def _candidate_from_mapping(obj: Any) -> Optional[Candidate]:
    if not isinstance(obj, dict):
        return None
    try:
        tid = obj.get("tmdb_id", None)
        if tid is None:
            tid = obj.get("id", None)
        tid = int(tid) if tid is not None else 0
        if tid <= 0:
            return None

        mt = str(obj.get("media_type") or obj.get("mt") or "").strip() or "movie"
        title = str(obj.get("title") or obj.get("name") or "").strip()
        if not title:
            return None

        y = obj.get("year", None)
        if isinstance(y, str):
            y = int(y) if y.isdigit() else None
        elif not isinstance(y, int):
            y = None

        rating = obj.get("rating", None)
        if rating is not None:
            try:
                rating = float(rating)
            except (ValueError, TypeError):
                biz.detail(
                    "ℹ️ [TMDB客户端]评分转换失败：无法将评分值转换为浮点数。"
                    "可能原因：评分值格式异常、包含非数字字符、或数据类型错误。"
                    "影响：该候选的评分信息将被忽略",
                    raw_value=repr(rating),
                    exc_info=True
                )
                rating = None

        vote_count = obj.get("vote_count", None)
        if vote_count is not None:
            try:
                vote_count = int(vote_count)
            except (ValueError, TypeError):
                biz.detail(
                    "ℹ️ [TMDB客户端]投票数转换失败：无法将投票数转换为整数。"
                    "可能原因：投票数格式异常、包含非数字字符、或数据类型错误。"
                    "影响：该候选的投票数信息将被忽略",
                    raw_value=repr(vote_count),
                    exc_info=True
                )
                vote_count = None

        score = obj.get("score", None)
        if score is not None:
            try:
                score = float(score)
            except (ValueError, TypeError):
                biz.detail(
                    "ℹ️ [TMDB客户端]score 转换失败：无法将匹配分数转换为浮点数。"
                    "可能原因：分数值格式异常、包含非数字字符、或数据类型错误。"
                    "影响：该候选的匹配分数将被忽略",
                    raw_value=repr(score),
                    exc_info=True
                )
                score = None

        extra = obj.get("extra", None)
        if extra is not None and not isinstance(extra, dict):
            extra = None

        return Candidate(
            tmdb_id=tid,
            media_type=mt,
            title=title,
            year=y,
            rating=rating,
            vote_count=vote_count,
            score=score,
            extra=extra,
        )
    except (ValueError, TypeError, KeyError, AttributeError):
        biz.detail(
            "ℹ️ [TMDB客户端]Candidate 对象创建失败：无法从映射数据创建候选对象。"
            "可能原因：数据结构不完整、必需字段缺失、或字段类型错误。"
            "影响：该候选将被跳过,不会出现在搜索结果中",
            tmdb_id=obj.get("tmdb_id"),
            title=obj.get("title"),
            exc_info=True
        )
        return None


def _db_cache_key(*parts: Any) -> str:
    """Stable key for persistent kv_cache."""

    def _to_jsonable(x: Any) -> Any:
        try:
            if x is None or isinstance(x, (str, int, float, bool)):
                return x
            if isinstance(x, (list, tuple)):
                return [_to_jsonable(i) for i in x]
            if isinstance(x, dict):
                return {str(k): _to_jsonable(v) for k, v in sorted(x.items(), key=lambda kv: str(kv[0]))}
            if hasattr(x, "model_dump"):
                try:
                    return _to_jsonable(x.model_dump())
                except (ValueError, TypeError, AttributeError):
                    biz.detail(
                        "ℹ️ [TMDB客户端]model_dump 转换失败：无法将对象转换为字典。"
                        "可能原因：对象不支持 model_dump 方法、方法调用失败、或返回值异常。"
                        "影响：使用字符串表示代替,可能影响缓存键的准确性",
                        type=type(x).__name__,
                        exc_info=True
                    )
                    pass
            return str(x)
        except (ValueError, TypeError):
            biz.detail(
                "ℹ️ [TMDB客户端]对象转字符串失败：无法将对象转换为可序列化的字符串。"
                "可能原因：对象类型不支持序列化、包含循环引用、或转换逻辑错误。"
                "影响：使用 repr 表示代替,可能影响缓存键的稳定性",
                type=type(x).__name__,
                exc_info=True
            )
            return repr(x)

    payload = _to_jsonable(list(parts))
    raw = json.dumps(payload, ensure_ascii=False, separators=(",", ":"), sort_keys=True, default=str)
    h = hashlib.sha1(raw.encode("utf-8")).hexdigest()
    return "tmdb:" + h


async def _db_get_json(key: str) -> Any:
    kv = get_kv_store_async()
    try:
        await kv.purge_expired()
    except (OSError, RuntimeError, ValueError, TypeError):
        biz.detail(
            "ℹ️ [TMDB客户端]tmdb kv_cache purge_expired 失败：无法清理过期的 KV 缓存。"
            "可能原因：文件系统错误、权限不足、或缓存存储异常。"
            "影响：过期缓存可能未被清理,占用存储空间",
            key=key,
            exc_info=True,
        )
    try:
        return await kv.get_json(key)
    except (OSError, RuntimeError, ValueError, TypeError, KeyError):
        biz.detail(
            "ℹ️ [TMDB客户端]tmdb kv_cache get 失败：无法从 KV 缓存中读取数据。"
            "可能原因：缓存键不存在、文件系统错误、或数据反序列化失败。"
            "影响：将从 TMDB API 重新获取数据",
            key=key,
            exc_info=True,
        )
        return None

async def _db_set_json(key: str, value: Any, *, ttl: int | None = None) -> None:
    kv = get_kv_store_async()
    try:
        await kv.set_json(key, value, ttl_sec=int(ttl) if ttl is not None else None)
    except (OSError, RuntimeError, ValueError, TypeError):
        biz.detail(
            "ℹ️ [TMDB客户端]tmdb kv_cache set 失败：无法将数据写入 KV 缓存。"
            "可能原因：文件系统错误、权限不足、磁盘空间不足、或数据序列化失败。"
            "影响：下次查询将无法使用缓存,需要重新请求 TMDB API",
            key=key,
            exc_info=True,
        )
        return
    try:
        await kv.purge_expired()
    except (OSError, RuntimeError, ValueError, TypeError):
        biz.detail(
            "ℹ️ [TMDB客户端]tmdb kv_cache purge_expired 失败（set 后）：无法在写入后清理过期缓存。"
            "可能原因：文件系统错误、权限不足、或缓存存储异常。"
            "影响：过期缓存可能未被清理,占用存储空间",
            key=key,
            exc_info=True,
        )

async def _http_get_json_with_retry(
    client,
    url: str,
    *,
    params: Dict[str, Any],
    timeout: float = 8.0,
    max_attempts: int = 3,
    backoff: Tuple[float, float] = (0.0, 1.0),
    log_ctx: str = "tmdb",
) -> Tuple[int, Any, str]:
    """HTTP GET with retry, in-flight de-dup and a tiny raw cache."""
    cache_key = (url, tuple(sorted((params or {}).items())))
    cached = _HTTP_RAW_CACHE.get(cache_key)
    if isinstance(cached, tuple) and len(cached) == 3:
        try:
            return int(cached[0]), cached[1], str(cached[2] or "")
        except (ValueError, TypeError, IndexError):
            biz.detail(
                "ℹ️ [TMDB客户端]缓存数据解析失败：无法解析 HTTP 原始缓存中的数据。"
                "可能原因：缓存数据结构异常、数据类型错误、或索引越界。"
                "影响：忽略缓存数据,重新发起 HTTP 请求",
                cache_value=repr(cached),
                exc_info=True
            )
            pass

    st = _state()
    sem = _get_tmdb_http_sem()

    async with st.inflight_lock:
        fut = st.inflight.get(cache_key)
        if fut is not None and not fut.done():
            try:
                r = await fut
                if isinstance(r, tuple) and len(r) == 3:
                    return int(r[0]), r[1], str(r[2] or "")
            except (ValueError, TypeError, IndexError, asyncio.CancelledError):
                biz.detail(
                    "ℹ️ [TMDB客户端]DB 缓存数据解析失败：无法解析正在进行的请求返回的缓存数据。"
                    "可能原因：数据结构异常、数据类型错误、索引越界、或请求被取消。"
                    "影响：忽略该缓存数据,继续发起新的 HTTP 请求",
                    data=repr(r),
                    exc_info=True
                )
                pass

        loop = asyncio.get_running_loop()
        fut = loop.create_future()
        st.inflight[cache_key] = fut

    async def _do() -> Tuple[int, Any, str]:
        async with sem:
            try:
                resp = await async_request_with_retry(
                    client,
                    "GET",
                    url,
                    params=params,
                    timeout=timeout,
                    max_attempts=max_attempts,
                    backoff=backoff,
                )
            except Exception as e:
                return 0, None, (str(e) or type(e).__name__)
        try:
            status = int(getattr(resp, "status_code", 0) or 0)
        except (ValueError, TypeError, AttributeError):
            biz.detail(
                "ℹ️ [TMDB客户端]HTTP 状态码读取失败：无法从 HTTP 响应中提取状态码。"
                "可能原因：响应对象结构异常、属性访问失败、或数据类型转换错误。"
                "影响：将状态码视为 0,该请求会被视为失败",
                exc_info=True
            )
            status = 0
        try:
            data = resp.json() if status == 200 else None
        except (ValueError, TypeError, json.JSONDecodeError):
            biz.detail(
                "ℹ️ [TMDB客户端]JSON 解析失败：无法将 HTTP 响应解析为 JSON 格式。"
                "可能原因：响应内容不是有效的 JSON、编码错误、或响应被截断。"
                "影响：该请求返回空数据,可能影响 TMDB 信息获取",
                status=status,
                exc_info=True
            )
            data = None
        try:
            body = (getattr(resp, "text", "") or "")
        except (ValueError, TypeError, AttributeError):
            biz.detail(
                "ℹ️ [TMDB客户端]响应文本读取失败：无法从 HTTP 响应中提取文本内容。"
                "可能原因：响应对象结构异常、文本编码错误、或属性访问失败。"
                "影响：无法记录响应内容摘要,但不影响数据解析",
                exc_info=True
            )
            body = ""
        snip = body[:180].replace("\n", " ") if body else ""
        return status, data, snip

    try:
        r = await _do()
        try:
            _HTTP_RAW_CACHE.set(cache_key, r, ttl=60)
        except (ValueError, TypeError):
            biz.detail(
                "ℹ️ [TMDB客户端]HTTP 原始缓存写入失败：无法将 HTTP 响应写入原始缓存。"
                "可能原因：缓存数据结构异常、序列化失败、或缓存容量已满。"
                "影响：下次相同请求无法使用缓存,需要重新请求 TMDB API",
                cache_key=str(cache_key),
                exc_info=True
            )
            pass
        fut.set_result(r)
        return r
    except Exception as e:
        try:
            fut.set_exception(e)
        except (asyncio.InvalidStateError, RuntimeError):
            biz.detail(
                "ℹ️ [TMDB客户端]future 异常设置失败：无法将异常设置到 Future 对象。"
                "可能原因：Future 已经完成、状态不一致、或并发访问冲突。"
                "影响：其他等待该请求的协程可能无法收到异常通知",
                error=type(e).__name__,
                exc_info=True
            )
            pass
        return 0, None, (str(e) or type(e).__name__)
    finally:
        async with st.inflight_lock:
            st.inflight.pop(cache_key, None)


async def fetch_tmdb_detail(
    tmdb_id: int,
    *,
    prefer_media_type: Optional[str] = None,
    language: Optional[str] = None,
    region: Optional[str] = None,
) -> Optional[Dict[str, Any]]:
    try:
        tid = int(tmdb_id)
    except (ValueError, TypeError):
        biz.detail(
            "ℹ️ [TMDB客户端]tmdb_detail 无效的 tid：无法将 TMDB ID 转换为整数。"
            "可能原因：TMDB ID 格式错误、包含非数字字符、或数据类型异常。"
            "影响：无法获取该 TMDB 条目的详细信息",
            tmdb_id=repr(tmdb_id),
            exc_info=True
        )
        return None
    if tid <= 0:
        return None

    s = get_settings()
    api_key = str(getattr(s, "TMDB_API_KEY", "") or "").strip()
    if not api_key:
        return None

    lang = str((language or getattr(s, "TMDB_LANGUAGE", "zh-CN")) or "zh-CN")
    region = str((region or getattr(s, "TMDB_REGION", "CN")) or "CN")

    try:
        _v = getattr(s, "TMDB_DETAIL_CACHE_TTL", None)
        if _v is None:
            _v = getattr(s, "TMDB_CACHE_TTL", 86400)
        ttl_d = int(_v or 86400)
    except (ValueError, TypeError, AttributeError):
        biz.detail(
            "ℹ️ [TMDB客户端]detail cache TTL 配置读取失败：无法读取详情缓存 TTL 配置。"
            "可能原因：配置项缺失、配置值类型错误、或 settings 对象访问失败。"
            "影响：使用默认值 86400 秒（24小时）",
            exc_info=True
        )
        ttl_d = 86400

    # IMPORTANT: TMDB movie IDs and TV IDs are in *different* namespaces.
    # A numeric tmdb_id may exist for both movie and tv. Therefore, detail
    # cache keys MUST include media_type, otherwise cross-type pollution
    # will happen (e.g. caching movie detail then reading it back for tv).

    def _mk_keys(mt: str) -> tuple[tuple[Any, ...], str]:
        cache_key = ("detail", mt, tid, lang, region)
        db_key = _db_cache_key("detail", mt, tid, lang, region)
        return cache_key, db_key

    async def _get(mt: str) -> Optional[Dict[str, Any]]:
        url = get_tmdb_api_url(f"/{mt}/{tid}")
        params = {"api_key": api_key, "language": lang, "region": region}
        client = await get_http_client()
        log_fetch(biz, "tmdb_detail", step="tmdb_detail", phase="fetch", mt=mt, tid=tid)
        status, data, body_snip = await _http_get_json_with_retry(
            client,
            url,
            params=params,
            timeout=get_timeout(TimeoutCategory.TMDB_API),
            max_attempts=_TMDB_RETRY.max_retries,
            backoff=_TMDB_RETRY.backoff,
            log_ctx=f"tmdb_detail:{mt}",
        )
        if status != 200:
            biz.warning("TMDB detail 请求失败，状态码非 200", tid=tid, mt=mt, status=status, body_snip=body_snip)
            return None
        if not isinstance(data, dict):
            return None

        title = str(data.get("title") or data.get("name") or "").strip()
        if not title:
            return None
        original = str(data.get("original_title") or data.get("original_name") or "").strip()

        dt = str(data.get("release_date") or data.get("first_air_date") or "").strip()
        year = None
        if dt and len(dt) >= 4:
            try:
                year = int(dt[:4])
            except (ValueError, TypeError):
                biz.detail(
                    "ℹ️ [TMDB客户端]年份提取失败：无法从日期字符串中提取年份。"
                    "可能原因：日期格式异常、前4位不是数字、或数据类型错误。"
                    "影响：尝试从标题中提取年份,或使用空年份",
                    date_str=dt,
                    exc_info=True
                )
                year = None

        if year is None:
            # date 为空时，尝试从 title/original 里解析 \"(2026)\"
            try:
                m = _YEAR_IN_TITLE_RE.search(title)
                if (not m) and original:
                    m = _YEAR_IN_TITLE_RE.search(original)
                if m:
                    year = int(m.group(1))
            except (ValueError, TypeError, AttributeError):
                biz.detail(
                    "ℹ️ [TMDB客户端]年份正则提取失败：无法从标题中提取年份。"
                    "可能原因：正则表达式匹配失败、标题格式不符合预期、或数据类型错误。"
                    "影响：该条目将没有年份信息,可能影响匹配准确性",
                    title=title,
                    exc_info=True
                )
                pass

        rating = None
        try:
            rating = float(data.get("vote_average")) if data.get("vote_average") is not None else None
        except (ValueError, TypeError):
            biz.detail(
                "ℹ️ [TMDB客户端]评分转换失败：无法将评分值转换为浮点数。"
                "可能原因：评分值格式异常、包含非数字字符、或数据类型错误。"
                "影响：该条目的评分信息将被忽略",
                raw_value=repr(data.get('vote_average')),
                exc_info=True
            )
            rating = None
        vote_count = None
        try:
            vote_count = int(data.get("vote_count")) if data.get("vote_count") is not None else None
        except (ValueError, TypeError):
            biz.detail(
                "ℹ️ [TMDB客户端]投票数转换失败：无法将投票数转换为整数。"
                "可能原因：投票数格式异常、包含非数字字符、或数据类型错误。"
                "影响：该条目的投票数信息将被忽略",
                raw_value=repr(data.get('vote_count')),
                exc_info=True
            )
            vote_count = None

        return {
            "tmdb_id": tid,
            "media_type": mt,
            "title": title,
            "year": year,
            "original_title": original,
            "rating": rating,
            "vote_count": vote_count,
            "number_of_seasons": int(data.get("number_of_seasons") or 0) if mt == "tv" else None,
            "number_of_episodes": int(data.get("number_of_episodes") or 0) if mt == "tv" else None,
        }

    prefer = (prefer_media_type or "").strip().lower()
    order: List[str] = []
    if prefer in {"movie", "tv"}:
        order.append(prefer)
    order.extend(["tv", "movie"])

    seen: set[str] = set()
    for mt in order:
        if mt in seen:
            continue
        seen.add(mt)

        cache_key, db_key = _mk_keys(mt)

        # 1) In-memory cache (type-safe)
        cached = _DETAIL_CACHE.get(cache_key)
        if isinstance(cached, dict) and cached.get("tmdb_id"):
            return dict(cached)

        # 2) Persistent cache (type-safe)
        cached_db = await _db_get_json(db_key)
        if isinstance(cached_db, dict) and cached_db.get("tmdb_id"):
            try:
                _DETAIL_CACHE.set(cache_key, dict(cached_db), ttl=ttl_d)
            except (ValueError, TypeError):
                biz.detail(
                    "ℹ️ [TMDB客户端]detail cache 写入失败：无法将详情数据写入内存缓存。"
                    "可能原因：缓存数据结构异常、序列化失败、或缓存容量已满。"
                    "影响：下次查询无法使用内存缓存,需要从 KV 存储或 API 获取",
                    cache_key=str(cache_key),
                    exc_info=True,
                )
            return dict(cached_db)

        try:
            out = await _get(mt)
        except (httpx.HTTPError, OSError, asyncio.TimeoutError, RuntimeError):
            biz.detail(
                "ℹ️ [TMDB客户端]tmdb_detail 请求失败：无法从 TMDB API 获取详情数据。"
                "可能原因：网络连接异常、TMDB API 暂时不可用、请求超时、或 API 密钥无效。"
                "影响：尝试其他媒体类型或返回空结果",
                tid=tid,
                mt=mt,
                exc_info=True
            )
            out = None
        if out:
            try:
                _DETAIL_CACHE.set(cache_key, dict(out), ttl=ttl_d)
            except (ValueError, TypeError):
                biz.detail(
                    "ℹ️ [TMDB客户端]detail cache 写入失败：无法将详情数据写入内存缓存。"
                    "可能原因：缓存数据结构异常、序列化失败、或缓存容量已满。"
                    "影响：下次查询无法使用内存缓存,需要从 KV 存储或 API 获取",
                    cache_key=str(cache_key),
                    exc_info=True
                )
                pass
            try:
                await _db_set_json(db_key, dict(out), ttl=ttl_d)
            except (OSError, RuntimeError, ValueError, TypeError):
                biz.detail(
                    "ℹ️ [TMDB客户端]detail DB 缓存写入失败：无法将详情数据写入 KV 存储。"
                    "可能原因：文件系统错误、权限不足、磁盘空间不足、或数据序列化失败。"
                    "影响：下次查询无法使用持久化缓存,需要重新请求 TMDB API",
                    db_key=db_key,
                    exc_info=True
                )
                pass
            return out

    return None


async def find_by_external_id(external_id: str, *, external_source: str = "imdb_id") -> List[Candidate]:
    eid = str(external_id or "").strip()
    if not eid:
        return []
    s = get_settings()
    api_key = str(getattr(s, "TMDB_API_KEY", "") or "").strip()
    if not api_key:
        return []

    url = get_tmdb_api_url(f"/find/{eid}")
    params = {
        "api_key": api_key,
        "external_source": external_source,
        "language": getattr(s, "TMDB_LANGUAGE", "zh-CN"),
        "region": getattr(s, "TMDB_REGION", "CN"),
    }
    try:
        _v = getattr(s, "TMDB_FIND_CACHE_TTL", None)
        if _v is None:
            _v = getattr(s, "TMDB_CACHE_TTL", 604800)
        ttl_f = int(_v or 604800)
    except (ValueError, TypeError, AttributeError):
        biz.detail(
            "ℹ️ [TMDB客户端]find cache TTL 配置读取失败：无法读取外部 ID 查找缓存 TTL 配置。"
            "可能原因：配置项缺失、配置值类型错误、或 settings 对象访问失败。"
            "影响：使用默认值 604800 秒（7天）",
            exc_info=True
        )
        ttl_f = 604800

    db_key = _db_cache_key("find", external_source, eid.lower(), params.get("language"), params.get("region"))
    cached_db = await _db_get_json(db_key)
    if isinstance(cached_db, list) and cached_db:
        out_db: List[Candidate] = []
        for it in cached_db:
            if not isinstance(it, dict):
                continue
            try:
                out_db.append(Candidate(**it))
            except (ValueError, TypeError, KeyError):
                biz.detail(
                    "ℹ️ [TMDB客户端]Candidate 对象创建失败：无法从缓存数据创建候选对象。"
                    "可能原因：缓存数据结构不完整、必需字段缺失、或字段类型错误。"
                    "影响：该候选将被跳过,继续处理其他候选",
                    data=repr(it),
                    exc_info=True
                )
                continue
        if out_db:
            return out_db

    client = await get_http_client()
    status, data, _ = await _http_get_json_with_retry(
        client,
        url,
        params=params,
        timeout=get_timeout(TimeoutCategory.TMDB_API),
        max_attempts=_TMDB_RETRY.max_retries,
        backoff=_TMDB_RETRY.backoff,
        log_ctx="tmdb_find",
    )
    if status != 200 or not isinstance(data, dict):
        return []

    out: List[Candidate] = []

    def _emit(items: Any, mt: str) -> None:
        if not isinstance(items, list):
            return
        for it in items[:8]:
            if not isinstance(it, dict):
                continue
            try:
                tid = int(it.get("id"))
            except (ValueError, TypeError):
                biz.detail(
                    "ℹ️ [TMDB客户端]tmdb id 转换失败：无法将 TMDB ID 转换为整数。"
                    "可能原因：ID 格式错误、包含非数字字符、或数据类型异常。"
                    "影响：该条目将被跳过,不会出现在查找结果中",
                    raw_value=repr(it.get('id')),
                    exc_info=True
                )
                continue
            name = str(it.get("title") or it.get("name") or "").strip()
            if not name:
                continue
            dt = str(it.get("release_date") or it.get("first_air_date") or "").strip()
            year = None
            if dt and len(dt) >= 4:
                try:
                    year = int(dt[:4])
                except (ValueError, TypeError):
                    biz.detail(
                        "ℹ️ [TMDB客户端]年份提取失败：无法从日期字符串中提取年份。"
                        "可能原因：日期格式异常、前4位不是数字、或数据类型错误。"
                        "影响：该条目将没有年份信息,可能影响匹配准确性",
                        date_str=dt,
                        exc_info=True
                    )
                    year = None
            rating = None
            try:
                rating = float(it.get("vote_average")) if it.get("vote_average") is not None else None
            except (ValueError, TypeError):
                biz.detail(
                    "ℹ️ [TMDB客户端]评分转换失败：无法将评分值转换为浮点数。"
                    "可能原因：评分值格式异常、包含非数字字符、或数据类型错误。"
                    "影响：该条目的评分信息将被忽略",
                    raw_value=repr(it.get('vote_average')),
                    exc_info=True
                )
                rating = None
            vote_count = None
            try:
                vote_count = int(it.get("vote_count")) if it.get("vote_count") is not None else None
            except (ValueError, TypeError):
                biz.detail(
                    "ℹ️ [TMDB客户端]投票数转换失败：无法将投票数转换为整数。"
                    "可能原因：投票数格式异常、包含非数字字符、或数据类型错误。"
                    "影响：该条目的投票数信息将被忽略",
                    raw_value=repr(it.get('vote_count')),
                    exc_info=True
                )
                vote_count = None
            out.append(
                Candidate(
                    tmdb_id=tid,
                    media_type=mt,
                    title=name,
                    year=year,
                    rating=rating,
                    vote_count=vote_count,
                    extra=it,
                )
            )

    _emit(data.get("movie_results"), "movie")
    _emit(data.get("tv_results"), "tv")

    try:
        await _db_set_json(db_key, [c.__dict__ for c in out], ttl=ttl_f)
    except (OSError, RuntimeError, ValueError, TypeError):
        biz.detail(
            "ℹ️ [TMDB客户端]find DB 缓存写入失败：无法将外部 ID 查找结果写入 KV 存储。"
            "可能原因：文件系统错误、权限不足、磁盘空间不足、或数据序列化失败。"
            "影响：下次查询无法使用持久化缓存,需要重新请求 TMDB API",
            db_key=db_key,
            exc_info=True
        )
        pass

    return out


async def fetch_tv_season_episode_count(
    tv_id: int,
    season_number: int,
    *,
    language: Optional[str] = None,
    region: Optional[str] = None,
) -> Optional[int]:
    """Fetch a TV season's episode count.

    This is intentionally light-weight and cached, because share-resolver may
    enrich top-K candidates to compute an episode-consistency score.
    """

    try:
        tid = int(tv_id)
        s_no = int(season_number)
    except (ValueError, TypeError):
        return None
    if tid <= 0 or s_no <= 0 or s_no > 200:
        return None

    lang = str(language or getattr(get_settings(), "TMDB_LANGUAGE", "") or "").strip() or None
    reg = str(region or getattr(get_settings(), "TMDB_REGION", "") or "").strip() or None

    ck = ("tv_season_eps", tid, s_no, lang, reg)
    try:
        cached = _SEASON_CACHE.get(ck)
        if cached is not None:
            return int(cached) if cached not in (None, "") else None
    except (ValueError, TypeError, KeyError):
        biz.detail(
            "ℹ️ [TMDB客户端]season cache 读取失败：无法从内存缓存中读取剧集季度集数。"
            "可能原因：缓存键不存在、数据类型转换失败、或缓存数据损坏。"
            "影响：将尝试从 KV 存储或 TMDB API 获取数据,性能略有下降",
            cache_key=ck,
            exc_info=True
        )

    # also cache in kv store for cross-process reuse
    kv = get_kv_store_async()
    kv_key = None
    try:
        kv_key = f"tmdb:tv:{tid}:season:{s_no}:eps:{lang or '-'}:{reg or '-'}"
        v_db = await kv.get_json(kv_key)
        if v_db is not None:
            try:
                v_db_i = int(v_db)
                _SEASON_CACHE.set(ck, v_db_i)
                return v_db_i
            except (ValueError, TypeError):
                pass
    except (OSError, RuntimeError, ValueError, TypeError, KeyError):
        biz.detail(
            "ℹ️ [TMDB客户端]season kv cache 读取失败：无法从 KV 存储中读取剧集季度集数。"
            "可能原因：文件系统错误、权限不足、数据格式异常、或键不存在。"
            "影响：将直接请求 TMDB API 获取数据,增加网络开销",
            kv_key=kv_key,
            exc_info=True
        )

    s = get_settings()
    api_key = str(getattr(s, "TMDB_API_KEY", "") or "").strip()
    if not api_key:
        return None

    params: Dict[str, Any] = {"api_key": api_key}
    if lang:
        params["language"] = lang
    if reg:
        params["region"] = reg

    # /tv/{tv_id}/season/{season_number}
    url = get_tmdb_api_url(f"/tv/{tid}/season/{s_no}")

    # Dedup inflight requests per-loop to avoid bursts.
    st = _state()
    async with st.inflight_lock:
        fut = st.inflight.get(ck)
        if fut is not None:
            try:
                v = await fut
                return int(v) if v is not None else None
            except (ValueError, TypeError, asyncio.CancelledError):
                return None
        loop = asyncio.get_running_loop()
        fut = loop.create_future()
        st.inflight[ck] = fut

    try:
        sem = _get_tmdb_http_sem()
        async with sem:
            data = await async_request_with_retry(url, params=params, timeout=get_timeout(TimeoutCategory.TMDB_API))
        if not isinstance(data, dict):
            return None
        # TMDB season payload contains either 'episodes' array or 'episode_count'
        tot = None
        if data.get("episode_count") not in (None, ""):
            try:
                tot = int(data.get("episode_count"))
            except (ValueError, TypeError):
                tot = None
        if tot is None:
            eps = data.get("episodes")
            if isinstance(eps, list):
                tot = len(eps)
        if tot is None or tot <= 0:
            return None
        _SEASON_CACHE.set(ck, int(tot))
        if kv_key:
            try:
                await kv.set_json(kv_key, int(tot), ttl_sec=86400)
            except (OSError, RuntimeError, ValueError, TypeError):
                biz.detail(
                    "ℹ️ [TMDB客户端]season kv cache 写入失败：无法将剧集季度集数写入 KV 存储。"
                    "可能原因：文件系统错误、权限不足、磁盘空间不足、或数据序列化失败。"
                    "影响：下次查询无法使用持久化缓存,需要重新请求 TMDB API",
                    kv_key=kv_key,
                    episode_count=tot,
                    exc_info=True
                )
        return int(tot)
    except (httpx.HTTPError, OSError, asyncio.TimeoutError, RuntimeError, ValueError, TypeError):
        biz.detail(
            "ℹ️ [TMDB客户端]fetch_tv_season_episode_count 失败：无法获取剧集季度的集数信息。"
            "可能原因：网络连接失败、TMDB API 超时、API 响应格式异常、或数据解析错误。"
            "影响：无法获取该季度的集数,可能影响剧集匹配的准确性",
            tv_id=tid,
            season_number=s_no,
            exc_info=True
        )
        return None
    finally:
        try:
            if fut is not None and not fut.done():
                fut.set_result(_SEASON_CACHE.get(ck))
        except (asyncio.InvalidStateError, RuntimeError):
            pass
        try:
            async with st.inflight_lock:
                st.inflight.pop(ck, None)
        except (RuntimeError, KeyError):
            pass
