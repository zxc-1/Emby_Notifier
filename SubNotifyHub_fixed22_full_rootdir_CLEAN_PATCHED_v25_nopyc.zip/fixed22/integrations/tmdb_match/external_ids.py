from __future__ import annotations

from typing import Optional

from .tmdb_match_core import IMDB_ID_RE


def extract_imdb_id_from_text(s: str) -> Optional[str]:
    """Extract imdb id (tt1234567/tt12345678) from any text."""
    if not isinstance(s, str) or not s:
        return None
    m = IMDB_ID_RE.search(s)
    if not m:
        return None
    return m.group(1).lower()
