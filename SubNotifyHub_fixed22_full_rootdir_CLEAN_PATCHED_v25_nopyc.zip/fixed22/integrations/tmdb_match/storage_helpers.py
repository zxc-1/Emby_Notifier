"""Storage helpers for TMDB candidate persistence.

The forward_bridge layer persists candidate lists in KV storage (for audit,
debugging, and "ask user to pick" UX). These helpers maintain compatibility
with 1.5.x behavior.
"""
from __future__ import annotations

import json
from typing import Any, Dict, List

from core.logging import get_biz_logger

biz = get_biz_logger(__name__)


def dump_candidates_for_storage(cands: List[Dict[str, Any]]) -> str:
    """Serialize candidates for persistence.

    Keep 1.5.x behavior: JSON array, utf-8 (ensure_ascii=False).
    Never raises.
    
    Args:
        cands: List of candidate dictionaries
        
    Returns:
        JSON string representation
    """
    try:
        return json.dumps(cands or [], ensure_ascii=False)
    except (ValueError, TypeError):
        biz.fail("TMDB 候选列表序列化失败", exc_info=True)
        return "[]"


def load_candidates_from_storage(s: str) -> List[Dict[str, Any]]:
    """Deserialize candidates from persistence.

    Keep 1.5.x behavior. Never raises.
    
    Args:
        s: JSON string to parse
        
    Returns:
        List of candidate dictionaries
    """
    try:
        data = json.loads(s or "[]")
        return data if isinstance(data, list) else []
    except (ValueError, TypeError, json.JSONDecodeError):
        biz.fail("TMDB 候选列表反序列化失败", exc_info=True)
        return []
