"""External ID recall for ambiguous / collision-prone titles.

Used as an optional fallback when TMDB search recall is low quality:
  title/year -> (IMDb tt... or derived via Douban) -> TMDB /find -> direct hit

Design goals:
  - Optional (feature flag)
  - Cheap: only runs when pool is low quality
  - Cached (in-memory TTL)
  - Robust: failures are swallowed with clear logs
"""

from __future__ import annotations

import re
import urllib.parse
from typing import Optional, Tuple

from core.cache.ttl_cache import TTLCache
from core.http import get_http_client, async_request_with_retry_json
from core.logging import get_biz_logger_adapter
from ports.settings_provider import get_settings

from douban_hotlist.client import fetch_json as douban_fetch_json, fetch_text as douban_fetch_text
from douban_hotlist.parser import extract_imdb_id_from_html

logger = get_biz_logger_adapter(__name__)

_IMDB_ID_RE = re.compile(r"(?i)\b(tt\d{7,9})\b")

# Small in-memory cache (key -> imdb_id)
_cache = TTLCache(maxsize=4096, default_ttl=30 * 24 * 3600)


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", str(s or "").strip()).lower()


def _ck(provider: str, title: str, year: Optional[int]) -> str:
    y = str(int(year)) if isinstance(year, int) else ""
    return f"extid:{provider}:{_norm(title)}:{y}"


def _cache_get(provider: str, title: str, year: Optional[int]) -> str:
    try:
        return str(_cache.get(_ck(provider, title, year)) or "").strip()
    except Exception as e:
        logger.detail(f"external id cache get 失败（已忽略） - 原因={type(e).__name__}")
        return ""


def _cache_set(provider: str, title: str, year: Optional[int], imdb_id: str) -> None:
    try:
        v = str(imdb_id or "").strip().lower()
        if v:
            _cache.set(_ck(provider, title, year), v)
    except Exception as e:
        logger.detail(f"external id cache set 失败（已忽略） - 原因={type(e).__name__}")


async def resolve_imdb_via_imdb_suggest(title: str, year: Optional[int]) -> Optional[str]:
    """Resolve IMDb tt-id via IMDb suggestion endpoint."""
    t = str(title or "").strip()
    if not t:
        return None

    cached = _cache_get("imdb_suggest", t, year)
    if cached:
        return cached

    q = _norm(t)
    if not q:
        return None

    first = q[0]
    url = f"https://v3.sg.media-imdb.com/suggestion/{first}/{urllib.parse.quote(q)}.json"

    s = get_settings()
    timeout = float(getattr(s, "TMDB_EXTERNAL_ID_RECALL_TIMEOUT_SEC", 6) or 6)

    cl = await get_http_client()
    status, obj, snip = await async_request_with_retry_json(
        cl,
        "GET",
        url,
        headers={
            "Accept": "application/json",
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120 Safari/537.36",
        },
        timeout=timeout,
        max_attempts=2,
        backoff=(0.25, 1.0),
        log_ctx="imdb_suggest",
        text_snip_len=200,
    )

    if int(status) < 200 or int(status) >= 300 or not isinstance(obj, dict):
        logger.detail(f"IMDb Suggest：HTTP 响应非 2xx 或 JSON 无效 - status={status} snip={snip}")
        return None

    items = obj.get("d")
    if not isinstance(items, list) or not items:
        return None

    best_tt: Optional[str] = None
    best_score = -1.0

    q_tokens = set(_norm(t).split())

    for it in items:
        if not isinstance(it, dict):
            continue
        tt = str(it.get("id") or "").strip().lower()
        if not _IMDB_ID_RE.match(tt):
            continue
        it_year = it.get("y")
        it_title = str(it.get("l") or "").strip()
        if not it_title:
            continue

        score = 0.0
        if isinstance(year, int) and isinstance(it_year, int) and it_year == year:
            score += 2.0
        it_tokens = set(_norm(it_title).split())
        if q_tokens and it_tokens:
            score += len(q_tokens & it_tokens) / max(1, len(q_tokens))

        if score > best_score:
            best_score = score
            best_tt = tt

    if best_tt:
        _cache_set("imdb_suggest", t, year, best_tt)
    return best_tt


async def resolve_imdb_via_douban_suggest(title: str, year: Optional[int]) -> Optional[str]:
    """Resolve IMDb tt-id via Douban subject suggest -> subject page -> IMDb field."""
    t = str(title or "").strip()
    if not t:
        return None

    cached = _cache_get("douban_suggest", t, year)
    if cached:
        return cached

    status, obj, _snip = await douban_fetch_json(
        "https://movie.douban.com/j/subject_suggest",
        params={"q": t},
        headers={"Referer": "https://movie.douban.com/"},
        timeout=float(getattr(get_settings(), "TMDB_EXTERNAL_ID_RECALL_TIMEOUT_SEC", 6) or 6),
    )
    if int(status) < 200 or int(status) >= 300 or not isinstance(obj, list) or not obj:
        return None

    best_sid: Optional[str] = None
    best_score = -1.0
    q_tokens = set(_norm(t).split())

    for it in obj:
        if not isinstance(it, dict):
            continue
        sid = str(it.get("id") or "").strip()
        if not sid.isdigit():
            continue
        it_year = str(it.get("year") or "").strip()
        it_title = str(it.get("title") or "").strip()
        it_sub = str(it.get("sub_title") or "").strip()

        score = 0.0
        if isinstance(year, int) and it_year.isdigit() and int(it_year) == year:
            score += 2.0

        probe = it_sub or it_title
        p_tokens = set(_norm(probe).split())
        if q_tokens and p_tokens:
            score += len(q_tokens & p_tokens) / max(1, len(q_tokens))

        if score > best_score:
            best_score = score
            best_sid = sid

    if not best_sid:
        return None

    html = await douban_fetch_text(f"https://movie.douban.com/subject/{best_sid}/", timeout=float(getattr(get_settings(), "TMDB_EXTERNAL_ID_RECALL_TIMEOUT_SEC", 6) or 6))
    if not html:
        return None

    imdb = str(extract_imdb_id_from_html(html) or "").strip().lower()
    if not _IMDB_ID_RE.match(imdb):
        return None

    _cache_set("douban_suggest", t, year, imdb)
    return imdb


async def resolve_imdb_id(title: str, year: Optional[int]) -> Tuple[Optional[str], str]:
    """Resolve IMDb id using configured providers.

    Returns: (imdb_id or None, provider_name)
    """
    s = get_settings()
    providers = str(getattr(s, "TMDB_EXTERNAL_ID_RECALL_PROVIDERS", "imdb_suggest,douban_suggest") or "")
    order = [p.strip().lower() for p in providers.split(",") if p.strip()]

    for p in order:
        try:
            if p == "imdb_suggest":
                tt = await resolve_imdb_via_imdb_suggest(title, year)
                if tt:
                    return tt, "imdb_suggest"
            elif p == "douban_suggest":
                tt = await resolve_imdb_via_douban_suggest(title, year)
                if tt:
                    return tt, "douban_suggest"
        except Exception:
            logger.detail(f"外部ID召回提供方调用失败：{p}", exc_info=True)

    return None, ""
