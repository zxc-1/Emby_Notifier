"""Query variant generation for TMDB filename matching.

This module provides utilities to generate multiple query variants from a title,
improving recall when searching TMDB.
"""
from __future__ import annotations

import re
from typing import List

from .tmdb_match_core import zh_variants


def cn_only(text: str) -> str:
    """Extract only Chinese characters from text."""
    return re.sub(r"[^\u4e00-\u9fff]+", " ", text or "").strip()


def en_only(text: str) -> str:
    """Extract only English alphanumeric characters from text."""
    return re.sub(r"[^A-Za-z0-9]+", " ", text or "").strip()


def shorten(text: str, n: int = 6) -> str:
    """Keep only the first n tokens of text."""
    toks = (text or "").split()
    return " ".join(toks[:n]).strip()


def token_count(text: str) -> int:
    """Count tokens for adaptive fetch size.
    
    Treat CJK sequences as one token each.
    """
    return len(re.findall(r"[A-Za-z0-9]+|[\u4e00-\u9fff]+", text or ""))


def build_query_variants(title: str, max_variants: int = 6) -> List[str]:
    """Build a list of query variants from a title.
    
    Generates variants by:
    - Original title
    - Chinese-only extraction
    - English-only extraction
    - Shortened versions (6, 4, 2 tokens)
    - Simplified/Traditional Chinese variants
    
    Args:
        title: The original title to generate variants from
        max_variants: Maximum number of variants to return
        
    Returns:
        List of unique query variants, ordered by preference
    """
    base_vars: List[str] = []
    for v in (
        title,
        cn_only(title),
        en_only(title),
        shorten(title, 6),
        shorten(title, 4),
        shorten(title, 2),
    ):
        v = (v or "").strip()
        if v and v not in base_vars and len(v) >= 2:
            base_vars.append(v)

    variants: List[str] = []
    for v in base_vars:
        if re.search(r"[\u4e00-\u9fff]", v):
            for vv in zh_variants(v):
                if vv and vv not in variants and len(vv) >= 2:
                    variants.append(vv)
        else:
            if v and v not in variants and len(v) >= 2:
                variants.append(v)

    return variants[:max_variants]


def is_collision_prone(query: str) -> bool:
    """Check if a query is prone to TMDB search collisions.

    Collision-prone patterns:
      - Very short queries containing common words (love/life/home/time...).
      - "<common> is <X>" patterns (e.g., "love is hard") which tend to collide.

    We use this to increase recall budget and to avoid trusting shallow matches.
    """
    ql = (query or "").strip().lower()
    if not ql:
        return False

    collision_words = {
        "spring", "summer", "fall", "autumn", "winter",
        "love", "life", "home", "day", "night", "star",
        "blue", "red", "black", "white",
        "fever", "story", "stories", "heart", "time",
        "dream", "dreams",
    }

    toks = re.findall(r"[A-Za-z0-9]+|[一-鿿]+", ql)
    if not toks:
        return False

    # Single token collision words
    if len(toks) == 1 and toks[0] in collision_words:
        return True

    # Very short queries with a collision word
    if len(toks) <= 2 and any(t in collision_words for t in toks):
        return True

    # "<collision> is <...>" pattern (e.g., "love is hard")
    if len(toks) >= 3 and toks[0] in collision_words and toks[1] == "is":
        return True

    return False
