"""TMDB matching core (facade).

This module previously mixed:
  - filename parsing + tv hints
  - normalization (zh variants, id extraction)
  - token similarity + scoring
  - auto-pick policy

It has been split into smaller modules:
  - tg_bot.tmdb.tmdb_norm
  - tg_bot.tmdb.tmdb_guess
  - tg_bot.tmdb.tmdb_similarity
  - tg_bot.tmdb.tmdb_fingerprint
  - tg_bot.tmdb.tmdb_scoring
  - tg_bot.tmdb.tmdb_autopick

The public API is preserved for backwards compatibility.
"""

from __future__ import annotations

import re
from typing import Optional

from core.http import get_http_client
from core.http import async_request_with_retry
from ports.settings_provider import get_settings
from core.logging import log_fetch, log_ok
from core.logging import get_biz_logger_adapter


logger = get_biz_logger_adapter(__name__)


from domain.tmdb_match.types import Candidate


# IMDb ids: tt1234567 / tt12345678
IMDB_ID_RE = re.compile(r"\b(tt\d{7,8})\b", re.IGNORECASE)


# Re-export the split implementations
from .tmdb_norm import (  # noqa: E402
    extract_tmdb_id_from_text,
    normalize_title,
    zh_to_traditional,
    zh_to_simplified,
    zh_variants,
)
from .tmdb_guess import (  # noqa: E402
    parse_title_year_from_filename,
    detect_tv_hint,
    has_tv_hints,
)
from .tmdb_similarity import (  # noqa: E402
    _key_tokens,
    _compute_idf_weights,
)
from .tmdb_fingerprint import (  # noqa: E402
    make_title_fingerprint,
    make_series_fingerprints,
)
from .tmdb_scoring import (  # noqa: E402
    score_candidate_meta,
    score_candidate,
)
from .tmdb_autopick import should_auto_pick  # noqa: E402


__all__ = [
    "logger",
    "Candidate",
    "IMDB_ID_RE",
    # runtime utilities
    "get_settings",
    "get_http_client",
    "async_request_with_retry",
    "log_fetch",
    "log_ok",
    # id + normalize
    "extract_tmdb_id_from_text",
    "normalize_title",
    "zh_to_traditional",
    "zh_to_simplified",
    "zh_variants",
    # filename / tv hints
    "parse_title_year_from_filename",
    "detect_tv_hint",
    "has_tv_hints",
    # similarity helpers (used by guess logic)
    "_key_tokens",
    "_compute_idf_weights",
    # fingerprints
    "make_title_fingerprint",
    "make_series_fingerprints",
    # scoring
    "score_candidate_meta",
    "score_candidate",
    # policy
    "should_auto_pick",
]
