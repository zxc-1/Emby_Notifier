from __future__ import annotations

"""Wrappers for fingerprints.

The implementation lives in :mod:`domain.tmdb_match.fingerprint`.
"""
from core.logging import get_biz_logger
biz = get_biz_logger(__name__)


from typing import List, Optional

from ports.settings_provider import get_settings

from domain.tmdb_match import fingerprint as _fp


def _cleanup_mode() -> str:
    try:
        mode = str(getattr(get_settings(), "TMDB_CN_TAG_CLEANUP_MODE", "conservative") or "conservative")
        mode = mode.strip().lower()
    except (ValueError, TypeError, AttributeError) as e:
        biz.detail(
            "ℹ️ [TMDB匹配]TMDB中文标签清理模式配置解析失败：无法读取或解析配置值。"
            "可能原因：配置项不存在、数据类型错误、或属性访问失败。"
            "影响：将使用默认值 'conservative',可能影响中文标签清理行为",
            config="TMDB_CN_TAG_CLEANUP_MODE",
            default="conservative",
            reason=type(e).__name__,
            exc_info=True
        )
        mode = "conservative"
    return mode if mode in {"conservative", "aggressive", "off"} else "conservative"


def make_title_fingerprint(title: str, year: Optional[int], media_type: str, season: Optional[int]) -> str:
    return _fp.make_title_fingerprint(
        title,
        year,
        media_type,
        season,
        cn_tag_cleanup_mode=_cleanup_mode(),
    )


def make_series_fingerprints(title: str, year: Optional[int]) -> List[str]:
    return _fp.make_series_fingerprints(title, year, cn_tag_cleanup_mode=_cleanup_mode())
