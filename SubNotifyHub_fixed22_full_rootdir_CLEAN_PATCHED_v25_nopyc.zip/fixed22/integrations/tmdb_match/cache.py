from __future__ import annotations

import logging
from core.logging import get_biz_logger_adapter, get_biz_logger
logger = get_biz_logger_adapter(__name__)
biz = get_biz_logger(__name__)

import time
from typing import Dict, List, Optional, Tuple


_ALIAS_CACHE: Dict[Tuple[str, int, str], Tuple[List[str], float]] = {}
_ALIAS_CACHE_MAX = 512
_ALIAS_CACHE_TTL_SEC = 6 * 60 * 60  # 6h


def alias_cache_get(key: Tuple[str, int, str]) -> Optional[List[str]]:
    try:
        # IMPORTANT: cached titles may legitimately be an empty list.
        # So we must differentiate between "missing" and "present but empty".
        if key not in _ALIAS_CACHE:
            return None
        titles, ts = _ALIAS_CACHE[key]
        if (time.time() - float(ts)) > _ALIAS_CACHE_TTL_SEC:
            _ALIAS_CACHE.pop(key, None)
            return None
        return titles
    except (ValueError, TypeError, KeyError) as e:
        biz.detail(f"别名缓存读取失败 - 缓存键={key!r}, 原因={type(e).__name__}")
        return None


def alias_cache_put(key: Tuple[str, int, str], titles: List[str]) -> None:
    try:
        if len(_ALIAS_CACHE) >= _ALIAS_CACHE_MAX:
            for k in list(_ALIAS_CACHE.keys())[:64]:
                _ALIAS_CACHE.pop(k, None)
        _ALIAS_CACHE[key] = (titles[:64], float(time.time()))
    except (ValueError, TypeError, KeyError) as e:
        biz.detail(f"别名缓存写入失败（已忽略） - 缓存键={key!r}, 标题数={len(titles) if titles else 0}, 原因={type(e).__name__}")
