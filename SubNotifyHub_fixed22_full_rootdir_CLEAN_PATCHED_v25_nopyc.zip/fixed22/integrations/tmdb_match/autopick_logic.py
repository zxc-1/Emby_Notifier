"""Auto-pick logic for TMDB candidate selection.

This module handles the decision logic for automatically selecting
a TMDB candidate when confidence is high enough.
"""
from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

from core.logging import get_biz_logger

from .tmdb_match_core import Candidate, should_auto_pick, _key_tokens

biz = get_biz_logger(__name__)


def evaluate_autopick(
    scored: List[Tuple[Candidate, float]],
    title: str,
    year: Optional[int],
    media_type: str,
    fm: str,
    tv_hint: bool,
) -> Tuple[bool, Optional[Dict[str, Any]]]:
    """Evaluate whether to auto-pick the best candidate.
    
    Args:
        scored: List of (candidate, score) tuples, sorted by score descending
        title: The query title
        year: The query year
        media_type: The determined media type
        fm: Forced media type (empty if not forced)
        tv_hint: Whether TV hints were detected
        
    Returns:
        Tuple of (should_pick, picked_dict)
        - should_pick: Whether auto-pick should happen
        - picked_dict: The picked candidate as a dict, or None
    """
    if not scored:
        return False, None
    
    q_tokens = _key_tokens(title)
    auto_ok = should_auto_pick(scored)
    
    # Extra guard for single-token queries
    if auto_ok and len(q_tokens) <= 1:
        try:
            best_sc = float(scored[0][1])
            second_sc = float(scored[1][1]) if len(scored) > 1 else 0.0
        except (ValueError, TypeError, IndexError):
            biz.detail(
                "ℹ️ [TMDB匹配]score 计算失败：无法计算最佳和次佳候选对象的评分。"
                "可能原因：候选列表为空、评分数据类型转换失败、或索引越界。"
                "影响：将使用默认值 (0.0, 0.0),可能影响自动选择逻辑",
                exc_info=True
            )
            best_sc, second_sc = 0.0, 0.0

        try:
            m0 = ((scored[0][0].extra or {}).get("_match") or {})
            best_cov = float(m0.get("coverage") or 0.0)
        except (ValueError, TypeError, KeyError, AttributeError, IndexError):
            biz.detail(
                "ℹ️ [TMDB匹配]coverage 计算失败：无法从候选对象中提取覆盖率信息。"
                "可能原因：extra 字段缺失、_match 字段结构异常、或数据类型错误。"
                "影响：将使用默认值 0.0,可能影响自动选择逻辑",
                exc_info=True
            )
            best_cov = 0.0

        if not (best_sc >= 0.93 and best_cov >= 0.92 and (len(scored) == 1 or (best_sc - second_sc) >= 0.12)):
            auto_ok = False

    # Compute score gap
    try:
        best_sc = float(scored[0][1])
        second_sc = float(scored[1][1]) if len(scored) > 1 else 0.0
        gap = best_sc - second_sc
    except (ValueError, TypeError, IndexError):
        biz.detail(
            "ℹ️ [TMDB匹配]score gap 计算失败：无法计算最佳和次佳候选对象的评分差距。"
            "可能原因：候选列表为空、评分数据类型转换失败、或索引越界。"
            "影响：将使用默认值 (0.0, 0.0, 0.0),可能影响自动选择逻辑",
            exc_info=True
        )
        best_sc, second_sc, gap = 0.0, 0.0, 0.0

    # Year mismatch guard (skip for TV-like queries)
    if auto_ok and isinstance(year, int) and (not tv_hint):
        try:
            by = getattr(scored[0][0], "year", None)
            if by is not None and abs(int(by) - int(year)) >= 2:
                m0 = ((scored[0][0].extra or {}).get("_match") or {})
                bcov = float(m0.get("coverage") or 0.0)
                if not (best_sc >= 0.95 and gap >= 0.15 and bcov >= 0.92):
                    auto_ok = False
        except (ValueError, TypeError, AttributeError, IndexError):
            biz.detail(
                "ℹ️ [TMDB匹配]year guard 检查失败：无法检查年份匹配保护条件。"
                "可能原因：年份数据类型转换失败、候选对象缺少年份字段、或数据结构异常。"
                "影响：将跳过年份保护检查,可能影响自动选择的准确性",
                exc_info=True
            )

    # Forced media type guard
    if auto_ok and fm:
        try:
            c0 = scored[0][0]
            if str(getattr(c0, "media_type", "")) != str(media_type):
                m0 = ((c0.extra or {}).get("_match") or {})
                bcov = float(m0.get("coverage") or 0.0)
                if not (best_sc >= 0.97 and gap >= 0.18 and bcov >= 0.92):
                    auto_ok = False
        except (ValueError, TypeError, AttributeError, IndexError):
            biz.detail(
                "ℹ️ [TMDB匹配]forced media type autopick guard 失败：无法检查强制媒体类型保护条件。"
                "可能原因：媒体类型字段缺失、数据类型转换失败、或数据结构异常。"
                "影响：将跳过强制媒体类型保护检查,可能影响自动选择的准确性",
                exc_info=True
            )

    if not auto_ok:
        return False, None

    # Build picked dict
    c, sc = scored[0]
    extra = c.extra or {}
    
    rating = None
    try:
        rating = float(extra.get("vote_average")) if extra.get("vote_average") is not None else None
    except (ValueError, TypeError):
        biz.detail(
            "ℹ️ [TMDB匹配]评分转换失败：无法将评分值转换为浮点数。"
            "可能原因：评分值格式异常、包含非数字字符、或数据类型错误。"
            "影响：该候选对象的评分信息将被忽略",
            raw_value=repr(extra.get('vote_average')),
            exc_info=True
        )
        rating = None
    
    vote_count = None
    try:
        vote_count = int(extra.get("vote_count")) if extra.get("vote_count") is not None else None
    except (ValueError, TypeError):
        biz.detail(
            "ℹ️ [TMDB匹配]投票数转换失败：无法将投票数转换为整数。"
            "可能原因：投票数格式异常、包含非数字字符、或数据类型错误。"
            "影响：该候选对象的投票数信息将被忽略",
            raw_value=repr(extra.get('vote_count')),
            exc_info=True
        )
        vote_count = None
    
    picked = {
        "tmdb_id": int(c.tmdb_id),
        "title": c.title,
        "year": c.year,
        "media_type": c.media_type,
        "score": round(float(sc), 3),
        "gap": round(float(gap), 3),
        "rating": round(rating, 1) if isinstance(rating, (int, float)) else None,
        "vote_count": vote_count,
    }
    
    return True, picked


def log_no_autopick_reason(
    scored: List[Tuple[Candidate, float]],
    title: str,
    year: Optional[int],
    media_type: str,
) -> None:
    """Log diagnostic information when auto-pick doesn't happen.
    
    Args:
        scored: List of (candidate, score) tuples
        title: The query title
        year: The query year
        media_type: The determined media type
    """
    try:
        best_sc = float(scored[0][1]) if scored else 0.0
        second_sc = float(scored[1][1]) if len(scored) > 1 else 0.0
        gap = best_sc - second_sc
    except (ValueError, TypeError, IndexError):
        best_sc, gap = 0.0, 0.0
    
    try:
        _top = scored[0][0] if scored else None
        _top_id = int(getattr(_top, "tmdb_id", 0) or 0) if _top is not None else None
        _top_title = str(getattr(_top, "title", "") or "") if _top is not None else None
        _top_score = round(float(best_sc), 3) if isinstance(best_sc, (int, float)) else None
        
        try:
            _m0 = ((_top.extra or {}).get("_match") or {}) if (_top is not None and getattr(_top, "extra", None) is not None) else {}
            _top_cov_val = float(_m0.get("coverage") or 0.0)
        except (ValueError, TypeError, KeyError, AttributeError):
            _top_cov_val = None

        _reason = "best_low"
        try:
            if isinstance(_top_score, (int, float)) and float(_top_score) >= 0.62:
                if isinstance(gap, (int, float)) and float(gap) < 0.06:
                    _reason = "ambiguous"
                elif isinstance(_top_cov_val, (int, float)) and float(_top_cov_val) < 0.45:
                    _reason = "coverage_low"
                else:
                    _reason = "need_pick"
        except (ValueError, TypeError):
            _reason = "need_pick"
        # 人话版业务日志：未自动匹配需要把原因、影响、建议讲清楚
        reason_map = {
            'best_low': '候选分数偏低且差距不够大',
            'ambiguous': '候选差距太小，存在歧义',
            'coverage_low': '候选覆盖率偏低，标题可能过于泛化或翻译差异较大',
            'need_pick': '匹配存在不确定性',
        }
        reason_desc = reason_map.get(_reason, '匹配存在不确定性')

        biz.warning(
            f"⚠️ 未能自动匹配：{reason_desc}，需要人工确认",
            Top1=_top_title,
            Top1_ID=_top_id,
            Top1_分数=_top_score,
            分差=(round(float(gap), 3) if isinstance(gap, (int, float)) else None),
            原因=_reason,
        )
    except (ValueError, TypeError, AttributeError, IndexError):
        biz.warning("⚠️ 未能自动匹配：匹配结果不够稳定，需要人工确认", 标题=title, 年份=year, 类型=media_type)
