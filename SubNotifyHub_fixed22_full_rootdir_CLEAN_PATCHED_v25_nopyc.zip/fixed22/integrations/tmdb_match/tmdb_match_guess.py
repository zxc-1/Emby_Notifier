"""TMDB filename-based guessing - main coordinator.

This module is the entry point for guessing TMDB matches from filenames.
It coordinates the various sub-modules that handle specific aspects of the matching process.

NOTE: This module was refactored from a 1255-line monolith into a coordinator
that delegates to specialized modules:
- query_variants.py: Query variant generation
- year_confidence.py: Year reliability detection
- alias_enrichment.py: Alternative title fetching and scoring
- search_executor.py: Multi-stage TMDB search strategy
- candidate_ranking.py: IDF re-scoring and output formatting
- autopick_logic.py: Auto-pick decision logic
- storage_helpers.py: Persistence utilities
"""
from __future__ import annotations

import asyncio
import re
from typing import Any, Dict, List, Optional

import httpx

from core.logging import get_biz_logger, get_biz_logger_adapter
from ports.settings_provider import get_settings

from .tmdb_match_core import (
    Candidate,
    has_tv_hints,
    parse_title_year_from_filename,
    _key_tokens,
)
from core.task_registry import create_task_logged
from .tmdb_match_api import (
    extract_imdb_id_from_text,
    find_by_external_id,
)

# Import from refactored modules
from .query_variants import build_query_variants
from .external_id_recall import resolve_imdb_id
from .year_confidence import compute_year_confidence, recompute_year_for_search
from .alias_enrichment import (
    enrich_candidates_with_aliases,
    should_enrich_aliases,
    pool_is_low_quality,
)
from .search_executor import (
    execute_staged_search,
    execute_yearless_fallback,
    execute_multi_search_fallback,
    search_one,
    compute_recall_limits,
)
from .candidate_ranking import (
    rescore_with_idf,
    log_score_softcap_debug,
    tighten_by_year,
    format_output_list,
    compute_score_gap,
)
from .autopick_logic import evaluate_autopick, log_no_autopick_reason

# Re-export storage helpers for backward compatibility
from .storage_helpers import dump_candidates_for_storage, load_candidates_from_storage

logger = get_biz_logger_adapter(__name__)
biz = get_biz_logger(__name__)

# Lazy guessit loader
_guessit = None
_guessit_tried = False


def _ensure_guessit() -> Any:
    global _guessit, _guessit_tried
    if _guessit_tried:
        return _guessit
    _guessit_tried = True
    try:
        from guessit import guessit as g  # type: ignore
        _guessit = g
    except ImportError:
        _guessit = None
    return _guessit


async def guess_tmdb_from_filename(
    filename: str,
    *,
    force_media_type: Optional[str] = None,
    mode: str = "full",
) -> Dict[str, Any]:
    """Guess a best TMDB candidate from filename.

    Args:
        filename: The filename to parse and match
        force_media_type: Force "movie" or "tv" (optional)
        mode: "full" for comprehensive search, "light" for faster/cheaper search

    Returns:
        {
            ok: bool,
            title: str,
            year: int|None,
            media_type: movie|tv,
            season: int|None,
            candidates: [ {tmdb_id,title,year,media_type,score} ],
            picked: { ... } | None,
            reason: optional
        }
    """
    with biz.entry(
        domain="TMDB",
        action="匹配",
        group_title="TMDB 匹配",
        filename=(str(filename)[:120] + ("…" if len(str(filename)) > 120 else "")),
        mode=mode,
        force_media_type=force_media_type,
    ):
        # Step 0: External ID fast path (IMDb tt1234567)
        biz.step("外部 ID 快速匹配", i=1, total=5)
        result = await _try_external_id_match(filename)
        if result is not None:
            return result

        # Step 1: Parse title/year/season
        title, year, season = parse_title_year_from_filename(filename)
        tv_hint = has_tv_hints(filename)

        # Determine mode settings
        m0 = str(mode or "full").strip().lower()
        is_light_mode = (m0.startswith("l") or m0 in {"1", "true", "yes", "light"})
        max_variants = 3 if is_light_mode else 6
        max_merged = 25 if is_light_mode else 40
        enable_multi_fallback = not is_light_mode
        enable_alias_enrich = not is_light_mode

        # Apply guessit if available
        title, year, season = _apply_guessit(filename, title, year, season)

        # Compute year confidence
        tvish = (season is not None) or tv_hint
        year_for_search = recompute_year_for_search(filename, year, tvish)

        # Determine media type
        fm = (force_media_type or "").strip().lower()
        if fm not in ("movie", "tv"):
            fm = ""
        media_type = fm or ("tv" if tvish else "movie")
        strict_tv = bool(media_type == "tv" and (fm == "tv" or season is not None or tv_hint))

        biz.step(
            "解析标题/年份/类型", i=2, total=5,
            解析标题=title, 解析年份=year, 检索年份=year_for_search,
            季=season, 类型=media_type,
        )

        # Validate
        if not title:
            biz.warning("空标题，跳过匹配", reason="empty_title")
            return {"ok": False, "reason": "empty_title", "title": "", "year": year, "media_type": media_type, "season": season}

        s = get_settings()
        if not bool(str(getattr(s, "TMDB_API_KEY", "") or "").strip()):
            biz.warning("未配置 TMDB_API_KEY", reason="no_tmdb_api_key")
            return {"ok": False, "reason": "no_tmdb_api_key", "title": title, "year": year, "media_type": media_type, "season": season}

        # Step 2: Build query variants
        biz.step("构造查询变体", i=3, total=5, 基准标题=title, 检索年份=year_for_search)
        variants = build_query_variants(title, max_variants=max_variants * 2)

        # Step 3: Execute staged search
        mt_order = ["tv"] if strict_tv else [media_type, ("tv" if media_type == "movie" else "movie")]
        
        merged, used_q = await execute_staged_search(
            variants=variants,
            mt_order=mt_order,
            title=title,
            year=year,
            year_for_search=year_for_search,
            media_type=media_type,
            fm=fm,
            tv_hint=tv_hint,
            strict_tv=strict_tv,
            max_variants=max_variants,
            max_merged=max_merged,
            merge_callback=lambda got, q: None,  # Merging is handled internally
        )

        # Step 4: Fallback searches if low quality
        await _execute_fallback_searches(
            merged=merged,
            variants=variants,
            mt_order=mt_order,
            title=title,
            year=year,
            year_for_search=year_for_search,
            media_type=media_type,
            fm=fm,
            tv_hint=tv_hint,
            strict_tv=strict_tv,
            max_variants=max_variants,
            max_merged=max_merged,
            enable_multi_fallback=enable_multi_fallback,
        )

        if not merged:
            return {"ok": True, "title": title, "year": year, "media_type": media_type, "season": season, "candidates": [], "picked": None}

        # Step 5: Alias enrichment
        do_alias = should_enrich_aliases(merged, title, year, enable_alias_enrich)
        if do_alias:
            await _perform_alias_enrichment(merged, title, year)

        # Step 6: Alias-seeded recall if still low quality
        if do_alias and pool_is_low_quality(merged, title, year):
            await _alias_seeded_recall(merged, title, variants, media_type, _key_tokens)

        # Step 6.5: External-ID recall if still low quality
        s2 = get_settings()
        if bool(getattr(s2, 'TMDB_ENABLE_EXTERNAL_ID_RECALL', True)) and pool_is_low_quality(merged, title, year):
            try:
                biz.step('外部 ID 兜底召回', i=3, total=5, strategy='imdb/douban -> tmdb /find')
                imdb_id, provider = await resolve_imdb_id(title, year)
                if imdb_id:
                    found = []
                    try:
                        found = await find_by_external_id(imdb_id)
                    except (httpx.HTTPError, OSError, asyncio.TimeoutError, RuntimeError):
                        found = []

                    if found:
                        picked_c = None
                        for c in found:
                            if getattr(c, 'media_type', None) == media_type:
                                picked_c = c
                                break
                        picked_c = picked_c or found[0]
                        biz.ok('外部 ID 兜底命中', imdb_id=imdb_id, provider=provider, tmdb_id=int(picked_c.tmdb_id), media_type=str(picked_c.media_type))

                        # Short-circuit: return a deterministic hit (still compatible with old output format)
                        return {
                            'ok': True,
                            'title': str(picked_c.title or title),
                            'year': picked_c.year,
                            'media_type': str(picked_c.media_type or media_type),
                            'season': season,
                            'candidates': [
                                {
                                    'tmdb_id': int(picked_c.tmdb_id),
                                    'title': str(picked_c.title or title),
                                    'year': picked_c.year,
                                    'media_type': str(picked_c.media_type or media_type),
                                    'score': 0.999,
                                    'rating': picked_c.rating,
                                    'vote_count': picked_c.vote_count,
                                }
                            ],
                            'picked': {
                                'tmdb_id': int(picked_c.tmdb_id),
                                'title': str(picked_c.title or title),
                                'year': picked_c.year,
                                'media_type': str(picked_c.media_type or media_type),
                                'score': 0.999,
                                'rating': picked_c.rating,
                                'vote_count': picked_c.vote_count,
                            },
                        }
                    else:
                        biz.detail('外部 ID 已解析但 TMDB /find 无结果', imdb_id=imdb_id, provider=provider)
            except Exception:
                biz.detail('外部 ID 兜底召回异常（已忽略）', exc_info=True)

        # Step 7: Re-score with IDF
        scored = rescore_with_idf(merged, title, year, tv_hint)
        log_score_softcap_debug(scored)

        # Step 8: Year tightening
        scored = tighten_by_year(scored, year, tv_hint)

        # Step 9: Format output
        out_list = format_output_list(scored, max_items=8)
        best_sc, second_sc, gap = compute_score_gap(scored)

        biz.step(
            "评分/筛选候选", i=4, total=5,
            merged=len(merged), scored=len(scored), top=len(out_list),
            best_score=round(best_sc, 3) if best_sc else None,
        )

        # Log top candidates
        _log_top_candidates(out_list)

        # Step 10: Auto-pick decision
        auto_ok, picked = evaluate_autopick(scored, title, year, media_type, fm, tv_hint)

        biz.step("输出/自动选择", i=5, total=5, 候选数=len(out_list), 已自动选择=bool(picked))
        
        if picked:
            biz.ok(
                "匹配成功",
                tmdb_id=picked.get("tmdb_id"),
                picked_title=picked.get("title"),
                year=picked.get("year"),
                media_type=picked.get("media_type"),
                score=picked.get("score"),
            )
        else:
            log_no_autopick_reason(scored, title, year, media_type)

        return {
            "ok": True,
            "title": title,
            "year": year,
            "media_type": media_type,
            "season": season,
            "candidates": out_list,
            "picked": picked,
        }


async def _try_external_id_match(filename: str) -> Optional[Dict[str, Any]]:
    """Try to match via external ID (IMDb)."""
    imdb_id = extract_imdb_id_from_text(filename)
    if not imdb_id or not bool(getattr(get_settings(), "TMDB_ENABLE_EXTERNAL_ID_FIND", True)):
        return None

    try:
        found = await find_by_external_id(imdb_id, external_source="imdb_id")
    except (httpx.HTTPError, OSError, asyncio.TimeoutError, RuntimeError):
        biz.detail(
            "ℹ️ [TMDB匹配]tmdb_find_by_external_id 失败：无法通过 IMDb ID 查找 TMDB 条目。"
            "可能原因：网络连接失败、TMDB API 超时、API 响应异常、或 IMDb ID 格式错误。"
            "影响：无法通过 IMDb ID 直接匹配,将尝试其他匹配方式",
            imdb_id=imdb_id,
            exc_info=True
        )
        return None

    if len(found) != 1:
        return None

    c0 = found[0]
    biz.ok("外部 ID 命中", imdb_id=imdb_id, tmdb_id=int(c0.tmdb_id), media_type=c0.media_type)
    
    extra = c0.extra or {}
    rating = _safe_float(extra.get("vote_average"))
    vote_count = _safe_int(extra.get("vote_count"))

    return {
        "ok": True,
        "title": str(extra.get("title") or extra.get("name") or c0.title),
        "year": c0.year,
        "media_type": c0.media_type,
        "season": None,
        "candidates": [{
            "tmdb_id": int(c0.tmdb_id),
            "title": c0.title,
            "year": c0.year,
            "media_type": c0.media_type,
            "score": 0.999,
            "rating": round(rating, 1) if rating else None,
            "vote_count": vote_count,
        }],
        "picked": {
            "tmdb_id": int(c0.tmdb_id),
            "title": c0.title,
            "year": c0.year,
            "media_type": c0.media_type,
            "score": 0.999,
            "rating": round(rating, 1) if rating else None,
            "vote_count": vote_count,
        },
    }


def _apply_guessit(filename: str, title: str, year: Optional[int], season: Optional[int]) -> Tuple[str, Optional[int], Optional[int]]:
    """Apply guessit parsing if available."""
    if not bool(getattr(get_settings(), "TMDB_ENABLE_GUESSIT", True)):
        return title, year, season
    
    g = _ensure_guessit()
    if g is None:
        return title, year, season

    try:
        guessit_result = (g(filename) if g is not None else {}) or {}
    except (ValueError, TypeError, AttributeError, RuntimeError):
        biz.detail(
            "ℹ️ [TMDB匹配]guessit 解析失败：无法使用 guessit 解析文件名。"
            "可能原因：文件名格式异常、guessit 库内部错误、或数据类型不匹配。"
            "影响：将使用原始标题和年份信息,可能影响匹配准确性",
            filename=filename[:80],
            exc_info=True
        )
        return title, year, season

    if not isinstance(guessit_result, dict):
        return title, year, season

    g_title = str(guessit_result.get("title") or "").strip()
    g_year = guessit_result.get("year")
    g_season = guessit_result.get("season")

    # Normalize season type
    if isinstance(g_season, (list, tuple, set)) and g_season:
        try:
            g_season = int(list(g_season)[0])
        except (ValueError, TypeError, IndexError):
            g_season = None
    elif not isinstance(g_season, int):
        try:
            g_season = int(g_season) if g_season is not None else None
        except (ValueError, TypeError):
            g_season = None

    # Prefer guessit title if better
    tv_hint = has_tv_hints(filename)
    tvish = (season is not None) or tv_hint
    if g_title:
        if tvish:
            if len(title) < 3 or len(g_title) <= len(title) + 3:
                title = g_title
        else:
            if (len(g_title) >= len(title) + 1) or (len(title) < 3):
                title = g_title
        if isinstance(g_year, int):
            year = g_year
        if g_season is not None:
            season = g_season

    return title, year, season


async def _execute_fallback_searches(
    merged, variants, mt_order, title, year, year_for_search,
    media_type, fm, tv_hint, strict_tv, max_variants, max_merged,
    enable_multi_fallback,
):
    """Execute fallback searches when initial results are low quality."""
    try:
        low_quality = False
        qk = list(_key_tokens(title) or [])
        qk_len = len(qk)

        if not merged or len(merged) < 6:
            low_quality = True
        else:
            try:
                _tmp = sorted(list(merged.values()), key=lambda x: float(x[1]), reverse=True)
                _best = float(_tmp[0][1]) if _tmp else 0.0
                _second = float(_tmp[1][1]) if len(_tmp) > 1 else 0.0

                # Read best coverage if available (stored by score_candidate_meta).
                _best_cov = 0.0
                try:
                    _c0 = _tmp[0][0]
                    m = (_c0.extra or {}).get("_match") or {}
                    _best_cov = float(m.get("coverage") or 0.0)
                except Exception:
                    _best_cov = 0.0

                # Short / collision-prone queries must have full coverage; otherwise force fallback.
                # This prevents "Love is X" style collisions from blocking yearless/multi recall.
                if qk_len > 0 and qk_len <= 3 and _best_cov < 0.999:
                    low_quality = True
                elif _best < 0.62 or (_best - _second) < 0.06:
                    low_quality = True
            except (ValueError, TypeError, IndexError):
                low_quality = True


        if low_quality and (year_for_search is not None):
            await execute_yearless_fallback(
                merged, variants, mt_order, title, year,
                media_type, fm, tv_hint, strict_tv, max_variants, max_merged,
            )

        if low_quality and enable_multi_fallback:
            await execute_multi_search_fallback(
                merged, variants, title, year,
                media_type, fm, tv_hint, strict_tv,
            )
    except (httpx.HTTPError, OSError, asyncio.TimeoutError, RuntimeError, ValueError, TypeError):
        biz.detail(
            "ℹ️ [TMDB匹配]fallback searches 失败：备用搜索策略执行失败。"
            "可能原因：网络连接失败、TMDB API 超时、API 响应异常、或数据解析错误。"
            "影响：无法通过备用策略获取更多候选结果,可能影响匹配准确性",
            exc_info=True
        )


async def _perform_alias_enrichment(merged, title, year):
    """Perform alias enrichment on top candidates.
    
    Selection strategy:
    - Top 8 by score (traditional behavior)
    - Top 4 by year match (ensures year-matched candidates get translations even if low score)
    This fixes the issue where correct candidates with non-matching titles (e.g., Chinese
    title "小城大事" for English query "The Dream Maker") were missed because their
    initial score was too low to make Top 12.
    """
    try:
        base_sorted = sorted(list(merged.values()), key=lambda x: float(x[1]), reverse=True)
        
        # Strategy: Top 8 by score + Top 4 by year match (deduplicated)
        by_score = [c for c, _sc, _q in base_sorted[:8]]
        
        # Find year-matched candidates that might not be in top 8
        by_year_match = []
        if isinstance(year, int):
            seen_ids = {int(c.tmdb_id) for c in by_score}
            for c, _sc, _q in base_sorted:
                if int(c.tmdb_id) in seen_ids:
                    continue
                try:
                    if isinstance(c.year, int) and c.year == year:
                        by_year_match.append(c)
                        seen_ids.add(int(c.tmdb_id))
                        if len(by_year_match) >= 4:
                            break
                except (ValueError, TypeError, AttributeError):
                    continue
        
        topk = by_score + by_year_match
        
        # Log trigger info
        try:
            _best_before = float(base_sorted[0][1]) if base_sorted else 0.0
            _second_before = float(base_sorted[1][1]) if len(base_sorted) > 1 else 0.0
            _gap_before = _best_before - _second_before
            _reason = "best_low" if _best_before < 0.62 else ("gap_small" if _gap_before < 0.06 else "rerank")
            _top_ids = [int(c.tmdb_id) for c in topk[:3]]
            _year_match_ids = [int(c.tmdb_id) for c in by_year_match[:3]]
            biz.detail(
                "alias_enrich：操作异常：trigger",
                best=round(_best_before, 3),
                second=round(_second_before, 3),
                gap=round(_gap_before, 3),
                topK=len(topk),
                by_score=len(by_score),
                by_year_match=len(by_year_match),
                reason=_reason,
                top_ids=_top_ids,
                year_match_ids=_year_match_ids if by_year_match else None,
            )
        except (ValueError, TypeError, AttributeError, IndexError):
            biz.detail(
                "ℹ️ [TMDB匹配]alias_enrich trigger log 失败：无法记录别名增强触发日志。"
                "可能原因：候选对象数据结构异常、字段缺失、或数据类型转换失败。"
                "影响：仅影响日志记录,不影响别名增强功能",
                exc_info=True
            )

        await enrich_candidates_with_aliases(topk, lang="en-US")
    except (httpx.HTTPError, OSError, asyncio.TimeoutError, RuntimeError, ValueError, TypeError):
        biz.detail(
            "ℹ️ [TMDB匹配]alias enrichment 失败：别名增强功能执行失败。"
            "可能原因：网络连接失败、TMDB API 超时、API 响应异常、或数据解析错误。"
            "影响：候选结果将缺少别名信息,可能影响匹配准确性",
            exc_info=True
        )


async def _alias_seeded_recall(merged, title, variants, media_type, key_tokens_func):
    """Perform alias-seeded recall for low quality pools."""
    try:
        from .search_executor import search_one
        from .tmdb_match_core import score_candidate_meta
        
        base_sorted = sorted(list(merged.values()), key=lambda x: float(x[1]), reverse=True)
        topk2 = base_sorted[:12]
        q_tok = set(key_tokens_func(title) or [])
        seeds = []
        seen_seed = set(v.lower() for v in (variants or []) if isinstance(v, str))
        bad_tag_re = re.compile(r"(?i)\b(1080p|2160p|720p|web[- ]?dl|webrip|hdr|dv|amzn|hulu|netflix|bluray|bdrip|x264|x265|h\.264|h\.265|ddp|dts|aac)\b")
        
        for c, _sc, _q in topk2:
            try:
                aliases = list((c.extra or {}).get("_aliases") or [])
            except (ValueError, TypeError, KeyError, AttributeError):
                aliases = []
            for a in aliases:
                aa = str(a or "").strip()
                if not aa or len(aa) < 2 or len(aa) > 80:
                    continue
                if bad_tag_re.search(aa):
                    continue
                if re.search(r"(?i)\bS\d{1,2}\b|\bE\d{1,3}\b", aa):
                    continue
                al = aa.lower()
                if al in seen_seed:
                    continue
                seen_seed.add(al)
                toks = set(key_tokens_func(aa) or [])
                ov = len(toks & q_tok) if q_tok else 0
                seeds.append((ov, aa))

        seeds = sorted(seeds, key=lambda x: (x[0], -len(x[1])), reverse=True)[:6]

        async def _search_seed(seed_title: str):
            cap_s, mpo_s = compute_recall_limits(seed_title, widened=True)
            from .tmdb_match_api import search_candidates_via_tmdb
            try:
                return await search_candidates_via_tmdb(seed_title, media_type, year=None, max_candidates=cap_s, max_pages_override=mpo_s)
            except (httpx.HTTPError, OSError, asyncio.TimeoutError, RuntimeError):
                return []

        if seeds:
            tasks_s = [create_task_logged(_search_seed(t)) for _ov, t in seeds]
            res_s = await asyncio.gather(*tasks_s, return_exceptions=True)
            for _r in res_s:
                if isinstance(_r, Exception):
                    biz.detail(f"并行任务失败（已忽略）：{type(_r).__name__}", error=str(_r))
            for idx_s, got_s in enumerate(res_s):
                if isinstance(got_s, Exception):
                    biz.detail(
                        "ℹ️ [TMDB匹配]seed 并行召回失败：召回任务返回异常。"
                        "可能原因：TMDB API 超时/限流、网络异常、或响应解析失败。"
                        "影响：该 seed 无法召回候选,可能降低召回率",
                        seed=seeds[idx_s][1] if idx_s < len(seeds) else None,
                        exc_info=got_s,
                    )
                    continue
                if not got_s:
                    continue
                for c in got_s:
                    sc, _cov, _mn = score_candidate_meta(title, None, c)
                    key = (int(c.tmdb_id), str(c.media_type))
                    prev = merged.get(key)
                    if prev is None or sc > prev[1]:
                        merged[key] = (c, sc, seeds[idx_s][1])
    except (httpx.HTTPError, OSError, asyncio.TimeoutError, RuntimeError, ValueError, TypeError):
        biz.detail(
            "ℹ️ [TMDB匹配]alias-seeded recall 失败：基于别名的召回策略执行失败。"
            "可能原因：网络连接失败、TMDB API 超时、API 响应异常、或数据解析错误。"
            "影响：无法通过别名召回更多候选结果,可能影响低质量查询的匹配准确性",
            exc_info=True
        )


def _log_top_candidates(out_list: List[Dict[str, Any]]) -> None:
    """Log top candidates for debugging."""
    try:
        topn = min(3, len(out_list or []))
        for idx, it in enumerate(list(out_list or [])[:topn], start=1):
            if isinstance(it, dict):
                biz.detail_item(
                    "候选",
                    i=idx,
                    total=topn,
                    tmdb_id=it.get("tmdb_id"),
                    cand_title=it.get("title"),
                    year=it.get("year"),
                    media_type=it.get("media_type"),
                    score=it.get("score"),
                )
    except (ValueError, TypeError, AttributeError):
        biz.detail(
            "ℹ️ [TMDB匹配]tmdb candidate detail log 失败：无法记录候选对象详细信息。"
            "可能原因：候选对象数据结构异常、字段缺失、或数据类型转换失败。"
            "影响：仅影响日志记录,不影响匹配功能",
            exc_info=True
        )


def _safe_float(v) -> Optional[float]:
    """Safely convert to float."""
    if v is None:
        return None
    try:
        return float(v)
    except (ValueError, TypeError):
        return None


def _safe_int(v) -> Optional[int]:
    """Safely convert to int."""
    if v is None:
        return None
    try:
        return int(v)
    except (ValueError, TypeError):
        return None


# Re-export for backward compatibility
__all__ = [
    "guess_tmdb_from_filename",
    "dump_candidates_for_storage",
    "load_candidates_from_storage",
]