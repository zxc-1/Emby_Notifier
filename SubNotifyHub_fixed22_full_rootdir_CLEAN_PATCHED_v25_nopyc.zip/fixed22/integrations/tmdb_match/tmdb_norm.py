from __future__ import annotations

"""Thin wrappers around :mod:`domain.tmdb_match.norm`.

Rationale:
- Keep integrations public surface stable (backward compatible imports)
- Keep pure logic in :mod:`domain` (no I/O)
- Allow runtime settings to tweak normalization behavior
"""
import logging
from core.logging import get_biz_logger_adapter
logger = get_biz_logger_adapter(__name__)


from ports.settings_provider import get_settings

from domain.tmdb_match import norm as _norm


def _cleanup_mode() -> str:
    try:
        mode = str(getattr(get_settings(), "TMDB_CN_TAG_CLEANUP_MODE", "conservative") or "conservative")
        mode = mode.strip().lower()
    except (ValueError, TypeError, AttributeError):
        mode = "conservative"
    return mode if mode in {"conservative", "aggressive", "off"} else "conservative"


# Pure helpers (no settings) are re-exported directly
extract_tmdb_id_from_text = _norm.extract_tmdb_id_from_text
zh_to_traditional = _norm.zh_to_traditional
zh_to_simplified = _norm.zh_to_simplified
zh_variants = _norm.zh_variants


def normalize_title(s: str) -> str:
    return _norm.normalize_title(s, cn_tag_cleanup_mode=_cleanup_mode())
