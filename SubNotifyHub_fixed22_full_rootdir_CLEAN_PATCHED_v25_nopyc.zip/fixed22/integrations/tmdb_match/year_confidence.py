"""Year confidence detection for TMDB filename matching.

This module provides utilities to determine how reliable a year extracted
from a filename is, which affects whether it should be used as a strict
TMDB search filter.
"""
from __future__ import annotations

import re
from typing import Optional, Tuple

from core.logging import get_biz_logger_adapter, get_biz_logger

logger = get_biz_logger_adapter(__name__)
biz = get_biz_logger(__name__)

# Year token heuristic: treat a year as "reliable" if it appears as a standalone
# token in the original filename, e.g. "Title.2026.S01E03...".
_YEAR_TOKEN_RE = re.compile(r"(^|[\s._\-\[\(（【])(?P<y>\d{4})(?=$|[\s._\-\]\)）】])")


def year_token_reliable_in_filename(filename: str, year: int) -> bool:
    """Check if a year appears as a standalone token in the filename.
    
    A year is considered reliable if it appears surrounded by delimiters
    (spaces, dots, dashes, brackets, etc.) rather than embedded in other text.
    
    Args:
        filename: The filename to check
        year: The year to look for
        
    Returns:
        True if the year appears as a standalone token
    """
    try:
        y = int(year)
    except (ValueError, TypeError):
        return False
    if y < 1870 or y > 2100:
        return False
    fn = str(filename or "").strip()
    if not fn:
        return False
    for m in _YEAR_TOKEN_RE.finditer(fn):
        try:
            if int(m.group("y")) == y:
                return True
        except (ValueError, TypeError):
            continue
    return False


def compute_year_confidence(
    filename: str,
    year: Optional[int],
    tvish: bool,
) -> Tuple[bool, bool, bool]:
    """Compute year confidence levels for a filename.
    
    Args:
        filename: The original filename
        year: Extracted year (may be None)
        tvish: Whether the content appears to be TV-like (has season/episode markers)
        
    Returns:
        Tuple of (year_conf_high, year_conf_low, year_reliable)
        - year_conf_high: Year appears in brackets like (2026) or [2026]
        - year_conf_low: Year confidence is low (e.g., appears after SxxEyy)
        - year_reliable: Year should be used as a strict TMDB search filter
    """
    year_conf_high = False
    year_conf_low = False
    year_reliable = False
    
    if not isinstance(year, int):
        return year_conf_high, year_conf_low, year_reliable
    
    # Check if year appears in brackets (high confidence)
    try:
        ypat = rf"[\(\[]\s*{int(year)}\s*[\)\]]"
        if re.search(ypat, filename or ""):
            year_conf_high = True
    except (ValueError, TypeError, re.error):
        biz.detail(
            "ℹ️ [TMDB匹配]年份置信度检查失败：无法检查年份是否出现在括号中。"
            "可能原因：年份数据类型转换失败、正则表达式错误、或文件名格式异常。"
            "影响：将假设年份置信度不高,可能影响匹配准确性",
            year=year,
            filename=filename[:80],
            exc_info=True
        )
        year_conf_high = False
    
    # For TV content, check if year appears after SxxEyy (low confidence)
    if tvish and not year_conf_high:
        try:
            if re.search(rf"(?i)S\d{{1,2}}E\d{{1,3}}[^0-9]*{int(year)}", filename or ""):
                year_conf_low = True
            else:
                year_conf_low = True
        except (ValueError, TypeError, re.error):
            biz.detail(
                "ℹ️ [TMDB匹配]年份置信度检查失败：无法检查年份是否出现在剧集标记之后。"
                "可能原因：年份数据类型转换失败、正则表达式错误、或文件名格式异常。"
                "影响：将假设年份置信度较低,可能影响匹配准确性",
                year=year,
                filename=filename[:80],
                exc_info=True
            )
            year_conf_low = True
    
    # Determine if year should be used as strict filter
    if isinstance(year, int) and 1870 <= int(year) <= 2100:
        if tvish:
            year_reliable = year_token_reliable_in_filename(filename, int(year)) or bool(year_conf_high)
            try:
                if year_reliable and (not bool(year_conf_high)) and re.search(
                    rf"(?i)S\d{{1,2}}E\d{{1,3}}[^0-9]*{int(year)}", filename or ""
                ):
                    year_reliable = False
            except (ValueError, TypeError, re.error):
                biz.detail(
                    "ℹ️ [TMDB匹配]TV 年份可靠性检查失败：无法检查 TV 内容的年份可靠性。"
                    "可能原因：年份数据类型转换失败、正则表达式错误、或文件名格式异常。"
                    "影响：将保持当前年份可靠性判断,可能影响匹配准确性",
                    year=year,
                    filename=filename[:80],
                    exc_info=True
                )
        else:
            year_reliable = bool(year_conf_high) or year_token_reliable_in_filename(filename, int(year))
    
    return year_conf_high, year_conf_low, year_reliable


def recompute_year_for_search(
    filename: str,
    year: Optional[int],
    tvish: bool,
) -> Optional[int]:
    """Determine the year to use for TMDB search filtering.
    
    Args:
        filename: The original filename
        year: Extracted year (may be None)
        tvish: Whether the content appears to be TV-like
        
    Returns:
        The year to use for search, or None if year should not be used as a filter
    """
    if not isinstance(year, int):
        return None
    
    _, _, year_reliable = compute_year_confidence(filename, year, tvish)
    return year if year_reliable else None
