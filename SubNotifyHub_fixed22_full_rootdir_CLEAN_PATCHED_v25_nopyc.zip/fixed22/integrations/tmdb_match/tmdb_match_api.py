"""TMDB network-facing helpers (facade).

This module used to contain:
  - TMDB HTTP logic + de-dup/limits
  - caches (memory + sqlite kv_cache)
  - search endpoints + external-id lookup
  - alternative titles enrichment

It has been split into:
  - tg_bot.tmdb.client: HTTP / kv_cache helpers, fetch_tmdb_detail, find_by_external_id
  - tg_bot.tmdb.search: /search endpoints + caching
  - tg_bot.tmdb.aliases: alternative titles + translations
  - tg_bot.tmdb.external_ids: external id extraction

The public API is preserved for backward compatibility.
"""

from __future__ import annotations

from .client import fetch_tmdb_detail, find_by_external_id, fetch_tv_season_episode_count
from .search import (
    search_candidates_via_tmdb,
    search_candidates_movie_via_tmdb,
    search_candidates_tv_via_tmdb,
    search_candidates_multi_via_tmdb,
)
from .aliases import fetch_tmdb_alias_titles
from .external_ids import extract_imdb_id_from_text

__all__ = [
    "search_candidates_via_tmdb",
    "search_candidates_movie_via_tmdb",
    "search_candidates_tv_via_tmdb",
    "search_candidates_multi_via_tmdb",
    "fetch_tmdb_detail",
    "fetch_tv_season_episode_count",
    "fetch_tmdb_alias_titles",
    "find_by_external_id",
    "extract_imdb_id_from_text",
]
