"""Alias enrichment for TMDB candidate scoring.

This module handles fetching and scoring alternative titles/translations
from TMDB to improve candidate matching accuracy.
"""
from __future__ import annotations

import asyncio
import time
from typing import Any, Dict, List, Optional, TYPE_CHECKING

import httpx

from core.logging import get_biz_logger, get_biz_logger_adapter
from ports.settings_provider import get_settings

from .cache import alias_cache_get
from .tmdb_match_api import fetch_tmdb_alias_titles
from .tmdb_match_core import _key_tokens, Candidate, score_candidate_meta

if TYPE_CHECKING:
    pass

logger = get_biz_logger_adapter(__name__)
biz = get_biz_logger(__name__)

# Limit TMDB alias enrichment concurrency to avoid bursty /details calls.
_ALIAS_ENRICH_SEM: Optional[asyncio.Semaphore] = None


def _get_alias_enrich_sem() -> asyncio.Semaphore:
    """Get or create the alias enrichment semaphore."""
    global _ALIAS_ENRICH_SEM
    if _ALIAS_ENRICH_SEM is None:
        try:
            n = int(getattr(get_settings(), "TMDB_ALIAS_ENRICH_CONCURRENCY", 4) or 4)
        except (ValueError, TypeError, AttributeError):
            n = 4
        n = max(1, min(8, n))
        _ALIAS_ENRICH_SEM = asyncio.Semaphore(n)
    return _ALIAS_ENRICH_SEM


def alias_match_quality(query_title: str, cand: Candidate) -> Optional[float]:
    """Return [0,1] quality for alias/translation match against query title.

    Lightweight heuristic: token overlap of query tokens covered by an alias.
    
    Args:
        query_title: The original query title
        cand: The candidate to check aliases for
        
    Returns:
        Quality score between 0 and 1, or None if no aliases available
    """
    try:
        aliases = (cand.extra or {}).get("_aliases") or []
    except (KeyError, TypeError, AttributeError):
        aliases = []
    if not aliases:
        return None
    qt = set(_key_tokens(query_title))
    if not qt:
        return None
    best = 0.0
    for a in aliases:
        if not a:
            continue
        at = set(_key_tokens(str(a)))
        if not at:
            continue
        cov = len(qt & at) / max(1, len(qt))
        if cov > best:
            best = cov
    return best


def softcap_alias_score(score_raw: float, alias_q: Optional[float]) -> float:
    """Soft-cap near-1.0 scores to keep headroom for tie-break signals.

    If score_raw is effectively 1.0, map it into ~[0.990, 0.999] based on alias quality.
    This preserves headroom so year/episode/votes signals can separate candidates.
    
    Args:
        score_raw: The raw score (0.0-1.0)
        alias_q: The alias quality score (0.0-1.0), or None
        
    Returns:
        The soft-capped score
    """
    if score_raw < 0.999:
        return score_raw
    q = 0.5 if alias_q is None else max(0.0, min(1.0, float(alias_q)))
    return min(0.999, 0.990 + 0.009 * q)


def should_enrich_aliases(
    merged: Dict[Any, Any],
    title: str,
    year: Optional[int],
    enable_alias_enrich: bool,
) -> bool:
    """Determine if alias enrichment should be performed.
    
    Skip enrichment if the best candidate is already extremely strong.
    
    Args:
        merged: Dictionary of merged candidates
        title: The query title
        year: The query year
        enable_alias_enrich: Whether alias enrichment is enabled by mode
        
    Returns:
        True if alias enrichment should be performed
    """
    if not enable_alias_enrich:
        return False
    
    try:
        _tmp = sorted(list(merged.values()), key=lambda x: float(x[1]), reverse=True)
        if _tmp:
            _best_c, _best_sc, _ = _tmp[0]
            _second_sc = float(_tmp[1][1]) if len(_tmp) > 1 else 0.0
            _gap = float(_best_sc) - float(_second_sc)
            try:
                _sc2, _cov2, _ = score_candidate_meta(title, year, _best_c)
            except (ValueError, TypeError, AttributeError):
                _cov2 = 0.0
            
            # Check year mismatch
            if isinstance(year, int) and isinstance(_best_c.year, int):
                if abs(int(_best_c.year) - int(year)) > 1:
                    return True
            
            # Skip if already very confident
            if (float(_best_sc) >= 0.92) and (_gap >= 0.18) and (float(_cov2) >= 0.62):
                return False
    except (ValueError, TypeError, AttributeError):
        biz.detail(
            "ℹ️ [TMDB匹配]alias 决策失败：无法判断是否需要进行别名增强。"
            "可能原因：候选对象数据结构异常、字段缺失、或数据类型转换失败。"
            "影响：将默认执行别名增强,可能增加不必要的 API 调用",
            exc_info=True
        )
    
    return True


async def enrich_candidates_with_aliases(
    candidates: List[Candidate],
    lang: str = "en-US",
) -> int:
    """Enrich candidates with alternative titles from TMDB.
    
    Args:
        candidates: List of candidates to enrich
        lang: Language for alias enrichment
        
    Returns:
        Number of cache hits
    """
    cache_hit = 0
    miss: List[Candidate] = []
    
    # Pre-check in-memory alias cache
    for c in candidates:
        try:
            mt = "movie" if str(c.media_type).strip().lower() == "movie" else "tv"
            key = (mt, int(c.tmdb_id), lang)
            cached = alias_cache_get(key)
            if cached is not None:
                cache_hit += 1
                if c.extra is None:
                    c.extra = {}
                c.extra["_aliases"] = cached
            else:
                miss.append(c)
        except (ValueError, TypeError, KeyError, AttributeError):
            biz.detail(f"alias cache 查询失败（已忽略） - tmdb_id={getattr(c, 'tmdb_id', None)}")
            miss.append(c)
    
    sem = _get_alias_enrich_sem()
    t0 = time.monotonic()
    
    async def _enrich_one(c: Candidate) -> None:
        try:
            async with sem:
                aliases = await fetch_tmdb_alias_titles(
                    tmdb_id=int(c.tmdb_id),
                    media_type=str(c.media_type),
                    lang=lang,
                )
            if aliases:
                if c.extra is None:
                    c.extra = {}
                c.extra["_aliases"] = sorted(set((c.extra.get("_aliases") or []) + (aliases or [])))
        except (httpx.HTTPError, OSError, asyncio.TimeoutError, RuntimeError, ValueError, TypeError):
            biz.detail(
                f"alias fetch 失败（已忽略） - tmdb_id={getattr(c, 'tmdb_id', None)}, "
                f"media_type={getattr(c, 'media_type', None)}"
            )
    if miss:
        res = await asyncio.gather(*[_enrich_one(c) for c in miss], return_exceptions=True)
        for _r in res:
            if isinstance(_r, Exception):
                biz.detail(f"并行任务失败（已忽略）：{type(_r).__name__}", error=str(_r))
        for r in (res or []):
            if isinstance(r, Exception):
                biz.detail(
                    "ℹ️ [TMDB匹配]alias_enrich 并行任务失败：获取别名的并行任务抛出异常。"
                    "可能原因：网络连接失败、TMDB API 超时、响应解析异常。"
                    "影响：部分候选缺少别名增强,可能降低召回/合并质量",
                    exc_info=r,
                )

    dt_ms = int((time.monotonic() - t0) * 1000)
    try:
        biz.detail(
            "alias_enrich：操作异常：fetched",
            n=len(candidates),
            cache_hit=cache_hit,
            miss=len(miss),
            http_calls_est=(len(miss) * 2),
            duration_ms=dt_ms,
        )
    except (ValueError, TypeError, AttributeError):
        biz.detail(
            "ℹ️ [TMDB匹配]alias_enrich fetched log 失败：无法记录别名增强获取日志。"
            "可能原因：候选对象数据结构异常、字段缺失、或数据类型转换失败。"
            "影响：仅影响日志记录,不影响别名增强功能",
            exc_info=True
        )
    
    return cache_hit


def pool_is_low_quality(
    merged: Dict[Any, Any],
    title: str,
    year: Optional[int],
) -> bool:
    """Check if the candidate pool is low quality.
    
    Args:
        merged: Dictionary of merged candidates
        title: The query title
        year: The query year
        
    Returns:
        True if the pool is considered low quality
    """
    if not merged:
        return True
    try:
        tmp0 = sorted(list(merged.values()), key=lambda x: float(x[1]), reverse=True)
        best_c0, best_sc0, _ = tmp0[0]
        second_sc0 = float(tmp0[1][1]) if len(tmp0) > 1 else 0.0
        gap0 = float(best_sc0) - float(second_sc0)
        try:
            _scx, covx, _ = score_candidate_meta(title, year, best_c0)
            cov0 = float(covx)
        except (ValueError, TypeError, AttributeError):
            cov0 = 0.0
        
        # Small gaps can happen due to multilingual titles
        if (float(best_sc0) >= 0.90) and (cov0 >= 0.80):
            return False
        return (float(best_sc0) < 0.62) or (gap0 < 0.06) or (cov0 < 0.35)
    except (ValueError, TypeError, IndexError, AttributeError):
        return True
