from __future__ import annotations

import re
import time

# 年份兜底：从标题里提取 (2026) / （2026） / [2026] 等
_YEAR_IN_TITLE_RE = re.compile(r"[\(\[（【]\s*(\d{4})\s*[\)\]）】]")
from typing import Any, Dict, List, Optional, Tuple

from core.cache import TTLCache
from core.logging import get_biz_logger
from settings.timeouts import TimeoutCategory, get_timeout
from settings.retries import RetryCategory, get_retry_config
from settings.urls import get_tmdb_api_url

from .client import _candidate_from_mapping, _db_cache_key, _db_get_json, _db_set_json, _http_get_json_with_retry
from .tmdb_match_core import Candidate, get_http_client, get_settings

biz = get_biz_logger(__name__)

# Get default retry config for TMDB API
_TMDB_RETRY = get_retry_config(RetryCategory.EXTERNAL_SERVICE)

_SEARCH_CACHE: TTLCache[tuple, object] = TTLCache(maxsize=2048, default_ttl=900)


_VIDEO_SEARCH_EXTS = {
    "mp4",
    "mkv",
    "avi",
    "mov",
    "wmv",
    "flv",
    "ts",
    "m2ts",
    "mpg",
    "mpeg",
}


def _should_pass_year_hint(title: str, year: Optional[int]) -> bool:
    if year is None:
        return False
    try:
        y = int(year)
    except (ValueError, TypeError) as e:
        biz.detail(f"年份转换失败（已忽略） - year={year}, 类型={type(year).__name__}, 原因={type(e).__name__}")
        return False
    if y < 1870 or y > 2100:
        return False
    t = (title or "").strip()
    if len(t) < 4:
        return False
    toks = re.split(r"\s+", t)
    if len(toks) == 1 and len(toks[0]) <= 6:
        return False
    low = t.lower().strip(". ")
    if low in _VIDEO_SEARCH_EXTS:
        return False
    return True


async def search_candidates_via_tmdb(
    title: str,
    media_type: Optional[str] = None,
    *,
    year: Optional[int] = None,
    limit: int = 8,
    max_candidates: Optional[int] = None,
    max_pages_override: Optional[int] = None,
    tv_hint: Optional[bool] = None,
) -> List[Candidate]:
    mt: Optional[str] = None
    if media_type is not None:
        mt = str(media_type).strip().lower() or None
    elif tv_hint is not None:
        mt = "tv" if bool(tv_hint) else "movie"

    if mt:
        mt = "movie" if mt == "movie" else "tv"
        if mt == "movie":
            return await search_candidates_movie_via_tmdb(title, year=year, limit=limit, max_candidates=max_candidates, max_pages_override=max_pages_override)
        return await search_candidates_tv_via_tmdb(title, year=year, limit=limit, max_candidates=max_candidates, max_pages_override=max_pages_override)

    return await search_candidates_multi_via_tmdb(title, year=year, limit=limit, max_candidates=max_candidates, max_pages_override=max_pages_override)


async def _search_candidates_typed_via_tmdb(
    title: str,
    *,
    endpoint: str,
    kind: str,
    year: Optional[int] = None,
    limit: int = 8,
    max_candidates: Optional[int] = None,
    max_pages_override: Optional[int] = None,
) -> List[Candidate]:
    s = get_settings()
    api_key = str(getattr(s, "TMDB_API_KEY", "") or "").strip()
    if not api_key:
        return []

    if max_candidates is not None:
        try:
            limit = int(max_candidates)
        except (ValueError, TypeError) as e:
            biz.detail(f"max_candidates 转换失败（已忽略） - max_candidates={max_candidates}, 类型={type(max_candidates).__name__}, 原因={type(e).__name__}")
            pass

    try:
        fetch_n = int(getattr(s, "TMDB_SEARCH_FETCH_N", 40))
    except (ValueError, TypeError, AttributeError) as e:
        biz.detail(f"TMDB_SEARCH_FETCH_N 配置读取失败（使用默认值 40） - 原因={type(e).__name__}")
        fetch_n = 40
    fetch_n = max(fetch_n, int(limit), 20)

    max_pages = max(1, (fetch_n + 19) // 20)
    # Allow callers (low-quality recall paths) to temporarily widen page fetch.
    # When max_pages_override is provided, it acts as an upper bound and bypasses the global TMDB_SEARCH_MAX_PAGES cap.
    if max_pages_override is not None:
        try:
            mpo = int(max_pages_override)
        except (ValueError, TypeError) as e:
            biz.detail(f"max_pages_override 转换失败（已忽略） - max_pages_override={max_pages_override}, 类型={type(max_pages_override).__name__}, 原因={type(e).__name__}")
            mpo = None
        if mpo is not None and mpo > 0:
            max_pages = min(max_pages, mpo)
    else:
        try:
            max_pages_cfg = int(getattr(s, "TMDB_SEARCH_MAX_PAGES", max_pages))
            if max_pages_cfg > 0:
                max_pages = min(max_pages, max_pages_cfg)
        except (ValueError, TypeError, AttributeError) as e:
            biz.detail(f"TMDB_SEARCH_MAX_PAGES 配置读取失败（已忽略） - 原因={type(e).__name__}")
            pass

    primary_lang = str(getattr(s, "TMDB_LANGUAGE", "zh-CN") or "zh-CN").strip() or "zh-CN"
    enable_dual = bool(getattr(s, "TMDB_ENABLE_DUAL_LANGUAGE_SEARCH", True))
    langs: List[str] = [primary_lang]
    if enable_dual:
        if primary_lang.lower() != "en-us":
            langs.append("en-US")
        if primary_lang.lower() != "zh-cn":
            langs.append("zh-CN")
        seen = set()
        langs = [x for x in langs if not (x in seen or seen.add(x))]

    # 人话版业务日志：语言轮询属于细节，默认不刷屏（BIZ_DETAIL=1 才输出）
    biz.detail("· 详细：已生成查询变体并将按语言轮询", 语言=",".join(langs))

    try:
        _v = getattr(s, "TMDB_SEARCH_CACHE_TTL", None)
        if _v is None:
            _v = getattr(s, "TMDB_CACHE_TTL", 900)
        ttl_s = int(_v or 900)
    except (ValueError, TypeError, AttributeError) as e:
        biz.detail(f"TMDB_SEARCH_CACHE_TTL 配置读取失败（使用默认值 900） - 原因={type(e).__name__}")
        ttl_s = 900
    try:
        neg_ttl_s = int(getattr(s, "TMDB_NEGATIVE_CACHE_TTL", 180) or 180)
    except (ValueError, TypeError, AttributeError) as e:
        biz.detail(f"TMDB_NEGATIVE_CACHE_TTL 配置读取失败（使用默认值 180） - 原因={type(e).__name__}")
        neg_ttl_s = 180
    neg_ttl_s = max(30, min(int(ttl_s or 900), int(neg_ttl_s or 180)))

    norm_title = (title or "").strip().lower()
    year_norm = int(year) if year is not None else None
    cache_key = (kind, norm_title, year_norm, int(limit), primary_lang.lower(), bool(enable_dual))
    cached = _SEARCH_CACHE.get(cache_key)
    if isinstance(cached, list):
        return list(cached)

    db_key = _db_cache_key(kind, norm_title, year_norm, int(limit), primary_lang.lower(), bool(enable_dual))
    try:
        cached_db = await _db_get_json(db_key)
        if isinstance(cached_db, list):
            out_db: List[Candidate] = []
            for it in cached_db:
                c = _candidate_from_mapping(it)
                if c is not None:
                    out_db.append(c)
            if out_db or cached_db == []:
                _SEARCH_CACHE.set(cache_key, list(out_db), ttl=(ttl_s if out_db else neg_ttl_s))
                return out_db
    except (ValueError, TypeError, KeyError, AttributeError) as e:
        biz.detail(f"数据库缓存读取失败（已忽略） - db_key={db_key}, 原因={type(e).__name__}")
        pass

    url = get_tmdb_api_url(f"/search/{endpoint}")
    pass_year = _should_pass_year_hint(title, year)

    def _build_params(*, language: str, page: int) -> Dict[str, Any]:
        params: Dict[str, Any] = {
            "api_key": api_key,
            "query": title,
            "language": language,
            "page": page,
        }
        if pass_year and year is not None:
            if kind == "movie":
                params["year"] = int(year)
            else:
                params["first_air_date_year"] = int(year)
        return params

    out: List[Candidate] = []
    seen_keys: set[tuple[int, str]] = set()
    client = await get_http_client()

    # 人话版业务日志：逐页请求属于“细节日志”，默认不刷屏。
    # 开启 BIZ_DETAIL=1（或包含 TMDB 域）时才会显示。
    t0 = time.perf_counter()
    total_req = int(len(langs) * max_pages)
    req_i = 0

    for language in langs:
        for page in range(1, max_pages + 1):
            params = _build_params(language=language, page=page)
            req_i += 1
            biz.detail("· 详细：发送搜索请求", 类型=kind, 语言=language, 页=page)
            status, data, _ = await _http_get_json_with_retry(
                client,
                url,
                params=params,
                timeout=get_timeout(TimeoutCategory.TMDB_API),
                max_attempts=_TMDB_RETRY.max_retries,
                backoff=_TMDB_RETRY.backoff,
                log_ctx="tmdb_search",
            )
            if status != 200 or not isinstance(data, dict):
                break
            items = data.get("results") or []
            if not isinstance(items, list) or not items:
                break
            for it in items:
                if not isinstance(it, dict):
                    continue
                try:
                    tid = int(it.get("id") or 0)
                except (ValueError, TypeError) as e:
                    biz.detail(f"TMDB ID 转换失败（已跳过） - id={it.get('id')}, 类型={type(it.get('id')).__name__}, 原因={type(e).__name__}")
                    tid = 0
                if tid <= 0:
                    continue
                k = (tid, kind)
                if k in seen_keys:
                    continue
                seen_keys.add(k)
                title0 = str(it.get("title") or it.get("name") or "").strip()
                if not title0:
                    continue
                date0 = str(it.get("release_date") or it.get("first_air_date") or "").strip()
                y0 = None
                if len(date0) >= 4 and date0[:4].isdigit():
                    try:
                        y0 = int(date0[:4])
                    except (ValueError, TypeError) as e:
                        biz.detail(f"年份提取失败（已忽略） - date0={date0}, 原因={type(e).__name__}")
                        y0 = None

                if y0 is None:
                    # 年份兜底：部分条目 date 为空，但 title/original_title 里带 "(2026)"
                    try:
                        m = _YEAR_IN_TITLE_RE.search(title0)
                        if not m:
                            m = _YEAR_IN_TITLE_RE.search(str(it.get("original_title") or it.get("original_name") or ""))
                        if m:
                            y0 = int(m.group(1))
                    except (ValueError, TypeError, AttributeError) as e:
                        biz.detail(f"标题中年份提取失败（已忽略） - title0={title0}, 原因={type(e).__name__}")
                try:
                    rating0 = float(it.get("vote_average")) if it.get("vote_average") is not None else None
                except (ValueError, TypeError) as e:
                    biz.detail(f"评分转换失败（已忽略） - vote_average={it.get('vote_average')}, 类型={type(it.get('vote_average')).__name__}, 原因={type(e).__name__}")
                    rating0 = None
                try:
                    vc0 = int(it.get("vote_count")) if it.get("vote_count") is not None else None
                except (ValueError, TypeError) as e:
                    biz.detail(f"投票数转换失败（已忽略） - vote_count={it.get('vote_count')}, 类型={type(it.get('vote_count')).__name__}, 原因={type(e).__name__}")
                    vc0 = None
                out.append(
                    Candidate(
                        tmdb_id=tid,
                        media_type=kind,
                        title=title0,
                        year=y0,
                        rating=rating0,
                        vote_count=vc0,
                        score=1.0,
                        extra=it,
                    )
                )
                if len(out) >= fetch_n:
                    break
            if len(out) >= fetch_n:
                break
        if len(out) >= fetch_n:
            break

    # 细节摘要：仅在开启 BIZ_DETAIL 时输出
    try:
        biz.detail(
            "· 详细：TMDB 搜索完成",
            media_type=kind,
            query=(title[:80] + ("…" if len(title) > 80 else "")),
            year=year,
            langs=len(langs),
            req=req_i,
            max_pages=max_pages,
            candidates=len(out),
            duration_ms=int((time.perf_counter() - t0) * 1000),
        )
    except Exception:
        # 仅日志，不能影响主流程
        pass

    ttl_write = ttl_s if out else neg_ttl_s
    try:
        _SEARCH_CACHE.set(cache_key, list(out), ttl=ttl_write)
    except (ValueError, TypeError) as e:
        biz.detail(f"缓存设置失败（已忽略） - cache_key={cache_key}, ttl={ttl_write}, 原因={type(e).__name__}")
        pass
    try:
        payload = [
            {
                "tmdb_id": int(c.tmdb_id),
                "media_type": str(c.media_type or kind),
                "title": str(c.title or ""),
                "year": int(c.year) if isinstance(c.year, int) else None,
                "rating": float(c.rating) if c.rating is not None else None,
                "vote_count": int(c.vote_count) if c.vote_count is not None else None,
                "score": float(c.score) if c.score is not None else None,
            }
            for c in out
        ]
        await _db_set_json(db_key, payload, ttl=ttl_write)
    except (ValueError, TypeError, KeyError, AttributeError) as e:
        biz.detail(f"数据库缓存写入失败（已忽略） - db_key={db_key}, ttl={ttl_write}, 原因={type(e).__name__}")
        pass

    return out


async def search_candidates_movie_via_tmdb(
    title: str,
    *,
    year: Optional[int] = None,
    limit: int = 8,
    max_candidates: Optional[int] = None,
    max_pages_override: Optional[int] = None,
) -> List[Candidate]:
    return await _search_candidates_typed_via_tmdb(
        title,
        endpoint="movie",
        kind="movie",
        year=year,
        limit=limit,
        max_candidates=max_candidates,
        max_pages_override=max_pages_override,
    )


async def search_candidates_tv_via_tmdb(
    title: str,
    *,
    year: Optional[int] = None,
    limit: int = 8,
    max_candidates: Optional[int] = None,
    max_pages_override: Optional[int] = None,
) -> List[Candidate]:
    return await _search_candidates_typed_via_tmdb(
        title,
        endpoint="tv",
        kind="tv",
        year=year,
        limit=limit,
        max_candidates=max_candidates,
        max_pages_override=max_pages_override,
    )


async def search_candidates_multi_via_tmdb(
    title: str,
    *,
    year: Optional[int] = None,
    limit: int = 8,
    max_candidates: Optional[int] = None,
    max_pages_override: Optional[int] = None,
) -> List[Candidate]:
    s = get_settings()
    api_key = str(getattr(s, "TMDB_API_KEY", "") or "").strip()
    if not api_key:
        return []

    if max_candidates is not None:
        try:
            limit = int(max_candidates)
        except (ValueError, TypeError) as e:
            biz.detail(f"max_candidates 转换失败（已忽略） - max_candidates={max_candidates}, 类型={type(max_candidates).__name__}, 原因={type(e).__name__}")
            pass

    url = get_tmdb_api_url("/search/multi")

    try:
        fetch_n = int(getattr(s, "TMDB_SEARCH_FETCH_N", 40))
    except (ValueError, TypeError, AttributeError) as e:
        biz.detail(f"TMDB_SEARCH_FETCH_N 配置读取失败（使用默认值 40） - 原因={type(e).__name__}")
        fetch_n = 40
    fetch_n = max(fetch_n, int(limit), 20)

    max_pages = max(1, (fetch_n + 19) // 20)
    # Allow callers (low-quality recall paths) to temporarily widen page fetch.
    # When max_pages_override is provided, it acts as an upper bound and bypasses the global TMDB_SEARCH_MAX_PAGES cap.
    if max_pages_override is not None:
        try:
            mpo = int(max_pages_override)
        except (ValueError, TypeError) as e:
            biz.detail(f"max_pages_override 转换失败（已忽略） - max_pages_override={max_pages_override}, 类型={type(max_pages_override).__name__}, 原因={type(e).__name__}")
            mpo = None
        if mpo is not None and mpo > 0:
            max_pages = min(max_pages, mpo)
    else:
        try:
            max_pages_cfg = int(getattr(s, "TMDB_SEARCH_MAX_PAGES", max_pages))
            if max_pages_cfg > 0:
                max_pages = min(max_pages, max_pages_cfg)
        except (ValueError, TypeError, AttributeError) as e:
            biz.detail(f"TMDB_SEARCH_MAX_PAGES 配置读取失败（已忽略） - 原因={type(e).__name__}")
            pass

    primary_lang = str(getattr(s, "TMDB_LANGUAGE", "zh-CN") or "zh-CN").strip() or "zh-CN"
    enable_dual = bool(getattr(s, "TMDB_ENABLE_DUAL_LANGUAGE_SEARCH", True))
    langs: List[str] = [primary_lang]
    if enable_dual:
        if primary_lang.lower() != "en-us":
            langs.append("en-US")
        if primary_lang.lower() != "zh-cn":
            langs.append("zh-CN")
        seen = set()
        langs = [x for x in langs if not (x in seen or seen.add(x))]

    # 人话版业务日志：语言轮询属于细节，默认不刷屏（BIZ_DETAIL=1 才输出）
    biz.detail("· 详细：已生成查询变体并将按语言轮询", 语言=",".join(langs))

    try:
        _v = getattr(s, "TMDB_SEARCH_CACHE_TTL", None)
        if _v is None:
            _v = getattr(s, "TMDB_CACHE_TTL", 900)
        ttl_s = int(_v or 900)
    except (ValueError, TypeError, AttributeError) as e:
        biz.detail(f"TMDB_SEARCH_CACHE_TTL 配置读取失败（使用默认值 900） - 原因={type(e).__name__}")
        ttl_s = 900
    try:
        neg_ttl_s = int(getattr(s, "TMDB_NEGATIVE_CACHE_TTL", 180) or 180)
    except (ValueError, TypeError, AttributeError) as e:
        biz.detail(f"TMDB_NEGATIVE_CACHE_TTL 配置读取失败（使用默认值 180） - 原因={type(e).__name__}")
        neg_ttl_s = 180
    neg_ttl_s = max(30, min(int(ttl_s or 900), int(neg_ttl_s or 180)))

    cache_key = (
        "search_multi",
        (title or "").strip().lower(),
        int(year) if year else None,
        int(limit),
        primary_lang.lower(),
        bool(enable_dual),
    )
    cached = _SEARCH_CACHE.get(cache_key)
    if isinstance(cached, list):
        return list(cached)

    db_key = _db_cache_key(*cache_key)
    try:
        cached_db = await _db_get_json(db_key)
        if isinstance(cached_db, list):
            out_db: List[Candidate] = []
            for it in cached_db:
                c = _candidate_from_mapping(it)
                if c is not None:
                    out_db.append(c)
            if out_db or cached_db == []:
                _SEARCH_CACHE.set(cache_key, list(out_db), ttl=(ttl_s if out_db else neg_ttl_s))
                return out_db
    except (ValueError, TypeError, KeyError, AttributeError) as e:
        biz.detail(f"数据库缓存读取失败（已忽略） - db_key={db_key}, 原因={type(e).__name__}")
        pass

    client = await get_http_client()
    out: List[Candidate] = []
    seen_keys: set[tuple[int, str]] = set()

    # 人话版业务日志：逐页请求属于“细节日志”，默认不刷屏。
    # 开启 BIZ_DETAIL=1（或包含 TMDB 域）时才会显示。
    t0 = time.perf_counter()
    total_req = int(len(langs) * max_pages)
    req_i = 0

    for language in langs:
        for page in range(1, max_pages + 1):
            params = {
                "api_key": api_key,
                "query": title,
                "language": language,
                "page": page,
            }
            req_i += 1
            biz.detail("· 详细：发送搜索请求", 类型="multi", 语言=language, 页=page)
            status, data, _ = await _http_get_json_with_retry(
                client,
                url,
                params=params,
                timeout=get_timeout(TimeoutCategory.TMDB_API),
                max_attempts=_TMDB_RETRY.max_retries,
                backoff=_TMDB_RETRY.backoff,
                log_ctx="tmdb_search",
            )
            if status != 200 or not isinstance(data, dict):
                break
            items = data.get("results") or []
            if not isinstance(items, list) or not items:
                break
            for it in items:
                if not isinstance(it, dict):
                    continue
                mt = str(it.get("media_type") or "").strip().lower()
                if mt not in ("movie", "tv"):
                    continue
                try:
                    tid = int(it.get("id") or 0)
                except (ValueError, TypeError) as e:
                    biz.detail(f"TMDB ID 转换失败（已跳过） - id={it.get('id')}, 类型={type(it.get('id')).__name__}, 原因={type(e).__name__}")
                    tid = 0
                if tid <= 0:
                    continue
                k = (tid, mt)
                if k in seen_keys:
                    continue
                seen_keys.add(k)
                title0 = str(it.get("title") or it.get("name") or "").strip()
                if not title0:
                    continue
                date0 = str(it.get("release_date") or it.get("first_air_date") or "").strip()
                y0 = None
                if len(date0) >= 4 and date0[:4].isdigit():
                    try:
                        y0 = int(date0[:4])
                    except (ValueError, TypeError) as e:
                        biz.detail(f"年份提取失败（已忽略） - date0={date0}, 原因={type(e).__name__}")
                        y0 = None

                if y0 is None:
                    # 年份兜底：部分条目 date 为空，但 title/original_title 里带 "(2026)"
                    try:
                        m = _YEAR_IN_TITLE_RE.search(title0)
                        if not m:
                            m = _YEAR_IN_TITLE_RE.search(str(it.get("original_title") or it.get("original_name") or ""))
                        if m:
                            y0 = int(m.group(1))
                    except (ValueError, TypeError, AttributeError) as e:
                        biz.detail(f"标题中年份提取失败（已忽略） - title0={title0}, 原因={type(e).__name__}")
                        pass

                # NOTE: TMDB /search/multi does not accept a TV year parameter
                # like first_air_date_year. To keep recall good but reduce
                # noise, we locally filter by year when the caller provides a
                # query year and the candidate has a parsable year.
                if year is not None and y0 is not None:
                    try:
                        if abs(int(y0) - int(year)) > 1:
                            continue
                    except (ValueError, TypeError):
                        pass
                try:
                    rating0 = float(it.get("vote_average")) if it.get("vote_average") is not None else None
                except (ValueError, TypeError) as e:
                    biz.detail(f"评分转换失败（已忽略） - vote_average={it.get('vote_average')}, 类型={type(it.get('vote_average')).__name__}, 原因={type(e).__name__}")
                    rating0 = None
                try:
                    vc0 = int(it.get("vote_count")) if it.get("vote_count") is not None else None
                except (ValueError, TypeError) as e:
                    biz.detail(f"投票数转换失败（已忽略） - vote_count={it.get('vote_count')}, 类型={type(it.get('vote_count')).__name__}, 原因={type(e).__name__}")
                    vc0 = None
                out.append(
                    Candidate(
                        tmdb_id=tid,
                        media_type=mt,
                        title=title0,
                        year=y0,
                        rating=rating0,
                        vote_count=vc0,
                        score=1.0,
                        extra=it,
                    )
                )
                if len(out) >= fetch_n:
                    break
            if len(out) >= fetch_n:
                break
        if len(out) >= fetch_n:
            break

    # 细节摘要：仅在开启 BIZ_DETAIL 时输出
    try:
        biz.detail(
            "· 详细：TMDB 搜索完成",
            media_type="multi",
            query=(title[:80] + ("…" if len(title) > 80 else "")),
            year=year,
            langs=len(langs),
            req=req_i,
            max_pages=max_pages,
            candidates=len(out),
            duration_ms=int((time.perf_counter() - t0) * 1000),
        )
    except Exception as e:
        biz.detail("ignored exception in _build_params", exc_info=True)
        pass

    ttl_write = ttl_s if out else neg_ttl_s
    try:
        _SEARCH_CACHE.set(cache_key, list(out), ttl=ttl_write)
    except (ValueError, TypeError) as e:
        biz.detail(f"缓存设置失败（已忽略） - cache_key={cache_key}, ttl={ttl_write}, 原因={type(e).__name__}")
        pass
    try:
        payload = [
            {
                "tmdb_id": int(c.tmdb_id),
                "media_type": str(c.media_type or ""),
                "title": str(c.title or ""),
                "year": int(c.year) if isinstance(c.year, int) else None,
                "rating": float(c.rating) if c.rating is not None else None,
                "vote_count": int(c.vote_count) if c.vote_count is not None else None,
                "score": float(c.score) if c.score is not None else None,
            }
            for c in out
        ]
        await _db_set_json(db_key, payload, ttl=ttl_write)
    except (ValueError, TypeError, KeyError, AttributeError) as e:
        biz.detail(f"数据库缓存写入失败（已忽略） - db_key={db_key}, ttl={ttl_write}, 原因={type(e).__name__}")
        pass

    return out
