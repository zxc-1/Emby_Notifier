from __future__ import annotations

import logging
from core.logging import get_biz_logger_adapter, get_biz_logger
logger = get_biz_logger_adapter(__name__)
biz = get_biz_logger(__name__)

import re
from typing import Optional, Tuple

from .tmdb_norm import normalize_title

# Optional: guessit (industry-grade release name parser).
# Loaded lazily to avoid import-time overhead/log noise.
_guessit = None
_guessit_tried = False


def _ensure_guessit():
    global _guessit, _guessit_tried
    if _guessit_tried:
        return _guessit
    _guessit_tried = True
    try:
        from guessit import guessit as g  # type: ignore
        _guessit = g
    except ImportError:  # pragma: no cover
        _guessit = None
    return _guessit


_YEAR_RE = re.compile(r"(?:19\d{2}|20\d{2})")

# Season markers (best-effort):
_SXX_RE = re.compile(r"\bS(\d{1,2})(?:\b|E\d{1,3}\b)", re.IGNORECASE)
_SEASON_WORD_RE = re.compile(r"\bSeason\s*[._-]?(\d{1,2})\b", re.IGNORECASE)
_CN_SEASON_RE = re.compile(r"第\s*(\d{1,2})\s*季")
_EXX_RE = re.compile(r"\bE(\d{1,3})\b", re.IGNORECASE)
_EP_WORD_RE = re.compile(r"\bEP\s*(\d{1,3})\b", re.IGNORECASE)
_CN_EP_RE = re.compile(r"第\s*(\d{1,3})\s*(?:集|話|话)")
_TV_HINT_WORDS = re.compile(
    r"(全集|全\d+集|完结|完結|更新至|第\d+集|第\d+话|番外|OVA|SP|Series|Season|S\d{1,2}E\d{1,3})",
    re.IGNORECASE,
)


def parse_title_year_from_filename(name: str) -> Tuple[str, Optional[int], Optional[int]]:
    """Return (title, year, season).

    Notes:
      - season is best-effort parsed from Sxx markers (tv hints)
      - year is extracted from any 4-digit 19xx/20xx substring
      - for titles, we try a few variants because some releases put the real title in []/()
    """
    raw = name or ""
    base = raw.rsplit("/", 1)[-1]
    base = base.rsplit("\\\\", 1)[-1]
    # strip extension
    if "." in base:
        base = ".".join(base.split(".")[:-1])

    season: Optional[int] = None
    ms_season = None
    for rx in (_SXX_RE, _SEASON_WORD_RE, _CN_SEASON_RE):
        ms = rx.search(base)
        if ms:
            try:
                season = int(ms.group(1))
            except (ValueError, TypeError) as e:
                biz.detail(f"季数解析失败 - 匹配值={ms.group(1)!r}, 原因={type(e).__name__}")
                season = None
            ms_season = ms
            break

    ms_episode = None
    for rx in (_EXX_RE, _EP_WORD_RE, _CN_EP_RE):
        ms = rx.search(base)
        if ms:
            ms_episode = ms
            break

    year: Optional[int] = None
    my = _YEAR_RE.search(base)
    if my:
        try:
            year = int(my.group(0))
        except (ValueError, TypeError) as e:
            biz.detail(f"年份解析失败 - 匹配值={my.group(0)!r}, 原因={type(e).__name__}")
            year = None

    cand_before_year = ""
    if my and my.start() > 0:
        cand_before_year = base[: my.start()].strip(" ._-[](){}")

    cand_before_season = ""
    if ms_season and ms_season.start() > 0:
        cand_before_season = base[: ms_season.start()].strip(" ._-[](){}")
    cand_before_episode = ""
    if ms_episode and ms_episode.start() > 0:
        cand_before_episode = base[: ms_episode.start()].strip(" ._-[](){}")

    cand_raw = base
    cand_no_brackets = re.sub(r"\[[^\]]*\]|\([^\)]*\)|\{[^\}]*\}", " ", base)
    inner = re.findall(r"\[([^\]]+)\]|\(([^\)]+)\)|\{([^\}]+)\}", base)
    inner_parts = []
    for a, b, c in inner:
        p = (a or b or c or "").strip()
        if p:
            inner_parts.append(p)
    cand_inner = " ".join(inner_parts)

    def _finalize(c: str) -> str:
        t = normalize_title(c)
        t = _SXX_RE.sub(" ", t)
        t = _SEASON_WORD_RE.sub(" ", t)
        t = _CN_SEASON_RE.sub(" ", t)
        if year:
            t = re.sub(str(year), " ", t)
        t = re.sub(r"\s+", " ", t).strip()
        return t

    candidates = []
    if cand_before_season:
        candidates.append(_finalize(cand_before_season))
    if cand_before_episode:
        candidates.append(_finalize(cand_before_episode))
    if cand_before_year:
        candidates.append(_finalize(cand_before_year))
    candidates.extend([_finalize(cand_no_brackets), _finalize(cand_raw), _finalize(cand_inner)])

    before_year_final = _finalize(cand_before_year) if cand_before_year else ""
    before_season_final = _finalize(cand_before_season) if cand_before_season else ""
    before_episode_final = _finalize(cand_before_episode) if cand_before_episode else ""

    def _quality(t: str) -> float:
        if not t:
            return 0.0
        cjk = len(re.findall(r"[\u4e00-\u9fff]", t))
        alpha = len(re.findall(r"[A-Za-z]", t))
        tokens = len(t.split())
        q = min(10, tokens) * 0.15 + min(30, cjk) * 0.03 + min(60, alpha) * 0.01 + min(60, len(t)) * 0.002
        if before_year_final and t == before_year_final and len(t) >= 2:
            q += 0.22
        if season is not None and before_season_final and t == before_season_final and len(t) >= 2:
            q += 0.35
        if season is not None and before_episode_final and t == before_episode_final and len(t) >= 2:
            q += 0.28
        return q

    def _is_bad_before_year_title(t: str) -> bool:
        tt = (t or "").strip()
        if not tt:
            return True
        if len(tt) < 2:
            return True
        if re.fullmatch(r"[A-Za-z]", tt):
            return True
        if re.fullmatch(r"\d{1,4}", tt):
            return True
        if re.fullmatch(r"[Ss]\s*\d{1,2}", tt):
            return True
        if re.fullmatch(r"season\s*\d{1,2}", tt, flags=re.I):
            return True
        toks = tt.lower().split()
        junk = {"s", "season", "ep", "episode", "e", "complete", "全集", "完结", "合集", "更新"}
        if toks and all((re.fullmatch(r"s\d{1,2}", x) or re.fullmatch(r"e\d{1,3}", x) or x in junk) for x in toks):
            return True
        if not re.search(r"[A-Za-z\u4e00-\u9fff]", tt):
            return True
        return False

    if year and before_year_final and not _is_bad_before_year_title(before_year_final):
        has_cjk_any = bool(re.search(r"[\u4e00-\u9fff]", base))
        has_cjk_before = bool(re.search(r"[\u4e00-\u9fff]", before_year_final))
        if not (has_cjk_any and not has_cjk_before):
            return before_year_final, year, season

    if season is not None:
        if before_season_final and not _is_bad_before_year_title(before_season_final):
            return before_season_final, year, season
        if before_episode_final and not _is_bad_before_year_title(before_episode_final):
            return before_episode_final, year, season

    best_title = max(candidates, key=_quality)
    return best_title, year, season


def detect_tv_hint(raw: str, season: Optional[int] = None) -> bool:
    if season is not None:
        return True
    s = (raw or "").strip()
    if not s:
        return False
    if _SXX_RE.search(s) or _SEASON_WORD_RE.search(s) or _CN_SEASON_RE.search(s):
        return True
    if _EXX_RE.search(s) or _EP_WORD_RE.search(s) or _CN_EP_RE.search(s):
        return True
    if _TV_HINT_WORDS.search(s):
        return True
    return False


def has_tv_hints(raw: str) -> bool:
    s = (raw or "").strip()
    if not s:
        return False
    if _SXX_RE.search(s) or _SEASON_WORD_RE.search(s) or _CN_SEASON_RE.search(s):
        return True
    if _EXX_RE.search(s) or _EP_WORD_RE.search(s) or _CN_EP_RE.search(s):
        return True
    if _TV_HINT_WORDS.search(s):
        return True
    return False
