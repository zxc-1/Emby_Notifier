"""Candidate ranking and scoring for TMDB matching.

This module handles the final ranking of TMDB candidates, including
IDF-weighted re-scoring, year tightening, and output formatting.
"""
from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple

from core.logging import get_biz_logger

from .tmdb_match_core import (
    Candidate,
    _compute_idf_weights,
    _key_tokens,
    score_candidate_meta,
)
from .alias_enrichment import alias_match_quality, softcap_alias_score

biz = get_biz_logger(__name__)


def rescore_with_idf(
    merged: Dict[Any, Any],
    title: str,
    year: Optional[int],
    tv_hint: bool,
) -> List[Tuple[Candidate, float]]:
    """Re-score candidates using IDF-like weighting.
    
    Args:
        merged: Dictionary of merged candidates
        title: The query title
        year: The query year
        tv_hint: Whether TV hints were detected
        
    Returns:
        List of (candidate, score) tuples, sorted by score descending
    """
    q_tokens = _key_tokens(title)
    cand_titles = []
    for c, _sc, _q in merged.values():
        try:
            mn = str(((c.extra or {}).get("_match") or {}).get("matched_name") or c.title or "")
        except (ValueError, TypeError, KeyError, AttributeError):
            biz.detail(
                "ℹ️ [TMDB匹配]matched name 提取失败：无法从候选对象中提取匹配的名称。"
                "可能原因：extra 字段缺失、_match 字段结构异常、或数据类型错误。"
                "影响：将使用候选对象的原始标题作为备选",
                tmdb_id=getattr(c, 'tmdb_id', None),
                exc_info=True
            )
            mn = str(c.title or "")
        if mn:
            cand_titles.append(mn)
    
    idf = _compute_idf_weights(q_tokens, cand_titles) if (q_tokens and cand_titles) else None

    rescored: List[Tuple[Candidate, float]] = []
    for c, _sc, _q in merged.values():
        sc2, _cov2, _mn2 = score_candidate_meta(title, year, c, idf=idf)
        
        # Re-apply the same small media-type bonus
        if tv_hint and c.media_type == "tv":
            sc2 = min(1.0, float(sc2) + 0.04)
        if (not tv_hint) and c.media_type == "movie":
            sc2 = min(1.0, float(sc2) + 0.02)
        
        # Keep raw score for debugging
        sc_raw = float(sc2)

        # Soft-cap scores that collapse to 1.0 after alias/translation enrichment
        alias_q = alias_match_quality(title, c)
        sc_soft = softcap_alias_score(sc_raw, alias_q)

        # Attach debug fields
        try:
            if c.extra is None:
                c.extra = {}
            c.extra["_score_raw"] = sc_raw
            c.extra["_score_soft"] = sc_soft
            if alias_q is not None:
                c.extra["_alias_q"] = float(alias_q)
            if year:
                cy = c.year or 0
                c.extra["_year_diff"] = abs(int(cy) - int(year)) if cy else None
        except (ValueError, TypeError, AttributeError):
            pass

        rescored.append((c, float(sc_soft)))

    return sorted(rescored, key=lambda x: x[1], reverse=True)


def log_score_softcap_debug(scored: List[Tuple[Candidate, float]]) -> None:
    """Log debug info for score soft-capping."""
    try:
        if len(scored) >= 2:
            c1, s1 = scored[0]
            c2, s2 = scored[1]
            r1 = float((c1.extra or {}).get("_score_raw", s1))
            r2 = float((c2.extra or {}).get("_score_raw", s2))
            sf1 = float((c1.extra or {}).get("_score_soft", s1))
            sf2 = float((c2.extra or {}).get("_score_soft", s2))
            if (r1 >= 0.999 or r2 >= 0.999) or (abs(r1 - sf1) > 1e-6) or (abs(r2 - sf2) > 1e-6):
                yd1 = (c1.extra or {}).get("_year_diff", None)
                yd2 = (c2.extra or {}).get("_year_diff", None)
                vc1 = (c1.extra or {}).get("vote_count", None) or getattr(c1, "vote_count", None)
                vc2 = (c2.extra or {}).get("vote_count", None) or getattr(c2, "vote_count", None)
                pop1 = (c1.extra or {}).get("popularity", None) or getattr(c1, "popularity", None)
                pop2 = (c2.extra or {}).get("popularity", None) or getattr(c2, "popularity", None)
                aq1 = (c1.extra or {}).get("_alias_q", None)
                aq2 = (c2.extra or {}).get("_alias_q", None)
                biz.detail(
                    "评分软上限调试 - 第一名",
                    tmdb_id=getattr(c1, "tmdb_id", None),
                    raw=round(r1, 3),
                    soft=round(sf1, 3),
                    year_diff=yd1,
                    vote_count=vc1,
                    popularity=pop1,
                    alias_q=aq1,
                )
                biz.detail(
                    "评分软上限调试 - 第二名",
                    tmdb_id=getattr(c2, "tmdb_id", None),
                    raw=round(r2, 3),
                    soft=round(sf2, 3),
                    year_diff=yd2,
                    vote_count=vc2,
                    popularity=pop2,
                    alias_q=aq2,
                )
    except (ValueError, TypeError, AttributeError, IndexError):
        pass


def tighten_by_year(
    scored: List[Tuple[Candidate, float]],
    year: Optional[int],
    tv_hint: bool,
) -> List[Tuple[Candidate, float]]:
    """Tighten candidate list by year preference.
    
    If we have a query year and there exist candidates in the same year,
    prefer showing/scoring within that year to reduce noise.
    
    For TV-like queries, the release year is often unreliable, so we
    do NOT hard-tighten by year.
    
    Args:
        scored: List of (candidate, score) tuples
        year: The query year
        tv_hint: Whether TV hints were detected
        
    Returns:
        Filtered list of (candidate, score) tuples
    """
    if not isinstance(year, int) or tv_hint:
        return scored
    
    try:
        with_year = [(c, sc) for (c, sc) in scored if getattr(c, "year", None) is not None]
        same = [(c, sc) for (c, sc) in with_year if int(c.year) == int(year)]
        if same:
            return same
        near = [(c, sc) for (c, sc) in with_year if abs(int(c.year) - int(year)) <= 1]
        if near:
            return near
    except (ValueError, TypeError, AttributeError):
        biz.detail(
            "ℹ️ [TMDB匹配]year tightening 失败：无法按年份筛选候选结果。"
            "可能原因：年份数据类型转换失败、候选对象缺少年份字段、或数据结构异常。"
            "影响：将返回所有候选结果,不进行年份筛选",
            query_year=year,
            exc_info=True
        )
    
    return scored


def format_output_list(
    scored: List[Tuple[Candidate, float]],
    max_items: int = 8,
) -> List[Dict[str, Any]]:
    """Format scored candidates into output dictionaries.
    
    Args:
        scored: List of (candidate, score) tuples
        max_items: Maximum number of items to include
        
    Returns:
        List of formatted candidate dictionaries
    """
    out_list = []
    for c, sc in scored[:max_items]:
        extra = c.extra or {}
        rating = None
        try:
            rating = float(extra.get("vote_average")) if extra.get("vote_average") is not None else None
        except (ValueError, TypeError):
            biz.detail(
                "ℹ️ [TMDB匹配]评分转换失败：无法将评分值转换为浮点数。"
                "可能原因：评分值格式异常、包含非数字字符、或数据类型错误。"
                "影响：该候选对象的评分信息将被忽略",
                raw_value=repr(extra.get('vote_average')),
                exc_info=True
            )
            rating = None
        
        vote_count = None
        try:
            vote_count = int(extra.get("vote_count")) if extra.get("vote_count") is not None else None
        except (ValueError, TypeError):
            biz.detail(
                "ℹ️ [TMDB匹配]投票数转换失败：无法将投票数转换为整数。"
                "可能原因：投票数格式异常、包含非数字字符、或数据类型错误。"
                "影响：该候选对象的投票数信息将被忽略",
                raw_value=repr(extra.get('vote_count')),
                exc_info=True
            )
            vote_count = None
        
        cov = None
        try:
            cov = float(((c.extra or {}).get("_match") or {}).get("coverage"))
        except (ValueError, TypeError, KeyError, AttributeError):
            biz.detail(
                "ℹ️ [TMDB匹配]coverage 提取失败：无法从候选对象中提取覆盖率信息。"
                "可能原因：extra 字段缺失、_match 字段结构异常、或数据类型错误。"
                "影响：该候选对象的覆盖率信息将被忽略",
                tmdb_id=getattr(c, 'tmdb_id', None),
                exc_info=True
            )
            cov = None
        
        out_list.append({
            "tmdb_id": int(c.tmdb_id),
            "title": c.title,
            "year": c.year,
            "media_type": c.media_type,
            "score": round(float(sc), 3),
            "coverage": round(float(cov), 3) if isinstance(cov, (int, float)) else None,
            "rating": round(rating, 1) if isinstance(rating, (int, float)) else None,
            "vote_count": vote_count,
        })
    
    return out_list


def compute_score_gap(scored: List[Tuple[Candidate, float]]) -> Tuple[float, float, float]:
    """Compute score statistics for diagnostics.
    
    Args:
        scored: List of (candidate, score) tuples
        
    Returns:
        Tuple of (best_score, second_score, gap)
    """
    try:
        best_sc = float(scored[0][1])
        second_sc = float(scored[1][1]) if len(scored) > 1 else 0.0
        gap = best_sc - second_sc
        return best_sc, second_sc, gap
    except (ValueError, TypeError, IndexError):
        biz.detail(
            "ℹ️ [TMDB匹配]score gap 计算失败：无法计算最佳和次佳候选对象的评分差距。"
            "可能原因：候选列表为空、评分数据类型转换失败、或索引越界。"
            "影响：将返回默认值 (0.0, 0.0, 0.0),可能影响自动选择逻辑",
            exc_info=True
        )
        return 0.0, 0.0, 0.0
