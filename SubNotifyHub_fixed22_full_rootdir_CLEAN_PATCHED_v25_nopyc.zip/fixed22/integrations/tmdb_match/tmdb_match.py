"""Compatibility shim for TMDB matching.

P0-1 refactor: split the original huge module into smaller parts.
The public API is unchanged; this file re-exports everything.
"""

import warnings

from core.runtime_env import debug_imports_enabled


if debug_imports_enabled():
    warnings.warn(
        "tg_bot.tmdb_match is a compatibility shim (implementation lives in tmdb_match_core/tmdb_match_api/tmdb_match_guess). "
        "Prefer importing from the split modules for new code.",
        DeprecationWarning,
        stacklevel=2,
    )

from . import tmdb_match_core as _tmdb_match_core
from . import tmdb_match_api as _tmdb_match_api
from . import tmdb_match_guess as _tmdb_match_guess

# Keep a strict, stable public surface for star-import users.
# NOTE: Derived from the pre-split (v1.7.60) module's top-level defs/consts.
__all__ = [
    "Candidate",
    "IMDB_ID_RE",
    "detect_tv_hint",
    "dump_candidates_for_storage",
    "extract_imdb_id_from_text",
    "extract_tmdb_id_from_text",
    "fetch_tmdb_alias_titles",
    "fetch_tmdb_detail",
    "fetch_tv_season_episode_count",
    "find_by_external_id",
    "guess_tmdb_from_filename",
    "has_tv_hints",
    "load_candidates_from_storage",
    "logger",
    "make_title_fingerprint",
    "make_series_fingerprints",
    "normalize_title",
    "parse_title_year_from_filename",
    "score_candidate",
    "score_candidate_meta",
    "search_candidates_via_tmdb",
    "should_auto_pick",
]

# ---- Re-exports (IMPORTANT) -------------------------------------------------
# Only importing the split modules above does NOT expose their attributes on
# this module. Callers using `from tg_bot.tmdb_match import ...` must see these
# symbols here.

# Core utilities & scoring
Candidate = _tmdb_match_core.Candidate
IMDB_ID_RE = _tmdb_match_core.IMDB_ID_RE
detect_tv_hint = _tmdb_match_core.detect_tv_hint
extract_tmdb_id_from_text = _tmdb_match_core.extract_tmdb_id_from_text
has_tv_hints = _tmdb_match_core.has_tv_hints
logger = _tmdb_match_core.logger
make_title_fingerprint = _tmdb_match_core.make_title_fingerprint
make_series_fingerprints = _tmdb_match_core.make_series_fingerprints
normalize_title = _tmdb_match_core.normalize_title
parse_title_year_from_filename = _tmdb_match_core.parse_title_year_from_filename
score_candidate = _tmdb_match_core.score_candidate
score_candidate_meta = _tmdb_match_core.score_candidate_meta
should_auto_pick = _tmdb_match_core.should_auto_pick

# TMDB network API
extract_imdb_id_from_text = _tmdb_match_api.extract_imdb_id_from_text
fetch_tmdb_alias_titles = _tmdb_match_api.fetch_tmdb_alias_titles
fetch_tmdb_detail = _tmdb_match_api.fetch_tmdb_detail
fetch_tv_season_episode_count = _tmdb_match_api.fetch_tv_season_episode_count
find_by_external_id = _tmdb_match_api.find_by_external_id
search_candidates_via_tmdb = _tmdb_match_api.search_candidates_via_tmdb

# Guess / local heuristics
dump_candidates_for_storage = _tmdb_match_guess.dump_candidates_for_storage
guess_tmdb_from_filename = _tmdb_match_guess.guess_tmdb_from_filename
load_candidates_from_storage = _tmdb_match_guess.load_candidates_from_storage
