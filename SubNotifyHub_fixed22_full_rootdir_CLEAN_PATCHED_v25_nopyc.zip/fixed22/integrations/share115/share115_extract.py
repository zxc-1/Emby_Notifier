from __future__ import annotations

"""Helpers to extract file lists/titles from 115 share responses.

Root cause addressed:
Some 115 share/snap payload variants (often when a share root contains a *single folder*)
do NOT reliably mark that entry as a directory (missing/odd `is_dir`, no `fid`, etc.).

When we mis-classify that folder as a file:
  - BFS cannot descend -> we never see episode filenames like "S01E.."
  - TMDB hint becomes only the outer folder/share title -> wrong movie/TV guess

So we add extra dir-detection heuristics:
  - Treat non-zero numeric flags as truthy (e.g. is_dir=2)
  - If no `fid` but `cid` exists, size==0, name has no extension, and no pick_code -> likely folder
"""

import logging
from core.logging import get_biz_logger_adapter

import re
from typing import Any, Dict, List

from .share115_models import ShareFile

__all__ = ["extract_share_files", "extract_share_title"]

logger = get_biz_logger_adapter(__name__)

def _as_int(v: Any) -> int:
    try:
        return int(v)
    except (ValueError, TypeError) as e:
        logger.detail(f"整数转换失败 - 输入值={v!r}, 原因={type(e).__name__}")
        return 0



def _brief_raw_item(it: Dict[str, Any]) -> Dict[str, Any]:
    """Pick a stable subset of fields for debugging 115 payload shape."""
    if not isinstance(it, dict):
        return {"_type": str(type(it))}
    keys = list(it.keys())
    # common keys observed in 115 webapi variants
    pick = {}
    for k in (
        "n","name","file_name",
        "fid","file_id","id",
        "cid","pid","pcid",
        "is_dir","is_folder","folder",
        "ico","fc","file_category","type",
        "pick_code","pc",
        "s","size","file_size",
        "sha","md5","t","te","utime","ptime",
    ):
        if k in it:
            v = it.get(k)
            # shorten big strings
            if isinstance(v, str) and len(v) > 120:
                v = v[:120] + "…"
            pick[k] = v
    pick["_keys"] = keys[:60]
    pick["_keys_more"] = len(keys) - min(len(keys), 60)
    return pick


def extract_share_files(payload: Dict[str, Any]) -> List[ShareFile]:
    """Extract file list from share/snap response (tolerant to shape variations).

    P0 fix: do field normalization first (dir_id/file_id), then decide `chosen`,
    and only then apply empty checks. This avoids dropping directory entries when
    115 payload fields drift (cid/fid/id variants).
    """
    root = payload or {}
    data = root.get("data") if isinstance(root, dict) else None
    if not isinstance(data, dict):
        data = root if isinstance(root, dict) else {}

    cand = (
        data.get("list")
        or data.get("filelist")
        or data.get("files")
        or data.get("items")
        or []
    )
    if not isinstance(cand, list):
        cand = []

    out: List[ShareFile] = []
    skipped_no_id = 0

    for it in cand:
        if not isinstance(it, dict):
            continue

        name = str(it.get("n") or it.get("file_name") or it.get("name") or "").strip()
        if not name:
            continue

        # --- is_dir normalization (robust across 115 variants) ---
        raw_is_dir = it.get("is_dir") or it.get("is_folder") or it.get("folder") or it.get("isFolder")
        # Some 115 variants use int flags beyond {0,1}. Treat any non-zero int as dir.
        is_dir = str(raw_is_dir or "0").strip().lower() in ("1", "true", "yes", "2")
        if (not is_dir) and isinstance(raw_is_dir, int) and raw_is_dir != 0:
            is_dir = True

        # Some APIs use file_category/type/ico/fc for folder-ness.
        t = it.get("ico") or it.get("type") or it.get("file_category") or it.get("fc")
        t = str(t).lower().strip() if t is not None else ""
        low_name = name.lower()

        # Heuristic: only treat season-like names as folders when the name does NOT look like a file.
        # This prevents misclassifying files like "Season 1 (2019).mkv" as directories.
        has_ext = "." in low_name and len(low_name.rsplit(".", 1)[-1]) <= 6
        ext = ("." + low_name.rsplit(".", 1)[-1]) if has_ext else ""
        fileish = bool(has_ext and ext and ext not in {".", ".."})

        if (not is_dir) and t in ("folder", "dir", "directory"):
            is_dir = True
        if (not is_dir) and (not fileish) and (
            re.search(r"\bseason\s*\d+\b", low_name) or re.search(r"\bs\d{1,2}\b", low_name)
        ):
            # Some payloads fail to mark season folders as directories.
            is_dir = True

        # Parse size early: used by heuristics below.
        size = _as_int(it.get("s") or it.get("file_size") or it.get("size") or 0)

        # --- id normalization: unify (dir_id/file_id) ---
        cid_raw = it.get("cid")
        cid = str(cid_raw).strip() if cid_raw not in (None, "") else ""

        fid_raw = (
            it.get("fid")
            or it.get("file_id")
            or it.get("fileId")
            or it.get("id")
            or it.get("fileid")
        )
        fid = str(fid_raw).strip() if fid_raw not in (None, "") else ""

        # Some payloads omit folder flags for shares that contain a single *folder* at root.
        # A particularly tricky variant: the web UI shows an aggregated folder size (e.g. 122GB),
        # and the API may also return a non-zero `size` even though the entry is a directory.
        #
        # Robust heuristic:
        #   - name does NOT look like a file (no extension)
        #   - there is NO pick_code (files almost always have it)
        #   - and we have some id to descend into (fid/cid)
        # -> treat as directory so BFS can descend.
        if (not is_dir) and (not fileish):
            pc = it.get("pick_code") or it.get("pc")
            has_pick = bool(str(pc).strip()) if pc is not None else False
            if (not has_pick) and (fid or (cid and cid not in ("0", "None"))):
                is_dir = True

        # NOTE:
        # - `cid` is often the *parent/current directory id* in share/snap.
        # - Folder items typically carry their own id in fid/file_id/id.
        # - Some payload variants only provide cid for folder items; keep it as a last-resort fallback.
        dir_id = fid or (cid if cid not in ("0", "None") else "")
        file_id = fid or (cid if cid not in ("0", "None") else "")

        chosen = dir_id if is_dir else file_id
        if not chosen:
            if skipped_no_id < 5:
                logger.detail("share115 skip item missing id：操作异常：%s", _brief_raw_item(it))
                skipped_no_id += 1
            continue

        out.append(ShareFile(file_id=chosen, name=name, size=size, is_dir=is_dir))

    return out




def extract_share_title(payload: Dict[str, Any]) -> str:
    """Best-effort extract share title from share/snap payload.

    115 webapi response shape is not stable; we try several common keys.
    """
    root = payload or {}
    data = root.get("data") if isinstance(root, dict) else None
    if not isinstance(data, dict):
        data = root if isinstance(root, dict) else {}

    # Common locations
    candidates = []
    for k in ("share_title", "share_name", "title", "name"):
        v = data.get(k)
        if isinstance(v, str) and v.strip():
            candidates.append(v.strip())
    for k in ("shareinfo", "share_info", "share"):
        info = data.get(k)
        if isinstance(info, dict):
            for kk in ("share_title", "title", "name"):
                v = info.get(kk)
                if isinstance(v, str) and v.strip():
                    candidates.append(v.strip())
    # Heuristic: pick the longest non-empty title
    candidates = [c for c in candidates if c and len(c) >= 2]
    if not candidates:
        return ""
    candidates.sort(key=lambda x: len(x), reverse=True)
    return candidates[0]

