from __future__ import annotations

"""115 share rate/concurrency limits.

Shared helpers for both share115_client and share115_resolve.

This file exists to avoid circular imports (share115_resolve imports Share115Client).
"""
import logging
from core.logging import get_biz_logger_adapter
logger = get_biz_logger_adapter(__name__)


import asyncio

from core.loop_local import loop_local
from core.rate_limiter import AsyncRateLimiter
from ports.settings_provider import get_settings


def _get_share115_semaphore() -> asyncio.Semaphore:
    """Process-wide concurrency cap, stored per event loop."""
    try:
        s = get_settings()
        n = int(getattr(s, 'SHARE115_GLOBAL_MAX_CONCURRENCY', 6) or 6)
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"115并发限制配置解析失败，使用默认值 - 配置项=SHARE115_GLOBAL_MAX_CONCURRENCY, 默认值=6, 原因={type(e).__name__}")
        n = 6
    n = max(1, min(32, int(n)))

    st = loop_local('share115:global_sem', lambda: {'sem': None, 'n': 0})
    sem = st.get('sem')
    if sem is None or int(st.get('n', 0) or 0) != n:
        sem = asyncio.Semaphore(n)
        st['sem'] = sem
        st['n'] = n
    return sem


def _get_share115_rate_limiter() -> AsyncRateLimiter:
    """Min-interval limiter (ms) between 115 API calls, stored per event loop."""
    try:
        s = get_settings()
        ms = int(getattr(s, 'SHARE115_MIN_INTERVAL_MS', 0) or 0)
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"115速率限制配置解析失败，使用默认值 - 配置项=SHARE115_MIN_INTERVAL_MS, 默认值=0ms, 原因={type(e).__name__}")
        ms = 0
    ms = max(0, min(2000, int(ms)))

    st = loop_local('share115:min_interval', lambda: {'rl': None, 'ms': 0})
    rl = st.get('rl')
    if rl is None or int(st.get('ms', 0) or 0) != ms:
        rl = AsyncRateLimiter(ms)
        st['rl'] = rl
        st['ms'] = ms
    return rl
