from __future__ import annotations

"""Wrappers around :mod:`domain.share115.url`.

Pure parsing/build logic lives in :mod:`domain`.
This module keeps backward compatible import paths while allowing settings
to control the default host.
"""
import logging
from core.logging import get_biz_logger_adapter
logger = get_biz_logger_adapter(__name__)


from domain.share115 import url as _url
from ports.settings_provider import get_settings

__all__ = [
    "parse_share_url",
    "normalize_share_host",
    "default_share_host",
    "pick_share_host_from_url",
    "build_share_url",
]


def _default_host() -> str:
    try:
        s = get_settings()
        v = str(getattr(s, "SHARE115_DEFAULT_HOST", "") or "").strip().lower()
    except (AttributeError, TypeError) as e:
        logger.detail(f"115分享默认域名配置解析失败 - 配置项=SHARE115_DEFAULT_HOST, 原因={type(e).__name__}")
        v = ""
    return _url.default_share_host(v)


def parse_share_url(url: str):
    return _url.parse_share_url(url)


def normalize_share_host(host: str | None) -> str:
    return _url.normalize_share_host(host, configured_default=_default_host())


def default_share_host() -> str:
    return _default_host()


def pick_share_host_from_url(url: str) -> str:
    return _url.pick_share_host_from_url(url, configured_default=_default_host())


def build_share_url(share_code: str, receive_code: str | None = None, base_host: str | None = None) -> str:
    return _url.build_share_url(
        share_code,
        receive_code=receive_code,
        base_host=base_host,
        configured_default=_default_host(),
    )
