from __future__ import annotations

"""115 share BFS/resolve logic.

This module contains the async scanning routine that tries to find a representative
video from a share by traversing a limited number of folders.

It is intentionally separated from URL parsing (`share115_url`) and HTTP transport
(`share115_client`) to keep responsibilities clear and make testing easier.
"""

import asyncio
import hashlib
import json
from core.logging import get_biz_logger
import re
from collections import deque
from typing import Any, Dict, Optional, Tuple

from core.cache import TTLCache
from core.rate_limiter import AsyncRateLimiter
from core.loop_local import loop_local
from ports.stores import get_kv_store, get_kv_store_async
from ports.settings_provider import get_settings

from .share115_client import Share115Client
from .share115_extract import extract_share_files, extract_share_title
from core.suppress import safe_hash8
from .share115_models import ShareFile
from .share115_errors import Share115Error, classify_share115_error
from .share115_select import count_video_files, pick_best_video_file, is_video_filename, _BAD_VIDEO_NAME_RE

biz = get_biz_logger(__name__)

__all__ = ["resolve_best_video_for_share"]



def _extract_claimed_count(payload: Dict[str, Any]) -> Optional[int]:
    """Best-effort extract total count from 115 payload."""
    try:
        root = payload or {}
        data = root.get('data') if isinstance(root, dict) else None
        if not isinstance(data, dict):
            data = root if isinstance(root, dict) else {}
        for k in ('count','total','total_count','file_count','item_count'):
            v = data.get(k)
            if v not in (None, ''):
                try:
                    iv = int(v)
                    if iv >= 0:
                        return iv
                except (TypeError, ValueError):
                    continue
        pg = data.get('page') if isinstance(data, dict) else None
        if isinstance(pg, dict):
            for k in ('count','total','total_count'):
                v = pg.get(k)
                if v not in (None, ''):
                    try:
                        iv = int(v)
                        if iv >= 0:
                            return iv
                    except (TypeError, ValueError):
                        continue
    except (TypeError, AttributeError, KeyError) as e:
        biz.detail("提取声明数量失败", error=type(e).__name__)
    return None


async def _snap_paged_files(
    client: 'Share115Client',
    *,
    share_code: str,
    receive_code: str | None,
    cid: int,
) -> tuple[Dict[str, Any], list[ShareFile], Dict[str, Any]]:
    """Snap a directory with pagination and basic consistency stats."""
    try:
        s = get_settings()
        limit = int(getattr(s, 'SHARE115_SNAP_PAGE_LIMIT', 200) or 200)
    except (TypeError, ValueError, AttributeError) as e:
        biz.detail("获取分页限制失败", error=type(e).__name__)
        limit = 200
    limit = max(50, min(1000, int(limit)))

    try:
        s = get_settings()
        max_pages = int(getattr(s, 'SHARE115_SNAP_MAX_PAGES', 10) or 10)
    except (TypeError, ValueError, AttributeError) as e:
        biz.detail("获取最大页数失败", error=type(e).__name__)
        max_pages = 10
    max_pages = max(1, min(50, int(max_pages)))

    try:
        s = get_settings()
        max_items = int(getattr(s, 'SHARE115_SNAP_MAX_ITEMS', 4000) or 4000)
    except (TypeError, ValueError, AttributeError) as e:
        biz.detail("获取最大项数失败", error=type(e).__name__)
        max_items = 4000
    max_items = max(200, min(20000, int(max_items)))

    payload0 = await client.snap(share_code=share_code, receive_code=receive_code, cid=cid, offset=0, limit=limit)
    claimed = _extract_claimed_count(payload0)

    files_all: list[ShareFile] = []
    seen_ids: set[str] = set()

    def _merge(fs: list[ShareFile]) -> None:
        for f in fs or []:
            try:
                fid = str(getattr(f, 'file_id', '') or '')
            except Exception:
                fid = ''
            if not fid or fid in seen_ids:
                continue
            seen_ids.add(fid)
            files_all.append(f)

    fs = extract_share_files(payload0)
    _merge(fs)

    pages = 1
    offset = limit
    while pages < max_pages and len(fs) >= limit and len(files_all) < max_items:
        if claimed is not None and claimed >= 0 and offset >= claimed:
            break
        payload = await client.snap(share_code=share_code, receive_code=receive_code, cid=cid, offset=offset, limit=limit)
        fs = extract_share_files(payload)
        if not fs:
            break
        _merge(fs)
        pages += 1
        if len(fs) < limit:
            break
        offset += limit

    paging: Dict[str, Any] = {
        'cid': int(cid),
        'limit': int(limit),
        'pages': int(pages),
        'claimed_count': int(claimed) if claimed is not None else None,
        'items': int(len(files_all)),
    }
    try:
        paging['count_mismatch'] = bool(claimed is not None and int(claimed) > 0 and int(claimed) != int(len(files_all)))
    except Exception:
        paging['count_mismatch'] = False

    return payload0, files_all, paging

def _safe_text_for_log(text: str, *, max_len: int = 120) -> str:
    """Avoid leaking share titles/paths in INFO logs.

    - If SHARE115_LOG_SAMPLES is enabled, allow limited plaintext (truncated).
    - Otherwise, log only a stable short hash.
    """
    t = str(text or "").strip()
    if not t:
        return ""
    if _log_samples_enabled():
        return (t[: max_len - 1] + "…") if len(t) > max_len else t
    return f"sha1:{safe_hash8(t, default='00000000')}"

def _log_samples_enabled() -> bool:
    """Whether to allow limited plaintext samples in INFO logs."""
    try:
        s = get_settings()
        return bool(getattr(s, "SHARE115_LOG_SAMPLES", False))
    except (TypeError, AttributeError) as e:
        biz.detail("获取日志采样配置失败", error=type(e).__name__)
        return False


_RESOLVE_CACHE: TTLCache[tuple[str, str, int, int], dict] = TTLCache(maxsize=256, default_ttl=15 * 60)

# Global (process-wide) 115 rate controls: prevent bursty concurrent requests when multiple
# share links are processed at the same time.
def _get_share115_semaphore() -> asyncio.Semaphore:
    try:
        s = get_settings()
        n = int(getattr(s, 'SHARE115_GLOBAL_MAX_CONCURRENCY', 6) or 6)
    except (TypeError, ValueError, AttributeError) as e:
        biz.detail("获取并发限制失败", error=type(e).__name__)
        n = 6
    n = max(1, min(32, int(n)))
    st = loop_local("share115:global_sem", lambda: {"sem": None, "n": 0})
    sem = st.get("sem")
    if sem is None or int(st.get("n", 0) or 0) != n:
        sem = asyncio.Semaphore(n)
        st["sem"] = sem
        st["n"] = n
    return sem

def _get_share115_rate_limiter() -> AsyncRateLimiter:
    try:
        s = get_settings()
        ms = int(getattr(s, 'SHARE115_MIN_INTERVAL_MS', 0) or 0)
    except (TypeError, ValueError, AttributeError) as e:
        biz.detail("获取速率限制间隔失败", error=type(e).__name__)
        ms = 0
    ms = max(0, min(2000, int(ms)))
    st = loop_local("share115:min_interval", lambda: {"rl": None, "ms": 0})
    rl = st.get("rl")
    if rl is None or int(st.get("ms", 0) or 0) != ms:
        rl = AsyncRateLimiter(ms)
        st["rl"] = rl
        st["ms"] = ms
    return rl






# BFS scan batch size: concurrent share/snap calls per scan round.
# Exposed as a setting to let power users trade speed vs. rate-limit risk.
_share115_bfs_batch_size: int | None = None
_share115_bfs_batch_size_n: int = 0

def _get_share115_bfs_batch_size() -> int:
    global _share115_bfs_batch_size, _share115_bfs_batch_size_n
    try:
        s = get_settings()
        n = int(getattr(s, 'SHARE115_BFS_BATCH_SIZE', 4) or 4)
    except (TypeError, ValueError, AttributeError) as e:
        biz.detail("获取BFS批量大小失败", error=type(e).__name__)
        n = 4
    n = max(1, min(10, int(n)))
    if _share115_bfs_batch_size is None or _share115_bfs_batch_size_n != n:
        _share115_bfs_batch_size = n
        _share115_bfs_batch_size_n = n
    return int(_share115_bfs_batch_size or 4)


async def resolve_best_video_for_share(
    client: "Share115Client",
    *,
    share_code: str,
    receive_code: str | None = None,
    max_depth: int = 3,
    max_dir_scans: int = 10,
) -> Dict[str, Any]:
    """Try to resolve a best video filename (or a title-ish hint) from a share.

    Returns:
      { ok, filename, dir_path, video_count, hint_name, share_title }

    Notes:
      - share/snap lists only one directory (cid). Many shares put videos under folders.
      - We scan a limited number of directories to avoid rate limits.
      - If no video file is found, we fall back to a likely *folder/share title* so TMDB
        matching can still work for Blu-ray/BDMV shares.
    """
    with biz.entry(
        domain="115",
        action="分享解析",
        group_title="115 分享解析",
        share_code=safe_hash8(share_code),
        receive_code=bool(receive_code),
        max_depth=max_depth,
        max_dir_scans=max_dir_scans,
    ):

        # Resolve-cache: avoid repeating expensive BFS scans for the same share link and scan params.
        key = (str(share_code), str(receive_code or ""), int(max_depth), int(max_dir_scans))
        # Persistent cache key (cross-process): includes share link + scan params.
        pkey = f"share115_resolve:{str(share_code)}:{str(receive_code or '')}:{int(max_depth)}:{int(max_dir_scans)}"
        # Root signature (set after root listing); used to validate persistent cache entries.
        root_sig: str = ""
        biz.step("检查缓存", i=1, total=5, cache="mem")
        cached = _RESOLVE_CACHE.get(key)
        if isinstance(cached, dict) and cached.get("ok") is not None:
            biz.ok("命中内存缓存", ok=bool(cached.get("ok")), reason=str(cached.get("reason") or ""))
            return dict(cached)


        def _looks_rate_limited(reason: str) -> bool:
            t = str(reason or "").lower()
            if not t:
                return False
            needles = [
                "429",
                "too many requests",
                "rate limit",
                "ratelimit",
                "too fast",
                "频繁",
                "过于频繁",
                "访问过快",
                "限制",
                "risk",
                "风控",
            ]
            return any(n in t for n in needles)

        async def _cache(out: Dict[str, Any], *, ttl: int | None = None) -> Dict[str, Any]:
            """Cache resolve results.

            Rule:
              - Cache ok=True results (normal TTL).
              - Cache ok=False *rate-limit* failures for a short TTL to avoid request storms.
                Other failures are not cached.
            """
            try:
                ok = bool(out.get("ok"))
            except (TypeError, AttributeError) as e:
                biz.detail("解析结果状态失败", error=type(e).__name__)
                ok = False

            if not ok:
                # Short negative cache for rate-limit errors to prevent storms.
                try:
                    if _looks_rate_limited(str(out.get("reason") or "")):
                        _RESOLVE_CACHE.set(key, dict(out), ttl=int(ttl or 15))
                except (TypeError, ValueError) as e:
                    biz.detail("缓存速率限制失败", error=type(e).__name__)
                    pass
                return out

            try:
                _RESOLVE_CACHE.set(key, dict(out), ttl=ttl)
            except (TypeError, ValueError) as e:
                biz.detail("缓存解析结果失败", error=type(e).__name__)
                pass

            # Best-effort persistent cache (SQLite kv_cache) for cross-process/restart speed-ups.
            #
            # IMPORTANT (test contract): unit tests patch `get_kv_store` to provide an isolated
            # in-memory store. Therefore, this resolve routine should use `get_kv_store()` for
            # the persistent cache so the tests can deterministically assert BFS behavior.
            # (Using the async singleton store would leak cache across tests/runs.)
            try:
                s = get_settings()
                ttl_p = int(getattr(s, "SHARE115_RESOLVE_PERSIST_TTL_SEC", 24 * 3600) or (24 * 3600))
            except (TypeError, ValueError, AttributeError) as e:
                biz.detail("获取持久化TTL失败", error=type(e).__name__)
                ttl_p = 24 * 3600
            if int(ttl_p) <= 0:
                return out
            ttl_p = max(60, min(7 * 24 * 3600, int(ttl_p)))

            try:
                outp = dict(out)
                # Attach root_sig if available (may not exist on early failures / pre-root).
                try:
                    rs = str(root_sig)  # type: ignore[name-defined]
                except (TypeError, NameError) as e:
                    biz.detail("获取根签名失败", error=type(e).__name__)
                    rs = ""
                if rs and (not str(outp.get("root_sig") or "").strip()):
                    outp["root_sig"] = rs
                # Persist to KV cache for cross-process/restart speed-ups (non-blocking).
                store = get_kv_store()
                # Use a thread to avoid blocking the event loop when the backend is SQLite.
                await asyncio.to_thread(store.set_json, str(pkey), outp, ttl_sec=ttl_p)
            except (TypeError, ValueError, KeyError) as e:
                biz.detail("持久化缓存失败", error=type(e).__name__)
                pass

            return out


        def _dir_rank(name: str) -> tuple[int, int, int]:
            n0 = (name or "").strip()
            n = n0.lower().strip()
            if not n:
                return (0, 0, 0)

            # Special-case: for BDMV structures, the real video is under BDMV/STREAM.
            # STREAM should be scanned early; treating it as "bad" causes BFS to miss the m2ts files.
            if n == "stream":
                return (6, len(n), 0)

            # Negative signals (extras/trailer/sample folders)
            bad = 0
            if re.search(r"\b(sample|trailer|teaser|extras?|extra|featurette|behind|making|interview|promo|preview)\b", n):
                bad = 2
            if re.search(r"(花絮|预告|片花|特辑|制作|采访|番外|彩蛋|PV|CM|NCOP|NCED)", n0):
                bad = max(bad, 2)

            # Disc structure folders are usually not the best "title folders"
            if n in {"bdmv", "playlist", "menus", "menu", "clpi", "mpls"}:
                bad = max(bad, 1)

            # Prefer folders that look like seasons or complete packs
            seasonish = 2 if ("season" in n or re.search(r"\bs\d{1,2}\b", n) or ("第" in n0 and "季" in n0)) else 0
            completeish = 1 if re.search(r"\b(complete|全集|全\d+集|完结|完結)\b", n, flags=re.IGNORECASE) else 0

            # Prefer longer "title-ish" folder names
            titleish = 1 if (len(n) >= 6) else 0

            score = seasonish + completeish + titleish - bad
            return (score, len(n), -bad)

        try:
            payload, root_files, root_paging = await _snap_paged_files(
                client, share_code=share_code, receive_code=receive_code, cid=0
            )
        except Exception as e:
            if isinstance(e, Share115Error):
                cls = classify_share115_error(e)
                return await _cache(
                    {
                        "ok": False,
                        "reason": f"snap_root_failed:{cls.get('reason_code')}",
                        "reason_code": cls.get("reason_code"),
                        "error": cls,
                        "video_count_scope": "unknown",
                    },
                    ttl=5,
                )
            return await _cache({"ok": False, "reason": f"snap_root_failed:{e}", "video_count_scope": "unknown"}, ttl=5)

        share_title = extract_share_title(payload)

        # Root-heal: some shares have a single folder entry, but 115 payload may omit
        # reliable folder flags (is_dir/fid). If we treat that folder as a file, the
        # resolver will never descend and TMDB hints degrade to the outer title only.
        #
        # We probe one level only when the pattern matches (single item, size==0, not a
        # video filename). If probing succeeds, force that entry to be a directory.
        if isinstance(root_files, list) and len(root_files) == 1:
            f0 = root_files[0]
            try:
                nm0 = str(getattr(f0, "name", "") or "")
                low = nm0.lower().strip()
                has_ext = ("." in low) and (len(low.rsplit(".", 1)[-1]) <= 6)
                fileish = bool(has_ext)
                # Some shares expose a single folder at root and the API may NOT mark it as dir.
                # The folder may also report an aggregated non-zero size.
                # So: if it's not a video filename and doesn't look like a file, probe it.
                looks_like_single_dir = (
                    (not bool(getattr(f0, "is_dir", False)))
                    and (not is_video_filename(nm0))
                    and (not fileish)
                )
            except (TypeError, AttributeError) as e:
                biz.detail("检查单目录失败", error=type(e).__name__)
                looks_like_single_dir = False
            if looks_like_single_dir:
                try:
                    cid_probe = int(str(getattr(f0, "file_id", "") or "0"))
                except (TypeError, ValueError, AttributeError) as e:
                    biz.detail("解析探测CID失败", error=type(e).__name__)
                    cid_probe = 0
                if cid_probe > 0:
                    try:
                        payload_probe, probe_files, _probe_paging = await _snap_paged_files(
                            client, share_code=share_code, receive_code=receive_code, cid=cid_probe
                        )
                        if isinstance(probe_files, list) and len(probe_files) > 0:
                            biz.detail(
                                "115 分享根目录修复：单项被视为文件夹",
                                cid=cid_probe,
                                name=_safe_text_for_log(getattr(f0, "name", "")),
                            )
                            root_files = [ShareFile(file_id=str(cid_probe), name=str(getattr(f0, "name", "")), size=0, is_dir=True)]
                    except (TypeError, ValueError, AttributeError) as e:
                        # Probe is best-effort; ignore any errors.
                        biz.detail("探测单目录失败", cid=cid_probe, error=type(e).__name__)
                        pass


        # Persistent cache (SQLite kv_cache): avoid repeating expensive BFS scans across process restarts.
        # We validate against a lightweight "root signature" derived from the root listing we already fetched.
        def _compute_root_sig(files: List[ShareFile]) -> str:
            try:
                items = [(str(f.file_id), str(f.name or ""), 1 if f.is_dir else 0, int(f.size or 0)) for f in (files or [])]
                items.sort()
                if len(items) > 200:
                    items = items[:200]
                raw = json.dumps(items, ensure_ascii=False, separators=(",", ":"))
                return hashlib.sha1(raw.encode("utf-8", errors="ignore")).hexdigest()[:16]
            except (TypeError, AttributeError, ValueError) as e:
                biz.detail("计算根签名失败", error=type(e).__name__)
                return ""

        root_sig = _compute_root_sig(root_files)

        try:
            store = get_kv_store()
            pst = await asyncio.to_thread(store.get_json, str(pkey))
        except (TypeError, ValueError, KeyError) as e:
            biz.detail("读取持久化缓存失败", error=type(e).__name__)
            pst = None
        if isinstance(pst, dict) and pst.get("ok") is True:
            try:
                sig0 = str(pst.get("root_sig") or "")
                if (not sig0) or (sig0 == root_sig):
                    out0 = dict(pst)
                    out0["root_sig"] = root_sig or sig0
                    return await _cache(out0)
            except (TypeError, ValueError, KeyError) as e:
                biz.detail("验证持久化缓存失败", error=type(e).__name__)
                pass


        biz.step("拉取根目录", i=2, total=5)
        biz.detail(
            "115 分享快照根目录",
            title=_safe_text_for_log(share_title),
            items=len(root_files),
            dirs=sum(1 for x in root_files if x.is_dir),
        )
        if root_files and _log_samples_enabled():
            biz.detail(
                "115 分享根目录样本",
                sample=" | ".join(
                    f"{x.name}#{x.file_id}#{'D' if x.is_dir else 'F'}#{x.size or 0}"
                    for x in root_files[:12]
                ),
            )

        # Debug the payload shape (115 frequently changes fields; web view may differ from API).
        try:
            data = payload.get("data") if isinstance(payload, dict) else None
            if not isinstance(data, dict):
                data = payload if isinstance(payload, dict) else {}
            cand = data.get("list") or data.get("filelist") or data.get("files") or data.get("items") or []
            if isinstance(cand, list) and cand and isinstance(cand[0], dict):
                if _log_samples_enabled():
                    biz.detail("115 分享原始根目录项", raw=json.dumps(_brief_raw_item(cand[0]), ensure_ascii=False))
        except (TypeError, AttributeError, KeyError, IndexError) as e:
            biz.detail("调试载荷结构失败", error=type(e).__name__)
            pass

        best = pick_best_video_file(root_files)
        # Defensive: if the "best" picked from root isn't a video, do not early-return.
        # This avoids getting stuck when a folder is misreported as a file.
        if best and is_video_filename(str(best.name or "")):
            hint = best.name
            biz.ok("根目录发现视频", filename=best.name, size=best.size or 0, video_count=count_video_files(root_files), scope="root")
            return await _cache({
                "ok": True,
                "filename": best.name,
                "best_file_id": best.file_id,
                "best_size": best.size or 0,
                "dir_path": [],
                "video_count": count_video_files(root_files),
                "video_count_scope": "root",
                "hint_name": hint,
                "share_title": share_title,
                "video_samples": [best.name] if best.name else [],
                "video_files": ([{"name": best.name, "file_id": best.file_id, "size": int(best.size or 0)}] if best.name else []),
                "paging": (root_paging if "root_paging" in locals() else {}),
            })

        biz.step("BFS 扫描子目录", i=3, total=5, seed_dirs=len([f for f in root_files if f.is_dir]))
        # No video on root: BFS scan folders up to max_depth
        dirs = [f for f in root_files if f.is_dir]
        # Seed with top ranked folders
        dirs = sorted(dirs, key=lambda d: _dir_rank(d.name), reverse=True)
        # Always scan disc-structure dirs early when present (BDMV/STREAM).
        # This improves both accuracy and speed for Blu-ray shares where the real video is under BDMV/STREAM.
        try:
            _specials: list[ShareFile] = []
            _rest: list[ShareFile] = []
            for _d in dirs:
                _ln = (_d.name or "").strip().lower()
                if _ln in {"stream", "bdmv"}:
                    _specials.append(_d)
                else:
                    _rest.append(_d)
            _specials.sort(key=lambda _d: 0 if ((_d.name or "").strip().lower() == "stream") else 1)
            dirs = _specials + _rest
        except (TypeError, AttributeError) as e:
            biz.detail("排序特殊目录失败", error=type(e).__name__)
            pass


        scanned = 0
        best_found: Optional[tuple[ShareFile, List[str], int, List[str], List[dict], Dict[str, Any]]] = None  # (file, path, video_count, samples, video_files, paging)

        # queue entries: (depth, cid, path_names)
        queue = deque()  # (depth, cid, path_names)
        for d in (dirs[: int(max_dir_scans)] if int(max_dir_scans) > 0 else []):
            try:
                cid = int(d.file_id)
            except (TypeError, ValueError, AttributeError) as e:
                biz.detail("解析目录ID失败", name=d.name, error=type(e).__name__)
                continue
            biz.detail("115 分享种子目录", name=_safe_text_for_log(d.name), file_id=d.file_id)
            queue.append((1, cid, [d.name]))

        batch_size = _get_share115_bfs_batch_size()

        while queue and scanned < max_dir_scans:
            # Batch a few directory snaps concurrently to reduce latency under high RTT.
            batch: List[Tuple[int, int, List[str]]] = []
            while queue and (scanned + len(batch)) < max_dir_scans and len(batch) < batch_size:
                batch.append(queue.popleft())

            async def _snap_one(cid: int) -> Any:
                p0, fs, pg = await _snap_paged_files(client, share_code=share_code, receive_code=receive_code, cid=cid)
                return (p0, fs, pg)

            tasks = []
            for _depth, cid, _path in batch:
                tasks.append(_snap_one(cid))

            results = await asyncio.gather(*tasks, return_exceptions=True)
            for _r in results:
                if isinstance(_r, Exception):
                    biz.detail(f"并行任务失败（已忽略）：{type(_r).__name__}", error=str(_r))

            for (depth, cid, path_names), res in zip(batch, results):
                scanned += 1
                path_s = "/".join([_safe_text_for_log(p, max_len=64) for p in (path_names or [])])
                if isinstance(res, Exception):
                    biz.warn_item(
                        "扫描目录失败",
                        i=scanned,
                        total=max_dir_scans,
                        depth=depth,
                        cid=cid,
                        path=path_s,
                        err=repr(res),
                    )
                    continue

                try:
                    _p0, sub_files, sub_paging = res
                except Exception as e:
                    biz.warn_item(
                        "扫描目录解析失败",
                        i=scanned,
                        total=max_dir_scans,
                        depth=depth,
                        cid=cid,
                        path=path_s,
                        err=repr(e),
                    )
                    continue

                dirs_cnt = sum(1 for x in sub_files if x.is_dir)
                vids_cnt = count_video_files(sub_files)
                biz.ok_item(
                    "扫描目录",
                    i=scanned,
                    total=max_dir_scans,
                    depth=depth,
                    cid=cid,
                    path=path_s,
                    items=len(sub_files),
                    dirs=dirs_cnt,
                    vids=vids_cnt,
                )

                if sub_files and _log_samples_enabled():
                    try:
                        biz.detail(
                            "115 分享子目录样本",
                            sample=" | ".join([f"{x.name}#{x.file_id}#{1 if x.is_dir else 0}#{x.size or 0}" for x in sub_files[:12]]),
                        )
                    except (TypeError, AttributeError) as e:
                        biz.detail("记录子目录样本失败", error=type(e).__name__)
                        pass

                sub_best = pick_best_video_file(sub_files)
                if sub_best:
                    vc = vids_cnt
                    # collect representative video names for downstream matching (accuracy)
                    try:
                        vids0 = [x for x in sub_files if (not x.is_dir) and is_video_filename(x.name)]
                        vids0 = sorted(vids0, key=lambda x: (x.size or 0), reverse=True)
                        samples = [x.name for x in vids0[:5] if x.name]
                        video_files_detail = [
                            {"name": x.name, "file_id": x.file_id, "size": int(x.size or 0)}
                            for x in vids0
                            if x.name
                        ]
                        try:
                            _pg = dict(sub_paging) if isinstance(sub_paging, dict) else {}
                        except (TypeError, ValueError):
                            _pg = {}
                    except (TypeError, AttributeError, ValueError) as e:
                        biz.detail("收集视频样本失败", error=type(e).__name__)
                        samples = []
                        video_files_detail = []
                        _pg = {}
                    if best_found is None or (sub_best.size or 0) > (best_found[0].size or 0):
                        best_found = (sub_best, path_names, vc, samples, video_files_detail, _pg)

                
                    # Early stop (TV/season packs): when a folder clearly contains many episodes,
                    # scanning deeper siblings rarely changes the final hint but costs a lot of 115 calls.
                    try:
                        s = get_settings()
                        ep_min = int(getattr(s, "SHARE115_EPISODE_EARLY_STOP_MIN_VIDEOS", 8) or 8)
                    except (TypeError, ValueError, AttributeError) as e:
                        biz.detail("获取剧集早停阈值失败", error=type(e).__name__)
                        ep_min = 8
                    if int(ep_min) <= 0:
                        ep_min = 10**9  # disabled
                    else:
                        ep_min = max(4, min(30, int(ep_min)))

                    try:
                        if vc >= ep_min:
                            # Avoid stopping on noise/extras folders or Blu-ray structures.
                            pn_last = (path_names[-1] if path_names else "")
                            pn_all = "/".join([str(x or "") for x in (path_names or [])]).lower()
                            if ("bdmv" not in pn_all) and ("stream" not in pn_all) and (_BAD_VIDEO_NAME_RE.search(pn_last or "") is None):
                                episodish = 0
                                for nm in (samples or []):
                                    if re.search(r"(?i)\bS\d{1,2}E\d{1,3}\b|\bE\d{1,3}\b|第\s*\d+\s*集", str(nm or "")):
                                        episodish += 1
                                # If we have at least a couple episode-like filenames (or very high count), treat as season pack.
                                if episodish >= 2 or vc >= (ep_min + 4):
                                    queue.clear()
                                    break
                    except (TypeError, AttributeError, IndexError) as e:
                        biz.detail("检查剧集早停失败", error=type(e).__name__)
                        pass

                    # Early stop: if we found a large main file (or single-file folder), scanning further rarely changes the hint.
                    try:
                        if (sub_best.size or 0) >= (4 * 1024 * 1024 * 1024) or (vc <= 1 and (sub_best.size or 0) >= (2 * 1024 * 1024 * 1024)):
                            queue.clear()
                            break
                    except (TypeError, AttributeError) as e:
                        biz.detail("检查大文件早停失败", error=type(e).__name__)
                        pass

                # Expand BFS only when we did NOT find a video in this folder.
                if depth < max_depth and not sub_best:
                    sub_dirs = [x for x in sub_files if x.is_dir]
                    sub_dirs = sorted(sub_dirs, key=lambda d: _dir_rank(d.name), reverse=True)
                    for sd in sub_dirs[:3]:
                        try:
                            cid2 = int(sd.file_id)
                        except (TypeError, ValueError, AttributeError) as e:
                            biz.detail("解析子目录ID失败", name=sd.name, error=type(e).__name__)
                            continue
                        queue.append((depth + 1, cid2, path_names + [sd.name]))

        if best_found:
            f, path, vc, samples, video_files_detail, pg = best_found
            hint = " ".join([x for x in path if x] + [f.name])
            return await _cache({"ok": True, "filename": f.name, "best_file_id": f.file_id, "best_size": f.size or 0, "dir_path": path, "video_count": vc, "video_count_scope": "folder", "hint_name": hint, "share_title": share_title, "video_samples": samples, "video_files": video_files_detail, "paging": pg})


        # Fallback: try to provide a title-ish hint even when no video is detected.
        # Common for Blu-ray/BDMV shares where the actual video is deep under STREAM.
        hint_candidates = []
        if share_title:
            hint_candidates.append(share_title)
        # Prefer non-noise folder names
        for d in dirs[:10]:
            n = (d.name or "").strip()
            if not n:
                continue
            if (n.lower() in {"bdmv", "stream", "playlist", "menu", "menus"}):
                continue
            hint_candidates.append(n)

        hint_candidates = [h for h in hint_candidates if h and len(h) >= 2]
        if hint_candidates:
            hint_candidates.sort(key=lambda x: len(x), reverse=True)
            hint = hint_candidates[0]
            return await _cache({"ok": True, "filename": hint, "dir_path": [], "video_count": 0, "video_count_scope": "unknown", "hint_name": hint, "share_title": share_title, "fallback": True})

        return await _cache({"ok": False, "reason": "no_video_found", "video_count_scope": "unknown"}, ttl=10)
