"""115 share integration.

Stable public imports (preferred):

- `from integrations.share115 import Share115Client`
- `from integrations.share115 import parse_share_url, build_share_url, pick_share_host_from_url, normalize_share_host`
- `from integrations.share115 import resolve_best_video_for_share`

Implementation is split into:
- `share115_url.py` (URL parsing/building)
- `share115_client.py` (HTTP transport)
- `share115_resolve.py` (BFS scanning/resolution)

A legacy `core.py` remains as a compatibility import path.
"""

from .share115_client import Share115Client  # noqa: F401
from .share115_url import (  # noqa: F401
    parse_share_url,
    build_share_url,
    pick_share_host_from_url,
    normalize_share_host,
)
from .share115_resolve import resolve_best_video_for_share  # noqa: F401

__all__ = [
    "Share115Client",
    "parse_share_url",
    "build_share_url",
    "pick_share_host_from_url",
    "normalize_share_host",
    "resolve_best_video_for_share",
]
