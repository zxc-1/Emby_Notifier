"""Thin re-export for resolver functions."""

from .share115_resolve import resolve_best_video_for_share

__all__ = ["resolve_best_video_for_share"]
