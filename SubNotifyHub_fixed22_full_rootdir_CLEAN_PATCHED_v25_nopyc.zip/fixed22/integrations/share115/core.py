from __future__ import annotations

"""Legacy compatibility module for 115 share integration.

Historically, this integration lived in a single large `core.py`. For maintainability,
it has been split into focused modules:

- share115_url: URL parse/build/host normalization
- share115_errors: tolerant business/errno handling
- share115_client: HTTP transport client
- share115_extract: payload extraction helpers
- share115_select: video selection heuristics
- share115_resolve: BFS scanning & best-video resolution

This file remains as a stable import path for older call sites.
"""

from .share115_models import ShareFile
from .share115_url import (
    parse_share_url,
    normalize_share_host,
    default_share_host,
    pick_share_host_from_url,
    build_share_url,
)
from .share115_errors import (
    Share115Error,
    _to_str,
    _parse_errno,
    _looks_like_business_ok,
    _is_retryable_errno,
)
from .share115_client import Share115Client
from .share115_extract import extract_share_files, extract_share_title
from .share115_select import (
    is_video_filename,
    pick_best_video_file,
    count_video_files,
    pick_best_video_name,
)
from .share115_resolve import resolve_best_video_for_share

__all__ = [
    # Models
    "ShareFile",
    # URL helpers
    "parse_share_url",
    "normalize_share_host",
    "default_share_host",
    "pick_share_host_from_url",
    "build_share_url",
    # Errors + helpers (semi-private but kept for backward compat)
    "Share115Error",
    "_to_str",
    "_parse_errno",
    "_looks_like_business_ok",
    "_is_retryable_errno",
    # Client
    "Share115Client",
    # Extract/select
    "extract_share_files",
    "extract_share_title",
    "is_video_filename",
    "pick_best_video_file",
    "count_video_files",
    "pick_best_video_name",
    # Resolver
    "resolve_best_video_for_share",
]
