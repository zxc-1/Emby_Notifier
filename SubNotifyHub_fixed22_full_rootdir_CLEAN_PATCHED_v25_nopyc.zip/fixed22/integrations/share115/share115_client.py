from __future__ import annotations

from core.exceptions.base import ExternalServiceError

"""115 share HTTP client.

The client encapsulates the webapi.115.com request/retry + tolerant response
parsing logic. Higher-level BFS scanning lives in `share115_resolve.py`.
"""

import asyncio
import time
from typing import Any, Dict, Optional, Tuple

import httpx

from core.cache import TTLCache
from core.http import async_request_with_retry
from core.http import get_http_client
from core.logging import get_biz_logger, log_fetch, log_ok
from ports.settings_provider import get_settings

from .share115_limits import _get_share115_rate_limiter, _get_share115_semaphore

from .share115_errors import (
    Share115Error,
    _looks_like_business_ok,
    _parse_errno,
    _is_retryable_errno,
    _to_str,
)

biz = get_biz_logger(__name__)

__all__ = ["Share115Client"]

class Share115Client:
    """Best-effort 115 share snapshot client.

    It uses the public webapi.115.com endpoints. Some shares may require cookie or
    may be rate-limited; callers should handle failures gracefully.
    """

    def __init__(self, *, cookie: str = "", timeout: float = 15.0) -> None:
        self.cookie = (cookie or "").strip()
        self.timeout = timeout
        self._client: Optional[httpx.AsyncClient] = None
        # Prefer the process-wide shared httpx.AsyncClient to avoid per-flow leaks.
        # Per-request timeout is still respected via httpx request parameters.
        try:
            s = get_settings()
            self._use_shared_http = bool(getattr(s, "SHARE115_USE_SHARED_HTTP_CLIENT", True))
        except (AttributeError, TypeError) as e:
            biz.detail("115 分享客户端配置读取失败，使用默认值", error=type(e).__name__)
            self._use_shared_http = True
        # In-process cache for share/snap responses (reduces latency for multi-pass scans).
        # Key: (share_code, receive_code, cid, offset, limit) -> payload
        self._snap_cache: TTLCache[Tuple[str, str, int, int, int], Dict[str, Any]] = TTLCache(
            maxsize=256,
            default_ttl=30,
        )

    async def _get_client(self) -> httpx.AsyncClient:
        if self._use_shared_http:
            return await get_http_client()
        if self._client is None:
            self._client = httpx.AsyncClient(follow_redirects=True, timeout=self.timeout)
        return self._client

    def _headers(self) -> Dict[str, str]:
        h = {
            "Accept": "application/json, text/plain, */*",
            "User-Agent": "Mozilla/5.0 (EmbyNotifier; Share115)",
        }
        if self.cookie:
            h["Cookie"] = self.cookie
        return h

    async def close(self) -> None:
        # Only close when we own the client.
        if (not self._use_shared_http) and self._client is not None:
            await self._client.aclose()
            self._client = None

    async def __aenter__(self) -> "Share115Client":
        return self

    async def __aexit__(self, exc_type, exc, tb) -> None:
        await self.close()

    async def _request_json(
        self,
        url: str,
        *,
        params: Dict[str, Any],
        log_step: str,
        max_attempts: int = 3,
        backoff: Tuple[float, float] = (0.0, 1.0),
    ) -> Dict[str, Any]:
        """GET url and return parsed JSON, with both HTTP retry and business errno retry."""
        last_exc: Optional[Exception] = None
        for attempt in range(max(1, int(max_attempts or 1))):
            try:
                await _get_share115_rate_limiter().wait()
                sem = _get_share115_semaphore()
                async with sem:
                    
                    resp = await async_request_with_retry(
                        await self._get_client(),
                        "GET",
                        url,
                        params=params,
                        headers=self._headers(),
                        timeout=self.timeout,
                        max_attempts=3,
                        backoff=backoff,
                        log_ctx=log_step,
                    )
                    try:
                        if resp.status_code != 200:
                            raise Share115Error(
                                f"{log_step} http {resp.status_code}",
                                url=url,
                                params=params,
                                http_status=resp.status_code,
                            )
                        try:
                            data = resp.json() or {}
                        except Exception as e:
                            raise Share115Error(
                                f"{log_step} non-json",
                                url=url,
                                params=params,
                                raw=str(resp.text or ""),
                            ) from e
                        if not isinstance(data, dict):
                            raise Share115Error(f"{log_step} non-dict-json", url=url, params=params, raw=data)
                    finally:
                        try:
                            await resp.aclose()
                        except (AttributeError, RuntimeError) as e:
                            biz.detail("115 分享响应关闭失败", error=type(e).__name__)


                if _looks_like_business_ok(data):
                    return data

                errno = _parse_errno(data.get("errno"))
                msg = (
                    _to_str(data.get("error"))
                    or _to_str(data.get("message"))
                    or _to_str(data.get("msg"))
                    or _to_str(data.get("error_msg"))
                    or ""
                ).strip()
                state = data.get("state")
                if _is_retryable_errno(errno, msg) and attempt < (max_attempts - 1):
                    delay = backoff[0] if attempt == 0 else backoff[1] * (2 ** (attempt - 1))
                    delay = max(0.0, float(delay))
                    biz.warning(
                        "115 分享可重试业务错误，等待后重试",
                        step=log_step,
                        errno=errno,
                        state=state,
                        attempt=attempt + 1,
                        max_attempts=max_attempts,
                        delay_sec=round(delay, 2),
                        msg=(msg[:120] + "…") if len(msg) > 120 else msg,
                    )
                    if delay:
                        await asyncio.sleep(delay)
                    continue

                raise Share115Error(
                    f"{log_step} business failed errno={errno} state={state}",
                    url=url,
                    params=params,
                    errno=errno,
                    state=state,
                    raw=data,
                )
            except Share115Error as e:
                last_exc = e
                raise
            except Exception as e:
                last_exc = e
                if attempt < (max_attempts - 1):
                    delay = backoff[0] if attempt == 0 else backoff[1] * (2 ** (attempt - 1))
                    delay = max(0.0, float(delay))
                    biz.warning(
                        "115 分享请求异常，等待后重试",
                        step=log_step,
                        error=type(e).__name__,
                        attempt=attempt + 1,
                        max_attempts=max_attempts,
                        delay_sec=round(delay, 2),
                    )
                    if delay:
                        await asyncio.sleep(delay)
                    continue
                raise

        if last_exc:
            raise last_exc
        raise ExternalServiceError("share115 request failed")

    async def snap(
        self,
        *,
        share_code: str,
        receive_code: str | None = None,
        cid: int = 0,
        offset: int = 0,
        limit: int = 200,
    ) -> Dict[str, Any]:
        # Short TTL cache: avoids repeating identical snap calls in a single flow.
        k = (str(share_code or ""), str(receive_code or ""), int(cid), int(offset), int(limit))
        cached = self._snap_cache.get(k)
        if isinstance(cached, dict) and cached:
            biz.detail("115 分享快照命中缓存", stage="115_cache", cid=cid, offset=offset, limit=limit)
            return dict(cached)

        params: Dict[str, Any] = {
            "share_code": share_code,
            "cid": int(cid),
            "offset": int(offset),
            "limit": int(limit),
            "_": str(int(time.time() * 1000)),
        }
        if receive_code:
            params["receive_code"] = receive_code
        log_fetch(biz, "step=share115_snap phase=start")
        data = await self._request_json(
            "https://webapi.115.com/share/snap",
            params=params,
            log_step="share115_snap",
            max_attempts=3,
            backoff=(0.0, 1.0),
        )
        log_ok(biz, "step=share115_snap phase=ok")
        try:
            self._snap_cache.set(k, dict(data))
        except (ValueError, TypeError, KeyError) as e:
            biz.detail("115 分享快照缓存写入失败", error=type(e).__name__)
        return data
