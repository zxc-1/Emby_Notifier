from __future__ import annotations

"""Video selection heuristics for 115 share listings."""

import re
from typing import List, Optional

from .share115_models import ShareFile

__all__ = [
    "is_video_filename",
    "pick_best_video_file",
    "count_video_files",
    "pick_best_video_name",
]

_VIDEO_EXTS = {
    ".mp4",
    ".mkv",
    ".avi",
    ".mov",
    ".wmv",
    ".flv",
    ".m4v",
    ".ts",
    ".m2ts",
    ".mts",
    ".webm",
    # legacy / disc / container formats (common in CN shares)
    ".rmvb",
    ".vob",
    ".mpg",
    ".mpeg",
    ".m2v",
    ".iso",
}

# Names that usually indicate non-main-feature videos (extras/trailers/samples).
# We still keep them as candidates if nothing else exists, but we try hard not to pick them as the representative file.
_BAD_VIDEO_NAME_RE = re.compile(
    r"(?:\b(extras?|extra|sample|trailer|teaser|featurette|behind(?:\s*the\s*scenes)?|making|interview|promo|preview)\b|"
    r"(?:花絮|预告|片花|特辑|制作|采访|番外|彩蛋|PV|CM|NCOP|NCED|SP|OVA))",
    re.IGNORECASE,
)



def _is_video_name(name: str) -> bool:
    ln = (name or "").lower()
    ext = "." + ln.split(".")[-1] if "." in ln else ""
    return ext in _VIDEO_EXTS



# Backward-compat alias: older code paths used `is_video_filename()`.
# A missing alias/call-site fix would make `video_samples` always empty,
# hurting TMDB disambiguation and auto-pick.
def is_video_filename(name: str) -> bool:
    return _is_video_name(name)


def pick_best_video_file(files: List[ShareFile]) -> Optional[ShareFile]:
    """Pick a representative video file from list (returns ShareFile).

    Notes:
      - Prefer real video files by extension.
      - Avoid picking trailers/extras/samples as the "best" when a real main-feature exists.
      - Fallback to the largest non-dir file when extension matching fails.
    """
    if not files:
        return None
    has_dirs = any(getattr(f, "is_dir", False) for f in files)
    vids = [f for f in files if (not f.is_dir) and _is_video_name(f.name)]

    # IMPORTANT: if a listing contains directories but no obvious video files,
    # returning a random non-video file (e.g. README/NFO) would stop the BFS scan
    # early and cause false negatives. In this case, return None so the caller
    # can继续向下扫描.
    if (not vids) and has_dirs:
        return None

    cand = vids or [f for f in files if not f.is_dir]
    if not cand:
        return None

    def _goodness(f: ShareFile) -> int:
        # 1 = looks like a main feature, 0 = likely extra/trailer/sample
        n = (f.name or "")
        return 0 if (_BAD_VIDEO_NAME_RE.search(n) is not None) else 1

    return max(cand, key=lambda x: (_goodness(x), x.size or 0, len(x.name or "")))




def count_video_files(files: List[ShareFile]) -> int:
    if not files:
        return 0
    return sum(1 for f in files if (not f.is_dir) and _is_video_name(f.name))



def pick_best_video_name(files: List[ShareFile]) -> Optional[str]:
    """Pick a representative filename from share list.

    Strategy:
      1) Prefer non-dir video files by extension
      2) Choose the largest one (common for single-movie share)
      3) Fallback to first non-dir file
    """
    if not files:
        return None

    vids = []
    for f in files:
        if f.is_dir:
            continue
        ln = f.name.lower()
        ext = "." + ln.split(".")[-1] if "." in ln else ""
        if ext in _VIDEO_EXTS:
            vids.append(f)

    cand = vids or [f for f in files if not f.is_dir]
    if not cand:
        return None

    best = max(cand, key=lambda x: (x.size or 0, len(x.name or "")))
    return best.name

