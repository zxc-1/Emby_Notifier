from __future__ import annotations

from dataclasses import dataclass

__all__ = ["ShareFile"]


@dataclass
class ShareFile:
    file_id: str
    name: str
    size: int = 0
    is_dir: bool = False
