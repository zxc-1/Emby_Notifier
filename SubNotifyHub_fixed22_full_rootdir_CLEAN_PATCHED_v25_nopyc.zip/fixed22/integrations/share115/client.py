"""Thin re-export for the Share115 HTTP client."""

from .share115_client import Share115Client

__all__ = ["Share115Client"]
