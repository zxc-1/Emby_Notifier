from __future__ import annotations

"""Error helpers for 115 share endpoints."""
import logging
from core.logging import get_biz_logger_adapter
logger = get_biz_logger_adapter(__name__)


from typing import Any, Dict, Optional

__all__ = [
    "Share115Error",
    "_to_str",
    "_parse_errno",
    "_looks_like_business_ok",
    "_is_retryable_errno",
]

class Share115Error(RuntimeError):
    def __init__(
        self,
        message: str,
        *,
        url: str = "",
        params: Optional[Dict[str, Any]] = None,
        http_status: Optional[int] = None,
        errno: Optional[int] = None,
        state: Any = None,
        raw: Any = None,
    ) -> None:
        super().__init__(message)
        self.url = url
        self.params = params or {}
        self.http_status = http_status
        self.errno = errno
        self.state = state
        self.raw = raw


class Share115RetryableError(Share115Error):
    pass


def _to_str(v: Any) -> str:
    try:
        return str(v)
    except (TypeError, ValueError) as e:
        logger.detail(f"转换字符串失败（已忽略） - 类型={type(v).__name__}, 原因={type(e).__name__}")
        return ""


def _parse_errno(v: Any) -> Optional[int]:
    if v is None:
        return None
    try:
        return int(v)
    except (TypeError, ValueError) as e:
        logger.detail(f"解析错误码失败（已忽略） - 值={v}, 原因={type(e).__name__}")
        return None


def _looks_like_business_ok(data: Dict[str, Any]) -> bool:
    # 115 often returns HTTP 200 but business fails via errno/state.
    errno = _parse_errno(data.get("errno"))
    if errno is not None and errno != 0:
        return False
    state = data.get("state")
    if state is None:
        return True
    if isinstance(state, bool):
        return bool(state)
    s = _to_str(state).strip().lower()
    if s in ("1", "true", "ok", "success"):
        return True
    if s in ("0", "false", "fail", "failed", "error"):
        return False
    # Unknown state value: do not treat as failure.
    return True


def _is_retryable_errno(errno: Optional[int], msg: str) -> bool:
    # Best-effort: errno codes are not stable across time; fall back to message hints.
    ml = (msg or "").lower()

    # Message-based retry signals (work even when errno is missing/unstable).
    # Typical examples: “服务器升级中 / 系统维护 / 请稍后再试 / 访问频繁 / 风控”.
    if any(
        k in ml
        for k in (
            "too fast",
            "rate",
            "频繁",
            "稍后",
            "later",
            "busy",
            "timeout",
            "upgrade",
            "upgrading",
            "maintenance",
            "维护",
            "升级",
            "server",
            "系统",
            "风控",
            "risk",
        )
    ):
        return True

    # errno-based retry signals (when present)
    if errno is None:
        return False
    if errno in {429, 990008, 990009, 990010, 990011, 990012, 990013}:
        return True
    return False



# ---------------------------------------------------------------------------
# Error classification helpers (share resolver UX)
# ---------------------------------------------------------------------------

def _extract_msg_from_raw(raw: Any) -> str:
    if isinstance(raw, dict):
        for k in ("error","message","msg","error_msg","info","tip"):
            v = raw.get(k)
            if v:
                try:
                    return str(v).strip()
                except (TypeError, AttributeError):
                    pass
    try:
        return str(raw).strip()
    except (TypeError, AttributeError):
        return ""

def classify_share115_error(err: "Share115Error") -> Dict[str, Any]:
    """Classify 115 business errors into stable reason_code for user-facing hints.

    Returns:
      { reason_code, temp_unavailable, errno, state, msg }
    """
    errno = getattr(err, "errno", None)
    state = getattr(err, "state", None)
    raw = getattr(err, "raw", None)
    msg = _extract_msg_from_raw(raw) or str(err)
    low = (msg or "").lower()

    # Heuristics (115 messages can be CN/EN/mixed)
    def has(*subs: str) -> bool:
        return any(s and (s in low) for s in subs)

    # Permission / login required
    if has("forbidden","permission","unauthorized","need login","login required","请登录","需要登录","无权限","权限不足","没有权限","访问受限"):
        return {"reason_code":"share115_permission","temp_unavailable":False,"errno":errno,"state":state,"msg":msg}

    # Wrong receive_code / extraction code
    if has("提取码","取码","密码错误","receive_code","code wrong","wrong code","验证码错误","访问码"):
        return {"reason_code":"share115_bad_code","temp_unavailable":False,"errno":errno,"state":state,"msg":msg}

    # Link expired / removed
    if has("失效","不存在","已取消","被取消","已删除","not exist","expired","removed","invalid share","share not found"):
        return {"reason_code":"share115_expired","temp_unavailable":False,"errno":errno,"state":state,"msg":msg}

    # Rate limiting / too frequent
    if has("频繁","too many","rate","limit","limited","busy","稍后","try again","操作过于频繁"):
        return {"reason_code":"share115_rate_limited","temp_unavailable":True,"errno":errno,"state":state,"msg":msg}

    # Generic temporary failures
    if has("timeout","timed out","connect","network","remoteprotocol","reset","temporarily","暂时","失败","server error","502","503","504"):
        return {"reason_code":"share115_temp_unavailable","temp_unavailable":True,"errno":errno,"state":state,"msg":msg}

    return {"reason_code":"share115_read_failed","temp_unavailable":False,"errno":errno,"state":state,"msg":msg}
