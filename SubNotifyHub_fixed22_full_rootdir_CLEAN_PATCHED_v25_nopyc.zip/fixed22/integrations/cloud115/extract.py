from __future__ import annotations

import base64
import logging
import re
import unicodedata
from typing import Any, List, Optional, Tuple
from urllib.parse import parse_qs, unquote, urlparse

from core.logging import get_biz_logger_adapter
from core.patterns import ED2K_RE, MAGNET_RE, SHARE_RE

logger = get_biz_logger_adapter(__name__)

# Any "safe" URL-ish prefix (avoid swallowing trailing Chinese/punctuation)
_URL_SAFE_PREFIX_RE = re.compile(r"^([A-Za-z0-9:/?#\[\]@!$&'()*+,;=%._~\-|]+)")

# Start markers (allow spaces/newlines around ":" and "//" or "?" for TG formatting)
_OFFLINE_START_RE = re.compile(
    r"(magnet\s*:\s*\?|ed2k\s*:\s*//|ftp\s*:\s*//|thunder\s*:\s*//|qqdl\s*:\s*//|flashget\s*:\s*//)",
    re.I,
)
_FTP_RE = re.compile(r"(ftp://[^\s]+)", re.I)

# Validate a magnet has a usable btih.
#
# BTIH is either 40-hex or 32-base32.
#
# NOTE:
#   Do NOT accept "{32,}" here. Telegram/Telegra previews sometimes glue
#   the file name right after the hash (missing "&dn=...") which would make
#   the captured group hundreds of characters long and later fail validation.
#   We still *recover* polluted hashes elsewhere (see _recover_btih_hash).
_MAGNET_BTIH_RE = re.compile(r"(?i)xt=urn:btih:([0-9a-f]{40}|[A-Za-z2-7]{32})")

# Capture "btih:" with possible spaces/newlines between tokens
_BTIH_LOOSE_RE = re.compile(r"btih\s*:\s*([0-9A-Za-z\+\s]{16,200})", re.I)

# Canonical ED2K: ed2k://|file|<name>|<size>|<hash>|/
_ED2K_CANON_RE = re.compile(r"(?is)^ed2k://\|file\|(.+?)\|(\d{1,20})\|([0-9a-f]{32})\|/.*$")

# Tolerate missing terminator (common in telegra/html line breaks or user edits).
# We only accept *file* links that contain (name,size,hash).
_ED2K_PARTIAL_RE = re.compile(r"(?is)^ed2k://\|file\|(.+?)\|(\d{1,20})\|([0-9a-f]{32})\|?(?:/.*)?$")


def _normalize_url(u: str) -> str:
    u = (u or "").strip()
    if not u:
        return ""
    try:
        # strip trailing punctuation
        u = u.strip('"\'<>[](){}.,;\n\r\t ')
    except (ValueError, TypeError, AttributeError):
        logger.detail("_normalize_url 中异常已抑制", exc_info=True)
    return u


def _short_hash(h: str, *, head: int = 8, tail: int = 8) -> str:
    h = (h or "").strip()
    if not h:
        return ""
    if len(h) <= head + tail + 2:
        return h
    return f"{h[:head]}…{h[-tail:]}"


def _canonical_ed2k(url: str) -> tuple[str, str]:
    """Return (canonical_url, dedup_key) for ed2k.

    - Canonical url is truncated at the first "|/" terminator.
    - Dedup key is based on (hash,size) when parseable.

    Returns ("", "") if url is not a valid ed2k file link.
    """
    u = (url or "").strip()
    if not u:
        return "", ""
    low = u.lower()
    if not low.startswith("ed2k://"):
        return "", ""

    # Remove whitespace that TG might inject.
    u2 = re.sub(r"\s+", "", u)

    # Truncate at the official terminator to avoid glued content.
    term = u2.lower().find("|/")
    if term >= 0:
        u2 = u2[: term + 2]

    m = _ED2K_CANON_RE.match(u2)
    if not m:
        # Some telegra/html line breaks or user edits may drop the trailing "|/".
        # Accept partial only if (name,size,hash) are all present.
        mp = _ED2K_PARTIAL_RE.match(u2)
        if not mp:
            # Only accept file links; ignore partial tokens like "ed2k://|file|The"
            return "", ""
        name = mp.group(1)
        size = mp.group(2)
        h = mp.group(3)
        # Construct canonical form.
        u2 = f"ed2k://|file|{name}|{size}|{h}|/"
        m = mp
    size = m.group(2)
    h = m.group(3)
    key = f"ed2k:{h.lower()}:{size}"
    return u2, key


def _pick_btih_hash(raw: str) -> str:
    """Pick a *strictly valid* BTIH hash from a raw string.

    Accepted:
      - 40-hex (most common)
      - 32-base32 (common)

    This is intentionally conservative: it does NOT accept generic alnum prefixes.
    """
    s = re.sub(r"[\s+]+", "", raw or "")  # also drop '+' which often appears in polluted copies
    if not s:
        return ""
    if re.fullmatch(r"[0-9a-fA-F]{40}", s):
        return s.lower()
    if re.fullmatch(r"[A-Za-z2-7]{32}", s):
        return s.upper()
    return ""


def _recover_btih_hash(raw: str) -> str:
    """Recover a valid BTIH hash from a *polluted* raw string.

    Telegram/Telegra previews or user edits may glue extra text right after
    the BTIH (e.g. missing "&dn="). In that case, we still want to salvage
    the first valid 40-hex / 32-base32 segment.

    Safety properties:
      - Only returns a hash when we can find an *exact* 40-hex or 32-base32
        token (no fuzzy matching).
      - Prefer a token at the beginning of the string; otherwise, take the
        first token after "btih:" marker.
    """
    s = re.sub(r"[\s+]+", "", raw or "")
    if not s:
        return ""

    # Fast path: token at start (most common for xt=urn:btih:<hash>...)
    m = re.match(r"(?i)^([0-9a-f]{40})", s)
    if m:
        return m.group(1).lower()
    m = re.match(r"(?i)^([A-Z2-7]{32})", s)
    if m:
        return m.group(1).upper()

    # Fallback: search within the string (e.g. "...btih:<hash>...")
    m = re.search(r"(?i)(?:btih:)?([0-9a-f]{40})", s)
    if m:
        return m.group(1).lower()
    m = re.search(r"(?i)(?:btih:)?([A-Z2-7]{32})", s)
    if m:
        return m.group(1).upper()
    return ""


def _decode_wrapped_link(u: str) -> str:
    """Decode thunder/qqdl/flashget wrapped links when possible."""
    u = (u or "").strip()
    low = u.lower()
    if not low.startswith(("thunder://", "qqdl://", "flashget://")):
        return ""
    try:
        b64 = u.split("://", 1)[1]
        # wrappers are sometimes URL-encoded; also flashget may append &... params
        b64 = unquote(b64)
        b64 = b64.split("&", 1)[0].strip()
        # urlsafe fix + padding
        b64 = b64.replace("-", "+").replace("_", "/")
        pad = (-len(b64)) % 4
        if pad:
            b64 += "=" * pad
        raw = base64.b64decode(b64, validate=False)
        s = raw.decode("utf-8", errors="ignore").strip()

        if low.startswith("thunder://"):
            if s.startswith("AA") and s.endswith("ZZ") and len(s) > 4:
                s = s[2:-2]
        elif low.startswith("flashget://"):
            if s.upper().startswith("[FLASHGET]") and s.upper().endswith("[FLASHGET]") and len(s) > 20:
                s = s[len("[FLASHGET]") : -len("[FLASHGET]")]
        s = s.strip()
        if s.lower().startswith(("http://", "https://", "ftp://", "magnet:?", "magnet:", "ed2k://")):
            return s
    except (ValueError, TypeError, UnicodeDecodeError, base64.binascii.Error):
        logger.detail("_decode_wrapped_link 失败", exc_info=True)
        return ""
    return ""


# --- Magnet robustness helpers (conservative) ---------------------------------

_ZERO_WIDTH_CHARS = "\u200b\u200c\u200d\ufeff"


def _clean_text_nfkc(t: str) -> str:
    """Normalize Telegram/clipboard text without guessing content."""
    t = t or ""
    try:
        t = unicodedata.normalize("NFKC", t)
    except (ValueError, TypeError):
        pass
    if _ZERO_WIDTH_CHARS:
        t = t.translate({ord(c): None for c in _ZERO_WIDTH_CHARS})
    return t


def _fix_magnet_prefixes_in_text(t: str) -> str:
    """Fix common magnet prefix typos introduced by chat/IME."""
    t = _clean_text_nfkc(t)
    # Normalize "magnet...xt=" into canonical "magnet:?xt="
    t = re.sub(r"(?i)magnet\s*\?\s*xt\s*=", "magnet:?xt=", t)
    t = re.sub(r"(?i)magnet\s*[:：]\s*[\.?。]?\s*2?\s*xt\s*=", "magnet:?xt=", t)
    t = re.sub(r"(?i)magnet\s*[\.。]\s*\?\s*xt\s*=", "magnet:?xt=", t)
    t = re.sub(r"(?i)magnet\s*[\.。]\s*2?\s*xt\s*=", "magnet:?xt=", t)
    return t


def _btih_reason_from_clean(clean: str) -> str:
    if not clean:
        return "BTIH 为空"
    if len(clean) not in (40, 32):
        return f"BTIH 长度异常({len(clean)})"
    for ch in clean:
        if len(clean) == 40:
            if ch not in "0123456789abcdefABCDEF":
                return f"BTIH 含非法字符({ch})"
        else:
            if ch not in "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567abcdefghijklmnopqrstuvwxyz":
                return f"BTIH 含非法字符({ch})"
    return "BTIH 格式非法"


def _extract_magnet_btih_with_reason(url: str) -> tuple[str, str]:
    """Extract BTIH from magnet link and provide a human reason on failure."""
    url = (url or "").strip()
    if not url:
        return "", "空链接"

    # Prefer parse_qs because it correctly decodes '+' to space (common pollution).
    try:
        p = urlparse(url)
        qs = parse_qs(p.query or "")
        xts = qs.get("xt") or qs.get("XT") or []
        for xt in xts:
            if isinstance(xt, str) and "urn:btih:" in xt.lower():
                raw = xt.split(":")[-1]
                h = _pick_btih_hash(raw)
                if h:
                    return h, ""
                # Try to recover a polluted BTIH (e.g. hash glued with filename).
                rh = _recover_btih_hash(raw)
                if rh:
                    logger.detail("recovered polluted btih via parse_qs：操作异常：%s", _short_hash(rh, head=8, tail=6))
                    return rh, ""
                clean = re.sub(r"[\s+]+", "", raw or "")
                return "", _btih_reason_from_clean(clean)
    except (ValueError, TypeError, KeyError):
        logger.detail("_extract_magnet_btih_with_reason 中异常已抑制", exc_info=True)

    # Regex fallback (handles non-standard magnet strings)
    m = re.search(r"(?i)xt=urn:btih:([^&\s]+)", url)
    if m:
        raw = m.group(1)
        h = _pick_btih_hash(raw)
        if h:
            return h, ""
        rh = _recover_btih_hash(raw)
        if rh:
            logger.detail("recovered polluted btih via regex xt：操作异常：%s", _short_hash(rh, head=8, tail=6))
            return rh, ""
        clean = re.sub(r"[\s+]+", "", raw or "")
        return "", _btih_reason_from_clean(clean)

    ml = re.search(r"(?i)btih\s*:\s*([0-9A-Za-z\+\s]{16,200})", url)
    if ml:
        raw = ml.group(1)
        h = _pick_btih_hash(raw)
        if h:
            return h, ""
        rh = _recover_btih_hash(raw)
        if rh:
            logger.detail("recovered polluted btih via loose btih：操作异常：%s", _short_hash(rh, head=8, tail=6))
            return rh, ""
        clean = re.sub(r"[\s+]+", "", raw or "")
        return "", _btih_reason_from_clean(clean)

    return "", "未找到 BTIH"


def _extract_magnet_btih(url: str) -> str:
    h, _reason = _extract_magnet_btih_with_reason(url)
    return h or ""


def _magnet_min_url(url: str) -> str:
    btih = _extract_magnet_btih(url)
    if btih:
        return f"magnet:?xt=urn:btih:{btih}"
    return (url or "").strip()


def _extract_task_hint_from_resp(resp: Any) -> str:
    """Try to extract a task id / queue hint from 115 response."""

    def _walk(obj: Any):
        yield obj
        if isinstance(obj, dict):
            for v in obj.values():
                yield from _walk(v)
        elif isinstance(obj, list):
            for it in obj:
                yield from _walk(it)

    try:
        for node in _walk(resp):
            if isinstance(node, dict):
                for k in ("task_id", "taskid", "taskId", "taskID"):
                    v = node.get(k)
                    if isinstance(v, (int, float)) and int(v) > 0:
                        return f"id={int(v)}"
                    if isinstance(v, str) and v.strip().isdigit():
                        return f"id={int(v.strip())}"
    except (ValueError, TypeError, KeyError, AttributeError):
        logger.detail("_extract_task_hint_from_resp 中异常已抑制", exc_info=True)
    return "已进入队列"


def _offline_title_and_brief(u: str) -> Tuple[str, str]:
    """Best-effort: return (title, brief) for displaying offline submissions."""
    u = (u or "").strip()
    low = u.lower()
    title = ""
    brief = ""

    if low.startswith("magnet:"):
        h = _extract_magnet_btih(u)
        if h:
            brief = f"btih:{h[:8]}…{h[-6:]}" if len(h) > 14 else f"btih:{h}"
        # dn param as title
        try:
            qs = parse_qs(u.split("?", 1)[1]) if "?" in u else {}
            dn = (qs.get("dn") or [""])[0]
            dn = unquote(dn) if dn else ""
            title = dn.strip()
        except (ValueError, TypeError, KeyError, IndexError):
            title = ""
        if not title:
            title = "magnet"
        if not brief:
            brief = "magnet"
        return title, brief

    if low.startswith("ed2k://"):
        u2 = re.sub(r"\s+", "", u)
        term = u2.lower().find("|/")
        if term >= 0:
            u2 = u2[: term + 2]
        m = _ED2K_CANON_RE.match(u2)
        if m:
            name = unquote(m.group(1)).strip()
            size = m.group(2).strip()
            h = m.group(3).lower().strip()
            title = name or "ed2k"
            hshort = _short_hash(h) if h else "—"
            brief = f"ed2k:{hshort} size:{size}" if size else f"ed2k:{hshort}"
            return title, brief
        brief = (u2[:70] + "…") if len(u2) > 70 else u2
        return "ed2k", brief

    if low.startswith(("http://", "https://", "ftp://")):
        try:
            p = urlparse(u)
            host = p.netloc
            path = p.path or "/"
            title = unquote(path.rsplit("/", 1)[-1] or host or "link")
            brief = f"{host}{path}"
            if len(brief) > 70:
                brief = brief[:68] + "…"
            return title or "link", brief
        except (ValueError, TypeError, KeyError):
            logger.detail("_offline_title_and_brief 失败 for http(s)/ftp URL", exc_info=True)
            return "link", ((u[:70] + "…") if len(u) > 70 else u)

    return "link", ((u[:70] + "…") if len(u) > 70 else u)


def _offline_key(url: str) -> str:
    """Key for offline submission dedup."""
    url = (url or "").strip()
    if not url:
        return ""
    low = url.lower()
    if low.startswith("ed2k://"):
        can, key = _canonical_ed2k(url)
        return key or can or url
    if low.startswith("magnet:"):
        mh = _MAGNET_BTIH_RE.search(url)
        if mh:
            h = _pick_btih_hash(mh.group(1))
            if h:
                return f"magnet:{h.lower()}"
        ml = _BTIH_LOOSE_RE.search(url)
        if ml:
            h = _pick_btih_hash(ml.group(1)) or _recover_btih_hash(ml.group(1))
            if h:
                return f"magnet:{h.lower()}"
    return url


def _extract_cloud115_offline_urls(text: str, *, limit: Optional[int] = None) -> List[str]:
    """Extract offline URLs for 115 (magnet/ed2k/ftp/thunder/qqdl/flashget).

    NOTE: bare http(s) is NOT treated as offline.
    Plain web links should go to the H (http_other) review flow, where users can
    preview and explicitly choose which ones to submit as offline.
    """

    # Best-effort text cleanup for common TG/clipboard/HTML artifacts.
    text = _fix_magnet_prefixes_in_text((text or ""))
    try:
        import html as _html
        # Convert common line-break tags first, then drop the remaining tags.
        text = re.sub(r"(?i)<\s*br\s*/?\s*>", "\n", text)
        text = re.sub(r"(?i)</\s*p\s*>", "\n", text)
        text = re.sub(r"(?i)<\s*wbr\s*/?\s*>", "", text)
        text = re.sub(r"(?is)<[^>]{1,200}>", " ", text)
        text = _html.unescape(text)
    except (ImportError, ValueError, TypeError):
        pass
    text = text.strip()
    if not text:
        return []

    lim: int = int(limit) if (limit is not None and int(limit) > 0) else 0  # 0 => unlimited

    urls: List[str] = []
    seen: set[str] = set()

    def _push(u: str) -> None:
        u2 = _normalize_url(u)
        if not u2:
            return
        if str(u2).lower().startswith("ed2k://"):
            can, _k = _canonical_ed2k(u2)
            if not can:
                return
            u2 = can
        # Exclude 115 share links: they are handled by the share-flow, not offline.
        # NOTE: SHARE_RE is only a locator; validate via parse_share_url for correctness.
        try:
            from integrations.share115 import parse_share_url as _psu

            sc, _rc = _psu(u2)
            if sc:
                return
        except ImportError:
            # Fallback: keep the previous behavior (best-effort) if parser is unavailable.
            try:
                if SHARE_RE.search(u2):
                    return
            except (ValueError, TypeError):
                pass
        k = _offline_key(u2)
        if k and k not in seen:
            seen.add(k)
            urls.append(u2)

    def _reached_limit() -> bool:
        return bool(lim) and len(urls) >= lim

    # (1) Slice by any start marker
    starts = [m.start() for m in _OFFLINE_START_RE.finditer(text)]
    if starts:
        starts.append(len(text))
        for i in range(len(starts) - 1):
            seg = text[starts[i] : starts[i + 1]]
            if not seg:
                continue

            seg2 = re.sub(r"\s+", "", seg)  # remove all whitespace
            ms = _URL_SAFE_PREFIX_RE.match(seg2)
            seg3 = ms.group(1) if ms else seg2
            if not seg3:
                continue

            # Extra safety: if slicing missed boundaries and multiple offline links glued, cut at 2nd marker
            try:
                _starts2 = [m.start() for m in _OFFLINE_START_RE.finditer(seg3)]
                if len(_starts2) > 1 and _starts2[0] == 0:
                    seg3 = seg3[: _starts2[1]]
            except (ValueError, TypeError, re.error):
                pass

            low = seg3.lower()

            # thunder/qqdl/flashget wrapper decode
            decoded_wrapped = False
            if low.startswith(("thunder://", "qqdl://", "flashget://")):
                dec = _decode_wrapped_link(seg3)
                if dec:
                    seg3 = dec
                    low = seg3.lower()
                    decoded_wrapped = True

            if low.startswith("magnet:"):
                bt_positions = [mm.start() for mm in re.finditer(r"btih:", seg3, flags=re.I)]
                if len(bt_positions) > 1:
                    seg3 = seg3[: bt_positions[1]]

                if _MAGNET_BTIH_RE.search(seg3):
                    _push(seg3)
                else:
                    mhash = _BTIH_LOOSE_RE.search(seg3)
                    raw = (mhash.group(1) if mhash else "")
                    h = _pick_btih_hash(raw) or _recover_btih_hash(raw)
                    if h:
                        _push(f"magnet:?xt=urn:btih:{h}")
            elif low.startswith("ed2k://"):
                _push(seg3)
            elif low.startswith("ftp://"):
                _push(seg3)
            elif decoded_wrapped and low.startswith(("http://", "https://")):
                # Only accept http(s) when it was explicitly wrapped (thunder/qqdl/flashget).
                # Bare http(s) in random text is intentionally ignored (review flow).
                _push(seg3)

            if _reached_limit():
                break

    # (1b) Extra ED2K recovery: telegra/clipboard sometimes breaks the link with
    # HTML tags or soft line breaks that defeat the start-marker slicing.
    # We scan nearby windows and try to reconstruct a canonical file link.
    if not _reached_limit() and "ed2k" in text.lower():
        try:
            for m in re.finditer(r"(?i)ed2k\s*:\s*//", text):
                if _reached_limit():
                    break
                win = text[m.start() : m.start() + 2048]
                # Drop all whitespace and then keep a safe URL-ish prefix.
                win2 = re.sub(r"\s+", "", win)
                ms = _URL_SAFE_PREFIX_RE.match(win2)
                cand = ms.group(1) if ms else win2
                if cand:
                    _push(cand)
        except (ValueError, TypeError, re.error):
            logger.detail("ed2k 恢复中异常已抑制", exc_info=True)

    # (2) Regex fallback (old behavior)
    if not _reached_limit():
        for m in MAGNET_RE.finditer(text):
            _push(m.group(1))
            if _reached_limit():
                break

    if not _reached_limit():
        for m in ED2K_RE.finditer(text):
            _push(m.group(1))
            if _reached_limit():
                break

    if not _reached_limit():
        for m in _FTP_RE.finditer(text):
            _push(m.group(1))
            if _reached_limit():
                break

    # (3) Global BTIH fallback
    if not _reached_limit() or not lim:
        for m in _BTIH_LOOSE_RE.finditer(text):
            raw = m.group(1)
            h = _pick_btih_hash(raw) or _recover_btih_hash(raw)
            if h:
                _push(f"magnet:?xt=urn:btih:{h}")
                if _reached_limit():
                    break

    return urls[:lim] if lim else urls


def extract_cloud115_offline_urls(text: str, *, limit: Optional[int] = None) -> List[str]:
    """Public, stable API for extracting 115 offline URLs.

    We keep the internal implementation name (leading underscore) for
    backward compatibility, but other modules should import this public
    wrapper to avoid private-symbol coupling.
    """

    return _extract_cloud115_offline_urls(text, limit=limit)
