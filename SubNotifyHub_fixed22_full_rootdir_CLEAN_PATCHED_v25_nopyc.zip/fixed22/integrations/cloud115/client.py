#!/usr/bin/env python3
# encoding: utf-8
from __future__ import annotations

from core.exceptions.base import ConfigurationError, ExternalServiceError, ValidationError


import asyncio
import hashlib
import time
import os
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple, Union

from core.logging import get_biz_logger_adapter
from core.env_utils import env_float, env_int
from core.exceptions import safe_context
from settings.urls import URLCategory, get_url

logger = get_biz_logger_adapter(__name__)
log = logger  # 兼容旧代码中使用 log 的地方

# -----------------------------------------------------------------------------
# 115 离线/目录逻辑（SDK 版）
#
# 说明：
# - 旧实现通过 web/lixian + sign/time 来提交离线任务（add_task_url）。
#   近期该流程在部分网络/UA/风控条件下更容易失败，导致 UI 端“测试 Cookie”误判。
# - 现在改为使用 p115client（作为 SDK）封装：
#   - 下拉目录：webapi.115.com/offine/downpath
#   - 磁力离线：lixian.115.com/lixianssp/?ac=add_task_url
#   - 任务列表：lixian.115.com/lixian/?ac=task_lists
# -----------------------------------------------------------------------------

try:
    # p115client 需要 Python >= 3.12
    from p115client import P115Client, check_response  # type: ignore
except Exception as e:  # pragma: no cover
    P115Client = None  # type: ignore
    check_response = None  # type: ignore
    _IMPORT_ERROR = e
else:
    _IMPORT_ERROR = None


@dataclass
class Cloud115Item:
    name: str
    file_id: int
    is_selected: bool = False


# 目录缓存：避免 UI 端频繁点击“测试/刷新”时触发多次请求
_DOWNPATH_CACHE: Dict[str, Tuple[float, List[Dict[str, Any]]]] = {}
# Directory listing cache (folders only). Keeps the dir-browser responsive and reduces
# repeated fs_list calls when users quickly navigate back/forth.
_FSLIST_CACHE: Dict[tuple, Tuple[float, Dict[str, Any]]] = {}
_FSLIST_CACHE_TTL_SEC = env_float("CLOUD115_FSLIST_CACHE_TTL_SEC", 15.0, min_value=0.0, max_value=3600.0)
_FSLIST_RETRY = env_int("CLOUD115_FSLIST_RETRY", 2, min_value=0, max_value=10)  # retries (in addition to first attempt)
_FSLIST_CACHE_MAX = env_int("CLOUD115_FSLIST_CACHE_MAX", 512, min_value=64, max_value=4096)
_DOWNPATH_CACHE_TTL_SEC = 30.0

# 115 风控/限流：机房 IP + 高频目录遍历很容易触发 403/405（返回 HTML 而非 JSON）
# 参考社区实践：遇到 405 视为“需要重新登录/风控”，应当降速 + 退避重试 + 适当熔断。
# 默认把所有 115 WebAPI 调用节流到 ~1.4 rps（可用环境变量调整）。
_CLOUD115_MIN_INTERVAL_MS = env_int("CLOUD115_MIN_INTERVAL_MS", 700, min_value=0, max_value=10000)
_CLOUD115_MAX_RETRY = env_int("CLOUD115_MAX_RETRY", 3, min_value=0, max_value=10)
_CLOUD115_BACKOFF_BASE_MS = env_int("CLOUD115_BACKOFF_BASE_MS", 600, min_value=0, max_value=60000)

_CLOUD115_RATELIMIT_LOCK: asyncio.Lock = asyncio.Lock()
_CLOUD115_LAST_REQ_TS: float = 0.0


async def _cloud115_rate_limit() -> None:
    """Global rate limiter for 115 WebAPI calls.

    Uses a process-wide lock so concurrent tasks won't spike QPS and trigger 115 风控.
    """
    global _CLOUD115_LAST_REQ_TS
    interval = max(int(_CLOUD115_MIN_INTERVAL_MS or 0), 0) / 1000.0
    if interval <= 0:
        return
    async with _CLOUD115_RATELIMIT_LOCK:
        now = time.time()
        wait = (_CLOUD115_LAST_REQ_TS + interval) - now
        if wait > 0:
            await asyncio.sleep(wait)
        _CLOUD115_LAST_REQ_TS = time.time()


def _looks_like_html(text: str | None) -> bool:
    if not text:
        return False
    t = text.strip().lower()
    return t.startswith("<!doctype") or t.startswith("<html") or ("text/html" in t)


def _raise_115_risk_control(status: int, detail: str = "") -> None:
    # User-friendly message surfaced in UI
    msg = "115 接口触发风控/需要验证（通常是 Cookie 失效、需要人机验证，或请求过于频繁）。"
    if status:
        msg += f" HTTP {status}。"
    if detail:
        msg += f" {detail}"
    msg += " 建议：更新 115 Cookie/CK，降低扫描频率（CLOUD115_MIN_INTERVAL_MS），或更换网络/IP（机房 IP 很容易被限）。"
    raise ExternalServiceError(msg)



def _prune_fslist_cache(now: float | None = None) -> None:
    """Best-effort prune for _FSLIST_CACHE to avoid unbounded growth."""
    global _FSLIST_CACHE
    
    # Parse now timestamp
    try:
        now_ts = float(now if now is not None else time.time())
    except (ValueError, TypeError):
        now_ts = time.time()

    # Drop expired entries
    try:
        ttl = float(_FSLIST_CACHE_TTL_SEC or 0)
    except (ValueError, TypeError):
        ttl = 0.0
    
    if ttl > 0:
        for k, (ts, _v) in list(_FSLIST_CACHE.items()):
            try:
                if (now_ts - float(ts or 0.0)) >= ttl:
                    _FSLIST_CACHE.pop(k, None)
            except (ValueError, TypeError, KeyError):
                continue

    # Enforce max size by dropping oldest entries
    try:
        maxn = int(_FSLIST_CACHE_MAX or 0)
    except (ValueError, TypeError):
        maxn = 0
    
    if maxn > 0 and len(_FSLIST_CACHE) > maxn:
        items = sorted(_FSLIST_CACHE.items(), key=lambda kv: float(kv[1][0] or 0.0))
        drop = max(1, len(items) - maxn)
        for k, _v in items[:drop]:
            _FSLIST_CACHE.pop(k, None)




def _is_retryable_fs_list_error(exc: Exception) -> bool:
    """Whether fs_list should be retried for this exception."""
    if exc is None:
        return False

    # Common transient classes
    if isinstance(exc, (TimeoutError, asyncio.TimeoutError, ConnectionError, OSError)):
        return True

    # Inspect chained causes
    cause = getattr(exc, "__cause__", None) or getattr(exc, "__context__", None)
    if isinstance(cause, Exception) and cause is not exc:
        if _is_retryable_fs_list_error(cause):
            return True

    name = exc.__class__.__name__.lower()
    if "timeout" in name or "temporar" in name or "connect" in name or "network" in name:
        return True

    # Some SDKs expose status code separately (e.g. HTTPError/ResponseError)
    status = getattr(exc, "status", None) or getattr(exc, "status_code", None)
    try:
        if status is not None and int(status) in (405, 412, 429, 500, 502, 503, 504):
            return True
    except Exception as e:
        biz.detail(f"fs_list status_code 解析失败（已忽略） - 原因={type(e).__name__}")

    msg = str(exc).lower()
    # 115 / upstream occasionally triggers WAF / 风控，常见为 405 / 412 / 429 或包含 risk-control 文案
    # 115 常见短暂故障文案："服务器开小差"、"稍后再试"
    if any(x in msg for x in (
        " 405",
        "405 ",
        "method not allowed",
        "waf",
        "risk",
        "风控",
        "412",
        "429",
        "too many",
        "rate limit",
        "server busy",
        "try again",
        "开小差",
        "稍后再试",
    )):
        return True
    keywords = (
        "timeout",
        "timed out",
        "connection reset",
        "reset by peer",
        "broken pipe",
        "server disconnected",
        "remote protocol",
        "eof",
        "connection aborted",
        "connect",
        "handshake",
        "tls",
        "ssl",
        "dns",
        "name or service not known",
        "temporary failure",
        "temporarily unavailable",
        "try again",
    )
    return any(k in msg for k in keywords)

def _cookie_to_str(cookie: Union[str, Dict[str, str], List[Tuple[str, str]], None]) -> str:
    if cookie is None:
        return ""
    if isinstance(cookie, str):
        return cookie.strip()
    if isinstance(cookie, dict):
        return "; ".join([f"{k}={v}" for k, v in cookie.items() if k and v is not None])
    # list[tuple]
    return "; ".join([f"{k}={v}" for k, v in cookie if k and v is not None])


def _cookie_cache_key(cookie_str: str) -> str:
    s = str(cookie_str or '').strip()
    if not s:
        return 'empty'
    try:
        return hashlib.sha256(s.encode('utf-8')).hexdigest()[:16]
    except (ValueError, TypeError, UnicodeEncodeError):
        return str(abs(hash(s)))


class Cloud115Client:
    """115 客户端（SDK 版）

    目前对外保留旧接口名，方便 tg_bot/service.py 与 admin/routes.py 直接复用。
    """

    def __init__(self, cookie: Union[str, Dict[str, str]], timeout: float = 30.0):
        if P115Client is None:  # pragma: no cover
            raise ConfigurationError(f"p115client 未安装或导入失败：{_IMPORT_ERROR!r}")

        self.cookie_str = _cookie_to_str(cookie)
        self.timeout = float(timeout)

        # p115client 内部自带请求实现（httpcore），支持 async_ 参数
        # check_for_relogin=False：不在服务端/容器里做交互式登录（由 UI 的扫码登录负责刷新 cookie）
        self._sdk = P115Client(self.cookie_str, check_for_relogin=False)

        # 115 Web API 的分页字段在不同版本/端可能有差异；仅在首次 files 列表请求时打印一次样本便于排障。
        self._logged_files_paging = False

    async def _await_with_timeout(self, coro, *, action: str):
        try:
            return await asyncio.wait_for(coro, timeout=float(self.timeout or 0) if float(self.timeout or 0) > 0 else None)
        except asyncio.TimeoutError as e:
            raise TimeoutError(f"cloud115 {action} timeout after {self.timeout}s") from e

    async def close(self) -> None:
        # p115client 不需要显式 close（内部请求按次创建/复用），这里保留方法以兼容旧调用
        return None

    # ----------------------------- DownPath -----------------------------

    async def get_downpath(self, force_refresh: bool = False) -> List[Dict[str, Any]]:
        """获取离线下载目录列表（115 的“下载路径”下拉）"""
        global _DOWNPATH_CACHE

        now = time.time()
        key = _cookie_cache_key(self.cookie_str)

        ts, cached = _DOWNPATH_CACHE.get(key, (0.0, []))
        if (not force_refresh) and cached and (now - ts) < _DOWNPATH_CACHE_TTL_SEC:
            return cached

        # webapi: POST https://webapi.115.com/offine/downpath  (注意 offine 拼写)
        # p115client: offline_download_path
        resp = await self._await_with_timeout(self._sdk.offline_download_path(0, async_=True), action='downpath')
        resp = check_response(resp)  # type: ignore

        data = resp.get("data")
        # 兼容：有些返回是 {data: [...]}，有些可能嵌套 {data:{data:[...]}}
        items: List[Dict[str, Any]] = []
        if isinstance(data, list):
            items = data
        elif isinstance(data, dict) and isinstance(data.get("data"), list):
            items = data.get("data")  # type: ignore

        _DOWNPATH_CACHE[key] = (now, items)

        # Best-effort prune to avoid unbounded growth when multiple cookies are used.
        if len(_DOWNPATH_CACHE) > 32:
            try:
                # drop oldest half
                oldest = sorted(_DOWNPATH_CACHE.items(), key=lambda kv: float(kv[1][0] or 0.0))
                for k, _v in oldest[: max(1, len(oldest)//2)]:
                    _DOWNPATH_CACHE.pop(k, None)
            except (ValueError, TypeError, KeyError):
                pass

        return items


    async def list_downpath(self, selected_file_id: int = 0, force_refresh: bool = False) -> List[Cloud115Item]:
        items = await self.get_downpath(force_refresh=force_refresh)
        out: List[Cloud115Item] = []
        sel_id = int(selected_file_id or 0)
        for it in items or []:
            try:
                fid = int(it.get("file_id") or it.get("id") or 0)
            except (ValueError, TypeError):
                fid = 0
            name = str(it.get("name") or it.get("file_name") or "")
            is_sel = (fid == sel_id) if sel_id else bool(it.get("is_selected") or it.get("selected"))
            out.append(Cloud115Item(name=name, file_id=fid, is_selected=is_sel))
        return out

    # ----------------------------- Magnet Offline -----------------------------

    async def add_offline_url(self, url: str, wp_path_id: Optional[int] = None) -> Dict[str, Any]:
        """提交 115 离线任务（SDK 版）。

        115 的 SDK 接口 `offline_add_url` 支持多种 URL 类型，例如：
          - magnet:?xt=urn:btih:...
          - ed2k://...
          - http(s)://...
          - ftp://...

        - url: 任意支持类型的下载链接
        - wp_path_id: 目标目录 id（为空则走 115 默认目录）
        """
        url = (url or "").strip()
        if not url:
            raise ValidationError("url 不能为空")

        payload: Dict[str, Any] = {"url": url}
        if wp_path_id:
            payload["wp_path_id"] = int(wp_path_id)

        # lixianssp: POST https://lixian.115.com/lixianssp/?ac=add_task_url
        resp = await self._await_with_timeout(self._sdk.offline_add_url(payload, async_=True), action="add_url")
        resp = check_response(resp)  # type: ignore
        return resp

    # -----------------------------------------------------------------
    # Backward-compatible aliases (older tg_bot implementations)
    # -----------------------------------------------------------------

    async def offline_add_task(self, url: str, wp_path_id: Optional[int] = None) -> Dict[str, Any]:
        """Alias for add_offline_url (kept for compatibility)."""
        return await self.add_offline_url(url, wp_path_id=wp_path_id)

    async def add_magnet_task(self, magnet: str, wp_path_id: Optional[int] = None) -> Dict[str, Any]:
        """提交磁力离线任务（SDK 版）

        - magnet: magnet:?xt=urn:btih:...
        - wp_path_id: 目标目录 id（为空则走 115 默认目录）
        """
        magnet = (magnet or "").strip()
        if not magnet.startswith("magnet:"):
            raise ValidationError("magnet 链接不合法")
        return await self.add_offline_url(magnet, wp_path_id=wp_path_id)

    async def fetch_task_list(self, page: int = 1) -> Dict[str, Any]:
        """获取离线任务列表（用于提交后轮询确认）。

        仍然返回 115 原始结构（一般包含 tasks 列表），调用方自己解析。
        """
        page = int(page or 1)
        resp = await self._await_with_timeout(self._sdk.offline_list(page, async_=True), action="task_list")
        resp = check_response(resp)  # type: ignore
        return resp

    # ----------------------------- FS Browse -----------------------------

    async def fs_list_folders(self, cid: int = 0, *, offset: int = 0, limit: int = 50) -> Dict[str, Any]:
        """列出某个目录下的子项目（只用于目录浏览）。

        使用 115 Web API：GET https://webapi.115.com/files?aid=1&cid=...&show_dir=1&format=json

        说明：
        - 返回结构里通常包含：data(list), count(int), offset/page_size 等
        - data 项里：文件通常带 fid；目录通常带 cid 且 fid 为空
        """
        global _FSLIST_CACHE

        cid = int(cid or 0)
        offset = int(offset or 0)
        limit = int(limit or 50)

        # Short TTL cache to reduce repeated fs_list calls during fast UI navigation.
        now = time.time()
        cache_key = (_cookie_cache_key(self.cookie_str), cid, offset, limit)
        ts, cached = _FSLIST_CACHE.get(cache_key, (0.0, None))
        if cached and (now - ts) < float(_FSLIST_CACHE_TTL_SEC or 0):
            return cached  # type: ignore

        params: Dict[str, Any] = {
            "aid": 1,
            "cid": cid,
            "show_dir": 1,
            "format": "json",
            "offset": offset,
            "limit": limit,
            "o": "file_name",
            "asc": 1,
            "natsort": 1,
        }

        async def _do_request() -> Dict[str, Any]:
            """115 的 /files 接口在部分节点/时期会对 GET 返回 405。

            目录树浏览是 UI 高频调用，不能依赖 SDK 的默认方法（通常是 GET）。
            这里改为：优先 POST(form)；若仍 405 再回退 GET。

            该接口仅依赖 Cookie，无需额外签名。
            """
            try:
                from core.http import get_http_client

                http = await get_http_client()
                headers = {
                    # 115 对 UA/Referer/Origin/XRW 在不同节点可能有隐性要求；
                    # 尽量模拟浏览器请求，避免出现“200 但 data 为空”的诡异情况。
                    "User-Agent": (
                        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                        "AppleWebKit/537.36 (KHTML, like Gecko) "
                        "Chrome/121.0.0.0 Safari/537.36"
                    ),
                    "Accept": "application/json, text/plain, */*",
                    "X-Requested-With": "XMLHttpRequest",
                    "Origin": "https://115.com",
                    "Referer": "https://115.com/",
                    "Cookie": str(self.cookie_str or ""),
                }

                # 1) Prefer POST (form)
                r = await http.post("https://webapi.115.com/files", data=params, headers=headers, timeout=30.0)
                if int(r.status_code) == 405:
                    # 2) Fallback GET
                    r = await http.get("https://webapi.115.com/files", params=params, headers=headers, timeout=30.0)

                if int(r.status_code) in (403, 405):
                    # 115 风控/登录失效/人机验证：常返回 403/405 或 HTML
                    txt = (getattr(r, "text", "") or "")[:800]
                    raise RuntimeError(f"115 风控/验证: HTTP {r.status_code} {txt}")
                if int(r.status_code) >= 400:
                    # Keep a short, user-friendly error; caller will wrap.
                    raise RuntimeError(f"115 文件列表请求失败: HTTP {r.status_code}")

                try:
                    resp = r.json()
                except Exception:
                    txt = (getattr(r, "text", "") or "")[:1200]
                    # json 解析失败时，十有八九是 115 返回了 HTML 风控页
                    if _looks_like_html(txt) or "text/html" in txt.lower() or "method not allowed" in txt.lower():
                        raise RuntimeError(f"115 风控/验证: HTTP {r.status_code} {txt}")
                    txt = (r.text or "")
                    raise RuntimeError(f"115 文件列表返回非 JSON（可能 Cookie 失效或被风控）: {txt[:200]}")

                # If p115client.check_response is available, use it to normalize.
                try:
                    return check_response(resp)  # type: ignore
                except Exception:
                    return resp  # type: ignore

            except Exception as e:
                # Bubble up to retry loop.
                raise e

        # Retry a couple of times on timeout/network flakiness (GET is idempotent).
        backoffs = (0.3, 0.8, 1.6)
        last_exc: Exception | None = None
        for attempt in range(int(_FSLIST_RETRY or 0) + 1):
            await _cloud115_rate_limit()
            try:
                resp = await _do_request()

                # Some 115 nodes return HTTP 200 but the body is an error shape, e.g.
                #   {"errno":0, "error":"服务器开小差了，稍后再试吧", "state":0, "data": null}
                # Treat this as a transient failure so our retry/backoff + cache fallback can kick in.
                try:
                    if isinstance(resp, dict):
                        errtxt = resp.get("error")
                        state = resp.get("state")
                        data0 = resp.get("data")
                        is_state_bad = state in (0, False, "0", "false", "False")
                        is_transient_msg = isinstance(errtxt, str) and any(k in errtxt for k in ("开小差", "稍后再试", "繁忙"))
                        if is_state_bad or (is_transient_msg and data0 is None):
                            raise RuntimeError(f"115 API 返回错误: errno={resp.get('errno')} error={errtxt or state}")
                except RuntimeError:
                    raise
                except Exception:
                    # If detection fails, do not block normal flow.
                    pass

                # One-time debug sample for paging fields (helps future troubleshooting).
                if not self._logged_files_paging:
                    try:
                        self._logged_files_paging = True
                        paging: Dict[str, Any] = {}
                        for k in (
                            "offset",
                            "limit",
                            "page",
                            "page_size",
                            "pageSize",
                            "pagesize",
                            "count",
                            "total",
                            "sys_count",
                            "data_count",
                        ):
                            if resp.get(k) is not None:
                                paging[k] = resp.get(k)
                        data0 = resp.get("data")
                        if isinstance(data0, dict):
                            for k in ("offset", "limit", "page", "page_size", "pageSize", "pagesize", "count", "total"):
                                if data0.get(k) is not None:
                                    paging["data." + k] = data0.get(k)
                        logger.detail(
                            "115 文件列表分页样本 - cid=%s offset=%s limit=%s resp=%s",
                            cid,
                            offset,
                            limit,
                            paging,
                        )
                    except (ValueError, TypeError, KeyError):
                        logger.detail("115 文件列表分页样本记录失败", exc_info=True)

                # Only cache "good" responses; error-shaped responses are handled above.
                _FSLIST_CACHE[cache_key] = (time.time(), resp)
                _prune_fslist_cache(now=time.time())
                return resp
            except TimeoutError as e:
                last_exc = e
            except Exception as e:
                # Some SDK/network errors may not raise TimeoutError; treat transient network flakiness as retryable.
                last_exc = e
                if not _is_retryable_fs_list_error(e):
                    raise

            # retry if we have attempts left
            if attempt < int(_FSLIST_RETRY or 0):
                await asyncio.sleep(backoffs[min(attempt, len(backoffs) - 1)])
                continue
            # Final attempt failed.
            # If we have any cached value (even stale), prefer returning it for UI navigation
            # instead of hard-failing on 115's occasional WAF/risk-control responses (e.g. HTTP 405/429).
            if cached is not None and last_exc and _is_retryable_fs_list_error(last_exc):
                try:
                    age = now - float(ts or 0.0)
                except (TypeError, ValueError):
                    age = -1.0
                logger.warning(
                    "115 fs_list transient failure, fallback to cached result (cid=%s offset=%s limit=%s cache_age=%.1fs): %s",
                    cid,
                    offset,
                    limit,
                    age,
                    last_exc,
                )
                return cached  # type: ignore
            if last_exc:
                msg = str(last_exc)
                if ("风控" in msg) or ("method not allowed" in msg.lower()) or ("captcha" in msg.lower()) or ("text/html" in msg.lower()):
                    _raise_115_risk_control(0, msg[:200])
                raise last_exc
        # unreachable
        raise ExternalServiceError("cloud115 fs_list: unreachable")
    async def list_child_folders(self, cid: int = 0, *, offset: int = 0, limit: int = 50) -> Tuple[List[Cloud115Item], int]:
        """返回 (folders, total_count)。folders 的 file_id 即子目录 cid。

        115 的 /files 返回结构在不同节点/时期可能不一致：
        - resp['data'] 可能是 list
        - resp['data'] 可能是 dict，里面再嵌套 data/list/folder 等字段
        - 目录项有时会带 fid="0" 或其他弱标志位

        这里做“强健解析”：尽可能把“子文件夹列表”解析出来，保证目录树可用。
        """
        cid0 = int(cid or 0)
        resp = await self.fs_list_folders(cid0, offset=offset, limit=limit)

        # Detect common 115 error shapes early so the UI can show a real error instead of
        # misleading “no subfolders”.
        try:
            errno = resp.get('errno') if isinstance(resp, dict) else None
            errtxt = resp.get('error') if isinstance(resp, dict) else None
            state = resp.get('state') if isinstance(resp, dict) else None
        except Exception:
            errno, errtxt, state = None, None, None
        if (errno is not None and str(errno) not in ('0', 'None', '')) or (state in (False, 0, '0', 'false', 'False')):
            # Many 115 APIs return {'errno': <non-zero>, 'error': '...'} when cookie expired or risk-control triggered.
            raise ExternalServiceError(f"115 API 返回错误: errno={errno} error={errtxt or state}")


        def _extract_items(r: Dict[str, Any]) -> List[Dict[str, Any]]:
            # 1) Top-level list keys
            for k in ("items", "list"):
                v = r.get(k)
                if isinstance(v, list):
                    return [x for x in v if isinstance(x, dict)]

            data = r.get("data")
            # 2) data is already a list
            if isinstance(data, list):
                return [x for x in data if isinstance(x, dict)]

            # 3) data is a dict with nested lists
            if isinstance(data, dict):
                # Most common
                for k in ("data", "list", "items", "folder", "folders", "dir", "dirs", "sub", "subdirs"):
                    v = data.get(k)
                    if isinstance(v, list):
                        return [x for x in v if isinstance(x, dict)]

                # folder/dir could itself be a dict containing a list
                for k in ("folder", "folders", "dir", "dirs"):
                    v = data.get(k)
                    if isinstance(v, dict):
                        for k2 in ("data", "list", "items"):
                            v2 = v.get(k2)
                            if isinstance(v2, list):
                                return [x for x in v2 if isinstance(x, dict)]

            return []

        items: List[Dict[str, Any]] = _extract_items(resp)

        # If extracted list is empty, emit a compact diagnostic once per cid to help field debugging.
        if not items:
            try:
                data0 = resp.get("data")
                brief = {
                    "keys": sorted(list(resp.keys()))[:20],
                    "errno": resp.get("errno"),
                    "error": resp.get("error"),
                    "state": resp.get("state"),
                    "data_type": type(data0).__name__,
                    "data_keys": sorted(list(data0.keys()))[:20] if isinstance(data0, dict) else None,
                    "count": resp.get("count") or (data0.get("count") if isinstance(data0, dict) else None),
                    "total": resp.get("total") or (data0.get("total") if isinstance(data0, dict) else None),
                }
                logger.warning("115 目录项为空（可能被风控/接口形态变化）: cid=%s offset=%s limit=%s brief=%s", cid0, int(offset or 0), int(limit or 0), brief)
            except Exception:
                logger.detail("115 空列表诊断输出失败", exc_info=True)


        # total fields: try resp first, then resp['data'] dict, fallback to len(items)
        total = 0
        for k in ("count", "total", "sys_count", "data_count"):
            try:
                if resp.get(k) is not None:
                    total = int(resp.get(k) or 0)
                    break
            except (ValueError, TypeError):
                logger.detail("115 总数字段解析失败 - field=%s value=%r", k, resp.get(k), exc_info=True)

        if total <= 0:
            data = resp.get("data")
            if isinstance(data, dict):
                for k in ("count", "total", "sys_count", "data_count"):
                    try:
                        if data.get(k) is not None:
                            total = int(data.get(k) or 0)
                            break
                    except (ValueError, TypeError):
                        logger.detail("115 data.* 总数字段解析失败 - field=%s value=%r", k, data.get(k), exc_info=True)

        if total <= 0:
            total = len(items)

        def _to_int(v: Any) -> int:
            try:
                if v is None:
                    return 0
                s = str(v).strip()
                if not s:
                    return 0
                # some fields come as "0" / "123" strings
                if s.isdigit() or (s.startswith("-") and s[1:].isdigit()):
                    return int(s)
                # tolerate floats like "123.0"
                if s.replace(".", "", 1).isdigit() and s.count(".") == 1:
                    return int(float(s))
            except Exception:
                return 0
            return 0

        def _pick_name(it: Dict[str, Any], fallback_id: int) -> str:
            for k in ("n", "file_name", "name", "fname", "title"):
                v = it.get(k)
                if isinstance(v, str) and v.strip():
                    return v.strip()
            return str(fallback_id)

        folders: List[Cloud115Item] = []
        sample: List[Dict[str, Any]] = []
        for it in items or []:
            if not isinstance(it, dict):
                continue

            # === TG 同款判定：有 cid 且 fid 为 ""/0/"0" 视为目录；fid>0 视为文件 ===
            fid_raw = it.get("fid")
            fid_int = _to_int(fid_raw)
            if fid_raw not in (None, "", 0, "0") and fid_int <= 0:
                # 非数字但有值（例如某些版本返回 fid="abc"），按文件处理
                fid_int = 1
            if fid_int > 0:
                # file
                continue

            # folder id: prefer child cid; fallback to other keys
            folder_id = _to_int(it.get("cid"))
            if folder_id <= 0:
                for k in ("category_id", "folder_id", "dir_id", "file_id", "id"):
                    folder_id = _to_int(it.get(k))
                    if folder_id > 0:
                        break
            if folder_id <= 0:
                if len(sample) < 3:
                    sample.append({"keys": list(it.keys())[:20], "cid": it.get("cid"), "fid": it.get("fid"), "name": it.get("n") or it.get("name")})
                continue
            if folder_id == cid0:
                # 防误伤：部分条目会携带 parent cid
                continue

            name = _pick_name(it, folder_id)
            folders.append(Cloud115Item(name=name, file_id=folder_id, is_selected=False))

        if not folders and items:
            # 目录项非空但筛不出文件夹：把样本打出来，便于定位 115 字段形态
            try:
                if not sample:
                    for it in items[:3]:
                        if isinstance(it, dict):
                            sample.append({"keys": list(it.keys())[:20], "cid": it.get("cid"), "fid": it.get("fid"), "name": it.get("n") or it.get("name")})
                logger.warning("115 目录筛选结果为空（items=%s cid=%s）：sample=%s", len(items), cid0, sample)
            except Exception:
                logger.detail("115 目录筛选空结果样本输出失败", exc_info=True)

        return folders, int(total)


    async def get_storage_info(self) -> Dict[str, Any]:
        """获取网盘容量信息（已用/总量等）。"""
        resp = await self._await_with_timeout(
            self._sdk.request(
                url="https://115.com/index.php",
                method="GET",
                params={"ct": "ajax", "ac": "get_storage_info"},
                async_=True,
            ),
            action="storage_info",
        )
        resp = check_response(resp)  # type: ignore
        return resp

    async def get_offline_space(self) -> Dict[str, Any]:
        """获取云下载（离线）空间信息（已用/总量等）。"""
        resp = await self._await_with_timeout(
            self._sdk.request(
                url="https://115.com/",
                method="GET",
                params={"ct": "offline", "ac": "space"},
                async_=True,
            ),
            action="offline_space",
        )
        resp = check_response(resp)  # type: ignore
        return resp

    async def get_quota_package_info(self) -> Dict[str, Any]:
        """获取云下载配额包信息（新版 Web 端接口）。

        Web 端（2025 近期）常见调用：
          GET /web/lixian/?ct=lixian&ac=get_quota_package_info
        """
        resp = await self._await_with_timeout(
            self._sdk.request(
                url="https://115.com/web/lixian/",
                method="GET",
                params={"ct": "lixian", "ac": "get_quota_package_info"},
                async_=True,
            ),
            action="quota_package",
        )
        resp = check_response(resp)  # type: ignore
        return resp

    # ----------------------------- File Operations -----------------------------

    async def move_files(self, file_ids: List[Union[str, int]], target_cid: int) -> Dict[str, Any]:
        """移动文件到指定目录。

        Args:
            file_ids: 文件 ID 列表
            target_cid: 目标目录 ID

        Returns:
            API 响应
        """
        if not file_ids:
            raise ValidationError("file_ids 不能为空")

        # 115 API: POST https://webapi.115.com/files/move
        # 参数: pid=目标目录ID, fid[0]=文件ID1, fid[1]=文件ID2, ...
        data: Dict[str, Any] = {"pid": int(target_cid)}
        for i, fid in enumerate(file_ids):
            data[f"fid[{i}]"] = str(fid)

        resp = await self._await_with_timeout(
            self._sdk.request(
                url="https://webapi.115.com/files/move",
                method="POST",
                data=data,
                async_=True,
            ),
            action="move_files",
        )
        resp = check_response(resp)  # type: ignore
        logger.ok("移动文件成功 - 文件数=%d 目标目录=%d", len(file_ids), target_cid)
        return resp

    async def delete_files(
        self,
        file_ids: List[Union[str, int]],
        to_recycle: bool = True,
    ) -> Dict[str, Any]:
        """删除文件。

        Args:
            file_ids: 文件 ID 列表
            to_recycle: True=移到回收站，False=永久删除

        Returns:
            API 响应
        """
        if not file_ids:
            raise ValidationError("file_ids 不能为空")

        # 115 API:
        # - 移到回收站: POST https://webapi.115.com/rb/delete
        # - 永久删除: POST https://webapi.115.com/rb/clean (需要先在回收站)
        # 参数: fid[0]=文件ID1, fid[1]=文件ID2, ...
        data: Dict[str, Any] = {}
        for i, fid in enumerate(file_ids):
            data[f"fid[{i}]"] = str(fid)

        if to_recycle:
            url = "https://webapi.115.com/rb/delete"
            action = "delete_to_recycle"
        else:
            # 永久删除需要先移到回收站再清空
            # 这里简化处理，直接用 rb/delete
            url = "https://webapi.115.com/rb/delete"
            action = "delete_permanent"
            logger.warning("永久删除暂时使用回收站删除，需要手动清空回收站")

        resp = await self._await_with_timeout(
            self._sdk.request(
                url=url,
                method="POST",
                data=data,
                async_=True,
            ),
            action=action,
        )
        resp = check_response(resp)  # type: ignore
        logger.ok("删除文件成功 - 文件数=%d 回收站=%s", len(file_ids), to_recycle)
        return resp

    async def move_file(self, file_id: Union[str, int], target_cid: int) -> bool:
        """移动单个文件。

        Args:
            file_id: 文件 ID
            target_cid: 目标目录 ID

        Returns:
            是否成功
        """
        try:
            await self.move_files([file_id], target_cid)
            return True
        except Exception as e:
            logger.fail("移动文件失败 - 文件ID=%s 错误=%s", file_id, str(e))
            return False

    async def delete_file(self, file_id: Union[str, int], to_recycle: bool = True) -> bool:
        """删除单个文件。

        Args:
            file_id: 文件 ID
            to_recycle: True=移到回收站，False=永久删除

        Returns:
            是否成功
        """
        try:
            await self.delete_files([file_id], to_recycle=to_recycle)
            return True
        except Exception as e:
            logger.fail("删除文件失败 - 文件ID=%s 错误=%s", file_id, str(e))
            return False