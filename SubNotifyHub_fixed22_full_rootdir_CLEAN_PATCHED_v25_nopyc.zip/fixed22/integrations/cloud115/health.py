from __future__ import annotations

import asyncio
import logging
from core.logging import get_biz_logger_adapter
import time
from dataclasses import dataclass
from typing import Optional, Awaitable, Callable

from ports.settings_provider import get_settings

logger = get_biz_logger_adapter(__name__)


@dataclass
class Cloud115HealthState:
    status: str = "unknown"  # unknown / ok / missing / invalid
    consecutive_fail: int = 0
    last_check_ts: float = 0.0
    last_ok_ts: float = 0.0
    last_notify_ts: float = 0.0
    last_error: str = ""


def _should_notify(now: float, *, last_notify_ts: float, cooldown: float) -> bool:
    if cooldown <= 0:
        return True
    return (now - float(last_notify_ts or 0.0)) >= float(cooldown)


async def _check_cookie_once(*, timeout: float) -> tuple[bool, str]:
    """Return (ok, err)."""
    s = get_settings()
    cookie = str(getattr(s, "CLOUD115_COOKIE", "") or "").strip()
    if not cookie:
        return False, "missing"

    try:
        from integrations.cloud115.client import Cloud115Client
    except Exception as e:
        return False, f"cloud115_import_failed:{type(e).__name__}"

    try:
        cli = Cloud115Client(cookie, timeout=float(timeout or 6.0))
        # Use downpath as a lightweight authenticated call. Force refresh so it actually validates cookie.
        await cli.get_downpath(force_refresh=True)
        return True, ""
    except Exception as e:
        # Best-effort classify
        msg = str(e)
        low = msg.lower()
        if "relogin" in low or "login" in low or "cookie" in low or "unauthor" in low:
            return False, "unauthorized"
        return False, f"{type(e).__name__}:{msg[:200]}"


async def run_cloud115_cookie_health_loop(
    *,
    stop_evt: asyncio.Event,
    state: Cloud115HealthState,
    add_warning: callable,
    remove_warning: callable,
    notify: Callable[[str], Awaitable[None]] | None = None,
) -> None:
    """Background loop: periodically validate CLOUD115_COOKIE and notify on state changes."""

    while not stop_evt.is_set():
        s = get_settings()

        if not bool(getattr(s, "CLOUD115_HEALTHCHECK_ENABLED", True)):
            # Sleep a bit and re-check config.
            await asyncio.sleep(10.0)
            continue

        interval = float(getattr(s, "CLOUD115_HEALTHCHECK_INTERVAL_SEC", 21600) or 21600)
        timeout = float(getattr(s, "CLOUD115_HEALTHCHECK_TIMEOUT_SEC", 6.0) or 6.0)
        threshold = int(getattr(s, "CLOUD115_HEALTHCHECK_FAIL_THRESHOLD", 2) or 2)
        cooldown = float(getattr(s, "CLOUD115_HEALTHCHECK_NOTIFY_COOLDOWN_SEC", 7200) or 7200)

        now = time.time()

        ok, err = await _check_cookie_once(timeout=timeout)
        state.last_check_ts = now

        cookie_missing = (err == "missing")
        if cookie_missing:
            # Do not spam when user hasn't configured cookie.
            state.status = "missing"
            state.consecutive_fail = 0
            state.last_error = "missing"
            remove_warning("cloud115_cookie_invalid")
            add_warning("cloud115_cookie_missing")

        elif ok:
            # Recovered
            prev = state.status
            state.status = "ok"
            state.consecutive_fail = 0
            state.last_ok_ts = now
            state.last_error = ""
            remove_warning("cloud115_cookie_invalid")
            remove_warning("cloud115_cookie_missing")

            if prev == "invalid":
                # State transition: always notify (no cooldown needed)
                if notify:
                    await notify("✅ 115 登录已恢复：CLOUD115_COOKIE 校验成功。")
                state.last_notify_ts = now

        else:
            # Failed this round
            state.consecutive_fail += 1
            state.last_error = err
            remove_warning("cloud115_cookie_missing")

            # Only flip to invalid after threshold
            if state.consecutive_fail >= max(1, threshold):
                prev = state.status
                state.status = "invalid"
                add_warning("cloud115_cookie_invalid")
                if prev != "invalid":
                    # State transition: always notify
                    if notify:
                        await notify(
                            "⚠️ 115 登录可能已失效：CLOUD115_COOKIE 校验失败。\n"
                            "请在 TG 使用 /115login 重新扫码，或在后台更新 CLOUD115_COOKIE。"
                        )
                    state.last_notify_ts = now
                else:
                    # Still invalid: honor cooldown
                    if _should_notify(now, last_notify_ts=state.last_notify_ts, cooldown=cooldown):
                        if notify:
                            await notify(
                                "⚠️ 115 仍未恢复：CLOUD115_COOKIE 校验持续失败。\n"
                                "建议重新扫码 /115login（或后台更新 cookie）。"
                            )
                        state.last_notify_ts = now

        # Sleep until next round, but wake early on stop.
        try:
            await asyncio.wait_for(stop_evt.wait(), timeout=max(5.0, interval))
        except asyncio.TimeoutError:
            pass
