from __future__ import annotations

from core.exceptions.base import ExternalServiceError

import base64
import time
from collections import OrderedDict
from dataclasses import dataclass
from typing import Any, Dict, Optional

import httpx

from core.http import get_http_client
from core.http import async_request_with_retry
from settings.timeouts import TimeoutCategory, get_timeout
from settings.retries import RetryCategory, get_retry_config
from settings.urls import URLCategory, get_url


# Get default retry config for 115 API
_CLOUD115_RETRY = get_retry_config(RetryCategory.EXTERNAL_SERVICE)


@dataclass
class QRSession:
    uid: str
    time_str: str
    sign: str
    created_at: float
    app: str


# in-memory sessions (uid as key)
# NOTE: keep as insertion-ordered map so we can evict oldest.
QR_SESSIONS: "OrderedDict[str, QRSession]" = OrderedDict()

# default limits (defense against abuse)
_QR_SESSION_MAX_AGE_SEC = 600
_QR_SESSION_MAX_ITEMS = 200


def purge_old_sessions(*, max_age_sec: int = _QR_SESSION_MAX_AGE_SEC, max_items: int = _QR_SESSION_MAX_ITEMS) -> None:
    """Best-effort purge for QR_SESSIONS.

    Called on hot paths to avoid unbounded growth when /115login is spammed.
    """
    try:
        now = float(time.time())
    except (ValueError, TypeError):
        return

    # 1) remove expired
    for k, sess in list(QR_SESSIONS.items()):
        try:
            if (now - float(getattr(sess, "created_at", now))) > float(max_age_sec):
                QR_SESSIONS.pop(k, None)
        except (ValueError, TypeError, KeyError, AttributeError):
            continue

    # 2) bound size (evict oldest)
    try:
        while len(QR_SESSIONS) > int(max_items):
            try:
                QR_SESSIONS.popitem(last=False)
            except (KeyError, IndexError):
                break
    except (ValueError, TypeError):
        pass


def _ua() -> str:
    return "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"


async def _get_json(client: httpx.AsyncClient, url: str, *, params: Optional[Dict[str, str]] = None, headers: Optional[Dict[str, str]] = None) -> Any:
    resp = await async_request_with_retry(
        client,
        "GET",
        url,
        params=params,
        headers=headers,
        timeout=get_timeout(TimeoutCategory.CLOUD115_API),
        max_attempts=_CLOUD115_RETRY.max_retries,
        backoff=_CLOUD115_RETRY.backoff,
        log_ctx="115_qr:get_json",
    )
    resp.raise_for_status()
    try:
        return resp.json()
    finally:
        try:
            await resp.aclose()
        except (httpx.HTTPError, OSError, RuntimeError):
            pass


async def start_qrcode_login(*, app: str = "windows") -> Dict[str, Any]:
    """Start QR login flow.

    Returns:
      { uid, time, sign, qr_png_base64, app }
    """
    token_url = f"{get_url(URLCategory.CLOUD115_QRCODE)}/api/1.0/web/1.0/token/"
    qrcode_url = f"{get_url(URLCategory.CLOUD115_QRCODE)}/api/1.0/mac/1.0/qrcode"

    headers = {
        "User-Agent": _ua(),
        "Accept": "application/json, text/plain, */*",
        "Referer": get_url(URLCategory.CLOUD115_REFERER),
    }

    purge_old_sessions()

    client = await get_http_client()

    data = await _get_json(client, token_url, headers=headers)
    root = data if isinstance(data, dict) else {}
    d = root.get("data") if isinstance(root.get("data"), dict) else root
    uid = str(d.get("uid") or "").strip()
    t = str(d.get("time") or "").strip()
    sign = str(d.get("sign") or "").strip()
    if not uid or not t or not sign:
        raise ExternalServiceError("qrcode token missing uid/time/sign")

    # fetch QR image bytes (with retry; 115 may return 429)
    resp = await async_request_with_retry(
        client,
        "GET",
        qrcode_url,
        params={"uid": uid, "app": app},
        headers=headers,
        timeout=get_timeout(TimeoutCategory.HTTP_DEFAULT),
        max_attempts=_CLOUD115_RETRY.max_retries,
        backoff=_CLOUD115_RETRY.backoff,
        log_ctx="115_qr:qrcode_png",
    )
    try:
        resp.raise_for_status()
        png = resp.content
    finally:
        try:
            await resp.aclose()
        except (httpx.HTTPError, OSError, RuntimeError):
            pass
    b64 = base64.b64encode(png).decode("ascii")

    QR_SESSIONS[uid] = QRSession(uid=uid, time_str=t, sign=sign, created_at=time.time(), app=app)
    return {"uid": uid, "time": t, "sign": sign, "qr_png_base64": b64, "app": app}

async def poll_qrcode_status(uid: str) -> Dict[str, Any]:
    purge_old_sessions()
    sess = QR_SESSIONS.get(uid)
    if not sess:
        return {"ok": False, "detail": "session_not_found"}

    status_url = f"{get_url(URLCategory.CLOUD115_QRCODE)}/get/status/"
    headers = {
        "User-Agent": _ua(),
        "Accept": "application/json, text/plain, */*",
        "Referer": get_url(URLCategory.CLOUD115_REFERER),
    }

    client = await get_http_client()
    data = await _get_json(
        client,
        status_url,
        params={"uid": sess.uid, "time": sess.time_str, "sign": sess.sign},
        headers=headers,
    )

    root = data if isinstance(data, dict) else {}
    d = root.get("data") if isinstance(root.get("data"), dict) else root
    status = d.get("status") if isinstance(d, dict) else None
    msg = str(d.get("msg") or root.get("msg") or root.get("message") or root.get("error") or "").strip()
    try:
        status_i = int(status) if status is not None else None
    except (ValueError, TypeError):
        status_i = None

    phase = "waiting"
    if status_i == 1:
        phase = "scanned"
    elif status_i == 2:
        phase = "confirmed"
    elif status_i is not None and status_i >= 3:
        phase = "expired"

    if phase == "expired":
        try:
            QR_SESSIONS.pop(uid, None)
        except (KeyError, TypeError):
            pass

    return {"ok": True, "phase": phase, "status": status_i, "msg": msg}


async def exchange_qrcode_for_cookie(uid: str) -> str:
    purge_old_sessions()
    sess = QR_SESSIONS.get(uid)
    if not sess:
        raise ExternalServiceError("session_not_found")

    api = f"{get_url(URLCategory.CLOUD115_PASSPORT)}/app/1.0/{sess.app}/1.0/login/qrcode/"
    headers = {
        "User-Agent": _ua(),
        "Accept": "application/json, text/plain, */*",
        "Referer": get_url(URLCategory.CLOUD115_REFERER),
    }

    purge_old_sessions()

    client = await get_http_client()
    resp: httpx.Response | None = None
    try:
        resp = await async_request_with_retry(
            client,
            "POST",
            api,
            data={"app": sess.app, "account": sess.uid},
            headers=headers,
            timeout=get_timeout(TimeoutCategory.CLOUD115_API),
            max_attempts=_CLOUD115_RETRY.max_retries,
            backoff=_CLOUD115_RETRY.backoff,
            log_ctx="115_qr:exchange",
        )
        resp.raise_for_status()

        try:
            QR_SESSIONS.pop(uid, None)
        except (KeyError, TypeError):
            pass

        data: Any = {}
        try:
            if (resp.headers.get("content-type", "") or "").startswith("application/json"):
                data = resp.json()
        except (ValueError, TypeError, httpx.HTTPError):
            data = {}

        root = data if isinstance(data, dict) else {}
        d = root.get("data") if isinstance(root.get("data"), dict) else root
        cookie_obj = d.get("cookie") if isinstance(d, dict) else None

        if isinstance(cookie_obj, str) and cookie_obj.strip():
            return cookie_obj.strip().rstrip(";")
        if isinstance(cookie_obj, dict):
            uidv = str(cookie_obj.get("UID") or cookie_obj.get("uid") or "").strip()
            cidv = str(cookie_obj.get("CID") or cookie_obj.get("cid") or "").strip()
            seidv = str(cookie_obj.get("SEID") or cookie_obj.get("seid") or "").strip()
            parts = []
            if uidv:
                parts.append(f"UID={uidv}")
            if cidv:
                parts.append(f"CID={cidv}")
            if seidv:
                parts.append(f"SEID={seidv}")
            if parts:
                return "; ".join(parts)

        # last resort: pick from response cookies (snapshot before close)
        try:
            jar = resp.cookies
        except (AttributeError, httpx.HTTPError):
            jar = None

        parts2 = []
        if jar is not None:
            for k in ("UID", "CID", "SEID"):
                try:
                    v = jar.get(k)
                except (KeyError, TypeError, AttributeError):
                    v = None
                if v:
                    parts2.append(f"{k}={v}")
        if parts2:
            return "; ".join(parts2)

        raise ExternalServiceError("no_cookie_in_qrcode_login_response")
    finally:
        if resp is not None:
            try:
                await resp.aclose()
            except (httpx.HTTPError, OSError, RuntimeError):
                pass
