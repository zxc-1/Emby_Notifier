from __future__ import annotations

import asyncio
import time
from typing import Any, Mapping

from core.logging import get_biz_logger
from ports.http_client import AsyncHttpClient, HttpRequestError, HttpTimeoutError
from ports.tmdb import TmdbGateway
from settings.timeouts import TimeoutCategory, get_timeout
from settings.urls import get_tmdb_api_url

biz = get_biz_logger(__name__)


class DefaultTmdbGateway(TmdbGateway):
    """TMDB gateway adapter using :class:`ports.http_client.AsyncHttpClient`."""

    def __init__(self, *, http: AsyncHttpClient, settings: Any) -> None:
        self._http = http
        self._settings = settings

    def _base_params(self) -> dict[str, Any] | None:
        s = self._settings
        api_key = str(getattr(s, "TMDB_API_KEY", "") or "").strip()
        if not api_key:
            return None
        lang = str(getattr(s, "TMDB_LANGUAGE", "") or "").strip()
        region = str(getattr(s, "TMDB_REGION", "") or "").strip()
        out: dict[str, Any] = {"api_key": api_key}
        if lang:
            out["language"] = lang
        if region:
            out["region"] = region
        return out

    async def get_json(self, path: str, *, params: Mapping[str, Any] | None = None) -> dict[str, Any] | None:
        base_params = self._base_params()
        if base_params is None:
            biz.detail("TMDB API 密钥未配置，跳过请求", path=path)
            return None

        url = get_tmdb_api_url(path)
        merged = {**base_params, **dict(params or {})}

        # Metrics are optional.
        try:
            from core.metrics import metrics  # type: ignore
        except (ImportError, AttributeError):
            biz.detail("metrics 模块导入失败，将跳过 metrics 记录", path=path)
            metrics = None  # type: ignore

        last_exc: Exception | None = None
        for attempt in range(3):
            try:
                t0 = time.monotonic()
                biz.detail("TMDB API 请求开始", stage="tmdb_request", path=path, attempt=attempt + 1)
                resp = await self._http.get(url, params=merged, timeout=get_timeout(TimeoutCategory.TMDB_API))
                dt = int((time.monotonic() - t0) * 1000)
                biz.ok("TMDB API 请求完成", path=path, status=resp.status_code, duration_ms=dt)
                try:
                    if metrics:
                        metrics.observe("external_request_ms", float(dt), labels={"service": "tmdb"})
                except (ValueError, TypeError, AttributeError, RuntimeError):
                    biz.detail("metrics 记录失败", duration_ms=dt, path=path)

                if int(resp.status_code) != 200:
                    body_snip = (resp.text or "")[:800]
                    biz.warning("TMDB 请求失败，状态码非 200", path=path, status=resp.status_code, body_snip=body_snip)
                    try:
                        if metrics:
                            metrics.inc("external_error_total", labels={"service": "tmdb"})
                    except (ValueError, TypeError, AttributeError, RuntimeError):
                        biz.detail("metrics 错误计数失败", status=resp.status_code, path=path)
                    return None

                try:
                    data = resp.json()
                except (ValueError, TypeError):
                    biz.detail("JSON 解析失败", path=path, status=resp.status_code)
                    data = None
                if isinstance(data, dict):
                    try:
                        if metrics:
                            metrics.inc("external_success_total", labels={"service": "tmdb"})
                    except (ValueError, TypeError, AttributeError, RuntimeError):
                        biz.detail("metrics 成功计数失败", path=path)
                    return data
                return None

            except (HttpTimeoutError, HttpRequestError) as exc:
                last_exc = exc
                biz.warning("TMDB 请求临时失败，将重试", path=path, attempt=attempt + 1, error=str(exc))
                try:
                    if metrics:
                        metrics.inc("external_error_total", labels={"service": "tmdb"})
                except (ValueError, TypeError, AttributeError, RuntimeError):
                    biz.detail("metrics 错误计数失败", path=path, error=type(exc).__name__)
                if attempt < 2:
                    await asyncio.sleep(2 ** attempt)
                continue
            except Exception as exc:
                last_exc = exc
                biz.fail("TMDB 请求发生意外错误", path=path, error=str(exc), exc_info=True)
                try:
                    if metrics:
                        metrics.inc("external_error_total", labels={"service": "tmdb"})
                except (ValueError, TypeError, AttributeError, RuntimeError):
                    biz.detail("metrics 错误计数失败", path=path, error=type(exc).__name__)
                return None

        biz.fail("TMDB 请求在多次重试后仍然失败", path=path, error=str(last_exc))
        return None

    async def search(
        self,
        media_type: str,
        *,
        query: str,
        year: int | None = None,
        first_air_date_year: int | None = None,
        page: int | None = None,
        include_adult: bool | None = None,
    ) -> dict[str, Any] | None:
        mt = str(media_type or "").lower()
        if mt not in {"movie", "tv"}:
            return None
        params: dict[str, Any] = {"query": query}
        if page is not None:
            params["page"] = int(page)
        if include_adult is not None:
            params["include_adult"] = bool(include_adult)
        if mt == "movie":
            if year is not None:
                params["year"] = int(year)
        else:
            # TMDB uses first_air_date_year for tv.
            if first_air_date_year is not None:
                params["first_air_date_year"] = int(first_air_date_year)
            elif year is not None:
                params["first_air_date_year"] = int(year)
        return await self.get_json(f"/search/{mt}", params=params)

    async def fetch_detail(
        self,
        media_type: str,
        tmdb_id: int | str,
        *,
        append_to_response: str | None = None,
    ) -> dict[str, Any] | None:
        mt = str(media_type or "").lower()
        if mt not in {"movie", "tv"}:
            return None
        params: dict[str, Any] = {}
        if append_to_response:
            params["append_to_response"] = str(append_to_response)
        return await self.get_json(f"/{mt}/{tmdb_id}", params=params)

    async def find_by_external_id(
        self,
        external_id: str,
        *,
        external_source: str = "imdb_id",
    ) -> dict[str, Any] | None:
        params: dict[str, Any] = {"external_source": str(external_source)}
        return await self.get_json(f"/find/{external_id}", params=params)

    async def alias_titles(self, media_type: str, tmdb_id: int | str) -> dict[str, Any] | None:
        mt = str(media_type or "").lower()
        if mt not in {"movie", "tv"}:
            return None
        # For movies the endpoint is /movie/{id}/alternative_titles.
        # For TV the endpoint is /tv/{id}/alternative_titles.
        return await self.get_json(f"/{mt}/{tmdb_id}/alternative_titles", params={})
