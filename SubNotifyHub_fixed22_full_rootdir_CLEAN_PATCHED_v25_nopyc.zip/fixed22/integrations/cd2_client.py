from __future__ import annotations

"""CloudDrive2 (CD2) integration.

This repo integrates with CloudDrive2 via python-clouddrive2 (import name:
`clouddrive`). Different deployments may expose slightly different proto / RPC
surfaces, so this client is written to be tolerant to:

- field name differences (savePath vs save_path, taskId vs id, ...)
- RPC name differences (AddOfflineFiles vs AddOfflineFile vs AddOffline)

⚠️ Important: In the user's runtime environment, CreateFolderRequest fields are
['parentPath', 'folderName'] (NOT parentId). This client therefore never sends
parentId.
"""

from dataclasses import dataclass
from typing import Any, Optional

import asyncio
import logging
import re
import base64

log = logging.getLogger(__name__)

_BTih_RE = re.compile(r"btih:([0-9a-fA-F]{40}|[A-Z2-7]{32})")


def _extract_btih(magnet: str) -> str:
    """Extract BTIH infohash from a magnet link.

    Returns lowercase hex when possible (base32 will be decoded to hex).
    """

    m = (magnet or "").strip()
    if not m:
        return ""

    mo = _BTih_RE.search(m)
    if not mo:
        return ""

    v = (mo.group(1) or "").strip()
    if not v:
        return ""

    # base32 -> hex
    if len(v) == 32 and re.fullmatch(r"[A-Z2-7]+", v, flags=re.I):
        try:
            return base64.b32decode(v.upper()).hex()
        except Exception:
            return v

    # hex
    if len(v) == 40 and re.fullmatch(r"[0-9a-fA-F]+", v):
        return v.lower()

    return v


def _resp_is_success(resp: Any) -> bool:
    """Best-effort success detector for different proto response types."""

    if resp is None:
        return False

    succ = _extract_attr(resp, ("success", "ok", "succeed", "succeeded", "result"))
    if isinstance(succ, bool):
        return succ
    if isinstance(succ, (int, float)):
        return int(succ) == 1

    code = _extract_attr(resp, ("code", "status", "statusCode", "status_code"))
    if isinstance(code, (int, float)):
        # Some APIs use 0 for OK
        if int(code) == 0:
            return True
        # Some might use HTTP-like codes
        if int(code) == 200:
            return True

    err = _extract_attr(resp, ("errorMessage", "error", "err", "message", "msg"))
    if err:
        return False

    # As a last resort: assume "no error field" means success.
    return True


class Cd2Error(RuntimeError):
    """CD2 integration error (human-meaningful message in .args[0])."""


@dataclass(frozen=True)
class Cd2Config:
    mode: str  # cloudapi | grpc
    base_url: str  # http(s)://host:19798 (UI + CloudAPI)
    username: str = ""
    password: str = ""
    grpc_addr: str = ""  # host:port (optional)
    token: str = ""  # bearer token (grpc metadata); REQUIRED when mode=grpc
    default_dir: str = ""
    auto_mkdir: bool = True

    # Optional: some gRPC builds require cloud identity to list offline files.
    cloud_name: str = ""
    cloud_account_id: str = ""


def _norm_path(p: str) -> str:
    p = (p or "").strip()
    if not p:
        return "/"
    if not p.startswith("/"):
        p = "/" + p
    # remove trailing slash except root
    if len(p) > 1 and p.endswith("/"):
        p = p[:-1]
    return p


def _split_parts(path: str) -> list[str]:
    path = _norm_path(path)
    if path == "/":
        return []
    return [x for x in path.split("/") if x]


def _ensure_dep():
    try:
        import clouddrive  # type: ignore

        return clouddrive
    except Exception as e:
        raise Cd2Error(
            "缺少依赖 python-clouddrive2：请在 requirements/requirements.txt 中安装 python-clouddrive2"
        ) from e


def _get_pb2():
    """Import CloudDrive2 generated protos from python-clouddrive2."""

    try:
        from clouddrive.proto import CloudDrive_pb2  # type: ignore
        from clouddrive.proto import CloudDrive_pb2_grpc  # type: ignore

        return CloudDrive_pb2, CloudDrive_pb2_grpc
    except Exception as e:
        raise Cd2Error("无法导入 CloudDrive2 gRPC proto（clouddrive.proto.CloudDrive_pb2*）") from e


def _set_best_effort(msg: Any, field: str, value: Any) -> bool:
    """Set a protobuf field if it exists and is compatible."""

    try:
        desc = msg.DESCRIPTOR  # type: ignore[attr-defined]
    except Exception:
        return False

    fd = None
    for f in getattr(desc, "fields", []):
        if f.name == field:
            fd = f
            break
    if fd is None:
        return False

    try:
        cur = getattr(msg, field)
        if getattr(fd, "label", None) == fd.LABEL_REPEATED:
            if value is None:
                return True
            if isinstance(value, (list, tuple, set)):
                cur.extend(list(value))
            else:
                cur.append(value)
            return True

        setattr(msg, field, value)
        return True
    except Exception:
        return False


def _grpc_metadata(cfg: Cd2Config) -> list[tuple[str, str]]:
    token = (cfg.token or "").strip()
    if not token:
        return []

    # grpc metadata keys must be lowercase
    return [("authorization", f"Bearer {token}")]


def _iter_public_callables(obj: Any) -> list[str]:
    """Return a stable list of callable public attribute names."""

    out: list[str] = []
    try:
        for n in dir(obj):
            if n.startswith("_"):
                continue
            try:
                v = getattr(obj, n)
            except Exception:
                continue
            if callable(v):
                out.append(n)
    except Exception:
        return []
    return sorted(set(out))


def _extract_attr(obj: Any, names: tuple[str, ...]) -> Any:
    """Best-effort attribute/key extraction.

    Supports both protobuf message objects (attr access) and dict responses
    returned by some CloudAPI helpers.
    """

    if obj is None:
        return None

    # dict payloads (cloudapi)
    if isinstance(obj, dict):
        for n in names:
            if n in obj and obj.get(n) is not None:
                return obj.get(n)
        return None

    # protobuf / plain objects (grpc)
    for n in names:
        if hasattr(obj, n):
            v = getattr(obj, n)
            if v is not None:
                return v
    return None


def _find_in_list(resp: Any, task_id: str) -> Any | None:
    if resp is None:
        return None

    # Common list containers
    for container_name in ("items", "tasks", "list", "data", "downloads", "files", "offlineFiles", "offline_files", "rows", "entries", "records"):
        if hasattr(resp, container_name):
            seq = getattr(resp, container_name)
            try:
                for x in seq:
                    # Different CD2 builds may expose different identifiers.
                    # - download task: taskId / id
                    # - offline file:  fileId / infoHash
                    if str(
                        _extract_attr(
                            x,
                            (
                                "taskId",
                                "id",
                                "task_id",
                                "fileId",
                                "file_id",
                                "infoHash",
                                "info_hash",
                            ),
                        )
                        or ""
                    ) == str(task_id):
                        return x
            except Exception:
                pass

    # If resp itself is iterable
    try:
        for x in resp:
            if str(
                _extract_attr(
                    x,
                    (
                        "taskId",
                        "id",
                        "task_id",
                        "fileId",
                        "file_id",
                        "infoHash",
                        "info_hash",
                    ),
                )
                or ""
            ) == str(task_id):
                return x
    except Exception:
        pass

    return None


def _norm_task_info(resp: Any) -> dict[str, Any]:
    """Normalize various task response shapes to a stable dict."""

    if resp is None:
        return {"ok": True, "status": "unknown"}

    raw_status = _extract_attr(resp, ("status", "state", "taskStatus", "task_state", "task_status"))

    status = "unknown"
    if isinstance(raw_status, str):
        s = raw_status.strip().lower()
        if any(k in s for k in ("success", "complete", "completed", "done", "finish", "finished")):
            status = "success"
        elif any(k in s for k in ("fail", "failed", "error")):
            status = "failed"
        elif any(k in s for k in ("run", "downloading", "running", "active")):
            status = "running"
        elif any(k in s for k in ("pend", "wait", "queue")):
            status = "pending"
    elif isinstance(raw_status, (int, float)):
        # Best-effort mapping; different versions differ.
        iv = int(raw_status)
        if iv <= 0:
            status = "pending"
        elif iv == 1:
            status = "running"
        elif iv == 2:
            status = "success"
        elif iv == 3:
            status = "failed"
        elif iv == 4:
            # Some builds define 4 as UNKNOWN; keep polling.
            status = "pending"

    # Progress field names vary a lot across builds.
    # Some versions even have a typo: `percendDone`.
    prog = _extract_attr(
        resp,
        (
            "progress",
            "percent",
            "percentage",
            "rate",
            "percentDone",
            "percent_done",
            "percendDone",
        ),
    )
    progress: int | None = None
    if isinstance(prog, (int, float)):
        fv = float(prog)
        # Some versions use 0-1
        if 0.0 <= fv <= 1.0:
            progress = int(round(fv * 100))
        else:
            progress = int(round(fv))
        progress = max(0, min(progress, 100))

    err = _extract_attr(resp, ("error", "errorMsg", "errorMessage", "err", "message", "msg"))
    error = str(err) if err else ""

    result_paths = _extract_attr(resp, ("resultPaths", "result_paths", "paths", "savePath", "save_path"))

    out: dict[str, Any] = {"ok": True, "status": status}
    if progress is not None:
        out["progress"] = progress
    if error:
        out["error"] = error
    if result_paths is not None:
        out["result_paths"] = result_paths
    return out


class Cd2Client:
    def __init__(self, cfg: Cd2Config):
        self.cfg = cfg
        self._client: Any = None

    def _connect(self) -> None:
        clouddrive = _ensure_dep()
        cfg = self.cfg

        mode = (cfg.mode or "cloudapi").strip().lower() or "cloudapi"
        if mode not in ("cloudapi", "grpc"):
            mode = "cloudapi"

        if mode == "cloudapi":
            if not cfg.base_url:
                raise Cd2Error("未配置 CD2 Base URL（例如 http://127.0.0.1:19798）")
            if not cfg.username or not cfg.password:
                raise Cd2Error("CD2 CloudAPI 模式需要用户名/密码（CloudDrive2 登录账号）")
            self._client = clouddrive.CloudDriveClient(cfg.base_url, cfg.username, cfg.password)
            return

        # grpc mode
        # NOTE: must import both pb2 and pb2_grpc; otherwise NameError at runtime.
        CloudDrive_pb2, CloudDrive_pb2_grpc = _get_pb2()
        try:
            import grpc  # type: ignore
        except Exception as e:
            raise Cd2Error("缺少 grpc 依赖：请安装 grpcio") from e

        addr = (cfg.grpc_addr or "").strip()
        if not addr:
            base = (cfg.base_url or "").strip()
            if "://" in base:
                base = base.split("://", 1)[1]
            addr = base
        addr = addr.strip()
        if "://" in addr:
            addr = addr.split("://", 1)[1]
        addr = addr.split("/", 1)[0].rstrip("/")
        if not addr:
            raise Cd2Error("未配置 CD2 gRPC 地址（例如 127.0.0.1:19798）")

        if not (cfg.token or "").strip():
            raise Cd2Error("CD2 gRPC 模式需要 Token（请在 UI 配置里填写）")

        channel = grpc.insecure_channel(addr)

        # CloudDrive2 protos often expose multiple services (FileSrv, DownloadSrv, ...).
        # Different CD2 versions may place RPCs (e.g. AddOffline*) on different services.
        # To be robust, build *all* available stubs and resolve RPCs dynamically.
        stubs: dict[str, Any] = {}
        for attr in dir(CloudDrive_pb2_grpc):
            if not attr.endswith("Stub"):
                continue
            cls = getattr(CloudDrive_pb2_grpc, attr, None)
            if cls is None:
                continue
            try:
                stubs[attr] = cls(channel)
            except Exception:
                continue

        if not stubs:
            # Fallback to the most common service name.
            stub = CloudDrive_pb2_grpc.CloudDriveFileSrvStub(channel)
            stubs = {"CloudDriveFileSrvStub": stub}

        self._client = (stubs, CloudDrive_pb2, _grpc_metadata(cfg))

    def _ensure(self) -> None:
        if self._client is None:
            self._connect()

    async def _call_rpc(self, rpc_name: str, req: Any | None) -> Any:
        """Call a RPC on either CloudAPI client (async_=True) or gRPC stub."""

        self._ensure()
        mode = (self.cfg.mode or "cloudapi").strip().lower() or "cloudapi"

        if mode == "cloudapi":
            client = self._client
            fn = getattr(client, rpc_name, None)
            if fn is None:
                raise AttributeError(rpc_name)

            try:
                if req is None:
                    return await fn(async_=True)  # type: ignore
                return await fn(req, async_=True)  # type: ignore
            except TypeError:
                # Some versions don't support async_ kw.
                if req is None:
                    return fn()  # type: ignore
                return fn(req)  # type: ignore

        # grpc mode
        stubs, CloudDrive_pb2, md = self._client  # type: ignore[misc]
        fn = None
        for _name, stub in (stubs or {}).items():
            cand = getattr(stub, rpc_name, None)
            if cand is not None:
                fn = cand
                break
        if fn is None:
            raise AttributeError(rpc_name)

        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(
            None,
            lambda: fn(req, metadata=md) if req is not None else fn(metadata=md),
        )

    async def verify(self) -> dict[str, Any]:
        await self.stat("/")
        return {"ok": True}

    async def _find_file_by_path(self, parent_path: str, name: str) -> Any:
        CloudDrive_pb2, _ = _get_pb2()
        Req = getattr(CloudDrive_pb2, "FindFileByPathRequest", None)
        if Req is None:
            raise Cd2Error("CD2 proto 缺少 FindFileByPathRequest")

        req = Req()
        _set_best_effort(req, "parentPath", _norm_path(parent_path))
        _set_best_effort(req, "path", str(name))

        last_err: Exception | None = None
        for rpc in ("FindFileByPath", "FindFileByPath2", "FindFile", "GetFileByPath"):
            try:
                return await self._call_rpc(rpc, req)
            except Exception as e:
                last_err = e
                continue
        raise Cd2Error(f"CD2.FindFileByPath 失败：{last_err}")

    def _file_to_dict(self, obj: Any, full_path: str) -> dict[str, Any]:
        fid = _extract_attr(obj, ("id", "fileId", "file_id", "fid"))
        name = _extract_attr(obj, ("name", "fileName", "filename"))
        is_dir = _extract_attr(obj, ("isDir", "is_dir", "dir"))
        file_type = _extract_attr(obj, ("fileType", "type"))

        # Best-effort determine directory
        is_dir_bool: bool
        if isinstance(is_dir, bool):
            is_dir_bool = is_dir
        elif isinstance(file_type, (int, float)):
            # many protos use 1=folder
            is_dir_bool = int(file_type) == 1
        else:
            is_dir_bool = True if full_path == "/" else False

        return {
            "ok": True,
            "id": str(fid) if fid is not None else "",
            "name": str(name) if name is not None else full_path.rsplit("/", 1)[-1],
            "path": full_path,
            "is_dir": is_dir_bool,
            "raw": obj,
        }

    async def stat(self, path: str) -> dict[str, Any]:
        self._ensure()
        path = _norm_path(path)
        if path == "/":
            # Root always exists.
            return {"ok": True, "id": "", "name": "/", "path": "/", "is_dir": True}

        parts = _split_parts(path)
        parent = "/"
        cur_obj: Any | None = None

        for seg in parts:
            cur_obj = await self._find_file_by_path(parent, seg)
            parent = _norm_path(parent + "/" + seg)

        return self._file_to_dict(cur_obj, path)

    async def _stat_soft(self, path: str) -> Optional[dict[str, Any]]:
        try:
            return await self.stat(path)
        except Exception:
            return None

    async def _mkdir_one(self, full_path: str) -> None:
        """Create one directory (its parent must already exist)."""

        CloudDrive_pb2, _ = _get_pb2()
        Req = getattr(CloudDrive_pb2, "CreateFolderRequest", None)
        if Req is None:
            raise Cd2Error("CD2 proto 缺少 CreateFolderRequest")

        full_path = _norm_path(full_path)
        if full_path in ("", "/"):
            return

        parent, name = full_path.rsplit("/", 1)
        parent = _norm_path(parent or "/")
        name = name.strip()
        if not name:
            return

        req = Req()

        # Runtime-verified fields: parentPath + folderName
        if not _set_best_effort(req, "parentPath", parent):
            _set_best_effort(req, "parent_path", parent)
        if not _set_best_effort(req, "folderName", name):
            _set_best_effort(req, "folder_name", name)

        last_err: Exception | None = None
        for rpc in ("CreateFolder", "CreateFolderByPath", "Mkdir", "MakeDir"):
            try:
                await self._call_rpc(rpc, req)
                return
            except Exception as e:
                last_err = e
                continue

        raise Cd2Error(f"CD2.MKDIR 失败：path={full_path} err={last_err}")

    async def mkdirp(self, path: str) -> None:
        """Ensure directory exists (mkdir -p)."""

        path = _norm_path(path)
        if path in ("", "/"):
            return

        parts = _split_parts(path)
        cur = "/"
        for seg in parts:
            cur = _norm_path(cur + "/" + seg)
            info = await self._stat_soft(cur)
            if info is not None:
                continue
            # create
            await self._mkdir_one(cur)

    async def ensure_dir(self, path: str) -> None:
        if not self.cfg.auto_mkdir:
            return
        await self.mkdirp(path)

    async def add_offline(self, magnet: str, save_path: str, title: str = "") -> dict[str, Any]:
        """Submit a magnet to CD2 offline download.

        Returns: {ok: True, task_id: "..."}
        """

        self._ensure()
        magnet = (magnet or "").strip()
        if not magnet:
            raise Cd2Error("magnet_required")

        save_path = _norm_path(save_path or self.cfg.default_dir or "/")
        if self.cfg.auto_mkdir:
            await self.mkdirp(save_path)

        mode = (self.cfg.mode or "cloudapi").strip().lower() or "cloudapi"

        # CloudAPI mode: python-clouddrive2 exposes offline APIs via helper objects
        # (method names vary across versions). Probe best-effort.
        if mode == "cloudapi":
            resp = await self._add_offline_cloudapi(magnet=magnet, save_path=save_path, title=title)
            return self._build_add_offline_out(resp)

        # gRPC mode: probe RPC and request shapes across CD2 versions.
        CloudDrive_pb2, _ = _get_pb2()

        def build_req(req_cls: Any) -> Any | None:
            try:
                req = req_cls()
            except Exception:
                return None

            # magnets/urls (best-effort)
            url_ok = (
                _set_best_effort(req, "urls", [magnet])
                or _set_best_effort(req, "url", magnet)
                or _set_best_effort(req, "magnet", magnet)
                or _set_best_effort(req, "links", [magnet])
                or _set_best_effort(req, "link", magnet)
                or _set_best_effort(req, "uris", [magnet])
            )

            # Heuristic fallback: any string / repeated-string field whose name looks like url/link/magnet
            if not url_ok:
                try:
                    for f in getattr(req.DESCRIPTOR, "fields", []):  # type: ignore[attr-defined]
                        fn = str(getattr(f, "name", "")).lower()
                        if not fn or not any(k in fn for k in ("url", "uri", "magnet", "link")):
                            continue
                        if getattr(f, "label", None) == f.LABEL_REPEATED:
                            getattr(req, f.name).append(magnet)
                            url_ok = True
                            break
                        if getattr(f, "type", None) == f.TYPE_STRING:
                            setattr(req, f.name, magnet)
                            url_ok = True
                            break
                except Exception:
                    pass

            # save path
            _set_best_effort(req, "savePath", save_path)
            _set_best_effort(req, "save_path", save_path)
            _set_best_effort(req, "path", save_path)
            _set_best_effort(req, "dirPath", save_path)
            _set_best_effort(req, "dir_path", save_path)
            _set_best_effort(req, "folderPath", save_path)
            _set_best_effort(req, "folder_path", save_path)

            # Heuristic fallback: any string field that looks like path/dir/save
            try:
                if not any(
                    hasattr(req, k)
                    for k in ("savePath", "save_path", "path", "dirPath", "dir_path", "folderPath", "folder_path")
                ):
                    for f in getattr(req.DESCRIPTOR, "fields", []):  # type: ignore[attr-defined]
                        fn = str(getattr(f, "name", "")).lower()
                        if not fn or not any(k in fn for k in ("path", "dir", "save", "folder")):
                            continue
                        if getattr(f, "type", None) == f.TYPE_STRING:
                            setattr(req, f.name, save_path)
                            break
            except Exception:
                pass

            # title/name
            if title:
                _set_best_effort(req, "title", title)
                _set_best_effort(req, "name", title)
                _set_best_effort(req, "displayName", title)
                _set_best_effort(req, "display_name", title)

            # If we couldn't set *any* URL field, the request is probably incompatible.
            return req if url_ok else None

        # 1) Collect request class candidates
        req_classes: list[Any] = []
        for cls_name in ("AddOfflineFilesRequest", "AddOfflineFileRequest", "AddOfflineRequest"):
            cls = getattr(CloudDrive_pb2, cls_name, None)
            if cls is not None:
                req_classes.append(cls)

        for name in dir(CloudDrive_pb2):
            if not name.endswith("Request"):
                continue
            ln = name.lower()
            if "offline" not in ln and "magnet" not in ln:
                continue
            if not any(k in ln for k in ("add", "create", "submit", "download", "task")):
                continue
            cls = getattr(CloudDrive_pb2, name, None)
            if cls is None or cls in req_classes:
                continue
            # protobuf message classes have DESCRIPTOR
            if getattr(cls, "DESCRIPTOR", None) is None:
                continue
            req_classes.append(cls)

        # 2) Collect RPC candidates across *all* stubs
        # Explicit common names first
        rpc_candidates: list[str] = ["AddOfflineFiles", "AddOfflineFile", "AddOffline"]

        # Dynamic discovery from the actual stubs we created in _connect
        dyn_rpcs: set[str] = set()
        try:
            stubs, _, _ = self._client  # type: ignore[misc]
            for _stub_name, stub in (stubs or {}).items():
                for m in _iter_public_callables(stub):
                    lm = m.lower()
                    if "offline" in lm and any(k in lm for k in ("add", "create", "submit", "new")):
                        dyn_rpcs.add(m)
        except Exception:
            pass

        # Prefer deterministic order
        for m in sorted(dyn_rpcs):
            if m not in rpc_candidates:
                rpc_candidates.append(m)

        last_err: Exception | None = None
        last_rpc: str | None = None
        last_req: str | None = None

        # Prefer the last *meaningful* error for reporting (AttributeError is often
        # just from a non-existent RPC name we probed).
        last_meaningful_err: Exception | None = None
        last_meaningful_rpc: str | None = None
        last_meaningful_req: str | None = None

        # Try each RPC with each plausible request type
        for rpc in rpc_candidates:
            for req_cls in req_classes:
                req = build_req(req_cls)
                if req is None:
                    continue
                try:
                    resp = await self._call_rpc(rpc, req)

                    # Some CD2 gRPC builds return a FileOperationResult-like response
                    # (success/errorMessage/resultFilePaths) that does NOT include a
                    # taskId. In that case, fall back to magnet BTIH as task_id
                    # (it matches OfflineFile.infoHash in later list queries).
                    try:
                        return self._build_add_offline_out(resp)
                    except Cd2Error as e_out:
                        if str(e_out) == "cd2_missing_task_id":
                            btih = _extract_btih(magnet)
                            if btih and _resp_is_success(resp):
                                return {
                                    "ok": True,
                                    "task_id": btih,
                                    "derived": "btih",
                                    "rpc": rpc,
                                }
                        raise

                except Exception as e:
                    last_err = e
                    last_rpc = rpc
                    last_req = getattr(req_cls, "__name__", str(req_cls))

                    if not isinstance(e, AttributeError):
                        last_meaningful_err = e
                        last_meaningful_rpc = rpc
                        last_meaningful_req = last_req
                    continue

        # If we get here, we couldn't find any compatible combo.
        # Provide actionable debug info (which RPCs exist on stubs).
        existing_offline_rpcs: list[str] = []
        try:
            stubs, _, _ = self._client  # type: ignore[misc]
            for _stub_name, stub in (stubs or {}).items():
                for m in _iter_public_callables(stub):
                    if "offline" in m.lower() or "download" in m.lower():
                        existing_offline_rpcs.append(m)
        except Exception:
            pass

        existing_offline_rpcs = sorted(set(existing_offline_rpcs))
        hint = ""
        if existing_offline_rpcs:
            hint = f"; available_rpc~={existing_offline_rpcs[:25]}"

        err = last_meaningful_err or last_err
        rpc = last_meaningful_rpc or last_rpc
        req = last_meaningful_req or last_req

        raise Cd2Error(
            f"CD2.ADD_OFFLINE 失败：last={err!r} rpc={rpc} req={req}{hint}"
        )

    def _build_add_offline_out(self, resp: Any) -> dict[str, Any]:
        """Normalize add_offline response to {ok, task_id, ...}."""

        task_id = _extract_attr(
            resp,
            (
                "taskId",
                "taskID",
                "task_id",
                "downloadTaskId",
                "downloadTaskID",
                "download_task_id",
                "id",
                # some builds expose offline file identifiers
                "fileId",
                "file_id",
                "infoHash",
                "info_hash",
            ),
        )
        if task_id is None:
            nested = _extract_attr(resp, ("task", "data"))
            if nested is not None:
                task_id = _extract_attr(
                    nested,
                    (
                        "taskId",
                        "taskID",
                        "task_id",
                        "downloadTaskId",
                        "download_task_id",
                        "id",
                        "fileId",
                        "file_id",
                        "infoHash",
                        "info_hash",
                    ),
                )
        if task_id is None:
            # list response
            for k in ("taskIds", "task_ids", "ids"):
                v = _extract_attr(resp, (k,))
                if isinstance(v, (list, tuple)) and v:
                    task_id = v[0]
                    break
        if task_id is None:
            found = _find_in_list(resp, "")
            if found is not None:
                task_id = _extract_attr(
                    found,
                    (
                        "taskId",
                        "id",
                        "task_id",
                        "fileId",
                        "file_id",
                        "infoHash",
                        "info_hash",
                    ),
                )

        task_id_str = str(task_id or "").strip()
        if not task_id_str:
            raise Cd2Error("cd2_missing_task_id")

        out: dict[str, Any] = {"ok": True, "task_id": task_id_str}
        for k in ("message", "msg", "status"):
            if hasattr(resp, k):
                out[k] = getattr(resp, k)
        return out

    async def _add_offline_cloudapi(self, magnet: str, save_path: str, title: str) -> Any:
        """Best-effort CloudAPI add-offline across python-clouddrive2 versions."""

        self._ensure()
        cli = self._client

        # candidate objects that may host offline APIs
        objs: list[tuple[str, Any]] = [("client", cli)]
        for name in ("offline", "download", "download_task", "download_tasklist", "tasklist", "downloads"):
            obj = getattr(cli, name, None)
            if obj is not None:
                objs.append((name, obj))

        def iter_candidates() -> list[tuple[str, Any]]:
            out: list[tuple[str, Any]] = []
            for prefix, obj in objs:
                for n in (
                    "add_offline",
                    "add_offline_files",
                    "add_offline_file",
                    "add_offline_task",
                    "addOffline",
                    "AddOffline",
                    "submit_offline",
                    "create_offline",
                    "add",
                    "create",
                    "submit",
                ):
                    fn = getattr(obj, n, None)
                    if callable(fn):
                        out.append((f"{prefix}.{n}", fn))

                for n in dir(obj):
                    ln = n.lower()
                    if "offline" in ln and ("add" in ln or "create" in ln or "submit" in ln):
                        fn = getattr(obj, n, None)
                        if callable(fn):
                            out.append((f"{prefix}.{n}", fn))

            seen = set()
            uniq: list[tuple[str, Any]] = []
            for label, fn in out:
                if id(fn) in seen:
                    continue
                seen.add(id(fn))
                uniq.append((label, fn))
            return uniq

        async def call_best_effort(label: str, fn: Any) -> Any:
            req = {"urls": [magnet], "savePath": save_path}
            if title:
                req["title"] = title

            for args, kwargs in (
                ((req,), {"async_": True}),
                ((req,), {}),
            ):
                try:
                    return await fn(*args, **kwargs)  # type: ignore[misc]
                except TypeError:
                    pass

            kw_variants = [
                {"urls": [magnet], "savePath": save_path, "title": title},
                {"url": magnet, "savePath": save_path, "title": title},
                {"magnet": magnet, "save_path": save_path, "title": title},
                {"link": magnet, "path": save_path, "title": title},
                {"links": [magnet], "dirPath": save_path, "title": title},
            ]
            for kw in kw_variants:
                kw = {k: v for k, v in kw.items() if v}
                for kwargs in ({"async_": True, **kw}, kw):
                    try:
                        return await fn(**kwargs)  # type: ignore[misc]
                    except TypeError:
                        continue

            pos_variants = [
                (magnet, save_path, title),
                (magnet, save_path),
                (magnet,),
            ]
            for args in pos_variants:
                for kwargs in ({"async_": True}, {}):
                    try:
                        return await fn(*args, **kwargs)  # type: ignore[misc]
                    except TypeError:
                        continue

            raise TypeError(f"no_compatible_signature:{label}")

        last_err: Exception | None = None
        last_label: str | None = None

        for label, fn in iter_candidates():
            try:
                return await call_best_effort(label, fn)
            except Exception as e:
                last_err = e
                last_label = label
                continue

        if last_err is not None:
            raise Cd2Error(f"CD2 cloudapi AddOffline 失败({last_label})：{last_err!r}")
        raise Cd2Error("CD2 cloudapi 未找到可用的 AddOffline 接口（请改用 grpc 模式或升级 python-clouddrive2）")
    async def get_download_task(self, task_id: str) -> dict[str, Any]:
        """Get task status for polling."""

        self._ensure()
        tid = str(task_id or "").strip()
        if not tid:
            raise Cd2Error("task_id_required")

        # Preferred: python-clouddrive2 high-level helper (cloudapi)
        if (self.cfg.mode or "cloudapi").strip().lower() == "cloudapi":
            cli = self._client
            try:
                dl = getattr(cli, "download_tasklist", None)
                if dl is not None:
                    for name in ("get", "get_task", "task", "query", "find"):
                        fn = getattr(dl, name, None)
                        if fn is None:
                            continue
                        try:
                            resp = await fn(tid, async_=True)  # type: ignore
                        except TypeError:
                            resp = await fn(task_id=tid, async_=True)  # type: ignore
                        return _norm_task_info(resp)

                    # list & filter
                    for name in ("list", "list_all", "all", "iter"):
                        fn = getattr(dl, name, None)
                        if fn is None:
                            continue
                        try:
                            resp = await fn(async_=True)  # type: ignore
                        except TypeError:
                            resp = await fn()  # type: ignore
                        found = _find_in_list(resp, tid)
                        if found is not None:
                            return _norm_task_info(found)
            except Exception as e:
                log.warning("CD2 download_tasklist probe failed: %s", e)

        # Fallback: proto RPCs (best-effort)
        return await self._get_task_via_proto(tid)

    async def _get_task_via_proto(self, task_id: str) -> dict[str, Any]:
        CloudDrive_pb2, _ = _get_pb2()

        # request candidates
        req = None
        for cls_name in (
            "GetTaskRequest",
            "QueryTaskRequest",
            "GetDownloadTaskRequest",
            "GetOfflineTaskRequest",
        ):
            cls = getattr(CloudDrive_pb2, cls_name, None)
            if cls is None:
                continue
            r = cls()
            # best-effort set id
            if not (
                _set_best_effort(r, "taskId", str(task_id))
                or _set_best_effort(r, "id", str(task_id))
                or _set_best_effort(r, "task_id", str(task_id))
            ):
                continue
            req = r
            break

        if req is None:
            # generic empty request
            req = getattr(CloudDrive_pb2, "Empty", None)
            req = req() if req is not None else None

        last_err: Exception | None = None

        # direct single-task RPCs
        for rpc in (
            "GetDownloadTask",
            "GetOfflineTask",
            "QueryTask",
            "GetTask",
            "GetDownloadTasks",
            "ListDownloadTasks",
            "ListTasks",
        ):
            try:
                resp = await self._call_rpc(rpc, req)
                found = _find_in_list(resp, str(task_id))
                return _norm_task_info(found if found is not None else resp)
            except Exception as e:
                last_err = e
                continue

        # Sometimes task list RPCs require other request types; try to discover signatures by name.
        for rpc in ("ListAllOfflineFiles", "GetDownloadFileList", "ListOfflineFilesByPath"):
            try:
                # Try to call without params first
                try:
                    resp = await self._call_rpc(rpc, None)
                except Exception:
                    resp = await self._call_rpc(rpc, req)
                found = _find_in_list(resp, str(task_id))
                return _norm_task_info(found if found is not None else resp)
            except Exception as e:
                last_err = e
                continue

        # Newer gRPC builds (and some forks) expose offline tasks via OfflineFileListAll.
        # That request typically uses cloudName/cloudAccountId/page.
        cls = getattr(CloudDrive_pb2, "OfflineFileListAllRequest", None)
        if cls is not None:
            r = cls()
            # best-effort fill (some servers accept empty + default account)
            _set_best_effort(r, "cloudName", (self.cfg.cloud_name or ""))
            _set_best_effort(r, "cloudAccountId", (self.cfg.cloud_account_id or ""))
            _set_best_effort(r, "page", 1)
            for rpc in ("OfflineFileListAll", "OfflineFileList", "OfflineFileListAllV2"):
                try:
                    resp = await self._call_rpc(rpc, r)
                    found = _find_in_list(resp, str(task_id))
                    return _norm_task_info(found if found is not None else resp)
                except Exception as e:
                    last_err = e
                    continue

        hint = ""
        if cls is not None and (not (self.cfg.cloud_name or "").strip() or not (self.cfg.cloud_account_id or "").strip()):
            hint = "（提示：该 CD2 gRPC 版本可能需要配置 cloud_name / cloud_account_id 才能查询离线任务）"
        raise Cd2Error(f"无法通过 CD2 RPC 查询任务：task_id={task_id} err={last_err} {hint}")
