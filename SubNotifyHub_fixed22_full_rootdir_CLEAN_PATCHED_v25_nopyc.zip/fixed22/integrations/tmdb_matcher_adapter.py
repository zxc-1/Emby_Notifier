from __future__ import annotations

"""Adapter exposing :mod:`integrations.tmdb_match` as :class:`ports.tmdb_matcher.TmdbMatcher`."""

import logging
from core.logging import get_biz_logger_adapter
from typing import Any, Dict, Optional, Pattern, Sequence

from ports.tmdb_matcher import CandidateLike, TmdbMatcher

logger = get_biz_logger_adapter(__name__)


class DefaultTmdbMatcher(TmdbMatcher):
    def __init__(self) -> None:
        # Keep module import lazy to reduce import-time side effects.
        import integrations.tmdb_match as tm

        self._tm = tm

    # Pattern
    @property
    def IMDB_ID_RE(self) -> Pattern[str]:
        return self._tm.IMDB_ID_RE  # type: ignore[return-value]

    # Pure-ish helpers (delegate)
    def normalize_title(self, title: str) -> str:
        return self._tm.normalize_title(title)

    def parse_title_year_from_filename(self, name: str) -> tuple[str, Optional[int]]:
        return self._tm.parse_title_year_from_filename(name)

    def detect_tv_hint(self, name: str) -> Optional[int]:
        return self._tm.detect_tv_hint(name)

    def extract_imdb_id_from_text(self, text: str) -> Optional[str]:
        return self._tm.extract_imdb_id_from_text(text)

    def extract_tmdb_id_from_text(self, text: str) -> Optional[int]:
        return self._tm.extract_tmdb_id_from_text(text)

    def make_title_fingerprint(self, title: str, year: Optional[int], media_type: str, season: Optional[int]) -> str:
        return self._tm.make_title_fingerprint(title, year, media_type, season)

    def make_series_fingerprints(self, title: str, year: Optional[int] = None) -> Sequence[str]:
        return self._tm.make_series_fingerprints(title, year)

    def score_candidate(self, query_title: str, query_year: Optional[int], cand: CandidateLike) -> float:
        return self._tm.score_candidate(query_title, query_year, cand)

    def score_candidate_meta(
        self,
        query_title: str,
        query_year: Optional[int],
        cand: CandidateLike,
        *,
        idf: Optional[Dict[str, float]] = None,
    ) -> tuple[float, float, str]:
        return self._tm.score_candidate_meta(query_title, query_year, cand, idf=idf)

    def should_auto_pick(self, scores: list[tuple[CandidateLike, float]], *, ctx: Optional[Dict[str, Any]] = None) -> bool:
        return self._tm.should_auto_pick(scores, ctx=ctx)

    # I/O helpers (delegate)
    async def fetch_tmdb_detail(
        self,
        tmdb_id: int,
        *,
        prefer_media_type: Optional[str] = None,
        language: Optional[str] = None,
        region: Optional[str] = None,
    ) -> dict[str, Any] | None:
        return await self._tm.fetch_tmdb_detail(
            int(tmdb_id),
            prefer_media_type=prefer_media_type,
            language=language,
            region=region,
        )

    async def fetch_tv_season_episode_count(
        self,
        tv_id: int,
        season_number: int,
        *,
        language: Optional[str] = None,
        region: Optional[str] = None,
    ) -> Optional[int]:
        fn = getattr(self._tm, "fetch_tv_season_episode_count", None)
        if not callable(fn):
            return None
        v = await fn(int(tv_id), int(season_number), language=language, region=region)
        try:
            return int(v) if v not in (None, "") else None
        except Exception:
            return None

    async def find_by_external_id(self, external_id: str, *, external_source: str = "imdb_id") -> list[CandidateLike]:
        res = await self._tm.find_by_external_id(str(external_id), external_source=str(external_source or "imdb_id"))
        return list(res or [])

    async def guess_tmdb_from_filename(
        self,
        name: str,
        *,
        force_media_type: Optional[str] = None,
        mode: str = "full",
    ) -> Dict[str, Any]:
        return await self._tm.guess_tmdb_from_filename(
            str(name or ""),
            force_media_type=str(force_media_type).strip().lower() if force_media_type else None,
            mode=str(mode or "full"),
        )
