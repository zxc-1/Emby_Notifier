"""ASGI app entrypoint (worker role).

In worker-only role the app exposes only minimal HTTP routes by default.
"""

from core.bootstrap import create_app


app = create_app()
