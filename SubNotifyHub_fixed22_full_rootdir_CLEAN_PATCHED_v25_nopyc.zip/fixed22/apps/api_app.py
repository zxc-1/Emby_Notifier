"""ASGI app entrypoint (API role).

Typical usage (uvicorn):

    uvicorn apps.api_app:app

This does not force APP_ROLE; it just documents intent.
"""

from core.bootstrap import create_app


app = create_app()
