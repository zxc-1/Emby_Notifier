"""ASGI app entrypoint (legacy all-in-one).

This is functionally identical to :mod:`app`, but provides a clearer import
path when using explicit entrypoints.
"""

from core.bootstrap import create_app


app = create_app()
