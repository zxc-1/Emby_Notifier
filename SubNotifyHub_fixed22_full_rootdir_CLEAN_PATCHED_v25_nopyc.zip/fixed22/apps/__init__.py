"""Explicit app entrypoints.

These modules provide clear, stable import paths for different deployment modes.

They are optional conveniences; the project still supports legacy `app.py`.
"""
