"""
Emby Notifier 1.3.0

核心职责：
- 接收 Emby Webhook
- 收集 / 合并各种元数据（Emby / NFO / Mediainfo / TMDB）
- 渲染消息模板
- 通过 Telegram 等通道推送通知
"""