from __future__ import annotations

"""Backward-compatible shim.

Canonical implementation lives under :mod:`core.metrics`.
"""

from core.metrics import *  # noqa: F401,F403
