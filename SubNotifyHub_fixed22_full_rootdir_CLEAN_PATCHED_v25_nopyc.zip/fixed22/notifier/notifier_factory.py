from __future__ import annotations

from core.exceptions.base import ValidationError

from typing import Optional

from core.task_registry import TaskRegistry
from .notifiers.base import DummyNotifier, Notifier
from .notifiers.aggregator import AggregatingNotifier
from .notifiers.composite import CompositeNotifier
from .notifiers.registry import (
    NotifierRegistry,
    default_registry,
    register_builtins,
    create as create_notifier,
    is_registered,
    list_registered,
)


def _parse_notifier_types(settings) -> list[str]:
    raw = getattr(settings, "NOTIFIER_TYPES", "") or ""
    s = str(raw).strip()
    if not s:
        return []
    out: list[str] = []
    for part in s.split(","):
        k = str(part or "").strip().lower()
        if k:
            out.append(k)
    # De-dup while preserving order
    seen = set()
    uniq: list[str] = []
    for k in out:
        if k in seen:
            continue
        seen.add(k)
        uniq.append(k)
    return uniq


def build_base_notifier(settings, *, registry: NotifierRegistry | None = None) -> Notifier:
    """Build the leaf (or composite) notifier based on settings.

    Backward compatible:
      - NOTIFIER_TYPES empty: Telegram (or Dummy when DRY_RUN)
      - NOTIFIER_TYPES set: build composite from registry
    """
    reg = registry or default_registry
    # Ensure built-in channels are registered without relying on random import order.
    register_builtins(reg)

    if getattr(settings, "NOTIFIER_DRY_RUN", False):
        return DummyNotifier()

    types = _parse_notifier_types(settings)
    if not types:
        # Default channel (backward compatible): telegram
        return reg.create("telegram", settings)

    # Build composite from registry
    strict = getattr(settings, "NOTIFIER_STRICT", None)
    if strict is None:
        strict = bool(getattr(settings, "CONFIG_STRICT", True))

    leaves: list[Notifier] = []
    for t in types:
        if strict and not reg.is_registered(t):
            raise ValidationError(
                f"NOTIFIER_TYPES contains unknown notifier '{t}'. available={','.join(reg.list_registered())}"
            )
        leaves.append(reg.create(t, settings))

    if len(leaves) == 1:
        return leaves[0]
    return CompositeNotifier(
        leaves,
        parallel=bool(getattr(settings, "NOTIFIER_SEND_PARALLEL", False)),
        require_all=bool(getattr(settings, "NOTIFIER_SEND_REQUIRE_ALL", True)),
        timeout_sec=float(getattr(settings, "NOTIFIER_CHANNEL_TIMEOUT_SEC", 15.0) or 0.0),
    )


def build_notifier(settings, downstream: Optional[Notifier] = None, task_registry: TaskRegistry | None = None, *, registry: NotifierRegistry | None = None) -> Notifier:
    """Build full notifier chain.

    If *downstream* is provided, it will be used as the base notifier (e.g. HookedNotifier).
    """
    base = downstream or build_base_notifier(settings, registry=registry)
    window = float(getattr(settings, "NOTIFIER_AGGREGATE_WINDOW", 0.0) or 0.0)
    if window > 0:
        return AggregatingNotifier(base, task_registry=task_registry)
    return base
