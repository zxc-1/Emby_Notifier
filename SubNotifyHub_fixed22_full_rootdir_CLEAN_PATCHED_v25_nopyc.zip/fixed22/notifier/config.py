from __future__ import annotations

"""Backward-compatible settings access.

.. deprecated::
    This module is deprecated. Use ``settings.runtime`` instead:
    ``from settings.runtime import get_settings, reload_settings``

Historically, many modules imported :func:`get_settings` from ``notifier.config``.
Settings has been moved to the top-level :mod:`settings` package to avoid layer
inversions (e.g. ``core`` importing from notifier).

Please prefer:
  - ``from settings.runtime import get_settings, reload_settings``
  - ``from settings.all import Settings``
"""

import warnings

warnings.warn(
    "notifier.config is deprecated; "
    "use settings.runtime.get_settings() instead",
    DeprecationWarning,
    stacklevel=2,
)

from settings.all import Settings  # noqa: F401
from settings.runtime import get_settings, reload_settings, set_settings  # noqa: F401
