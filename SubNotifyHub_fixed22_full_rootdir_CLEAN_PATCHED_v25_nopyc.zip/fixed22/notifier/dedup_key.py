from __future__ import annotations

"""Dedup key builders.

This module centralizes "enqueue dedup" signature calculation so webhook,
worker, and direct notification flows share exactly the same semantics.

Keeping this as a small, mostly-pure helper makes it easy to unit test and
reduces drift caused by copy/paste changes.
"""

from core.dedup_key import compute_enqueue_dedup

__all__ = ["compute_enqueue_dedup"]
