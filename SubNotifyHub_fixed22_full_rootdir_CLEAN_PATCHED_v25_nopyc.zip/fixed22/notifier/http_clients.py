from __future__ import annotations

"""Compatibility wrapper.

Historically this project exposed a shared AsyncClient from notifier.http_clients.
The shared client is now implemented in core.http_clients so tg_bot/core/notifier
can all reuse the same pool.
"""

from core.http import close_http_client, create_http_client, get_http_client

__all__ = ["create_http_client", "get_http_client", "close_http_client"]
