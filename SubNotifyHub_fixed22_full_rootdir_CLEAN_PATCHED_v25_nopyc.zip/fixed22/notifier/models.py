from __future__ import annotations

"""Backward-compatible shim.

Canonical domain models live under :mod:`domain.models`.

This module re-exports them to avoid breaking existing imports.
"""

from domain.models import *  # noqa: F403
