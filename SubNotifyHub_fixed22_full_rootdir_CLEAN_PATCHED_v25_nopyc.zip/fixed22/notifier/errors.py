from __future__ import annotations

from core.logging import get_biz_logger
biz = get_biz_logger(__name__)

import json
from typing import Literal

from ports.http_client import HttpRequestError, HttpStatusError, HttpTimeoutError



ErrorCategory = Literal["network", "parse", "io", "unknown"]


class RetryableNotifyError(RuntimeError):
    """A transient error that should be retried by the worker.

    Integrations can attach a `retry_after` (seconds) hint when the upstream
    explicitly tells us when to retry (e.g. Telegram 429 parameters.retry_after).

    The worker will honor this hint by taking the max(retry_after, backoff).
    """

    def __init__(self, message: str, *, retry_after: float | None = None) -> None:
        super().__init__(message)
        self.retry_after: float | None = None
        if retry_after is not None:
            try:
                ra = float(retry_after)
                if ra < 0:
                    ra = 0.0
                self.retry_after = ra
            except (ValueError, TypeError):
                biz.detail(
                    "ℹ️ [重试延迟参数转换]失败：无法将 retry_after 参数转换为浮点数。"
                    "可能原因：传入了非数字字符串、None 值、或其他无效类型。"
                    "影响：将忽略服务器建议的重试时间，使用默认退避策略",
                    raw=repr(retry_after)
                )



def categorize_exc(exc: BaseException) -> ErrorCategory:
    """Classify exceptions into coarse categories for consistent logging."""
    if isinstance(exc, RetryableNotifyError):
        return "network"
    if isinstance(exc, (HttpTimeoutError, HttpRequestError)):
        return "network"
    # httpx: treat certain status errors as transient
    if isinstance(exc, HttpStatusError):
        try:
            status = int(getattr(exc, "status_code", 0) or 0)
            if status == 429 or (500 <= status <= 599):
                return "network"
        except (ValueError, AttributeError):
            biz.detail(
                "ℹ️ [HTTP 状态码解析]失败：无法从异常对象中提取 HTTP 状态码。"
                "可能原因：异常对象缺少 status_code 属性、或类型转换失败。"
                "影响：无法判断是否为可重试的网络错误，将归类为 unknown",
                exc_type=type(exc).__name__
            )
    if isinstance(exc, (json.JSONDecodeError, ValueError)):
        return "parse"
    if isinstance(exc, OSError):
        return "io"
    return "unknown"
