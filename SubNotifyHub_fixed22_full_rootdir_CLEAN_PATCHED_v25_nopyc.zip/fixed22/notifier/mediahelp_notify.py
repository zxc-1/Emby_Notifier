from __future__ import annotations

import asyncio
import inspect
from core.logging import get_biz_logger
from core.task_registry import create_task_logged
from typing import Any, Callable, Optional

from notifier.mediahelp import MediaHelpNotifyPayload, build_mediahelp_notification
from notifier.models import NotificationContent

biz = get_biz_logger(__name__)

_EnqueueFunc = Callable[[NotificationContent], Any]
_enqueue_func: Optional[_EnqueueFunc] = None


def set_enqueue_func(func: _EnqueueFunc) -> None:
    global _enqueue_func
    _enqueue_func = func


def emit_mediahelp_event(payload: MediaHelpNotifyPayload) -> Optional[NotificationContent]:
    """Format and enqueue a MediaHelp notification (if enqueue is configured)."""
    try:
        content = build_mediahelp_notification(payload)
    except (ValueError, TypeError, AttributeError, KeyError) as e:
        biz.warning("构建 MediaHelp 通知失败", payload_type=type(payload).__name__, reason=type(e).__name__)
        return None

    if _enqueue_func is None:
        return content

    try:
        ret = _enqueue_func(content)
        # The notifier worker's enqueue() is async in newer versions.
        # emit_mediahelp_event is intentionally sync (used by forward bridge),
        # so if enqueue returns a coroutine we schedule it on the running loop.
        if inspect.isawaitable(ret):
            try:
                loop = asyncio.get_running_loop()
                create_task_logged(ret, name="mediahelp_enqueue")  # fire-and-forget (logged)
            except RuntimeError:
                # No running loop (shouldn't happen under FastAPI), best-effort run.
                asyncio.run(ret)
    except (RuntimeError, ValueError, OSError) as e:
        biz.warning("通知入队失败", reason=type(e).__name__)
    return content


__all__ = [
    "MediaHelpNotifyPayload",
    "build_mediahelp_notification",
    "set_enqueue_func",
    "emit_mediahelp_event",
]
