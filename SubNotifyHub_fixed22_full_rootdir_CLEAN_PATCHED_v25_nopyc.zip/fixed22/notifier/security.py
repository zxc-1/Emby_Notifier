from __future__ import annotations

"""Backward-compatible shim.

Canonical implementation lives under :mod:`core.admin_auth`.
"""

from core.admin_auth import *  # noqa: F401,F403
