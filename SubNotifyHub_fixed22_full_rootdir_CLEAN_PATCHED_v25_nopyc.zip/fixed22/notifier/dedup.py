# notifier/dedup.py
from __future__ import annotations
from core.logging import get_biz_logger
biz = get_biz_logger(__name__)


import hashlib
import time
from collections import OrderedDict
from typing import OrderedDict as OrderedDictType

from ports.stores import KVStore, get_kv_store


class Deduper:
    """
    幂等去重（可选持久化）：

    - 默认：内存去重（进程内），重启/多进程不共享
    - 可选：持久化去重（SQLite kv_cache），多进程/多副本更一致

    行为：
    - TTL 内重复出现则返回 True（表示近期见过）
    - 第一次出现返回 False（并写入记录）
    """

    def __init__(
        self,
        ttl_seconds: int = 600,
        max_size: int = 5000,
        *,
        persistent: bool = False,
        key_prefix: str = "dedup:",
        kv_store: KVStore | None = None,
    ) -> None:
        # Semantics:
        #   ttl > 0 : normal dedup within TTL
        #   ttl == 0: disable dedup (treat everything as NOT seen)
        #   ttl < 0 : "infinite" dedup (never expires; bounded by max_size in mem mode)
        self.ttl = int(ttl_seconds)
        self.max_size = int(max_size or 0)
        self.persistent = bool(persistent)
        self.key_prefix = str(key_prefix or "dedup:")

        # Optional injection for tests / future backends.
        self._kv = kv_store

        # In-memory store (only used when persistent=False)
        self._store: OrderedDictType[str, float] = OrderedDict()

    def _hash_key(self, key: str) -> str:
        # Keep DB keys short & safe (avoid huge keys / unicode oddities)
        h = hashlib.sha1(str(key).encode("utf-8", errors="ignore")).hexdigest()
        return f"{self.key_prefix}{h}"

    def _cleanup_mem(self) -> None:
        now = time.time()
        # 删除过期（ttl<=0 时不做过期删除：
        #   ttl==0 已禁用去重，不会写入 _store
        #   ttl<0 视为永不过期）
        to_delete = [k for k, ts in self._store.items() if (self.ttl > 0 and (now - ts) > self.ttl)]
        for k in to_delete:
            self._store.pop(k, None)

        # 控制容量：超过 max_size 时，从最老的开始删
        while self.max_size > 0 and len(self._store) > self.max_size:
            self._store.popitem(last=False)

    def is_duplicate(self, key: str) -> bool:
        """Check whether *key* has been seen recently.

        This method NEVER records/marks the key.
        """
        if not key:
            return False

        # ttl==0 means "disable dedup"
        if self.ttl == 0:
            return False

        now = time.time()

        if self.persistent:
            k = self._hash_key(key)
            try:
                kv = self._kv or get_kv_store()
                v = kv.get_json(k)
                return v is not None
            except (OSError, RuntimeError) as e:
                biz.detail("持久化去重查询失败（已降级到内存模式）", key=key[:50], reason=type(e).__name__)

        ts = self._store.get(key)
        if ts is None:
            return False
        if self.ttl < 0:
            return True
        return (now - ts) <= float(self.ttl)

    def mark(self, key: str) -> None:
        """Record *key* as seen now.

        Used to support "check then enqueue then mark" so that queue-full
        doesn't permanently drop retried events.
        """
        if not key:
            return
        if self.ttl == 0:
            return

        now = time.time()

        if self.persistent:
            k = self._hash_key(key)
            try:
                ttl = None
                if self.ttl > 0:
                    ttl = self.ttl
                # ttl<0 => infinite (no expiry)
                kv = self._kv or get_kv_store()
                kv.set_json(k, 1, ttl_sec=ttl)
                return
            except (OSError, RuntimeError) as e:
                biz.detail("持久化去重写入失败（已降级到内存模式）", key=key[:50], reason=type(e).__name__)

        self._store[key] = now
        self._cleanup_mem()

    def seen_recently(self, key: str) -> bool:
        """Backward-compatible helper.

        True = 在 TTL 内已经见过，应该视为“重复”；
        False = 第一次出现（同时会记录）。

        NOTE: For enqueue reliability, prefer using is_duplicate()+mark() so
        callers can mark only after successful enqueue.
        """
        if self.is_duplicate(key):
            return True
        self.mark(key)
        return False
