from __future__ import annotations

from core.logging import get_biz_logger
from typing import Awaitable, Callable, Optional

from .models import NotificationContent
from .notifiers.base import Notifier

biz = get_biz_logger(__name__)


class HookedNotifier(Notifier):
    """Trigger callback after a successful send (works for aggregated sends too)."""

    def __init__(
        self,
        base: Notifier,
        on_sent: Optional[Callable[[NotificationContent], Awaitable[None]]] = None,
    ) -> None:
        self._base = base
        self._on_sent = on_sent

    async def send(self, content: NotificationContent) -> None:
        await self._base.send(content)
        if self._on_sent:
            try:
                await self._on_sent(content)
            except (RuntimeError, ValueError, TypeError) as e:
                biz.detail("通知发送后回调失败", callback_type=type(self._on_sent).__name__, reason=type(e).__name__)
