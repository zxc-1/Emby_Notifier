from __future__ import annotations

"""Backward-compatible shim.

Canonical implementation lives under :mod:`domain.utils.episode_agg`.
"""

from domain.utils.episode_agg import *  # noqa: F403
