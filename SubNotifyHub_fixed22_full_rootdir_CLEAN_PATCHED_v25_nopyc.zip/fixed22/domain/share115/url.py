from __future__ import annotations

"""115 share URL helpers (pure).

No settings access, no network I/O.

Callers may pass a default host ...
"""
import logging
from core.logging import get_biz_logger_adapter
logger = get_biz_logger_adapter(__name__)


import html
import re
from typing import Optional, Tuple
from urllib.parse import parse_qs, urlparse, unquote


__all__ = [
    "parse_share_url",
    "normalize_share_host",
    "default_share_host",
    "pick_share_host_from_url",
    "build_share_url",
]


def _host_is_allowed_115(host: str) -> bool:
    """Return True when host is exactly a known 115 share host or its subdomain."""
    h = str(host or "").strip().lower()
    if not h:
        return False
    for dom in ("115.com", "115cdn.com", "anxia.com"):
        if h == dom or h.endswith("." + dom):
            return True
    return False


_SHARE_CODE_RE = re.compile(r"/s/([0-9a-zA-Z]+)", re.I)


def parse_share_url(url: str) -> Tuple[Optional[str], Optional[str]]:
    """Parse 115 share url and return (share_code, receive_code/password)."""
    raw = (url or "").strip()
    try:
        raw = html.unescape(raw)
    except (ValueError, TypeError) as e:
        logger.detail(f"HTML 反转义失败（已忽略） - url={url!r}, 原因={type(e).__name__}")
    try:
        trail = '"\'<>[](){}.,;:!?，。！？、”’：；'
        while raw and raw[-1] in trail:
            raw = raw[:-1]
        raw = raw.strip()
    except (IndexError, TypeError) as e:
        logger.detail(f"字符串尾部清理失败（已忽略） - raw={raw!r}, 原因={type(e).__name__}")
    if not raw:
        return None, None

    low0 = raw.lower()
    if low0.startswith("//"):
        raw = "https:" + raw
        low0 = raw.lower()
    if re.match(r"(?i)^(?:[a-z0-9-]+\.)*(?:115\.com|115cdn\.com|anxia\.com)/", low0):
        raw = "https://" + raw

    # Python 3.12+ urlparse 会对 URL 中的方括号进行 IPv6 校验
    # 如果 URL 包含非 IPv6 的方括号（如 [字幕组名]），会抛出 ValueError
    # 快速检测：如果 URL 包含方括号但不是合法的 IPv6 格式，直接返回 None
    if "[" in raw:
        # 合法 IPv6 URL 格式: scheme://[ipv6]:port/path
        # 如果方括号不在 :// 之后紧跟，或者方括号内不是 IPv6 地址，则不是合法 URL
        ipv6_pattern = re.match(r"^[a-z][a-z0-9+.-]*://\[[0-9a-fA-F:]+\]", raw, re.I)
        if not ipv6_pattern:
            logger.detail(f"URL 包含非 IPv6 方括号，跳过解析 - raw={raw!r}")
            return None, None

    try:
        u = urlparse(raw)
    except (ValueError, TypeError) as e:
        logger.detail(f"URL 解析失败 - raw={raw!r}, 原因={type(e).__name__}")
        return None, None

    try:
        host = str(u.netloc or "").strip().lower()
        if host:
            if not _host_is_allowed_115(host):
                return None, None
        else:
            low = raw.lower()
            if low.startswith("/s/"):
                pass
            elif re.match(r"(?i)^(?:https?://|//)?(?:[a-z0-9-]+\.)*(?:115\.com|115cdn\.com|anxia\.com)/", low):
                pass
            else:
                return None, None
    except (AttributeError, TypeError, ValueError) as e:
        logger.detail(f"主机验证失败 - netloc={getattr(u, 'netloc', None)!r}, raw={raw!r}, 原因={type(e).__name__}")
        return None, None

    share_code = None
    try:
        path = unquote(u.path or "")
    except (ValueError, TypeError) as e:
        logger.detail(f"URL 路径解码失败（已忽略） - path={getattr(u, 'path', None)!r}, 原因={type(e).__name__}")
        path = u.path or ""
    m = _SHARE_CODE_RE.search(path)
    if m:
        try:
            share_code = str(m.group(1) or "").strip().lower() or None
        except (IndexError, AttributeError, TypeError) as e:
            logger.detail(f"分享码提取失败（已忽略） - path={path!r}, 原因={type(e).__name__}")
            share_code = m.group(1)

    qs0 = parse_qs(u.query or "")
    qs = {str(k or "").lower(): (v or []) for k, v in (qs0 or {}).items()}
    receive = None
    for k in ("password", "receive_code", "pwd", "code"):
        if k in qs and qs.get(k):
            receive = str((qs.get(k) or [""])[0] or "").strip()
            break

    if not receive:
        frag = (u.fragment or "").strip()
        if frag:
            frag_qs0 = parse_qs(frag) if ("=" in frag or "&" in frag) else {}
            frag_qs = {str(k or "").lower(): (v or []) for k, v in (frag_qs0 or {}).items()}
            for k in ("password", "receive_code", "pwd", "code"):
                if k in frag_qs and frag_qs.get(k):
                    receive = str((frag_qs.get(k) or [""])[0] or "").strip()
                    break
            if not receive and frag and ("=" not in frag) and ("&" not in frag):
                if re.fullmatch(r"[0-9A-Za-z]{3,16}", frag):
                    receive = frag

    return share_code, receive


def default_share_host(configured_default: str | None = None) -> str:
    v = str(configured_default or "").strip().lower()
    if v in ("115.com", "115cdn.com", "anxia.com"):
        return v
    return "115.com"


def normalize_share_host(host: str | None, *, configured_default: str | None = None) -> str:
    h = str(host or "").strip().lower()
    if not h:
        return default_share_host(configured_default)
    h = re.sub(r"^https?://", "", h)
    h = h.split("/", 1)[0]
    h = h.split(":", 1)[0]
    h = h.strip(".")

    for dom in ("115cdn.com", "115.com", "anxia.com"):
        if h == dom or h.endswith("." + dom):
            return dom
    return default_share_host(configured_default)


def pick_share_host_from_url(url: str, *, configured_default: str | None = None) -> str:
    raw = str(url or "").strip()
    if not raw:
        return default_share_host(configured_default)
    try:
        raw = html.unescape(raw)
    except (ValueError, TypeError) as e:
        logger.detail(f"HTML 反转义失败（已忽略） - url={url!r}, 原因={type(e).__name__}")
    low0 = raw.lower()
    if low0.startswith("//"):
        raw2 = "https:" + raw
    elif re.match(r"(?i)^(?:[a-z0-9-]+\.)*(?:115\.com|115cdn\.com|anxia\.com)/", low0):
        raw2 = "https://" + raw
    else:
        raw2 = raw
    # Python 3.12+ urlparse 会对方括号进行 IPv6 校验
    if "[" in raw2:
        ipv6_pattern = re.match(r"^[a-z][a-z0-9+.-]*://\[[0-9a-fA-F:]+\]", raw2, re.I)
        if not ipv6_pattern:
            return default_share_host(configured_default)
    try:
        u = urlparse(raw2)
        return normalize_share_host(u.hostname or "", configured_default=configured_default)
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"URL 解析失败（已忽略） - raw2={raw2!r}, 原因={type(e).__name__}")
        return default_share_host(configured_default)


def build_share_url(share_code: str, receive_code: str | None = None, base_host: str | None = None, *, configured_default: str | None = None) -> str:
    sc = str(share_code or "").strip()
    if not sc:
        return ""

    host = normalize_share_host(base_host, configured_default=configured_default) if base_host else default_share_host(configured_default)
    pwd = str(receive_code or "").strip() or None
    if pwd:
        return f"https://{host}/s/{sc}?password={pwd}"
    return f"https://{host}/s/{sc}"
