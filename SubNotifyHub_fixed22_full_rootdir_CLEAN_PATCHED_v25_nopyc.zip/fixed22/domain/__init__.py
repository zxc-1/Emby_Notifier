"""Domain layer.

The *domain* package hosts the stable, internal data model used across:
- webhook ingestion
- pipeline enrichment
- notifier dispatch

Goal: reduce cross-layer dict coupling and make future integrations/plugins easy.
"""
