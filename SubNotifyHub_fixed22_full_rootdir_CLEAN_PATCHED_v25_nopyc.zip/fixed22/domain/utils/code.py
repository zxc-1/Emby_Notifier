from __future__ import annotations

"""Media code helpers (pure).

This module hosts utilities that were historically located in notifier.utils.
They are pure and safe to import from any layer.

Robustness: callers sometimes pass non-string objects by mistake. We coerce
inputs to string to avoid UI/API crashes.
"""

import re
from typing import Optional, Any

# 番号提取：ABP-123 / ABP123 / FC2-PPV-1234567 / FC2PPV1234567 等
CODE_PATTERN = re.compile(r"(?i)(?<![A-Za-z0-9])([A-Za-z]{2,6}[0-9]{0,2})[-_]?(\d{3,7})(?!\d)")


def extract_code(path_or_name: Any) -> Optional[str]:
    """从路径或文件名中提取番号，如 ABP-123 / ABP123。

    Accepts any object; best-effort coerces to string.
    """
    if path_or_name is None:
        return None

    try:
        s = path_or_name if isinstance(path_or_name, str) else str(path_or_name)
    except Exception:
        return None

    s = s.strip()
    if not s:
        return None

    try:
        m = CODE_PATTERN.search(s)
    except Exception:
        return None

    if not m:
        return None
    prefix, digits = m.groups()
    return f"{prefix.upper()}-{digits}"
