"""Domain-level pure utilities.

These helpers are safe to import from any layer (domain/application/core/etc.)
and intentionally avoid importing infrastructure or feature-layer modules.
"""
