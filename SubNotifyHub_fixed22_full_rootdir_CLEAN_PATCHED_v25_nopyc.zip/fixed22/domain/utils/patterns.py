from __future__ import annotations

"""Stable regex patterns shared across layers.

Keep pure regexes here so application/integrations can depend on them without
importing tg_bot.
"""

import re

TMDB_EXPLICIT_RE = re.compile(
    r"(?ix)(?<![0-9A-Za-z])(?:tmdbid|tmdb_id|tmdb)\s*[:=_-]?\s*(\d{1,9})(?![0-9A-Za-z])"
)
