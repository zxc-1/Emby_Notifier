from __future__ import annotations

import logging
from core.logging import get_biz_logger_adapter
logger = get_biz_logger_adapter(__name__)

from typing import Iterable, List, Optional, Tuple


def _is_continuous(nums: List[int]) -> bool:
    if not nums:
        return False
    return nums[-1] - nums[0] + 1 == len(nums)


def format_episode_keys(ep_keys: Iterable[Tuple[int, int]]) -> Optional[str]:
    keys: List[Tuple[int, int]] = []
    for s, e in ep_keys:
        try:
            keys.append((int(s), int(e)))
        except (ValueError, TypeError) as e_exc:
            logger.detail(f"剧集键解析失败（已跳过） - 季数={s!r}, 集数={e!r}, 原因={type(e_exc).__name__}")
            continue

    if not keys:
        return None

    keys = sorted(set(keys), key=lambda x: (x[0], x[1]))
    seasons = sorted({s for s, _ in keys})

    if len(seasons) == 1:
        s = seasons[0]
        eps = sorted({e for _, e in keys})
        if len(eps) == 1:
            return f"S{s:02d}E{eps[0]:02d}"
        if _is_continuous(eps):
            return f"S{s:02d}E{eps[0]:02d}-S{s:02d}E{eps[-1]:02d}"
        # Discontinuous: S01E11/S01E15/S01E16 (no spaces)
        return "/".join(f"S{s:02d}E{e:02d}" for e in eps)

    # Multi-season: keep explicit pairs, no spaces
    return "/".join(f"S{s:02d}E{e:02d}" for s, e in keys)
