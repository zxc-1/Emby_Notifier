from __future__ import annotations

"""Domain-layer error types.

Domain errors represent violated business rules or invalid domain state.
They should not depend on infrastructure or FastAPI specifics.
"""


class DomainError(Exception):
    """Base class for domain errors."""


class ValidationError(DomainError):
    """The input violates domain rules."""


class NotFoundError(DomainError):
    """Entity not found."""


class ConflictError(DomainError):
    """Operation conflicts with existing state."""
