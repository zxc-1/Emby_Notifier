from __future__ import annotations

"""Domain-level event models.

These models define stable, typed contracts used across the app:

- **SourceEvent**: raw inbound event + extracted envelope fields.
- **MetaContext/EnrichedContext/...**: pipeline contexts (moved out of notifier.service.pipeline).
- **NotificationJob**: NotificationContent plus optional provenance.

Goal: reduce cross-layer dict coupling and make future integrations/plugins easier.
"""
import logging
from core.logging import get_biz_logger_adapter
logger = get_biz_logger_adapter(__name__)


from datetime import datetime, timezone
from typing import Any, Dict, Optional

from pydantic import BaseModel, ConfigDict, Field

from domain.models import EmbyItem, LocalMeta, MediaInfo, NfoMeta, NotificationContent, TmdbMeta


class SourceEvent(BaseModel):
    """Normalized envelope for inbound events (currently Emby webhook)."""

    model_config = ConfigDict(extra="allow")

    source: str = "emby"
    received_at: datetime = Field(default_factory=lambda: datetime.now(timezone.utc))
    raw: Dict[str, Any] = Field(default_factory=dict)

    event: Optional[str] = None
    library_name: Optional[str] = None
    library_id: Optional[str] = None

    item_raw: Dict[str, Any] = Field(default_factory=dict)
    item_id: Optional[str] = None

    @classmethod
    def from_payload(cls, payload: Dict[str, Any], *, source: str = "emby") -> "SourceEvent":
        p = payload or {}
        # Some webhook senders use different casings / flatter schemas.
        item_raw = p.get("Item") or p.get("item") or {}
        # Flat schema fallback: ItemId/ItemName without nested Item dict
        if not item_raw and (p.get("ItemId") or p.get("itemId") or p.get("ItemName") or p.get("itemName")):
            item_raw = {
                "Id": p.get("ItemId") or p.get("itemId"),
                "Name": p.get("ItemName") or p.get("itemName"),
            }
        try:
            ev = str(p.get("Event") or p.get("event") or p.get("NotificationType") or p.get("notificationType") or "").strip() or None
        except (ValueError, TypeError, AttributeError) as e:
            logger.detail(f"事件类型读取失败（已忽略） - 原因={type(e).__name__}")
            ev = None
        try:
            lib_name = str(p.get("LibraryName") or p.get("libraryName") or p.get("Library") or p.get("library") or "").strip() or None
        except (ValueError, TypeError, AttributeError) as e:
            logger.detail(f"媒体库名称读取失败（已忽略） - 原因={type(e).__name__}")
            lib_name = None
        try:
            lib_id = str(p.get("LibraryId") or p.get("libraryId") or "").strip() or None
        except (ValueError, TypeError, AttributeError) as e:
            logger.detail(f"媒体库 ID 读取失败（已忽略） - 原因={type(e).__name__}")
            lib_id = None
        try:
            item_id = str(
                item_raw.get("Id")
                or item_raw.get("id")
                or item_raw.get("ItemId")
                or item_raw.get("itemId")
                or ""
            ).strip() or None
        except (ValueError, TypeError, AttributeError) as e:
            logger.detail(f"项目 ID 读取失败（已忽略） - 原因={type(e).__name__}")
            item_id = None
        return cls(
            source=source,
            raw=dict(p),
            event=ev,
            library_name=lib_name,
            library_id=lib_id,
            item_raw=dict(item_raw) if isinstance(item_raw, dict) else {},
            item_id=item_id,
        )


# -----------------------------------------------------------------------------
# Pipeline contexts
# -----------------------------------------------------------------------------

class MetaContext(BaseModel):
    model_config = ConfigDict(arbitrary_types_allowed=True)

    source_event: SourceEvent
    payload: Dict[str, Any]
    library_name: Optional[str] = None
    item_raw: Dict[str, Any] = Field(default_factory=dict)
    item: EmbyItem
    path: Optional[str] = None
    local_meta: LocalMeta
    nfo_meta: Optional[NfoMeta] = None


class EnrichedContext(MetaContext):
    tmdb_meta: Optional[TmdbMeta] = None
    mediainfo: Optional[MediaInfo] = None
    is_adult: bool = False


class RenderedContext(EnrichedContext):
    text: str


class CoversResolvedContext(RenderedContext):
    poster_path: Optional[str] = None
    poster_url: Optional[str] = None
    fanart_path: Optional[str] = None
    fanart_url: Optional[str] = None
    local_meta_final: LocalMeta


class NotificationJob(NotificationContent):
    """Final output job including provenance.

    Subclasses NotificationContent so existing notifiers keep working.
    """

    model_config = ConfigDict(extra="allow")

    source_event: Optional[SourceEvent] = None
