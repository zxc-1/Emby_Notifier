from __future__ import annotations

from datetime import datetime
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field, ConfigDict


class EmbyItem(BaseModel):
    """
    Emby Webhook 里的 Item 结构（保留原字段名，方便映射）
    """

    Id: str
    Name: str
    Type: str
    Path: Optional[str] = None
    ProviderIds: Dict[str, Any] = Field(default_factory=dict)
    ProductionYear: Optional[int] = None
    PremiereDate: Optional[datetime | str] = None
    OfficialRating: Optional[str] = None
    CustomRating: Optional[str] = None
    Genres: List[str] = Field(default_factory=list)
    Tags: List[str] = Field(default_factory=list)
    RunTimeTicks: Optional[int] = None

    model_config = ConfigDict(extra="allow")


class LocalMeta(BaseModel):
    """
    整合 Emby / NFO / 本地路径 推断出来的本地元数据
    """

    # 原有字段
    title: str
    original_title: Optional[str] = None
    year: Optional[int] = None
    premiere_date: Optional[datetime] = None
    overview: Optional[str] = None
    community_rating: Optional[float] = None
    mpaa: Optional[str] = None
    website: Optional[str] = None
    genres: List[str] = Field(default_factory=list)
    tags: List[str] = Field(default_factory=list)
    actresses: List[str] = Field(default_factory=list)
    code: Optional[str] = None
    library_name: Optional[str] = None
    tmdb_id: Optional[str] = None
    imdb_id: Optional[str] = None
    language: Optional[str] = None
    duration_ms: Optional[int] = None
    is_adult: bool = False

    # 新增字段（模板会用）
    path: Optional[str] = None          # 实际文件路径，用来找 fanart.jpg
    media_type: Optional[str] = None    # Emby 的 Type，例如 "Movie" / "Episode"
    series_name: Optional[str] = None   # 剧集名（SeriesName）
    series_id: Optional[str] = None     # 剧集ID（Episode 时常见：SeriesId）
    episode_name: Optional[str] = None  # 集标题（一般就是 item.Name）
    season_number: Optional[int] = None
    episode_number: Optional[int] = None
    date_added: Optional[datetime] = None   # 入库时间 / 创建时间
    actors: List[str] = Field(default_factory=list)  # 普通影视的演员
    country: Optional[str] = None        # 国家/地区（可选）
    region_bucket: Optional[str] = None  # 华语 / 日本 / 韩国 / 欧美
    resolution: Optional[str] = None     # 1080p/2160p/...（可选，用于展示）
    douban_url: Optional[str] = None		     # 豆瓣链接（可选，看你后面要不要用）
    emby_image_url: Optional[str] = None # Emby 封面 URL 兜底（可选，历史字段）
    emby_primary_url: Optional[str] = None  # Emby Primary(Poster) URL
    emby_backdrop_url: Optional[str] = None # Emby Backdrop(Fanart) URL

class NfoRating(BaseModel):
    source: str
    value: float
    max_value: Optional[float] = None


class NfoMeta(BaseModel):
    title: Optional[str] = None
    original_title: Optional[str] = None
    year: Optional[int] = None
    premiere_date: Optional[datetime] = None
    plot: Optional[str] = None
    genres: List[str] = Field(default_factory=list)
    actresses: List[str] = Field(default_factory=list)
    mpaa: Optional[str] = None
    website: Optional[str] = None
    code: Optional[str] = None
    tmdb_id: Optional[str] = None
    imdb_id: Optional[str] = None

    # AV 相关扩展字段
    ratings: List["NfoRating"] = Field(default_factory=list)
    studio: Optional[str] = None
    country: Optional[str] = None
    release_date: Optional[datetime] = None
    date_added: Optional[datetime] = None
    tags: List[str] = Field(default_factory=list)
    cover_url: Optional[str] = None       # 线上封面
    fanart_file: Optional[str] = None     # 本地 fanart 文件名
    trailer_url: Optional[str] = None     # 预告片链接（可选）


class MediaInfoVideo(BaseModel):
    width: Optional[int] = None
    height: Optional[int] = None
    codec: Optional[str] = None
    bitrate: Optional[int] = None


class MediaInfoAudio(BaseModel):
    codec: Optional[str] = None
    channels: Optional[str] = None
    language: Optional[str] = None


class MediaInfo(BaseModel):
    video: Optional[MediaInfoVideo] = None
    audios: List[MediaInfoAudio] = Field(default_factory=list)
    duration_ms: Optional[int] = None
    size_bytes: Optional[int] = None


class TmdbMeta(BaseModel):
    tmdb_id: Optional[int] = None
    imdb_id: Optional[str] = None
    original_title: Optional[str] = None
    title: Optional[str] = None
    overview: Optional[str] = None
    poster_url: Optional[str] = None
    backdrop_url: Optional[str] = None
    score: Optional[float] = None
    vote_count: Optional[int] = None
    genres: List[str] = Field(default_factory=list)
    spoken_languages: List[str] = Field(default_factory=list)
    origin_countries: List[str] = Field(default_factory=list)
    production_countries: List[Dict[str, Any]] = Field(default_factory=list)
    release_date: Optional[datetime] = None
    year: Optional[int] = None
    raw: Dict[str, Any] = Field(default_factory=dict)


class NotificationContent(BaseModel):
    """
    模板渲染完成后，传给 Notifier 的最终消息内容
    """

    text: str
    cover_url: Optional[str] = None  # 兼容字段：历史上作为“远程图片兜底”使用（现在等同 poster_url）
    # 本地图片路径：
    # - fanart_path：优先用于 TG 的 fanart（横图/背景图），以及 UI 的次选图
    # - poster_path：优先用于 UI 展示
    fanart_path: Optional[str] = None
    poster_path: Optional[str] = None

    # 远程图片 URL：
    # - fanart_url：TG 首选（backdrop/fanart）
    # - poster_url：兜底（poster/primary）
    fanart_url: Optional[str] = None
    poster_url: Optional[str] = None
    # Web 管理台用的可访问海报 URL（当 fanart_path 是本地文件时，会被缓存到 /data 并映射成 URL）
    web_cover_url: Optional[str] = None
    is_adult: bool = False

    # 下面这些字段用于统计 / 聚合等高级功能（可选）
    # webhook origin (optional)
    event: Optional[str] = None
    library_id: Optional[str] = None
    item_id: Optional[str] = None
    item_path: Optional[str] = None
    # Stable identity for "same media" across chains; used by recent_entries and dedup.
    media_key: Optional[str] = None

    media_type: Optional[str] = None         # Emby 的 Type，例如 "Movie" / "Episode"
    series_name: Optional[str] = None        # 剧集名（Episode 时使用）
    series_id: Optional[str] = None          # 剧集ID（可用于更精确聚合）
    episode_name: Optional[str] = None       # 集标题
    season_number: Optional[int] = None
    episode_number: Optional[int] = None
    library_name: Optional[str] = None       # Emby LibraryName，方便做指标分维度统计

    # 管理后台 UI 专用的展示字段
    display_title: Optional[str] = None      # 列表上的标题（含 🔞 和番号）
    display_meta_line: Optional[str] = None  # 一行元信息
    detail_url: Optional[str] = None         # 点击跳转的详情链接（TMDB 或成人详情页）       # Emby LibraryName，方便做指标分维度统计

    # 管理后台 UI：成人条目的详情链接（历史兼容字段）。
    # recent_entries.list_for_ui 会在缺失时尝试从 item_path / display_title 中提取番号并补全。
    adult_detail_url: Optional[str] = None

    # 入库时间戳（用于统计和趋势图）
    added_at: Optional[str] = None
