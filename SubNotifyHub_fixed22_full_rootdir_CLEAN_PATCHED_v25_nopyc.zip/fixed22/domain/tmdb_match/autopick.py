from __future__ import annotations

"""Auto-pick policy (1.5.x compatible).

This module intentionally mirrors the 1.5.x tg_bot/tmdb_match_core.py
`should_auto_pick` behavior so that refactors do not change user-facing
matching decisions.
"""

import re
from typing import Any, Dict, List, Optional, Tuple

from core.logging import get_biz_logger
from .types import Candidate

biz = get_biz_logger(__name__)


def should_auto_pick(scores: List[Tuple[Candidate, float]], *, ctx: Optional[Dict[str, Any]] = None) -> bool:
    """Decide whether to auto-pick the best TMDB candidate.

    Base rules (used everywhere):
      - If only one candidate and it is reasonably strong, auto-pick.
      - Otherwise use (best score + gap) with a popularity-based relaxation.

    Share-flow extension (ctx provided):
      - Apply extra guards based on hint support / forced media type / query token/year risk.
      - The decision logic still lives here to keep consistency across entry points.
    """

    if not scores:
        return False
    scores = sorted(scores, key=lambda x: x[1], reverse=True)
    best = float(scores[0][1])
    second_score = float(scores[1][1]) if len(scores) > 1 else 0.0

    def _cov(c: Candidate) -> float:
        try:
            m = (c.extra or {}).get("_match") or {}
            return float(m.get("coverage") or 0.0)
        except (TypeError, ValueError, AttributeError) as e:
            biz.detail(f"获取覆盖率失败（已忽略） - 原因={type(e).__name__}")
            return 0.0

    def _support_int(c: Candidate, k: str, default: int = 0) -> int:
        try:
            return int((c.extra or {}).get(k) or default)
        except (TypeError, ValueError, AttributeError) as e:
            biz.detail(f"获取支持度失败（已忽略） - 键={k}, 原因={type(e).__name__}")
            return default

    # --- optional share-flow guards (ctx) ---
    q_year = None  # may be set from ctx (query year)
    if ctx:
        try:
            selected_hints_count = int(ctx.get("selected_hints_count") or 1)
        except (TypeError, ValueError) as e:
            biz.detail(f"解析提示数量失败（已忽略） - 原因={type(e).__name__}")
            selected_hints_count = 1
        has_main_hint = bool(ctx.get("has_main_hint"))
        force_mt = str(ctx.get("force_media_type") or "").strip().lower()
        q_title = str(ctx.get("query_title") or "").strip()
        # batch/group evidence
        try:
            standard_rate = float(ctx.get("standard_rate") or 0.0)
        except (TypeError, ValueError) as e:
            biz.detail(f"解析标准率失败（已忽略） - 原因={type(e).__name__}")
            standard_rate = 0.0
        try:
            ep_cnt = int(ctx.get("episode_count") or 0)
        except (TypeError, ValueError) as e:
            biz.detail(f"解析剧集数量失败（已忽略） - 原因={type(e).__name__}")
            ep_cnt = 0
        try:
            ep_best_cnt = int(ctx.get("episode_best_count") or 0)
        except (TypeError, ValueError) as e:
            biz.detail(f"解析最佳剧集数量失败（已忽略） - 原因={type(e).__name__}")
            ep_best_cnt = 0
        try:
            count_mismatch = bool(ctx.get("count_mismatch"))
        except (TypeError, ValueError) as e:
            biz.detail(f"解析数量不匹配标志失败（已忽略） - 原因={type(e).__name__}")
            count_mismatch = False
        q_year = None
        try:
            q_year = int(ctx.get("query_year")) if ctx.get("query_year") not in (None, "") else None
        except (TypeError, ValueError) as e:
            biz.detail(f"解析查询年份失败（已忽略） - 原因={type(e).__name__}")
            q_year = None

        c0 = scores[0][0]
        supp = _support_int(c0, "_support_count", 1)
        supp_w = _support_int(c0, "_support_weight", supp)
        supp_main = _support_int(c0, "_support_main", 0)
        top1_supp = _support_int(c0, "_top1_support_count", 0)
        top1_w = _support_int(c0, "_top1_support_weight", top1_supp)
        top1_main = _support_int(c0, "_top1_support_main", 0)

        # If we had multiple hints, do *not* always require consensus.
        # Consensus is critical for collision-prone queries (very short titles / generic words),
        # but it can be overly conservative when we already have a strong main hint (video/season folder).
        #
        # We therefore require top-1 consensus only under risky conditions.
        require_consensus = False
        try:
            tc = len(re.findall(r"[A-Za-z0-9]+|[\u4e00-\u9fff]+", q_title or ""))
        except (TypeError, AttributeError) as e:
            biz.detail(f"解析标题词数失败（已忽略） - 原因={type(e).__name__}")
            tc = 2
        try:
            toks = [t.lower() for t in re.findall(r"[A-Za-z]{2,}|[\u4e00-\u9fff]+", q_title or "")]
        except (TypeError, AttributeError) as e:
            biz.detail(f"解析标题词列表失败（已忽略） - 原因={type(e).__name__}")
            toks = []
        collision = {
            "man",
            "one",
            "family",
            "home",
            "love",
            "world",
            "life",
            "day",
            "night",
            "story",
            "journey",
            "the",
            "a",
            "an",
            "and",
            "男人",
            "一个",
            "家庭",
            "家",
            "爱情",
            "世界",
            "人生",
            "故事",
            "旅程",
        }
        collision_risky = bool(toks and len(toks) <= 3 and any(t in collision for t in toks))
        if tc <= 2 or collision_risky:
            require_consensus = True

        # If 115 paging reports a mismatch, we may have incomplete evidence.
        # Be conservative: require stronger match before any auto-pick relaxation.
        if count_mismatch:
            if best < 0.92 or _cov(scores[0][0]) < 0.80:
                return False
            # When evidence may be incomplete, favor multi-hint consensus when available.
            if selected_hints_count >= 2:
                require_consensus = True

        # strong main hint can relax the consensus requirement
        if require_consensus and has_main_hint and supp_main >= 1 and best >= 0.90 and _cov(c0) >= 0.70:
            require_consensus = False

        # Single-hint queries can be very short (e.g., 'Up', 'Her'). When we only have
        # one selected hint but the match evidence is very strong, do not force a
        # multi-hint consensus/weight gate.
        if require_consensus and selected_hints_count <= 1 and has_main_hint and best >= 0.95 and _cov(c0) >= 0.85:
            require_consensus = False

        if selected_hints_count >= 2 and require_consensus:
            eff = top1_supp if top1_supp > 0 else supp
            eff_main = top1_main if top1_supp > 0 else supp_main
            if eff < 2:
                # allow a single-hint auto-pick only when evidence is extremely strong
                if not (best >= 0.97 and _cov(c0) >= 0.92):
                    return False
            if has_main_hint and eff_main <= 0:
                return False

        # When not requiring consensus, still ensure main hint participates (prevents message-only mis-picks)
        if selected_hints_count >= 2 and (not require_consensus) and has_main_hint and supp_main <= 0:
            if best < 0.93 or _cov(c0) < 0.80:
                return False

        # Weighted support: main hints count as 2, message-only hints count as 1.
        if has_main_hint:
            eff_w = top1_w if top1_supp > 0 else supp_w
            # Only enforce the stronger weight gate when we *actually* have multiple hints to form
            # a consensus. For single-hint flows, eff_w may legitimately be 1 even with very
            # strong match evidence.
            if require_consensus and selected_hints_count >= 2:
                if eff_w < 2:
                    return False
            else:
                if eff_w < 1:
                    return False

        # Media-type guard: if we forced TV (season pack / explicit season) do not auto-pick movies.
        try:
            mt_b = str(getattr(c0, "media_type", "") or "").strip().lower()
        except (TypeError, AttributeError) as e:
            biz.detail(f"获取媒体类型失败（已忽略） - 原因={type(e).__name__}")
            mt_b = ""
        if force_mt == "tv" and mt_b == "movie":
            return False

        # Paging mismatch guard (115): if the share listing appears incomplete, do not auto-pick
        # unless evidence is extremely strong.
        if count_mismatch:
            if best < 0.92 or _cov(c0) < 0.80:
                return False

        # Token guard: extremely short titles collide easily; require very strong evidence.
        try:
            tc = len(re.findall(r"[A-Za-z0-9]+|[\u4e00-\u9fff]+", q_title or ""))
        except (TypeError, AttributeError) as e:
            biz.detail(f"解析标题词数失败（已忽略） - 原因={type(e).__name__}")
            tc = 2
        if tc <= 1:
            if best < 0.93 or _cov(c0) < 0.90:
                return False

        # Collision-words guard: very generic short English titles collide frequently.
        try:
            toks = [t.lower() for t in re.findall(r"[A-Za-z]{2,}|[\u4e00-\u9fff]+", q_title or "")]
        except (TypeError, AttributeError) as e:
            biz.detail(f"解析标题词列表失败（已忽略） - 原因={type(e).__name__}")
            toks = []
        collision_risky = bool(toks and len(toks) <= 3 and any(t in collision for t in toks))
        if collision_risky:
            if best < 0.95 or _cov(c0) < 0.92:
                return False

        # Year guard: large year mismatch is risky (remakes / same-name collisions).
        by = None
        try:
            by = int(getattr(c0, "year", None)) if getattr(c0, "year", None) not in (None, "") else None
        except (TypeError, ValueError, AttributeError) as e:
            biz.detail(f"解析候选年份失败（已忽略） - 原因={type(e).__name__}")
            by = None
        if q_year and by and abs(int(q_year) - int(by)) >= 2:
            if best < 0.90 or _cov(c0) < 0.80:
                return False

        # If all supports are from weak hints, tighten thresholds slightly.
        weak_only = (has_main_hint and supp_main <= 0) or ((not has_main_hint) and supp_main <= 0 and selected_hints_count >= 2)
        if weak_only and best < 0.86:
            return False

        # --- Accuracy-first, but allow *more* auto-picks when evidence is strong ---
        best_cov0 = _cov(c0)
        second_cov0 = _cov(scores[1][0]) if len(scores) > 1 else 0.0
        eff = top1_supp if top1_supp > 0 else supp
        eff_main = top1_main if top1_supp > 0 else supp_main

        if len(scores) > 1 and selected_hints_count >= 2 and not collision_risky:
            # 2-hint consensus: allow smaller gap when coverage is decent.
            if eff >= 2 and best >= 0.81 and best_cov0 >= 0.62:
                if (best - second_score) >= 0.02 or (best_cov0 - second_cov0) >= 0.08:
                    return True
            # 3+ hints (or weighted confirmation) can be slightly more permissive.
            if eff >= 3 and best >= 0.78 and best_cov0 >= 0.58 and (best - second_score) >= 0.00:
                return True

        # Main-hint present (video filename / season folder): allow relaxed gap, but still require decent match.
        if len(scores) > 1 and has_main_hint and eff_main >= 1 and not collision_risky:
            if best >= 0.83 and best_cov0 >= 0.65 and (best - second_score) >= 0.02:
                return True

            # "High coverage + healthy margin" fallback.
            # For short titles (e.g. "Spring Fever"), the matching score can
            # land slightly below 0.83 even when the result is clearly correct.
            if best >= 0.78 and best_cov0 >= 0.95 and (best - second_score) >= 0.10:
                return True

        # Batch evidence fast-pass (clean season packs): when most files follow standard SxxEyy and
        # episode evidence supports the mapping, allow a smaller margin.
        try:
            mt_b = str(getattr(c0, "media_type", "") or "").strip().lower()
        except Exception:
            mt_b = ""
        try:
            ep_sc = float((c0.extra or {}).get("_episode_score") or 0.0)
        except Exception:
            ep_sc = 0.0
        cov_eps = (float(ep_best_cnt) / float(ep_cnt)) if ep_cnt > 0 else 0.0
        if mt_b == "tv" and standard_rate >= 0.90 and ep_cnt >= 3 and cov_eps >= 0.75 and ep_sc >= 0.45:
            if best >= 0.80 and _cov(c0) >= 0.55 and (best - second_score) >= 0.03:
                return True

    # --- base decision rules ---
    # Special case: only one candidate
    if len(scores) == 1:
        c0 = scores[0][0]
        extra = c0.extra or {}
        cov0 = _cov(c0)
        try:
            vc = int(extra.get("vote_count") or c0.vote_count or 0)
        except (TypeError, ValueError, AttributeError) as e:
            biz.detail(f"获取投票数失败（已忽略） - 原因={type(e).__name__}")
            vc = 0
        if best >= 0.82 and cov0 >= 0.55:
            return True
        if best >= 0.78 and cov0 >= 0.65:
            return True
        if best >= 0.70 and vc >= 1500 and cov0 >= 0.35:
            return True
        return False

    second = float(scores[1][1])
    best_cov = _cov(scores[0][0])
    second_cov = _cov(scores[1][0]) if len(scores) > 1 else 0.0

    # Hard guard: if coverage is very low, do not auto-pick.
    if best_cov < 0.45:
        return False

    # Base rule: strong enough AND clear gap.
    if best >= 0.86 and (best - second) >= 0.08 and best_cov >= 0.65:
        return True

    # Very high coverage can compensate for smaller gap.
    if best >= 0.82 and best_cov >= 0.90 and (best - second) >= 0.03:
        return True

    # Relaxed rule: still strong, small gap allowed when the best is clearly more popular
    if best >= 0.82 and (best - second) >= 0.06 and best_cov >= 0.60:
        try:
            a = scores[0][0]
            b = scores[1][0]
            va = float((a.extra or {}).get("vote_count") or a.vote_count or 0)
            vb = float((b.extra or {}).get("vote_count") or b.vote_count or 0)
            if (va >= 4 * max(1.0, vb)) or (va - vb >= 500):
                return True
        except Exception:
            biz.detail("异常已抑制", exc_info=True)

    # Tie-break for "perfect ties": when multilingual/alias matching produces two near-perfect results,
    # scores/coverage may collapse and look identical. In that case, we *must* use deterministic
    # metadata signals to decide (year -> episode consistency -> vote_count/popularity).
    if len(scores) >= 2 and best >= 0.985 and best_cov >= 0.80:
        try:
            c1, s1 = scores[0][0], float(scores[0][1])
            c2, s2 = scores[1][0], float(scores[1][1])

            eps = 0.002
            if abs(s1 - s2) < eps and abs(best_cov - second_cov) < 0.01:
                def _feat(c):
                    ex = getattr(c, "extra", None) or {}
                    cy = getattr(c, "year", None)
                    # smaller year_diff is better (if q_year unknown, deprioritize year)
                    year_diff = abs(int(cy) - int(q_year)) if (q_year and cy) else 999
                    # higher episode_score is better (we store it as negative for tuple ordering)
                    ep = ex.get("_episode_score", 0.0) or 0.0
                    # higher vote_count/popularity are better
                    vc = ex.get("vote_count", None)
                    if vc is None:
                        vc = getattr(c, "vote_count", 0) or 0
                    pop = ex.get("popularity", None)
                    if pop is None:
                        pop = getattr(c, "popularity", 0.0) or 0.0
                    return (int(year_diff), -float(ep), -int(vc), -float(pop))

                f1 = _feat(c1)
                f2 = _feat(c2)

                if f1 != f2:
                    winner_is_top1 = f1 < f2
                    biz.detail(
                        f"TMDB 自动选择平局决胜：使用年份+剧集+投票+热度进行排序",
                        结果="选择第一候选" if winner_is_top1 else "选择第二候选",
                        第一候选=getattr(c1, "tmdb_id", None),
                        第二候选=getattr(c2, "tmdb_id", None),
                        第一特征=str(f1),
                        第二特征=str(f2),
                    )
                    if winner_is_top1:
                        return True
        except (ValueError, TypeError, AttributeError) as e:
            biz.detail(f"TMDB自动选择特征计算失败（已跳过） - 原因={type(e).__name__}")
    return False
