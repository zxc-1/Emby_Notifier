from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional


@dataclass
class Candidate:
    """A TMDB search/match candidate.

    This is a *data-only* structure used across layers.
    """

    tmdb_id: int
    media_type: str  # movie/tv
    title: str
    year: Optional[int] = None
    rating: Optional[float] = None
    vote_count: Optional[int] = None
    score: Optional[float] = None
    extra: Dict[str, Any] | None = None
