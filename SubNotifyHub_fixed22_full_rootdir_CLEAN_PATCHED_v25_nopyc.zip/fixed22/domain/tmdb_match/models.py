"""Data models for TMDB recognition optimization.

These models provide structured representations for evidence levels,
hint sources, auto-pick context, and candidate score breakdowns.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from enum import IntEnum, Enum
from typing import Any, Dict, List, Optional


class EvidenceLevel(IntEnum):
    """Evidence quality level from 115 share.
    
    L0: 115 temporarily unavailable - no reliable evidence
    L1: Title/folder only - no actual video filenames (NEVER auto-pick)
    L2: At least 1 real video filename sample
    L3: Multiple video samples or reliable multi-file count
    """
    L0_UNAVAILABLE = 0
    L1_TITLE_ONLY = 1
    L2_VIDEO_SAMPLE = 2
    L3_MULTI_SAMPLES = 3
    
    @classmethod
    def from_int(cls, value: int) -> "EvidenceLevel":
        """Convert integer to EvidenceLevel, clamping to valid range."""
        try:
            return cls(max(0, min(3, int(value))))
        except (ValueError, TypeError):
            return cls.L1_TITLE_ONLY
    
    def allows_auto_pick(self) -> bool:
        """Return True if this evidence level allows auto-pick."""
        return self.value >= 2
    
    def description(self) -> str:
        """Return human-readable description."""
        descriptions = {
            0: "L0:share_unavailable",
            1: "L1:title_only",
            2: "L2:video_sample",
            3: "L3:multi_video_samples",
        }
        return descriptions.get(self.value, f"L{self.value}:unknown")


class HintSource(str, Enum):
    """Source type for search hints.
    
    MAIN: High-priority hints (video filename, season folder)
    MSG: Message hints (user input, URL fragment)
    EXTRA: Low-priority hints (additional samples)
    """
    MAIN = "main"
    MSG = "msg"
    EXTRA = "extra"
    
    def weight(self) -> int:
        """Return weight for support calculation."""
        weights = {
            "main": 2,
            "msg": 1,
            "extra": 1,
        }
        return weights.get(self.value, 1)


@dataclass
class AutoPickContext:
    """Context for auto-pick decision.
    
    Contains all signals needed by should_auto_pick() to make a decision.
    """
    selected_hints_count: int = 0
    has_main_hint: bool = False
    require_consensus: bool = False
    force_media_type: Optional[str] = None
    query_title: str = ""
    query_year: Optional[int] = None
    standard_rate: float = 0.0
    episode_count: int = 0
    episode_best_count: int = 0
    episode_dup_count: int = 0
    count_mismatch: bool = False
    evidence_level: int = 2
    strict_year: Optional[int] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for passing to should_auto_pick()."""
        return {
            "selected_hints_count": self.selected_hints_count,
            "has_main_hint": self.has_main_hint,
            "require_consensus": self.require_consensus,
            "force_media_type": self.force_media_type,
            "query_title": self.query_title,
            "query_year": self.query_year,
            "standard_rate": self.standard_rate,
            "episode_count": self.episode_count,
            "episode_best_count": self.episode_best_count,
            "episode_dup_count": self.episode_dup_count,
            "count_mismatch": self.count_mismatch,
        }


@dataclass
class CandidateScoreBreakdown:
    """Detailed score breakdown for a candidate.
    
    Used in debug mode to show how the final score was computed.
    """
    tmdb_id: int
    media_type: str = "movie"
    title: str = ""
    year: Optional[int] = None
    
    # Score components
    base_score: float = 0.0           # Original similarity score
    coverage: float = 0.0             # Coverage ratio
    year_adjustment: float = 0.0      # Year affinity adjustment (+0.03 / -0.02 / -0.05)
    episode_adjustment: float = 0.0   # Episode consistency adjustment
    support_adjustment: float = 0.0   # Multi-hint consensus adjustment
    alias_adjustment: float = 0.0     # Alias matching adjustment
    sequel_adjustment: float = 0.0    # Sequel marker adjustment
    fused_score: float = 0.0          # Final fused score
    
    # Gate tracking
    gates_passed: List[str] = field(default_factory=list)
    gates_blocked: List[str] = field(default_factory=list)
    
    def compute_fused_score(self) -> float:
        """Compute fused score from components."""
        self.fused_score = (
            self.base_score
            + self.year_adjustment
            + self.episode_adjustment
            + self.support_adjustment
            + self.alias_adjustment
            + self.sequel_adjustment
        )
        return self.fused_score
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "tmdb_id": self.tmdb_id,
            "media_type": self.media_type,
            "title": self.title,
            "year": self.year,
            "base_score": round(self.base_score, 4),
            "coverage": round(self.coverage, 4),
            "year_adjustment": round(self.year_adjustment, 4),
            "episode_adjustment": round(self.episode_adjustment, 4),
            "support_adjustment": round(self.support_adjustment, 4),
            "alias_adjustment": round(self.alias_adjustment, 4),
            "sequel_adjustment": round(self.sequel_adjustment, 4),
            "fused_score": round(self.fused_score, 4),
            "gates_passed": self.gates_passed,
            "gates_blocked": self.gates_blocked,
        }


@dataclass
class DecisionTrace:
    """Trace of decision path through the resolver pipeline.
    
    Records which stages were executed and which gates blocked auto-pick.
    """
    stages: List[str] = field(default_factory=list)
    gates_blocked: List[str] = field(default_factory=list)
    score_adjustments: List[Dict[str, Any]] = field(default_factory=list)
    
    def add_stage(self, stage: str) -> None:
        """Record a stage completion."""
        self.stages.append(stage)
    
    def add_gate_blocked(self, gate: str) -> None:
        """Record a gate that blocked auto-pick."""
        self.gates_blocked.append(gate)
    
    def add_score_adjustment(
        self,
        field_name: str,
        before: float,
        after: float,
        reason: str = ""
    ) -> None:
        """Record a score adjustment."""
        self.score_adjustments.append({
            "field": field_name,
            "before": round(before, 4),
            "after": round(after, 4),
            "delta": round(after - before, 4),
            "reason": reason,
        })
    
    def to_list(self) -> List[str]:
        """Convert to list of trace strings for logging."""
        result = list(self.stages)
        for gate in self.gates_blocked:
            result.append(f"gate:{gate}")
        for adj in self.score_adjustments:
            result.append(f"score_adj:{adj['field']}:{adj['before']}->{adj['after']}")
        return result
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for JSON serialization."""
        return {
            "stages": self.stages,
            "gates_blocked": self.gates_blocked,
            "score_adjustments": self.score_adjustments,
        }


@dataclass
class HintPack:
    """Structured hint pack from share evidence.
    
    Contains all hints categorized by source and priority.
    """
    hints_main: List[str] = field(default_factory=list)
    hints_msg: List[str] = field(default_factory=list)
    hints_extra: List[str] = field(default_factory=list)
    hints2: List[str] = field(default_factory=list)  # Cleaned unique hints
    
    q_title: str = ""
    q_year: Optional[int] = None
    strict_year: Optional[int] = None
    
    evidence_level: int = 1
    evidence_level_desc: str = "L1:title_only"
    
    season_hint_eff: Optional[int] = None
    episode_set: List[int] = field(default_factory=list)
    episode_count: int = 0
    standard_rate: float = 0.0
    
    batch_title: str = ""
    episode_best_files: List[Dict[str, Any]] = field(default_factory=list)
    episode_dup_count: int = 0
    
    tvish: bool = False
    force_mt: Optional[str] = None
    has_msg_hints: bool = False
    
    count_mismatch: bool = False
    vc_reliable: bool = False
    video_count: int = 0
    
    # Raw evidence
    share_title: str = ""
    filename: str = ""
    hint_name: str = ""
    dir_path: List[str] = field(default_factory=list)
    video_samples: List[str] = field(default_factory=list)
    
    def all_hints(self) -> List[str]:
        """Return all hints in priority order."""
        return self.hints_main + self.hints_msg + self.hints_extra
    
    def has_bilingual_evidence(self) -> bool:
        """Check if hints contain both CJK and Latin characters."""
        import re
        has_cjk = False
        has_latin = False
        for h in self.hints2[:10]:
            if re.search(r'[\u4e00-\u9fff]', h):
                has_cjk = True
            if re.search(r'[A-Za-z]', h):
                has_latin = True
            if has_cjk and has_latin:
                return True
        return False
