from __future__ import annotations

import re
from typing import List, Optional

from .norm import normalize_title, zh_variants


def make_title_fingerprint(
    title: str,
    year: Optional[int],
    media_type: str,
    season: Optional[int],
    *,
    cn_tag_cleanup_mode: str = "conservative",
) -> str:
    """Fingerprint for caching / disambiguation.

    Note: This is intentionally stable and lossy.
    """
    t = normalize_title(title or "", cn_tag_cleanup_mode=cn_tag_cleanup_mode)
    t = re.sub(r"\s+", " ", t).strip().lower()
    y = str(int(year)) if isinstance(year, int) else ""
    mt = "movie" if (media_type or "").lower() == "movie" else "tv"
    s = str(int(season)) if isinstance(season, int) else ""
    return f"{mt}:{t}:{y}:{s}"


def make_series_fingerprints(
    title: str,
    year: Optional[int],
    *,
    cn_tag_cleanup_mode: str = "conservative",
) -> List[str]:
    """Generate multiple fingerprints for a series title.

    Includes simplified/traditional variants for better recall.
    """
    t0 = normalize_title(title or "", cn_tag_cleanup_mode=cn_tag_cleanup_mode)
    t0 = re.sub(r"\s+", " ", t0).strip()
    outs: List[str] = []
    seen = set()
    for t in [t0, *zh_variants(t0)]:
        t = re.sub(r"\s+", " ", (t or "")).strip().lower()
        if not t:
            continue
        key = f"tv:{t}:{int(year) if isinstance(year, int) else ''}:"
        if key in seen:
            continue
        seen.add(key)
        outs.append(key)
    return outs
