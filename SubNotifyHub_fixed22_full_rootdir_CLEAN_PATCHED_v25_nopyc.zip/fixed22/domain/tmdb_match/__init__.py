"""Pure TMDB matching logic (no I/O).

This package contains deterministic parts of TMDB matching:

- title normalization
- token similarity / scoring
- fingerprints
- auto-pick heuristics

All network I/O (TMDB API calls, caching, settings access) must live outside
this package (typically in :mod:`integrations`).
"""

from .types import Candidate
from .norm import (
    extract_tmdb_id_from_text,
    normalize_title,
    zh_to_simplified,
    zh_to_traditional,
    zh_variants,
)
from .fingerprint import make_series_fingerprints, make_title_fingerprint
from .similarity import compute_idf_weights, key_tokens, match_meta, title_similarity
from .scoring import score_candidate, score_candidate_meta
from .autopick import should_auto_pick

__all__ = [
    "Candidate",
    "extract_tmdb_id_from_text",
    "normalize_title",
    "zh_to_simplified",
    "zh_to_traditional",
    "zh_variants",
    "make_series_fingerprints",
    "make_title_fingerprint",
    "key_tokens",
    "compute_idf_weights",
    "match_meta",
    "title_similarity",
    "score_candidate_meta",
    "score_candidate",
    "should_auto_pick",
]
