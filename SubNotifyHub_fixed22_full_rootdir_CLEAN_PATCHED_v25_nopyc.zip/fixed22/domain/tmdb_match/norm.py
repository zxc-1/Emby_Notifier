from __future__ import annotations

import html
import re
import unicodedata
from typing import List, Optional
from urllib.parse import parse_qs, unquote, urlparse

from core.logging import get_biz_logger_adapter
from domain.utils.patterns import TMDB_EXPLICIT_RE

logger = get_biz_logger_adapter(__name__)

_DIGITS_RE = re.compile(r"\d{3,10}")


def _normalize_for_id(text: str) -> str:
    t = (text or "").strip()
    if not t:
        return ""
    try:
        t = unicodedata.normalize("NFKC", t)
    except Exception:
        logger.detail("异常已抑制", exc_info=True)
    try:
        t = unquote(t)
    except Exception:
        logger.detail("异常已抑制", exc_info=True)
    t = t.lower()
    t = re.sub(r"[\[\]\(\)\{\}<>|,:;=+@~!#$%^&*`\"'\\/\\?]+", " ", t)
    t = re.sub(r"[._-]+", " ", t)
    t = re.sub(r"[^0-9a-z\u4e00-\u9fff\s]+", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t


def _looks_like_tech_number(num_token: str, prev_tok: str, next_tok: str) -> bool:
    if not num_token.isdigit():
        return False
    prev_tok = (prev_tok or "").lower()
    next_tok = (next_tok or "").lower()
    try:
        n = int(num_token)
    except Exception:
        logger.fail("数字解析异常 - token=%s", num_token, exc_info=True)
        return True

    if next_tok in {"p", "fps", "hz", "bit", "bits", "kbps", "mbps", "gbps"}:
        return True
    if prev_tok in {"p", "fps", "hz", "bit", "bits", "kbps", "mbps", "gbps"}:
        return True

    if n in {264, 265} and prev_tok in {"h", "x"}:
        return True
    if n in {264, 265} and next_tok in {"h", "x"}:
        return True
    if n in {2160, 1080, 720, 480} and (prev_tok == "p" or next_tok == "p"):
        return True
    if n in {24, 25, 30, 50, 60, 120} and (prev_tok == "fps" or next_tok == "fps"):
        return True
    return False


def _extract_tmdb_id_from_tokens(tokens: List[str]) -> Optional[int]:
    if not tokens:
        return None
    window = 6
    for i, tok in enumerate(tokens):
        if "tmdb" not in tok:
            continue
        m = _DIGITS_RE.search(tok)
        if m:
            num = m.group(0)
            if num and num.isdigit() and len(num) >= 5:
                try:
                    n = int(num)
                except Exception:
                    logger.detail("异常已抑制", exc_info=True)
                else:
                    if not (1900 <= n <= 2099):
                        return n
        for j in range(i + 1, min(len(tokens), i + 1 + window)):
            t = tokens[j]
            if not t.isdigit():
                continue
            if not (5 <= len(t) <= 10):
                continue
            try:
                n = int(t)
            except Exception:
                logger.detail("循环中异常已抑制", exc_info=True)
                continue
            if 1900 <= n <= 2099:
                continue
            prev_tok = tokens[j - 1] if j - 1 >= 0 else ""
            next_tok = tokens[j + 1] if j + 1 < len(tokens) else ""
            if _looks_like_tech_number(t, prev_tok, next_tok):
                continue
            return n
    return None


def extract_tmdb_id_from_text(s: str) -> Optional[int]:
    """Extract an explicit TMDB id from a text/URL fragment."""

    if not isinstance(s, str) or not s.strip():
        return None
    try:
        m0 = TMDB_EXPLICIT_RE.search(s)
        if m0:
            v0 = m0.group(1)
            if v0 and str(v0).isdigit():
                return int(v0)
    except Exception:
        logger.detail("异常已抑制", exc_info=True)

    try:
        u = urlparse(s)
        if u.scheme and u.netloc:
            qs = parse_qs(u.query or "")
            for k, vs in (qs or {}).items():
                if "tmdb" not in (k or "").lower():
                    continue
                for v in vs or []:
                    mv = _DIGITS_RE.search(str(v))
                    if mv:
                        return int(mv.group(0))
            if u.fragment and "tmdb" in u.fragment.lower():
                norm_f = _normalize_for_id(u.fragment)
                tid = _extract_tmdb_id_from_tokens(norm_f.split())
                if tid:
                    return tid
    except Exception:
        logger.detail("异常已抑制", exc_info=True)

    norm = _normalize_for_id(s)
    if not norm or "tmdb" not in norm:
        return None
    return _extract_tmdb_id_from_tokens(norm.split())


def normalize_title(s: str, *, cn_tag_cleanup_mode: str = "conservative") -> str:
    """Normalize a title for matching.

    Args:
        cn_tag_cleanup_mode: "conservative" | "aggressive" | "off"

    Note: settings access must happen in integrations; this function stays pure.
    """

    t = (s or "").strip()
    if not t:
        return ""

    mode = str(cn_tag_cleanup_mode or "conservative").strip().lower()
    if mode not in {"conservative", "aggressive", "off"}:
        mode = "conservative"

    cn_tags_re = (
        r"(?:"
        r"中字|双语|國語|国语|粤语|粵語|国粤|國粵|中英字幕|中文字幕|外挂字幕|內嵌字幕|内嵌字幕|官方字幕|无字|無字|无字幕|無字幕|简繁|簡繁|繁中|簡中|简中|繁中"
        r"|全集|全\d+集|完结|完結|更新至\d+|更新至|番外|特典|花絮|预告|預告|片花|特辑|特輯|抢先|搶先|先导|先導|彩蛋|加更|未删减|未刪減|删减|刪減|修复|修復|高清|超清|蓝光|藍光"
        r")"
    )

    if mode != "off":
        if mode == "aggressive":
            t = re.sub(cn_tags_re, " ", t)
        else:
            bracket_rx = re.compile(r"\[[^\]]*\]|\([^\)]*\)|\{[^\}]*\}")

            def _clean_bracket(m: re.Match) -> str:
                seg = m.group(0)
                inner = seg[1:-1]
                inner_no_tags = re.sub(cn_tags_re, " ", inner)
                inner_no_tags = re.sub(r"[\s\._\-]+", " ", inner_no_tags).strip()
                if not inner_no_tags:
                    return " "
                inner2 = re.sub(
                    rf"(?:(?<=^)|(?<=[\s\._\-])){cn_tags_re}(?:(?=$)|(?=[\s\._\-]))",
                    " ",
                    inner,
                )
                return " " + inner2 + " "

            t = bracket_rx.sub(_clean_bracket, t)
            t = re.sub(
                rf"(?:(?<=^)|(?<=[\s\._\-\[\(\{{])){cn_tags_re}(?:(?=$)|(?=[\s\._\-\]\)\}}]))",
                " ",
                t,
            )

    for ch in "[](){}":
        t = t.replace(ch, " ")

    t = t.replace("+", " ")

    t = re.sub(
        r"\b(2160p|1080p|720p|480p|4k|8k|hdr10\+?|hdr|dv|dovi|dolby\.?vision|x264|x265|h\.?264|h\.?265|hevc|avc|aac|ac3|eac3|dts(?:-?hd)?|truehd|atmos|flac|mp3|mp4|mkv|avi|mov|wmv|flv|m2ts|ts|mpg|mpeg|bluray|blu[- ]?ray|brrip|web[- ]?dl|webrip|remux|hdtv|proper|repack|imax|uhd|10bit|8bit|yuv\d{3}|bitrate\d+|multi(?:-?audio)?|dual\s*audio|sub(?:bed)?|dub(?:bed)?|chs|cht|eng|amzn|nf|netflix|dsnp|disney\+|atvp|appletv\+|hmax|ddp|dd)\b",
        " ",
        t,
        flags=re.IGNORECASE,
    )

    t = re.sub(r"\b\d{2,3}\s*fps\b", " ", t, flags=re.IGNORECASE)
    t = re.sub(r"\b(maxplus|max\+|vivid|hdr\s*vivid|hdrvivid|imax\s*enhanced)\b", " ", t, flags=re.IGNORECASE)
    t = re.sub(r"\b(hiveweb|rarbg|yts|tgx|evo|yify|ettv|ntb|amiable|ctrlhd)\b", " ", t, flags=re.IGNORECASE)

    t = re.sub(r"\b(bdmv|stream|playlist|mpls|clpi|menu|menus|extra|extras|sample)\b", " ", t, flags=re.IGNORECASE)
    t = re.sub(r"[._]+", " ", t)
    t = re.sub(r"[-]+", " ", t)
    t = re.sub(r"\b0\d{2,}\b", " ", t)
    t = re.sub(r"\b\d{5,}\b", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    toks = [x for x in t.split() if not (len(x) == 1 and re.fullmatch(r"[A-Za-z]", x))]
    t = " ".join(toks).strip()
    return t


_OPENCC_S2T = None
_OPENCC_T2S = None
try:  # pragma: no cover
    from opencc import OpenCC  # type: ignore

    _OPENCC_S2T = OpenCC("s2t").convert
    _OPENCC_T2S = OpenCC("t2s").convert
except Exception:
    logger.detail("⚠️ OpenCC 不可用：繁简转换已禁用；如需启用请安装 opencc-python-reimplemented")
    _OPENCC_S2T = None
    _OPENCC_T2S = None


# Minimal builtin fallback maps for common title chars.
_ZH_S2T_MAP = {
    "后": "後",
    "发": "發",
    "复": "復",
    "台": "臺",
    "龙": "龍",
    "风": "風",
    "门": "門",
    "国": "國",
    "爱": "愛",
    "梦": "夢",
    "电": "電",
    "战": "戰",
    "话": "話",
    "网": "網",
    "乐": "樂",
    "云": "雲",
    "线": "線",
    "画": "畫",
    "马": "馬",
    "点": "點",
    "儿": "兒",
    "时": "時",
    "这": "這",
    "见": "見",
    "观": "觀",
    "觉": "覺",
    "气": "氣",
    "体": "體",
    "历": "歷",
    "卫": "衛",
    "万": "萬",
    "与": "與",
    "东": "東",
    "圣": "聖",
    "岁": "歲",
    "为": "為",
    "丰": "豐",
    "众": "眾",
    "优": "優",
    "会": "會",
    "传": "傳",
    "价": "價",
    "伤": "傷",
    "伦": "倫",
    "侠": "俠",
    "侧": "側",
    "侦": "偵",
    "储": "儲",
    "关": "關",
    "兴": "興",
    "军": "軍",
    "农": "農",
    "冲": "沖",
    "决": "決",
    "净": "淨",
    "刘": "劉",
    "剑": "劍",
    "剧": "劇",
    "击": "擊",
    "创": "創",
    "别": "別",
    "剂": "劑",
    "动": "動",
    "务": "務",
    "华": "華",
    "厅": "廳",
    "压": "壓",
    "参": "參",
    "双": "雙",
    "变": "變",
    "号": "號",
    "启": "啟",
    "团": "團",
    "围": "圍",
    "场": "場",
    "坏": "壞",
    "声": "聲",
    "处": "處",
    "备": "備",
    "够": "夠",
    "头": "頭",
    "妈": "媽",
    "宝": "寶",
    "实": "實",
    "审": "審",
    "将": "將",
    "尽": "盡",
    "岛": "島",
    "师": "師",
    "带": "帶",
    "广": "廣",
    "庆": "慶",
    "库": "庫",
    "异": "異",
    "归": "歸",
    "录": "錄",
    "当": "當",
    "忧": "憂",
    "惊": "驚",
    "戏": "戲",
    "户": "戶",
    "扬": "揚",
    "扩": "擴",
    "扫": "掃",
    "择": "擇",
    "挂": "掛",
    "换": "換",
    "损": "損",
    "摇": "搖",
    "敌": "敵",
    "数": "數",
    "旧": "舊",
    "杂": "雜",
    "极": "極",
    "杀": "殺",
    "条": "條",
    "枪": "槍",
    "树": "樹",
    "欢": "歡",
    "汤": "湯",
    "沟": "溝",
    "汉": "漢",
    "泽": "澤",
    "湾": "灣",
    "灾": "災",
    "灯": "燈",
    "灵": "靈",
    "热": "熱",
    "猎": "獵",
    "猫": "貓",
    "现": "現",
    "盘": "盤",
    "确": "確",
    "礼": "禮",
    "离": "離",
    "税": "稅",
    "穷": "窮",
    "竞": "競",
    "罗": "羅",
    "绿": "綠",
    "续": "續",
    "罚": "罰",
    "职": "職",
    "联": "聯",
    "脸": "臉",
    "苏": "蘇",
    "范": "範",
    "荡": "蕩",
    "虑": "慮",
    "计": "計",
    "认": "認",
    "负": "負",
    "贡": "貢",
    "购": "購",
    "转": "轉",
    "输": "輸",
    "边": "邊",
    "进": "進",
    "远": "遠",
    "连": "連",
    "选": "選",
    "遗": "遺",
    "邮": "郵",
    "郁": "鬱",
    "酿": "釀",
    "钟": "鐘",
    "铁": "鐵",
    "长": "長",
    "闪": "閃",
    "闭": "閉",
    "问": "問",
    "队": "隊",
    "阴": "陰",
    "际": "際",
    "顾": "顧",
    "飞": "飛",
    "饭": "飯",
    "馆": "館",
    "骇": "駭",
    "鱼": "魚",
}

_ZH_T2S_MAP = {v: k for k, v in _ZH_S2T_MAP.items()}


def zh_to_traditional(s: str) -> str:
    if not s:
        return s
    if _OPENCC_S2T is not None:
        try:
            return _OPENCC_S2T(s)
        except Exception:
            logger.detail("⚠️ OpenCC 不可用：繁简转换已禁用；如需启用请安装 opencc-python-reimplemented")
            pass
    return "".join(_ZH_S2T_MAP.get(ch, ch) for ch in s)


def zh_to_simplified(s: str) -> str:
    if not s:
        return s
    if _OPENCC_T2S is not None:
        try:
            return _OPENCC_T2S(s)
        except Exception:
            logger.detail("⚠️ OpenCC 不可用：繁简转换已禁用；如需启用请安装 opencc-python-reimplemented")
            pass
    return "".join(_ZH_T2S_MAP.get(ch, ch) for ch in s)


def zh_variants(s: str) -> List[str]:
    if not s:
        return [""]
    t2 = zh_to_traditional(s)
    t3 = zh_to_simplified(s)
    out = [s]
    if t2 != s:
        out.append(t2)
    if t3 != s and t3 != t2:
        out.append(t3)
    return out
