from __future__ import annotations

import logging
import math
from typing import Dict, List, Optional, Tuple

from core.logging import get_biz_logger_adapter
from .similarity import match_meta
from .types import Candidate

logger = get_biz_logger_adapter(__name__)


def score_candidate_meta(
    query_title: str,
    query_year: Optional[int],
    cand: Candidate,
    *,
    idf: Optional[Dict[str, float]] = None,
    cn_tag_cleanup_mode: str = "conservative",
) -> Tuple[float, float, str]:
    """Return (score, coverage, matched_name)."""
    names: List[str] = []
    if cand.title:
        names.append(str(cand.title))
    extra = cand.extra or {}
    for k in ("original_title", "original_name", "title", "name"):
        v = extra.get(k)
        if isinstance(v, str) and v.strip():
            names.append(v.strip())

    try:
        aliases = extra.get("_aliases")
        if isinstance(aliases, list):
            for a in aliases:
                if isinstance(a, str) and a.strip():
                    names.append(a.strip())
    except Exception:
        logger.detail("异常已抑制", exc_info=True)

    seen = set()
    names2: List[str] = []
    for x in names:
        if x not in seen:
            seen.add(x)
            names2.append(x)

    best_s = 0.0
    best_cov = 0.0
    best_name = ""
    for n in names2 or []:
        s0, cov0 = match_meta(query_title, n, idf=idf, cn_tag_cleanup_mode=cn_tag_cleanup_mode)
        if s0 > best_s:
            best_s = float(s0)
            best_cov = float(cov0)
            best_name = str(n)

    s = float(best_s)
    # Year proximity
    # Previous behavior penalized large year mismatches too weakly (e.g. 2026 query could still
    # rank 1920s movies very high if the title matched exactly). We keep small mismatches
    # tolerant, but strongly penalize big gaps.
    if query_year and cand.year:
        dy = abs(int(query_year) - int(cand.year))
        if dy == 0:
            s += 0.10
        elif dy == 1:
            s += 0.05
        elif dy == 2:
            s -= 0.02
        elif dy <= 5:
            s -= 0.12
        elif dy <= 10:
            s -= 0.20
        else:
            s -= 0.35
    s = max(0.0, min(1.0, float(s)))
    # Soft-saturate near-perfect title matches to avoid "perfect ties" caused by multilingual/alias matches.
    # We compress scores in [0.985, 1.0) using year proximity + popularity/vote_count as tiny priors.
    if s >= 0.995:
        try:
            extra2 = cand.extra or {}
            vc = cand.vote_count
            if vc is None:
                vc = extra2.get("vote_count")
            try:
                vc_i = int(vc) if vc is not None else 0
            except Exception:
                vc_i = 0
            pop = extra2.get("popularity")
            try:
                pop_f = float(pop) if pop is not None else 0.0
            except Exception:
                pop_f = 0.0

            vc_q = min(1.0, math.log1p(max(vc_i, 0)) / math.log1p(5000.0))
            pop_q = min(1.0, math.log1p(max(pop_f, 0.0)) / math.log1p(100.0))

            year_q = 0.5
            if query_year and cand.year:
                try:
                    dy2 = abs(int(cand.year) - int(query_year))
                    year_q = max(0.0, 1.0 - 0.35 * float(dy2))
                except Exception:
                    year_q = 0.5

            direct_match = 0.0
            try:
                if best_name and cand.title and str(best_name).strip().lower() == str(cand.title).strip().lower():
                    direct_match = 1.0
            except Exception:
                direct_match = 0.0

            q2 = 0.45 * year_q + 0.30 * vc_q + 0.15 * pop_q + 0.10 * direct_match
            q2 = max(0.0, min(1.0, float(q2)))
            s = 0.985 + 0.015 * q2
        except (ValueError, TypeError, AttributeError) as e:
            logger.detail(f"TMDB评分质量计算失败（使用默认） - 原因={type(e).__name__}")

    try:
        if cand.extra is None:
            cand.extra = {}
        m = cand.extra.get("_match")
        if not isinstance(m, dict):
            m = {}
        m["coverage"] = float(best_cov)
        m["matched_name"] = best_name
        cand.extra["_match"] = m
    except Exception:
        logger.detail("异常已抑制", exc_info=True)

    return s, max(0.0, min(1.0, float(best_cov))), best_name


def score_candidate(
    query_title: str,
    query_year: Optional[int],
    cand: Candidate,
    *,
    cn_tag_cleanup_mode: str = "conservative",
) -> float:
    """Score a TMDB candidate against a query title/year."""
    return score_candidate_meta(
        query_title,
        query_year,
        cand,
        cn_tag_cleanup_mode=cn_tag_cleanup_mode,
    )[0]
