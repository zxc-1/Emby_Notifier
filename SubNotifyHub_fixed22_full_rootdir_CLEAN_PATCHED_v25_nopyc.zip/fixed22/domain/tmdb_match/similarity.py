from __future__ import annotations

"""Title similarity primitives (1.5.x compatible).

This module is performance-critical and intentionally tiny.

Design goals (kept consistent with the old 1.5.x tg_bot matcher):
  - Prefer *token coverage* over raw char similarity to avoid prefix collisions.
  - Down-weight ubiquitous tokens via a lightweight IDF computed from the
    candidate set.
  - Keep CJK sequences as a single token (titles usually have no spaces).

Public API:
  - key_tokens
  - compute_idf_weights
  - match_meta -> (score, coverage)
  - title_similarity
"""

import math
import re
from difflib import SequenceMatcher
from typing import Dict, List, Optional, Tuple

from .norm import normalize_title


_EN_STOPWORDS = {
    # English function words
    "the",
    "a",
    "an",
    "of",
    "and",
    "or",
    "to",
    "in",
    "on",
    "at",
    "for",
    "with",
    "from",
    "by",
    "is",
    "are",
    "was",
    "were",
    "be",
    "been",
    "being",
    # High-collision generic words
    "man",
    "men",
    "woman",
    "women",
    # release/junk tokens
    "part",
    "pt",
    "vol",
    "volume",
    "season",
    "series",
    "episode",
    "ep",
    "e",
    "s",
    "complete",
    # CN junk tokens (kept for backwards compatibility)
    "全集",
    "合集",
    "完结",
    "完結",
    "更新",
    "更新至",
    "剧",
    "電影",
    "电影",
    "电视剧",
    "劇集",
}


def _tokenize_norm(s: str, *, cn_tag_cleanup_mode: str = "conservative") -> List[str]:
    """Normalize then tokenize by whitespace.

    Important: we do NOT split CJK into chars. Chinese titles usually have no
    whitespace, so the full title stays as one token and coverage remains a
    useful gating signal.
    """

    t = normalize_title(s, cn_tag_cleanup_mode=cn_tag_cleanup_mode).lower().strip()
    if not t:
        return []
    return [x for x in t.split() if x]


def key_tokens(s: str, *, cn_tag_cleanup_mode: str = "conservative") -> List[str]:
    toks = _tokenize_norm(s, cn_tag_cleanup_mode=cn_tag_cleanup_mode)
    out: List[str] = []
    for x in toks:
        if x in _EN_STOPWORDS:
            continue
        # Drop tiny alnum tokens (but keep CJK)
        if len(x) <= 1 and re.fullmatch(r"[a-z0-9]", x):
            continue
        out.append(x)
    return out


def compute_idf_weights(
    query_tokens: List[str],
    candidate_titles: List[str],
    *,
    cn_tag_cleanup_mode: str = "conservative",
) -> Dict[str, float]:
    """Compute IDF-like weights for query tokens based on the candidate set."""

    q = [t for t in (query_tokens or []) if t]
    if not q or not candidate_titles:
        return {t: 1.0 for t in q}

    sets: List[set] = []
    for ct in candidate_titles:
        sets.append(set(_tokenize_norm(ct, cn_tag_cleanup_mode=cn_tag_cleanup_mode)))

    n = max(1, len(sets))
    out: Dict[str, float] = {}
    for t in q:
        df = sum(1 for s in sets if t in s)
        # Smooth IDF, range ~[1, 1+log(n)]
        out[t] = 1.0 + math.log((n + 1.0) / (df + 1.0))
    return out


def title_similarity(a: str, b: str, *, cn_tag_cleanup_mode: str = "conservative") -> float:
    aa = normalize_title(a, cn_tag_cleanup_mode=cn_tag_cleanup_mode).lower().strip()
    bb = normalize_title(b, cn_tag_cleanup_mode=cn_tag_cleanup_mode).lower().strip()
    if not aa or not bb:
        return 0.0
    return float(SequenceMatcher(None, aa, bb).ratio())


def match_meta(
    query_title: str,
    cand_title: str,
    *,
    idf: Optional[Dict[str, float]] = None,
    cn_tag_cleanup_mode: str = "conservative",
) -> Tuple[float, float]:
    """Return (score, coverage) in [0, 1].

    score blends:
      - weighted token Jaccard
      - weighted query-token coverage
      - lightweight character similarity

    Key property: candidates that only match a generic prefix token are
    penalized when the query has multiple key tokens.
    """

    qn = normalize_title(query_title, cn_tag_cleanup_mode=cn_tag_cleanup_mode).lower().strip()
    cn = normalize_title(cand_title, cn_tag_cleanup_mode=cn_tag_cleanup_mode).lower().strip()
    if not qn or not cn:
        return 0.0, 0.0

    q_tokens = key_tokens(qn, cn_tag_cleanup_mode=cn_tag_cleanup_mode)
    c_tokens = set(_tokenize_norm(cn, cn_tag_cleanup_mode=cn_tag_cleanup_mode))

    ratio = float(SequenceMatcher(None, qn, cn).ratio())
    if not q_tokens:
        # Query too short after filtering: fall back to char ratio.
        return ratio, 0.0

    w = idf or {t: 1.0 for t in q_tokens}
    total_w = sum(float(w.get(t, 1.0)) for t in q_tokens) or 1.0
    inter_w = sum(float(w.get(t, 1.0)) for t in q_tokens if t in c_tokens)
    coverage = float(inter_w) / float(total_w)

    # Weighted Jaccard (query tokens dominate; candidate-only tokens add to union).
    # P0 fix: increase penalty for extra tokens in candidate title.
    # Old: 0.35 per extra token was too lenient, causing "Rap Star Dream Maker" to
    # score high against "The Dream Maker" (coverage=1.0 but 2 extra tokens).
    # New: 0.55 per extra token, plus additional ratio penalty when extras >= 2.
    cand_extra = [t for t in c_tokens if t not in q_tokens]
    extra_penalty_per_token = 0.55
    union_w = total_w + sum(extra_penalty_per_token for _ in cand_extra)
    jacc = float(inter_w) / float(union_w or 1.0)

    score = 0.62 * jacc + 0.28 * coverage + 0.10 * ratio

    # Additional penalty: if candidate has 2+ extra tokens, it's likely a different work
    # with a similar substring (e.g., "Rap Star Dream Maker" vs "The Dream Maker").
    if len(cand_extra) >= 2:
        score = score * 0.88

    # Penalize "only matched a generic token" cases.
    if len(q_tokens) >= 2 and coverage < 0.5:
        score = min(score, 0.75)
        score = max(0.0, score - 0.12)

    return max(0.0, min(1.0, float(score))), max(0.0, min(1.0, float(coverage)))
