from __future__ import annotations

"""Application-layer error types.

These errors represent failures in orchestration/integration that are not
pure domain rule violations.
"""

from core.exceptions.base import AppException


class AppError(AppException):
    """Base class for application errors."""

    category = "application"


class ConfigError(AppError):
    """Invalid or missing configuration."""

    category = "configuration"


class TemporaryError(AppError):
    """Transient failure; safe to retry."""

    category = "temporary"


class PermissionError(AppError):
    """Access denied."""

    category = "permission"
