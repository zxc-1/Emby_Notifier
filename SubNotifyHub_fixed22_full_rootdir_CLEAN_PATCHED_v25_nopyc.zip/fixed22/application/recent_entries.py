from __future__ import annotations
from core.task_registry import create_task_logged

"""Recent entries store.

This used to live in :mod:`core.recent_entries`, but the implementation depends on
feature-layer types (``domain.models.NotificationContent``). Keeping it inside
``core`` caused a reverse dependency (core -> notifier) which hurts long-term
maintainability.

We keep the implementation identical and only relocate it to the application
layer so ``core`` can remain infrastructure-only.
"""

import asyncio
import json
import logging
from core.logging import get_biz_logger_adapter
from collections import deque
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from ports.settings_provider import get_settings

from domain.utils.episode_agg import format_episode_keys
from domain.models import NotificationContent
from domain.utils.code import extract_code

from core.env_utils import env_float, env_int
from core.storage import load_json, save_json
from core.storage import file_lock
from core.cache import PosterCache

logger = get_biz_logger_adapter(__name__)


def _build_adult_detail_url(code: Optional[str]) -> Optional[str]:
    """Build adult detail URL in a structured way.

    Priority:
    1) Settings.ADULT_DETAIL_BASE_URL + {code}
    """

    try:
        settings = get_settings()
        base = getattr(settings, "ADULT_DETAIL_BASE_URL", None)
        if not base or not code:
            return None
        base_s = str(base)
        if "{code}" in base_s:
            return base_s.format(code=code)
        return base_s.rstrip("/") + "/" + str(code)
    except (ValueError, TypeError, AttributeError, KeyError) as e:
        logger.detail(f"成人详情 URL 构建失败（已忽略） - code={code}, 原因={type(e).__name__}")
        return None


def _compact_episode_entries(items: List[NotificationContent]) -> List[NotificationContent]:
    """Collapse multiple Episode entries of the same series+season into one UI entry.

    Keeps the newest entry's cover/detail/meta, and rewrites display_title to:
    - 1 ep: Series S01E16
    - continuous: Series S01E10-S01E16
    - non-continuous: Series S01E10 / S01E12 / ...
    """

    # First pass: collect episodes per (series_name, season, library)
    groups: dict[tuple[str, int, str], dict[str, object]] = {}
    for e in items:
        try:
            mt = str(getattr(e, "media_type", "") or "").lower()
            if mt != "episode":
                continue
            series = (getattr(e, "series_name", None) or "").strip()
            if not series:
                continue
            sn = getattr(e, "season_number", None)
            en = getattr(e, "episode_number", None)
            if sn is None or en is None:
                continue
            key = (series, int(sn), str(getattr(e, "library_name", "") or ""))
            g = groups.get(key)
            if g is None:
                # base uses the first (newest) occurrence
                groups[key] = {"base": e, "eps": [(int(sn), int(en))]}
            else:
                g["eps"].append((int(sn), int(en)))
        except (ValueError, TypeError, AttributeError) as e_inner:
            logger.detail(f"剧集分组失败（跳过） - 原因={type(e_inner).__name__}")
            continue

    # Second pass: build a compacted list preserving original order (newest-first)
    out: List[NotificationContent] = []
    emitted: set[tuple[str, int, str]] = set()
    for e in items:
        try:
            mt = str(getattr(e, "media_type", "") or "").lower()
            if mt != "episode":
                out.append(e)
                continue

            series = (getattr(e, "series_name", None) or "").strip()
            sn = getattr(e, "season_number", None)
            en = getattr(e, "episode_number", None)
            if not series or sn is None or en is None:
                out.append(e)
                continue

            key = (series, int(sn), str(getattr(e, "library_name", "") or ""))
            if key in emitted:
                continue
            emitted.add(key)

            g = groups.get(key)
            if not g:
                out.append(e)
                continue

            base = g["base"]  # newest entry
            eps = g["eps"]
            details = format_episode_keys(eps)
            if not details:
                # fallback to current one
                details = f"S{int(sn):02d}E{int(en):02d}"

            try:
                data = base.model_dump() if hasattr(base, "model_dump") else base.dict()
                data["display_title"] = f"{series} {details}"
                out.append(NotificationContent(**data))
            except (ValueError, TypeError, AttributeError) as e:
                logger.detail(f"剧集条目合并失败（使用原始条目） - series={series}, details={details}, 原因={type(e).__name__}")
                base.display_title = f"{series} {details}"
                out.append(base)
        except (ValueError, TypeError, AttributeError, KeyError) as e:
            logger.detail(f"剧集条目处理失败（保留原始条目） - 原因={type(e).__name__}")
            out.append(e)

    return out


@dataclass
class RecentEntriesConfig:
    store_max: int = 50
    display_max: int = 12
    api_max: int = 50


class RecentEntriesStore:
    """In-memory + on-disk store for recent NotificationContent entries.

    - Mutations/snapshots are protected by an asyncio.Lock (safe under worker concurrency).
    - Disk writes are debounced and executed in a thread to reduce event-loop blocking.
    """

    def __init__(
        self,
        store_path: Path,
        poster_cache: PosterCache,
        cfg: RecentEntriesConfig,
    ) -> None:
        self.store_path = store_path
        self.poster_cache = poster_cache
        self.cfg = cfg
        self._dq: deque[NotificationContent] = deque(maxlen=self.cfg.store_max)

        # Cross-process guard for the on-disk JSON store (read/write + atomic replace).
        # This prevents partial reads during writes and reduces lost updates.
        try:
            sp = self.store_path
            if sp.suffix:
                self._disk_lock_path = sp.with_suffix(sp.suffix + ".lock")
            else:
                self._disk_lock_path = sp.parent / (sp.name + ".lock")
        except (OSError, ValueError, AttributeError) as e:
            logger.detail(f"锁文件路径生成失败（使用默认路径） - store_path={self.store_path}, 原因={type(e).__name__}")
            self._disk_lock_path = self.store_path.parent / (self.store_path.name + ".lock")

        self._lock = asyncio.Lock()
        self._save_event = asyncio.Event()
        self._save_task: Optional[asyncio.Task] = None
        self._save_debounce_s = env_float("RECENT_ENTRIES_SAVE_DEBOUNCE", 0.8, min_value=0.0)
        self._closed: bool = False
        self._cover_tasks: set[asyncio.Task] = set()
        # Background cover preparation can involve network/disk IO.
        # Keep it best-effort AND bounded so it doesn't create too many concurrent tasks.
        n = env_int("RECENT_COVER_CONCURRENCY", 3, min_value=1, max_value=8)
        self._cover_sem = asyncio.Semaphore(n)
        # Whether to compact Episode entries of same series+season into one UI line.
        # Default: OFF ("入库一集就是一集"). Set RECENT_EPISODE_COMPACT=1 to enable legacy behavior.
        self._compact_episodes = bool(env_int("RECENT_EPISODE_COMPACT", 0, min_value=0, max_value=1))

    def _ensure_save_task(self) -> None:
        if self._closed:
            return
        if self._save_task is None or self._save_task.done():
            self._save_task = create_task_logged(self._save_loop(), name="recent_entries_save", log=logger)

    async def _save_loop(self) -> None:
        """Coalesce multiple save requests into a single disk write."""
        try:
            while True:
                await self._save_event.wait()
                self._save_event.clear()

                await asyncio.sleep(self._save_debounce_s)

                # drain bursts
                while self._save_event.is_set():
                    self._save_event.clear()
                    await asyncio.sleep(self._save_debounce_s)

                async with self._lock:
                    await asyncio.to_thread(self._save_sync)
        except asyncio.CancelledError:
            try:
                if self._save_event.is_set():
                    async with self._lock:
                        await asyncio.to_thread(self._save_sync)
            except (OSError, ValueError, TypeError) as e:
                logger.detail(f"最终保存失败（已忽略） - 原因={type(e).__name__}")
            raise
        except (OSError, ValueError, TypeError, asyncio.CancelledError) as e:
            logger.detail(f"保存循环崩溃 - 原因={type(e).__name__}")

    def stop_accepting(self) -> None:
        """Prevent new entries/saves from being scheduled (used during shutdown)."""
        self._closed = True

    def _schedule_cover(self, content: NotificationContent) -> None:
        """Best-effort background cover preparation (never blocks the notification path)."""
        if self._closed:
            return

        async def _runner() -> None:
            try:
                async with self._cover_sem:
                    await self.poster_cache.ensure_web_cover(content)
            except (OSError, ValueError, TypeError, asyncio.TimeoutError) as e:
                logger.detail(f"封面准备失败（已忽略） - 原因={type(e).__name__}")

        try:
            t = create_task_logged(_runner(), name="recent_entries_cover", log=logger)
            self._cover_tasks.add(t)
            t.add_done_callback(lambda _t: self._cover_tasks.discard(_t))
        except (RuntimeError, ValueError) as e:
            # create_task can fail if loop is closing
            logger.detail(f"封面任务调度失败（已忽略） - 原因={type(e).__name__}")

    async def close(self) -> None:
        """Persist the latest state and stop background tasks (best-effort)."""

        # Mark closed first: prevent push()/replace_series_entries() from creating new tasks during shutdown.
        self._closed = True

        # Force an immediate save of the current deque snapshot.
        try:
            async with self._lock:
                await asyncio.to_thread(self._save_sync)
        except asyncio.CancelledError:
            logger.detail("最近入库记录：forced 保存 cancelled during 关闭")
        except (OSError, ValueError, TypeError) as e:
            logger.detail(f"强制保存失败（已忽略） - 原因={type(e).__name__}")

        if self._save_task is not None and not self._save_task.done():
            self._save_task.cancel()
            try:
                await self._save_task
            except asyncio.CancelledError:
                pass
            except (OSError, ValueError, TypeError) as e:
                logger.detail(f"保存任务等待失败（已忽略） - 原因={type(e).__name__}")

        # best-effort: wait for cover tasks
        try:
            if self._cover_tasks:
                await asyncio.wait(self._cover_tasks, timeout=5)
        except (asyncio.TimeoutError, asyncio.CancelledError) as e:
            logger.detail(f"封面任务等待超时（已忽略） - 原因={type(e).__name__}")

    async def load(self) -> None:
        try:
            def _load_locked():
                with file_lock(self._disk_lock_path):
                    return load_json(self.store_path, default=None)

            data = await asyncio.to_thread(_load_locked)
            if not data:
                return
            items = []
            needs_migration = False
            for x in data:
                try:
                    # 迁移：为缺少 added_at 的旧条目补充时间戳
                    if isinstance(x, dict) and not x.get("added_at"):
                        from datetime import datetime, timezone
                        x["added_at"] = datetime.now(timezone.utc).isoformat()
                        needs_migration = True
                    items.append(NotificationContent(**x))
                except (ValueError, TypeError, KeyError) as e:
                    logger.detail(f"通知内容解析失败（跳过） - data={x if isinstance(x, dict) else type(x)}, 原因={type(e).__name__}")
                    continue
            async with self._lock:
                self._dq.clear()
                for it in items[: self.cfg.store_max]:
                    self._dq.append(it)
            # 如果有迁移，立即保存
            if needs_migration:
                logger.detail(f"迁移旧条目 added_at 字段完成，共 {len(items)} 条")
                await self._request_save()
        except (OSError, ValueError, TypeError, json.JSONDecodeError) as e:
            logger.detail(f"最近条目加载失败（已忽略） - 原因={type(e).__name__}")

    def _save_sync(self) -> None:
        try:
            snap = [e.model_dump() if hasattr(e, "model_dump") else e.dict() for e in list(self._dq)]
            with file_lock(self._disk_lock_path):
                save_json(self.store_path, snap)
        except (OSError, ValueError, TypeError) as e:
            logger.detail(f"最近条目保存失败（已忽略） - 原因={type(e).__name__}")

    async def _request_save(self) -> None:
        self._ensure_save_task()
        self._save_event.set()

    async def push(self, content: NotificationContent) -> None:
        """Push a new entry (newest first)."""
        # 设置入库时间戳（如果未设置）
        if not getattr(content, "added_at", None):
            from datetime import datetime, timezone
            content.added_at = datetime.now(timezone.utc).isoformat()
        
        async with self._lock:
            self._dq.appendleft(content)

        # Enrich/prepare cover in the background.
        self._schedule_cover(content)

        await self._request_save()

    async def replace_series_entries(self, series_name: str, items: List[NotificationContent]) -> None:
        """Replace entries of a series with a new list (used by refresh jobs)."""
        series_name = (series_name or "").strip()
        if not series_name:
            return

        async with self._lock:
            keep: deque[NotificationContent] = deque(maxlen=self.cfg.store_max)
            for e in self._dq:
                if (getattr(e, "series_name", None) or "").strip() != series_name:
                    keep.append(e)

            # items are expected newest-first
            for it in items:
                keep.appendleft(it)

            self._dq = keep

        for it in items:
            self._schedule_cover(it)
        await self._request_save()

    async def list_for_ui(self) -> List[NotificationContent]:
        async with self._lock:
            items = list(self._dq)[: self.cfg.display_max]

        # Optional: compact episode entries for UI friendliness.
        if self._compact_episodes:
            items = _compact_episode_entries(items)

        # Enrich UI fields.
        out: List[NotificationContent] = []
        for e in items:
            try:
                # Fill adult_detail_url if absent.
                if not getattr(e, "adult_detail_url", None):
                    # `extract_code` expects a string. `e` is a NotificationContent.
                    # Prefer item_path (most precise), then display_title/text as fallbacks.
                    src = (
                        getattr(e, "item_path", None)
                        or getattr(e, "display_title", None)
                        or getattr(e, "text", None)
                        or ""
                    )
                    code = extract_code(src)
                    url = _build_adult_detail_url(code)
                    if url:
                        e.adult_detail_url = url
            except (ValueError, TypeError, AttributeError) as e:
                logger.detail(f"成人详情 URL 填充失败（已忽略） - 原因={type(e).__name__}")
            out.append(e)
        return out

    async def list_for_api(self) -> List[NotificationContent]:
        async with self._lock:
            return list(self._dq)[: self.cfg.api_max]

    # ---------------------------------------------------------------------
    # Backward-compatible helpers (used by older admin UI routes)
    # ---------------------------------------------------------------------
    async def snapshot(self) -> List[NotificationContent]:
        """Return a snapshot (newest-first)."""
        async with self._lock:
            return list(self._dq)

    async def total_count(self) -> int:
        async with self._lock:
            return len(self._dq)

    async def for_ui_render(self, display_max: int = 12):
        """Return (items_for_ui, total_count) for server-side template render."""
        items = await self.list_for_ui()
        try:
            if display_max and display_max > 0:
                items = items[: int(display_max)]
        except (ValueError, TypeError) as e:
            logger.detail(f"显示数量限制失败（使用全部） - display_max={display_max}, 原因={type(e).__name__}")
        total = await self.total_count()
        return items, total

    async def to_api_payload(self) -> Dict[str, Any]:
        """Return a JSON payload for /admin/recent.json polling."""
        items = await self.list_for_api()
        total = await self.total_count()

        out: List[Dict[str, Any]] = []
        for e in items:
            try:
                if hasattr(e, "model_dump"):
                    data = e.model_dump()  # type: ignore[attr-defined]
                else:
                    data = e.dict()  # type: ignore[attr-defined]
                # Add poster_url field (prefer web_cover_url, fallback to cover_url/poster_url).
                # If still missing, use a local placeholder so the dashboard doesn't look broken.
                poster_url = (
                    data.get("web_cover_url")
                    or data.get("cover_url")
                    or data.get("poster_url")
                )
                data["poster_url"] = poster_url or "/static/img/poster_placeholder.svg"
                out.append(data)
            except (ValueError, TypeError, AttributeError) as e_inner:
                # last-resort: best-effort attrs
                logger.detail(f"条目序列化失败（使用备用方案） - 原因={type(e_inner).__name__}")
                web_cover = getattr(e, "web_cover_url", None)
                cover = getattr(e, "cover_url", None)
                poster = getattr(e, "poster_url", None)
                out.append({
                    "media_type": getattr(e, "media_type", None),
                    "display_title": getattr(e, "display_title", None),
                    "text": getattr(e, "text", None),
                    "display_meta_line": getattr(e, "display_meta_line", None),
                    "is_adult": bool(getattr(e, "is_adult", False)),
                    "detail_url": getattr(e, "detail_url", None),
                    "web_cover_url": web_cover,
                    "cover_url": cover,
                    "poster_url": web_cover or cover or poster or "/static/img/poster_placeholder.svg",
                })

        return {"ok": True, "count": len(out), "total": int(total), "items": out}
