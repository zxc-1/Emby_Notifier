from __future__ import annotations

import logging
from core.logging import get_biz_logger_adapter
logger = get_biz_logger_adapter(__name__)

import time
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Optional

from core.dedup_key import compute_enqueue_dedup
from core.logging import get_trace_id
from core.metrics import metrics
from ports.contracts import WorkerPort
from ports.settings_provider import get_settings


@dataclass(frozen=True)
class IngestWebhookResult:
    status: str  # ACCEPTED | DUPLICATE | QUEUE_FULL | STOPPED | ERROR
    dedup_key: str = ""
    item_id: str = ""
    item_name: str = ""
    created_raw: str = ""


def _extract_item_fields(payload: Any) -> tuple[str, str, str]:
    """Best-effort extraction for logs/metrics."""
    try:
        if isinstance(payload, dict):
            item = payload.get("Item") or payload.get("item") or {}
            if not isinstance(item, dict):
                return "", "", ""
            item_id = str(item.get("Id") or item.get("id") or "")
            item_name = str(item.get("Name") or item.get("name") or "")
            created_raw = str(item.get("DateCreated") or item.get("DateAdded") or item.get("PremiereDate") or "")
            return item_id, item_name, created_raw
    except (ValueError, TypeError, AttributeError, KeyError) as e:
        logger.detail(f"条目字段提取失败（返回空值） - 原因={type(e).__name__}")
    return "", "", ""


async def ingest_emby_webhook(
    payload: Any,
    *,
    ctx: Any,
    worker: WorkerPort,
    deduper: Any = None,
    started_monotonic: Optional[float] = None,
) -> IngestWebhookResult:
    """Validate/dedup/enqueue an Emby webhook payload.

    The API layer should only:
      - verify request signature
      - parse JSON
      - fetch ctx/worker
      - call this usecase and map result to HTTP response
    """
    t0 = started_monotonic if started_monotonic is not None else time.monotonic()

    # webhook-level metrics (worker.enqueue() records enqueue_* metrics)
    try:
        metrics.inc("webhook_received")
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"指标记录失败（已忽略） - metric=webhook_received, 原因={type(e).__name__}")

    item_id, item_name, created_raw = _extract_item_fields(payload)

    # Compute dedup key (shared semantics with worker/direct notifications)
    episode_strategy = getattr(get_settings(), "EPISODE_DEDUP_STRATEGY", "default")
    dedup_key, _, _ = compute_enqueue_dedup(payload, episode_strategy=episode_strategy)

    # IMPORTANT: do NOT mark dedup BEFORE enqueue succeeds.
    if dedup_key and deduper is not None:
        try:
            if getattr(deduper, "is_duplicate", None) and deduper.is_duplicate(dedup_key):
                try:
                    metrics.inc("webhook_duplicate_dropped")
                except (ValueError, TypeError, AttributeError) as e:
                    logger.detail(f"指标记录失败（已忽略） - metric=webhook_duplicate_dropped, 原因={type(e).__name__}")
                return IngestWebhookResult(
                    status="DUPLICATE",
                    dedup_key=dedup_key,
                    item_id=item_id,
                    item_name=item_name,
                    created_raw=created_raw,
                )
        except (ValueError, TypeError, AttributeError) as e:
            # If dedup check fails, proceed with enqueue (fail-open).
            logger.detail(f"去重检查失败（继续入队） - dedup_key={dedup_key}, 原因={type(e).__name__}")

    # Ensure trace_id is passed downstream for queue processing logs.
    if isinstance(payload, dict):
        try:
            payload = dict(payload)
            payload.setdefault("_trace_id", get_trace_id())
            payload.setdefault("_source", "emby")
            payload.setdefault("_kind", "webhook")
        except (ValueError, TypeError, AttributeError) as e:
            logger.detail(f"payload 元数据设置失败（已忽略） - 原因={type(e).__name__}")

    res = await worker.enqueue(payload)
    ok = bool(getattr(res, "ok", False))

    try:
        metrics.observe("webhook_enqueue_ms", (time.monotonic() - t0) * 1000.0)
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"指标记录失败（已忽略） - metric=webhook_enqueue_ms, 原因={type(e).__name__}")

    if ok and dedup_key and deduper is not None:
        try:
            if getattr(deduper, "mark", None):
                deduper.mark(dedup_key)
        except (ValueError, TypeError, AttributeError) as e:
            logger.detail(f"去重标记失败（已忽略） - dedup_key={dedup_key}, 原因={type(e).__name__}")

    if ok:
        # Record recent webhook time for health/debug counters.
        try:
            dq = getattr(ctx, "recent_webhook_times", None)
            if dq is not None:
                dq.append(datetime.now(timezone.utc).timestamp())
        except (ValueError, TypeError, AttributeError) as e:
            logger.detail(f"webhook 时间记录失败（已忽略） - 原因={type(e).__name__}")

    st = "ACCEPTED" if ok else "ERROR"
    try:
        status = getattr(res, "status", None)
        if status is not None:
            # EnqueueStatus is a str Enum. `str(enum_member)` is usually
            # like "EnqueueStatus.QUEUE_FULL" which does NOT contain the
            # desired lowercase tokens. Prefer .value when available and
            # normalize to lowercase for robust matching.
            raw = getattr(status, "value", status)
            s = str(raw).strip().lower()
            if "duplicate" in s:
                st = "DUPLICATE"
            elif "queue_full" in s:
                st = "QUEUE_FULL"
            elif "stopped" in s:
                st = "STOPPED"
            elif ok:
                st = "ACCEPTED"
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"状态解析失败（使用默认值） - 原因={type(e).__name__}")

    return IngestWebhookResult(
        status=st,
        dedup_key=dedup_key,
        item_id=item_id,
        item_name=item_name,
        created_raw=created_raw,
    )
