"""Evidence level management for TMDB recognition.

This module contains functions for:
- Detecting count mismatch in 115 API responses (Requirement 15.1)
- Downgrading evidence level when count mismatch detected (Requirement 15.2)
- Computing evidence level from share evidence (Requirement 15.3)

Evidence Levels:
- L0: No evidence (API unavailable)
- L1: Weak evidence (only share title, no video samples)
- L2: Medium evidence (video samples but incomplete)
- L3: Strong evidence (complete video samples with SxxEyy patterns)
"""

from __future__ import annotations

from enum import IntEnum
from typing import Any, Dict, List, Optional, Tuple

from core.logging import get_biz_logger_adapter

logger = get_biz_logger_adapter(__name__)


class EvidenceLevel(IntEnum):
    """Evidence level enumeration."""
    L0_UNAVAILABLE = 0
    L1_WEAK = 1
    L2_MEDIUM = 2
    L3_STRONG = 3


def detect_count_mismatch(
    reported_count: int,
    actual_count: int,
    tolerance: float = 0.1,
) -> Tuple[bool, Dict[str, Any]]:
    """Detect count mismatch between 115 API reported count and actual items (Requirement 15.1).
    
    When 115 API reports video_count != actual paged items, this indicates
    potential paging issues that could affect evidence quality.
    
    Args:
        reported_count: Count reported by 115 API
        actual_count: Actual number of items retrieved
        tolerance: Allowed tolerance ratio (default 10%)
    
    Returns:
        Tuple of (is_mismatch, details)
    """
    if reported_count <= 0 or actual_count <= 0:
        return False, {
            "reported_count": reported_count,
            "actual_count": actual_count,
            "reason": "invalid_counts",
        }
    
    # Calculate difference
    diff = abs(reported_count - actual_count)
    diff_ratio = diff / max(reported_count, actual_count)
    
    # Check if mismatch exceeds tolerance
    is_mismatch = diff_ratio > tolerance
    
    return is_mismatch, {
        "reported_count": reported_count,
        "actual_count": actual_count,
        "difference": diff,
        "diff_ratio": round(diff_ratio, 3),
        "tolerance": tolerance,
        "is_mismatch": is_mismatch,
    }


def downgrade_evidence_level(
    current_level: int,
    count_mismatch: bool = False,
    min_level: int = 1,
) -> Tuple[int, Optional[str]]:
    """Downgrade evidence level when count mismatch detected (Requirement 15.2).
    
    When count_mismatch is True, evidence_level is downgraded by 1
    (but not below L1).
    
    Args:
        current_level: Current evidence level (0-3)
        count_mismatch: True if count mismatch detected
        min_level: Minimum level to downgrade to (default L1)
    
    Returns:
        Tuple of (new_level, downgrade_reason)
    """
    if not count_mismatch:
        return current_level, None
    
    # If already at or below min_level, no downgrade possible
    if current_level <= min_level:
        return max(current_level, min_level), None
    
    new_level = max(min_level, current_level - 1)
    
    if new_level < current_level:
        reason = f"count_mismatch:L{current_level}->L{new_level}"
        return new_level, reason
    
    return current_level, None


def compute_evidence_level(
    has_video_samples: bool,
    video_sample_count: int,
    standard_rate: float,
    has_episode_pattern: bool,
    count_mismatch: bool = False,
    api_available: bool = True,
) -> Tuple[int, str]:
    """Compute evidence level from share evidence (Requirement 15.3).
    
    Args:
        has_video_samples: True if video samples are available
        video_sample_count: Number of video samples
        standard_rate: Rate of SxxEyy pattern matches
        has_episode_pattern: True if episode patterns detected
        count_mismatch: True if count mismatch detected
        api_available: True if 115 API is available
    
    Returns:
        Tuple of (evidence_level, description)
    """
    if not api_available:
        return EvidenceLevel.L0_UNAVAILABLE, "api_unavailable"
    
    if not has_video_samples or video_sample_count == 0:
        return EvidenceLevel.L1_WEAK, "no_video_samples"
    
    # Determine base level
    if standard_rate >= 0.85 and has_episode_pattern and video_sample_count >= 3:
        base_level = EvidenceLevel.L3_STRONG
        desc = "strong_episode_evidence"
    elif video_sample_count >= 2:
        base_level = EvidenceLevel.L2_MEDIUM
        desc = "medium_video_samples"
    else:
        base_level = EvidenceLevel.L1_WEAK
        desc = "weak_single_sample"
    
    # Apply count mismatch downgrade
    final_level, downgrade_reason = downgrade_evidence_level(
        base_level, count_mismatch
    )
    
    if downgrade_reason:
        desc = f"{desc}:{downgrade_reason}"
    
    return final_level, desc


def should_block_autopick_by_evidence(
    evidence_level: int,
    score: float,
    count_mismatch: bool = False,
) -> Tuple[bool, Optional[str]]:
    """Check if auto-pick should be blocked based on evidence (Requirement 15.2, 15.3).
    
    Args:
        evidence_level: Current evidence level
        score: Top candidate score
        count_mismatch: True if count mismatch detected
    
    Returns:
        Tuple of (should_block, reason)
    """
    # L0/L1 always blocks
    if evidence_level <= 1:
        return True, f"evidence_level_L{evidence_level}"
    
    # Count mismatch with low score blocks
    if count_mismatch and score < 0.92:
        return True, f"count_mismatch_low_score:{score:.3f}<0.92"
    
    return False, None


def format_evidence_level_desc(level: int) -> str:
    """Format evidence level as human-readable description.
    
    Args:
        level: Evidence level (0-3)
    
    Returns:
        Human-readable description
    """
    descriptions = {
        0: "L0: API unavailable",
        1: "L1: Weak (share title only)",
        2: "L2: Medium (video samples)",
        3: "L3: Strong (episode patterns)",
    }
    return descriptions.get(level, f"L{level}: Unknown")
