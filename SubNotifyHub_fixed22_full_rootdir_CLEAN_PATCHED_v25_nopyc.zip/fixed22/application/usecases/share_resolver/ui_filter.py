"""UI filter module for TMDB candidate display.

This module handles filtering and sorting candidates for UI display:
- Filter candidates below score/coverage thresholds
- Filter garbage titles
- Ensure top-1 is always included
- Limit maximum candidates shown

Extracted from tmdb_lookup.py for better maintainability.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from core.logging import get_biz_logger_adapter

from .hints import _is_garbage_hint

logger = get_biz_logger_adapter(__name__)


# Default thresholds
DEFAULT_MIN_SCORE = 0.60
DEFAULT_MIN_COVERAGE = 0.45
DEFAULT_MAX_SHOW = 8


def is_ui_keepable(
    candidate: Dict[str, Any],
    min_score: float = DEFAULT_MIN_SCORE,
    min_coverage: float = DEFAULT_MIN_COVERAGE,
) -> bool:
    """Check if a candidate should be kept for UI display.
    
    A candidate is keepable if:
    1. Score >= min_score (default 0.60)
    2. Coverage >= min_coverage (default 0.45)
    3. Title is not garbage
    
    Args:
        candidate: Candidate dict with score, coverage, title/name
        min_score: Minimum score threshold
        min_coverage: Minimum coverage threshold
    
    Returns:
        True if candidate should be shown in UI
    """
    if not isinstance(candidate, dict):
        return False
    
    # Get score (prefer fused_score)
    try:
        fused = candidate.get("_fused_score")
        if fused is not None:
            sc = float(fused)
        else:
            sc = float(candidate.get("score") or 0.0)
    except (ValueError, TypeError):
        sc = 0.0
    
    # Get coverage
    try:
        cov = float(candidate.get("coverage") or 0.0)
    except (ValueError, TypeError):
        cov = 0.0
    
    # Check title
    title = str(candidate.get("title") or candidate.get("name") or "").strip()
    if _is_garbage_hint(title):
        return False
    
    # Check thresholds
    return sc >= min_score and cov >= min_coverage


def filter_for_ui(
    candidates: List[Dict[str, Any]],
    min_score: float = DEFAULT_MIN_SCORE,
    min_coverage: float = DEFAULT_MIN_COVERAGE,
    max_show: int = DEFAULT_MAX_SHOW,
) -> List[Dict[str, Any]]:
    """Filter candidates for UI display.
    
    Rules:
    1. Filter candidates below score/coverage thresholds
    2. Filter garbage titles
    3. If nothing passes threshold, show top-N raw candidates
    4. Always include top-1 candidate (even if below threshold)
    5. Limit to max_show candidates
    
    Args:
        candidates: List of candidate dicts, assumed sorted by score descending
        min_score: Minimum score threshold (default 0.60)
        min_coverage: Minimum coverage threshold (default 0.45)
        max_show: Maximum candidates to show (default 8)
    
    Returns:
        Filtered list of candidates for UI display
    """
    if not candidates:
        return []
    
    # Filter by threshold
    pruned = [
        c for c in candidates
        if isinstance(c, dict) and is_ui_keepable(c, min_score, min_coverage)
    ]
    
    # If nothing passes threshold, show top-N raw candidates
    if not pruned:
        return candidates[:max_show]
    
    # Ensure top-1 is included
    top1 = candidates[0] if candidates else None
    if top1 and top1 not in pruned:
        pruned.insert(0, top1)
    
    # Limit to max_show
    return pruned[:max_show]


def get_ui_candidates(
    candidates: List[Dict[str, Any]],
    min_score: float = DEFAULT_MIN_SCORE,
    min_coverage: float = DEFAULT_MIN_COVERAGE,
    max_show: int = DEFAULT_MAX_SHOW,
    sort_by_fused: bool = True,
) -> Dict[str, Any]:
    """Get candidates for UI display with metadata.
    
    Args:
        candidates: List of candidate dicts
        min_score: Minimum score threshold
        min_coverage: Minimum coverage threshold
        max_show: Maximum candidates to show
        sort_by_fused: If True, sort by _fused_score first
    
    Returns:
        Dict with:
        - candidates: Filtered candidate list
        - total_count: Total candidates before filtering
        - filtered_count: Candidates after filtering
        - threshold_applied: True if threshold filtering was applied
        - top1_included: True if top-1 was force-included
    """
    if not candidates:
        return {
            "candidates": [],
            "total_count": 0,
            "filtered_count": 0,
            "threshold_applied": False,
            "top1_included": False,
        }
    
    # Sort if needed
    if sort_by_fused:
        candidates = sorted(
            candidates,
            key=lambda x: float(
                x.get("_fused_score")
                if x.get("_fused_score") is not None
                else x.get("score") or 0
            ),
            reverse=True,
        )
    
    total_count = len(candidates)
    
    # Filter by threshold
    pruned = [
        c for c in candidates
        if isinstance(c, dict) and is_ui_keepable(c, min_score, min_coverage)
    ]
    
    threshold_applied = len(pruned) < total_count
    
    # Handle empty pruned list
    if not pruned:
        return {
            "candidates": candidates[:max_show],
            "total_count": total_count,
            "filtered_count": min(total_count, max_show),
            "threshold_applied": False,  # Threshold not applied (fallback)
            "top1_included": True,
        }
    
    # Check if top-1 needs to be force-included
    top1 = candidates[0] if candidates else None
    top1_included = False
    
    if top1 and top1 not in pruned:
        pruned.insert(0, top1)
        top1_included = True
    
    # Limit to max_show
    result = pruned[:max_show]
    
    return {
        "candidates": result,
        "total_count": total_count,
        "filtered_count": len(result),
        "threshold_applied": threshold_applied,
        "top1_included": top1_included,
    }


def compute_ui_stats(
    candidates: List[Dict[str, Any]],
    min_score: float = DEFAULT_MIN_SCORE,
    min_coverage: float = DEFAULT_MIN_COVERAGE,
) -> Dict[str, Any]:
    """Compute statistics about candidates for UI display.
    
    Args:
        candidates: List of candidate dicts
        min_score: Minimum score threshold
        min_coverage: Minimum coverage threshold
    
    Returns:
        Dict with:
        - total: Total candidate count
        - above_threshold: Count above threshold
        - below_threshold: Count below threshold
        - garbage_titles: Count with garbage titles
        - top1_score: Score of top-1 candidate
        - top1_coverage: Coverage of top-1 candidate
        - top1_passes: True if top-1 passes threshold
    """
    if not candidates:
        return {
            "total": 0,
            "above_threshold": 0,
            "below_threshold": 0,
            "garbage_titles": 0,
            "top1_score": 0.0,
            "top1_coverage": 0.0,
            "top1_passes": False,
        }
    
    above = 0
    below = 0
    garbage = 0
    
    for c in candidates:
        if not isinstance(c, dict):
            continue
        
        title = str(c.get("title") or c.get("name") or "").strip()
        if _is_garbage_hint(title):
            garbage += 1
            continue
        
        try:
            fused = c.get("_fused_score")
            if fused is not None:
                sc = float(fused)
            else:
                sc = float(c.get("score") or 0.0)
        except (ValueError, TypeError):
            sc = 0.0
        
        try:
            cov = float(c.get("coverage") or 0.0)
        except (ValueError, TypeError):
            cov = 0.0
        
        if sc >= min_score and cov >= min_coverage:
            above += 1
        else:
            below += 1
    
    # Top-1 stats
    top1 = candidates[0] if candidates else {}
    try:
        fused = top1.get("_fused_score")
        if fused is not None:
            top1_score = float(fused)
        else:
            top1_score = float(top1.get("score") or 0.0)
    except (ValueError, TypeError):
        top1_score = 0.0
    
    try:
        top1_coverage = float(top1.get("coverage") or 0.0)
    except (ValueError, TypeError):
        top1_coverage = 0.0
    
    top1_passes = is_ui_keepable(top1, min_score, min_coverage) if top1 else False
    
    return {
        "total": len(candidates),
        "above_threshold": above,
        "below_threshold": below,
        "garbage_titles": garbage,
        "top1_score": top1_score,
        "top1_coverage": top1_coverage,
        "top1_passes": top1_passes,
    }
