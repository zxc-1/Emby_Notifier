"""Observability and logging utilities for TMDB recognition pipeline.

This module provides:
- Stage timing and metrics logging (Requirement 14.1)
- Decision trace management (Requirement 14.2)
- Score adjustment logging (Requirement 14.4)
- Debug response building (Requirement 14.5)
"""

from __future__ import annotations

import time
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple

from core.logging import get_biz_logger

biz = get_biz_logger(__name__)


@dataclass
class StageMetrics:
    """Metrics for a single pipeline stage."""
    stage_name: str
    # perf_counter provides a monotonic clock suitable for durations.
    start_time: float = field(default_factory=time.perf_counter)
    end_time: Optional[float] = None
    metrics: Dict[str, Any] = field(default_factory=dict)
    
    @property
    def duration_ms(self) -> float:
        """Get stage duration in milliseconds."""
        if self.end_time is None:
            return (time.perf_counter() - self.start_time) * 1000
        return (self.end_time - self.start_time) * 1000
    
    def complete(self, **metrics: Any) -> None:
        """Mark stage as complete with optional metrics."""
        self.end_time = time.perf_counter()
        self.metrics.update(metrics)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for logging."""
        return {
            "stage": self.stage_name,
            "duration_ms": round(self.duration_ms, 2),
            **self.metrics,
        }


@dataclass
class ScoreAdjustment:
    """Record of a score adjustment."""
    field: str
    before: float
    after: float
    reason: str
    tmdb_id: Optional[int] = None
    
    @property
    def delta(self) -> float:
        """Get the adjustment delta."""
        return self.after - self.before
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for logging."""
        return {
            "field": self.field,
            "before": round(self.before, 4),
            "after": round(self.after, 4),
            "delta": round(self.delta, 4),
            "reason": self.reason,
            "tmdb_id": self.tmdb_id,
        }


class DecisionTrace:
    """Manages decision trace for a resolve request (Requirement 14.2)."""
    
    def __init__(self) -> None:
        self._stages: List[str] = []
        self._gates_blocked: List[str] = []
        self._score_adjustments: List[ScoreAdjustment] = []
        self._stage_metrics: List[StageMetrics] = []
        self._current_stage: Optional[StageMetrics] = None
    
    def append(self, entry: str) -> None:
        """Append an entry to the trace."""
        self._stages.append(entry)
    
    def add_gate_blocked(self, gate_name: str, reason: Optional[str] = None) -> None:
        """Record a gate that blocked auto-pick (Requirement 14.3)."""
        entry = f"gate:{gate_name}"
        if reason:
            entry = f"{entry}:{reason}"
        self._gates_blocked.append(gate_name)
        self._stages.append(entry)
    
    def add_score_adjustment(
        self,
        field: str,
        before: float,
        after: float,
        reason: str,
        tmdb_id: Optional[int] = None,
    ) -> None:
        """Record a score adjustment (Requirement 14.4)."""
        adj = ScoreAdjustment(
            field=field,
            before=before,
            after=after,
            reason=reason,
            tmdb_id=tmdb_id,
        )
        self._score_adjustments.append(adj)
        self._stages.append(f"score_adj:{field}:{before:.3f}->{after:.3f}")
    
    def start_stage(self, stage_name: str) -> StageMetrics:
        """Start timing a new stage (Requirement 14.1)."""
        if self._current_stage is not None:
            self._current_stage.complete()
            self._stage_metrics.append(self._current_stage)
        
        self._current_stage = StageMetrics(stage_name=stage_name)
        self._stages.append(f"stage:{stage_name}")
        return self._current_stage
    
    def complete_stage(self, **metrics: Any) -> None:
        """Complete the current stage with metrics."""
        if self._current_stage is not None:
            self._current_stage.complete(**metrics)
            self._stage_metrics.append(self._current_stage)
            self._current_stage = None
    
    @property
    def stages(self) -> List[str]:
        """Get all trace entries."""
        return list(self._stages)
    
    @property
    def gates_blocked(self) -> List[str]:
        """Get all gates that blocked auto-pick."""
        return list(self._gates_blocked)
    
    @property
    def score_adjustments(self) -> List[Dict[str, Any]]:
        """Get all score adjustments as dicts."""
        return [adj.to_dict() for adj in self._score_adjustments]
    
    @property
    def timing(self) -> Dict[str, float]:
        """Get timing for all stages."""
        return {
            m.stage_name: round(m.duration_ms, 2)
            for m in self._stage_metrics
        }
    
    def to_list(self) -> List[str]:
        """Convert to list for backward compatibility."""
        return list(self._stages)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to full dictionary representation."""
        return {
            "stages": self._stages,
            "gates_blocked": self._gates_blocked,
            "score_adjustments": self.score_adjustments,
            "timing": self.timing,
        }


def log_stage_completion(
    stage_name: str,
    duration_ms: float,
    **metrics: Any,
) -> None:
    """Log stage completion with timing and metrics (Requirement 14.1)."""
    biz.detail(
        f"阶段完成：{stage_name}",
        extra={
            "stage": stage_name,
            "duration_ms": round(duration_ms, 2),
            **metrics,
        },
    )


def log_auto_pick_blocked(
    gate_name: str,
    reason: str,
    context: Optional[Dict[str, Any]] = None,
) -> None:
    """Log when auto-pick is blocked by a gate (Requirement 14.3)."""
    biz.detail(
        f"自动选择被 {gate_name} 阻止：{reason}",
        extra={
            "gate": gate_name,
            "reason": reason,
            **(context or {}),
        },
    )


def log_score_adjustment(
    field: str,
    before: float,
    after: float,
    reason: str,
    tmdb_id: Optional[int] = None,
) -> None:
    """Log a score adjustment with before/after values (Requirement 14.4)."""
    delta = after - before
    direction = "+" if delta >= 0 else ""
    biz.detail(
        f"分数调整：{field} {before:.3f} -> {after:.3f} ({direction}{delta:.3f}) [{reason}]",
        extra={
            "field": field,
            "before": round(before, 4),
            "after": round(after, 4),
            "delta": round(delta, 4),
            "reason": reason,
            "tmdb_id": tmdb_id,
        },
    )



@dataclass
class CandidateScoreBreakdown:
    """Detailed score breakdown for a candidate (Requirement 14.5)."""
    tmdb_id: int
    media_type: str
    title: str
    year: Optional[int]
    
    # Base scores
    title_similarity: float = 0.0
    coverage: float = 0.0
    
    # Adjustments
    year_affinity: float = 0.0
    episode_score: float = 0.0
    support_bonus: float = 0.0
    collision_penalty: float = 0.0
    alias_boost: float = 0.0
    
    # Final scores
    base_score: float = 0.0
    fused_score: float = 0.0
    
    # Metadata
    support_count: int = 0
    support_main: int = 0
    from_hints: List[str] = field(default_factory=list)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for debug response."""
        return {
            "tmdb_id": self.tmdb_id,
            "media_type": self.media_type,
            "title": self.title,
            "year": self.year,
            "scores": {
                "title_similarity": round(self.title_similarity, 4),
                "coverage": round(self.coverage, 4),
                "base_score": round(self.base_score, 4),
                "fused_score": round(self.fused_score, 4),
            },
            "adjustments": {
                "year_affinity": round(self.year_affinity, 4),
                "episode_score": round(self.episode_score, 4),
                "support_bonus": round(self.support_bonus, 4),
                "collision_penalty": round(self.collision_penalty, 4),
                "alias_boost": round(self.alias_boost, 4),
            },
            "support": {
                "count": self.support_count,
                "main": self.support_main,
                "from_hints": self.from_hints,
            },
        }


def build_debug_response(
    cands_all: List[Dict[str, Any]],
    decision_trace: DecisionTrace,
    hint_pack: Dict[str, Any],
    stage_a_result: Optional[Dict[str, Any]] = None,
    stage_b_result: Optional[Dict[str, Any]] = None,
    picked: Optional[Dict[str, Any]] = None,
    ok_pick: bool = False,
    auto_strength: Optional[str] = None,
) -> Dict[str, Any]:
    """Build complete debug response (Requirement 14.5).
    
    Args:
        cands_all: All candidates with scores
        decision_trace: Decision trace object
        hint_pack: Complete hint pack information
        stage_a_result: Stage-A search result
        stage_b_result: Stage-B search result (if run)
        picked: Picked candidate (if any)
        ok_pick: Whether auto-pick succeeded
        auto_strength: Auto-pick strength
    
    Returns:
        Complete debug response with all diagnostic information
    """
    # Build candidate breakdowns
    candidates_breakdown = []
    for cand in cands_all[:20]:  # Limit to top 20 for debug
        breakdown = {
            "tmdb_id": cand.get("tmdb_id"),
            "media_type": cand.get("media_type"),
            "title": cand.get("title") or cand.get("name"),
            "year": cand.get("year") or cand.get("release_year"),
            "scores": {
                "score": cand.get("score"),
                "coverage": cand.get("coverage"),
                "fused_score": cand.get("_fused_score"),
                "episode_score": cand.get("_episode_score"),
            },
            "support": {
                "count": cand.get("_support_count", 0),
                "main": cand.get("_support_main", 0),
                "weight": cand.get("_support_weight", 0),
            },
            "flags": {
                "collision_risky": cand.get("_collision_risky", False),
                "year_mismatch": cand.get("_year_mismatch", False),
            },
        }
        candidates_breakdown.append(breakdown)
    
    # Build hint pack summary
    hint_summary = {
        "hints_main": hint_pack.get("hints_main", []),
        "hints_msg": hint_pack.get("hints_msg", []),
        "hints_extra": hint_pack.get("hints_extra", []),
        "hints2": hint_pack.get("hints2", []),
        "q_title": hint_pack.get("q_title"),
        "q_year": hint_pack.get("q_year"),
        "tvish": hint_pack.get("tvish"),
        "season_hint_eff": hint_pack.get("season_hint_eff"),
        "evidence_level": hint_pack.get("evidence_level"),
        "evidence_level_desc": hint_pack.get("evidence_level_desc"),
        "standard_rate": hint_pack.get("standard_rate"),
        "episode_set": hint_pack.get("episode_set"),
        "count_mismatch": hint_pack.get("count_mismatch"),
    }
    
    return {
        "debug": True,
        "hint_pack": hint_summary,
        "candidates": candidates_breakdown,
        "decision_trace": decision_trace.to_dict(),
        "timing": decision_trace.timing,
        "stage_a": stage_a_result,
        "stage_b": stage_b_result,
        "result": {
            "ok_pick": ok_pick,
            "auto_strength": auto_strength,
            "picked": picked,
        },
    }


def extract_score_breakdown(cand: Dict[str, Any]) -> CandidateScoreBreakdown:
    """Extract score breakdown from a candidate dict."""
    return CandidateScoreBreakdown(
        tmdb_id=cand.get("tmdb_id", 0),
        media_type=cand.get("media_type", ""),
        title=cand.get("title") or cand.get("name") or "",
        year=cand.get("year") or cand.get("release_year"),
        title_similarity=cand.get("score", 0.0),
        coverage=cand.get("coverage", 0.0),
        year_affinity=cand.get("_year_affinity", 0.0),
        episode_score=cand.get("_episode_score", 0.0),
        support_bonus=cand.get("_support_bonus", 0.0),
        collision_penalty=cand.get("_collision_penalty", 0.0),
        alias_boost=cand.get("_alias_boost", 0.0),
        base_score=cand.get("score", 0.0),
        fused_score=cand.get("_fused_score", 0.0),
        support_count=cand.get("_support_count", 0),
        support_main=cand.get("_support_main", 0),
        from_hints=cand.get("_from_hints", []),
    )
