"""Episode consistency scoring for TV show candidates.

This module contains functions for:
- Computing episode score based on local episodes vs TMDB season total
- Applying episode exceed penalty
- Year score calculation

Extracted for better maintainability (Requirement 6).
"""

from __future__ import annotations

import asyncio
from typing import Any, Dict, List, Optional, Callable, Awaitable

from core.logging import get_biz_logger_adapter

from .constants import (
    EPISODE_SCORE_TOP_K,
    EPISODE_SCORE_CONCURRENCY,
    EPISODE_SCORE_MIN_EPISODES,
    EPISODE_SCORE_BOOST_THRESHOLD,
    EPISODE_EXCEED_PENALTY_THRESHOLD,
)

logger = get_biz_logger_adapter(__name__)


def compute_year_score(query_year: Optional[int], candidate_year: Optional[int]) -> float:
    """Compute year match score between query and candidate.
    
    Args:
        query_year: Year from query/evidence
        candidate_year: Year of TMDB candidate
    
    Returns:
        Score from 0.0 to 1.0
    """
    if query_year is None or candidate_year is None:
        return 0.0
    try:
        dy = abs(int(query_year) - int(candidate_year))
    except (ValueError, TypeError):
        return 0.0
    
    if dy == 0:
        return 1.0
    if dy == 1:
        return 0.8
    if dy == 2:
        return 0.6
    if dy <= 5:
        return 0.3
    return 0.0


def compute_episode_score(
    local_episodes: List[int],
    season_total: int,
) -> Dict[str, Any]:
    """Compute episode consistency score (Requirement 6.2, 6.3).
    
    Args:
        local_episodes: List of episode numbers from local files
        season_total: Total episodes in TMDB season
    
    Returns:
        Dict with:
        - episode_score: float (0.0 to 1.0)
        - in_range_count: int
        - exceed_count: int
        - exceed_penalty: bool
    """
    if not local_episodes or season_total <= 0:
        return {
            "episode_score": 0.0,
            "in_range_count": 0,
            "exceed_count": 0,
            "exceed_penalty": False,
        }
    
    # Count episodes in range
    in_range = [e for e in local_episodes if 1 <= e <= season_total]
    in_range_count = len(in_range)
    
    # Count episodes exceeding season total
    exceed = [e for e in local_episodes if e > season_total]
    exceed_count = len(exceed)
    
    # Check if exceed penalty applies (Requirement 6.4)
    exceed_ratio = exceed_count / len(local_episodes) if local_episodes else 0.0
    exceed_penalty = exceed_ratio > EPISODE_EXCEED_PENALTY_THRESHOLD
    
    if in_range_count == 0:
        return {
            "episode_score": 0.0,
            "in_range_count": 0,
            "exceed_count": exceed_count,
            "exceed_penalty": exceed_penalty,
        }
    
    # Compute score
    ratio = in_range_count / season_total
    coverage = in_range_count / len(local_episodes)
    
    # Calibrated formula: 0.3 base + 0.7 * ratio, scaled by coverage
    ep_score = (0.3 + 0.7 * min(1.0, ratio)) * min(1.0, coverage)
    ep_score = max(0.0, min(1.0, ep_score))
    
    # Apply penalty if too many episodes exceed
    if exceed_penalty:
        ep_score *= 0.7  # 30% penalty
    
    return {
        "episode_score": round(ep_score, 3),
        "in_range_count": in_range_count,
        "exceed_count": exceed_count,
        "exceed_penalty": exceed_penalty,
    }


def normalize_episode_set(episode_set: List[Any]) -> List[int]:
    """Normalize episode set to sorted unique integers.
    
    Args:
        episode_set: Raw episode set (may contain strings, duplicates)
    
    Returns:
        Sorted list of unique episode numbers
    """
    if not episode_set:
        return []
    
    result = []
    for x in episode_set:
        try:
            if isinstance(x, int):
                ep = x
            elif isinstance(x, str) and x.isdigit():
                ep = int(x)
            else:
                continue
            
            if 0 < ep <= 2000:  # Reasonable episode range
                result.append(ep)
        except (ValueError, TypeError):
            continue
    
    return sorted(set(result))


async def enrich_episode_scores(
    candidates: List[Dict[str, Any]],
    episode_set: List[int],
    season_hint: int,
    query_year: Optional[int],
    fetch_season_total: Callable[[int, int], Awaitable[Optional[int]]],
) -> List[Dict[str, Any]]:
    """Enrich TV candidates with episode scores (Requirement 6.1, 6.5).
    
    Args:
        candidates: List of candidate dicts
        episode_set: Normalized episode numbers from local files
        season_hint: Season number hint
        query_year: Year from query/evidence
        fetch_season_total: Async function to fetch season episode count
    
    Returns:
        Candidates with episode scores added (mutated in place)
    """
    if len(episode_set) < EPISODE_SCORE_MIN_EPISODES:
        return candidates
    
    # Filter to TV candidates only, limit to top K (Requirement 6.5)
    tv_candidates = []
    for d in candidates[:EPISODE_SCORE_TOP_K]:
        if not isinstance(d, dict):
            continue
        if str(d.get("media_type") or "").strip().lower() != "tv":
            continue
        tid = d.get("tmdb_id")
        if not tid or int(tid) <= 0:
            continue
        tv_candidates.append((d, int(tid)))
    
    if not tv_candidates:
        return candidates
    
    # Use semaphore for concurrency control (Requirement 13.4)
    sem = asyncio.Semaphore(EPISODE_SCORE_CONCURRENCY)
    
    async def enrich_one(d: Dict[str, Any], tid: int) -> None:
        async with sem:
            try:
                season_total = await fetch_season_total(tid, season_hint)
            except Exception as e:
                logger.detail(f"获取季总集数失败：{e}")
                return
        
        if not season_total or season_total <= 0:
            return
        
        # Compute episode score
        result = compute_episode_score(episode_set, season_total)
        
        d["_episode_total"] = season_total
        d["_episode_local"] = len(episode_set)
        d["_episode_in_range"] = result["in_range_count"]
        d["_episode_score"] = result["episode_score"]
        d["_episode_exceed_penalty"] = result["exceed_penalty"]
        
        # Compute year score
        cy = d.get("year")
        try:
            cy = int(cy) if cy not in (None, "") else None
        except (ValueError, TypeError):
            cy = None
        
        year_sc = compute_year_score(query_year, cy)
        d["_year_score"] = round(year_sc, 3)
        
        # Compose total score
        try:
            base_sc = float(d.get("_fused_score") or d.get("score") or 0.0)
        except (ValueError, TypeError):
            base_sc = 0.0
        
        ep_sc = result["episode_score"]
        total = 0.6 * min(1.0, base_sc) + 0.3 * ep_sc + 0.1 * year_sc
        d["_total_score"] = round(total, 5)
        
        # Update fused score if improved
        try:
            prev = float(d.get("_fused_score") or d.get("score") or 0.0)
        except (ValueError, TypeError):
            prev = 0.0
        
        if total > prev:
            d["_fused_score"] = round(total, 5)
    
    # Run enrichment concurrently
    await asyncio.gather(*[enrich_one(d, tid) for d, tid in tv_candidates])
    
    return candidates


def should_boost_by_episode_score(candidate: Dict[str, Any]) -> bool:
    """Check if candidate should get fused_score boost from episode score.
    
    Args:
        candidate: Candidate dict with _episode_score
    
    Returns:
        True if episode score is high enough for boost
    """
    try:
        ep_score = float(candidate.get("_episode_score") or 0.0)
    except (ValueError, TypeError):
        return False
    
    return ep_score >= EPISODE_SCORE_BOOST_THRESHOLD
