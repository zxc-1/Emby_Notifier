from __future__ import annotations

"""Share TMDB resolver use-case.

This module contains the orchestration flow for resolving a TMDB id from a 115 share link.
Heavy logic has been split into:
- hints.py (pure)
- season.py (pure)
- scoring.py (pure)
- repo.py (storage thin wrapper)
- ui.py (telegram UI rendering helpers)
- gateways.py (external integrations thin wrapper)
"""

import asyncio
import re
from typing import Any, Dict, List, Optional, Tuple

from ports.settings_provider import get_settings

from .ports_access import share115, tmdb


from domain.utils.patterns import TMDB_EXPLICIT_RE
from core.suppress import safe_int, safe_hash8

from .hints import build_hint_pack, pick_best_hint
from .snapshot import fetch_share_evidence
from .cache import resolve_from_caches_initial, resolve_from_caches_with_sig
from .gateways import tmdb_detail_safe, tmdb_find_by_external_id_safe
from .tmdb_lookup import build_candidate_sets, pre_resolve_from_names_and_caches
from .decide import decide_best_candidate
from .persist import finalize


from .repo import (
    init_db,
    cleanup_pending,
    create_pending_choice,
    get_mapping,
    get_title_mapping,
    get_series_mapping,
    upsert_mapping,
    upsert_title_mapping,
    upsert_series_mapping,
)

from core.logging import get_biz_logger_adapter
from core.logging import get_biz_logger

logger = get_biz_logger_adapter(__name__)
biz = get_biz_logger(__name__)



async def _resolve_tmdb_for_share(
    *,
    chat_id: int,
    user_id: int,
    share_url: str,
    hint_text: Optional[str] = None,
    season_hint: Optional[int] = None,
    explicit_tmdb_id: Optional[int] = None,
) -> Dict[str, Any]:
    """Resolve tmdb_id for a 115 share url (v1.7.19 behavior)."""
    await asyncio.to_thread(init_db)
    biz.step("开始解析分享链接并准备识别", i=1, total=7, 显式TMDBID=bool(explicit_tmdb_id))
    decision_trace: List[str] = []
    m = tmdb()
    sh = share115()
    decision_trace.append("start")
    try:
        await asyncio.to_thread(cleanup_pending, 1800)
    except Exception:
        logger.detail("TG 机器人：cleanup_pending 失败", extra={"chat_id": chat_id, "user_id": user_id}, exc_info=True)

    share_url = (share_url or "").strip()
    if not share_url:
        return {"ok": False, "reason": "empty_url", "decision_trace": decision_trace}

    share_code, receive_code = sh.parse_share_url(share_url)
    share_code = str(share_code or "").strip()
    receive_code = str(receive_code or "").strip()
    rc_from_url = bool(receive_code)

    # Read cached mapping (strong/weak). Strong mapping may be validated by file_sig if present.
    cached_strong: Optional[Dict[str, Any]] = None
    cached_weak: Optional[Dict[str, Any]] = None
    if share_code:
        m0 = await asyncio.to_thread(get_mapping, share_code)
        if m0 and m0.get("tmdb_id"):
            st0 = str(m0.get("strength") or "strong").strip().lower()
            if st0 == "strong":
                cached_strong = m0
            else:
                cached_weak = m0

    # If user did NOT provide a password but we have a cached one for this share_code,
    # use it so:
    # - 115 API calls (snap/BFS) can succeed
    # - downstream subscription receives a working link
    rc_from_cache = False
    if (not rc_from_url) and share_code and (not receive_code):
        try:
            rc0 = ""
            if cached_strong and str(cached_strong.get("receive_code") or "").strip():
                rc0 = str(cached_strong.get("receive_code") or "").strip()
            elif cached_weak and str(cached_weak.get("receive_code") or "").strip():
                rc0 = str(cached_weak.get("receive_code") or "").strip()
            if rc0:
                receive_code = rc0
                rc_from_cache = True
        except Exception:
            logger.detail("⚠️ 捕获到异常（已抑制，不中断流程）", exc_info=True)

    biz.step("解析分享码并加载缓存映射", i=2, total=7, 分享码=safe_hash8(share_code), 已有提取码=bool(receive_code), 提取码来自链接=bool(rc_from_url), 提取码来自缓存=bool(rc_from_cache), 命中强缓存=bool(cached_strong), 命中弱缓存=bool(cached_weak))

    # Try to compute a share snapshot signature (file_sig) for integrity checks and later persistence.
    best: Dict[str, Any] = {}
    file_sig: Optional[str] = None
    sig_mismatch = False

    # Explicit tmdb_id bypasses search, but we still try to bind with file_sig if possible.
    if explicit_tmdb_id:
        # Best-effort: determine media_type. Without it, a TV tmdb_id may be
        # mistakenly persisted as movie when season_hint is not provided.
        #
        # Root fix: prefer cached mapping's media_type for the same share_code
        # (works even when TMDB is temporarily unreachable).
        mt_final = "tv" if season_hint is not None else "movie"
        try:
            if share_code:
                m1 = cached_strong or cached_weak
                mt1 = str((m1 or {}).get("media_type") or "").strip().lower() if isinstance(m1, dict) else ""
                if mt1 in {"movie", "tv"}:
                    mt_final = mt1
        except Exception:
            logger.detail("⚠️ 捕获到异常（已抑制，不中断流程）", exc_info=True)
        try:
            d0 = await tmdb_detail_safe(int(explicit_tmdb_id), timeout=3.0)
            mt0 = str((d0 or {}).get("media_type") or "").strip().lower() if isinstance(d0, dict) else ""
            if mt0 in {"movie", "tv"}:
                mt_final = mt0
        except Exception:
            logger.detail("⚠️ 捕获到异常（已抑制，不中断流程）", exc_info=True)
        if share_code:
            try:
                ev = await fetch_share_evidence(
                    share_url=share_url,
                    share_code=share_code,
                    receive_code=receive_code or "",
                    decision_trace=decision_trace,
                )
                if isinstance(ev, dict) and ev.get("ok") and isinstance(ev.get("best"), dict):
                    best = dict(ev.get("best") or {})
                    file_sig = str(ev.get("file_sig") or "").strip() or None
            except Exception:
                logger.detail("TG 机器人：share snap (explicit tmdb) 失败", exc_info=True)

            await asyncio.to_thread(upsert_mapping, 
                share_code=share_code,
                receive_code=receive_code,
                tmdb_id=int(explicit_tmdb_id),
                media_type=mt_final,
                title="",
                year=None,
                # In explicit TMDB-ID flow we only know the user-provided season hint here.
                # season_hint_eff is computed later after inspecting share evidence.
                season=int(season_hint) if season_hint is not None else None,
                strength="strong",
                confidence=1.0,
                evidence_title=(hint_text or "") if isinstance(hint_text, str) else "",
                evidence_year=None,
                file_sig=file_sig,
            )
        try:
            biz.ok("使用显式 TMDB ID：跳过检索", TMDBID=int(explicit_tmdb_id), 类型=mt_final, 分享码=safe_hash8(share_code), 已有提取码=bool(receive_code), 文件指纹=(file_sig or ""))
        except Exception:
            logger.detail("⚠️ 捕获到异常（已抑制，不中断流程）", exc_info=True)
        biz.step("持久化识别结果并返回", i=7, total=7, 已自动选择=True, 自动强度="strong")
        return {
            "ok": True,
            "tmdb_id": int(explicit_tmdb_id),
            "share_code": share_code,
            "receive_code": receive_code,
            "file_sig": file_sig or "",
            "share_title": str(best.get("share_title") or "").strip() if isinstance(best, dict) else "",
            "from": "explicit",
            "media_type": mt_final,
            "decision_trace": decision_trace,
        }

    # ① Cache fast path (strong mapping without signature)
    hit0 = resolve_from_caches_initial(
        cached_strong=cached_strong,
        share_code=share_code,
        receive_code=receive_code,
        decision_trace=decision_trace,
    )
    if hit0:
        try:
            biz.ok("命中缓存映射：跳过 TMDB 检索", 来源=str(hit0.get("from") or hit0.get("from_source") or "cache"), TMDBID=hit0.get("tmdb_id"), 类型=hit0.get("media_type"), 分享码=safe_hash8(share_code), 文件指纹=str(hit0.get("file_sig") or ""))
        except Exception:
            logger.detail("⚠️ 捕获到异常（已抑制，不中断流程）", exc_info=True)
        return hit0


    # ② 115 evidence stage: fetch share snapshot (fast->deep) and compute file_sig.
    biz.step("从115拉取分享快照并提取媒体证据", i=3, total=7, 分享码=safe_hash8(share_code), 已有提取码=bool(receive_code))
    evidence_temp_unavailable = False
    evidence_weak = False
    evidence_reason: str | None = None
    evidence_reason_code: str | None = None
    evidence_error: dict | None = None
    try:
        if share_code:
            ev = await fetch_share_evidence(
                share_url=share_url,
                share_code=share_code,
                receive_code=receive_code or "",
                decision_trace=decision_trace,
            )
            if isinstance(ev, dict) and ev.get("ok") and isinstance(ev.get("best"), dict):
                best = dict(ev.get("best") or {})
                file_sig = str(ev.get("file_sig") or "").strip() or None
                evidence_weak = bool(ev.get("evidence_weak"))
            else:
                if isinstance(ev, dict):
                    evidence_temp_unavailable = bool(ev.get("temp_unavailable"))
                    evidence_reason = str(ev.get("reason") or "").strip() or None
                    evidence_reason_code = str(ev.get("reason_code") or "").strip() or None
                    evidence_error = ev.get("error") if isinstance(ev.get("error"), dict) else None
                else:
                    evidence_temp_unavailable = False
    except Exception:
        logger.detail("TG 机器人：share evidence fetch 失败", exc_info=True)

    try:
        if file_sig:
            biz.ok(
                "115 证据已收集（可用于防误伤）",
                文件指纹=file_sig,
                证据偏弱=bool(evidence_weak),
                暂不可用=bool(evidence_temp_unavailable),
                原因码=(evidence_reason_code or None),
            )
        elif evidence_temp_unavailable:
            biz.warning(
                "115 证据暂不可用：将降级为标题识别（更易误伤）",
                证据偏弱=bool(evidence_weak),
                暂不可用=True,
                原因码=(evidence_reason_code or None),
            )
        else:
            biz.warning(
                "115 证据不足：将降级为标题识别（更易误伤）",
                证据偏弱=bool(evidence_weak),
                暂不可用=False,
                原因码=(evidence_reason_code or None),
            )
    except Exception:
        logger.detail("⚠️ 捕获到异常（已抑制，不中断流程）", exc_info=True)
    # ③ Hint pack stage (pure): merge message text + URL fragment + share evidence into searchable hints.
    # This matches the v103-style split where hint packing is a standalone phase.
    hp = build_hint_pack(
        share_url=share_url,
        hint_text=hint_text,
        season_hint=season_hint,
        best=best if isinstance(best, dict) and best else None,
        evidence_temp_unavailable=evidence_temp_unavailable,
        evidence_weak=evidence_weak,
    )
    hints_main = list(hp.get("hints_main") or [])
    hints_msg = list(hp.get("hints_msg") or [])
    hints_extra = list(hp.get("hints_extra") or [])
    hints2 = list(hp.get("hints2") or [])
    q_title = str(hp.get("q_title") or "").strip()
    q_year = hp.get("q_year")
    tvish = bool(hp.get("tvish"))
    season_hint_eff = hp.get("season_hint_eff")
    force_mt = hp.get("force_mt")
    # batch/group evidence (for safer auto-pick)
    try:
        standard_rate = float(hp.get("standard_rate") or 0.0)
    except (ValueError, TypeError) as e:
        logger.detail(f"标准化率读取失败（已忽略） - 原因={type(e).__name__}")
        standard_rate = 0.0
    episode_set = list(hp.get("episode_set") or [])
    episode_best_files = list(hp.get("episode_best_files") or [])
    try:
        episode_dup_count = int(hp.get("episode_dup_count") or 0)
    except (ValueError, TypeError) as e:
        logger.detail(f"剧集重复数读取失败（已忽略） - 原因={type(e).__name__}")
        episode_dup_count = 0
    count_mismatch = bool(hp.get("count_mismatch"))
    share_title = str(hp.get("share_title") or "").strip()
    fname = str(hp.get("filename") or "").strip()
    hint_name = str(hp.get("hint_name") or "").strip()
    dir_path = list(hp.get("dir_path") or [])
    video_samples = list(hp.get("video_samples") or [])
    try:
        video_count = int(hp.get("video_count") or 0)
    except (ValueError, TypeError) as e:
        logger.detail(f"视频数量读取失败（已忽略） - 原因={type(e).__name__}")
        video_count = 0
    vc_reliable = bool(hp.get("vc_reliable"))
    evidence_temp_unavailable = bool(hp.get("evidence_temp_unavailable"))
    biz.step(
        "构造搜索提示：提取标题/年份/季信息用于 TMDB 检索",
        i=4,
        total=7,
        标题=q_title,
        年份=q_year,
        像剧集=bool(tvish),
        季=season_hint_eff,
        季推断=hp.get("season_infer"),
        季置信度=hp.get("season_level"),
        季来源=hp.get("season_source"),
        用户指定季=season_hint,
        强制类型=force_mt,
        分享标题=share_title,
        文件名=fname or hint_name,
        提示数=(len(hints_main) + len(hints_msg) + len(hints_extra) + len(hints2)),
        视频数=video_count,
        视频数可信=bool(vc_reliable),
        标准化率=float(standard_rate),
        剧集数=len(episode_set or []),
        重复版本=int(episode_dup_count),
        数量不一致=bool(count_mismatch),
    )
    evidence_weak = bool(hp.get("evidence_weak"))
    try:
        evidence_level = int(hp.get("evidence_level") or 2)
    except (ValueError, TypeError) as e:
        logger.detail(f"证据等级读取失败（已忽略） - 原因={type(e).__name__}")
        evidence_level = 2
    evidence_level_desc = str(hp.get("evidence_level_desc") or "")
    # ② Cache signature validation (after evidence)
    hit_sig, cached_strong, cached_weak, sig_mismatch = await resolve_from_caches_with_sig(
        cached_strong=cached_strong,
        cached_weak=cached_weak,
        share_code=share_code,
        receive_code=receive_code,
        file_sig=file_sig,
        best=best,
        share_title=share_title,
        filename=fname,
        hint_name=hint_name,
        decision_trace=decision_trace,
    )
    if hit_sig:
        return hit_sig


    # Cleaned, de-duplicated hints are computed by build_hint_pack() above.
    if not hints2:
        if not share_code:
            return {"ok": False, "reason": "share_code_missing", "decision_trace": decision_trace}

        # Evidence-driven failure reasons (more specific than generic no_hints)
        if evidence_temp_unavailable:
            return {
                "ok": False,
                "reason": (evidence_reason_code or "share115_temp_unavailable"),
                "share_code": share_code,
                "evidence_error": evidence_error,
                "decision_trace": decision_trace,
            }

        if evidence_reason_code and evidence_reason_code.startswith("share115_"):
            return {
                "ok": False,
                "reason": evidence_reason_code,
                "share_code": share_code,
                "evidence_error": evidence_error,
                "decision_trace": decision_trace,
            }

        if evidence_weak:
            return {"ok": False, "reason": "share_evidence_incomplete", "share_code": share_code, "decision_trace": decision_trace}

        # Generic read failed (snap_root_failed / empty listing etc.)
        if evidence_reason:
            return {
                "ok": False,
                "reason": "share115_read_failed",
                "share_code": share_code,
                "evidence_error": evidence_error,
                "decision_trace": decision_trace,
            }

        return {"ok": False, "reason": "no_hints", "share_code": share_code, "decision_trace": decision_trace}

    # q_title/q_year, evidence_texts, tvish and season_hint_eff were computed by build_hint_pack() above.

# ④ Pre-resolve stage: explicit ids / external ids / learned caches (no DB writes here).
    pre0 = await pre_resolve_from_names_and_caches(
        q_title=str(q_title or ""),
        q_year=(int(q_year) if q_year is not None else None),
        season_hint_eff=(int(season_hint_eff) if season_hint_eff is not None else None),
        tvish=bool(tvish),
        vc_reliable=bool(vc_reliable),
        video_count=int(video_count or 0),
        hints2=hints2,
        filename=fname,
        hint_name=hint_name,
        share_title=share_title,
        dir_path=dir_path,
        cached_weak=cached_weak,
        decision_trace=decision_trace,
    )

    cached_fp_tid = pre0.get("cached_fp_tid")
    if pre0.get("picked"):
        picked0 = dict(pre0.get("picked") or {})
        try:
            biz.ok("预检索命中：直接复用结果", 来源=str(pre0.get("from_source") or "auto"), TMDBID=picked0.get("tmdb_id"), 类型=picked0.get("media_type"), 标题=(picked0.get("title") or picked0.get("name")))
        except Exception:
            logger.detail("⚠️ 捕获到异常（已抑制，不中断流程）", exc_info=True)
        biz.step("持久化识别结果并返回", i=7, total=7, 已自动选择=True, 自动强度="strong")
        return await finalize(
            from_source=str(pre0.get("from_source") or "auto"),
            chat_id=chat_id,
            user_id=user_id,
            share_url=share_url,
            share_code=share_code,
            receive_code=receive_code,
            file_sig=file_sig,
            share_title=share_title,
            filename=fname,
            hint_name=hint_name,
            q_title=str(q_title or ""),
            q_year=(int(q_year) if q_year is not None else None),
            used_title=str(pre0.get("used_title") or q_title or ""),
            used_year=(int(pre0.get("used_year")) if isinstance(pre0.get("used_year"), int) else None),
            used_mt=str(pre0.get("used_mt") or force_mt or ""),
            used_season=(int(pre0.get("used_season")) if pre0.get("used_season") is not None else None),
            force_mt=(str(force_mt) if force_mt else None),
            evidence_temp_unavailable=bool(evidence_temp_unavailable),
            evidence_weak=bool(evidence_weak),
            evidence_level=int(evidence_level),
            evidence_level_desc=str(evidence_level_desc),
            has_msg_hints=bool(hints_msg),
            decision_trace=decision_trace,
            cands_all=[picked0],
            cands_show=[picked0],
            picked=picked0,
            ok_pick=True,
            auto_strength="strong",
        )

    biz.step("在 TMDB 检索候选并合并结果", i=5, total=7, 强制类型=force_mt, 主提示数=len(hints_main), 消息提示数=len(hints_msg), 额外提示数=len(hints_extra), 补充提示数=len(hints2))

    # ④ TMDB 候选生成（staged guess + merge）
    cand_pack = await build_candidate_sets(
        hints_main=hints_main,
        hints_msg=hints_msg,
        hints_extra=hints_extra,
        hints2=hints2,
        q_title=str(q_title or ""),
        q_year=(int(q_year) if q_year is not None else None),
        force_mt=force_mt,
        season_hint_eff=season_hint_eff,
        episode_set=hp.get("episode_set") if isinstance(hp, dict) else None,
        cached_fp_tid=cached_fp_tid,
        seed_candidates=pre0.get("seed_candidates"),
    )

    cands_all = list(cand_pack.get("cands_all") or [])
    cands_show = list(cand_pack.get("cands_show") or [])
    used_season = cand_pack.get("used_season")
    used_title = str(cand_pack.get("used_title") or "")
    used_year = cand_pack.get("used_year")
    used_mt = str(cand_pack.get("used_mt") or "")

    # When the resolver believes it's TV (e.g., SxxEyy evidence / forced TV), do not flood the UI with same-name movies.
    # Keep movies only when we truly have no TV candidates at all.
    if used_mt == "tv":
        try:
            tv_show = [c for c in cands_show if str(c.get("media_type") or "") == "tv"]
            if tv_show:
                cands_show = tv_show
            tv_all = [c for c in cands_all if str(c.get("media_type") or "") == "tv"]
            if tv_all:
                cands_all = tv_all
        except Exception:
            logger.detail("⚠️ 捕获到异常（已抑制，不中断流程）", exc_info=True)
    selected_hints = list(cand_pack.get("selected_hints") or [])
    has_main_hint = bool(cand_pack.get("has_main_hint"))

    try:
        biz.ok("候选生成完成", 候选总数=len(cands_all), 展示数=len(cands_show), 使用标题=used_title, 使用年份=used_year, 使用类型=used_mt, 使用季=used_season, 选中提示数=len(selected_hints))
        top_show = list(cands_show[: min(8, len(cands_show))])
        for _i, _c in enumerate(top_show, start=1):
            try:
                biz.ok_item(
                    "候选",
                    i=_i,
                    total=len(top_show),
                    tmdb_id=_c.get("tmdb_id"),
                    media_type=_c.get("media_type"),
                    score=_c.get("_fused_score") if _c.get("_fused_score") is not None else _c.get("score"),
                    coverage=_c.get("coverage"),
                    cand_title=(str(_c.get("title") or _c.get("name") or "")[:60] + ("…" if len(str(_c.get("title") or _c.get("name") or "")) > 60 else "")),
                )
            except Exception:
                logger.detail("⚠️ 捕获到异常（已抑制，不中断流程）", exc_info=True)
    except Exception:
        logger.detail("⚠️ 捕获到异常（已抑制，不中断流程）", exc_info=True)

    

    # ⑤ 决策（自动选 or 需要人工）
    biz.step("根据证据等级与候选评分做决策", i=6, total=7, 证据等级=int(evidence_level), 证据说明=str(evidence_level_desc), 选中提示数=len(selected_hints), 有主提示=bool(has_main_hint))
    dec = await decide_best_candidate(
        cands_all=cands_all,
        q_title=str(q_title or ""),
        q_year=(int(q_year) if q_year is not None else None),
        used_title=str(used_title or ""),
        used_year=(int(used_year) if used_year is not None else None),
        used_mt=str(used_mt or ""),
        used_season=(int(used_season) if used_season is not None else None),
        force_mt=force_mt,
        has_main_hint=has_main_hint,
        selected_hints_count=len(selected_hints),
        evidence_level=int(evidence_level),
        evidence_level_desc=str(evidence_level_desc),
        standard_rate=float(standard_rate),
        episode_set=episode_set,
        episode_best_files=episode_best_files,
        episode_dup_count=int(episode_dup_count),
        count_mismatch=bool(count_mismatch),
    )

    try:
        if bool(dec.get("ok_pick")) and isinstance(dec.get("picked"), dict):
            pk = dec.get("picked") or {}
            strength_eff = str(dec.get("auto_strength") or "weak")
            # P0 fix: strength=weak 时不应该说"自动选择"，容易误导
            if strength_eff == "strong":
                biz.ok("自动选择", tmdb_id=pk.get("tmdb_id"), media_type=pk.get("media_type"), picked_title=pk.get("title"), year=pk.get("year"), score=pk.get("score"), coverage=pk.get("coverage"), strength=strength_eff)
            else:
                biz.warning("弱匹配（需确认）", tmdb_id=pk.get("tmdb_id"), media_type=pk.get("media_type"), picked_title=pk.get("title"), year=pk.get("year"), score=pk.get("score"), coverage=pk.get("coverage"), strength=strength_eff)
        else:
            top0 = (cands_show[0] if cands_show else (cands_all[0] if cands_all else {})) or {}
            biz.warning("需要人工选择", top_tmdb_id=top0.get("tmdb_id"), top_title=top0.get("title") or top0.get("name"), top_score=top0.get("_fused_score") if top0.get("_fused_score") is not None else top0.get("score"), top_coverage=top0.get("coverage"), strength=str(dec.get("auto_strength") or "weak"), evidence_level=int(evidence_level), evidence_level_desc=str(evidence_level_desc))
    except Exception:
        logger.detail("⚠️ 捕获到异常（已抑制，不中断流程）", exc_info=True)

    biz.step("持久化识别结果并返回", i=7, total=7, 已自动选择=bool(dec.get("ok_pick")), 自动强度=str(dec.get("auto_strength") or ""))

    

    # ⑥ 持久化 + 返回
    return await finalize(
        chat_id=chat_id,
        user_id=user_id,
        share_url=share_url,
        share_code=share_code,
        receive_code=receive_code,
        file_sig=file_sig,
        share_title=share_title,
        filename=fname,
        hint_name=hint_name,
        q_title=str(q_title or ""),
        q_year=(int(q_year) if q_year is not None else None),
        used_title=str(used_title or ""),
        used_year=(int(used_year) if used_year is not None else None),
        used_mt=str(used_mt or ""),
        used_season=(int(used_season) if used_season is not None else None),
        force_mt=force_mt,
        evidence_temp_unavailable=bool(evidence_temp_unavailable),
        evidence_weak=bool(evidence_weak),
        evidence_level=int(evidence_level),
        evidence_level_desc=str(evidence_level_desc),
        has_msg_hints=bool(hints_msg),
        decision_trace=decision_trace,
        cands_all=list(dec.get("cands_all") or cands_all),
        cands_show=cands_show,
        picked=dec.get("picked"),
        ok_pick=bool(dec.get("ok_pick")),
        auto_strength=dec.get("auto_strength"),
    )
