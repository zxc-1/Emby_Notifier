from __future__ import annotations

from core.exceptions.base import ConfigurationError

"""Access injected ports for share_resolver.

This module keeps share_resolver code dependency-light:
- Application code must NOT import integrations directly.
- Infrastructure is accessed via AppContext ports (injected during bootstrap).

Design goal:
- share_resolver should remain usable in unit tests / CLI even when no AppContext
  is bound. In that case we fall back to default adapters (best-effort).
"""
import logging
from core.logging import get_biz_logger_adapter
logger = get_biz_logger_adapter(__name__)


from ports.app_context import get_ctx_optional
from ports.share115 import Share115Gateway
from ports.tmdb_matcher import TmdbMatcher


def tmdb() -> TmdbMatcher:
    ctx = get_ctx_optional()
    if ctx is not None:
        v = getattr(ctx, "tmdb_matcher", None)
        if v is not None:
            return v  # type: ignore[return-value]

    # Best-effort fallback: keep share resolver functional even if bootstrap wiring
    # failed to inject tmdb_matcher (e.g., optional deps import error) or when ctx
    # is not bound (tests/CLI).
    try:
        from integrations.tmdb_matcher_adapter import DefaultTmdbMatcher  # type: ignore

        v = DefaultTmdbMatcher()
        if ctx is not None:
            try:
                setattr(ctx, "tmdb_matcher", v)
            except (AttributeError, TypeError) as e:
                logger.detail(f"TMDB匹配器注入失败（已忽略） - 原因={type(e).__name__}")
        return v  # type: ignore[return-value]
    except Exception as e:
        raise ConfigurationError("tmdb_matcher is not available (bootstrap wiring missing or optional deps failed)", cause=e)


def share115() -> Share115Gateway:
    ctx = get_ctx_optional()
    if ctx is not None:
        v = getattr(ctx, "share115_gateway", None)
        if v is not None:
            return v  # type: ignore[return-value]

    # Best-effort fallback for share resolver and tg-bot share handling.
    try:
        from integrations.share115_gateway import DefaultShare115Gateway  # type: ignore

        v = DefaultShare115Gateway()
        if ctx is not None:
            try:
                setattr(ctx, "share115_gateway", v)
            except (AttributeError, TypeError) as e:
                logger.detail(f"115网关注入失败（已忽略） - 原因={type(e).__name__}")
        return v  # type: ignore[return-value]
    except Exception as e:
        raise ConfigurationError("share115_gateway is not available (bootstrap wiring missing or optional deps failed)", cause=e)
