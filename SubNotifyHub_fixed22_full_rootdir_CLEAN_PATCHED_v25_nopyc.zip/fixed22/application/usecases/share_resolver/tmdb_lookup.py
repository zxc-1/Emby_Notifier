from __future__ import annotations

"""TMDB candidate generation for share->TMDB resolver.

This module corresponds to stage ④ in the refactored flow: given a HintPack,
run TMDB guessing (staged) and merge candidates across hints.

It is intentionally focused on producing candidates; decision/persistence live elsewhere.

Refactored in Task 9: This module now acts as a coordination layer, delegating
to specialized modules:
- pre_resolve.py: Pre-resolution (external IDs, caches)
- hint_selection.py: Hint selection and prioritization
- candidate_merge.py: Candidate merging and consensus scoring
- ui_filter.py: UI filtering and display

Task 4.2: 集成搜索缓存统计日志 (Requirement 6.2, 6.6)
"""

import asyncio
import re
from typing import Any, Dict, List, Optional, Tuple

from core.logging import get_biz_logger_adapter

from .ports_access import tmdb
from .search_cache import get_search_cache
from .scoring import _title_quality_score
from .stage_strategy import (
    check_stage_a_stability as _stage_a_stable,
    normalize_hint_query_key as _hint_query_key,
)

# Task 7.1: episode_scoring.py
from .episode_scoring import normalize_episode_set, enrich_episode_scores

# Task 7.4: sequel_detection.py
from .sequel_detection import compute_sequel_mismatch_penalty

# Task 7.5: alias_matching.py
from .alias_matching import (
    fetch_alternative_titles,
    compute_alias_similarity,
    has_cjk_text,
)

# Task 5.3: title_alias.py - 多语言标题关联
from .title_alias import (
    boost_candidates_with_aliases as _boost_with_aliases,
    normalize_alias,
)

# Task 9: 新模块导入
from .hint_selection import (
    select_hints,
    pick_primary_hint,
    compute_adaptive_hint_budget,
    extract_strict_year,
    should_force_stage_b,
    has_main_hint as _has_main_hint,
)
from .candidate_merge import (
    merge_candidates,
    inject_seeds,
    compute_top1_consensus,
    attach_top1_support,
    apply_evidence_fusion,
    apply_year_affinity_bias,
    apply_title_cache_bias,
    apply_sequel_penalty,
    apply_alias_bonus,
    sort_by_fused_score,
)
from .ui_filter import filter_for_ui

# Task 9.1: 导入 pre_resolve 模块
from .pre_resolve import (
    pre_resolve_from_names_and_caches as _pre_resolve_impl,
    CandidateShim,
)

biz = get_biz_logger_adapter(__name__)
logger = get_biz_logger_adapter(__name__)



async def pre_resolve_from_names_and_caches(
    *,
    q_title: str,
    q_year: Optional[int],
    season_hint_eff: Optional[int],
    tvish: bool,
    vc_reliable: bool,
    video_count: int,
    hints2: List[str],
    filename: str,
    hint_name: str,
    share_title: str,
    dir_path: List[str],
    cached_weak: Optional[Dict[str, Any]] = None,
    decision_trace: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Stage-④ pre-resolve: external ids + learned caches + explicit ids in names.

    Returns dict:
      - picked: dict|None
      - from_source: str|None
      - used_mt/used_title/used_year/used_season
      - cached_fp_tid: Optional[int]  (for boosting later search)
      - seed_candidates: List[Dict]

    This function performs TMDB IO for validation, but does NOT write to DB.
    
    Task 9.1: Delegates to pre_resolve.py module.
    """
    # Task 9.1: 委托给 pre_resolve.py 模块
    return await _pre_resolve_impl(
        q_title=q_title,
        q_year=q_year,
        season_hint_eff=season_hint_eff,
        tvish=tvish,
        vc_reliable=vc_reliable,
        video_count=video_count,
        hints2=hints2,
        filename=filename,
        hint_name=hint_name,
        share_title=share_title,
        dir_path=dir_path,
        cached_weak=cached_weak,
        decision_trace=decision_trace,
    )


async def build_candidate_sets(
    *,
    hints_main: List[str],
    hints_msg: List[str],
    hints_extra: List[str],
    hints2: List[str],
    q_title: str,
    q_year: Optional[int],
    force_mt: Optional[str],
    season_hint_eff: Optional[int] = None,
    episode_set: Optional[List[int]] = None,
    cached_fp_tid: Optional[int] = None,
    seed_candidates: Optional[List[Dict[str, Any]]] = None,
) -> Dict[str, Any]:
    """Run staged TMDB lookup and merge candidates across hints.

    Returns a dict:
      - cands_all / cands_show
      - used_title / used_year / used_mt / used_season
      - selected_hints / hint_src / has_main_hint
    """

    force_mt = str(force_mt or "").strip().lower() or None

    # TMDB matcher (required). In v1.6.17.11 refactor this was accidentally
    # omitted, causing NameError on `m.*` calls and silently producing
    # empty candidate sets.
    m = tmdb()

    # Seed candidates: validated hints coming from pre-resolve stage (explicit tmdbid in evidence,
    # validated learned cache, etc). These are NOT authoritative.
    seeds: List[Dict[str, Any]] = []
    try:
        for _s in (seed_candidates or []):
            if isinstance(_s, dict) and int(_s.get('tmdb_id') or 0) > 0:
                seeds.append(dict(_s))
    except (ValueError, TypeError, KeyError):
        logger.detail("seed candidates 处理失败（已忽略）")
        seeds = []

    # Also convert cached_fp_tid (validated learned title mapping) into a seed so it can
    # compete with search results rather than being silently ignored.
    try:
        if cached_fp_tid and int(cached_fp_tid) > 0 and (not any(int(x.get('tmdb_id') or 0) == int(cached_fp_tid) for x in seeds)):
            _pref = str(force_mt or '').strip().lower() or None
            _det = None
            try:
                _det = await m.fetch_tmdb_detail(int(cached_fp_tid), prefer_media_type=_pref)
            except (ValueError, TypeError, KeyError, OSError, asyncio.TimeoutError):
                logger.detail(f"cached fp tid seed 详情获取失败（已忽略） - tmdb_id={cached_fp_tid}, prefer_mt={_pref}")
                _det = None
            if _det and str(_det.get('title') or '').strip():
                _mt = str(_det.get('media_type') or (_pref or 'movie')).strip().lower() or (_pref or 'movie')
                _title = str(_det.get('title') or '').strip()
                _year = _det.get('year')
                cand0 = CandidateShim(
                    tmdb_id=int(cached_fp_tid),
                    media_type=_mt,
                    title=_title,
                    year=_year,
                    rating=float(_det.get('rating') or 0.0),
                    vote_count=int(_det.get('vote_count') or 0),
                    score=1.0,
                    extra=_det,
                )
                sc0, cov0, _ = m.score_candidate_meta(str(q_title or ''), q_year, cand0)
                seeds.append(
                    {
                        'tmdb_id': int(cached_fp_tid),
                        'title': _title,
                        'year': _year,
                        'media_type': _mt,
                        'score': float(sc0),
                        'coverage': float(cov0),
                        'vote_count': int(_det.get('vote_count') or 0),
                        'rating': float(_det.get('rating') or 0.0),
                        '_seed_reason': 'title_cache_seed',
                    }
                )
    except (ValueError, TypeError, KeyError, OSError, asyncio.TimeoutError):
        logger.detail('cached_fp_tid seed 失败', exc_info=True)

    merged: Dict[Tuple[int, str], Dict[str, Any]] = {}
    used_season: Optional[int] = season_hint_eff
    used_title = ""
    used_year = None
    used_mt = force_mt or ""

    # Task 9.2: 使用 hint_selection.py 模块进行 hint 选择
    max_hints = compute_adaptive_hint_budget(hints_main, hints_msg, hints2)
    selected_hints, hint_src = select_hints(
        hints_main, hints_msg, hints_extra, hints2, q_title, max_hints
    )
    
    # 提取 strict year 和检测双语证据
    _main_hints = [h for h in selected_hints if hint_src.get(h) == "main"]
    _strict_year = extract_strict_year(_main_hints)
    _bilingual_main = should_force_stage_b(
        hints_main, hints_msg, str(q_title or ""), hint_src
    )
    
    has_main_hint = _has_main_hint(hint_src)
    
    # 选择 primary hint
    primary_hint = pick_primary_hint(selected_hints, hint_src, _strict_year)

    def _stage_a_stable_local(g: Dict[str, Any]) -> bool:
        """Local wrapper that uses module-level _stage_a_stable with additional guards."""
        try:
            cands = g.get("candidates") or []
            if not isinstance(cands, list) or not cands:
                return False
            cands2 = [x for x in cands if isinstance(x, dict)]
            if not cands2:
                return False
            cands2.sort(key=lambda x: float(x.get("score") or 0.0), reverse=True)
            
            # Use module-level _stage_a_stable for basic stability check (Requirement 4.1, 13.2)
            stability_result = _stage_a_stable(cands2)
            
            # If not stable at all, return False immediately
            if not stability_result.get("is_stable", False):
                return False
            
            b = cands2[0]
            bs = stability_result.get("top_score", 0.0)
            cov = stability_result.get("top_coverage", 0.0)
            gap = stability_result.get("gap", 0.0)
            
            # Strong-match early-stop: if Stage-A already has a clear and high-
            # coverage winner, Stage-B often adds noise for short / generic
            # titles (e.g. "Spring Fever").
            if stability_result.get("can_early_stop", False):
                # Additional year guard before early stop
                try:
                    if isinstance(_strict_year, int) and isinstance(b.get("year"), int):
                        if int(b.get("year")) != int(_strict_year):
                            return False
                except Exception as e:
                    biz.detail("ignored exception in _stage_a_stable_local", exc_info=True)
                    pass
                return True
            
            try:
                # Strict year guard (from CJK title like "轻年(2025)")
                if isinstance(_strict_year, int) and isinstance(b.get("year"), int):
                    if int(b.get("year")) != int(_strict_year):
                        return False
                if isinstance(q_year, int) and isinstance(b.get("year"), int):
                    if abs(int(b.get("year")) - int(q_year)) > 1:
                        return False
            except Exception:
                logger.detail(f"year guard 检查失败（已忽略） - strict_year={_strict_year}, q_year={q_year}, cand_year={b.get('year')}")
                pass

            # Collision/ambiguity guard: very short/generic titles are risky.
            # Avoid Stage-A early-stop unless the match is extremely strong.
            try:
                qt = str((g or {}).get('title') or '').strip()
                qt2 = re.sub(r"[^0-9A-Za-z\u4e00-\u9fff]+", " ", qt).strip().lower()
                stop = {
                    'the', 'a', 'an', 'of', 'and', 'to', 'in', 'on', 'at', 'for', 'with', 'from',
                    'season', 's', 'ep', 'episode',
                }
                toks = [t for t in qt2.split() if t and t not in stop]
                collision_words = {
                    'young', 'love', 'home', 'life', 'story', 'town', 'city', 'girl', 'boy', 'man', 'woman',
                    'world', 'family', 'time', 'day', 'night', 'dream', 'star', 'king', 'queen', 'game',
                }
                if len(toks) <= 2:
                    if any(t in collision_words for t in toks):
                        if not (bs >= 0.985 and cov >= 0.70 and gap >= 0.18):
                            return False
                    else:
                        if not (bs >= 0.975 and cov >= 0.65 and gap >= 0.15):
                            return False
            except Exception:
                logger.detail("collision guard 检查失败（已忽略）")
                pass
            if (bs >= 0.93 and cov >= 0.60):
                return True
            return (bs >= 0.88) and (cov >= 0.60) and (gap >= 0.12)
        except Exception:
            logger.detail("stage A stable 检查失败（已忽略）")
            return False

    gmap: Dict[str, Dict[str, Any]] = {}
    if primary_hint:
        try:
            gmap[primary_hint] = await m.guess_tmdb_from_filename(primary_hint, force_media_type=force_mt, mode="full")
        except Exception:
            logger.detail("stageA guess 失败", exc_info=True)

    run_stage_b = True
    try:
        if primary_hint and _stage_a_stable_local(gmap.get(primary_hint) or {}):
            run_stage_b = False
    except Exception:
        logger.detail("stage A stable 判断失败（已忽略）")
        run_stage_b = True

    # If bilingual main hints exist, never early-stop at Stage-A.
    # This ensures we query the CJK title and merge candidates.
    if _bilingual_main:
        run_stage_b = True


    if run_stage_b:
        hs_b = [h for h in selected_hints if h and h != primary_hint]

        # -----------------------------------------------------------------
        # Optimization: avoid redundant Stage-B calls (Requirement 4.5, 13.1).
        # Many shares produce multiple hints that normalize to the same
        # (title, year, season) query, which only wastes TMDB requests.
        # We dedupe by a normalized query key and cap to ONE best secondary hint.
        # Result: Stage-A(full) + Stage-B(light) => at most 2 TMDB calls.
        # -----------------------------------------------------------------
        def _hint_query_key_extended(h: str) -> tuple[str, int, int]:
            """Extended hint query key with year and season for precise deduplication."""
            s = str(h or "").strip()
            if not s:
                return ("", 0, 0)
            # Use module-level _hint_query_key for base normalization
            base_key = _hint_query_key(s)
            try:
                t0, y0, _mt0 = m.parse_title_year_from_filename(s)
            except Exception:
                t0, y0 = "", None
            t = base_key if base_key else (str(t0 or "").strip() or s)
            t = re.sub(r"[^0-9A-Za-z\u4e00-\u9fff]+", " ", t).strip().lower()
            y = int(y0) if isinstance(y0, int) else 0
            sm = re.search(r"(?i)\bS(\d{1,2})\b|\bSeason\s*(\d{1,2})\b", s)
            season = 0
            if sm:
                try:
                    season = int(sm.group(1) or sm.group(2) or 0)
                except Exception:
                    season = 0
            return (t, y, season)

        try:
            seen = set()
            if primary_hint:
                seen.add(_hint_query_key_extended(primary_hint))
            uniq: list[str] = []
            for h in hs_b:
                k = _hint_query_key_extended(h)
                if k in seen:
                    continue
                seen.add(k)
                uniq.append(h)
            # pick the strongest remaining hint (highest title quality) and cap to 1
            uniq.sort(key=lambda x: _title_quality_score(str(x or "")), reverse=True)
            hs_b = uniq[:1]
        except Exception:
            logger.detail("stage B dedupe 失败（已忽略）")
            # fall back to original hs_b as-is

        if hs_b:
            sem = asyncio.Semaphore(1)

            async def _guess_one_light(h: str) -> Tuple[str, Dict[str, Any]]:
                async with sem:
                    return h, await m.guess_tmdb_from_filename(h, force_media_type=force_mt, mode="light")

            try:
                res = await asyncio.gather(*[_guess_one_light(h) for h in hs_b], return_exceptions=True)
                for _r in res:
                    if isinstance(_r, Exception):
                        biz.detail(f"并行任务失败（已忽略）：{type(_r).__name__}", error=str(_r))
                for it in res:
                    if isinstance(it, Exception):
                        logger.detail(
                            "ℹ️ [TMDB解析]stageB 并行 guess 失败：单个任务返回异常（已忽略）。"
                            "可能原因：文件名解析异常、TMDB 接口失败、或内部数据错误。"
                            "影响：该 hint 无法生成 guess 结果,可能降低匹配准确性",
                            exc_info=it,
                        )
                        continue
                    if isinstance(it, tuple) and len(it) == 2:
                        h0, g0 = it
                        if isinstance(g0, dict):
                            gmap[str(h0)] = g0
            except Exception:
                logger.detail("stageB concurrent guess 失败", exc_info=True)


    selected_hints = [h for h in selected_hints if h in gmap]
    if primary_hint and primary_hint in gmap:
        selected_hints = [primary_hint] + [h for h in selected_hints if h != primary_hint]

    # 提取 used_season, used_title, used_year, used_mt 从 gmap
    for h in selected_hints:
        g = gmap.get(h) or {}
        if g.get("season") is not None and used_season is None:
            try:
                used_season = int(g.get("season"))
            except (ValueError, TypeError):
                pass
        if (not used_title) and g.get("title"):
            used_title = str(g.get("title") or "")
            used_year = g.get("year")
            used_mt = str(g.get("media_type") or used_mt)

    # Task 9.2: 使用 candidate_merge.py 模块进行候选合并
    # 计算 top-1 consensus
    top1_by_hint = compute_top1_consensus(gmap, hint_src)
    
    # 合并候选
    merged = merge_candidates(gmap, selected_hints, hint_src)
    
    # 注入 seed 候选
    inject_seeds(merged, seeds)
    
    # 附加 top-1 support 指标
    attach_top1_support(merged, top1_by_hint, hint_src)
    
    # 应用 evidence fusion
    apply_evidence_fusion(merged)

    # If force_mt is specified, prefer candidates of that media type only.
    # Fallback to mixed pool only when the forced pool is empty.
    _vals = list(merged.values())
    if force_mt in ("tv", "movie"):
        _forced = [v for v in _vals if isinstance(v, dict) and v.get("media_type") == force_mt]
        if _forced:
            _vals = _forced

    cands_all = sort_by_fused_score(_vals)

    # Task 9.2: 使用 candidate_merge.py 的辅助函数
    # 年份亲和度微调
    _year_ref = _strict_year if isinstance(_strict_year, int) else q_year
    apply_year_affinity_bias(cands_all, _year_ref, _strict_year)
    cands_all = sort_by_fused_score(cands_all)

    # Title cache bias
    apply_title_cache_bias(cands_all, cached_fp_tid)
    cands_all = sort_by_fused_score(cands_all)

    # 续集检测惩罚
    apply_sequel_penalty(cands_all, q_title, compute_sequel_mismatch_penalty)
    cands_all = sort_by_fused_score(cands_all)

    # ------------------------------------------------------------
    # Task 7.3: 动漫检测和 bonus
    # ------------------------------------------------------------
    # 基于候选的 genre_ids 检测动漫，为动画类型候选应用 bonus
    # 注意：由于 build_candidate_sets 没有 filename/video_samples 参数，
    # 我们直接基于候选的 genre_ids 来判断是否为动画
    try:
        # 简单的标题相似度函数
        def _simple_title_similarity(query: str, cand_title: str) -> float:
            """简单的标题相似度计算"""
            if not query or not cand_title:
                return 0.0
            q_lower = query.lower().strip()
            c_lower = cand_title.lower().strip()
            if q_lower == c_lower:
                return 1.0
            if q_lower in c_lower or c_lower in q_lower:
                return 0.9
            # 简单的词重叠
            q_words = set(q_lower.split())
            c_words = set(c_lower.split())
            if not q_words or not c_words:
                return 0.0
            overlap = len(q_words & c_words)
            return overlap / max(len(q_words), len(c_words))
        
        # 直接为动画类型候选应用 bonus（不依赖 anime_evidence）
        ANIMATION_GENRE_ID = 16
        for d in cands_all:
            if not isinstance(d, dict):
                continue
            genre_ids = d.get("genre_ids", [])
            if not genre_ids or ANIMATION_GENRE_ID not in genre_ids:
                continue
            
            cand_title = str(d.get("title") or d.get("name") or "").strip()
            if not cand_title:
                continue
            
            similarity = _simple_title_similarity(q_title, cand_title)
            # 当标题相似度 >= 0.85 且候选是动画类型时，应用 +0.03 bonus
            if similarity >= 0.85:
                d["_anime_bonus"] = 0.03
                try:
                    fs = float(
                        d.get("_fused_score")
                        if d.get("_fused_score") is not None
                        else d.get("score") or 0.0
                    )
                    d["_fused_score"] = round(max(0.0, min(1.0, fs + 0.03)), 5)
                except (ValueError, TypeError):
                    pass
        
        cands_all = sort_by_fused_score(cands_all)
    except Exception:
        logger.detail("anime bonus 应用失败（已忽略）", exc_info=True)

    # ------------------------------------------------------------
    # Task 7.5 + Task 5.3: 别名匹配 bonus (多语言标题关联)
    # ------------------------------------------------------------
    # 当查询包含 CJK 字符时，获取候选的 alternative_titles 并计算相似度
    # 使用 title_alias.py 的 boost_candidates_with_aliases 实现
    # API 错误时优雅降级 (Requirement 2.5)
    try:
        if has_cjk_text(q_title):
            # 使用新的 title_alias.py 模块进行别名匹配
            await _boost_with_aliases(
                cands_all,
                q_title,
                boost_factor=0.02,
                min_similarity=0.7,
            )
            cands_all = sort_by_fused_score(cands_all)
    except Exception:
        # 优雅降级：API 错误时继续使用原有候选
        logger.detail("alias bonus 应用失败（已忽略）", exc_info=True)

    # ------------------------------------------------------------
    # Episode consistency scoring (group-level safety belt)
    # Task 7.1: 使用 episode_scoring.py 的函数替换内联代码
    # ------------------------------------------------------------
    # When we have extracted an episode set from multiple filenames, we can
    # prefer TV candidates whose season episode-count is plausible.
    # This dramatically reduces wrong auto-binds for similarly named titles.
    if episode_set and isinstance(episode_set, list) and season_hint_eff is not None:
        # 使用 episode_scoring.normalize_episode_set 替换内联规范化
        local_eps = normalize_episode_set(episode_set)

        if len(local_eps) >= 2:
            # 创建 fetch_season_total 回调函数
            async def _fetch_season_total(tid: int, s_no: int) -> Optional[int]:
                try:
                    fn = getattr(m, "fetch_tv_season_episode_count", None)
                    if callable(fn):
                        v = await fn(int(tid), int(s_no))
                        return int(v) if v not in (None, "") else None
                except Exception:
                    logger.detail("fetch_tv_season_episode_count 失败", exc_info=True)
                try:
                    det = await m.fetch_tmdb_detail(int(tid), prefer_media_type="tv")
                    if isinstance(det, dict) and det.get("number_of_episodes"):
                        return int(det.get("number_of_episodes"))
                except Exception:
                    logger.detail("tmdb_detail fallback for season total 失败", exc_info=True)
                return None

            try:
                # 使用 episode_scoring.enrich_episode_scores 替换内联 _apply_episode_score
                await enrich_episode_scores(
                    candidates=cands_all,
                    episode_set=local_eps,
                    season_hint=int(season_hint_eff),
                    query_year=q_year,
                    fetch_season_total=_fetch_season_total,
                )
                cands_all = sorted(
                    cands_all,
                    key=lambda x: float(x.get("_fused_score") if x.get("_fused_score") is not None else x.get("score") or 0),
                    reverse=True,
                )
            except Exception:
                logger.detail("episode_score fusion 失败", exc_info=True)

    # Task 9.2: 使用 ui_filter.py 模块进行 UI 过滤
    cands_show = filter_for_ui(cands_all)

    # ------------------------------------------------------------
    # Task 4.2: 缓存统计日志 (Requirement 6.2, 6.6)
    # ------------------------------------------------------------
    # 记录搜索缓存统计信息，用于监控缓存效率
    try:
        cache = get_search_cache()
        stats = cache.get_stats()
        hit_rate = stats.get("hit_rate", 0.0)
        # 仅在有缓存活动时记录日志
        if stats.get("hits", 0) + stats.get("misses", 0) > 0:
            biz.detail(
                "搜索缓存统计",
                cache_hits=stats.get("hits", 0),
                cache_misses=stats.get("misses", 0),
                cache_hit_rate=round(hit_rate, 4),
                cache_size=stats.get("size", 0),
                cache_evictions=stats.get("evictions", 0),
                cache_expirations=stats.get("expirations", 0),
            )
    except Exception:
        logger.detail("缓存统计日志记录失败（已忽略）")

    return {
        "cands_all": cands_all,
        "cands_show": cands_show,
        "used_season": used_season,
        "used_title": used_title,
        "used_year": used_year,
        "used_mt": used_mt,
        "selected_hints": selected_hints,
        "hint_src": hint_src,
        "has_main_hint": bool(has_main_hint),
    }
