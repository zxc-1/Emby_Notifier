from __future__ import annotations

"""Cache stage for share->TMDB resolver.

Centralizes the "resolve_from_caches" behavior:
- fast-return on strong mapping without signature
- signature validation for strong mapping with v2 content-hash matching
- v1 signature row one-time migration to v2

This module does not call TMDB; it only validates mappings using share signatures.
"""

import asyncio
import hashlib
from core.logging import get_biz_logger
from typing import Any, Dict, List, Optional, Tuple

from .signatures import compute_share_file_sig_v1

from .repo import upsert_mapping

biz = get_biz_logger(__name__)


def resolve_from_caches_initial(
    *,
    cached_strong: Optional[Dict[str, Any]],
    share_code: str,
    receive_code: str,
    decision_trace: Optional[List[str]] = None,
) -> Optional[Dict[str, Any]]:
    """Fast path before evidence fetch.

    Keep v1.6.12.47 behavior: if we have a strong mapping without file_sig,
    short-circuit immediately.
    """
    if not cached_strong:
        return None
    if str(cached_strong.get("file_sig") or "").strip():
        return None
    if not cached_strong.get("tmdb_id"):
        return None
    if isinstance(decision_trace, list):
        decision_trace.append("cache_fast")
    return {
        "ok": True,
        "tmdb_id": int(cached_strong["tmdb_id"]),
        "share_code": share_code,
        "receive_code": receive_code,
        "from": "cache",
        "cached_title": cached_strong.get("title"),
        "cached_year": cached_strong.get("year"),
        "media_type": cached_strong.get("media_type"),
        "season": cached_strong.get("season"),
        "strength": "strong",
        "confidence": cached_strong.get("confidence"),
        "file_sig": "",
        "decision_trace": decision_trace or [],
    }


async def resolve_from_caches_with_sig(
    *,
    cached_strong: Optional[Dict[str, Any]],
    cached_weak: Optional[Dict[str, Any]],
    share_code: str,
    receive_code: str,
    file_sig: Optional[str],
    best: Dict[str, Any],
    share_title: str,
    filename: str,
    hint_name: str,
    decision_trace: Optional[List[str]] = None,
) -> Tuple[Optional[Dict[str, Any]], Optional[Dict[str, Any]], Optional[Dict[str, Any]], bool]:
    """Validate strong cached mapping using file_sig if present.

    Returns:
      (hit_result_or_none, new_cached_strong, new_cached_weak, sig_mismatch)

    Behavior mirrors v1.6.12.47:
    - If cannot compute current sig -> keep using cache (unchecked)
    - If mismatch -> downgrade strong to weak and continue
    - If match -> return cache_sig hit
    """
    if not cached_strong or not str(cached_strong.get("file_sig") or "").strip():
        return None, cached_strong, cached_weak, False

    exp_sig = str(cached_strong.get("file_sig") or "").strip()

    # If we don't have current file_sig, be conservative: keep using cache.
    if not file_sig:
        if isinstance(decision_trace, list):
            decision_trace.append("cache_sig_unchecked")
        return (
            {
                "ok": True,
                "tmdb_id": int(cached_strong["tmdb_id"]),
                "share_code": share_code,
                "receive_code": receive_code,
                "from": "cache_sig_unchecked",
                "cached_title": cached_strong.get("title"),
                "cached_year": cached_strong.get("year"),
                "media_type": cached_strong.get("media_type"),
                "season": cached_strong.get("season"),
                "strength": "strong",
                "confidence": cached_strong.get("confidence"),
                "share_title": share_title,
                "filename": filename,
                "hint_name": hint_name,
                "file_sig": "",
                "decision_trace": decision_trace or [],
            },
            cached_strong,
            cached_weak,
            False,
        )

    cur_sig = str(file_sig).strip()
    matched = False

    # v2: compare only the content-hash part to avoid rename causing mismatch.
    if exp_sig.startswith("v2:") and cur_sig.startswith("v2:"):
        try:
            exp_c = exp_sig.split(":", 2)[1]
            cur_c = cur_sig.split(":", 2)[1]
        except (ValueError, IndexError) as e:
            biz.detail(f"签名内容哈希提取失败（已忽略） - exp_sig={exp_sig}, cur_sig={cur_sig}, 原因={type(e).__name__}")
            exp_c, cur_c = "", ""
        if exp_c and cur_c and exp_c == cur_c:
            matched = True
    else:
        # legacy v1 rows are stored as plain sha1
        try:
            cur_v1 = compute_share_file_sig_v1(share_code=share_code, receive_code=receive_code, best=(best or {}))
        except (ValueError, TypeError, KeyError) as e:
            biz.detail(f"v1 签名计算失败（已忽略） - share_code={share_code}, 原因={type(e).__name__}")
            cur_v1 = ""
        if cur_v1 and exp_sig == cur_v1:
            matched = True
            # One-time migrate: rewrite DB row to v2 if we have it
            if cur_sig.startswith("v2:"):
                try:
                    await asyncio.to_thread(upsert_mapping, 
                        share_code=share_code,
                        receive_code=(receive_code or cached_strong.get("receive_code")),
                        tmdb_id=int(cached_strong.get("tmdb_id") or 0),
                        media_type=str(cached_strong.get("media_type") or "movie"),
                        title=str(cached_strong.get("title") or ""),
                        year=cached_strong.get("year"),
                        season=cached_strong.get("season"),
                        strength=str(cached_strong.get("strength") or "strong"),
                        confidence=cached_strong.get("confidence"),
                        evidence_title=cached_strong.get("evidence_title"),
                        evidence_year=cached_strong.get("evidence_year"),
                        file_sig=cur_sig,
                    )
                except Exception:
                    biz.detail("cache v1->v2 migrate 失败", exc_info=True)

    if matched:
        if isinstance(decision_trace, list):
            decision_trace.append("cache_sig_hit")
        return (
            {
                "ok": True,
                "tmdb_id": int(cached_strong["tmdb_id"]),
                "share_code": share_code,
                "receive_code": receive_code,
                "from": "cache_sig",
                "cached_title": cached_strong.get("title"),
                "cached_year": cached_strong.get("year"),
                "media_type": cached_strong.get("media_type"),
                "season": cached_strong.get("season"),
                "strength": "strong",
                "confidence": cached_strong.get("confidence"),
                "share_title": share_title,
                "filename": filename,
                "hint_name": hint_name,
                "file_sig": cur_sig,
                "decision_trace": decision_trace or [],
            },
            cached_strong,
            cached_weak,
            False,
        )

    # mismatch: downgrade the old strong mapping to weak and continue
    try:
        sc_h = hashlib.sha1(str(share_code).encode("utf-8")).hexdigest()[:10]
    except (ValueError, TypeError) as e:
        biz.detail(f"分享码哈希计算失败（已忽略） - share_code={share_code}, 原因={type(e).__name__}")
        sc_h = str(share_code)[-6:]
    biz.warning(
        f"⚠️ 缓存签名不匹配：分享内容可能已更新，将重新识别",
        分享码哈希=sc_h,
        期望签名=str(exp_sig or "")[:24],
        当前签名=str(cur_sig or "")[:24],
    )
    if isinstance(decision_trace, list):
        decision_trace.append("cache_sig_mismatch")

    cached_weak_new = cached_strong
    cached_strong_new = None
    return None, cached_strong_new, cached_weak_new, True
