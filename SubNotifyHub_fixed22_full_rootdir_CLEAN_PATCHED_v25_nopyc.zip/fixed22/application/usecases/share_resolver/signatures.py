from __future__ import annotations

import hashlib
import json
from typing import Any, Dict, Optional


def _sha1_of_payload(payload: dict) -> str:
    s = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha1(s.encode("utf-8")).hexdigest()


def compute_share_file_sig_v1(
    *,
    share_code: str,
    receive_code: Optional[str],
    best: Dict[str, Any],
) -> str:
    """Legacy v1 signature (sensitive to title/path/hints).

    Kept for backward compatibility so old DB rows (plain sha1) can still be validated.
    """
    sc = str(share_code or "").strip()
    rc = str(receive_code or "").strip()
    b = best or {}
    payload = {
        "v": 1,
        "share_code": sc,
        "receive_code": rc,
        "filename": str(b.get("filename") or ""),
        "best_file_id": str(b.get("best_file_id") or ""),
        "best_size": int(b.get("best_size") or 0),
        "dir_path": [str(x) for x in (b.get("dir_path") or []) if isinstance(x, str) and x.strip()],
        "video_count": int(b.get("video_count") or 0),
        "share_title": str(b.get("share_title") or ""),
        "hint_name": str(b.get("hint_name") or ""),
        "fallback": bool(b.get("fallback")),
    }
    return _sha1_of_payload(payload)


def compute_share_file_sig_v2(
    *,
    share_code: str,
    receive_code: Optional[str],
    best: Dict[str, Any],
) -> str:
    """v2 signature: stable content hash + optional hint hash.

    - Primary goal: avoid invalidating strong mappings due to share title/dir renames.
    - Compare should use the *content* part only.

    Format: "v2:<content_sha1>:<hint_sha1>"
    """
    sc = str(share_code or "").strip()
    rc = str(receive_code or "").strip()
    b = best or {}

    best_file_id = str(b.get("best_file_id") or "").strip()
    best_size = int(b.get("best_size") or 0)
    vc = int(b.get("video_count") or 0)
    fb = bool(b.get("fallback"))

    content_payload = {
        "v": 2,
        "share_code": sc,
        "receive_code": rc,
        "best_file_id": best_file_id,
        "best_size": best_size,
        "video_count": vc,
        "fallback": fb,
    }
    if not best_file_id:
        content_payload["fallback_hint"] = str(b.get("hint_name") or b.get("filename") or b.get("share_title") or "")

    hint_payload = {
        "v": 2,
        "share_title": str(b.get("share_title") or ""),
        "filename": str(b.get("filename") or ""),
        "hint_name": str(b.get("hint_name") or ""),
        "dir_path": [str(x) for x in (b.get("dir_path") or []) if isinstance(x, str) and x.strip()],
    }

    content_hash = _sha1_of_payload(content_payload)
    hint_hash = _sha1_of_payload(hint_payload)
    return f"v2:{content_hash}:{hint_hash}"


def compute_share_file_sig(
    *,
    share_code: str,
    receive_code: Optional[str],
    best: Dict[str, Any],
) -> str:
    """Compute a stable signature for a share snapshot.

    v2 is the default. Use compute_share_file_sig_v1 for validating legacy DB rows.
    """
    return compute_share_file_sig_v2(share_code=share_code, receive_code=receive_code, best=best)
