# -*- coding: utf-8 -*-
"""TMDB search result caching.

This module provides LRU caching for TMDB search results to reduce API calls
and improve performance.

Requirement 6: TMDB 搜索缓存
- 6.1: 实现 LRU 缓存
- 6.2: 集成到搜索流程
- 6.3: 缓存键唯一性
- 6.4: TTL 过期机制
- 6.5: LRU 淘汰策略
- 6.6: 缓存统计
"""
from __future__ import annotations

import threading
import time
from collections import OrderedDict
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple, TypeVar

from core.logging import get_biz_logger_adapter

logger = get_biz_logger_adapter(__name__)

T = TypeVar("T")


@dataclass
class CacheStats:
    """Cache statistics."""
    hits: int = 0
    misses: int = 0
    evictions: int = 0
    expirations: int = 0
    
    def hit_rate(self) -> float:
        """Calculate cache hit rate."""
        total = self.hits + self.misses
        return self.hits / total if total > 0 else 0.0
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "hits": self.hits,
            "misses": self.misses,
            "evictions": self.evictions,
            "expirations": self.expirations,
            "hit_rate": round(self.hit_rate(), 4),
        }


@dataclass
class CacheEntry:
    """Cache entry with timestamp."""
    value: List[Dict[str, Any]]
    timestamp: float
    
    def is_expired(self, ttl_sec: float) -> bool:
        """Check if entry is expired."""
        # Use a monotonic clock to avoid issues when system time jumps.
        return (time.monotonic() - self.timestamp) > ttl_sec


class LRUSearchCache:
    """LRU cache for TMDB search results.
    
    Thread-safe implementation with TTL expiration and LRU eviction.
    
    Attributes:
        max_size: Maximum number of entries in cache
        ttl_sec: Time-to-live in seconds for cache entries
    """
    
    def __init__(
        self,
        max_size: int = 1000,
        ttl_sec: float = 3600.0,
    ):
        """Initialize cache.
        
        Args:
            max_size: Maximum number of entries (default: 1000)
            ttl_sec: TTL in seconds (default: 3600 = 1 hour)
        """
        self._cache: OrderedDict[str, CacheEntry] = OrderedDict()
        self._max_size = max_size
        self._ttl_sec = ttl_sec
        self._lock = threading.Lock()
        self._stats = CacheStats()
    
    def _make_key(self, query: str, year: Optional[int], media_type: str) -> str:
        """Generate cache key from search parameters.
        
        Key format: "query_normalized|year_or_empty|media_type"
        
        Args:
            query: Search query string
            year: Optional year filter
            media_type: Media type ("movie", "tv", "multi")
            
        Returns:
            Unique cache key string
        """
        # Normalize query: lowercase, strip whitespace
        q_norm = (query or "").lower().strip()
        # Year: empty string if None
        y_str = str(year) if year is not None else ""
        # Media type: lowercase
        mt_norm = (media_type or "multi").lower().strip()
        
        return f"{q_norm}|{y_str}|{mt_norm}"
    
    def get(
        self,
        query: str,
        year: Optional[int],
        media_type: str,
    ) -> Optional[List[Dict[str, Any]]]:
        """Get cached results if not expired.
        
        Args:
            query: Search query string
            year: Optional year filter
            media_type: Media type
            
        Returns:
            Cached results if found and not expired, None otherwise
        """
        key = self._make_key(query, year, media_type)
        
        with self._lock:
            entry = self._cache.get(key)
            
            if entry is None:
                self._stats.misses += 1
                return None
            
            # Check expiration
            if entry.is_expired(self._ttl_sec):
                # Remove expired entry
                del self._cache[key]
                self._stats.expirations += 1
                self._stats.misses += 1
                return None
            
            # Move to end (most recently used)
            self._cache.move_to_end(key)
            self._stats.hits += 1
            
            return entry.value
    
    def set(
        self,
        query: str,
        year: Optional[int],
        media_type: str,
        results: List[Dict[str, Any]],
    ) -> None:
        """Cache search results with LRU eviction.
        
        Args:
            query: Search query string
            year: Optional year filter
            media_type: Media type
            results: Search results to cache
        """
        key = self._make_key(query, year, media_type)
        
        with self._lock:
            # If key exists, update and move to end
            if key in self._cache:
                self._cache[key] = CacheEntry(value=results, timestamp=time.monotonic())
                self._cache.move_to_end(key)
                return
            
            # Evict oldest entries if at capacity
            while len(self._cache) >= self._max_size:
                # Remove oldest (first) entry
                oldest_key = next(iter(self._cache))
                del self._cache[oldest_key]
                self._stats.evictions += 1
            
            # Add new entry
            self._cache[key] = CacheEntry(value=results, timestamp=time.monotonic())
    
    def get_stats(self) -> Dict[str, Any]:
        """Get cache statistics.
        
        Returns:
            Dictionary with hit/miss/eviction counts and hit rate
        """
        with self._lock:
            stats = self._stats.to_dict()
            stats["size"] = len(self._cache)
            stats["max_size"] = self._max_size
            stats["ttl_sec"] = self._ttl_sec
            return stats
    
    def clear(self) -> None:
        """Clear all cache entries."""
        with self._lock:
            self._cache.clear()
    
    def reset_stats(self) -> None:
        """Reset statistics counters."""
        with self._lock:
            self._stats = CacheStats()
    
    def size(self) -> int:
        """Get current cache size."""
        with self._lock:
            return len(self._cache)
    
    def contains(self, query: str, year: Optional[int], media_type: str) -> bool:
        """Check if key exists in cache (without updating LRU order).
        
        Args:
            query: Search query string
            year: Optional year filter
            media_type: Media type
            
        Returns:
            True if key exists and not expired
        """
        key = self._make_key(query, year, media_type)
        
        with self._lock:
            entry = self._cache.get(key)
            if entry is None:
                return False
            return not entry.is_expired(self._ttl_sec)


# Global cache instance
_SEARCH_CACHE: Optional[LRUSearchCache] = None
_CACHE_LOCK = threading.Lock()


def get_search_cache(
    max_size: int = 1000,
    ttl_sec: float = 3600.0,
) -> LRUSearchCache:
    """Get or create the global search cache instance.
    
    Args:
        max_size: Maximum cache size (only used on first call)
        ttl_sec: TTL in seconds (only used on first call)
        
    Returns:
        Global LRUSearchCache instance
    """
    global _SEARCH_CACHE
    
    with _CACHE_LOCK:
        if _SEARCH_CACHE is None:
            _SEARCH_CACHE = LRUSearchCache(max_size=max_size, ttl_sec=ttl_sec)
        return _SEARCH_CACHE


def reset_search_cache() -> None:
    """Reset the global search cache (for testing)."""
    global _SEARCH_CACHE
    
    with _CACHE_LOCK:
        _SEARCH_CACHE = None


async def cached_search(
    query: str,
    year: Optional[int],
    media_type: str,
    *,
    searcher: Callable[..., Any],
    cache: Optional[LRUSearchCache] = None,
) -> List[Dict[str, Any]]:
    """Execute search with caching.
    
    Args:
        query: Search query string
        year: Optional year filter
        media_type: Media type
        searcher: Async function to call if cache miss
        cache: Optional cache instance (uses global if None)
        
    Returns:
        Search results (from cache or fresh)
    """
    if cache is None:
        cache = get_search_cache()
    
    # Try cache first
    cached = cache.get(query, year, media_type)
    if cached is not None:
        logger.detail(f"搜索缓存命中 - query={query}, year={year}, media_type={media_type}")
        return cached
    
    # Cache miss - execute search
    logger.detail(f"搜索缓存未命中 - query={query}, year={year}, media_type={media_type}")
    
    try:
        results = await searcher(query, year, media_type)
        
        # Cache results
        if isinstance(results, list):
            cache.set(query, year, media_type, results)
        
        return results if isinstance(results, list) else []
    except Exception as e:
        logger.detail(f"搜索执行失败（已忽略） - query={query}, 原因={type(e).__name__}")
        return []
