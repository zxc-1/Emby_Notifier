from __future__ import annotations
from core.task_registry import create_task_logged

"""Share evidence snapshot for TMDB resolver.

This module isolates the *share-content reading* part of the "no TMDB" chain.
Networking and expensive scans are centralized here so the resolver orchestration
can remain smaller and easier to reason about.

v1.6.12.47 additions:
- per-share async lock (prevents concurrent stampedes)
- small in-memory TTL cache for resolved evidence
- clearer failure classification ("temp unavailable" vs "incomplete evidence")
"""

import asyncio
import logging
from core.logging import get_biz_logger_adapter
import time
from typing import Any, Dict, Optional, Tuple

from ports.settings_provider import get_settings
from .ports_access import share115
from .signatures import compute_share_file_sig

from .hints import _fast_hint_strong, _is_garbage_hint

logger = get_biz_logger_adapter(__name__)

# ---------------------------------------------------------------------------
# Small in-memory cache + stampede lock
# ---------------------------------------------------------------------------

_EVIDENCE_CACHE: dict[tuple[str, str], tuple[float, dict[str, Any]]] = {}
_EVIDENCE_LOCKS: dict[str, asyncio.Lock] = {}
# Track last access time for locks to prevent unbounded growth.
_EVIDENCE_LOCKS_LAST: dict[str, float] = {}
_EVIDENCE_LOCKS_GUARD = asyncio.Lock()


def _looks_temp_unavailable(reason: str) -> bool:
    t = str(reason or "").lower()
    if not t:
        return False
    needles = [
        "429",
        "too many requests",
        "rate limit",
        "ratelimit",
        "too fast",
        "频繁",
        "过于频繁",
        "访问过快",
        "限制",
        "risk",
        "风控",
        "unauthorized",
        "cookie",
        "invalid",
        "need login",
        "login",
        "forbidden",
        "timeout",
        "timed out",
        "connect",
        "network",
        "remoteprotocol",
    ]
    return any(n in t for n in needles)


def _get_cache(key: tuple[str, str], ttl_sec: float) -> Optional[dict[str, Any]]:
    try:
        ts, val = _EVIDENCE_CACHE.get(key, (0.0, {}))
        if not isinstance(val, dict):
            return None
        # Use monotonic time for TTL to avoid system clock jumps.
        age = (time.monotonic() - float(ts))
        if age <= float(ttl_sec):
            return dict(val)
        # Best-effort: drop expired entry to avoid unbounded growth.
        _EVIDENCE_CACHE.pop(key, None)
    except (TypeError, ValueError, KeyError) as e:
        logger.detail(f"分享证据缓存读取失败（已忽略） - key={key}, 原因={type(e).__name__}")
        return None
    return None


def _set_cache(key: tuple[str, str], val: dict[str, Any]) -> None:
    try:
        # Avoid unbounded growth: keep the cache at a reasonable size.
        if len(_EVIDENCE_CACHE) > 2048:
            now = time.monotonic()
            # Drop very old entries first.
            stale_before = now - 3600.0
            stale_keys = [k for k, (ts, _v) in _EVIDENCE_CACHE.items() if (now - float(ts)) > 3600.0]
            for k in stale_keys[:512]:
                _EVIDENCE_CACHE.pop(k, None)
            # If still too big, drop the oldest entries.
            if len(_EVIDENCE_CACHE) > 2048:
                for k, _ in sorted(_EVIDENCE_CACHE.items(), key=lambda kv: float(kv[1][0]))[:512]:
                    _EVIDENCE_CACHE.pop(k, None)
        _EVIDENCE_CACHE[key] = (float(time.monotonic()), dict(val))
    except (TypeError, ValueError) as e:
        logger.detail(f"分享证据缓存写入失败（已忽略） - key={key}, 原因={type(e).__name__}")


async def _get_lock(share_code: str) -> asyncio.Lock:
    sc = str(share_code or "").strip()
    if not sc:
        return asyncio.Lock()
    async with _EVIDENCE_LOCKS_GUARD:
        # Prune old locks occasionally to avoid unbounded growth.
        # This is best-effort and safe: locks are re-created on demand.
        if len(_EVIDENCE_LOCKS) > 2048:
            now = time.monotonic()
            # Drop locks not used in the last 30 minutes.
            stale_before = now - 1800.0
            stale_keys = [k for k, t in _EVIDENCE_LOCKS_LAST.items() if t < stale_before]
            for k in stale_keys:
                _EVIDENCE_LOCKS.pop(k, None)
                _EVIDENCE_LOCKS_LAST.pop(k, None)

        lk = _EVIDENCE_LOCKS.get(sc)
        if lk is None:
            lk = asyncio.Lock()
            _EVIDENCE_LOCKS[sc] = lk
        _EVIDENCE_LOCKS_LAST[sc] = time.monotonic()
        return lk


def _settings_int(name: str, default: int, *, lo: int | None = None, hi: int | None = None) -> int:
    try:
        s = get_settings()
        v = int(getattr(s, name, default) or default)
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"配置项读取失败，使用默认值 - name={name}, default={default}, 原因={type(e).__name__}")
        v = int(default)
    if lo is not None:
        v = max(int(lo), int(v))
    if hi is not None:
        v = min(int(hi), int(v))
    return int(v)


def _settings_float(name: str, default: float, *, lo: float | None = None, hi: float | None = None) -> float:
    try:
        s = get_settings()
        v = float(getattr(s, name, default) or default)
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"配置项读取失败，使用默认值 - name={name}, default={default}, 原因={type(e).__name__}")
        v = float(default)
    if lo is not None:
        v = max(float(lo), float(v))
    if hi is not None:
        v = min(float(hi), float(v))
    return float(v)


def _is_strong_evidence(result: dict[str, Any]) -> bool:
    """Check if evidence result is strong enough to skip deep scan.
    
    Strong evidence means:
    - ok=True with best_file
    - hint_name or share_title is not garbage
    - Either _fast_hint_strong returns True (for the whole result dict)
    - Or title contains CJK characters and is long enough
    - Or title is a meaningful English title (long enough, not garbage)
    """
    if not isinstance(result, dict) or not result.get("ok"):
        return False
    if not result.get("best_file"):
        return False
    
    # First, try _fast_hint_strong which checks the whole result dict
    try:
        if _fast_hint_strong(result):
            return True
    except (ValueError, TypeError) as e:
        logger.detail(f"快速提示强度检查失败（已忽略） - 原因={type(e).__name__}")
    
    # Check hint quality - prefer hint_name and share_title over filename
    hint_name = str(result.get("hint_name") or "").strip()
    share_title = str(result.get("share_title") or "").strip()
    filename = str(result.get("filename") or "").strip()
    
    # Prioritize hint_name and share_title over filename
    title_probe = hint_name or share_title
    if not title_probe:
        # Only use filename if it looks meaningful
        if filename and len(filename) >= 8:
            # Remove extension
            name_without_ext = filename.rsplit(".", 1)[0] if "." in filename else filename
            if len(name_without_ext) >= 6:
                title_probe = name_without_ext
    
    if not title_probe or len(title_probe) <= 2:
        return False
    
    try:
        if _is_garbage_hint(title_probe):
            return False
        
        # Check for CJK characters as a strong indicator
        has_cjk = any('\u4e00' <= c <= '\u9fff' for c in title_probe)
        if has_cjk and len(title_probe) >= 4:
            return True
        
        # For non-CJK titles, require longer length and meaningful content
        # (multiple words, not just technical terms)
        if not has_cjk:
            words = title_probe.split()
            # At least 2 words and total length >= 8
            if len(words) >= 2 and len(title_probe) >= 8:
                # Check it's not all technical terms
                tech_terms = {"1080p", "2160p", "x264", "x265", "hevc", "avc", "bluray", "webrip", "hdr", "dv"}
                non_tech_words = [w for w in words if w.lower() not in tech_terms]
                if len(non_tech_words) >= 2:
                    return True
    except (ValueError, TypeError) as e:
        logger.detail(f"强证据判断失败（已忽略） - title_probe={title_probe}, 原因={type(e).__name__}")
    
    # Default: NOT strong unless explicitly determined above
    return False


async def _do_fast_scan(
    sc: str,
    rc: str,
    timeout: float,
) -> dict[str, Any]:
    """Execute fast scan (depth=0, no directory traversal)."""
    return await asyncio.wait_for(
        share115().resolve_best_video_for_share(
            share_code=sc,
            receive_code=rc or None,
            max_depth=0,
            max_dir_scans=0,
        ),
        timeout=timeout,
    )


async def _do_deep1_scan(
    sc: str,
    rc: str,
    timeout: float,
    max_depth: int,
    max_dir_scans: int,
) -> dict[str, Any]:
    """Execute deep1 scan (moderate depth)."""
    return await asyncio.wait_for(
        share115().resolve_best_video_for_share(
            share_code=sc,
            receive_code=rc or None,
            max_depth=max_depth,
            max_dir_scans=max_dir_scans,
        ),
        timeout=timeout,
    )


async def _do_deep2_scan(
    sc: str,
    rc: str,
    timeout: float,
    max_depth: int,
    max_dir_scans: int,
) -> dict[str, Any]:
    """Execute deep2 scan (maximum depth)."""
    return await asyncio.wait_for(
        share115().resolve_best_video_for_share(
            share_code=sc,
            receive_code=rc or None,
            max_depth=max_depth,
            max_dir_scans=max_dir_scans,
        ),
        timeout=timeout,
    )


async def fetch_share_evidence(
    *,
    share_url: str,
    share_code: str,
    receive_code: str,
    decision_trace: Optional[list[str]] = None,
) -> dict[str, Any]:
    """Fetch share evidence using parallel fast+deep strategy.

    Strategy (Requirement 4 - 并行扫描优化):
    1. Start fast_scan and deep1_scan in parallel
    2. If fast_scan succeeds with strong hints, cancel deep1_scan
    3. If fast_scan fails/weak, wait for deep1_scan
    4. If deep1_scan fails, try deep2_scan

    Returns a dict with:
      ok: bool
      best: dict (raw resolve_best_video_for_share output) when ok
      file_sig: str
      reason: str (when not ok)
      temp_unavailable: bool
      evidence_weak: bool (when ok but hint looks weak)
      elapsed_ms: int
      scan_strategy: str (which scan strategy was used)
    """
    # Use a monotonic clock for elapsed time.
    t0 = time.perf_counter()
    trace = decision_trace if isinstance(decision_trace, list) else None

    sc = str(share_code or "").strip()
    rc = str(receive_code or "").strip()

    if not sc:
        return {
            "ok": False,
            "reason": "share_code_missing",
            "temp_unavailable": False,
            "elapsed_ms": int((time.perf_counter() - t0) * 1000),
        }

    # Cache key includes receive_code (sub-code) because it can change the view.
    key = (sc, rc or "")
    ttl_ok = _settings_float("SHARE115_EVIDENCE_CACHE_TTL_SEC", 120.0, lo=15.0, hi=3600.0)
    cached = _get_cache(key, ttl_ok)
    if cached and cached.get("ok"):
        if trace is not None:
            trace.append("evidence:cache_hit")
        cached["elapsed_ms"] = int((time.time() - t0) * 1000)
        return cached

    lk = await _get_lock(sc)
    async with lk:
        # Re-check cache after acquiring lock.
        cached2 = _get_cache(key, ttl_ok)
        if cached2 and cached2.get("ok"):
            if trace is not None:
                trace.append("evidence:cache_hit_locked")
            cached2["elapsed_ms"] = int((time.time() - t0) * 1000)
            return cached2

        # Settings-driven scan parameters (optimization #6).
        fast_timeout = _settings_float("SHARE115_SNAP_FAST_TIMEOUT_SEC", 3.5, lo=1.0, hi=30.0)
        deep1_timeout = _settings_float("SHARE115_SNAP_DEEP1_TIMEOUT_SEC", 6.0, lo=1.0, hi=60.0)
        deep2_timeout = _settings_float("SHARE115_SNAP_DEEP2_TIMEOUT_SEC", 10.0, lo=2.0, hi=90.0)

        deep1_depth = _settings_int("SHARE115_SNAP_DEEP1_MAX_DEPTH", 10, lo=0, hi=50)
        deep1_scans = _settings_int("SHARE115_SNAP_DEEP1_MAX_DIR_SCANS", 12, lo=0, hi=80)

        deep2_depth = _settings_int("SHARE115_SNAP_DEEP2_MAX_DEPTH", 20, lo=0, hi=80)
        deep2_scans = _settings_int("SHARE115_SNAP_DEEP2_MAX_DIR_SCANS", 25, lo=0, hi=150)

        best: dict[str, Any] = {}
        scan_strategy = "unknown"
        deep1_task: Optional[asyncio.Task[dict[str, Any]]] = None
        fast_task: Optional[asyncio.Task[dict[str, Any]]] = None
        
        try:
            # ============================================================
            # Parallel scan strategy (Requirement 4):
            # Start fast and deep1 scans in parallel
            # ============================================================
            if trace is not None:
                trace.append("evidence:parallel_scan_start")
            
            # Create tasks for parallel execution
            fast_task = create_task_logged(
                _do_fast_scan(sc, rc, fast_timeout),
                name=f"fast_scan_{sc}",
                log=logger,
            )
            deep1_task = create_task_logged(
                _do_deep1_scan(sc, rc, deep1_timeout, deep1_depth, deep1_scans),
                name=f"deep1_scan_{sc}",
                log=logger,
            )
            
            # Wait for fast scan first
            fast_result: Optional[dict[str, Any]] = None
            fast_ok = False
            fast_strong = False
            
            try:
                fast_result = await fast_task
                fast_ok = isinstance(fast_result, dict) and fast_result.get("ok") and fast_result.get("best_file")
                fast_strong = fast_ok and _is_strong_evidence(fast_result)
                
                if fast_strong:
                    # Fast scan succeeded with strong hints - cancel deep1
                    if trace is not None:
                        trace.append("evidence:fast_scan_strong")
                    deep1_task.cancel()
                    try:
                        await deep1_task
                    except asyncio.CancelledError:
                        if trace is not None:
                            trace.append("evidence:deep1_cancelled")
                    best = fast_result
                    scan_strategy = "fast_strong"
                    
            except asyncio.TimeoutError:
                if trace is not None:
                    trace.append("evidence:fast_scan_timeout")
            except asyncio.CancelledError:
                if trace is not None:
                    trace.append("evidence:fast_scan_cancelled")
            except Exception as e:
                if trace is not None:
                    trace.append(f"evidence:fast_scan_error:{type(e).__name__}")
            
            # If fast scan didn't produce strong result, wait for deep1
            if not best:
                if trace is not None:
                    trace.append("evidence:waiting_deep1")
                
                try:
                    deep1_result = await deep1_task
                    if isinstance(deep1_result, dict) and deep1_result.get("ok") and deep1_result.get("best_file"):
                        best = deep1_result
                        scan_strategy = "deep1"
                        if trace is not None:
                            trace.append("evidence:deep1_success")
                    elif fast_ok and fast_result:
                        # Deep1 failed but fast had weak result - use fast
                        best = fast_result
                        scan_strategy = "fast_weak"
                        if trace is not None:
                            trace.append("evidence:fallback_to_fast_weak")
                except asyncio.CancelledError:
                    # Deep1 was cancelled (shouldn't happen here, but handle it)
                    if fast_ok and fast_result:
                        best = fast_result
                        scan_strategy = "fast_weak"
                except asyncio.TimeoutError:
                    if trace is not None:
                        trace.append("evidence:deep1_timeout")
                    if fast_ok and fast_result:
                        best = fast_result
                        scan_strategy = "fast_weak"
                except Exception as e:
                    if trace is not None:
                        trace.append(f"evidence:deep1_error:{type(e).__name__}")
                    if fast_ok and fast_result:
                        best = fast_result
                        scan_strategy = "fast_weak"
            
            # If still no result, try deep2 scan
            if not best:
                if trace is not None:
                    trace.append("evidence:deep_scan2")
                try:
                    best = await _do_deep2_scan(sc, rc, deep2_timeout, deep2_depth, deep2_scans)
                    scan_strategy = "deep2"
                except asyncio.TimeoutError:
                    if trace is not None:
                        trace.append("evidence:deep2_timeout")
                except Exception as e:
                    if trace is not None:
                        trace.append(f"evidence:deep2_error:{type(e).__name__}")
                        
        except Exception as e:
            reason = str(e).strip() or type(e).__name__
            if trace is not None:
                trace.append(f"evidence:exception:{type(e).__name__}")
            return {
                "ok": False,
                "reason": reason,
                "temp_unavailable": _looks_temp_unavailable(reason),
                "elapsed_ms": int((time.time() - t0) * 1000),
                "scan_strategy": scan_strategy,
            }
        finally:
            # ============================================================
            # Resource cleanup (Requirement 4.5):
            # Ensure all tasks are properly cleaned up
            # ============================================================
            async def _cleanup_task(task: Optional[asyncio.Task], name: str) -> None:
                if task is None:
                    return
                if task.done():
                    # Task already completed, just retrieve exception if any
                    try:
                        task.result()
                    except (asyncio.CancelledError, Exception):
                        pass
                else:
                    # Task still running, cancel it
                    task.cancel()
                    try:
                        await task
                    except (asyncio.CancelledError, Exception):
                        pass
                    if trace is not None:
                        trace.append(f"evidence:cleanup_{name}")
            
            # Clean up any remaining tasks
            await _cleanup_task(fast_task, "fast")
            await _cleanup_task(deep1_task, "deep1")

        if not isinstance(best, dict) or not best.get("ok"):
            reason = str((best or {}).get("reason") or "share_read_failed")
            reason_code = str((best or {}).get("reason_code") or "").strip() or None
            err_obj = (best or {}).get("error") if isinstance(best, dict) else None
            if trace is not None:
                trace.append(f"evidence:fail:{reason_code or reason}")
            # temp_unavailable is derived from either reason_code or reason string
            tmp = False
            if reason_code in ("share115_rate_limited", "share115_temp_unavailable"):
                tmp = True
            else:
                tmp = _looks_temp_unavailable(reason)
            out = {
                "ok": False,
                "reason": reason,
                "reason_code": reason_code,
                "error": err_obj if isinstance(err_obj, dict) else None,
                "temp_unavailable": bool(tmp),
                "elapsed_ms": int((time.time() - t0) * 1000),
                "scan_strategy": scan_strategy,
            }
            return out

        # Success
        file_sig = ""
        try:
            file_sig = str(compute_share_file_sig(share_code=sc, receive_code=rc or None, best=best) or "")
        except (ValueError, TypeError, KeyError) as e:
            logger.detail(f"分享文件签名计算失败（已忽略） - share_code={sc}, 原因={type(e).__name__}")
            file_sig = ""

        # Evidence weakness heuristic (optimization #1): distinguish "read ok but hint too weak".
        hint_name = str(best.get("hint_name") or "").strip()
        share_title = str(best.get("share_title") or "").strip()
        filename = str(best.get("filename") or "").strip()
        title_probe = hint_name or share_title or filename
        evidence_weak = False
        try:
            if not title_probe or _is_garbage_hint(title_probe):
                evidence_weak = True
            if len(title_probe) <= 2:
                evidence_weak = True
            if bool(best.get("fallback")) and int(best.get("video_count") or 0) == 0:
                evidence_weak = True
        except (ValueError, TypeError, KeyError) as e:
            logger.detail(f"证据弱化判断失败（已忽略） - title_probe={title_probe}, 原因={type(e).__name__}")

        out = {
            "ok": True,
            "best": best,
            "file_sig": file_sig,
            "temp_unavailable": False,
            "evidence_weak": bool(evidence_weak),
            "elapsed_ms": int((time.time() - t0) * 1000),
            "scan_strategy": scan_strategy,
        }
        _set_cache(key, out)
        return out
