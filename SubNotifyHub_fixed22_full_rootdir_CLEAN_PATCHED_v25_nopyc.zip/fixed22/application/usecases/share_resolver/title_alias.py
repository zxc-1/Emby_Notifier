# -*- coding: utf-8 -*-
"""Multi-language title alias matching.

This module provides alias-based title matching to improve TMDB search accuracy
for CJK queries that may have English equivalents.

Requirement 2: 多语言标题关联
- 2.1: 获取 TMDB alternative titles
- 2.2: 缓存别名映射（TTL >= 1 hour）
- 2.3: 别名匹配时提升候选分数
- 2.4: 支持 movie 和 TV 的 alternative titles
- 2.5: API 错误时优雅降级
- 2.6: 规范化标题用于比较
"""
from __future__ import annotations

import re
import threading
import time
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

from core.logging import get_biz_logger_adapter

logger = get_biz_logger_adapter(__name__)


@dataclass
class AliasCache:
    """Alias cache entry."""
    aliases: List[str]
    normalized_aliases: List[str]
    timestamp: float
    tmdb_id: int
    media_type: str


# In-memory cache with TTL
_ALIAS_CACHE: Dict[Tuple[int, str], AliasCache] = {}
_ALIAS_CACHE_LOCK = threading.Lock()
_ALIAS_CACHE_TTL_SEC = 3600.0  # 1 hour (Requirement 2.2)
_ALIAS_CACHE_MAX_SIZE = 500  # Maximum cache entries


def normalize_alias(title: str) -> str:
    """Normalize title for comparison (Requirement 2.6).
    
    Normalization rules:
    - Lowercase
    - Remove punctuation (keep CJK characters)
    - Normalize whitespace to single spaces
    - Strip leading/trailing whitespace
    
    Args:
        title: Title string to normalize
        
    Returns:
        Normalized title string
    """
    if not title:
        return ""
    
    # Lowercase
    t = title.lower()
    
    # Remove punctuation but keep CJK characters and alphanumeric
    # Keep: a-z, 0-9, CJK unified ideographs, hiragana, katakana, spaces
    t = re.sub(r"[^\w\s\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]", " ", t)
    
    # Normalize whitespace
    t = re.sub(r"\s+", " ", t).strip()
    
    return t


def compute_alias_similarity(query: str, alias: str) -> float:
    """Compute similarity between query and alias (Requirement 2.3).
    
    Uses normalized comparison with Jaccard similarity:
    - Character-level for CJK text
    - Word-level for Latin text
    
    Args:
        query: Search query string
        alias: Alias string to compare
        
    Returns:
        Similarity score between 0.0 and 1.0
    """
    q_norm = normalize_alias(query)
    a_norm = normalize_alias(alias)
    
    if not q_norm or not a_norm:
        return 0.0
    
    # Exact match after normalization
    if q_norm == a_norm:
        return 1.0
    
    # Check if either contains CJK
    has_cjk = bool(re.search(r"[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]", q_norm + a_norm))
    
    if has_cjk:
        # Character-level Jaccard for CJK
        set_q = set(q_norm.replace(" ", ""))
        set_a = set(a_norm.replace(" ", ""))
    else:
        # Word-level Jaccard for Latin
        set_q = set(q_norm.split())
        set_a = set(a_norm.split())
    
    if not set_q or not set_a:
        return 0.0
    
    intersection = len(set_q & set_a)
    union = len(set_q | set_a)
    
    return intersection / union if union > 0 else 0.0


def _is_cache_expired(entry: AliasCache) -> bool:
    """Check if cache entry is expired."""
    return (time.time() - entry.timestamp) > _ALIAS_CACHE_TTL_SEC


def _get_cached_aliases(tmdb_id: int, media_type: str) -> Optional[AliasCache]:
    """Get cached aliases if not expired."""
    key = (int(tmdb_id), str(media_type).lower())
    
    with _ALIAS_CACHE_LOCK:
        entry = _ALIAS_CACHE.get(key)
        if entry is None:
            return None
        
        if _is_cache_expired(entry):
            # Remove expired entry
            del _ALIAS_CACHE[key]
            return None
        
        return entry


def _set_cached_aliases(
    tmdb_id: int,
    media_type: str,
    aliases: List[str],
) -> None:
    """Cache aliases with LRU eviction."""
    key = (int(tmdb_id), str(media_type).lower())
    
    # Pre-compute normalized aliases
    normalized = [normalize_alias(a) for a in aliases if a]
    
    entry = AliasCache(
        aliases=aliases,
        normalized_aliases=normalized,
        timestamp=time.time(),
        tmdb_id=int(tmdb_id),
        media_type=str(media_type).lower(),
    )
    
    with _ALIAS_CACHE_LOCK:
        # Evict oldest entries if at capacity
        while len(_ALIAS_CACHE) >= _ALIAS_CACHE_MAX_SIZE:
            # Find oldest entry
            oldest_key = None
            oldest_ts = float("inf")
            for k, v in _ALIAS_CACHE.items():
                if v.timestamp < oldest_ts:
                    oldest_ts = v.timestamp
                    oldest_key = k
            if oldest_key:
                del _ALIAS_CACHE[oldest_key]
            else:
                break
        
        _ALIAS_CACHE[key] = entry



async def fetch_title_aliases(
    tmdb_id: int,
    media_type: str,
    *,
    timeout: float = 3.0,
) -> List[str]:
    """Fetch alternative titles from TMDB API (Requirement 2.1, 2.4).
    
    Calls:
    - /movie/{id}/alternative_titles for movies
    - /tv/{id}/alternative_titles for TV shows
    
    Results are cached with TTL (Requirement 2.2).
    
    Args:
        tmdb_id: TMDB ID of the title
        media_type: "movie" or "tv"
        timeout: Request timeout in seconds
        
    Returns:
        List of alternative titles (all languages)
    """
    # Check cache first (Requirement 2.2)
    cached = _get_cached_aliases(tmdb_id, media_type)
    if cached is not None:
        logger.detail(f"别名缓存命中 - tmdb_id={tmdb_id}, media_type={media_type}")
        return cached.aliases
    
    # Cache miss - fetch from TMDB
    logger.detail(f"别名缓存未命中 - tmdb_id={tmdb_id}, media_type={media_type}")
    
    try:
        # Use existing implementation from integrations
        from integrations.tmdb_match.aliases import fetch_tmdb_alias_titles
        
        aliases = await fetch_tmdb_alias_titles(
            tmdb_id=int(tmdb_id),
            media_type=str(media_type),
        )
        
        result = aliases if isinstance(aliases, list) else []
        
        # Cache the result
        _set_cached_aliases(tmdb_id, media_type, result)
        
        return result
        
    except Exception as e:
        # Graceful fallback (Requirement 2.5)
        logger.detail(f"别名获取失败（已忽略） - tmdb_id={tmdb_id}, 原因={type(e).__name__}")
        
        # Cache empty result to avoid repeated failures
        _set_cached_aliases(tmdb_id, media_type, [])
        
        return []


def find_best_alias_match(
    query: str,
    aliases: List[str],
    *,
    min_similarity: float = 0.7,
) -> Tuple[Optional[str], float]:
    """Find the best matching alias for a query.
    
    Args:
        query: Search query string
        aliases: List of aliases to search
        min_similarity: Minimum similarity threshold
        
    Returns:
        Tuple of (best_alias, similarity) or (None, 0.0) if no match
    """
    if not query or not aliases:
        return None, 0.0
    
    best_alias = None
    best_sim = 0.0
    
    for alias in aliases:
        if not alias:
            continue
        
        sim = compute_alias_similarity(query, alias)
        if sim > best_sim:
            best_sim = sim
            best_alias = alias
    
    if best_sim >= min_similarity:
        return best_alias, best_sim
    
    return None, 0.0


async def boost_candidates_with_aliases(
    candidates: List[Dict[str, Any]],
    query_title: str,
    *,
    boost_factor: float = 0.08,
    min_similarity: float = 0.85,
) -> List[Dict[str, Any]]:
    """Boost candidate scores when aliases match query (Requirement 2.3).
    
    For each candidate:
    1. Fetch aliases (cached)
    2. Check if query matches any alias
    3. If match (similarity >= min_similarity), boost score by boost_factor
    
    Args:
        candidates: List of candidate dictionaries
        query_title: The search query
        boost_factor: Score boost amount (default: 0.08)
        min_similarity: Minimum similarity for boost (default: 0.85)
        
    Returns:
        Modified candidates list (in-place modification)
    """
    if not query_title or not candidates:
        return candidates
    
    for cand in candidates:
        if not isinstance(cand, dict):
            continue
        
        tmdb_id = cand.get("tmdb_id")
        media_type = cand.get("media_type")
        
        if not tmdb_id or not media_type:
            continue
        
        try:
            # Fetch aliases (cached)
            aliases = await fetch_title_aliases(int(tmdb_id), str(media_type))
            
            if not aliases:
                continue
            
            # Find best match
            best_alias, similarity = find_best_alias_match(
                query_title,
                aliases,
                min_similarity=min_similarity,
            )
            
            if best_alias and similarity >= min_similarity:
                # Apply boost
                current_score = float(cand.get("score") or cand.get("_fused_score") or 0.0)
                boosted_score = min(1.0, current_score + boost_factor)
                
                # Update scores
                cand["_alias_boost"] = boost_factor
                cand["_alias_match"] = best_alias
                cand["_alias_similarity"] = round(similarity, 4)
                
                if "_fused_score" in cand:
                    cand["_fused_score"] = round(boosted_score, 5)
                else:
                    cand["score"] = round(boosted_score, 5)
                
                logger.detail(
                    f"别名匹配提升 - tmdb_id={tmdb_id}, "
                    f"alias={best_alias}, sim={similarity:.3f}, boost={boost_factor}"
                )
                
        except Exception as e:
            logger.detail(f"别名提升失败（已忽略） - tmdb_id={tmdb_id}, 原因={type(e).__name__}")
            continue
    
    return candidates


def get_alias_cache_stats() -> Dict[str, Any]:
    """Get alias cache statistics.
    
    Returns:
        Dictionary with cache statistics
    """
    with _ALIAS_CACHE_LOCK:
        total = len(_ALIAS_CACHE)
        expired = sum(1 for e in _ALIAS_CACHE.values() if _is_cache_expired(e))
        
        return {
            "size": total,
            "max_size": _ALIAS_CACHE_MAX_SIZE,
            "expired": expired,
            "active": total - expired,
            "ttl_sec": _ALIAS_CACHE_TTL_SEC,
        }


def clear_alias_cache() -> None:
    """Clear the alias cache (for testing)."""
    with _ALIAS_CACHE_LOCK:
        _ALIAS_CACHE.clear()


def reset_alias_cache() -> None:
    """Reset the alias cache (alias for clear_alias_cache)."""
    clear_alias_cache()
