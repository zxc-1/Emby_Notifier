"""Candidate merge module for TMDB recognition.

This module handles candidate merging across multiple hints:
- Merge candidates from multiple TMDB search results
- Inject seed candidates from pre-resolve
- Compute top-1 consensus across hints
- Attach top-1 support metrics
- Apply evidence fusion scoring

Extracted from tmdb_lookup.py for better maintainability.
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

from core.logging import get_biz_logger_adapter
from core.exceptions.safe_context import safe_context

from .consensus_scoring import (
    compute_support_weight,
    compute_top1_support,
    compute_evidence_fusion_bonus,
    init_candidate_support,
    merge_candidate_support,
)
from .constants import (
    SUPPORT_MAIN_WEIGHT,
    SUPPORT_MSG_WEIGHT,
)

logger = get_biz_logger_adapter(__name__)


def merge_candidates(
    gmap: Dict[str, Dict[str, Any]],
    selected_hints: List[str],
    hint_sources: Dict[str, str],
) -> Dict[Tuple[int, str], Dict[str, Any]]:
    """Merge candidates from multiple hints.
    
    Combines candidates from multiple TMDB search results, tracking
    which hints support each candidate and computing support weights.
    
    Args:
        gmap: Dict mapping hint -> TMDB search result dict
              Each result has "results" key with list of candidates
        selected_hints: List of hints to process (in order)
        hint_sources: Dict mapping hint -> source ("main"|"msg"|"extra")
    
    Returns:
        Dict mapping (tmdb_id, media_type) -> merged candidate dict
        Each candidate has:
        - _hints: List of supporting hints
        - _support_count: Number of supporting hints
        - _support_weight: Weighted support (main=2, msg=1)
        - _support_main: Count of main hint support
        - _support_msg: Count of msg hint support
    """
    merged: Dict[Tuple[int, str], Dict[str, Any]] = {}
    
    for h in selected_hints:
        g = gmap.get(h) or {}
        # Support both "results" and "candidates" keys for compatibility
        results = g.get("results") or g.get("candidates") or []
        
        for c in results:
            if not isinstance(c, dict):
                continue
            
            try:
                tid = int(c.get("id") or c.get("tmdb_id") or 0)
            except (ValueError, TypeError):
                continue
            
            if tid <= 0:
                continue
            
            mt = str(c.get("media_type") or "movie").lower().strip() or "movie"
            key = (tid, mt)
            
            if key not in merged:
                # Initialize new candidate
                cc = init_candidate_support(c, h, hint_sources)
                cc["tmdb_id"] = tid
                cc["media_type"] = mt
                merged[key] = cc
            else:
                # Merge into existing candidate
                prev = merged[key]
                merge_candidate_support(prev, h, hint_sources)
                
                # Keep higher score
                try:
                    if float(c.get("score") or 0) > float(prev.get("score") or 0):
                        prev["score"] = c.get("score")
                        prev["coverage"] = c.get("coverage")
                except (ValueError, TypeError):
                    logger.detail("apply_title_cache_bias: invalid score type", extra={"candidate": cc}, exc_info=True)
    
    return merged


def inject_seeds(
    merged: Dict[Tuple[int, str], Dict[str, Any]],
    seeds: List[Dict[str, Any]],
) -> None:
    """Inject seed candidates into merged pool (in-place).
    
    Seeds come from pre-resolve (explicit ID, IMDb lookup, cache).
    They start with zero support; they only win if their intrinsic
    score is strong enough.
    
    Args:
        merged: Merged candidate dict to update
        seeds: List of seed candidate dicts
    """
    if not seeds:
        return
    
    for s in seeds:
        if not isinstance(s, dict):
            continue
        
        try:
            tid = int(s.get("id") or s.get("tmdb_id") or 0)
        except (ValueError, TypeError):
            continue
        
        if tid <= 0:
            continue
        
        mt = str(s.get("media_type") or "movie").lower().strip() or "movie"
        key = (tid, mt)
        
        if key in merged:
            # Already exists, mark as seed but don't override
            prev = merged[key]
            prev["_seed"] = 1
            prev["_seed_reason"] = str(s.get("_seed_reason") or "")
        else:
            # Add new seed candidate
            try:
                sc = float(s.get("score") or 0.0)
            except (ValueError, TypeError):
                sc = 0.0
            
            try:
                cov = float(s.get("coverage") or 0.0)
            except (ValueError, TypeError):
                cov = 0.0
            
            merged[key] = {
                "id": tid,
                "tmdb_id": tid,
                "media_type": mt,
                "title": s.get("title") or s.get("name") or "",
                "name": s.get("name") or s.get("title") or "",
                "score": sc,
                "coverage": cov,
                "_hint": "seed",
                "_hints": [],
                "_support_count": 0,
                "_support_weight": 0,
                "_support_main": 0,
                "_support_msg": 0,
                "_seed": 1,
                "_seed_reason": str(s.get("_seed_reason") or ""),
            }


def compute_top1_consensus(
    gmap: Dict[str, Dict[str, Any]],
    hint_sources: Dict[str, str],
) -> Dict[str, Tuple[int, str]]:
    """Compute top-1 candidate for each hint.
    
    For each hint's search results, identifies the highest-scoring
    candidate as the "top-1" for that hint.
    
    Args:
        gmap: Dict mapping hint -> TMDB search result dict
        hint_sources: Dict mapping hint -> source type
    
    Returns:
        Dict mapping hint -> (tmdb_id, media_type) of top-1 candidate
    """
    top1_by_hint: Dict[str, Tuple[int, str]] = {}
    
    for hk, gg in (gmap or {}).items():
        if not isinstance(gg, dict):
            continue
        
        # Support both "results" and "candidates" keys for compatibility
        results = gg.get("results") or gg.get("candidates") or []
        if not results:
            continue
        
        # Find top-1 by score
        best_score = -1.0
        best_tid = 0
        best_mt = "movie"
        
        for c in results:
            if not isinstance(c, dict):
                continue
            
            try:
                sc = float(c.get("score") or 0.0)
            except (ValueError, TypeError):
                sc = 0.0
            
            if sc > best_score:
                try:
                    tid = int(c.get("id") or c.get("tmdb_id") or 0)
                except (ValueError, TypeError):
                    continue
                
                if tid > 0:
                    best_score = sc
                    best_tid = tid
                    best_mt = str(c.get("media_type") or "movie").lower().strip() or "movie"
        
        if best_tid > 0:
            top1_by_hint[str(hk)] = (best_tid, best_mt)
    
    return top1_by_hint


def attach_top1_support(
    merged: Dict[Tuple[int, str], Dict[str, Any]],
    top1_by_hint: Dict[str, Tuple[int, str]],
    hint_sources: Dict[str, str],
) -> None:
    """Attach top-1 consensus support metrics to candidates (in-place).
    
    For each candidate, counts how many hints have it as their top-1
    result, with weighted scoring (main hints count more).
    
    Args:
        merged: Merged candidate dict to update
        top1_by_hint: Dict mapping hint -> (tmdb_id, media_type)
        hint_sources: Dict mapping hint -> source type
    """
    for (tid, mt), d in merged.items():
        mt_l = str(mt or "movie").lower().strip() or "movie"
        
        tcnt = 0
        tw = 0
        tmain = 0
        
        for h, (t0, mt0) in top1_by_hint.items():
            try:
                if int(t0) == int(tid) and str(mt0).lower().strip() == mt_l:
                    tcnt += 1
                    src = hint_sources.get(h, "msg")
                    if src == "main":
                        tw += SUPPORT_MAIN_WEIGHT
                        tmain += 1
                    else:
                        tw += SUPPORT_MSG_WEIGHT
            except (ValueError, TypeError):
                continue
        
        d["_top1_support_count"] = tcnt
        d["_top1_support_weight"] = tw
        d["_top1_support_main"] = tmain


def apply_evidence_fusion(
    merged: Dict[Tuple[int, str], Dict[str, Any]],
    min_coverage: float = 0.55,
) -> None:
    """Apply evidence voting fusion to compute fused scores (in-place).
    
    Combines base score with support bonuses:
    - Top-1 consensus bonus: +0.03 per additional top-1 beyond first
    - Support bonus: +0.01 per support weight beyond top-1
    
    Args:
        merged: Merged candidate dict to update
        min_coverage: Minimum coverage to apply bonuses
    """
    for (tid, mt), d in merged.items():
        if not isinstance(d, dict):
            continue
        
        # Get base score
        try:
            sc0 = float(
                d.get("_fused_score")
                if d.get("_fused_score") is not None
                else (d.get("score") or 0.0)
            )
        except (ValueError, TypeError):
            sc0 = 0.0
        
        # Get coverage
        try:
            cov0 = float(d.get("coverage") or 0.0)
        except (ValueError, TypeError):
            cov0 = 0.0
        
        # Get support weights
        try:
            top1w = int(d.get("_top1_support_weight") or 0)
        except (ValueError, TypeError):
            top1w = 0
        
        try:
            supw = int(d.get("_support_weight") or 0)
        except (ValueError, TypeError):
            supw = 0
        
        # Compute bonus
        bonus = compute_evidence_fusion_bonus(sc0, cov0, top1w, supw, min_coverage)
        
        # Apply fused score
        d["_fused_score"] = round(min(1.0, sc0 + bonus), 5)


def build_candidate_list(
    merged: Dict[Tuple[int, str], Dict[str, Any]],
    sort_by_fused: bool = True,
) -> List[Dict[str, Any]]:
    """Build sorted candidate list from merged dict.
    
    Args:
        merged: Merged candidate dict
        sort_by_fused: If True, sort by _fused_score; else by score
    
    Returns:
        List of candidate dicts, sorted by score descending
    """
    cands = list(merged.values())
    
    if sort_by_fused:
        cands.sort(
            key=lambda x: float(
                x.get("_fused_score")
                if x.get("_fused_score") is not None
                else x.get("score") or 0
            ),
            reverse=True,
        )
    else:
        cands.sort(
            key=lambda x: float(x.get("score") or 0),
            reverse=True,
        )
    
    return cands


def merge_and_score(
    gmap: Dict[str, Dict[str, Any]],
    selected_hints: List[str],
    hint_sources: Dict[str, str],
    seeds: Optional[List[Dict[str, Any]]] = None,
) -> List[Dict[str, Any]]:
    """Complete merge and scoring pipeline.
    
    Combines all merge operations:
    1. Merge candidates across hints
    2. Inject seed candidates
    3. Compute top-1 consensus
    4. Attach top-1 support metrics
    5. Apply evidence fusion scoring
    6. Build sorted candidate list
    
    Args:
        gmap: Dict mapping hint -> TMDB search result
        selected_hints: List of hints to process
        hint_sources: Dict mapping hint -> source type
        seeds: Optional list of seed candidates
    
    Returns:
        Sorted list of merged candidates with fused scores
    """
    # Step 1: Merge candidates
    merged = merge_candidates(gmap, selected_hints, hint_sources)
    
    # Step 2: Inject seeds
    if seeds:
        inject_seeds(merged, seeds)
    
    # Step 3: Compute top-1 consensus
    top1_by_hint = compute_top1_consensus(gmap, hint_sources)
    
    # Step 4: Attach top-1 support
    attach_top1_support(merged, top1_by_hint, hint_sources)
    
    # Step 5: Apply evidence fusion
    apply_evidence_fusion(merged)
    
    # Step 6: Build sorted list
    return build_candidate_list(merged)


def apply_year_affinity_bias(
    candidates: List[Dict[str, Any]],
    year_ref: Optional[int],
    strict_year: Optional[int] = None,
) -> None:
    """Apply year affinity bias to candidates (in-place).
    
    Adjusts scores based on year match:
    - Exact match: +0.03
    - Off by 1: +0.015 (or -0.02 if strict_year)
    - Off by 2: -0.02
    - Off by 3+: -0.05
    - Missing year: -0.02
    
    Args:
        candidates: List of candidate dicts to update
        year_ref: Reference year for comparison
        strict_year: If set, year-off-by-1 is penalized
    """
    if not isinstance(year_ref, int):
        return
    
    for d in candidates:
        if not isinstance(d, dict):
            continue
        
        y = d.get("year")
        try:
            y = int(y) if y not in (None, "") else None
        except (ValueError, TypeError):
            y = None
        
        delta = 0.0
        if y is None:
            delta -= 0.02
            d["_year_missing"] = True
        else:
            dy = abs(int(y) - int(year_ref))
            if dy == 0:
                delta += 0.03
            elif dy == 1:
                delta += (-0.02 if isinstance(strict_year, int) else 0.015)
            elif dy == 2:
                delta -= 0.02
            elif dy >= 3:
                delta -= 0.05
                d["_year_mismatch"] = True
        
        if delta:
            try:
                d["score"] = round(max(0.0, min(1.0, float(d.get("score") or 0.0) + delta)), 3)
            except (ValueError, TypeError):
                logger.detail("candidate_merge: invalid numeric field", extra={"context": "score_adjust", "candidate": d}, exc_info=True)
            try:
                fs = float(
                    d.get("_fused_score")
                    if d.get("_fused_score") is not None
                    else d.get("score") or 0.0
                )
                d["_fused_score"] = round(max(0.0, min(1.0, fs + delta)), 5)
            except (ValueError, TypeError):
                logger.detail("candidate_merge: invalid numeric field", extra={"context": "score_adjust", "candidate": d}, exc_info=True)


def apply_title_cache_bias(
    candidates: List[Dict[str, Any]],
    cached_fp_tid: Optional[int],
    bias: float = 0.06,
) -> None:
    """Apply bias toward learned title-fingerprint mapping (in-place).
    
    Args:
        candidates: List of candidate dicts to update
        cached_fp_tid: TMDB ID from title cache
        bias: Score bonus to apply (default 0.06)
    """
    if not cached_fp_tid:
        return
    
    for cc in candidates:
        if not isinstance(cc, dict):
            continue
        
        try:
            if int(cc.get("tmdb_id") or 0) == int(cached_fp_tid):
                cc["score"] = round(min(1.0, float(cc.get("score") or 0.0) + bias), 3)
                try:
                    cc["_fused_score"] = round(
                        min(1.0, float(cc.get("_fused_score") or cc.get("score") or 0.0) + bias),
                        5
                    )
                except (ValueError, TypeError):
                    logger.detail("apply_title_cache_bias: invalid score type", extra={"candidate": cc}, exc_info=True)
                cc["_prior"] = "title_cache"
        except (ValueError, TypeError):
            logger.detail("apply_title_cache_bias: invalid tmdb id type", extra={"candidate": cc, "cached_fp_tid": cached_fp_tid}, exc_info=True)


def apply_sequel_penalty(
    candidates: List[Dict[str, Any]],
    query_title: str,
    compute_penalty_fn: Any,
) -> None:
    """Apply sequel mismatch penalty to candidates (in-place)."""
    if not query_title:
        return

    for d in candidates:
        if not isinstance(d, dict):
            continue

        cand_title = str(d.get("title") or d.get("name") or "").strip()
        if not cand_title:
            continue

        with safe_context(
            catch=(ValueError, TypeError, KeyError, AttributeError),
            default=None,
            context_name="apply_sequel_penalty.compute",
            log_level="warning",
            extra={"query_title": query_title, "candidate": d},
        ) as r:
            penalty, penalty_info = compute_penalty_fn(query_title, cand_title)
            r.set_value((penalty, penalty_info))

        if not r.success or r.value is None:
            continue

        penalty, penalty_info = r.value
        if penalty == 0.0:
            continue

        d["_sequel_penalty"] = penalty
        d["_sequel_info"] = penalty_info

        with safe_context(
            catch=(ValueError, TypeError),
            default=None,
            context_name="apply_sequel_penalty.update_score",
            log_level="warning",
            extra={"candidate": d},
        ) as r2:
            fs = float(
                d.get("_fused_score")
                if d.get("_fused_score") is not None
                else d.get("score") or 0.0
            )
            r2.set_value(fs)

        if r2.success and r2.value is not None:
            d["_fused_score"] = round(max(0.0, min(1.0, r2.value + penalty)), 5)

def sort_by_fused_score(candidates: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Sort candidates by fused score descending.
    
    Args:
        candidates: List of candidate dicts
    
    Returns:
        Sorted list (new list, original not modified)
    """
    return sorted(
        candidates,
        key=lambda x: float(
            x.get("_fused_score")
            if x.get("_fused_score") is not None
            else x.get("score") or 0
        ),
        reverse=True,
    )


def apply_anime_bonus(
    candidates: List[Dict[str, Any]],
    anime_evidence: Dict[str, Any],
    query_title: str,
    compute_bonus_fn: Any,
    title_similarity_fn: Any,
) -> None:
    """Apply anime bonus to candidates (in-place)."""
    if not anime_evidence or not anime_evidence.get("is_anime"):
        return

    for d in candidates:
        if not isinstance(d, dict):
            continue

        cand_title = str(d.get("title") or d.get("name") or "").strip()
        if not cand_title:
            continue

        with safe_context(
            catch=(ValueError, TypeError, KeyError, AttributeError),
            default=None,
            context_name="apply_anime_bonus.similarity",
            log_level="warning",
            extra={"query_title": query_title, "candidate": d},
        ) as r_sim:
            similarity = float(title_similarity_fn(query_title, cand_title))
            r_sim.set_value(similarity)

        if not r_sim.success or r_sim.value is None:
            continue

        with safe_context(
            catch=(ValueError, TypeError, KeyError, AttributeError),
            default=None,
            context_name="apply_anime_bonus.compute",
            log_level="warning",
            extra={"candidate": d, "anime_evidence": anime_evidence},
        ) as r:
            bonus = float(compute_bonus_fn(d, anime_evidence, r_sim.value))
            r.set_value(bonus)

        if not r.success or r.value is None:
            continue

        bonus = r.value
        if bonus == 0.0:
            continue

        d["_anime_bonus"] = bonus

        with safe_context(
            catch=(ValueError, TypeError),
            default=None,
            context_name="apply_anime_bonus.update_score",
            log_level="warning",
            extra={"candidate": d},
        ) as r2:
            fs = float(
                d.get("_fused_score")
                if d.get("_fused_score") is not None
                else d.get("score") or 0.0
            )
            r2.set_value(fs)

        if r2.success and r2.value is not None:
            d["_fused_score"] = round(max(0.0, min(1.0, r2.value + bonus)), 5)

async def apply_alias_bonus(
    candidates: List[Dict[str, Any]],
    alias_evidence: Dict[str, Any],
    query_title: str,
    compute_bonus_fn: Any,
    title_similarity_fn: Any,
) -> None:
    """Apply alias bonus to candidates (in-place)."""
    if not alias_evidence or not alias_evidence.get("has_alias"):
        return

    for d in candidates:
        if not isinstance(d, dict):
            continue

        cand_title = str(d.get("title") or d.get("name") or "").strip()
        if not cand_title:
            continue

        with safe_context(
            catch=(ValueError, TypeError, KeyError, AttributeError),
            default=None,
            context_name="apply_alias_bonus.similarity",
            log_level="warning",
            extra={"query_title": query_title, "candidate": d},
        ) as r_sim:
            similarity = float(title_similarity_fn(query_title, cand_title))
            r_sim.set_value(similarity)

        if not r_sim.success or r_sim.value is None:
            continue

        with safe_context(
            catch=(ValueError, TypeError, KeyError, AttributeError),
            default=None,
            context_name="apply_alias_bonus.compute",
            log_level="warning",
            extra={"candidate": d, "alias_evidence": alias_evidence},
        ) as r:
            bonus = float(compute_bonus_fn(d, alias_evidence, r_sim.value))
            r.set_value(bonus)

        if not r.success or r.value is None:
            continue

        bonus = r.value
        if bonus == 0.0:
            continue

        d["_alias_bonus"] = bonus

        with safe_context(
            catch=(ValueError, TypeError),
            default=None,
            context_name="apply_alias_bonus.update_score",
            log_level="warning",
            extra={"candidate": d},
        ) as r2:
            fs = float(
                d.get("_fused_score")
                if d.get("_fused_score") is not None
                else d.get("score") or 0.0
            )
            r2.set_value(fs)

        if r2.success and r2.value is not None:
            d["_fused_score"] = round(max(0.0, min(1.0, r2.value + bonus)), 5)
