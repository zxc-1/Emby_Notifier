from __future__ import annotations

"""Scoring and candidate ranking for share TMDB resolver.

This module is meant to be pure (no network/DB/telegram).
"""
import logging
from core.logging import get_biz_logger_adapter
logger = get_biz_logger_adapter(__name__)


import re
from typing import Any, Dict, Iterable, List, Optional, Tuple
from dataclasses import dataclass

from .ports_access import tmdb

from .hints import _is_garbage_hint
from .constants import (
    COLLISION_WORDS_EN,
    COLLISION_WORDS_CJK,
    COLLISION_RISK_MIN_SCORE,
    COLLISION_RISK_MIN_COVERAGE,
    SHORT_TITLE_MIN_SCORE,
    SHORT_TITLE_MIN_COVERAGE,
)


def _title_quality_score(title: str) -> float:
    """Heuristic quality score for candidate evidence titles."""
    t = (title or "").strip()
    if not t:
        return -1e9
    if _is_garbage_hint(t):
        return -1e6
    score = 0.0

    # Strongly prefer CJK titles when present.
    # Why: CN shares frequently have a short, high-signal CJK title (e.g. “轻年”),
    # while inner filenames contain longer English aliases (“Forever Young ...”).
    # In the refactor, length-based scoring could let the long English string win.
    if re.search(r"[\u4e00-\u9fff]", t):
        score += 26.0
        # Extra boost for very short CJK titles (2~4 chars) which are common and correct.
        if len(t) <= 4:
            score += 6.0

    if re.search(r"[A-Za-z]", t):
        score += 3.0

    # Keep length as a weak signal only (avoid long release strings dominating).
    score += min(len(t), 24) / 8.0
    if re.fullmatch(r"\d+", t):
        score -= 10.0
    if re.search(
        r"\b(1080p|2160p|x264|x265|h\.?264|h\.?265|webrip|web[- ]?dl|bluray|bdrip|hdr|dv)\b",
        t,
        re.IGNORECASE,
    ):
        score -= 3.0
    return score


def compute_collision_risk(title: str) -> dict:
    """Compute collision risk for a title (Requirement 9.1, 9.2, 9.3).
    
    Short or common-word titles have higher collision risk with other media.
    This function analyzes the title and returns risk information.
    
    Args:
        title: The title to analyze
        
    Returns:
        Dict with keys:
        - collision_risky: True if title has high collision risk
        - matched_words: List of collision-prone words found
        - token_count: Number of meaningful tokens in title
        - is_short_title: True if title is considered short
        - min_score_threshold: Minimum score required for auto-pick
        - min_coverage_threshold: Minimum coverage required for auto-pick
    """
    t = (title or "").strip()
    if not t:
        return {
            "collision_risky": True,
            "matched_words": [],
            "token_count": 0,
            "is_short_title": True,
            "min_score_threshold": COLLISION_RISK_MIN_SCORE,
            "min_coverage_threshold": COLLISION_RISK_MIN_COVERAGE,
        }
    
    # Extract tokens (words)
    tokens_en = [w.lower() for w in re.findall(r"[A-Za-z]{2,}", t)]
    tokens_cjk = re.findall(r"[\u4e00-\u9fff]+", t)
    
    # Check for collision-prone words
    matched_en = [w for w in tokens_en if w in COLLISION_WORDS_EN]
    matched_cjk = [w for w in tokens_cjk if w in COLLISION_WORDS_CJK]
    matched_words = matched_en + matched_cjk
    
    # Count meaningful tokens
    token_count = len(tokens_en) + len(tokens_cjk)
    
    # Determine if title is short
    is_short = token_count <= 2 or len(t) <= 6
    
    # Collision risk: short title with common words
    collision_risky = (
        (is_short and len(matched_words) > 0) or
        (token_count <= 1) or
        (len(t) <= 3)
    )
    
    # Determine thresholds based on risk
    if collision_risky:
        min_score = COLLISION_RISK_MIN_SCORE
        min_coverage = COLLISION_RISK_MIN_COVERAGE
    elif is_short:
        min_score = SHORT_TITLE_MIN_SCORE
        min_coverage = SHORT_TITLE_MIN_COVERAGE
    else:
        min_score = 0.85  # Default threshold
        min_coverage = 0.70
    
    return {
        "collision_risky": collision_risky,
        "matched_words": matched_words,
        "token_count": token_count,
        "is_short_title": is_short,
        "min_score_threshold": min_score,
        "min_coverage_threshold": min_coverage,
    }


def sort_candidates(cands: Iterable[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """Sort candidate dicts in place-safe way (higher score first)."""
    xs = [c for c in cands if isinstance(c, dict)]
    def key(c: Dict[str, Any]) -> Tuple[float, float, float]:
        try:
            sc = float(c.get("score") or 0.0)
        except (ValueError, TypeError) as e:
            logger.detail(f"分数解析失败（使用 0.0） - value={c.get('score') if isinstance(c, dict) else None}, 原因={type(e).__name__}")
            sc = 0.0
        try:
            vc = float(c.get("vote_count") or 0.0)
        except (ValueError, TypeError) as e:
            logger.detail(f"投票数解析失败（使用 0.0） - value={c.get('vote_count') if isinstance(c, dict) else None}, 原因={type(e).__name__}")
            vc = 0.0
        try:
            rt = float(c.get("rating") or 0.0)
        except (ValueError, TypeError) as e:
            logger.detail(f"评分解析失败（使用 0.0） - value={c.get('rating') if isinstance(c, dict) else None}, 原因={type(e).__name__}")
            rt = 0.0
        return (sc, rt, vc)
    xs.sort(key=key, reverse=True)
    return xs


def pick_best_candidate(cands: Iterable[Dict[str, Any]]) -> Optional[Dict[str, Any]]:
    """Return the top candidate after sorting."""
    xs = sort_candidates(cands)
    return xs[0] if xs else None


@dataclass
class CandidateShim:
    tmdb_id: int
    media_type: str
    title: str
    year: Optional[int] = None
    rating: Optional[float] = None
    vote_count: Optional[int] = None
    score: Optional[float] = None
    extra: Dict[str, Any] | None = None


def should_auto_pick_from_candidates(cands: Iterable[Dict[str, Any]]) -> bool:
    """Auto-pick decision using injected tmdb matcher port."""
    try:
        xs = sort_candidates(cands)
        scored: list[tuple[CandidateShim, float]] = []
        for d in xs:
            if not isinstance(d, dict):
                continue
            try:
                tid = int(d.get("tmdb_id") or 0)
            except (ValueError, TypeError) as e:
                logger.detail(f"TMDB ID 解析失败（跳过候选） - value={d.get('tmdb_id') if isinstance(d, dict) else None}, 原因={type(e).__name__}")
                continue
            if tid <= 0:
                continue
            mt = str(d.get("media_type") or "movie").strip().lower() or "movie"
            title = str(d.get("title") or d.get("name") or "").strip()
            try:
                year = int(d.get("year")) if d.get("year") not in (None, "") else None
            except (ValueError, TypeError) as e:
                logger.detail(f"年份解析失败（视为无年份） - value={d.get('year') if isinstance(d, dict) else None}, 原因={type(e).__name__}")
                year = None
            try:
                rating = float(d.get("rating") or 0.0)
            except (ValueError, TypeError) as e:
                logger.detail(f"评分解析失败（使用 0.0） - value={d.get('rating') if isinstance(d, dict) else None}, 原因={type(e).__name__}")
                rating = 0.0
            try:
                vc = int(d.get("vote_count") or 0)
            except (ValueError, TypeError) as e:
                logger.detail(f"投票数解析失败（使用 0） - value={d.get('vote_count') if isinstance(d, dict) else None}, 原因={type(e).__name__}")
                vc = 0
            extra = dict(d)
            # preserve coverage if present
            if "coverage" in d:
                extra.setdefault("_match", {})
                try:
                    extra["_match"]["coverage"] = float(d.get("coverage") or 0.0)
                except (ValueError, TypeError) as e:
                    logger.detail(f"覆盖率解析失败（已忽略） - value={d.get('coverage') if isinstance(d, dict) else None}, 原因={type(e).__name__}")
            cand = CandidateShim(tmdb_id=tid, media_type=mt, title=title, year=year, rating=rating, vote_count=vc, score=1.0, extra=extra)
            try:
                sc = float(d.get("_fused_score") if d.get("_fused_score") is not None else (d.get("score") or 0.0))
            except (ValueError, TypeError) as e:
                logger.detail(f"分数解析失败（使用 0.0） - value={d.get('_fused_score') if isinstance(d, dict) else None}, 原因={type(e).__name__}")
                sc = 0.0
            scored.append((cand, sc))
        return bool(tmdb().should_auto_pick(scored))
    except (ValueError, TypeError, AttributeError, KeyError) as e:
        logger.detail(f"自动选择判断失败（返回 False） - 原因={type(e).__name__}")
        return False
