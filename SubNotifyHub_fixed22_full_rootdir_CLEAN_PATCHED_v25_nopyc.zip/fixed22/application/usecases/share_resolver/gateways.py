from __future__ import annotations

from core.exceptions.base import ExternalServiceError

"""External gateways for share TMDB resolver.

Keep all external I/O (TMDB, 115) behind small helpers so the resolver logic can
stay testable and the timeouts/retry behavior is consistent.

v1.6.12.47:
- unify TMDB call timeouts + retry (optimization #4)
"""

import asyncio
import logging
from core.logging import get_biz_logger_adapter
import re
from typing import Any, Dict, Optional

from ports.settings_provider import get_settings

from .ports_access import share115, tmdb


logger = get_biz_logger_adapter(__name__)


_YEAR_IN_TITLE_RE = re.compile(r"\((19\d{2}|20\d{2})\)")


def _infer_year_from_title(t: str) -> Optional[int]:
    """Infer year from a title like 'Foo (2026)'.

    This is a cheap, I/O-free fallback used when TMDB omits date fields.
    """
    try:
        m = _YEAR_IN_TITLE_RE.search(str(t or ""))
        return int(m.group(1)) if m else None
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"标题年份推断失败（已忽略） - title={t!r}, 原因={type(e).__name__}")
        return None


def _get_float(name: str, default: float, *, lo: float = 0.2, hi: float = 120.0) -> float:
    try:
        s = get_settings()
        v = float(getattr(s, name, default) or default)
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"浮点配置读取失败，使用默认值 - name={name}, default={default}, 原因={type(e).__name__}")
        v = float(default)
    v = max(lo, min(hi, v))
    return float(v)


def _get_int(name: str, default: int, *, lo: int = 0, hi: int = 20) -> int:
    try:
        s = get_settings()
        v = int(getattr(s, name, default) or default)
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"整数配置读取失败，使用默认值 - name={name}, default={default}, 原因={type(e).__name__}")
        v = int(default)
    v = max(lo, min(hi, v))
    return int(v)


async def _retry(
    fn,
    *,
    retries: int,
    sleep_sec: float,
) -> Any:
    last = None
    for i in range(max(1, int(retries))):
        try:
            return await fn()
        except Exception as e:
            last = e
            if i < retries - 1:
                try:
                    await asyncio.sleep(float(sleep_sec))
                except (ValueError, TypeError) as e:
                    logger.detail(f"重试等待失败（已忽略） - sleep_sec={sleep_sec}, 原因={type(e).__name__}")
    if last:
        raise last
    raise ExternalServiceError("unknown retry failure")


# ---------------------------------------------------------------------------
# 115 share evidence
# ---------------------------------------------------------------------------


async def resolve_share_best_video(
    *,
    share_code: str,
    receive_code: str,
    max_depth: int,
    max_dir_scans: int,
    timeout: float,
) -> Dict[str, Any]:
    """Resolve best video evidence from a 115 share link."""
    return await asyncio.wait_for(
        share115().resolve_best_video_for_share(
            share_code=str(share_code or ""),
            receive_code=str(receive_code or "") or None,
            max_depth=int(max_depth),
            max_dir_scans=int(max_dir_scans),
        ),
        timeout=float(timeout),
    )


# ---------------------------------------------------------------------------
# TMDB
# ---------------------------------------------------------------------------


async def tmdb_detail_safe(
    tmdb_id: int,
    *,
    prefer_media_type: Optional[str] = None,
    language: Optional[str] = None,
    region: Optional[str] = None,
    timeout: Optional[float] = None,
    retries: Optional[int] = None,
) -> dict[str, Any] | None:
    """Fetch TMDB detail with consistent timeout and retry.

    Returns None on failure.
    """
    if not tmdb_id:
        return None

    t = float(timeout) if timeout is not None else _get_float("TMDB_DETAIL_TIMEOUT_SEC", 3.0, lo=0.5, hi=30.0)
    r = int(retries) if retries is not None else _get_int("TMDB_DETAIL_RETRIES", 2, lo=1, hi=6)
    sleep_sec = _get_float("TMDB_DETAIL_RETRY_SLEEP_SEC", 0.35, lo=0.05, hi=3.0)

    async def _call():
        return await asyncio.wait_for(
            tmdb().fetch_tmdb_detail(
                int(tmdb_id),
                prefer_media_type=str(prefer_media_type).strip().lower() if prefer_media_type else None,
                language=language,
                region=region,
            ),
            timeout=t,
        )

    try:
        det = await _retry(_call, retries=r, sleep_sec=sleep_sec)
        # Year补救：部分条目 date 为空导致 year 缺失，但 title/original_title 里带 '(2026)'
        if isinstance(det, dict) and det and det.get("year") in (None, ""):
            for k in ("title", "original_title", "name", "original_name"):
                y = _infer_year_from_title(str(det.get(k) or "").strip())
                if y is not None:
                    det["year"] = y
                    break
        return det
    except Exception:
        logger.detail("tmdb_detail_safe 失败", exc_info=True)
        return None


async def tmdb_find_by_external_id_safe(
    external_id: str,
    *,
    external_source: str = "imdb_id",
    timeout: Optional[float] = None,
    retries: Optional[int] = None,
) -> list[Any]:
    """Find TMDB candidates by an external id (with timeout+retry)."""
    t = float(timeout) if timeout is not None else _get_float("TMDB_FIND_EXTERNAL_TIMEOUT_SEC", 4.0, lo=0.5, hi=30.0)
    r = int(retries) if retries is not None else _get_int("TMDB_FIND_EXTERNAL_RETRIES", 2, lo=1, hi=6)
    sleep_sec = _get_float("TMDB_FIND_EXTERNAL_RETRY_SLEEP_SEC", 0.35, lo=0.05, hi=3.0)

    async def _call():
        return await asyncio.wait_for(
            tmdb().find_by_external_id(str(external_id), external_source=str(external_source or "imdb_id")),
            timeout=t,
        )

    try:
        res = await _retry(_call, retries=r, sleep_sec=sleep_sec)
        return list(res or [])
    except Exception:
        logger.detail("tmdb_find_by_external_id_safe 失败", exc_info=True)
        return []


async def tmdb_guess_from_filename_safe(
    name: str,
    *,
    force_media_type: Optional[str] = None,
    mode: str = "full",
) -> Dict[str, Any]:
    """Guess TMDB by filename (no extra retry; upstream handles pagination)."""
    try:
        return await tmdb().guess_tmdb_from_filename(
            str(name or ""),
            force_media_type=str(force_media_type).strip().lower() if force_media_type else None,
            mode=str(mode or "full"),
        )
    except Exception:
        logger.detail("tmdb_guess_from_filename_safe 失败", exc_info=True)
        return {}
