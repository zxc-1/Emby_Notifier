"""Configuration constants for TMDB recognition optimization.

All thresholds and patterns are centralized here for easy tuning.
"""
from __future__ import annotations

import re
from typing import FrozenSet, Pattern

# =============================================================================
# Cache Thresholds (Requirement 8)
# =============================================================================
TITLE_CACHE_MIN_CONFIDENCE = 0.82
TITLE_CACHE_MIN_COVERAGE = 0.60
SERIES_CACHE_MIN_CONFIDENCE = 0.80
SERIES_CACHE_MAX_YEAR_DIFF = 2
CACHE_VALIDATION_MIN_SCORE = 0.72  # Below this, disable the cached mapping

# =============================================================================
# Stage-A/Stage-B Thresholds (Requirements 4, 13)
# =============================================================================
STAGE_A_STABLE_SCORE = 0.93
STAGE_A_STABLE_COVERAGE = 0.60
STAGE_A_EARLY_STOP_SCORE = 0.95
STAGE_A_EARLY_STOP_COVERAGE = 0.85
STAGE_A_EARLY_STOP_GAP = 0.15

# =============================================================================
# Collision Risk Thresholds (Requirement 9)
# =============================================================================
COLLISION_RISK_MIN_SCORE = 0.95
COLLISION_RISK_MIN_COVERAGE = 0.92
SHORT_TITLE_MIN_SCORE = 0.93
SHORT_TITLE_MIN_COVERAGE = 0.90
SHORT_TITLE_EARLY_STOP_SCORE = 0.985
SHORT_TITLE_EARLY_STOP_GAP = 0.18

# Collision-prone words (Requirements 9.1, 9.3)
COLLISION_WORDS_EN: FrozenSet[str] = frozenset({
    "man", "one", "family", "home", "love", "world", "life",
    "day", "night", "story", "journey", "young", "girl", "boy",
    "woman", "time", "dream", "star", "king", "queen", "game",
    "the", "a", "an", "and", "up", "her", "him", "it", "us",
})

COLLISION_WORDS_CJK: FrozenSet[str] = frozenset({
    "男人", "一个", "家庭", "家", "爱情", "世界", "人生",
    "故事", "旅程", "青春", "女孩", "男孩", "女人", "时间",
    "梦想", "星", "王", "女王", "游戏",
})

# =============================================================================
# Episode Score Thresholds (Requirements 6, 13)
# =============================================================================
EPISODE_SCORE_TOP_K = 8  # Limit API calls to top K candidates
EPISODE_SCORE_CONCURRENCY = 3  # Semaphore for concurrent API calls
EPISODE_SCORE_MIN_EPISODES = 3  # Minimum episodes to compute score
EPISODE_SCORE_BOOST_THRESHOLD = 0.45  # Minimum episode_score to boost fused_score
EPISODE_EXCEED_PENALTY_THRESHOLD = 0.20  # Penalty when episodes exceed TMDB total by >20%

# =============================================================================
# Year Affinity Adjustments (Requirements 5, 16)
# =============================================================================
YEAR_EXACT_BONUS = 0.03
YEAR_OFF_BY_1_BONUS = 0.015
YEAR_OFF_BY_1_STRICT_PENALTY = -0.02  # When strict_year is set
YEAR_OFF_BY_2_PENALTY = -0.02
YEAR_OFF_BY_3_PENALTY = -0.05
YEAR_MISSING_PENALTY = -0.02

# =============================================================================
# Support Weight (Requirement 7)
# =============================================================================
SUPPORT_MAIN_WEIGHT = 2  # Main hints (video filename, season folder)
SUPPORT_MSG_WEIGHT = 1   # Message hints (user input, URL fragment)
SUPPORT_BONUS_THRESHOLD = 3  # support_weight >= this triggers bonus
SUPPORT_BONUS_VALUE = 0.03

# =============================================================================
# Auto-Pick Thresholds (Requirement 3)
# =============================================================================
AUTO_PICK_L3_MIN_SCORE = 0.90
AUTO_PICK_L3_MIN_COVERAGE = 0.70
AUTO_PICK_L3_MIN_GAP = 0.08
AUTO_PICK_EPISODE_MIN_SCORE = 0.85
AUTO_PICK_EPISODE_MIN_STANDARD_RATE = 0.85
AUTO_PICK_EPISODE_MIN_EPISODE_SCORE = 0.50
AUTO_PICK_CONSENSUS_MIN_SCORE = 0.82
AUTO_PICK_SINGLE_STRONG_MIN_SCORE = 0.88
AUTO_PICK_SINGLE_STRONG_MIN_COVERAGE = 0.75

# =============================================================================
# Video Sample Priority (Requirement 1)
# =============================================================================
VIDEO_SAMPLE_PRIORITY_ENABLED = True
CJK_SHARE_TITLE_WEIGHT_BOOST = 1.5

# Generic share title patterns (Requirement 1.4, 2.2)
GENERIC_SHARE_TITLE_PATTERNS: tuple[Pattern[str], ...] = (
    re.compile(r"合集", re.IGNORECASE),
    re.compile(r"全集", re.IGNORECASE),
    re.compile(r"资源", re.IGNORECASE),
    re.compile(r"分享", re.IGNORECASE),
    re.compile(r"打包", re.IGNORECASE),
    re.compile(r"collection", re.IGNORECASE),
    re.compile(r"complete", re.IGNORECASE),
    re.compile(r"pack", re.IGNORECASE),
    re.compile(r"^\d+p$", re.IGNORECASE),  # Pure resolution like "1080p"
    re.compile(r"^BDMV$", re.IGNORECASE),
    re.compile(r"^REMUX$", re.IGNORECASE),
    re.compile(r"^4K$", re.IGNORECASE),
    re.compile(r"^HDR$", re.IGNORECASE),
)

# =============================================================================
# Multi-Season/Part Detection (Requirement 11)
# =============================================================================
MULTI_SEASON_PREFER_LOWEST = True
PART_MOVIE_BLOCK_AUTO_PICK = True
MIXED_CONTENT_BLOCK_AUTO_PICK = True

# Part marker patterns (Requirement 11.4)
PART_PATTERNS: tuple[Pattern[str], ...] = (
    re.compile(r"[.\s_-]Part[.\s_-]?(\d+)", re.IGNORECASE),
    re.compile(r"[.\s_-]Pt[.\s_-]?(\d+)", re.IGNORECASE),
    re.compile(r"第(\d+)部"),
    re.compile(r"[.\s_-](\d+)of\d+", re.IGNORECASE),
)

# =============================================================================
# Alias Matching (Requirement 12)
# =============================================================================
ALIAS_FETCH_TOP_K = 5
ALIAS_SIMILARITY_BOOST_THRESHOLD = 0.10

# =============================================================================
# Decision Stage Thresholds (Requirement 3)
# =============================================================================

# Episode-aware fast-pass thresholds (strict policy)
DECIDE_FASTPASS_STRICT_MIN_SCORE = 0.95
DECIDE_FASTPASS_STRICT_MIN_EPISODE_SCORE = 0.45
DECIDE_FASTPASS_STRICT_MIN_GAP = 0.10
DECIDE_FASTPASS_STRICT_MIN_COVERAGE = 0.55

# Episode-aware fast-pass thresholds (batch-evidence relaxation)
DECIDE_FASTPASS_BATCH_MIN_STANDARD_RATE = 0.90
DECIDE_FASTPASS_BATCH_MIN_EPISODES = 3
DECIDE_FASTPASS_BATCH_MIN_EPISODE_COVERAGE = 0.75
DECIDE_FASTPASS_BATCH_MIN_SCORE = 0.93
DECIDE_FASTPASS_BATCH_MIN_EPISODE_SCORE = 0.45
DECIDE_FASTPASS_BATCH_MIN_GAP = 0.06
DECIDE_FASTPASS_BATCH_MIN_COVERAGE = 0.55

# Single-candidate auto-upgrade thresholds
DECIDE_SINGLE_UPGRADE_MIN_SCORE = 0.90
DECIDE_SINGLE_UPGRADE_MIN_COVERAGE = 0.90
DECIDE_SINGLE_UPGRADE_COLLISION_MIN_SCORE = 0.95
DECIDE_SINGLE_UPGRADE_COLLISION_MIN_COVERAGE = 0.92
DECIDE_SINGLE_UPGRADE_GAP = 0.20
DECIDE_SINGLE_UPGRADE_MAX_YEAR_DIFF = 2

# Details re-score trigger thresholds
DECIDE_RESCORE_MIN_SCORE = 0.78
DECIDE_RESCORE_MAX_GAP = 0.08
DECIDE_RESCORE_MIN_COVERAGE = 0.55

# Strength downgrade thresholds
DECIDE_STRENGTH_MAX_YEAR_DIFF = 2
DECIDE_STRENGTH_MANY_CANDIDATES = 8
DECIDE_STRENGTH_MANY_CANDIDATES_MIN_GAP = 0.02
DECIDE_STRENGTH_SHORT_TITLE_MAX_LEN = 3

# Evidence level gating
DECIDE_EVIDENCE_GATE_LEVEL = 1  # ev_level <= this blocks auto-pick
DECIDE_MIN_EVIDENCE_LEVEL = 2  # Minimum evidence level for fast-pass

# =============================================================================
# Debug Mode (Requirement 14)
# =============================================================================
DEBUG_MODE_INCLUDE_TIMING = True
DEBUG_MODE_INCLUDE_ALL_CANDIDATES = True

# =============================================================================
# Anime Detection (Requirement 17)
# =============================================================================
ANIME_GENRE_ID = 16  # TMDB Animation genre ID
ANIME_CONFIDENCE_BOOST = 0.03
ANIME_BILINGUAL_FORCE_STAGE_B = True

# Anime subgroup patterns
ANIME_SUBGROUP_PATTERNS: tuple[Pattern[str], ...] = (
    re.compile(r'\[([A-Za-z0-9_-]+)\]'),  # [SubGroup]
    re.compile(r'【([^】]+)】'),           # 【字幕组】
)

# Anime season suffix patterns
ANIME_SEASON_PATTERNS: tuple[Pattern[str], ...] = (
    re.compile(r'第(\d+)季'),
    re.compile(r'Season\s*(\d+)', re.IGNORECASE),
    re.compile(r'S(\d+)(?![Ee])', re.IGNORECASE),  # S2 but not S2E1
    re.compile(r'(\d+)(?:st|nd|rd|th)\s*Season', re.IGNORECASE),
    re.compile(r'シーズン(\d+)'),
)

# =============================================================================
# Sequel Detection (Requirement 18)
# =============================================================================
SEQUEL_MISSING_PENALTY = -0.10
SEQUEL_MISMATCH_PENALTY = -0.15

# Sequel marker patterns
SEQUEL_PATTERNS_NUMERIC: tuple[Pattern[str], ...] = (
    re.compile(r'\b(\d+)$'),  # Trailing number
    re.compile(r'(\d+)$'),    # End with number
)

SEQUEL_PATTERNS_ROMAN: tuple[Pattern[str], ...] = (
    re.compile(r'\b(II|III|IV|V|VI|VII|VIII|IX|X)\b'),
)

SEQUEL_PATTERNS_CJK: tuple[Pattern[str], ...] = (
    re.compile(r'第([一二三四五六七八九十]+)部'),
    re.compile(r'第(\d+)部'),
    re.compile(r'续集'),
    re.compile(r'前传'),
)

SEQUEL_PATTERNS_ENGLISH: tuple[Pattern[str], ...] = (
    re.compile(r'Part\s*(\d+)', re.IGNORECASE),
    re.compile(r'Chapter\s*(\d+)', re.IGNORECASE),
    re.compile(r'Volume\s*(\d+)', re.IGNORECASE),
)

# Roman numeral to integer mapping
ROMAN_TO_INT: dict[str, int] = {
    'I': 1, 'II': 2, 'III': 3, 'IV': 4, 'V': 5,
    'VI': 6, 'VII': 7, 'VIII': 8, 'IX': 9, 'X': 10,
}

# CJK numeral to integer mapping
CJK_TO_INT: dict[str, int] = {
    '一': 1, '二': 2, '三': 3, '四': 4, '五': 5,
    '六': 6, '七': 7, '八': 8, '九': 9, '十': 10,
}

# =============================================================================
# Fast Hint Evaluation (Requirement 19)
# =============================================================================
FAST_HINT_MIN_CJK_LENGTH = 4
FAST_HINT_REQUIRE_NO_TECH_TAGS = True

# Technical tag pattern for weak hint detection
TECHNICAL_TAG_PATTERN: Pattern[str] = re.compile(
    r'\b(1080p|2160p|720p|4k|8k|x264|x265|h\.?264|h\.?265|hevc|avc|'
    r'webrip|bluray|bdrip|hdr|dv|dolby|dts|truehd|atmos|'
    r'remux|bdmv|stream|playlist)\b',
    re.IGNORECASE
)

# =============================================================================
# Quality Deduplication (Requirement 20)
# =============================================================================
DEDUP_PREFER_LARGER_SIZE = True
DEDUP_COVERAGE_THRESHOLD = 0.75

# =============================================================================
# Retry Configuration (Requirement 10)
# =============================================================================
TMDB_API_MAX_RETRIES = 2
TMDB_API_BACKOFF_BASE = 1.0  # seconds
TMDB_API_TIMEOUT = 3.0  # seconds
