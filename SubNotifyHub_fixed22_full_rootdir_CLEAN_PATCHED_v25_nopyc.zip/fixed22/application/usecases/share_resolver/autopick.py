"""Auto-pick decision logic for TMDB candidate selection.

This module contains the core auto-pick decision logic with:
- Evidence level gating (Requirement 3.5)
- Collision risk gating (Requirement 9.4)
- Mixed content blocking (Requirement 11.2)
- Part movie blocking (Requirement 11.4)
- Optimized threshold conditions (Requirements 3.1-3.4)

Extracted for better maintainability and testability.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

from core.logging import get_biz_logger_adapter

from .constants import (
    AUTO_PICK_L3_MIN_SCORE,
    AUTO_PICK_L3_MIN_COVERAGE,
    AUTO_PICK_L3_MIN_GAP,
    AUTO_PICK_EPISODE_MIN_SCORE,
    AUTO_PICK_EPISODE_MIN_STANDARD_RATE,
    AUTO_PICK_EPISODE_MIN_EPISODE_SCORE,
    AUTO_PICK_CONSENSUS_MIN_SCORE,
    AUTO_PICK_SINGLE_STRONG_MIN_SCORE,
    AUTO_PICK_SINGLE_STRONG_MIN_COVERAGE,
    COLLISION_RISK_MIN_SCORE,
    COLLISION_RISK_MIN_COVERAGE,
    SUPPORT_BONUS_THRESHOLD,
    MIXED_CONTENT_BLOCK_AUTO_PICK,
    PART_MOVIE_BLOCK_AUTO_PICK,
)
from .scoring import compute_collision_risk
from .hints import _detect_mixed_content, _detect_part_markers

logger = get_biz_logger_adapter(__name__)


@dataclass
class AutoPickContext:
    """Context for auto-pick decision."""
    evidence_level: int = 2
    selected_hints_count: int = 0
    has_main_hint: bool = False
    support_count: int = 0
    support_main: int = 0
    support_weight: int = 0
    standard_rate: float = 0.0
    episode_count: int = 0
    episode_score: float = 0.0
    count_mismatch: bool = False
    query_title: str = ""
    query_year: Optional[int] = None
    force_media_type: Optional[str] = None
    video_samples: Optional[List[str]] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "evidence_level": self.evidence_level,
            "selected_hints_count": self.selected_hints_count,
            "has_main_hint": self.has_main_hint,
            "support_count": self.support_count,
            "support_main": self.support_main,
            "support_weight": self.support_weight,
            "standard_rate": self.standard_rate,
            "episode_count": self.episode_count,
            "episode_score": self.episode_score,
            "count_mismatch": self.count_mismatch,
            "query_title": self.query_title,
            "query_year": self.query_year,
            "force_media_type": self.force_media_type,
            "video_samples": self.video_samples,
        }


@dataclass
class AutoPickResult:
    """Result of auto-pick decision."""
    ok_pick: bool
    gate_blocked: Optional[str] = None
    decision_trace: Optional[List[str]] = None
    adjusted_threshold: Optional[Dict[str, float]] = None


def check_evidence_level_gate(evidence_level: int) -> Tuple[bool, Optional[str]]:
    """Check evidence level gate (Requirement 3.5).
    
    When evidence_level <= L1, auto-pick is blocked regardless of scores.
    
    Args:
        evidence_level: Evidence level (0-3)
    
    Returns:
        Tuple of (passed, gate_name if blocked)
    """
    if evidence_level <= 1:
        return False, "evidence_level"
    return True, None


def check_collision_risk_gate(
    title: str,
    score: float,
    coverage: float,
    support_count: int,
) -> Tuple[bool, Optional[str], Dict[str, Any]]:
    """Check collision risk gate (Requirement 9.4).
    
    When collision_risky is True AND support_count < 2, auto-pick is blocked
    unless evidence is extremely strong (score >= 0.97, coverage >= 0.92).
    
    Args:
        title: Query title
        score: Top candidate score
        coverage: Top candidate coverage
        support_count: Number of supporting hints
    
    Returns:
        Tuple of (passed, gate_name if blocked, collision_info)
    """
    collision_info = compute_collision_risk(title)
    
    if not collision_info.get("collision_risky", False):
        return True, None, collision_info
    
    # Collision risky - check if we can still proceed
    if support_count >= 2:
        # Multiple hints agree - allow with relaxed threshold
        return True, None, collision_info
    
    # Single hint with collision risk - require extremely strong evidence
    if score >= 0.97 and coverage >= 0.92:
        return True, None, collision_info
    
    return False, "collision_risky", collision_info


def check_mixed_content_gate(
    video_samples: Optional[List[str]],
) -> Tuple[bool, Optional[str], Dict[str, Any]]:
    """Check mixed content gate (Requirement 11.2).
    
    When share contains both movie and TV content, auto-pick is blocked.
    
    Args:
        video_samples: List of video sample filenames
    
    Returns:
        Tuple of (passed, gate_name if blocked, mixed_info)
    """
    if not MIXED_CONTENT_BLOCK_AUTO_PICK:
        return True, None, {}
    
    if not video_samples:
        return True, None, {}
    
    mixed_info = _detect_mixed_content(video_samples)
    
    if mixed_info.get("is_mixed", False):
        return False, "mixed_content", mixed_info
    
    return True, None, mixed_info


def check_part_movie_gate(
    video_samples: Optional[List[str]],
    query_title: str,
) -> Tuple[bool, Optional[str], Dict[str, Any]]:
    """Check part movie gate (Requirement 11.4).
    
    When Part 1/2/3 markers are detected, auto-pick is blocked.
    
    Args:
        video_samples: List of video sample filenames
        query_title: Query title
    
    Returns:
        Tuple of (passed, gate_name if blocked, part_info)
    """
    if not PART_MOVIE_BLOCK_AUTO_PICK:
        return True, None, {}
    
    texts = list(video_samples or []) + [query_title]
    part_info = _detect_part_markers(texts)
    
    if part_info.get("has_part_marker", False):
        return False, "part_movie", part_info
    
    return True, None, part_info


def should_auto_pick_enhanced(
    candidates: List[Dict[str, Any]],
    ctx: AutoPickContext,
) -> AutoPickResult:
    """Enhanced auto-pick decision with all gates (Requirements 3.1-3.5, 9.4, 11.2, 11.4).
    
    This function implements the complete auto-pick decision logic with:
    1. Evidence level gating
    2. Mixed content blocking
    3. Part movie blocking
    4. Collision risk gating
    5. Score/coverage/gap thresholds
    
    Args:
        candidates: List of candidate dicts sorted by score
        ctx: Auto-pick context with evidence and hints info
    
    Returns:
        AutoPickResult with decision and trace
    """
    trace: List[str] = ["start"]
    
    # No candidates
    if not candidates:
        trace.append("no_candidates")
        return AutoPickResult(ok_pick=False, gate_blocked="no_candidates", decision_trace=trace)
    
    # Gate 1: Evidence level (Requirement 3.5)
    passed, gate = check_evidence_level_gate(ctx.evidence_level)
    if not passed:
        trace.append(f"gate:{gate}")
        return AutoPickResult(ok_pick=False, gate_blocked=gate, decision_trace=trace)
    trace.append("pass:evidence_level")
    
    # Gate 2: Mixed content (Requirement 11.2)
    passed, gate, mixed_info = check_mixed_content_gate(ctx.video_samples)
    if not passed:
        trace.append(f"gate:{gate}")
        return AutoPickResult(ok_pick=False, gate_blocked=gate, decision_trace=trace)
    if mixed_info:
        trace.append("pass:mixed_content")
    
    # Gate 3: Part movie (Requirement 11.4)
    passed, gate, part_info = check_part_movie_gate(ctx.video_samples, ctx.query_title)
    if not passed:
        trace.append(f"gate:{gate}")
        return AutoPickResult(ok_pick=False, gate_blocked=gate, decision_trace=trace)
    if part_info:
        trace.append("pass:part_movie")
    
    # Get top candidate info
    top = candidates[0]
    try:
        score = float(top.get("_fused_score") or top.get("score") or 0.0)
    except (ValueError, TypeError):
        score = 0.0
    
    try:
        coverage = float(top.get("coverage") or 0.0)
    except (ValueError, TypeError):
        coverage = 0.0
    
    # Compute gap
    gap = 0.0
    if len(candidates) > 1:
        try:
            second_score = float(candidates[1].get("_fused_score") or candidates[1].get("score") or 0.0)
            gap = score - second_score
        except (ValueError, TypeError):
            gap = 0.0
    else:
        gap = 0.20  # Single candidate gets default gap
    
    # Gate 4: Collision risk (Requirement 9.4)
    passed, gate, collision_info = check_collision_risk_gate(
        ctx.query_title, score, coverage, ctx.support_count
    )
    if not passed:
        trace.append(f"gate:{gate}")
        return AutoPickResult(
            ok_pick=False, 
            gate_blocked=gate, 
            decision_trace=trace,
            adjusted_threshold=collision_info,
        )
    trace.append("pass:collision_risk")
    
    # Get thresholds based on collision risk
    min_score = collision_info.get("min_score_threshold", 0.85)
    min_coverage = collision_info.get("min_coverage_threshold", 0.70)
    
    # Path 1: L3 evidence with strong scores (Requirement 3.1)
    if ctx.evidence_level >= 3:
        if score >= AUTO_PICK_L3_MIN_SCORE and coverage >= AUTO_PICK_L3_MIN_COVERAGE and gap >= AUTO_PICK_L3_MIN_GAP:
            trace.append("auto_pick:L3_strong")
            return AutoPickResult(ok_pick=True, decision_trace=trace)
    
    # Path 2: Episode-based auto-pick for TV (Requirement 3.2)
    if ctx.episode_count >= 3 and ctx.standard_rate >= AUTO_PICK_EPISODE_MIN_STANDARD_RATE:
        if ctx.episode_score >= AUTO_PICK_EPISODE_MIN_EPISODE_SCORE and score >= AUTO_PICK_EPISODE_MIN_SCORE:
            trace.append("auto_pick:episode_match")
            return AutoPickResult(ok_pick=True, decision_trace=trace)
    
    # Path 3: Consensus-based auto-pick (Requirement 3.3)
    if ctx.support_count >= 2 and ctx.support_main >= 1:
        if score >= AUTO_PICK_CONSENSUS_MIN_SCORE:
            trace.append("auto_pick:consensus")
            return AutoPickResult(ok_pick=True, decision_trace=trace)
    
    # Path 4: Single strong candidate (Requirement 3.4)
    if len(candidates) == 1:
        if score >= AUTO_PICK_SINGLE_STRONG_MIN_SCORE and coverage >= AUTO_PICK_SINGLE_STRONG_MIN_COVERAGE:
            trace.append("auto_pick:single_strong")
            return AutoPickResult(ok_pick=True, decision_trace=trace)
    
    # Path 5: General threshold check
    if score >= min_score and coverage >= min_coverage and gap >= 0.05:
        trace.append("auto_pick:threshold")
        return AutoPickResult(ok_pick=True, decision_trace=trace)
    
    # No path matched
    trace.append("no_match")
    return AutoPickResult(
        ok_pick=False, 
        gate_blocked="threshold_not_met", 
        decision_trace=trace,
        adjusted_threshold={
            "min_score": min_score,
            "min_coverage": min_coverage,
            "actual_score": score,
            "actual_coverage": coverage,
            "actual_gap": gap,
        },
    )


def build_autopick_context_from_dict(ctx_dict: Dict[str, Any]) -> AutoPickContext:
    """Build AutoPickContext from a dictionary.
    
    Args:
        ctx_dict: Dictionary with context values
    
    Returns:
        AutoPickContext instance
    """
    return AutoPickContext(
        evidence_level=int(ctx_dict.get("evidence_level", 2)),
        selected_hints_count=int(ctx_dict.get("selected_hints_count", 0)),
        has_main_hint=bool(ctx_dict.get("has_main_hint", False)),
        support_count=int(ctx_dict.get("support_count", 0)),
        support_main=int(ctx_dict.get("support_main", 0)),
        support_weight=int(ctx_dict.get("support_weight", 0)),
        standard_rate=float(ctx_dict.get("standard_rate", 0.0)),
        episode_count=int(ctx_dict.get("episode_count", 0)),
        episode_score=float(ctx_dict.get("episode_score", 0.0)),
        count_mismatch=bool(ctx_dict.get("count_mismatch", False)),
        query_title=str(ctx_dict.get("query_title", "")),
        query_year=ctx_dict.get("query_year"),
        force_media_type=ctx_dict.get("force_media_type"),
        video_samples=ctx_dict.get("video_samples"),
    )
