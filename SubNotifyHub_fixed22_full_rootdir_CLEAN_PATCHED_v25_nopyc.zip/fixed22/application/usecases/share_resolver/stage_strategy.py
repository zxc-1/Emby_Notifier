"""Stage-A/Stage-B strategy functions for TMDB candidate generation.

This module contains functions for:
- Stage-A stability checking (skip Stage-B when confident)
- Bilingual evidence detection (force Stage-B for CJK/Latin mix)
- Hint deduplication (avoid redundant TMDB API calls)
- Year affinity scoring

Extracted from tmdb_lookup.py for better maintainability.
"""

from __future__ import annotations

import re
from typing import Optional

from .constants import (
    YEAR_EXACT_BONUS,
    YEAR_OFF_BY_1_BONUS,
    YEAR_OFF_BY_1_STRICT_PENALTY,
    YEAR_OFF_BY_2_PENALTY,
    YEAR_OFF_BY_3_PENALTY,
    YEAR_MISSING_PENALTY,
    STAGE_A_STABLE_SCORE,
    STAGE_A_STABLE_COVERAGE,
    STAGE_A_EARLY_STOP_SCORE,
    STAGE_A_EARLY_STOP_COVERAGE,
    STAGE_A_EARLY_STOP_GAP,
)


def apply_year_affinity(
    base_score: float,
    query_year: int | None,
    candidate_year: int | None,
    *,
    strict_year: bool = False,
) -> tuple[float, str]:
    """Apply year affinity adjustment to a candidate score (Requirement 5, 16).
    
    Adjusts the score based on how well the candidate year matches the query year.
    
    Args:
        base_score: The original score before year adjustment
        query_year: The year from the query/evidence (may be None)
        candidate_year: The year of the TMDB candidate (may be None)
        strict_year: If True, apply stricter penalties for year mismatches
                    (used when year is explicitly marked in CJK title)
    
    Returns:
        Tuple of (adjusted_score, adjustment_reason)
    """
    if query_year is None:
        return base_score, "no_query_year"
    
    if candidate_year is None:
        return base_score + YEAR_MISSING_PENALTY, "candidate_year_missing"
    
    diff = abs(int(query_year) - int(candidate_year))
    
    if diff == 0:
        return base_score + YEAR_EXACT_BONUS, "year_exact_match"
    elif diff == 1:
        if strict_year:
            return base_score + YEAR_OFF_BY_1_STRICT_PENALTY, "year_off_by_1_strict"
        else:
            return base_score + YEAR_OFF_BY_1_BONUS, "year_off_by_1"
    elif diff == 2:
        return base_score + YEAR_OFF_BY_2_PENALTY, "year_off_by_2"
    elif diff == 3:
        return base_score + YEAR_OFF_BY_3_PENALTY, "year_off_by_3"
    else:
        penalty = YEAR_OFF_BY_3_PENALTY - 0.02 * (diff - 3)
        return base_score + max(penalty, -0.15), f"year_off_by_{diff}"


def check_stage_a_stability(
    candidates: list[dict],
    *,
    min_score: float = STAGE_A_STABLE_SCORE,
    min_coverage: float = STAGE_A_STABLE_COVERAGE,
    early_stop_score: float = STAGE_A_EARLY_STOP_SCORE,
    early_stop_coverage: float = STAGE_A_EARLY_STOP_COVERAGE,
    early_stop_gap: float = STAGE_A_EARLY_STOP_GAP,
) -> dict:
    """Check if Stage-A results are stable enough to skip Stage-B (Requirement 4.1, 13.2).
    
    Stage-A uses main hints (video filename, share title). If the top candidate
    has high confidence, we can skip Stage-B (message hints) to save API calls.
    
    Args:
        candidates: List of candidate dicts from Stage-A
        min_score: Minimum score for stability
        min_coverage: Minimum coverage for stability
        early_stop_score: Score threshold for early stop
        early_stop_coverage: Coverage threshold for early stop
        early_stop_gap: Gap threshold for early stop
    
    Returns:
        Dict with keys:
        - is_stable: True if Stage-A is stable enough
        - can_early_stop: True if we can skip Stage-B entirely
        - reason: Explanation of the decision
        - top_score: Score of top candidate
        - top_coverage: Coverage of top candidate
        - gap: Gap between top and second candidate
    """
    if not candidates:
        return {
            "is_stable": False,
            "can_early_stop": False,
            "reason": "no_candidates",
            "top_score": 0.0,
            "top_coverage": 0.0,
            "gap": 0.0,
        }
    
    top = candidates[0]
    top_score = float(top.get("score") or top.get("_fused_score") or 0.0)
    top_coverage = float(top.get("coverage") or 0.0)
    
    gap = 0.0
    if len(candidates) > 1:
        second = candidates[1]
        second_score = float(second.get("score") or second.get("_fused_score") or 0.0)
        gap = top_score - second_score
    else:
        gap = 1.0
    
    can_early_stop = (
        top_score >= early_stop_score and
        top_coverage >= early_stop_coverage and
        gap >= early_stop_gap
    )
    
    is_stable = (
        top_score >= min_score and
        top_coverage >= min_coverage
    )
    
    if can_early_stop:
        reason = "early_stop_high_confidence"
    elif is_stable:
        reason = "stable_good_match"
    else:
        reason = "unstable_needs_stage_b"
    
    return {
        "is_stable": is_stable,
        "can_early_stop": can_early_stop,
        "reason": reason,
        "top_score": top_score,
        "top_coverage": top_coverage,
        "gap": gap,
    }


def normalize_hint_query_key(hint: str) -> str:
    """Generate a normalized query key for hint deduplication (Requirement 4.5, 13.1).
    
    Normalizes a hint string to create a canonical key for deduplication.
    This prevents redundant TMDB API calls for similar hints.
    
    Args:
        hint: The hint string to normalize
    
    Returns:
        Normalized key string
    """
    h = (hint or "").strip().lower()
    if not h:
        return ""
    
    # Normalize whitespace and separators
    h = re.sub(r"\s+", " ", h)
    h = re.sub(r"[._-]+", " ", h)
    
    # Remove technical tags
    h = re.sub(r"\b(1080p|2160p|720p|4k|8k)\b", "", h, flags=re.IGNORECASE)
    h = re.sub(r"\b(x264|x265|h264|h265|hevc|avc)\b", "", h, flags=re.IGNORECASE)
    h = re.sub(r"\b(bluray|bdrip|webrip|web-dl|hdtv)\b", "", h, flags=re.IGNORECASE)
    h = re.sub(r"\b(remux|bdmv)\b", "", h, flags=re.IGNORECASE)
    h = re.sub(r"\b(hdr|dv|dolby|dts|truehd|atmos)\b", "", h, flags=re.IGNORECASE)
    h = re.sub(r"\b(mkv|mp4|avi|mov)\b", "", h, flags=re.IGNORECASE)
    h = re.sub(r"\s+", " ", h).strip()
    
    return h


def detect_bilingual_evidence(
    hints_main: list[str],
    hints_msg: list[str],
    share_title: str,
) -> dict:
    """Detect if there is bilingual evidence (Requirement 4.2, 12.1).
    
    When share_title is CJK but filenames are Latin (or vice versa),
    we should force Stage-B to search with both languages.
    
    Args:
        hints_main: Main hints (video filenames, etc.)
        hints_msg: Message hints (user input, URL fragment)
        share_title: The share title
    
    Returns:
        Dict with keys:
        - has_bilingual: True if bilingual evidence detected
        - has_cjk: True if CJK text found
        - has_latin: True if Latin text found
        - force_stage_b: True if Stage-B should be forced
    """
    def has_cjk(text: str) -> bool:
        return bool(re.search(r"[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]", text or ""))
    
    def has_latin(text: str) -> bool:
        return bool(re.search(r"[A-Za-z]{3,}", text or ""))
    
    all_texts = [share_title] + list(hints_main or []) + list(hints_msg or [])
    
    found_cjk = any(has_cjk(t) for t in all_texts)
    found_latin = any(has_latin(t) for t in all_texts)
    
    has_bilingual = found_cjk and found_latin
    
    share_is_cjk = has_cjk(share_title)
    main_is_latin = any(has_latin(h) and not has_cjk(h) for h in (hints_main or []))
    
    force_stage_b = share_is_cjk and main_is_latin
    
    return {
        "has_bilingual": has_bilingual,
        "has_cjk": found_cjk,
        "has_latin": found_latin,
        "force_stage_b": force_stage_b,
    }


# Backward compatibility aliases (for existing imports)
_apply_year_affinity = apply_year_affinity
_stage_a_stable = check_stage_a_stability
_hint_query_key = normalize_hint_query_key
_detect_bilingual_evidence = detect_bilingual_evidence
