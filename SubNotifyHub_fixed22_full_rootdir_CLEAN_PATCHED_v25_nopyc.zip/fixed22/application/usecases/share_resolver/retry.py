from __future__ import annotations
from core.exceptions.base import ExternalServiceError

"""Retry and error handling utilities for TMDB API calls."""
import asyncio
import functools
import time
from typing import Any, Callable, Dict, List, Optional, Tuple, Type, TypeVar
from core.logging import get_biz_logger
from core.suppress import suppress

biz = get_biz_logger(__name__)


class TMDBAPIError(Exception):
    """Base class for TMDB API errors."""
    def __init__(self, message: str, *, status_code: Optional[int] = None,
                 error_type: str = "unknown", context: Optional[Dict[str, Any]] = None):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.error_type = error_type
        self.context = context or {}

    def to_dict(self) -> Dict[str, Any]:
        return {"error_type": self.error_type, "message": self.message,
                "status_code": self.status_code, **self.context}


class TMDBTimeoutError(TMDBAPIError):
    """TMDB API timeout error."""
    def __init__(self, message: str = "TMDB API request timed out", *,
                 timeout_seconds: Optional[float] = None, context: Optional[Dict[str, Any]] = None):
        ctx = context or {}
        if timeout_seconds is not None:
            ctx["timeout_seconds"] = timeout_seconds
        super().__init__(message, error_type="timeout", context=ctx)
        self.timeout_seconds = timeout_seconds


class TMDBRateLimitError(TMDBAPIError):
    """TMDB API rate limit error (HTTP 429)."""
    def __init__(self, message: str = "TMDB API rate limit exceeded", *,
                 retry_after: Optional[int] = None, context: Optional[Dict[str, Any]] = None):
        ctx = context or {}
        if retry_after is not None:
            ctx["retry_after"] = retry_after
        super().__init__(message, status_code=429, error_type="rate_limit", context=ctx)
        self.retry_after = retry_after


class TMDBUnavailableError(TMDBAPIError):
    """TMDB API unavailable error (HTTP 5xx)."""
    def __init__(self, message: str = "TMDB API temporarily unavailable", *,
                 status_code: Optional[int] = None, context: Optional[Dict[str, Any]] = None):
        super().__init__(message, status_code=status_code or 503,
                         error_type="unavailable", context=context)


class TMDBNotFoundError(TMDBAPIError):
    """TMDB resource not found error (HTTP 404)."""
    def __init__(self, message: str = "TMDB resource not found", *,
                 resource_type: Optional[str] = None, resource_id: Optional[int] = None,
                 context: Optional[Dict[str, Any]] = None):
        ctx = context or {}
        if resource_type:
            ctx["resource_type"] = resource_type
        if resource_id:
            ctx["resource_id"] = resource_id
        super().__init__(message, status_code=404, error_type="not_found", context=ctx)


RETRYABLE_EXCEPTIONS: Tuple[Type[Exception], ...] = (
    TMDBTimeoutError, TMDBRateLimitError, TMDBUnavailableError,
    asyncio.TimeoutError, ConnectionError, OSError,
)

NON_RETRYABLE_EXCEPTIONS: Tuple[Type[Exception], ...] = (
    TMDBNotFoundError, ValueError, TypeError,
)

T = TypeVar("T")


def compute_backoff_delay(attempt: int, base_delay: float = 1.0,
                          max_delay: float = 30.0, jitter: float = 0.1) -> float:
    """Compute exponential backoff delay with jitter."""
    import random
    delay = base_delay * (2 ** attempt)
    delay = min(delay, max_delay)
    if jitter > 0:
        delay = delay + delay * jitter * random.random()
    return delay


def with_retry(max_retries: int = 2, base_delay: float = 1.0, max_delay: float = 30.0,
               retryable_exceptions: Optional[Tuple[Type[Exception], ...]] = None,
               on_retry: Optional[Callable[[Exception, int], None]] = None):
    """Decorator for async functions with exponential backoff retry."""
    if retryable_exceptions is None:
        retryable_exceptions = RETRYABLE_EXCEPTIONS

    def decorator(func):
        @functools.wraps(func)
        async def wrapper(*args, **kwargs):
            last_exception = None
            for attempt in range(max_retries + 1):
                try:
                    return await func(*args, **kwargs)
                except retryable_exceptions as e:
                    last_exception = e
                    if attempt >= max_retries:
                        break
                    delay = compute_backoff_delay(attempt, base_delay, max_delay)
                    if isinstance(e, TMDBRateLimitError) and e.retry_after:
                        delay = max(delay, float(e.retry_after))
                    biz.warning("⚠️ TMDB API 调用失败，将在稍后重试", stage="tmdb_retry", attempt=attempt + 1, max_retries=max_retries, delay_sec=round(delay, 3), err=type(e).__name__, reason=str(e)[:200])
                    if on_retry:
                        try:
                            on_retry(e, attempt)
                        except Exception as e2:
                            suppress(site="share_resolver/retry:on_retry", exc=e2, fallback=None)
                    await asyncio.sleep(delay)
                except NON_RETRYABLE_EXCEPTIONS:
                    raise
            if last_exception:
                raise last_exception
            raise ExternalServiceError("Retry logic error")
        return wrapper
    return decorator


def log_api_error(error: Exception, *, operation: str,
                  share_code_hash: Optional[str] = None, hint_count: Optional[int] = None,
                  tmdb_id: Optional[int] = None, extra: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Log API error with structured context."""
    error_dict: Dict[str, Any] = {
        "operation": operation, "error_class": type(error).__name__,
        "error_message": str(error),
    }
    if share_code_hash:
        error_dict["share_code_hash"] = share_code_hash
    if hint_count is not None:
        error_dict["hint_count"] = hint_count
    if tmdb_id is not None:
        error_dict["tmdb_id"] = tmdb_id
    if isinstance(error, TMDBAPIError):
        error_dict.update(error.to_dict())
    if extra:
        error_dict.update(extra)
    if isinstance(error, (TMDBTimeoutError, TMDBUnavailableError)):
        biz.warning("⚠️ TMDB API 暂时不可用，将按重试策略处理", stage="tmdb_api", **error_dict)
    elif isinstance(error, TMDBRateLimitError):
        biz.warning("⚠️ TMDB API 触发限流，将按 retry-after/backoff 处理", stage="tmdb_api", **error_dict)
    elif isinstance(error, TMDBNotFoundError):
        biz.detail("TMDB 未找到资源", stage="tmdb_api", **error_dict)
    else:
        biz.fail("❌ TMDB API 未知错误", stage="tmdb_api", **error_dict)
    return error_dict


def classify_http_error(status_code: int, response_text: Optional[str] = None,
                        context: Optional[Dict[str, Any]] = None) -> TMDBAPIError:
    """Classify HTTP error into appropriate TMDB error type."""
    ctx = context or {}
    if status_code == 404:
        return TMDBNotFoundError(message=response_text or "Resource not found", context=ctx)
    elif status_code == 429:
        retry_after = ctx.get("retry_after")
        return TMDBRateLimitError(message=response_text or "Rate limit exceeded",
                                  retry_after=int(retry_after) if retry_after else None, context=ctx)
    elif 500 <= status_code < 600:
        return TMDBUnavailableError(message=response_text or f"Server error {status_code}",
                                    status_code=status_code, context=ctx)
    else:
        return TMDBAPIError(message=response_text or f"HTTP error {status_code}",
                           status_code=status_code, error_type="http_error", context=ctx)


def is_retryable_error(error: Exception) -> bool:
    """Check if an error is retryable."""
    return isinstance(error, RETRYABLE_EXCEPTIONS)


def is_temporary_unavailable(error: Exception) -> bool:
    """Check if error indicates temporary unavailability."""
    if isinstance(error, (TMDBTimeoutError, TMDBUnavailableError, TMDBRateLimitError)):
        return True
    if isinstance(error, asyncio.TimeoutError):
        return True
    if isinstance(error, (ConnectionError, OSError)):
        return True
    return False


class RetryContext:
    """Context manager for tracking retry state."""
    def __init__(self, max_retries: int = 2, base_delay: float = 1.0):
        self.max_retries = max_retries
        self.base_delay = base_delay
        self.attempt = 0
        self.errors: List[Exception] = []
        self.start_time: Optional[float] = None
        self.end_time: Optional[float] = None

    def __enter__(self) -> "RetryContext":
        # Use a monotonic clock for durations to avoid issues when system time jumps.
        self.start_time = time.perf_counter()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> bool:
        self.end_time = time.perf_counter()
        return False

    @property
    def elapsed_time(self) -> float:
        if self.start_time is None:
            return 0.0
        return (self.end_time or time.perf_counter()) - self.start_time

    @property
    def can_retry(self) -> bool:
        return self.attempt < self.max_retries

    def record_error(self, error: Exception) -> None:
        self.errors.append(error)
        self.attempt += 1

    def get_delay(self) -> float:
        return compute_backoff_delay(self.attempt, base_delay=self.base_delay)

    def to_dict(self) -> Dict[str, Any]:
        return {
            "attempts": self.attempt + 1, "max_retries": self.max_retries,
            "elapsed_time": round(self.elapsed_time, 3), "error_count": len(self.errors),
            "last_error": str(self.errors[-1]) if self.errors else None,
        }
