"""Alias and translation matching for TMDB candidate scoring.

This module contains functions for:
- Fetching alternative titles from TMDB
- Computing similarity with alias consideration
- Weighting CJK share titles

Extracted for better maintainability (Requirement 12).
"""

from __future__ import annotations

import re
from typing import List, Optional

from core.logging import get_biz_logger_adapter

logger = get_biz_logger_adapter(__name__)


async def fetch_alternative_titles(
    tmdb_id: int,
    media_type: str,
) -> List[str]:
    """Fetch alternative titles from TMDB (Requirement 12.2).
    
    Wraps the existing integrations/tmdb_match/aliases.py implementation.
    
    Args:
        tmdb_id: TMDB ID of the candidate
        media_type: 'tv' or 'movie'
    
    Returns:
        List of alternative titles (may be empty)
    """
    try:
        from integrations.tmdb_match.aliases import fetch_tmdb_alias_titles
        
        titles = await fetch_tmdb_alias_titles(
            tmdb_id=tmdb_id,
            media_type=media_type,
        )
        return titles or []
    except Exception as e:
        logger.detail(f"获取候选别名列表失败：{e}")
        return []


def _normalize_for_comparison(text: str) -> str:
    """Normalize text for similarity comparison."""
    if not text:
        return ""
    # Lowercase
    t = text.lower()
    # Remove punctuation and extra whitespace
    t = re.sub(r"[^\w\s\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]", " ", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t


def _simple_similarity(a: str, b: str) -> float:
    """Compute simple similarity between two strings.
    
    Uses character-level Jaccard similarity for CJK,
    word-level for Latin text.
    """
    a_norm = _normalize_for_comparison(a)
    b_norm = _normalize_for_comparison(b)
    
    if not a_norm or not b_norm:
        return 0.0
    
    # Check if either contains CJK
    has_cjk = bool(re.search(r"[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]", a_norm + b_norm))
    
    if has_cjk:
        # Character-level comparison for CJK
        set_a = set(a_norm.replace(" ", ""))
        set_b = set(b_norm.replace(" ", ""))
    else:
        # Word-level comparison for Latin
        set_a = set(a_norm.split())
        set_b = set(b_norm.split())
    
    if not set_a or not set_b:
        return 0.0
    
    intersection = len(set_a & set_b)
    union = len(set_a | set_b)
    
    return intersection / union if union > 0 else 0.0


def compute_alias_similarity(
    query: str,
    candidate_title: str,
    alternative_titles: List[str],
) -> float:
    """Compute similarity considering alternative titles (Requirement 12.2, 12.3).
    
    Returns the maximum similarity between query and:
    - candidate_title (primary)
    - any alternative_title
    
    This ensures that CJK queries can match English TMDB entries via aliases.
    
    Args:
        query: The search query (e.g., share_title or filename)
        candidate_title: The primary title from TMDB
        alternative_titles: List of alternative titles from TMDB
    
    Returns:
        Maximum similarity score (0.0 to 1.0)
    """
    if not query:
        return 0.0
    
    # Start with primary title similarity
    max_sim = _simple_similarity(query, candidate_title)
    
    # Check each alternative title
    for alt in (alternative_titles or []):
        if not alt:
            continue
        sim = _simple_similarity(query, alt)
        if sim > max_sim:
            max_sim = sim
    
    return max_sim


def has_cjk_text(text: str) -> bool:
    """Check if text contains CJK characters."""
    return bool(re.search(r"[\u4e00-\u9fff\u3040-\u309f\u30a0-\u30ff]", text or ""))


def has_latin_text(text: str) -> bool:
    """Check if text contains Latin characters (at least 3 consecutive)."""
    return bool(re.search(r"[A-Za-z]{3,}", text or ""))


def weight_cjk_share_title(
    share_title: str,
    filename: str,
    current_weight: float,
) -> float:
    """Adjust weight when share_title is CJK and filename is Latin (Requirement 12.5).
    
    Human-chosen CJK labels (share_title) are often more reliable than
    release filenames which use English aliases.
    
    Args:
        share_title: The share title (human-chosen label)
        filename: The video filename
        current_weight: Current weight for share_title hint
    
    Returns:
        Adjusted weight (may be higher if CJK/Latin mismatch detected)
    """
    if not share_title or not filename:
        return current_weight
    
    share_is_cjk = has_cjk_text(share_title) and not has_latin_text(share_title)
    file_is_latin = has_latin_text(filename) and not has_cjk_text(filename)
    
    if share_is_cjk and file_is_latin:
        # CJK share_title with Latin filename - boost share_title weight
        # Human chose CJK name, release uses English alias
        return current_weight * 1.5
    
    return current_weight


def normalize_romanized_cjk(title: str) -> Optional[str]:
    """Attempt to normalize romanized CJK titles (Requirement 12.4).
    
    This is a heuristic function that tries to identify common
    romanization patterns. Not guaranteed to be accurate.
    
    Args:
        title: Potentially romanized CJK title (e.g., "Qing Nian")
    
    Returns:
        Normalized form if pattern detected, None otherwise
    
    Note:
        This is a placeholder for future enhancement.
        Full romanization->CJK conversion requires external libraries
        like pypinyin or similar.
    """
    # For now, just return None - this is a complex problem
    # that requires proper pinyin/romaji dictionaries
    # Future: integrate with pypinyin or similar library
    return None
