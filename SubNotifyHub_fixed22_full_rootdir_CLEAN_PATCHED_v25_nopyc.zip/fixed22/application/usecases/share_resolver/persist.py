from __future__ import annotations

"""Persistence stage for share->TMDB resolver (stage ⑥).

This module writes:
- share_code -> tmdb_id mapping (strong/weak)
- title fingerprint mapping (cross share reuse)
- optional global series fingerprints (tv only)
- pending choice tokens (need_pick / weak-pick correction)

It returns the final response dict used by upstream callers.
"""

import asyncio
import logging
from core.logging import get_biz_logger_adapter
from typing import Any, Dict, List, Optional

from ports.settings_provider import get_settings
from .ports_access import tmdb
from core.suppress import safe_int

from .repo import create_pending_choice, upsert_mapping, upsert_series_mapping, upsert_title_mapping

logger = get_biz_logger_adapter(__name__)


async def finalize(
    *,
    from_source: str = "auto",

    chat_id: int,
    user_id: int,
    share_url: str,
    share_code: str,
    receive_code: str,
    file_sig: Optional[str],
    share_title: str,
    filename: str,
    hint_name: str,
    q_title: str,
    q_year: Optional[int],
    used_title: str,
    used_year: Optional[int],
    used_mt: str,
    used_season: Optional[int],
    force_mt: Optional[str],
    evidence_temp_unavailable: bool,
    evidence_weak: bool,
    evidence_level: int = 2,
    evidence_level_desc: Optional[str] = None,
    has_msg_hints: bool,
    decision_trace: List[str],
    cands_all: List[Dict[str, Any]],
    cands_show: List[Dict[str, Any]],
    picked: Optional[Dict[str, Any]],
    ok_pick: bool,
    auto_strength: Optional[str],
) -> Dict[str, Any]:
    """Persist final decision and build response."""

    # Evidence gate: if we did not obtain real video filename samples (L1 and below),
    # do NOT auto-pick, do NOT persist weak hints, and require user confirmation.
    try:
        ev_lv = int(evidence_level or 0)
    except (ValueError, TypeError) as e:
        logger.detail(f"证据等级读取失败（已忽略） - evidence_level={evidence_level}, 原因={type(e).__name__}")
        ev_lv = 2
    if ev_lv <= 1:
        picked = None
        ok_pick = False
        auto_strength = "weak"
        if isinstance(decision_trace, list):
            decision_trace.append(f"gate:{evidence_level_desc or 'L1'}")

    # Auto path
    if picked and picked.get("tmdb_id"):
        tmdb_id = int(picked["tmdb_id"])
        auto_strength_eff = str(auto_strength or ("strong" if ok_pick else "weak"))

        if share_code:
            await asyncio.to_thread(
                upsert_mapping,
                share_code=share_code,
                receive_code=receive_code,
                tmdb_id=tmdb_id,
                media_type=str(picked.get("media_type") or "movie"),
                title=str(picked.get("title") or ""),
                year=safe_int(picked.get("year")) or (q_year or used_year),
                season=int(used_season) if used_season is not None else None,
                strength=auto_strength_eff,
                confidence=float(picked.get("score") or 0.0),
                evidence_title=q_title or used_title,
                evidence_year=q_year or used_year,
                file_sig=file_sig,
            )

        # Learn title->tmdb mapping (cross share reuse)
        # IMPORTANT: never learn global title/series mappings when evidence is weak.
        # Weak evidence commonly means we did not obtain real video filenames (e.g. only a folder name),
        # and learning from that will pollute future runs across different shares.
        if (not evidence_weak) and ev_lv >= 2:
            try:
                ev_t = str((q_title or used_title or picked.get("title") or "").strip())
                ev_y = q_year or used_year or picked.get("year")
                ev_mt = str(picked.get("media_type") or used_mt or "movie").strip().lower() or "movie"
                ev_s = int(used_season) if used_season is not None else None
                if ev_t:
                    fp1 = tmdb().make_title_fingerprint(ev_t, ev_y, ev_mt, ev_s)
                    await asyncio.to_thread(
                        upsert_title_mapping,
                        fp=fp1,
                        tmdb_id=tmdb_id,
                        media_type=ev_mt,
                        title=str(picked.get("title") or ""),
                        year=ev_y,
                        season=ev_s,
                        confidence=float(picked.get("score") or 0.0),
                        source="auto",
                    )
                    if ev_s is not None:
                        fp2 = tmdb().make_title_fingerprint(ev_t, ev_y, ev_mt, None)
                        await asyncio.to_thread(
                            upsert_title_mapping,
                            fp=fp2,
                            tmdb_id=tmdb_id,
                            media_type=ev_mt,
                            title=str(picked.get("title") or ""),
                            year=ev_y,
                            season=None,
                            confidence=float(picked.get("score") or 0.0),
                            source="auto",
                        )
            except Exception:
                logger.detail("title mapping upsert 失败", exc_info=True)

        # Learn global TV series mapping (only on strong)
        # Same safety rule: never learn series mappings when evidence is weak.
        try:
            if (not evidence_weak) and ev_lv >= 2 and auto_strength_eff == "strong":
                ev_t2 = str((q_title or used_title or picked.get("title") or "").strip())
                ev_y2 = q_year or used_year or picked.get("year")
                ev_mt2 = str(picked.get("media_type") or used_mt or "movie").strip().lower() or "movie"
                if ev_mt2 == "tv":
                    det_zh = await tmdb().fetch_tmdb_detail(int(tmdb_id), prefer_media_type="tv")
                    det_en = await tmdb().fetch_tmdb_detail(int(tmdb_id), prefer_media_type="tv", language="en-US", region="US")

                    year_pref = None
                    for det in (det_zh, det_en):
                        if isinstance(det, dict) and det.get("year") is not None:
                            try:
                                year_pref = int(det.get("year"))
                                break
                            except (ValueError, TypeError) as e:
                                logger.detail(f"TMDB 年份读取失败（已忽略） - year={det.get('year')}, 原因={type(e).__name__}")
                                year_pref = None
                    if year_pref is None and ev_y2 is not None:
                        try:
                            year_pref = int(ev_y2)
                        except (ValueError, TypeError) as e:
                            logger.detail(f"证据年份读取失败（已忽略） - ev_y2={ev_y2}, 原因={type(e).__name__}")
                            year_pref = None

                    titles_for_keys: List[str] = []
                    for t in (ev_t2, str(picked.get("title") or "").strip()):
                        if t:
                            titles_for_keys.append(t)
                    for det in (det_zh, det_en):
                        if isinstance(det, dict):
                            for k in ("title", "original_title"):
                                v = str(det.get(k) or "").strip()
                                if v:
                                    titles_for_keys.append(v)

                    seen_t = set()
                    uniq_titles: List[str] = []
                    for t in titles_for_keys:
                        if t not in seen_t:
                            seen_t.add(t)
                            uniq_titles.append(t)

                    for t in uniq_titles:
                        for sk in tmdb().make_series_fingerprints(t, year_pref):
                            await asyncio.to_thread(
                                upsert_series_mapping,
                                sk=sk,
                                tmdb_id=tmdb_id,
                                media_type="tv",
                                title=str(picked.get("title") or ""),
                                year=safe_int(picked.get("year")) or year_pref,
                                confidence=float(picked.get("score") or 0.0),
                                source="auto_strong",
                            )
        except Exception:
            logger.detail("series mapping upsert 失败", exc_info=True)

        # Weak auto-pick correction token
        weak_pick_token = None
        weak_candidates = None
        try:
            if auto_strength_eff == "weak" and cands_all:
                weak_candidates = cands_show
                corr_candidates = (cands_all[:8] if isinstance(cands_all, list) else weak_candidates) or weak_candidates
                weak_pick_token = create_pending_choice(
                    chat_id=chat_id,
                    user_id=user_id,
                    share_url=share_url,
                    share_code=share_code,
                    receive_code=receive_code,
                    season=int(used_season) if used_season is not None else None,
                    evidence_title=q_title or used_title,
                    evidence_year=q_year or used_year,
                    evidence_media_type=str(used_mt or force_mt or ""),
                    file_sig=file_sig,
                    candidates=corr_candidates,
                )
        except Exception:
            logger.detail("weak-pick token creation 失败", exc_info=True)

        return {
            "ok": True,
            "tmdb_id": tmdb_id,
            "share_code": share_code,
            "receive_code": receive_code,
            "share_title": share_title,
            "from": str(from_source or "auto"),
            "auto_strength": auto_strength_eff,
            "weak_pick_token": weak_pick_token,
            "weak_candidates": weak_candidates,
            "picked": picked,
            "filename": filename,
            "hint_name": hint_name,
            "season": used_season,
            "media_type": picked.get("media_type") or used_mt,
            "decision_trace": decision_trace,
        }

    # No candidates
    if not cands_all:
        s = get_settings()
        if not str(getattr(s, "TMDB_API_KEY", "") or "").strip():
            return {"ok": False, "reason": "no_tmdb_api_key", "share_code": share_code, "decision_trace": decision_trace}
        return {
            "ok": False,
            "reason": (
                "share115_temp_unavailable"
                if (evidence_temp_unavailable and not has_msg_hints)
                else (
                    "share_evidence_incomplete" if (evidence_weak and not has_msg_hints) else "no_candidates"
                )
            ),
            "share_code": share_code,
            "share_title": share_title,
            "filename": filename,
            "hint_name": hint_name,
            "title": used_title,
            "year": used_year,
            "media_type": used_mt,
            "season": used_season,
            "decision_trace": decision_trace,
        }

    # Low confidence -> need pick
    # Store a weak hint to help future runs.
    if share_code and cands_all and ev_lv >= 2 and (not evidence_temp_unavailable):
        try:
            _best = cands_all[0]
            _best_s = float(_best.get("score") or 0.0)
        except (ValueError, TypeError, IndexError, KeyError) as e:
            logger.detail(f"最佳候选读取失败（已忽略） - cands_all={len(cands_all) if cands_all else 0}, 原因={type(e).__name__}")
            _best, _best_s = None, 0.0
        if _best and _best_s >= 0.75:
            try:
                await asyncio.to_thread(
                    upsert_mapping,
                    share_code=share_code,
                    receive_code=receive_code,
                    tmdb_id=int(_best.get("tmdb_id") or 0),
                    media_type=str(_best.get("media_type") or used_mt or "movie"),
                    title=str(_best.get("title") or ""),
                    year=_best.get("year"),
                    season=int(used_season) if used_season is not None else None,
                    strength="weak",
                    confidence=_best_s,
                    evidence_title=q_title or used_title,
                    evidence_year=q_year or used_year,
                    file_sig=file_sig,
                )
            except Exception:
                logger.detail("weak hint upsert 失败", exc_info=True)

    token = create_pending_choice(
        chat_id=chat_id,
        user_id=user_id,
        share_url=share_url,
        share_code=share_code,
        receive_code=receive_code,
        season=int(used_season) if used_season is not None else None,
        evidence_title=q_title or used_title,
        evidence_year=q_year or used_year,
        evidence_media_type=str(used_mt or force_mt or ""),
        file_sig=file_sig,
        candidates=cands_show,
    )
    return {
        "ok": False,
        "reason": "need_pick",
        "token": token,
        "candidates": cands_show,
        "share_code": share_code,
        "receive_code": receive_code,
        "share_title": share_title,
        "filename": filename,
        "title": used_title,
        "year": used_year,
        "media_type": used_mt,
        "season": used_season,
        "decision_trace": decision_trace,
    }
