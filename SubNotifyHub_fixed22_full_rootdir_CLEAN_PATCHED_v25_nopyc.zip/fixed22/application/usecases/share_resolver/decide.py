from __future__ import annotations

"""Decision stage for share->TMDB resolver (stage ⑤).

Given merged candidate lists, decide whether we can auto-pick, and whether the
binding should be persisted as strong or weak.

This module does not touch database persistence.
"""

import logging
from core.logging import get_biz_logger_adapter
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass
import re

from .ports_access import tmdb
from .gateways import tmdb_detail_safe
from .constants import (
    DECIDE_FASTPASS_STRICT_MIN_SCORE,
    DECIDE_FASTPASS_STRICT_MIN_EPISODE_SCORE,
    DECIDE_FASTPASS_STRICT_MIN_GAP,
    DECIDE_FASTPASS_STRICT_MIN_COVERAGE,
    DECIDE_FASTPASS_BATCH_MIN_STANDARD_RATE,
    DECIDE_FASTPASS_BATCH_MIN_EPISODES,
    DECIDE_FASTPASS_BATCH_MIN_EPISODE_COVERAGE,
    DECIDE_FASTPASS_BATCH_MIN_SCORE,
    DECIDE_FASTPASS_BATCH_MIN_EPISODE_SCORE,
    DECIDE_FASTPASS_BATCH_MIN_GAP,
    DECIDE_FASTPASS_BATCH_MIN_COVERAGE,
    DECIDE_SINGLE_UPGRADE_MIN_SCORE,
    DECIDE_SINGLE_UPGRADE_MIN_COVERAGE,
    DECIDE_SINGLE_UPGRADE_COLLISION_MIN_SCORE,
    DECIDE_SINGLE_UPGRADE_COLLISION_MIN_COVERAGE,
    DECIDE_SINGLE_UPGRADE_GAP,
    DECIDE_SINGLE_UPGRADE_MAX_YEAR_DIFF,
    DECIDE_RESCORE_MIN_SCORE,
    DECIDE_RESCORE_MAX_GAP,
    DECIDE_RESCORE_MIN_COVERAGE,
    DECIDE_STRENGTH_MAX_YEAR_DIFF,
    DECIDE_STRENGTH_MANY_CANDIDATES,
    DECIDE_STRENGTH_MANY_CANDIDATES_MIN_GAP,
    DECIDE_STRENGTH_SHORT_TITLE_MAX_LEN,
    DECIDE_EVIDENCE_GATE_LEVEL,
    DECIDE_MIN_EVIDENCE_LEVEL,
)
from core.suppress import safe_int

logger = get_biz_logger_adapter(__name__)

_YEAR_IN_TITLE_RE = re.compile(r"\((19\d{2}|20\d{2})\)")

# Collision-risky tokens for single-candidate auto-upgrade
_COLLISION_TOKENS = {
    "man", "one", "family", "home", "love", "world", "life", "day", "night",
    "story", "journey", "the", "a", "an", "and",
    "男人", "一个", "家庭", "家", "爱情", "世界", "人生", "故事", "旅程",
}


def _infer_year_from_title(t: str) -> Optional[int]:
    try:
        m = _YEAR_IN_TITLE_RE.search(str(t or ""))
        return int(m.group(1)) if m else None
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"标题年份推断失败（返回 None） - title={t}, 原因={type(e).__name__}")
        return None


def _get_coverage(d: Dict[str, Any]) -> float:
    """Extract coverage value from candidate dict."""
    try:
        return float(d.get("coverage") or 0.0)
    except (ValueError, TypeError) as e:
        logger.detail(f"覆盖率解析失败（返回 0.0） - value={d.get('coverage') if isinstance(d, dict) else None}, 原因={type(e).__name__}")
        return 0.0


def _episode_aware_fastpass(
    cands_all: List[Dict[str, Any]],
    used_season: Optional[int],
    ev_level: int,
    count_mismatch: bool,
    standard_rate: float,
    episode_set: Optional[List[int]],
    episode_best_files: Optional[List[Dict[str, Any]]],
) -> bool:
    """Episode-aware fast-pass for TV series auto-pick.
    
    When we have a reliable episode-set match score on top1, we can safely
    relax some conservative gates. This is especially useful when the title
    similarity is near-perfect but classic gap/consensus rules are too strict.
    
    Args:
        cands_all: List of candidate dicts (sorted by score descending)
        used_season: Season number if detected, None otherwise
        ev_level: Evidence level (0-3)
        count_mismatch: Whether episode count mismatches expected
        standard_rate: Rate of files matching standard SxxEyy pattern
        episode_set: List of episode numbers detected
        episode_best_files: List of best file dicts per episode
        
    Returns:
        True if fast-pass conditions are met, False otherwise
        
    Safety conditions:
        1) strict: similarity>=0.95 AND episode_score>=0.45 AND gap>=0.10
        2) batch-evidence: high standard-rate + good episode coverage can relax the gap
    """
    # Pre-conditions
    if not cands_all or used_season is None or ev_level < DECIDE_MIN_EVIDENCE_LEVEL or count_mismatch:
        return False
    
    try:
        top0 = cands_all[0]
        top1 = cands_all[1] if len(cands_all) > 1 else None
        
        sim = float(top0.get("score") or 0.0)
        cov0 = _get_coverage(top0)
        ep_sc = float(top0.get("_episode_score") or 0.0)
        
        # Use fused score gap (after episode fusion) to measure confidence
        bsf = float(top0.get("_fused_score") if top0.get("_fused_score") is not None else (top0.get("score") or 0.0))
        ssf = 0.0
        if isinstance(top1, dict):
            ssf = float(top1.get("_fused_score") if top1.get("_fused_score") is not None else (top1.get("score") or 0.0))
        gap = bsf - ssf
        
        mt0 = str(top0.get("media_type") or "").strip().lower()
        
        # Must be TV content
        if mt0 != "tv":
            return False
        
        # Policy 1: strict conditions
        if (sim >= DECIDE_FASTPASS_STRICT_MIN_SCORE and 
            ep_sc >= DECIDE_FASTPASS_STRICT_MIN_EPISODE_SCORE and 
            gap >= DECIDE_FASTPASS_STRICT_MIN_GAP and 
            cov0 >= DECIDE_FASTPASS_STRICT_MIN_COVERAGE):
            return True
        
        # Policy 2: batch-evidence relaxation
        try:
            sr = float(standard_rate or 0.0)
        except (TypeError, ValueError):
            sr = 0.0
        try:
            total_eps = int(len(episode_set or []))
        except (TypeError, ValueError):
            total_eps = 0
        try:
            best_eps = int(len(episode_best_files or []))
        except (TypeError, ValueError):
            best_eps = 0
        
        cov_eps = (float(best_eps) / float(total_eps)) if total_eps > 0 else 0.0
        
        # When the directory is a clean season pack (standard SxxEyy for most files)
        # and we have a consistent episode set, allow a smaller margin
        if (sr >= DECIDE_FASTPASS_BATCH_MIN_STANDARD_RATE and 
            total_eps >= DECIDE_FASTPASS_BATCH_MIN_EPISODES and 
            cov_eps >= DECIDE_FASTPASS_BATCH_MIN_EPISODE_COVERAGE and 
            sim >= DECIDE_FASTPASS_BATCH_MIN_SCORE and 
            ep_sc >= DECIDE_FASTPASS_BATCH_MIN_EPISODE_SCORE and 
            gap >= DECIDE_FASTPASS_BATCH_MIN_GAP and 
            cov0 >= DECIDE_FASTPASS_BATCH_MIN_COVERAGE):
            return True
        
        return False
        
    except Exception:
        logger.detail("分集快速通道判断失败（已忽略）", exc_info=True)
        return False


def _is_collision_risky(q_eff: str) -> Tuple[bool, int]:
    """Check if query title has collision-risky tokens.
    
    Args:
        q_eff: Effective query title string
        
    Returns:
        Tuple of (is_risky, token_count)
        - is_risky: True if title contains collision-risky tokens
        - token_count: Number of meaningful tokens in title
    """
    tc = len(re.findall(r"[A-Za-z0-9]+|[\u4e00-\u9fff]+", q_eff))
    toks = [t.lower() for t in re.findall(r"[A-Za-z]{2,}|[\u4e00-\u9fff]+", q_eff)]
    collision_risky = bool(toks and len(toks) <= 3 and any(t in _COLLISION_TOKENS for t in toks))
    return collision_risky, tc


@dataclass
class SingleCandidateUpgradeResult:
    """Result of single-candidate auto-upgrade attempt."""
    upgraded: bool
    auto_score: float
    auto_cov: float
    auto_gap: float
    detail_fetched: bool = False


async def _single_candidate_auto_upgrade(
    picked: Dict[str, Any],
    cands_all: List[Dict[str, Any]],
    q_title: str,
    used_title: str,
    q_year: Optional[int],
    force_mt: Optional[str],
    has_main_hint: bool,
    current_score: float,
    current_cov: float,
    current_gap: float,
) -> SingleCandidateUpgradeResult:
    """Conservative single-candidate auto-upgrade (accuracy-first).
    
    When there's only one candidate and we have a main hint, try to upgrade
    from weak to strong by fetching details and re-scoring.
    
    Args:
        picked: The picked candidate dict
        cands_all: List of all candidates (should have exactly 1)
        q_title: Query title
        used_title: Used title (fallback)
        q_year: Query year (optional)
        force_mt: Forced media type (optional)
        has_main_hint: Whether we have a main hint
        current_score: Current auto_score
        current_cov: Current auto_cov
        current_gap: Current auto_gap
        
    Returns:
        SingleCandidateUpgradeResult with upgrade decision and updated scores
        
    Upgrade conditions:
        - Must have exactly 1 candidate
        - Must have main hint
        - Must have valid query title
        - Year must match (if both present)
        - Score/coverage must meet thresholds (higher for collision-risky titles)
    """
    result = SingleCandidateUpgradeResult(
        upgraded=False,
        auto_score=current_score,
        auto_cov=current_cov,
        auto_gap=current_gap,
    )
    
    # Pre-conditions
    if len(cands_all) != 1 or not has_main_hint:
        return result
    
    q_eff = str((q_title or used_title or "")).strip()
    if not q_eff:
        return result
    
    try:
        collision_risky, tc = _is_collision_risky(q_eff)
        
        tid0 = int(picked.get("tmdb_id") or 0)
        mt0 = str(picked.get("media_type") or "").strip().lower() or None
        
        if tid0 <= 0:
            return result
        
        det = await tmdb_detail_safe(tid0, prefer_media_type=mt0, timeout=3.0)
        if not isinstance(det, dict) or not det:
            return result
        
        result.detail_fetched = True
        
        cand0 = CandidateShim(
            tmdb_id=tid0,
            media_type=str(det.get("media_type") or (mt0 or "movie")),
            title=str(det.get("title") or "").strip(),
            year=det.get("year"),
            rating=float(det.get("rating") or 0.0),
            vote_count=int(det.get("vote_count") or 0),
            score=1.0,
            extra=det,
        )
        
        ns, nc, _ = tmdb().score_candidate_meta(q_eff, q_year, cand0)
        
        result.auto_score = float(max(float(current_score), float(ns)))
        result.auto_cov = float(max(float(current_cov), float(nc)))
        
        # Update picked and cands_all
        picked["score"] = round(result.auto_score, 3)
        picked["coverage"] = round(result.auto_cov, 3)
        try:
            cands_all[0]["score"] = picked["score"]
            cands_all[0]["coverage"] = picked["coverage"]
            cands_all[0]["_details_checked"] = True
        except (KeyError, IndexError, TypeError) as e:
            logger.detail(f"候选列表更新失败（已忽略） - 原因={type(e).__name__}")
        
        # Check year compatibility
        det_y = safe_int(det.get("year"))
        if q_year is not None and det_y is not None and abs(int(det_y) - int(q_year)) >= DECIDE_SINGLE_UPGRADE_MAX_YEAR_DIFF:
            return result  # Year mismatch, don't upgrade
        
        # Determine thresholds based on collision risk
        th_s, th_c = DECIDE_SINGLE_UPGRADE_MIN_SCORE, DECIDE_SINGLE_UPGRADE_MIN_COVERAGE
        if tc <= 1 or collision_risky:
            th_s, th_c = DECIDE_SINGLE_UPGRADE_COLLISION_MIN_SCORE, DECIDE_SINGLE_UPGRADE_COLLISION_MIN_COVERAGE
        
        # Check media type compatibility
        if force_mt == "tv" and str(picked.get("media_type") or "").strip().lower() == "movie":
            return result  # Media type mismatch, don't upgrade
        
        # Check if scores meet thresholds
        if result.auto_score >= th_s and result.auto_cov >= th_c:
            result.upgraded = True
            result.auto_gap = max(float(current_gap or 0.0), DECIDE_SINGLE_UPGRADE_GAP)
            picked["gap"] = result.auto_gap
            try:
                cands_all[0]["gap"] = result.auto_gap
                cands_all[0]["_single_candidate_auto_strong"] = True
            except (KeyError, IndexError, TypeError) as e:
                logger.detail(f"候选列表更新失败（已忽略） - 原因={type(e).__name__}")
        
        return result
        
    except Exception:
        logger.detail("单候选自动升级失败（已忽略）", exc_info=True)
        return result


@dataclass
class CandidateShim:
    tmdb_id: int
    media_type: str
    title: str
    year: Optional[int] = None
    rating: Optional[float] = None
    vote_count: Optional[int] = None
    score: Optional[float] = None
    extra: Dict[str, Any] | None = None



async def decide_best_candidate(
    *,
    cands_all: List[Dict[str, Any]],
    q_title: str,
    q_year: Optional[int],
    used_title: str,
    used_year: Optional[int],
    used_mt: str,
    used_season: Optional[int],
    force_mt: Optional[str],
    has_main_hint: bool,
    selected_hints_count: int,
    evidence_level: int = 2,
    evidence_level_desc: Optional[str] = None,
    # group/batch evidence signals (optional)
    standard_rate: float = 0.0,
    episode_set: Optional[List[int]] = None,
    episode_best_files: Optional[List[Dict[str, Any]]] = None,
    episode_dup_count: int = 0,
    count_mismatch: bool = False,
) -> Dict[str, Any]:
    """Return a decision result.

    Output keys:
      - ok_pick: bool (auto pick possible)
      - picked: dict|None
      - auto_strength: 'strong'|'weak' (UX risk gate)
      - cands_all: possibly updated (detail re-score)
      - auto_gap/auto_score/auto_cov
    """

    if not isinstance(cands_all, list) or not cands_all:
        return {
            "ok_pick": False,
            "picked": None,
            "auto_strength": "weak",
            "cands_all": cands_all,
            "auto_score": 0.0,
            "auto_cov": 0.0,
            "auto_gap": 0.0,
        }

    # Evidence quality gate (root-fix):
    # If we don't have any real video filenames (L1) or the share evidence
    # is temporarily unavailable (L0), we must *never* auto-pick, otherwise
    # the wrong mapping will be persisted and keep poisoning future resolves.
    # We still compute candidates for the UI.
    try:
        ev_level = int(evidence_level)
    except (ValueError, TypeError) as e:
        logger.detail(f"证据等级解析失败（使用默认值 2） - value={evidence_level}, 原因={type(e).__name__}")
        ev_level = 2

    force_mt = str(force_mt or "").strip().lower() or None

    def _mk_scored(cs: List[Dict[str, Any]]) -> List[Tuple[CandidateShim, float]]:
        out: List[Tuple[CandidateShim, float]] = []
        for d in cs:
            try:
                tid0 = int(d.get("tmdb_id") or 0)
            except (ValueError, TypeError) as e:
                logger.detail(f"TMDB ID 解析失败（跳过候选） - value={d.get('tmdb_id') if isinstance(d, dict) else None}, 原因={type(e).__name__}")
                continue
            if tid0 <= 0:
                continue
            mt0 = str(d.get("media_type") or "").strip().lower() or "movie"
            title0 = str(d.get("title") or "").strip() or str(d.get("name") or "").strip()
            y0 = d.get("year")
            try:
                y0 = int(y0) if y0 not in (None, "") else None
            except (ValueError, TypeError) as e:
                logger.detail(f"年份解析失败（视为无年份） - value={y0}, 原因={type(e).__name__}")
                y0 = None
            try:
                rating0 = float(d.get("rating") or 0.0)
            except (ValueError, TypeError) as e:
                logger.detail(f"评分解析失败（使用 0.0） - value={d.get('rating') if isinstance(d, dict) else None}, 原因={type(e).__name__}")
                rating0 = 0.0
            try:
                vc0 = int(d.get("vote_count") or 0)
            except (ValueError, TypeError) as e:
                logger.detail(f"投票数解析失败（使用 0） - value={d.get('vote_count') if isinstance(d, dict) else None}, 原因={type(e).__name__}")
                vc0 = 0

            extra0 = dict(d)
            extra0["_match"] = {"coverage": float(d.get("coverage") or 0.0)}
            try:
                sc0 = float(d.get("_fused_score") if d.get("_fused_score") is not None else (d.get("score") or 0.0))
            except (ValueError, TypeError) as e:
                logger.detail(f"分数解析失败（使用 0.0） - value={d.get('_fused_score') if isinstance(d, dict) else None}, 原因={type(e).__name__}")
                sc0 = 0.0

            out.append(
                (
                    CandidateShim(
                        tmdb_id=tid0,
                        media_type=mt0,
                        title=title0,
                        year=y0,
                        rating=rating0,
                        vote_count=vc0,
                        score=1.0,
                        extra=extra0,
                    ),
                    sc0,
                )
            )
        return out

    ctx = {
        "selected_hints_count": int(selected_hints_count or 0),
        "has_main_hint": bool(has_main_hint),
        "require_consensus": bool((selected_hints_count or 0) >= 2),
        "force_media_type": force_mt,
        "query_title": (q_title or used_title or "").strip(),
        "query_year": q_year,
        "standard_rate": float(standard_rate or 0.0),
        "episode_count": int(len(episode_set or []) if episode_set is not None else 0),
        "episode_best_count": int(len(episode_best_files or []) if episode_best_files is not None else 0),
        "episode_dup_count": int(episode_dup_count or 0),
        "count_mismatch": bool(count_mismatch),
    }

    ok_pick = tmdb().should_auto_pick(_mk_scored(cands_all), ctx=ctx)

    # ------------------------------------------------------------
    # Episode-aware fast-pass (group-level safety belt)
    # ------------------------------------------------------------
    if not ok_pick:
        ok_pick = _episode_aware_fastpass(
            cands_all=cands_all,
            used_season=used_season,
            ev_level=ev_level,
            count_mismatch=count_mismatch,
            standard_rate=standard_rate,
            episode_set=episode_set,
            episode_best_files=episode_best_files,
        )

    # q_year存在但top1.year缺失：只对top1拉一次detail回填，再重新跑autopick（避免 year=None 绕过）
    if ok_pick and q_year is not None and cands_all:
        try:
            top0 = cands_all[0]
            top0_y = safe_int(top0.get("year")) or _infer_year_from_title(str(top0.get("title") or ""))
            if top0_y is None:
                tid0 = int(top0.get("tmdb_id") or 0)
                mt0 = str(top0.get("media_type") or "").strip().lower() or None
                if tid0 > 0:
                    det = await tmdb_detail_safe(tid0, prefer_media_type=mt0, timeout=3.0)
                    if isinstance(det, dict) and det:
                        if det.get("year") not in (None, ""):
                            top0["year"] = det.get("year")
                        if det.get("title"):
                            top0["title"] = str(det.get("title")).strip()
                        ok_pick = tmdb().should_auto_pick(_mk_scored(cands_all), ctx=ctx)
        except Exception:
            logger.detail("Top1 详情补年份失败（已忽略）", exc_info=True)


    # If top-2 are close, fetch details and re-score with our best evidence title.
    if q_title and len(cands_all) >= 2:
        try:
            bs = float(cands_all[0].get("score") or 0.0)
            ss = float(cands_all[1].get("score") or 0.0)
            gap = bs - ss
            if bs >= DECIDE_RESCORE_MIN_SCORE and gap < DECIDE_RESCORE_MAX_GAP and _get_coverage(cands_all[0]) >= DECIDE_RESCORE_MIN_COVERAGE:
                for i in (0, 1, 2):
                    if i >= len(cands_all):
                        continue
                    d0 = cands_all[i]
                    tid0 = int(d0.get("tmdb_id") or 0)
                    mt0 = str(d0.get("media_type") or "").strip().lower() or None
                    if tid0 <= 0:
                        continue
                    det = await tmdb_detail_safe(tid0, prefer_media_type=mt0, timeout=3.0)
                    if not det:
                        continue
                    cand0 = CandidateShim(
                        tmdb_id=tid0,
                        media_type=str(det.get("media_type") or (mt0 or "movie")),
                        title=str(det.get("title") or "").strip(),
                        year=det.get("year"),
                        rating=float(det.get("rating") or 0.0),
                        vote_count=int(det.get("vote_count") or 0),
                        score=1.0,
                        extra=det,
                    )
                    ns, nc, _ = tmdb().score_candidate_meta(q_title, q_year, cand0)
                    d0["score"] = round(max(float(d0.get("score") or 0.0), float(ns)), 3)
                    d0["coverage"] = round(max(float(d0.get("coverage") or 0.0), float(nc)), 3)
                    d0["_details_checked"] = True
                cands_all = sorted(
                    cands_all,
                    key=lambda x: float(x.get("_fused_score") if x.get("_fused_score") is not None else x.get("score") or 0),
                    reverse=True,
                )
                ok_pick = tmdb().should_auto_pick(_mk_scored(cands_all), ctx=ctx)
        except Exception:
            logger.detail("详情重评分失败（已忽略）", exc_info=True)

    picked: Optional[Dict[str, Any]] = None
    if ok_pick and cands_all:
        best_c = cands_all[0]
        picked = {k: best_c.get(k) for k in ("tmdb_id", "title", "year", "media_type", "score", "coverage", "rating", "vote_count", "gap")}

    if not picked or not picked.get("tmdb_id"):
        return {
            "ok_pick": False,
            "picked": None,
            "auto_strength": "weak",
            "cands_all": cands_all,
            "auto_score": 0.0,
            "auto_cov": 0.0,
            "auto_gap": 0.0,
        }

    # Decide whether to persist a strong or weak share->tmdb binding (UX gate).
    auto_score = float(picked.get("score") or 0.0)
    auto_cov = float(picked.get("coverage") or 0.0) if picked.get("coverage") is not None else 0.0
    auto_gap = float(picked.get("gap") or 0.0)
    auto_year = safe_int(picked.get("year")) or _infer_year_from_title(str(picked.get("title") or ""))

    auto_strength = "strong" if ok_pick else "weak"

    if auto_gap <= 0.0 and len(cands_all) > 1:
        auto_gap = float(cands_all[0].get("score") or 0.0) - float(cands_all[1].get("score") or 0.0)

    if ok_pick:
        if len(cands_all) <= 1:
            auto_strength = "weak"
        # q_year存在但候选year缺失：默认weak（必须让用户确认）
        if q_year is not None and auto_year is None:
            auto_strength = "weak"
        if q_year is not None and auto_year is not None and abs(int(auto_year) - int(q_year)) >= DECIDE_STRENGTH_MAX_YEAR_DIFF:
            auto_strength = "weak"
        if force_mt == "tv" and str(picked.get("media_type") or "").strip().lower() == "movie":
            auto_strength = "weak"
        if len(cands_all) >= DECIDE_STRENGTH_MANY_CANDIDATES and auto_gap < DECIDE_STRENGTH_MANY_CANDIDATES_MIN_GAP:
            auto_strength = "weak"
        q_eff = str((q_title or used_title or "")).strip()
        if len(q_eff) <= DECIDE_STRENGTH_SHORT_TITLE_MAX_LEN:
            auto_strength = "weak"

    # Conservative single-candidate auto-upgrade (accuracy-first)
    if auto_strength == "weak" and len(cands_all) == 1 and has_main_hint:
        upgrade_result = await _single_candidate_auto_upgrade(
            picked=picked,
            cands_all=cands_all,
            q_title=q_title,
            used_title=used_title,
            q_year=q_year,
            force_mt=force_mt,
            has_main_hint=has_main_hint,
            current_score=auto_score,
            current_cov=auto_cov,
            current_gap=auto_gap,
        )
        auto_score = upgrade_result.auto_score
        auto_cov = upgrade_result.auto_cov
        auto_gap = upgrade_result.auto_gap
        if upgrade_result.upgraded:
            auto_strength = "strong"

    # --- evidence gating ---
    # When 115 evidence is weak (no real video filename samples), we must not
    # auto-pick nor persist any weak binding. This prevents "stuck" wrong
    # mappings for generic titles / alias collisions.
    gated = False
    try:
        ev_lv = int(evidence_level or 0)
    except (ValueError, TypeError) as e:
        logger.detail(f"证据等级解析失败（使用默认值 2） - value={evidence_level}, 原因={type(e).__name__}")
        ev_lv = 2
    if ev_lv <= DECIDE_EVIDENCE_GATE_LEVEL:
        gated = True
        ok_pick = False
        picked = None
        auto_strength = "weak"
        auto_score = 0.0
        auto_cov = 0.0
        auto_gap = 0.0

    return {
        "ok_pick": bool(ok_pick),
        "picked": picked,
        "auto_strength": str(auto_strength or "weak"),
        "cands_all": cands_all,
        "auto_score": float(auto_score),
        "auto_cov": float(auto_cov),
        "auto_gap": float(auto_gap),
        "gated": bool(gated),
        "evidence_level": int(ev_lv),
        "evidence_level_desc": str(evidence_level_desc or "") if gated else str(evidence_level_desc or ""),
    }
