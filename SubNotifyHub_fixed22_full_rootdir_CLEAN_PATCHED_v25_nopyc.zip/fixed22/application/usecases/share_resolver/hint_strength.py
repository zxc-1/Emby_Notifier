"""Hint strength detection module.

This module provides enhanced hint quality assessment:
- Fast hint strength detection (Requirement 19.1, 19.2, 19.4)
- Technical tag detection (Requirement 19.5)
- Evidence level adjustment based on hint quality

Extracted for better maintainability and testability.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple

from core.logging import get_biz_logger_adapter

logger = get_biz_logger_adapter(__name__)


# =============================================================================
# Constants
# =============================================================================

# Technical tags that indicate weak hints
TECHNICAL_TAGS = {
    # Video quality
    '1080p', '720p', '2160p', '4k', 'uhd', 'hd', 'sd',
    # Video codecs
    'x264', 'x265', 'h264', 'h265', 'h.264', 'h.265', 'hevc', 'avc',
    'xvid', 'divx', 'mpeg', 'mpeg2', 'mpeg4',
    # Audio codecs
    'aac', 'ac3', 'dts', 'flac', 'truehd', 'atmos', 'dd5.1', 'dd7.1',
    # Source types
    'webrip', 'web-dl', 'webdl', 'bluray', 'bdrip', 'brrip', 'dvdrip',
    'hdtv', 'hdrip', 'remux', 'encode',
    # HDR formats
    'hdr', 'hdr10', 'hdr10+', 'dolby vision', 'dv', 'hlg',
    # Disc formats
    'bdmv', 'stream', 'playlist', 'iso', 'disc',
    # Release groups (common patterns)
    'proper', 'repack', 'internal', 'extended', 'unrated', 'directors cut',
}

# Patterns that indicate technical-only content
TECHNICAL_ONLY_PATTERNS = [
    # Pure resolution
    r'^(1080p|720p|2160p|4k)$',
    # Resolution + codec
    r'^(1080p|720p|2160p|4k)[.\-_]?(x264|x265|hevc|h\.?264|h\.?265)$',
    # Source + resolution
    r'^(webrip|bluray|hdtv)[.\-_]?(1080p|720p|2160p)$',
    # Codec only
    r'^(x264|x265|hevc|h\.?264|h\.?265)$',
    # BDMV patterns
    r'^(bdmv|stream|playlist)$',
]

# Minimum CJK title length for strong hint
MIN_CJK_TITLE_LENGTH = 4

# Minimum Latin title length for strong hint
MIN_LATIN_TITLE_LENGTH = 6


# =============================================================================
# Technical Tag Detection (Requirement 19.5)
# =============================================================================

def detect_technical_tags(text: str) -> Dict[str, Any]:
    """Detect technical tags in text (Requirement 19.5).
    
    Args:
        text: Text to analyze
    
    Returns:
        Dict with:
        - has_technical_tags: True if technical tags found
        - matched_tags: List of matched technical tags
        - tag_count: Number of technical tags found
    """
    if not text:
        return {
            "has_technical_tags": False,
            "matched_tags": [],
            "tag_count": 0,
        }
    
    text_lower = text.lower()
    matched_tags = []
    
    # Check for technical tags
    for tag in TECHNICAL_TAGS:
        # Use word boundary matching
        pattern = r'\b' + re.escape(tag) + r'\b'
        if re.search(pattern, text_lower, re.IGNORECASE):
            matched_tags.append(tag)
    
    return {
        "has_technical_tags": len(matched_tags) > 0,
        "matched_tags": matched_tags,
        "tag_count": len(matched_tags),
    }


def contains_only_technical_tags(text: str) -> bool:
    """Check if text contains only technical tags (Requirement 19.5).
    
    Args:
        text: Text to check
    
    Returns:
        True if text contains only technical tags without meaningful title
    """
    if not text:
        return True
    
    text_clean = text.strip()
    text_lower = text_clean.lower()
    
    # Check against technical-only patterns
    for pattern in TECHNICAL_ONLY_PATTERNS:
        if re.fullmatch(pattern, text_lower, re.IGNORECASE):
            return True
    
    # Remove all technical tags and see what's left
    remaining = text_clean
    for tag in TECHNICAL_TAGS:
        pattern = r'\b' + re.escape(tag) + r'\b'
        remaining = re.sub(pattern, '', remaining, flags=re.IGNORECASE)
    
    # Remove common separators
    remaining = re.sub(r'[.\-_\[\]\(\)\s]+', ' ', remaining).strip()
    
    # If nothing meaningful remains, it's technical-only
    if not remaining:
        return True
    
    # If only numbers remain, it's technical-only
    if re.fullmatch(r'\d+', remaining):
        return True
    
    return False


# =============================================================================
# CJK Detection
# =============================================================================

def has_cjk_characters(text: str) -> bool:
    """Check if text contains CJK characters.
    
    Args:
        text: Text to check
    
    Returns:
        True if text contains CJK characters
    """
    if not text:
        return False
    
    return bool(re.search(r'[\u4e00-\u9fff]', text))


def count_cjk_characters(text: str) -> int:
    """Count CJK characters in text.
    
    Args:
        text: Text to count
    
    Returns:
        Number of CJK characters
    """
    if not text:
        return 0
    
    return len(re.findall(r'[\u4e00-\u9fff]', text))


# =============================================================================
# Fast Hint Strength Detection (Requirement 19.1, 19.2, 19.4)
# =============================================================================

def evaluate_hint_strength(
    title: str,
    has_fallback: bool = False,
) -> Dict[str, Any]:
    """Evaluate hint strength (Requirement 19.1, 19.2, 19.4).
    
    A strong hint has:
    - CJK title >= 4 chars, OR
    - Latin title >= 6 chars with no technical tags
    - No technical-only content
    
    Args:
        title: Title to evaluate
        has_fallback: True if this is a fallback hint
    
    Returns:
        Dict with:
        - is_strong: True if hint is strong
        - strength_score: Numeric strength score (0.0-1.0)
        - reason: Reason for strength assessment
        - has_cjk: True if title has CJK characters
        - cjk_count: Number of CJK characters
        - technical_info: Technical tag detection info
    """
    if not title:
        return {
            "is_strong": False,
            "strength_score": 0.0,
            "reason": "empty_title",
            "has_cjk": False,
            "cjk_count": 0,
            "technical_info": detect_technical_tags(""),
        }
    
    title_clean = title.strip()
    
    # Check for technical-only content
    if contains_only_technical_tags(title_clean):
        return {
            "is_strong": False,
            "strength_score": 0.1,
            "reason": "technical_only",
            "has_cjk": has_cjk_characters(title_clean),
            "cjk_count": count_cjk_characters(title_clean),
            "technical_info": detect_technical_tags(title_clean),
        }
    
    # Check for CJK content
    has_cjk = has_cjk_characters(title_clean)
    cjk_count = count_cjk_characters(title_clean)
    technical_info = detect_technical_tags(title_clean)
    
    # CJK title evaluation
    if has_cjk:
        if cjk_count >= MIN_CJK_TITLE_LENGTH:
            # Strong CJK title
            strength_score = min(1.0, 0.7 + (cjk_count - MIN_CJK_TITLE_LENGTH) * 0.05)
            return {
                "is_strong": True,
                "strength_score": strength_score,
                "reason": "strong_cjk_title",
                "has_cjk": True,
                "cjk_count": cjk_count,
                "technical_info": technical_info,
            }
        else:
            # Short CJK title - weak
            return {
                "is_strong": False,
                "strength_score": 0.3 + cjk_count * 0.1,
                "reason": "short_cjk_title",
                "has_cjk": True,
                "cjk_count": cjk_count,
                "technical_info": technical_info,
            }
    
    # Latin title evaluation
    # Remove technical tags for length calculation
    title_without_tags = title_clean
    for tag in technical_info.get("matched_tags", []):
        pattern = r'\b' + re.escape(tag) + r'\b'
        title_without_tags = re.sub(pattern, '', title_without_tags, flags=re.IGNORECASE)
    title_without_tags = ' '.join(title_without_tags.split()).strip()
    
    if len(title_without_tags) >= MIN_LATIN_TITLE_LENGTH:
        # Check if too many technical tags
        if technical_info.get("tag_count", 0) > 2:
            return {
                "is_strong": False,
                "strength_score": 0.4,
                "reason": "too_many_technical_tags",
                "has_cjk": False,
                "cjk_count": 0,
                "technical_info": technical_info,
            }
        
        # Strong Latin title
        strength_score = min(1.0, 0.6 + (len(title_without_tags) - MIN_LATIN_TITLE_LENGTH) * 0.02)
        return {
            "is_strong": True,
            "strength_score": strength_score,
            "reason": "strong_latin_title",
            "has_cjk": False,
            "cjk_count": 0,
            "technical_info": technical_info,
        }
    
    # Short Latin title - weak
    return {
        "is_strong": False,
        "strength_score": 0.2 + len(title_without_tags) * 0.03,
        "reason": "short_latin_title",
        "has_cjk": False,
        "cjk_count": 0,
        "technical_info": technical_info,
    }


def is_fast_hint_strong(hint_data: Dict[str, Any]) -> bool:
    """Check if fast hint is strong enough (Requirement 19.1, 19.2).
    
    Enhanced version of _fast_hint_strong() with better technical tag detection.
    
    Args:
        hint_data: Hint data dict with share_title, hint_name, filename, etc.
    
    Returns:
        True if hint is strong enough for TMDB search
    """
    if not isinstance(hint_data, dict):
        return False
    
    if not hint_data.get("ok"):
        return False
    
    # If not fallback, fast is already accurate
    if not hint_data.get("fallback"):
        return True
    
    # Get title from various sources
    title = (
        hint_data.get("share_title") or
        hint_data.get("hint_name") or
        hint_data.get("filename") or
        ""
    )
    
    if not title:
        return False
    
    # Evaluate hint strength
    strength_info = evaluate_hint_strength(str(title).strip())
    
    return strength_info.get("is_strong", False)


def compute_evidence_level_from_hint_strength(
    hint_strength: Dict[str, Any],
    base_evidence_level: int,
) -> int:
    """Adjust evidence level based on hint strength (Requirement 19.5).
    
    When hint contains only technical tags without meaningful title,
    evidence level should be set to L1.
    
    Args:
        hint_strength: Result from evaluate_hint_strength()
        base_evidence_level: Base evidence level (0-3)
    
    Returns:
        Adjusted evidence level
    """
    if not hint_strength.get("is_strong", False):
        reason = hint_strength.get("reason", "")
        
        # Technical-only content -> L1
        if reason == "technical_only":
            return min(base_evidence_level, 1)
        
        # Short title -> cap at L2
        if reason in ("short_cjk_title", "short_latin_title"):
            return min(base_evidence_level, 2)
        
        # Too many technical tags -> cap at L2
        if reason == "too_many_technical_tags":
            return min(base_evidence_level, 2)
    
    return base_evidence_level


# =============================================================================
# Utility Functions
# =============================================================================

def get_hint_strength_summary(
    title: str,
    has_fallback: bool = False,
) -> Dict[str, Any]:
    """Get comprehensive hint strength summary.
    
    Args:
        title: Title to evaluate
        has_fallback: True if this is a fallback hint
    
    Returns:
        Dict with all hint strength information
    """
    strength_info = evaluate_hint_strength(title, has_fallback)
    
    return {
        **strength_info,
        "title": title,
        "has_fallback": has_fallback,
        "recommended_action": (
            "proceed" if strength_info.get("is_strong", False)
            else "fetch_full_evidence"
        ),
    }
