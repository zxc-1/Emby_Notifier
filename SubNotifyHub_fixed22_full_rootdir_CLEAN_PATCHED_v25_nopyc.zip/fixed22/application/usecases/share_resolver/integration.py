"""Integration module for TMDB recognition optimization.

.. deprecated:: 1.7.0
    This module is deprecated. Use `tmdb_lookup.py` directly instead.
    All functions from this module are re-exported from `tmdb_lookup.py`.

This module provides the main entry point for the optimized TMDB recognition
pipeline, integrating all new components:
- Evidence level management
- Stage strategy optimization
- Alias matching
- Episode scoring
- Consensus scoring
- Auto-pick decision
- Cache validation
- Retry mechanism
- Observability

Requirement Coverage: All requirements (1-20)
"""

from __future__ import annotations

import warnings

# Emit deprecation warning on import
warnings.warn(
    "integration.py is deprecated. Use tmdb_lookup.py directly instead.",
    DeprecationWarning,
    stacklevel=2,
)

import asyncio
import re
from typing import Any, Dict, List, Optional, Tuple

from core.logging import get_biz_logger_adapter

# Re-export from tmdb_lookup.py for backward compatibility
from .tmdb_lookup import (
    pre_resolve_from_names_and_caches,
    build_candidate_sets,
)

from .observability import (
    DecisionTrace,
    build_debug_response,
    log_stage_completion,
    log_auto_pick_blocked,
    log_score_adjustment,
)
from .evidence_level import (
    compute_evidence_level,
    detect_count_mismatch,
    should_block_autopick_by_evidence,
)
from .stage_strategy import (
    check_stage_a_stability,
    normalize_hint_query_key,
    detect_bilingual_evidence,
    apply_year_affinity,
)
from .alias_matching import (
    compute_alias_similarity,
    weight_cjk_share_title,
    has_cjk_text,
)
from .episode_scoring import (
    compute_episode_score,
    should_boost_by_episode_score,
)
from .consensus_scoring import (
    compute_support_weight,
    apply_support_bonus,
)
from .autopick import (
    should_auto_pick_enhanced,
    AutoPickContext,
    AutoPickResult,
)
from .cache_validation import (
    validate_title_cache_hit,
    validate_series_cache_hit,
    should_disable_bad_mapping,
)
from .retry import (
    with_retry,
    is_temporary_unavailable,
    log_api_error,
    TMDBAPIError,
    TMDBTimeoutError,
    TMDBUnavailableError,
)
from .scoring import compute_collision_risk

logger = get_biz_logger_adapter(__name__)


# =============================================================================
# Content Detection Functions (Requirement 11)
# =============================================================================

def detect_multi_season_markers(
    share_title: str,
    filename: str,
    video_samples: List[str],
) -> Dict[str, Any]:
    """Detect multi-season markers in content (Requirement 11.1, 11.3).
    
    Args:
        share_title: Share title
        filename: Main filename
        video_samples: List of video sample filenames
    
    Returns:
        Dict with is_multi_season, seasons, preferred_season
    """
    # Pattern for season ranges like S01-S05, S1-S3
    range_pattern = re.compile(r'S(\d{1,2})\s*[-–]\s*S?(\d{1,2})', re.IGNORECASE)
    # Pattern for individual seasons

    _AUDIO_SEASON_GUARD_RE = re.compile(r"(?i)(?:DTS|DDP|EAC3|AC3|AAC)\s*(?:\d\.\d)")
    # 重要：避免把音轨标记误判成季号，如 DTS5.1 / DDP5.1 / AAC2.0
    # 规则：S 必须是独立 token（前面不是字母/数字），后面允许 E
    season_pattern = re.compile(r'(?i)(?<![A-Z0-9])S(\d{1,2})(?:\s*E\d{1,3})?(?!\d)')
    
    seasons_found = set()
    
    # Check share title
    range_match = range_pattern.search(share_title)
    if range_match:
        start, end = int(range_match.group(1)), int(range_match.group(2))
        seasons_found.update(range(start, end + 1))
    
    # Check filename
    range_match = range_pattern.search(filename)
    if range_match:
        start, end = int(range_match.group(1)), int(range_match.group(2))
        seasons_found.update(range(start, end + 1))
    
    # Check video samples for different seasons
    for sample in video_samples:
        sample2 = _AUDIO_SEASON_GUARD_RE.sub('', str(sample or ''))
        match = season_pattern.search(sample2)
        if match:
            seasons_found.add(int(match.group(1)))
    
    is_multi_season = len(seasons_found) > 1
    preferred_season = min(seasons_found) if seasons_found else None
    
    return {
        "is_multi_season": is_multi_season,
        "seasons": sorted(seasons_found),
        "preferred_season": preferred_season,
    }


def detect_mixed_content(
    share_title: str,
    filename: str,
    video_samples: List[str],
) -> Dict[str, Any]:
    """Detect mixed content (movie + TV) (Requirement 11.2).
    
    Args:
        share_title: Share title
        filename: Main filename
        video_samples: List of video sample filenames
    
    Returns:
        Dict with is_mixed, has_movie_markers, has_tv_markers
    """
    # TV markers
    tv_pattern = re.compile(r'S\d{1,2}E\d{1,2}|Season\s*\d+|第.{1,2}季', re.IGNORECASE)
    # Movie markers (year in parentheses, common movie patterns)
    movie_pattern = re.compile(r'\(\d{4}\)|\.(?:1080p|720p|2160p)\..*?(?:BluRay|WEB|HDTV)', re.IGNORECASE)
    
    has_tv = False
    has_movie = False
    
    all_text = f"{share_title} {filename} " + " ".join(video_samples)
    
    if tv_pattern.search(all_text):
        has_tv = True
    
    # Check for movie-like files without episode markers
    for sample in video_samples:
        if movie_pattern.search(sample) and not tv_pattern.search(sample):
            has_movie = True
            break
    
    return {
        "is_mixed": has_tv and has_movie,
        "has_movie_markers": has_movie,
        "has_tv_markers": has_tv,
    }


def detect_part_markers(
    share_title: str,
    filename: str,
) -> Dict[str, Any]:
    """Detect Part 1/2/3 markers (Requirement 11.4).
    
    Args:
        share_title: Share title
        filename: Main filename
    
    Returns:
        Dict with is_part_movie, part_number
    """
    # Part patterns
    part_pattern = re.compile(
        r'Part\s*(\d+)|第([一二三四五六七八九十\d]+)部|Vol(?:ume)?\.?\s*(\d+)',
        re.IGNORECASE
    )
    
    all_text = f"{share_title} {filename}"
    match = part_pattern.search(all_text)
    
    if match:
        # Extract part number
        part_num = match.group(1) or match.group(2) or match.group(3)
        # Convert Chinese numbers
        cn_nums = {'一': 1, '二': 2, '三': 3, '四': 4, '五': 5,
                   '六': 6, '七': 7, '八': 8, '九': 9, '十': 10}
        if part_num in cn_nums:
            part_num = cn_nums[part_num]
        else:
            try:
                part_num = int(part_num)
            except (ValueError, TypeError):
                part_num = None
        
        return {
            "is_part_movie": True,
            "part_number": part_num,
        }
    
    return {
        "is_part_movie": False,
        "part_number": None,
    }


# =============================================================================
# Main Integration Function
# =============================================================================

async def resolve_share_to_tmdb_optimized(
    *,
    share_code: str,
    receive_code: str,
    hint_pack: Dict[str, Any],
    cached_strong: Optional[Dict[str, Any]] = None,
    cached_weak: Optional[Dict[str, Any]] = None,
    file_sig: Optional[str] = None,
    debug_mode: bool = False,
) -> Dict[str, Any]:
    """Optimized TMDB resolution with all new components integrated.
    
    This is the main entry point for the optimized recognition pipeline.
    
    Args:
        share_code: 115 share code
        receive_code: 115 receive code (password)
        hint_pack: Hint pack from build_hint_pack()
        cached_strong: Strong cached mapping (if any)
        cached_weak: Weak cached mapping (if any)
        file_sig: File signature for cache validation
        debug_mode: If True, return full debug response
    
    Returns:
        Resolution result with tmdb_id, media_type, decision_trace, etc.
    """
    trace = DecisionTrace()
    trace.append("start:optimized")
    
    # Extract hint pack fields
    hints_main = hint_pack.get("hints_main", [])
    hints_msg = hint_pack.get("hints_msg", [])
    hints_extra = hint_pack.get("hints_extra", [])
    hints2 = hint_pack.get("hints2", [])
    q_title = hint_pack.get("q_title", "")
    q_year = hint_pack.get("q_year")
    tvish = hint_pack.get("tvish", False)
    season_hint_eff = hint_pack.get("season_hint_eff")
    share_title = hint_pack.get("share_title", "")
    filename = hint_pack.get("filename", "")
    standard_rate = hint_pack.get("standard_rate", 0.0)
    episode_set = hint_pack.get("episode_set", [])
    video_count = hint_pack.get("video_count", 0)
    count_mismatch = hint_pack.get("count_mismatch", False)
    video_samples = hint_pack.get("video_samples", [])
    
    # Stage 1: Evidence Level Computation
    stage = trace.start_stage("evidence_level")
    
    has_video_samples = bool(video_samples)
    video_sample_count = len(video_samples)
    has_episode_pattern = standard_rate >= 0.5 and len(episode_set) >= 2
    
    evidence_level, evidence_desc = compute_evidence_level(
        has_video_samples=has_video_samples,
        video_sample_count=video_sample_count,
        standard_rate=standard_rate,
        has_episode_pattern=has_episode_pattern,
        count_mismatch=count_mismatch,
    )
    
    trace.complete_stage(
        evidence_level=evidence_level,
        evidence_desc=evidence_desc,
        count_mismatch=count_mismatch,
    )
    
    # Stage 2: Multi-season/Part Detection
    stage = trace.start_stage("content_detection")
    
    multi_season_info = detect_multi_season_markers(
        share_title=share_title,
        filename=filename,
        video_samples=video_samples,
    )
    is_multi_season = multi_season_info.get("is_multi_season", False)
    preferred_season = multi_season_info.get("preferred_season")
    
    mixed_content = detect_mixed_content(
        share_title=share_title,
        filename=filename,
        video_samples=video_samples,
    )
    is_mixed = mixed_content.get("is_mixed", False)
    
    part_info = detect_part_markers(share_title, filename)
    is_part_movie = part_info.get("is_part_movie", False)
    
    trace.complete_stage(
        is_multi_season=is_multi_season,
        preferred_season=preferred_season,
        is_mixed=is_mixed,
        is_part_movie=is_part_movie,
    )
    
    # Stage 3: Collision Risk Detection
    stage = trace.start_stage("collision_risk")
    
    collision_result = compute_collision_risk(q_title)
    collision_risky = collision_result.get("collision_risky", False)
    collision_words = collision_result.get("matched_words", [])
    
    trace.complete_stage(
        collision_risky=collision_risky,
        collision_words=collision_words,
    )
    
    # Stage 4: Bilingual Evidence Detection
    stage = trace.start_stage("bilingual_detection")
    
    bilingual_result = detect_bilingual_evidence(
        hints_main=hints_main,
        hints_msg=hints_msg,
        share_title=share_title,
    )
    bilingual_evidence = bilingual_result.get("has_bilingual", False)
    
    trace.complete_stage(bilingual_evidence=bilingual_evidence)
    
    # Build context for auto-pick decision
    context = AutoPickContext(
        evidence_level=evidence_level,
        selected_hints_count=len(hints_main) + len(hints_msg),
        has_main_hint=len(hints_main) > 0,
        support_count=len(hints_main) + len(hints_msg),
        support_main=len(hints_main),
        support_weight=len(hints_main) * 2 + len(hints_msg),
        standard_rate=standard_rate,
        episode_count=len(episode_set),
        episode_score=0.0,  # Will be computed later in full pipeline
        count_mismatch=count_mismatch,
        query_title=q_title,
        query_year=q_year,
        force_media_type=None,
        video_samples=video_samples,
    )
    
    # Return integration result
    result = {
        "ok": True,
        "share_code": share_code,
        "evidence_level": evidence_level,
        "evidence_desc": evidence_desc,
        "collision_risky": collision_risky,
        "bilingual_evidence": bilingual_evidence,
        "is_multi_season": is_multi_season,
        "is_mixed_content": is_mixed,
        "is_part_movie": is_part_movie,
        "context": context.to_dict(),
        "decision_trace": trace.to_list(),
    }
    
    if debug_mode:
        result["debug"] = build_debug_response(
            cands_all=[],
            decision_trace=trace,
            hint_pack=hint_pack,
        )
    
    return result
