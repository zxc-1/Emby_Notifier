"""Cache validation for TMDB recognition.

This module contains functions for:
- Validating title cache hits (Requirement 8.1)
- Validating series cache hits (Requirement 8.2)
- Disabling bad cache mappings (Requirement 8.3)
- Media type consistency checks (Requirement 8.5)

Extracted for better maintainability and testability.
"""

from __future__ import annotations

from typing import Any, Dict, Optional, Tuple

from core.logging import get_biz_logger_adapter

from .constants import (
    TITLE_CACHE_MIN_CONFIDENCE,
    TITLE_CACHE_MIN_COVERAGE,
    SERIES_CACHE_MIN_CONFIDENCE,
    SERIES_CACHE_MAX_YEAR_DIFF,
    CACHE_VALIDATION_MIN_SCORE,
)

logger = get_biz_logger_adapter(__name__)


def validate_title_cache_hit(
    confidence: float,
    coverage: float,
    query_year: Optional[int] = None,
    cached_year: Optional[int] = None,
) -> Tuple[bool, Optional[str]]:
    """Validate title cache hit (Requirement 8.1).
    
    Title cache hit is valid when:
    - confidence >= 0.82
    - coverage >= 0.60
    
    Args:
        confidence: Match confidence score
        coverage: Coverage ratio
        query_year: Year from query (optional)
        cached_year: Year from cached mapping (optional)
    
    Returns:
        Tuple of (is_valid, rejection_reason)
    """
    if confidence < TITLE_CACHE_MIN_CONFIDENCE:
        return False, f"confidence_too_low:{confidence:.3f}<{TITLE_CACHE_MIN_CONFIDENCE}"
    
    if coverage < TITLE_CACHE_MIN_COVERAGE:
        return False, f"coverage_too_low:{coverage:.3f}<{TITLE_CACHE_MIN_COVERAGE}"
    
    # Optional year check
    if query_year is not None and cached_year is not None:
        year_diff = abs(int(query_year) - int(cached_year))
        if year_diff > SERIES_CACHE_MAX_YEAR_DIFF:
            return False, f"year_mismatch:{year_diff}>{SERIES_CACHE_MAX_YEAR_DIFF}"
    
    return True, None


def validate_series_cache_hit(
    confidence: float,
    query_year: Optional[int] = None,
    cached_year: Optional[int] = None,
) -> Tuple[bool, Optional[str]]:
    """Validate series cache hit (Requirement 8.2).
    
    Series cache hit is valid when:
    - confidence >= 0.80
    - year matches within 2 years (if both provided)
    
    Args:
        confidence: Match confidence score
        query_year: Year from query (optional)
        cached_year: Year from cached mapping (optional)
    
    Returns:
        Tuple of (is_valid, rejection_reason)
    """
    if confidence < SERIES_CACHE_MIN_CONFIDENCE:
        return False, f"confidence_too_low:{confidence:.3f}<{SERIES_CACHE_MIN_CONFIDENCE}"
    
    # Year check is required for series cache
    if query_year is not None and cached_year is not None:
        year_diff = abs(int(query_year) - int(cached_year))
        if year_diff > SERIES_CACHE_MAX_YEAR_DIFF:
            return False, f"year_mismatch:{year_diff}>{SERIES_CACHE_MAX_YEAR_DIFF}"
    
    return True, None


def should_disable_bad_mapping(
    validation_score: float,
) -> bool:
    """Check if a cached mapping should be disabled (Requirement 8.3).
    
    When cached mapping validation fails (score < 0.72), the mapping
    should be disabled to prevent repeated mis-binds.
    
    Args:
        validation_score: Score from validating cached mapping against current evidence
    
    Returns:
        True if mapping should be disabled
    """
    return validation_score < CACHE_VALIDATION_MIN_SCORE


def check_media_type_consistency(
    evidence_media_type: Optional[str],
    cached_media_type: Optional[str],
    strong_tv_evidence: bool = False,
) -> Tuple[bool, Optional[str]]:
    """Check media type consistency (Requirement 8.5).
    
    When strong TV evidence exists AND cached mapping points to movie,
    the cached mapping should be rejected.
    
    Args:
        evidence_media_type: Media type from evidence (e.g., "tv", "movie")
        cached_media_type: Media type from cached mapping
        strong_tv_evidence: True if evidence strongly indicates TV
    
    Returns:
        Tuple of (is_consistent, rejection_reason)
    """
    if not cached_media_type:
        return True, None
    
    cached_mt = str(cached_media_type).strip().lower()
    
    # Strong TV evidence should not accept movie mapping
    if strong_tv_evidence and cached_mt == "movie":
        return False, "strong_tv_evidence_rejects_movie"
    
    # If evidence specifies media type, check consistency
    if evidence_media_type:
        evidence_mt = str(evidence_media_type).strip().lower()
        if evidence_mt and cached_mt and evidence_mt != cached_mt:
            return False, f"media_type_mismatch:{evidence_mt}!={cached_mt}"
    
    return True, None


def validate_cache_hit(
    cache_type: str,
    confidence: float,
    coverage: float = 0.0,
    query_year: Optional[int] = None,
    cached_year: Optional[int] = None,
    evidence_media_type: Optional[str] = None,
    cached_media_type: Optional[str] = None,
    strong_tv_evidence: bool = False,
) -> Dict[str, Any]:
    """Comprehensive cache hit validation (Requirements 8.1-8.5).
    
    Args:
        cache_type: Type of cache ("title" or "series")
        confidence: Match confidence score
        coverage: Coverage ratio (for title cache)
        query_year: Year from query
        cached_year: Year from cached mapping
        evidence_media_type: Media type from evidence
        cached_media_type: Media type from cached mapping
        strong_tv_evidence: True if evidence strongly indicates TV
    
    Returns:
        Dict with:
        - is_valid: bool
        - rejection_reason: Optional[str]
        - should_disable: bool
        - validation_details: Dict with all checks
    """
    validation_details = {}
    rejection_reasons = []
    
    # Check confidence/coverage based on cache type
    if cache_type == "title":
        valid, reason = validate_title_cache_hit(
            confidence, coverage, query_year, cached_year
        )
        validation_details["title_check"] = {"valid": valid, "reason": reason}
        if not valid:
            rejection_reasons.append(reason)
    elif cache_type == "series":
        valid, reason = validate_series_cache_hit(
            confidence, query_year, cached_year
        )
        validation_details["series_check"] = {"valid": valid, "reason": reason}
        if not valid:
            rejection_reasons.append(reason)
    
    # Check media type consistency
    mt_valid, mt_reason = check_media_type_consistency(
        evidence_media_type, cached_media_type, strong_tv_evidence
    )
    validation_details["media_type_check"] = {"valid": mt_valid, "reason": mt_reason}
    if not mt_valid:
        rejection_reasons.append(mt_reason)
    
    # Determine if mapping should be disabled
    should_disable = should_disable_bad_mapping(confidence)
    validation_details["should_disable"] = should_disable
    
    is_valid = len(rejection_reasons) == 0
    
    return {
        "is_valid": is_valid,
        "rejection_reason": rejection_reasons[0] if rejection_reasons else None,
        "all_rejection_reasons": rejection_reasons,
        "should_disable": should_disable and not is_valid,
        "validation_details": validation_details,
    }


def compute_cache_seed_score(
    base_score: float,
    is_explicit_id: bool = False,
    has_query_title: bool = True,
) -> float:
    """Compute score for cache seed candidate (Requirement 8.4).
    
    Cached mappings are treated as seed candidates competing with search results.
    
    Args:
        base_score: Base confidence score
        is_explicit_id: True if from explicit TMDB ID in filename
        has_query_title: True if we have a query title to compare
    
    Returns:
        Adjusted score for seed candidate
    """
    if not has_query_title:
        # No title to compare - use default scores
        return 0.95 if is_explicit_id else 0.85
    
    # Use actual score when we have a title
    return base_score
