"""Episode deduplication module.

This module provides enhanced episode deduplication:
- Best quality version selection (Requirement 20.1, 20.2)
- Episode coverage tracking (Requirement 20.4)
- Deduplication statistics (Requirement 20.3)

Builds on batch_group.py with additional functionality.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Set, Tuple

from core.logging import get_biz_logger_adapter

from .batch_group import (
    EpisodeFile,
    dedup_by_episode,
    extract_season_episode,
    quality_score,
)

logger = get_biz_logger_adapter(__name__)


# =============================================================================
# Constants
# =============================================================================

# Minimum coverage ratio to maintain confidence (Requirement 20.4)
MIN_COVERAGE_RATIO = 0.75


# =============================================================================
# Data Classes
# =============================================================================

@dataclass
class DedupResult:
    """Result of episode deduplication."""
    best_files: Dict[int, EpisodeFile]
    duplicates: List[EpisodeFile]
    episode_set: Set[int]
    dup_count: int
    total_files: int
    coverage_ratio: float
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary."""
        return {
            "best_files": {ep: {"name": f.name, "size": f.size} for ep, f in self.best_files.items()},
            "duplicates": [{"name": f.name, "size": f.size} for f in self.duplicates],
            "episode_set": sorted(self.episode_set),
            "dup_count": self.dup_count,
            "total_files": self.total_files,
            "coverage_ratio": self.coverage_ratio,
        }


@dataclass
class QualityInfo:
    """Quality information for a file."""
    name: str
    size: int
    quality_score: float
    episode: Optional[int]
    season: Optional[int]


# =============================================================================
# Enhanced Deduplication (Requirement 20.1, 20.2)
# =============================================================================

def dedup_episodes_enhanced(
    files: List[Dict[str, Any]],
    season_hint: Optional[int] = None,
) -> DedupResult:
    """Enhanced episode deduplication (Requirement 20.1, 20.2).
    
    Selects best quality version for each episode based on:
    1. Quality score (resolution, codec, HDR, source, audio)
    2. File size (larger = better quality)
    
    Args:
        files: List of file dicts with 'name' and 'size' keys
        season_hint: Expected season number (optional)
    
    Returns:
        DedupResult with best files and statistics
    """
    # Convert to EpisodeFile objects
    episode_files = []
    for f in files or []:
        if isinstance(f, dict):
            name = str(f.get("name") or f.get("filename") or "")
            size = int(f.get("size") or 0)
            episode_files.append(EpisodeFile(name=name, size=size))
        elif isinstance(f, EpisodeFile):
            episode_files.append(f)
    
    # Use existing dedup function
    best_map, duplicates = dedup_by_episode(episode_files, season_hint=season_hint)
    
    # Compute statistics
    episode_set = set(best_map.keys())
    dup_count = len(duplicates)
    total_files = len(episode_files)
    
    # Compute coverage ratio
    if total_files > 0:
        coverage_ratio = len(episode_set) / total_files
    else:
        coverage_ratio = 0.0
    
    return DedupResult(
        best_files=best_map,
        duplicates=duplicates,
        episode_set=episode_set,
        dup_count=dup_count,
        total_files=total_files,
        coverage_ratio=coverage_ratio,
    )


def select_best_quality_file(
    files: List[Dict[str, Any]],
) -> Optional[Dict[str, Any]]:
    """Select the best quality file from a list (Requirement 20.2).
    
    Uses quality score and file size to determine best file.
    
    Args:
        files: List of file dicts
    
    Returns:
        Best quality file dict or None
    """
    if not files:
        return None
    
    best = None
    best_score = (-1.0, -1)
    
    for f in files:
        if not isinstance(f, dict):
            continue
        
        name = str(f.get("name") or f.get("filename") or "")
        size = int(f.get("size") or 0)
        
        score = (quality_score(name), size)
        
        if score > best_score:
            best_score = score
            best = f
    
    return best


# =============================================================================
# Coverage Tracking (Requirement 20.4)
# =============================================================================

def compute_episode_coverage(
    best_files: Dict[int, EpisodeFile],
    expected_episodes: Set[int],
) -> Dict[str, Any]:
    """Compute episode coverage statistics (Requirement 20.4).
    
    Args:
        best_files: Best file per episode
        expected_episodes: Expected episode numbers
    
    Returns:
        Dict with coverage statistics
    """
    actual_episodes = set(best_files.keys())
    
    covered = actual_episodes & expected_episodes
    missing = expected_episodes - actual_episodes
    extra = actual_episodes - expected_episodes
    
    if expected_episodes:
        coverage_ratio = len(covered) / len(expected_episodes)
    else:
        coverage_ratio = 1.0 if not actual_episodes else 0.0
    
    return {
        "covered_episodes": sorted(covered),
        "missing_episodes": sorted(missing),
        "extra_episodes": sorted(extra),
        "coverage_ratio": coverage_ratio,
        "meets_threshold": coverage_ratio >= MIN_COVERAGE_RATIO,
    }


def should_maintain_confidence(
    dedup_result: DedupResult,
    expected_episode_count: int,
) -> bool:
    """Check if confidence should be maintained (Requirement 20.4).
    
    When episode_dup_count > 0 AND episode_best_files covers >= 75%
    of episode_set, confidence should be maintained.
    
    Args:
        dedup_result: Result from dedup_episodes_enhanced()
        expected_episode_count: Expected number of episodes
    
    Returns:
        True if confidence should be maintained
    """
    if dedup_result.dup_count == 0:
        # No duplicates, confidence maintained
        return True
    
    if expected_episode_count <= 0:
        return True
    
    actual_coverage = len(dedup_result.episode_set) / expected_episode_count
    
    return actual_coverage >= MIN_COVERAGE_RATIO


# =============================================================================
# Quality Analysis
# =============================================================================

def analyze_file_quality(
    files: List[Dict[str, Any]],
) -> List[QualityInfo]:
    """Analyze quality of all files.
    
    Args:
        files: List of file dicts
    
    Returns:
        List of QualityInfo sorted by quality (best first)
    """
    results = []
    
    for f in files or []:
        if not isinstance(f, dict):
            continue
        
        name = str(f.get("name") or f.get("filename") or "")
        size = int(f.get("size") or 0)
        season, episode = extract_season_episode(name)
        
        results.append(QualityInfo(
            name=name,
            size=size,
            quality_score=quality_score(name),
            episode=episode,
            season=season,
        ))
    
    # Sort by quality score and size (descending)
    results.sort(key=lambda x: (x.quality_score, x.size), reverse=True)
    
    return results


def get_dedup_summary(
    files: List[Dict[str, Any]],
    season_hint: Optional[int] = None,
    expected_episode_count: Optional[int] = None,
) -> Dict[str, Any]:
    """Get comprehensive deduplication summary.
    
    Args:
        files: List of file dicts
        season_hint: Expected season number
        expected_episode_count: Expected number of episodes
    
    Returns:
        Dict with all deduplication information
    """
    dedup_result = dedup_episodes_enhanced(files, season_hint=season_hint)
    
    # Compute coverage if expected count provided
    coverage_info = None
    if expected_episode_count is not None:
        expected_episodes = set(range(1, expected_episode_count + 1))
        coverage_info = compute_episode_coverage(
            dedup_result.best_files,
            expected_episodes,
        )
    
    # Check confidence maintenance
    maintain_confidence = True
    if expected_episode_count is not None:
        maintain_confidence = should_maintain_confidence(
            dedup_result,
            expected_episode_count,
        )
    
    return {
        "dedup_result": dedup_result.to_dict(),
        "coverage_info": coverage_info,
        "maintain_confidence": maintain_confidence,
        "quality_analysis": [
            {
                "name": q.name,
                "size": q.size,
                "quality_score": q.quality_score,
                "episode": q.episode,
                "season": q.season,
            }
            for q in analyze_file_quality(files)[:10]  # Top 10
        ],
    }
