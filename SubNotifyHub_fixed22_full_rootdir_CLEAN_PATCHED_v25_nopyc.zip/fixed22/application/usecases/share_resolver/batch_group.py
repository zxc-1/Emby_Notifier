from __future__ import annotations

"""Batch (multi-episode) utilities (pure).

No IO here: just regex parsing + heuristic scoring.
"""

from dataclasses import dataclass
from typing import Dict, Iterable, List, Optional, Tuple
import re

_RE_SXXEYY = re.compile(r"(?i)\bS(?P<s>\d{1,2})\s*E(?P<e>\d{1,3})\b")
_RE_EYY = re.compile(r"(?i)(?:\bEP?\s*)(?P<e>\d{1,3})\b")
_RE_CN_EP = re.compile(r"第\s*(?P<e>\d{1,3})\s*集")


@dataclass(frozen=True)
class EpisodeFile:
    name: str
    size: int = 0


def extract_season_episode(name: str) -> Tuple[Optional[int], Optional[int]]:
    """Return (season, episode) if found, else (None, None)."""
    s = str(name or "")
    if not s:
        return None, None
    m = _RE_SXXEYY.search(s)
    if m:
        try:
            return int(m.group("s")), int(m.group("e"))
        except (ValueError, TypeError):
            return None, None
    m2 = _RE_CN_EP.search(s)
    if m2:
        try:
            return None, int(m2.group("e"))
        except (ValueError, TypeError):
            return None, None
    m3 = _RE_EYY.search(s)
    if m3:
        try:
            return None, int(m3.group("e"))
        except (ValueError, TypeError):
            return None, None
    return None, None


def standard_se_rate(names: Iterable[str]) -> float:
    """Fraction of filenames that match SxxEyy."""
    n = 0
    hit = 0
    for x in names or []:
        xx = str(x or "")
        if not xx:
            continue
        n += 1
        if _RE_SXXEYY.search(xx):
            hit += 1
    return float(hit) / float(n) if n else 0.0


_RESOLUTION = [(2160, 4.0), (1080, 3.0), (720, 2.0), (480, 1.0)]
_CODEC = [(r"\bAV1\b", 3.0), (r"\bH\.?265\b|\bHEVC\b", 2.0), (r"\bH\.?264\b|\bAVC\b", 1.0)]
_HDR = [(r"\bDV\b|\bDOVI\b|\bDOLBY\s*VISION\b", 3.0), (r"\bHDR10\+\b", 2.5), (r"\bHDR\b", 2.0)]
_SOURCE = [(r"\bREMUX\b", 4.0), (r"\bBLU\s*RAY\b|\bBLURAY\b|\bBDRIP\b", 3.0), (r"\bWEB[- ]?DL\b", 2.0), (r"\bWEBRIP\b", 1.5), (r"\bHDTV\b", 1.0)]
_AUDIO = [
    (r"TRUEHD", 3.0),
    (r"ATMOS", 2.5),
    (r"DTS[- ]?HD", 2.2),
    (r"DTS\b", 1.8),
    (r"DDP|EAC3", 1.6),
    (r"DD\b|AC3", 1.2),
    (r"AAC", 1.0),
]


def quality_score(name: str) -> float:
    """Heuristic quality score from filename tokens."""
    s = str(name or "")
    if not s:
        return 0.0
    u = s.upper()
    sc = 0.0

    for res, w in _RESOLUTION:
        if f"{res}P" in u:
            sc += w
            break

    for pat, w in _HDR:
        if re.search(pat, u):
            sc += w
            break

    for pat, w in _CODEC:
        if re.search(pat, u):
            sc += w
            break

    for pat, w in _SOURCE:
        if re.search(pat, u):
            sc += w
            break

    for pat, w in _AUDIO:
        if re.search(pat, u):
            sc += w
            break

    return sc


def dedup_by_episode(
    files: List[EpisodeFile],
    *,
    season_hint: Optional[int] = None,
) -> Tuple[Dict[int, EpisodeFile], List[EpisodeFile]]:
    """Pick best file per episode.

    Returns:
      best_map: {episode: EpisodeFile}
      duplicates: list[EpisodeFile] (non-best candidates)

    Notes:
    - If season_hint is provided, (None, e) pairs are accepted.
    - Otherwise, we require explicit SxxEyy.
    """
    best: Dict[int, EpisodeFile] = {}
    dup: List[EpisodeFile] = []

    def _ep_ok(s: Optional[int], e: Optional[int]) -> bool:
        if e is None or e <= 0 or e > 2000:
            return False
        if s is None:
            return season_hint is not None
        if season_hint is not None:
            return int(s) == int(season_hint)
        return True

    for f in files or []:
        s, e = extract_season_episode(f.name)
        if not _ep_ok(s, e):
            continue
        if e is None:
            continue
        if e not in best:
            best[e] = f
            continue
        b = best[e]
        q_new = (quality_score(f.name), int(f.size or 0))
        q_old = (quality_score(b.name), int(b.size or 0))
        if q_new > q_old:
            dup.append(b)
            best[e] = f
        else:
            dup.append(f)

    return best, dup
