"""Sequel and prequel detection module.

This module provides detection and handling for sequels and prequels:
- Sequel marker detection (Requirement 18.1, 18.3)
- Sequel number normalization (Requirement 18.5)
- Sequel mismatch penalty (Requirement 18.2, 18.4)

Extracted for better maintainability and testability.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple

from core.logging import get_biz_logger_adapter

logger = get_biz_logger_adapter(__name__)


# =============================================================================
# Constants
# =============================================================================

# Penalty for sequel mismatch (Requirement 18.2)
SEQUEL_MISMATCH_PENALTY = -0.10

# Penalty for sequel number mismatch (Requirement 18.4)
SEQUEL_NUMBER_MISMATCH_PENALTY = -0.15

# Roman numeral mapping
ROMAN_NUMERALS = {
    'I': 1, 'II': 2, 'III': 3, 'IV': 4, 'V': 5,
    'VI': 6, 'VII': 7, 'VIII': 8, 'IX': 9, 'X': 10,
    'XI': 11, 'XII': 12, 'XIII': 13, 'XIV': 14, 'XV': 15,
}

# Chinese number mapping
CN_NUMBERS = {
    '一': 1, '二': 2, '三': 3, '四': 4, '五': 5,
    '六': 6, '七': 7, '八': 8, '九': 9, '十': 10,
    '十一': 11, '十二': 12, '十三': 13, '十四': 14, '十五': 15,
}

# Chinese sequel markers
CN_SEQUEL_MARKERS = ['续集', '前传', '第二部', '第三部', '第四部', '第五部']

# Sequel patterns for detection
SEQUEL_PATTERNS = [
    # Arabic numerals at end: "Title 2", "Title 3"
    (r'\s+(\d+)\s*$', 'arabic'),
    # Roman numerals: "Title II", "Title III"
    (r'\s+(I{1,3}|IV|V|VI{0,3}|IX|X{1,3}|XI{0,3}|XIV|XV)\s*$', 'roman'),
    # Part patterns: "Part 2", "Part II"
    (r'\bPart\s*(\d+|I{1,3}|IV|V|VI{0,3}|IX|X)\b', 'part'),
    # Chinese patterns: "第二部", "第三部"
    (r'第([一二三四五六七八九十]+)部', 'cn_part'),
    # Chinese sequel markers
    (r'(续集|前传)', 'cn_marker'),
    # Colon patterns: "Title: Part 2"
    (r':\s*Part\s*(\d+|I{1,3}|IV|V|VI{0,3}|IX|X)\b', 'colon_part'),
]


# =============================================================================
# Sequel Number Normalization (Requirement 18.5)
# =============================================================================

def normalize_sequel_number(value: str) -> Optional[int]:
    """Normalize sequel number to integer (Requirement 18.5).
    
    Converts various formats to integer:
    - "2" -> 2
    - "II" -> 2
    - "第二部" -> 2
    - "二" -> 2
    
    Args:
        value: String representation of sequel number
    
    Returns:
        Integer sequel number or None if not parseable
    """
    if not value:
        return None
    
    value = value.strip()
    
    # Try Arabic numeral
    if value.isdigit():
        return int(value)
    
    # Try Roman numeral
    upper_val = value.upper()
    if upper_val in ROMAN_NUMERALS:
        return ROMAN_NUMERALS[upper_val]
    
    # Try Chinese number
    if value in CN_NUMBERS:
        return CN_NUMBERS[value]
    
    # Try Chinese part pattern
    cn_match = re.search(r'第([一二三四五六七八九十]+)部', value)
    if cn_match:
        cn_num = cn_match.group(1)
        if cn_num in CN_NUMBERS:
            return CN_NUMBERS[cn_num]
    
    return None


# =============================================================================
# Sequel Marker Detection (Requirement 18.1, 18.3)
# =============================================================================

def detect_sequel_markers(title: str) -> Dict[str, Any]:
    """Detect sequel markers in title (Requirement 18.1, 18.3).
    
    Detects:
    - Arabic numerals (2, 3, 4...)
    - Roman numerals (II, III, IV...)
    - Chinese markers (续集, 前传, 第二部...)
    - Part patterns (Part 2, Part II...)
    
    Args:
        title: Title to analyze
    
    Returns:
        Dict with:
        - has_sequel_marker: True if sequel marker found
        - sequel_number: Normalized sequel number (int) or None
        - marker_type: Type of marker found
        - marker_text: Original marker text
    """
    if not title:
        return {
            "has_sequel_marker": False,
            "sequel_number": None,
            "marker_type": None,
            "marker_text": None,
        }
    
    for pattern, marker_type in SEQUEL_PATTERNS:
        match = re.search(pattern, title, re.IGNORECASE)
        if match:
            marker_text = match.group(1) if match.lastindex else match.group(0)
            sequel_number = normalize_sequel_number(marker_text)
            
            # Special handling for Chinese markers
            if marker_type == 'cn_marker':
                if marker_text == '续集':
                    sequel_number = 2  # 续集 typically means part 2
                elif marker_text == '前传':
                    sequel_number = 0  # 前传 is prequel (before part 1)
            
            return {
                "has_sequel_marker": True,
                "sequel_number": sequel_number,
                "marker_type": marker_type,
                "marker_text": marker_text,
            }
    
    return {
        "has_sequel_marker": False,
        "sequel_number": None,
        "marker_type": None,
        "marker_text": None,
    }


def has_sequel_marker(title: str) -> bool:
    """Check if title has any sequel marker.
    
    Args:
        title: Title to check
    
    Returns:
        True if title contains sequel marker
    """
    result = detect_sequel_markers(title)
    return result.get("has_sequel_marker", False)


def get_sequel_number(title: str) -> Optional[int]:
    """Get normalized sequel number from title.
    
    Args:
        title: Title to analyze
    
    Returns:
        Sequel number or None
    """
    result = detect_sequel_markers(title)
    return result.get("sequel_number")


# =============================================================================
# Sequel Mismatch Penalty (Requirement 18.2, 18.4)
# =============================================================================

def compute_sequel_mismatch_penalty(
    query_title: str,
    candidate_title: str,
) -> Tuple[float, Dict[str, Any]]:
    """Compute penalty for sequel mismatch (Requirement 18.2, 18.4).
    
    Rules:
    - If query has no sequel marker but candidate does: -0.10
    - If query has sequel marker but candidate doesn't: -0.10
    - If both have sequel markers but numbers differ: -0.15
    
    Args:
        query_title: Query title
        candidate_title: Candidate title
    
    Returns:
        Tuple of (penalty, info_dict)
    """
    query_info = detect_sequel_markers(query_title)
    candidate_info = detect_sequel_markers(candidate_title)
    
    query_has = query_info.get("has_sequel_marker", False)
    candidate_has = candidate_info.get("has_sequel_marker", False)
    
    query_num = query_info.get("sequel_number")
    candidate_num = candidate_info.get("sequel_number")
    
    info = {
        "query_has_sequel": query_has,
        "candidate_has_sequel": candidate_has,
        "query_sequel_number": query_num,
        "candidate_sequel_number": candidate_num,
        "penalty_applied": 0.0,
        "penalty_reason": None,
    }
    
    # Case 1: Query has no sequel marker but candidate does (Requirement 18.2)
    if not query_has and candidate_has:
        info["penalty_applied"] = SEQUEL_MISMATCH_PENALTY
        info["penalty_reason"] = "candidate_has_sequel_query_not"
        return SEQUEL_MISMATCH_PENALTY, info
    
    # Case 2: Query has sequel marker but candidate doesn't
    if query_has and not candidate_has:
        info["penalty_applied"] = SEQUEL_MISMATCH_PENALTY
        info["penalty_reason"] = "query_has_sequel_candidate_not"
        return SEQUEL_MISMATCH_PENALTY, info
    
    # Case 3: Both have sequel markers but numbers differ (Requirement 18.4)
    if query_has and candidate_has:
        if query_num is not None and candidate_num is not None:
            if query_num != candidate_num:
                info["penalty_applied"] = SEQUEL_NUMBER_MISMATCH_PENALTY
                info["penalty_reason"] = "sequel_number_mismatch"
                return SEQUEL_NUMBER_MISMATCH_PENALTY, info
    
    # No penalty
    return 0.0, info


def apply_sequel_penalty_to_score(
    score: float,
    query_title: str,
    candidate_title: str,
) -> Tuple[float, Dict[str, Any]]:
    """Apply sequel penalty to score.
    
    Args:
        score: Original score
        query_title: Query title
        candidate_title: Candidate title
    
    Returns:
        Tuple of (adjusted_score, info_dict)
    """
    penalty, info = compute_sequel_mismatch_penalty(query_title, candidate_title)
    
    adjusted_score = score + penalty
    info["original_score"] = score
    info["adjusted_score"] = adjusted_score
    
    return adjusted_score, info


# =============================================================================
# Title Comparison Utilities
# =============================================================================

def extract_base_title(title: str) -> str:
    """Extract base title without sequel markers.
    
    Args:
        title: Title with potential sequel markers
    
    Returns:
        Base title without sequel markers
    """
    if not title:
        return title
    
    result = title
    
    # Remove sequel patterns
    for pattern, _ in SEQUEL_PATTERNS:
        result = re.sub(pattern, '', result, flags=re.IGNORECASE)
    
    # Clean up whitespace
    result = ' '.join(result.split())
    
    return result.strip()


def are_same_franchise(title1: str, title2: str) -> bool:
    """Check if two titles are from the same franchise.
    
    Compares base titles (without sequel markers) to determine
    if they belong to the same franchise.
    
    Args:
        title1: First title
        title2: Second title
    
    Returns:
        True if titles appear to be from same franchise
    """
    base1 = extract_base_title(title1).lower()
    base2 = extract_base_title(title2).lower()
    
    if not base1 or not base2:
        return False
    
    # Exact match
    if base1 == base2:
        return True
    
    # One contains the other
    if base1 in base2 or base2 in base1:
        return True
    
    return False


def get_sequel_comparison_summary(
    query_title: str,
    candidate_title: str,
) -> Dict[str, Any]:
    """Get comprehensive sequel comparison summary.
    
    Args:
        query_title: Query title
        candidate_title: Candidate title
    
    Returns:
        Dict with all sequel comparison information
    """
    query_info = detect_sequel_markers(query_title)
    candidate_info = detect_sequel_markers(candidate_title)
    penalty, penalty_info = compute_sequel_mismatch_penalty(query_title, candidate_title)
    
    return {
        "query": {
            "title": query_title,
            "base_title": extract_base_title(query_title),
            **query_info,
        },
        "candidate": {
            "title": candidate_title,
            "base_title": extract_base_title(candidate_title),
            **candidate_info,
        },
        "same_franchise": are_same_franchise(query_title, candidate_title),
        "penalty": penalty,
        "penalty_info": penalty_info,
    }
