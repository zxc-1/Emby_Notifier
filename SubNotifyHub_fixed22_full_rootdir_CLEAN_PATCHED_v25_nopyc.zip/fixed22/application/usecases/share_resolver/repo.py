from __future__ import annotations

"""Repository layer for share TMDB resolver.

This module is a thin wrapper around :mod:`tg_bot.storage`.

Goals:
- reduce cross-module imports
- provide a stable API surface for the resolver refactor

Do **not** put business logic here.
"""
import logging
from core.logging import get_biz_logger_adapter
logger = get_biz_logger_adapter(__name__)


import asyncio
from typing import Any, Dict, List, Optional

from application.errors import ConfigError
from ports.share_resolver_repo import get_share_resolver_repo


# ---------------------------------------------------------------------------
# Sync wrappers (compat with legacy resolver code)
# ---------------------------------------------------------------------------


def _repo():
    try:
        return get_share_resolver_repo()
    except Exception as e:
        raise ConfigError(
            "share_resolver repo 未配置：请确保在启动时注册 storage adapter（见 tg_bot.infra.share_resolver_repo）"
        ) from e


def init_db() -> None:
    _repo().init_db()


def cleanup_pending(ttl_sec: int = 1800) -> None:
    _repo().cleanup_pending(int(ttl_sec))


def create_pending_choice(
    *,
    chat_id: int,
    user_id: int,
    share_url: str,
    share_host: str | None = None,
    share_code: str | None,
    receive_code: str | None,
    season: int | None,
    evidence_title: str | None,
    evidence_year: int | None,
    evidence_media_type: str | None,
    file_sig: str | None = None,
    candidates: List[Dict[str, Any]],
) -> str:
    """Create pending choice token.

    This mirrors :func:`tg_bot.storage.create_pending_choice` (which handles
    schema backward-compat internally).
    """
    return _repo().create_pending_choice(
        chat_id=int(chat_id),
        user_id=int(user_id),
        share_url=str(share_url or ""),
        share_host=(str(share_host) if share_host is not None else None),
        share_code=(str(share_code) if share_code is not None else None),
        receive_code=(str(receive_code) if receive_code is not None else None),
        season=(int(season) if season is not None else None),
        evidence_title=(str(evidence_title) if evidence_title is not None else None),
        evidence_year=(int(evidence_year) if evidence_year is not None else None),
        evidence_media_type=(str(evidence_media_type) if evidence_media_type is not None else None),
        file_sig=(str(file_sig) if file_sig else None),
        candidates=list(candidates or []),
    )


def get_mapping(share_code: str) -> Optional[Dict[str, Any]]:
    return _repo().get_mapping(share_code)


def upsert_mapping(**kwargs: Any) -> None:
    return _repo().upsert_mapping(**kwargs)


def get_title_mapping(fp: str) -> Optional[Dict[str, Any]]:
    return _repo().get_title_mapping(fp)


def upsert_title_mapping(**kwargs: Any) -> None:
    return _repo().upsert_title_mapping(**kwargs)


def get_series_mapping(sk: str) -> Optional[Dict[str, Any]]:
    return _repo().get_series_mapping(sk)


def upsert_series_mapping(**kwargs: Any) -> None:
    return _repo().upsert_series_mapping(**kwargs)


# ---------------------------------------------------------------------------
# Async helpers (used by new resolver modules)
# ---------------------------------------------------------------------------


async def init_resolver_state() -> None:
    """Init DB and run periodic cleanup for pending choices."""
    await asyncio.to_thread(_repo().init_db)
    try:
        await asyncio.to_thread(_repo().cleanup_pending, 1800)
    except (OSError, RuntimeError) as e:
        # cleanup failure should not break user flow
        logger.detail(f"待处理选项清理失败（已忽略） - 原因={type(e).__name__}")


async def get_share_mapping(share_code: str) -> Optional[Dict[str, Any]]:
    if not share_code:
        return None
    return await asyncio.to_thread(_repo().get_mapping, share_code)


async def upsert_share_mapping(
    *,
    share_code: str,
    receive_code: str,
    tmdb_id: int,
    media_type: str,
    title: str,
    year: Optional[int],
    season: Optional[int],
    strength: str,
    confidence: float,
    evidence_title: str,
    evidence_year: Optional[int],
    file_sig: Optional[str],
) -> None:
    if not share_code:
        return
    await asyncio.to_thread(
        _repo().upsert_mapping,
        share_code=share_code,
        receive_code=receive_code,
        tmdb_id=int(tmdb_id),
        media_type=str(media_type or "").strip().lower() or "movie",
        title=str(title or ""),
        year=year,
        season=season,
        strength=str(strength or "strong"),
        confidence=float(confidence or 0.0),
        evidence_title=str(evidence_title or ""),
        evidence_year=evidence_year,
        file_sig=(str(file_sig) if file_sig else None),
    )


async def get_title_mapping_async(fp: str) -> Optional[Dict[str, Any]]:
    if not fp:
        return None
    return await asyncio.to_thread(_repo().get_title_mapping, fp)


async def get_series_mapping_async(sk: str) -> Optional[Dict[str, Any]]:
    if not sk:
        return None
    return await asyncio.to_thread(_repo().get_series_mapping, sk)


async def cleanup_pending_async(ttl_sec: int = 1800) -> None:
    try:
        await asyncio.to_thread(_repo().cleanup_pending, int(ttl_sec))
    except (OSError, RuntimeError) as e:
        logger.detail(f"待处理选项清理失败（已忽略） - 超时={ttl_sec}秒, 原因={type(e).__name__}")
