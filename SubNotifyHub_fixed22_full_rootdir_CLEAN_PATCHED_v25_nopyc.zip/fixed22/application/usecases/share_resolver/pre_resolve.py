"""Pre-resolve module for TMDB recognition.

This module handles the pre-resolution stage (Stage-④ pre-resolve):
- Extract explicit TMDB IDs from filenames/hints
- Extract IMDb IDs and lookup via TMDB /find
- Validate title-fingerprint cache hits
- Validate weak cached mappings
- Validate global TV series cache

Extracted from tmdb_lookup.py for better maintainability.
"""

from __future__ import annotations

import asyncio
import logging
import re
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple

from core.logging import get_biz_logger_adapter

from .cache_validation import (
    validate_title_cache_hit,
    validate_series_cache_hit,
    should_disable_bad_mapping,
    check_media_type_consistency,
    compute_cache_seed_score,
)
from .ports_access import tmdb
from core.suppress import suppress

logger = get_biz_logger_adapter(__name__)


@dataclass
class CandidateShim:
    """Lightweight candidate representation for pre-resolve stage."""
    tmdb_id: int
    media_type: str
    title: str
    year: Optional[int] = None
    rating: Optional[float] = None
    vote_count: Optional[int] = None
    score: Optional[float] = None
    extra: Dict[str, Any] | None = None


def extract_explicit_tmdb_id(
    sources: List[str],
    tmdb_explicit_re: re.Pattern,
    tmdb_matcher: Any,
) -> Tuple[Optional[int], bool]:
    """Extract explicit TMDB ID from sources.
    
    Searches for patterns like:
    - tmdb:123 / tmdbid-123 / {tmdbid-123}
    - Relaxed patterns via tmdb_matcher.extract_tmdb_id_from_text()
    
    Args:
        sources: List of strings to search (filename, hint_name, share_title, etc.)
        tmdb_explicit_re: Compiled regex for explicit TMDB ID patterns
        tmdb_matcher: TMDB matcher instance for relaxed extraction
    
    Returns:
        Tuple of (tmdb_id, is_explicit_marker)
        - tmdb_id: Extracted ID or None
        - is_explicit_marker: True if from explicit pattern (tmdb:123), False if relaxed
    """
    explicit_tid: Optional[int] = None
    is_explicit = False
    
    # First pass: explicit patterns (tmdb:123, tmdbid-123, etc.)
    for src in sources:
        try:
            mx = tmdb_explicit_re.search(str(src or ""))
        except Exception:
            logger.detail(f"explicit id 搜索失败（已忽略） - 源={str(src)[:80]}")
            mx = None
        if mx:
            try:
                explicit_tid = int(mx.group(1))
                is_explicit = True
                return explicit_tid, is_explicit
            except Exception:
                logger.detail(f"explicit tid 转换失败（已忽略） - 匹配值={mx.group(1) if mx else None}")
    
    # Second pass: relaxed extraction
    for src in sources:
        try:
            tid = tmdb_matcher.extract_tmdb_id_from_text(str(src or ""))
        except Exception:
            logger.detail(f"tmdb id 提取失败（已忽略） - 源={str(src)[:80]}")
            tid = None
        if tid:
            return int(tid), False
    
    return None, False


def extract_imdb_id(
    sources: List[str],
    tmdb_matcher: Any,
) -> Optional[str]:
    """Extract IMDb ID from sources.
    
    Args:
        sources: List of strings to search
        tmdb_matcher: TMDB matcher instance
    
    Returns:
        IMDb ID string (e.g., "tt1234567") or None
    """
    for src in sources:
        try:
            imdb_id = tmdb_matcher.extract_imdb_id_from_text(str(src or ""))
        except Exception:
            logger.detail(f"IMDb ID 提取失败（已忽略） - 源={str(src)[:80]}")
            imdb_id = None
        if imdb_id:
            return imdb_id
    return None


def determine_media_type_preference(
    season_hint_eff: Optional[int],
    tvish: bool,
    vc_reliable: bool,
    video_count: int,
    hints2: List[str],
    tmdb_matcher: Any,
) -> str:
    """Determine media type preference based on evidence.
    
    Args:
        season_hint_eff: Effective season hint
        tvish: True if evidence suggests TV
        vc_reliable: True if video count is reliable
        video_count: Number of video files
        hints2: List of hints
        tmdb_matcher: TMDB matcher instance
    
    Returns:
        "tv" or "movie"
    """
    if season_hint_eff is not None:
        return "tv"
    if tvish:
        return "tv"
    if vc_reliable and int(video_count or 0) >= 6:
        return "tv"
    # Check first few hints for TV patterns
    for hint in (hints2 or [])[:3]:
        try:
            if tmdb_matcher.detect_tv_hint(hint):
                return "tv"
        except Exception as e:
            suppress(site="share_resolver/pre_resolve:detect_tv_hint", exc=e, fallback=None)
    return "movie"


def _derive_title_year_from_evidence_without_tmdbid(
    share_title: str,
    hint_name: str,
    filename: str,
    dir_path: List[str],
    hints2: List[str],
    tmdb_explicit_re: re.Pattern,
    tmdb_matcher: Any,
) -> Tuple[str, Optional[int]]:
    """Derive title and year from evidence after removing explicit TMDB ID tokens.
    
    Used when we have an explicit TMDB ID but no query title - we try to recover
    a usable title by stripping the ID token and parsing again.
    
    Returns:
        Tuple of (title, year)
    """
    sources = [share_title, hint_name, filename, *(dir_path or []), *(hints2 or [])]
    
    for src in sources:
        s0 = str(src or "").strip()
        if not s0:
            continue
        
        # Remove explicit TMDB ID markers
        try:
            s1 = tmdb_explicit_re.sub("", s0)
        except Exception:
            logger.detail(f"explicit id 移除失败（已忽略） - 原始字符串={s0[:80]}")
            s1 = s0
        
        # Remove relaxed patterns like "tmdbid-123" / "tmdb:123"
        s1 = re.sub(r"(?i)(?:\b(?:tmdb|tmdbid)\s*[:#-]?\s*\d{3,10}\b)", "", s1)
        s1 = s1.strip(" _-·.()[]{}") 
        
        if not s1:
            continue
        
        try:
            t, y, _ = tmdb_matcher.parse_title_year_from_filename(s1)
        except Exception:
            logger.detail(f"标题/年份解析失败（已忽略） - 字符串={s1[:80]}")
            continue
        
        t = str(t or "").strip()
        if t:
            return t, (int(y) if y is not None else None)
    
    return "", None



async def _validate_explicit_tmdb_id(
    explicit_tid: int,
    explicit_is_explicit: bool,
    q_title: str,
    q_year: Optional[int],
    prefer_mt: str,
    evidence_tvish: bool,
    tmdb_matcher: Any,
    decision_trace: Optional[List[str]],
) -> Optional[Dict[str, Any]]:
    """Validate explicit TMDB ID and return seed candidate if valid.
    
    Returns:
        Seed candidate dict or None if rejected
    """
    def _trace(x: str) -> None:
        if isinstance(decision_trace, list):
            decision_trace.append(x)
    
    try:
        detail = await tmdb_matcher.fetch_tmdb_detail(int(explicit_tid), prefer_media_type=prefer_mt)
    except Exception:
        logger.detail(f"TMDB 详情获取失败（已忽略） - tmdb_id={explicit_tid}, prefer_mt={prefer_mt}")
        detail = None
    
    # Check if TMDB API is configured
    from ports.settings_provider import get_settings
    try:
        api_key = str(getattr(get_settings(), "TMDB_API_KEY", "") or "").strip()
    except Exception:
        logger.detail("TMDB API KEY 获取失败（已忽略）")
        api_key = ""
    
    if (not api_key) or detail:
        if detail and str(detail.get("title") or "").strip():
            mt = str(detail.get("media_type") or prefer_mt).strip().lower() or prefer_mt
            title = str(detail.get("title") or "").strip()
            year = detail.get("year")
            
            cand = CandidateShim(
                tmdb_id=int(explicit_tid),
                media_type=mt,
                title=title,
                year=year,
                rating=float(detail.get("rating") or 0.0),
                vote_count=int(detail.get("vote_count") or 0),
                score=1.0,
                extra=detail,
            )
            
            conf, cov, _ = tmdb_matcher.score_candidate_meta(q_title, q_year, cand)
            conf_score = float(conf)
            
            # Sanity checks for explicit TMDB ID
            reject = False
            
            # 1) TV evidence but TMDB says movie -> reject
            if evidence_tvish and mt == "movie":
                _trace("pre:name_tmdb_reject_tvish_movie")
                reject = True
            # 2) Title similarity check
            elif q_title and conf_score < 0.72:
                _trace("pre:name_tmdb_reject_low_title_match")
                reject = True
            
            # Non-explicit tokens require higher match
            if (not explicit_is_explicit) and q_title and conf_score < 0.82:
                _trace("pre:name_tmdb_low_conf")
                reject = True
            
            if not reject:
                _trace("pre:name_tmdb_seed")
                return {
                    "tmdb_id": int(explicit_tid),
                    "title": title,
                    "year": year,
                    "media_type": mt,
                    "score": conf_score if q_title else compute_cache_seed_score(
                        conf_score, is_explicit_id=explicit_is_explicit, has_query_title=bool(q_title)
                    ),
                    "coverage": float(cov),
                    "vote_count": int(detail.get("vote_count") or 0),
                    "rating": float(detail.get("rating") or 0.0),
                    "_seed_reason": "explicit_tmdb",
                }
    
    return None


async def _resolve_from_imdb_id(
    imdb_id: str,
    q_title: str,
    q_year: Optional[int],
    used_season: Optional[int],
    prefer_mt: str,
    decision_trace: Optional[List[str]],
) -> Optional[Dict[str, Any]]:
    """Resolve TMDB match from IMDb ID.
    
    Returns:
        Result dict with 'picked' if found, None otherwise
    """
    from .gateways import tmdb_find_by_external_id_safe
    
    def _trace(x: str) -> None:
        if isinstance(decision_trace, list):
            decision_trace.append(x)
    
    try:
        found = await tmdb_find_by_external_id_safe(imdb_id, external_source="imdb_id")
    except Exception:
        logger.detail(f"TMDB external id 查找失败（已忽略） - imdb_id={imdb_id}")
        found = []
    
    if len(found) == 1:
        c0 = found[0]
        extra = c0.extra or {}
        _trace("pre:imdb_find")
        return {
            "picked": {
                "tmdb_id": int(c0.tmdb_id),
                "title": str(extra.get("title") or extra.get("name") or c0.title),
                "year": c0.year,
                "media_type": c0.media_type,
                "score": 0.999,
                "rating": None,
                "vote_count": int(extra.get("vote_count") or c0.vote_count or 0),
            },
            "from_source": "imdb_find",
            "used_mt": str(c0.media_type or prefer_mt),
            "used_title": q_title,
            "used_year": q_year,
            "used_season": used_season,
            "cached_fp_tid": None,
        }
    
    return None


async def _resolve_from_title_cache(
    q_title: str,
    q_year: Optional[int],
    used_season: Optional[int],
    prefer_mt: str,
    strong_tv: bool,
    tmdb_matcher: Any,
    decision_trace: Optional[List[str]],
) -> Tuple[Optional[Dict[str, Any]], Optional[int], Optional[str]]:
    """Resolve from title-fingerprint cache.
    
    Returns:
        Tuple of (result_dict, cached_fp_tid, cached_fp)
    """
    from .repo import get_title_mapping, upsert_title_mapping
    
    def _trace(x: str) -> None:
        if isinstance(decision_trace, list):
            decision_trace.append(x)
    
    cached_fp_tid: Optional[int] = None
    cached_fp_map: Optional[Dict[str, Any]] = None
    cached_fp = ""
    
    if not q_title:
        return None, None, None
    
    prefer_mt0 = "tv" if strong_tv else "movie"
    if used_season is not None:
        prefer_mt0 = "tv"
    
    # Generate fingerprints to check
    fps: List[str] = []
    for mt in [prefer_mt0, ("tv" if prefer_mt0 == "movie" else "movie")]:
        fps.append(tmdb_matcher.make_title_fingerprint(q_title, q_year, mt, used_season))
        fps.append(tmdb_matcher.make_title_fingerprint(q_title, q_year, mt, None))
    
    seen_fp = set()
    for fp in fps:
        if not fp or fp in seen_fp:
            continue
        seen_fp.add(fp)
        
        mp = await asyncio.to_thread(get_title_mapping, fp)
        if mp and mp.get("tmdb_id"):
            mp_mt = str(mp.get("media_type") or "").strip().lower() or None
            
            # Check media type consistency
            is_consistent, reason = check_media_type_consistency(
                evidence_media_type=prefer_mt0 if strong_tv else None,
                cached_media_type=mp_mt,
                strong_tv_evidence=strong_tv,
            )
            if not is_consistent:
                _trace(f"pre:title_cache_reject_{reason}")
                continue
            
            cached_fp_map = mp
            cached_fp = fp
            try:
                cached_fp_tid = int(mp.get("tmdb_id") or 0)
            except Exception:
                logger.detail(f"cached fp tid 转换失败（已忽略） - 原始值={mp.get('tmdb_id')!r}")
                cached_fp_tid = None
            break
    
    # Validate cache hit
    if cached_fp_map and cached_fp_tid and cached_fp_tid > 0 and q_title:
        try:
            _prefer = str(cached_fp_map.get("media_type") or "").strip().lower() or None
            _d = await tmdb_matcher.fetch_tmdb_detail(int(cached_fp_tid), prefer_media_type=_prefer)
        except Exception:
            logger.detail(f"cached fp 详情获取失败（已忽略） - tmdb_id={cached_fp_tid}, prefer_mt={_prefer}")
            _d = None
        
        if _d and str(_d.get("title") or "").strip():
            cand = CandidateShim(
                tmdb_id=int(cached_fp_tid),
                media_type=str(_d.get("media_type") or (_prefer or "movie")),
                title=str(_d.get("title") or "").strip(),
                year=_d.get("year"),
                rating=float(_d.get("rating") or 0.0),
                vote_count=int(_d.get("vote_count") or 0),
                score=1.0,
                extra=_d,
            )
            
            s2, cov2, _ = tmdb_matcher.score_candidate_meta(q_title, q_year, cand)
            
            is_valid, rejection_reason = validate_title_cache_hit(
                confidence=float(s2),
                coverage=float(cov2),
                query_year=q_year,
                cached_year=cand.year,
            )
            
            if is_valid:
                _trace("pre:title_cache")
                return {
                    "picked": {
                        "tmdb_id": int(cached_fp_tid),
                        "title": cand.title,
                        "year": cand.year,
                        "media_type": cand.media_type,
                        "score": float(s2),
                        "coverage": float(cov2),
                    },
                    "from_source": "title_cache",
                    "used_mt": str(cand.media_type or prefer_mt),
                    "used_title": q_title,
                    "used_year": q_year,
                    "used_season": used_season,
                    "cached_fp_tid": cached_fp_tid,
                }, cached_fp_tid, cached_fp
            else:
                # Disable bad mapping
                if should_disable_bad_mapping(float(s2)):
                    try:
                        if cached_fp:
                            _trace("pre:title_cache_disable_bad")
                            await asyncio.to_thread(
                                upsert_title_mapping,
                                fp=str(cached_fp),
                                tmdb_id=0,
                                media_type=str(cached_fp_map.get("media_type") or prefer_mt or "movie"),
                                title="",
                                year=None,
                                season=None,
                                confidence=0.0,
                                source="disabled_bad",
                            )
                    except Exception:
                        logger.detail("disable bad title mapping 失败", exc_info=True)
    
    return None, cached_fp_tid, cached_fp


async def _resolve_from_weak_cache(
    cached_weak: Dict[str, Any],
    q_title: str,
    q_year: Optional[int],
    used_season: Optional[int],
    prefer_mt: str,
    cached_fp_tid: Optional[int],
    tmdb_matcher: Any,
    decision_trace: Optional[List[str]],
) -> Optional[Dict[str, Any]]:
    """Validate and resolve from weak cached mapping.
    
    Returns:
        Result dict with 'picked' if valid, None otherwise
    """
    def _trace(x: str) -> None:
        if isinstance(decision_trace, list):
            decision_trace.append(x)
    
    if not (cached_weak and cached_weak.get("tmdb_id") and q_title):
        return None
    
    try:
        _cid = int(cached_weak.get("tmdb_id") or 0)
    except Exception:
        logger.detail(f"cached weak tid 转换失败（已忽略） - 原始值={cached_weak.get('tmdb_id')!r}")
        return None
    
    if _cid <= 0:
        return None

    # Weak cache must be type-consistent; otherwise it can seed wrong candidates
    # and also cause tmdb_detail cache pollution when movie/tv IDs overlap.
    prefer_mt0 = str(prefer_mt or "").strip().lower()
    cached_mt0 = str((cached_weak or {}).get("media_type") or "").strip().lower()
    if prefer_mt0 in {"movie", "tv"} and cached_mt0 in {"movie", "tv"} and cached_mt0 != prefer_mt0:
        _trace("pre:cache_weak_skip_mt_mismatch")
        return None
    
    try:
        _d = await tmdb_matcher.fetch_tmdb_detail(_cid, prefer_media_type=prefer_mt)
    except Exception:
        logger.detail(f"cached weak 详情获取失败（已忽略） - tmdb_id={_cid}, prefer_mt={prefer_mt}")
        _d = None
    
    # Media type consistency check (both movie/tv)
    if _d and prefer_mt0 in {"movie", "tv"}:
        if str(_d.get("media_type") or "").strip().lower() != prefer_mt0:
            _trace("pre:cache_weak_reject_mt_mismatch")
            _d = None
    
    if _d and str(_d.get("title") or "").strip():
        cand = CandidateShim(
            tmdb_id=_cid,
            media_type=str(_d.get("media_type") or prefer_mt),
            title=str(_d.get("title") or "").strip(),
            year=_d.get("year"),
            rating=float(_d.get("rating") or 0.0),
            vote_count=int(_d.get("vote_count") or 0),
            score=1.0,
            extra=_d,
        )
        
        s = tmdb_matcher.score_candidate(q_title, q_year, cand)
        if float(s) >= 0.82:
            _trace("pre:cache_weak_validated")
            return {
                "picked": {
                    "tmdb_id": _cid,
                    "title": cand.title,
                    "year": cand.year,
                    "media_type": cand.media_type,
                    "score": float(s),
                },
                "from_source": "cache_weak_validated",
                "used_mt": str(cand.media_type or prefer_mt),
                "used_title": q_title,
                "used_year": q_year,
                "used_season": used_season,
                "cached_fp_tid": cached_fp_tid,
            }
    
    return None


async def _resolve_from_series_cache(
    q_title: str,
    q_year: Optional[int],
    used_season: Optional[int],
    tvish: bool,
    vc_reliable: bool,
    video_count: int,
    share_title: str,
    hint_name: str,
    filename: str,
    dir_path: List[str],
    hints2: List[str],
    cached_fp_tid: Optional[int],
    tmdb_matcher: Any,
    decision_trace: Optional[List[str]],
) -> Optional[Dict[str, Any]]:
    """Resolve from global TV series cache.
    
    Returns:
        Result dict with 'picked' if valid, None otherwise
    """
    from .repo import get_series_mapping, upsert_series_mapping
    
    def _trace(x: str) -> None:
        if isinstance(decision_trace, list):
            decision_trace.append(x)
    
    # Only check series cache for TV-like evidence
    if not (q_title and (used_season is not None or tvish or (vc_reliable and int(video_count or 0) >= 6))):
        return None
    
    try:
        series_keys: List[str] = []
        seen_sk = set()
        sources = [q_title, share_title, hint_name, filename, *(dir_path or []), *(hints2 or [])]
        
        for src in sources:
            t0, y0, _ = tmdb_matcher.parse_title_year_from_filename(str(src or ""))
            if not t0:
                continue
            for sk in tmdb_matcher.make_series_fingerprints(t0, y0 or q_year):
                if sk and sk not in seen_sk:
                    seen_sk.add(sk)
                    series_keys.append(sk)
            if len(series_keys) >= 10:
                break
        
        # Find best series mapping
        best_map: Optional[Dict[str, Any]] = None
        best_sk: Optional[str] = None
        best_rank = (-1.0, -1, -1)
        
        for sk in series_keys:
            sm = await asyncio.to_thread(get_series_mapping, sk)
            if not (sm and sm.get("tmdb_id")):
                continue
            conf = float(sm.get("confidence") or 0.0)
            hc = int(sm.get("hit_count") or 0)
            upd = int(sm.get("updated_at") or 0)
            rank = (conf, hc, upd)
            if rank > best_rank:
                best_rank = rank
                best_map = sm
                best_sk = str(sk)
        
        if best_map and best_map.get("tmdb_id"):
            mid = int(best_map.get("tmdb_id") or 0)
            if mid > 0:
                _d = await tmdb_matcher.fetch_tmdb_detail(mid, prefer_media_type="tv")
                if _d and str(_d.get("title") or "").strip():
                    cand = CandidateShim(
                        tmdb_id=mid,
                        media_type=str(_d.get("media_type") or "tv"),
                        title=str(_d.get("title") or "").strip(),
                        year=_d.get("year"),
                        rating=float(_d.get("rating") or 0.0),
                        vote_count=int(_d.get("vote_count") or 0),
                        score=1.0,
                        extra=_d,
                    )
                    
                    s3, cov3, _ = tmdb_matcher.score_candidate_meta(q_title, q_year, cand)
                    qn_norm = str(q_title).lower().strip()
                    short = len(tmdb_matcher.normalize_title(qn_norm)) <= 6
                    
                    # Validate series cache hit
                    is_valid, rejection_reason = validate_series_cache_hit(
                        confidence=float(s3) if not short else float(s3),
                        query_year=q_year,
                        cached_year=cand.year,
                    )
                    
                    # Additional coverage check
                    ok = is_valid and (float(cov3) >= (0.85 if short else 0.60))
                    
                    # Short title requires higher confidence
                    if short and float(s3) < 0.90:
                        ok = False
                    elif not short and float(s3) < 0.80:
                        ok = False
                    
                    if ok:
                        _trace("pre:series_cache")
                        return {
                            "picked": {
                                "tmdb_id": mid,
                                "title": cand.title,
                                "year": cand.year,
                                "media_type": "tv",
                                "score": float(s3),
                                "coverage": float(cov3),
                            },
                            "from_source": "series_cache",
                            "used_mt": "tv",
                            "used_title": q_title,
                            "used_year": q_year,
                            "used_season": used_season,
                            "cached_fp_tid": cached_fp_tid,
                        }
                    else:
                        # Disable bad series mapping
                        try:
                            if best_sk:
                                _trace("pre:series_cache_disable_bad")
                                await asyncio.to_thread(
                                    upsert_series_mapping,
                                    series_key=str(best_sk),
                                    tmdb_id=0,
                                    title="",
                                    year=None,
                                    confidence=0.0,
                                    source="disabled_bad",
                                )
                        except Exception:
                            logger.detail("disable bad series mapping 失败", exc_info=True)
    except Exception:
        logger.detail("series cache resolve 失败", exc_info=True)
    
    return None


async def pre_resolve_from_names_and_caches(
    *,
    q_title: str,
    q_year: Optional[int],
    season_hint_eff: Optional[int],
    tvish: bool,
    vc_reliable: bool,
    video_count: int,
    hints2: List[str],
    filename: str,
    hint_name: str,
    share_title: str,
    dir_path: List[str],
    cached_weak: Optional[Dict[str, Any]] = None,
    decision_trace: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """Stage-④ pre-resolve: external ids + learned caches + explicit ids in names.

    Returns dict:
      - picked: dict|None
      - from_source: str|None
      - used_mt/used_title/used_year/used_season
      - cached_fp_tid: Optional[int]  (for boosting later search)
      - seed_candidates: List[Dict]

    This function performs TMDB IO for validation, but does NOT write to DB.
    """
    from ports.settings_provider import get_settings
    from domain.utils.patterns import TMDB_EXPLICIT_RE
    
    def _trace(x: str) -> None:
        if isinstance(decision_trace, list):
            decision_trace.append(x)
    
    m = tmdb()
    seed_candidates: List[Dict[str, Any]] = []
    
    q_title = str(q_title or "").strip()
    q_year0: Optional[int] = int(q_year) if isinstance(q_year, int) else None
    
    # Determine media type preference
    prefer_mt = determine_media_type_preference(
        season_hint_eff, tvish, vc_reliable, video_count, hints2, m
    )
    
    used_season: Optional[int] = int(season_hint_eff) if season_hint_eff is not None else None
    
    # Build source list for ID extraction
    sources = [filename, hint_name, share_title, *(dir_path or []), *(hints2 or [])]
    
    # A) Extract explicit TMDB ID
    explicit_tid, explicit_is_explicit = extract_explicit_tmdb_id(
        sources, TMDB_EXPLICIT_RE, m
    )
    
    # If we have explicit ID but no title, try to recover title
    if explicit_tid and not q_title:
        t_rec, y_rec = _derive_title_year_from_evidence_without_tmdbid(
            share_title, hint_name, filename, dir_path, hints2, TMDB_EXPLICIT_RE, m
        )
        if t_rec:
            _trace(f"explicit_id_recover_title: '{t_rec}' y={y_rec}")
            q_title = t_rec
            if q_year0 is None and y_rec is not None:
                q_year0 = int(y_rec)
        else:
            _trace("explicit_id_no_title: fallback_to_search")
            explicit_tid = None
    
    # Validate explicit TMDB ID
    if explicit_tid:
        evidence_tvish = bool(
            season_hint_eff is not None
            or tvish
            or (vc_reliable and int(video_count or 0) >= 6)
            or any(m.detect_tv_hint(x) for x in (hints2 or [])[:3])
        )
        
        seed = await _validate_explicit_tmdb_id(
            explicit_tid, explicit_is_explicit, q_title, q_year0,
            prefer_mt, evidence_tvish, m, decision_trace
        )
        if seed:
            seed_candidates.append(seed)
    
    # B) External IDs (IMDb) -> TMDB /find
    s = get_settings()
    if bool(getattr(s, "TMDB_ENABLE_EXTERNAL_ID_FIND", True)):
        imdb_id = extract_imdb_id(sources, m)
        if imdb_id:
            result = await _resolve_from_imdb_id(
                imdb_id, q_title, q_year0, used_season, prefer_mt, decision_trace
            )
            if result:
                return result
    
    # C) Title-fingerprint cache
    strong_tv = bool(used_season is not None or tvish or (vc_reliable and int(video_count or 0) >= 6))
    
    result, cached_fp_tid, cached_fp = await _resolve_from_title_cache(
        q_title, q_year0, used_season, prefer_mt, strong_tv, m, decision_trace
    )
    if result:
        return result
    
    # D) Validate weak cached mapping
    result = await _resolve_from_weak_cache(
        cached_weak, q_title, q_year0, used_season, prefer_mt,
        cached_fp_tid, m, decision_trace
    )
    if result:
        return result
    
    # E) Global TV series cache
    result = await _resolve_from_series_cache(
        q_title, q_year0, used_season, tvish, vc_reliable, video_count,
        share_title, hint_name, filename, dir_path, hints2,
        cached_fp_tid, m, decision_trace
    )
    if result:
        return result
    
    # No match found - return for search stage
    return {
        "picked": None,
        "from_source": None,
        "used_mt": prefer_mt,
        "used_title": q_title,
        "used_year": q_year0,
        "used_season": used_season,
        "cached_fp_tid": cached_fp_tid,
        "seed_candidates": seed_candidates,
    }
