# -*- coding: utf-8 -*-
"""Hint extraction/cleaning for share TMDB resolver.

BACKWARD COMPATIBILITY LAYER:
This module re-exports all public functions from the hints/ package.
All helpers here are pure functions and are suitable for unit tests.

The actual implementations have been moved to:
- hints/hints_validation.py: Validation and cleaning functions
- hints/hints_detection.py: Content type detection functions
- hints/hints_extraction.py: Hint extraction functions
- hints/hints_episode.py: Episode set extraction
- hints/hints_core.py: Main build_hint_pack function
"""
from __future__ import annotations

# Re-export all public functions for backward compatibility
from .hints import (
    # Validation
    _is_garbage_hint,
    _is_generic_share_title,
    _fast_hint_strong,
    clean_hints,
    pick_best_hint,
    # Detection
    _detect_multi_season_markers,
    _detect_mixed_content,
    _detect_part_markers,
    _detect_regional_version,
    # Extraction
    _extract_share_fragment_hint,
    _extract_batch_title,
    _extract_strict_year,
    _prioritize_video_samples,
    # Episode
    _extract_episode_set,
    # Core
    build_hint_pack,
)

__all__ = [
    # Validation
    "_is_garbage_hint",
    "_is_generic_share_title",
    "_fast_hint_strong",
    "clean_hints",
    "pick_best_hint",
    # Detection
    "_detect_multi_season_markers",
    "_detect_mixed_content",
    "_detect_part_markers",
    "_detect_regional_version",
    # Extraction
    "_extract_share_fragment_hint",
    "_extract_batch_title",
    "_extract_strict_year",
    "_prioritize_video_samples",
    # Episode
    "_extract_episode_set",
    # Core
    "build_hint_pack",
]
