"""Share TMDB resolver package.

This package contains the refactored implementation of TMDB resolution for 115 share links.
Public API (compat): `_resolve_tmdb_for_share`.
"""

from .usecase import _resolve_tmdb_for_share

__all__ = ["_resolve_tmdb_for_share"]
