"""Hint selection module for TMDB recognition.

This module handles hint selection for TMDB search:
- Select strongest hints from multiple pools (main, msg, extra)
- Pick primary hint for Stage-A search
- Compute adaptive hint budget
- Extract strict year from CJK titles
- Detect bilingual evidence for Stage-B forcing

Extracted from tmdb_lookup.py for better maintainability.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Tuple

from core.logging import get_biz_logger_adapter

from .scoring import _title_quality_score
from .stage_strategy import detect_bilingual_evidence
from .hint_strength import evaluate_hint_strength

logger = get_biz_logger_adapter(__name__)


def select_hints(
    hints_main: List[str],
    hints_msg: List[str],
    hints_extra: List[str],
    hints2: List[str],
    q_title: str,
    max_hints: int = 3,
) -> Tuple[List[str], Dict[str, str]]:
    """Select strongest hints for TMDB search.
    
    Prioritizes hints based on source quality:
    1. Main hints (video filenames, share title) - highest priority
    2. Message hints (user input, URL fragment) - medium priority
    3. Extra hints (directory names, etc.) - lower priority
    
    Args:
        hints_main: Main hints from video evidence
        hints_msg: Message hints from user input
        hints_extra: Extra hints from directory structure
        hints2: Combined deduplicated hints
        q_title: Query title for reference
        max_hints: Maximum number of hints to select
    
    Returns:
        Tuple of (selected_hints, hint_sources)
        - selected_hints: List of selected hint strings
        - hint_sources: Dict mapping hint -> source ("main"|"msg"|"extra")
    """
    selected_hints: List[str] = []
    
    # Filter hints that are in hints2 (deduplicated pool)
    main_cands = [str(h or "").strip() for h in hints_main if str(h or "").strip() in hints2]
    msg_cands = [str(h or "").strip() for h in hints_msg if str(h or "").strip() in hints2]
    extra_cands = [str(h or "").strip() for h in hints_extra if str(h or "").strip() in hints2]
    
    # Selection strategy depends on whether we have message hints
    if msg_cands:
        # With message hints: prioritize main, then add one msg hint
        for h in main_cands:
            if h and (h not in selected_hints) and len(selected_hints) < 2:
                selected_hints.append(h)
        for h in msg_cands:
            if h and (h not in selected_hints) and len(selected_hints) < max_hints:
                selected_hints.append(h)
                break
        for h in main_cands + extra_cands + msg_cands:
            if h and (h not in selected_hints) and len(selected_hints) < max_hints:
                selected_hints.append(h)
    else:
        # Without message hints: main -> extra -> msg
        for h in main_cands:
            if h and (h not in selected_hints) and len(selected_hints) < max_hints:
                selected_hints.append(h)
        for h in extra_cands:
            if h and (h not in selected_hints) and len(selected_hints) < max_hints:
                selected_hints.append(h)
        for h in msg_cands:
            if h and (h not in selected_hints) and len(selected_hints) < max_hints:
                selected_hints.append(h)
    
    # Fallback to hints2 if nothing selected
    if not selected_hints:
        selected_hints = hints2[:max_hints]
    
    # Build source mapping
    hint_sources: Dict[str, str] = {}
    for h in selected_hints:
        if h in hints_main:
            hint_sources[h] = "main"
        elif h in hints_msg:
            hint_sources[h] = "msg"
        else:
            hint_sources[h] = "extra"
    
    return selected_hints, hint_sources


def pick_primary_hint(
    selected_hints: List[str],
    hint_sources: Dict[str, str],
    strict_year: Optional[int] = None,
) -> str:
    """Select primary hint for Stage-A search.
    
    Prioritizes:
    1. Main hints with CJK title + year (when strict_year is set)
    2. Main hints sorted by quality score
    3. First selected hint as fallback
    
    Args:
        selected_hints: List of selected hints
        hint_sources: Dict mapping hint -> source
        strict_year: Strict year from CJK title (if detected)
    
    Returns:
        Primary hint string for Stage-A search
    """
    if not selected_hints:
        return ""
    
    try:
        mains = [h for h in selected_hints if hint_sources.get(h) == "main"]
        if mains:
            # When we have a reliable CJK title+year, use it as primary
            if strict_year is not None:
                for h in mains:
                    if re.search(r"[\u4e00-\u9fff]", str(h or "")) and re.search(
                        rf"[\(（]{int(strict_year)}[\)）]", str(h or "")
                    ):
                        return str(h)
            # Sort by quality score
            mains.sort(key=lambda x: _title_quality_score(x), reverse=True)
            return mains[0]
    except Exception:
        logger.detail("primary hint 选择失败（已忽略）")
    
    return selected_hints[0] if selected_hints else ""


def compute_adaptive_hint_budget(
    hints_main: List[str],
    hints_msg: List[str],
    hints2: List[str],
) -> int:
    """Compute adaptive hint budget based on hint quality.
    
    High-quality main hints -> fewer hints needed (budget=2)
    Many hints without main -> more hints allowed (budget=4)
    Default -> budget=3
    
    Args:
        hints_main: Main hints from video evidence
        hints_msg: Message hints from user input
        hints2: Combined deduplicated hints
    
    Returns:
        Maximum number of hints to use
    """
    max_hints = 3
    
    try:
        # Filter main hints that are in hints2
        main_cands = [str(h or "").strip() for h in hints_main if str(h or "").strip() in hints2]
        msg_cands = [str(h or "").strip() for h in hints_msg if str(h or "").strip() in hints2]
        
        if main_cands:
            # High-quality main hint -> reduce budget
            mq = max(_title_quality_score(h) for h in main_cands)
            if mq >= 12.0:
                max_hints = 2
        elif msg_cands and len(hints2) >= 4:
            # Many hints without main -> increase budget
            max_hints = 4
    except Exception:
        logger.detail("hint budget 计算失败（已忽略）")
        max_hints = 3
    
    return max_hints


def extract_strict_year(hints: List[str]) -> Optional[int]:
    """Extract strict year from CJK title with explicit year marker.
    
    Looks for patterns like "剧名(2025)" or "剧名（2025）" in CJK titles.
    When found, this year is treated as authoritative and year-off-by-1
    matches are penalized.
    
    Args:
        hints: List of hints to search
    
    Returns:
        Year as integer if found, None otherwise
    """
    try:
        for h in hints:
            # Pattern: CJK characters followed by year in parentheses
            m = re.search(r"[\u4e00-\u9fff].{0,40}[\(（](19\d{2}|20\d{2})[\)）]", str(h or ""))
            if m:
                return int(m.group(1))
    except Exception:
        logger.detail("strict year 提取失败（已忽略）")
    
    return None


def should_force_stage_b(
    hints_main: List[str],
    hints_msg: List[str],
    share_title: str,
    hint_sources: Optional[Dict[str, str]] = None,
) -> bool:
    """Determine if Stage-B should be forced due to bilingual evidence.
    
    When share_title is CJK but filenames are Latin (or vice versa),
    Stage-B should be forced to search with both languages.
    
    Args:
        hints_main: Main hints (video filenames, etc.)
        hints_msg: Message hints (user input, URL fragment)
        share_title: The share title
        hint_sources: Optional hint source mapping
    
    Returns:
        True if Stage-B should be forced
    """
    # Filter to actual main hints if hint_sources provided
    if hint_sources:
        main_hints = [h for h in hints_main if hint_sources.get(h) == "main"]
        msg_hints = [h for h in hints_msg if hint_sources.get(h) == "msg"]
    else:
        main_hints = hints_main
        msg_hints = hints_msg
    
    result = detect_bilingual_evidence(
        hints_main=main_hints,
        hints_msg=msg_hints,
        share_title=share_title,
    )
    
    return result.get("force_stage_b", False) or result.get("has_bilingual", False)


def has_main_hint(hint_sources: Dict[str, str]) -> bool:
    """Check if any selected hint is from main source.
    
    Args:
        hint_sources: Dict mapping hint -> source
    
    Returns:
        True if at least one hint is from "main" source
    """
    return any(v == "main" for v in hint_sources.values())


def rank_hints_by_strength(hints: List[str]) -> List[Tuple[str, float]]:
    """Rank hints by their strength score.
    
    Uses hint_strength module to evaluate each hint.
    
    Args:
        hints: List of hints to rank
    
    Returns:
        List of (hint, strength_score) tuples, sorted by score descending
    """
    ranked: List[Tuple[str, float]] = []
    
    for h in hints:
        if not h:
            continue
        strength_info = evaluate_hint_strength(str(h).strip())
        score = strength_info.get("strength_score", 0.0)
        ranked.append((h, score))
    
    # Sort by score descending
    ranked.sort(key=lambda x: x[1], reverse=True)
    
    return ranked


def filter_weak_hints(hints: List[str], min_strength: float = 0.5) -> List[str]:
    """Filter out weak hints below minimum strength threshold.
    
    Args:
        hints: List of hints to filter
        min_strength: Minimum strength score to keep
    
    Returns:
        List of hints with strength >= min_strength
    """
    result: List[str] = []
    
    for h in hints:
        if not h:
            continue
        strength_info = evaluate_hint_strength(str(h).strip())
        if strength_info.get("strength_score", 0.0) >= min_strength:
            result.append(h)
    
    return result


def build_hint_selection_result(
    hints_main: List[str],
    hints_msg: List[str],
    hints_extra: List[str],
    hints2: List[str],
    q_title: str,
    share_title: str,
) -> Dict[str, Any]:
    """Build complete hint selection result.
    
    Combines all hint selection functions into a single result dict.
    
    Args:
        hints_main: Main hints from video evidence
        hints_msg: Message hints from user input
        hints_extra: Extra hints from directory structure
        hints2: Combined deduplicated hints
        q_title: Query title for reference
        share_title: Share title for bilingual detection
    
    Returns:
        Dict with:
        - selected_hints: List of selected hints
        - hint_sources: Dict mapping hint -> source
        - primary_hint: Primary hint for Stage-A
        - strict_year: Strict year if detected
        - force_stage_b: True if Stage-B should be forced
        - has_main_hint: True if main hint selected
        - hint_budget: Adaptive hint budget
    """
    # Compute adaptive budget
    hint_budget = compute_adaptive_hint_budget(hints_main, hints_msg, hints2)
    
    # Select hints
    selected_hints, hint_sources = select_hints(
        hints_main, hints_msg, hints_extra, hints2, q_title, hint_budget
    )
    
    # Extract strict year from main hints
    main_hints = [h for h in selected_hints if hint_sources.get(h) == "main"]
    strict_year = extract_strict_year(main_hints)
    
    # Pick primary hint
    primary_hint = pick_primary_hint(selected_hints, hint_sources, strict_year)
    
    # Check if Stage-B should be forced
    force_stage_b = should_force_stage_b(
        main_hints,
        [h for h in selected_hints if hint_sources.get(h) == "msg"],
        share_title,
    )
    
    return {
        "selected_hints": selected_hints,
        "hint_sources": hint_sources,
        "primary_hint": primary_hint,
        "strict_year": strict_year,
        "force_stage_b": force_stage_b,
        "has_main_hint": has_main_hint(hint_sources),
        "hint_budget": hint_budget,
    }
