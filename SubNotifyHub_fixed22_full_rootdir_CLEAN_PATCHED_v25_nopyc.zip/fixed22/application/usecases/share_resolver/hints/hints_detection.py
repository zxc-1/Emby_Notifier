# -*- coding: utf-8 -*-
"""Content type detection functions.

This module provides functions for detecting content characteristics:
- _detect_multi_season_markers: Detect multi-season markers
- _detect_mixed_content: Detect mixed movie/TV content
- _detect_part_markers: Detect Part 1/2/3 markers
- _detect_regional_version: Detect regional version markers
"""
from __future__ import annotations

import re
from typing import List

from core.logging import get_biz_logger_adapter
from ..constants import PART_PATTERNS, MULTI_SEASON_PREFER_LOWEST

logger = get_biz_logger_adapter(__name__)


def _detect_multi_season_markers(texts: List[str]) -> dict:
    """Detect multi-season markers in evidence texts (Requirement 11.1, 11.3).
    
    Scans evidence texts for season markers (S01, S02, 第一季, etc.) and returns
    information about detected seasons.
    
    Returns:
        Dict with keys:
        - seasons: List of detected season numbers
        - recommended_season: The recommended season (lowest by default)
        - is_multi_season: True if multiple seasons detected
    """
    if not texts:
        return {"seasons": [], "recommended_season": None, "is_multi_season": False}
    
    seasons: set[int] = set()
    
    # Season patterns
    patterns = [
        re.compile(r"(?i)\bS(?P<s>\d{1,2})(?:E\d+)?"),  # S01, S01E01
        re.compile(r"(?i)Season\s*(?P<s>\d{1,2})"),      # Season 1
        re.compile(r"第(?P<s>\d{1,2})季"),               # 第1季
        re.compile(r"(?i)(?P<s>\d{1,2})(?:st|nd|rd|th)\s*Season"),  # 1st Season
    ]
    
    for text in texts:
        t = str(text or "").strip()
        if not t:
            continue
        for pat in patterns:
            try:
                for m in pat.finditer(t):
                    s = int(m.group("s"))
                    if 1 <= s <= 50:  # Reasonable season range
                        seasons.add(s)
            except (ValueError, TypeError, AttributeError) as e:
                logger.detail(f"季度标记解析失败（已忽略） - text={t[:50]}, 原因={type(e).__name__}")
                continue
    
    season_list = sorted(seasons)
    is_multi = len(season_list) > 1
    
    # Recommend the lowest season by default (most common case)
    recommended = min(season_list) if season_list and MULTI_SEASON_PREFER_LOWEST else (
        max(season_list) if season_list else None
    )
    
    return {
        "seasons": season_list,
        "recommended_season": recommended,
        "is_multi_season": is_multi,
    }


def _detect_mixed_content(texts: List[str]) -> dict:
    """Detect if share contains mixed content types (Requirement 11.2).
    
    Checks if the share appears to contain both movies and TV episodes,
    which would make auto-pick unreliable.
    
    Returns:
        Dict with keys:
        - is_mixed: True if mixed content detected
        - has_movie_markers: True if movie-like content detected
        - has_tv_markers: True if TV-like content detected
    """
    if not texts:
        return {"is_mixed": False, "has_movie_markers": False, "has_tv_markers": False}
    
    has_movie = False
    has_tv = False
    
    # TV markers
    tv_patterns = [
        re.compile(r"(?i)\bS\d{1,2}E\d{1,3}\b"),  # S01E01
        re.compile(r"(?i)\bSeason\s*\d+\b"),       # Season 1
        re.compile(r"第\d+季"),                    # 第1季
        re.compile(r"第\d+集"),                    # 第1集
        re.compile(r"(?i)\bEP?\d{1,3}\b"),         # E01, EP01
    ]
    
    # Movie markers (standalone films, not episodes)
    movie_patterns = [
        re.compile(r"(?i)\b(1080p|2160p|720p)\b.*\b(BluRay|BDRip|WEBRip|HDTV)\b"),
        re.compile(r"(?i)\bREMUX\b"),
        re.compile(r"(?i)\bBDMV\b"),
    ]
    
    combined_text = " ".join(str(t or "") for t in texts)
    
    for pat in tv_patterns:
        if pat.search(combined_text):
            has_tv = True
            break
    
    for pat in movie_patterns:
        if pat.search(combined_text):
            has_movie = True
            break
    
    # Additional heuristic: if we have both episode markers AND no season markers,
    # but also have movie-quality markers, it might be mixed
    is_mixed = has_movie and has_tv
    
    return {
        "is_mixed": is_mixed,
        "has_movie_markers": has_movie,
        "has_tv_markers": has_tv,
    }


def _detect_part_markers(texts: List[str]) -> dict:
    """Detect Part 1/2/3 markers in evidence texts (Requirement 11.4).
    
    Part movies (like "Dune Part 1", "Mission Impossible Part 2") should not
    be auto-picked as they can easily be confused with sequels.
    
    Returns:
        Dict with keys:
        - has_part_marker: True if part marker detected
        - part_numbers: List of detected part numbers
    """
    if not texts:
        return {"has_part_marker": False, "part_numbers": []}
    
    parts: set[int] = set()
    
    for text in texts:
        t = str(text or "").strip()
        if not t:
            continue
        for pat in PART_PATTERNS:
            try:
                for m in pat.finditer(t):
                    p = int(m.group(1))
                    if 1 <= p <= 10:  # Reasonable part range
                        parts.add(p)
            except (ValueError, TypeError, AttributeError, IndexError) as e:
                logger.detail(f"Part 标记解析失败（已忽略） - text={t[:50]}, 原因={type(e).__name__}")
                continue
    
    part_list = sorted(parts)
    
    return {
        "has_part_marker": len(part_list) > 0,
        "part_numbers": part_list,
    }


def _detect_regional_version(texts: List[str]) -> dict:
    """Detect regional version markers (Requirement 11.5).
    
    Some shows have regional versions (US vs UK, etc.) that should not be
    auto-picked without user confirmation.
    
    Returns:
        Dict with keys:
        - has_regional_marker: True if regional marker detected
        - regions: List of detected region codes
    """
    if not texts:
        return {"has_regional_marker": False, "regions": []}
    
    regions: set[str] = set()
    
    # Regional patterns
    patterns = [
        (re.compile(r"(?i)\b(US|USA)\b"), "US"),
        (re.compile(r"(?i)\b(UK|GB)\b"), "UK"),
        (re.compile(r"(?i)\b(AU|AUS)\b"), "AU"),
        (re.compile(r"(?i)\b(CA|CAN)\b"), "CA"),
        (re.compile(r"(?i)\b(JP|JPN)\b"), "JP"),
        (re.compile(r"(?i)\b(KR|KOR)\b"), "KR"),
        (re.compile(r"(?i)\b(CN|CHN)\b"), "CN"),
        (re.compile(r"美版"), "US"),
        (re.compile(r"英版"), "UK"),
        (re.compile(r"日版"), "JP"),
        (re.compile(r"韩版"), "KR"),
        (re.compile(r"国语版"), "CN"),
        (re.compile(r"粤语版"), "HK"),
    ]
    
    for text in texts:
        t = str(text or "").strip()
        if not t:
            continue
        for pat, region in patterns:
            try:
                if pat.search(t):
                    regions.add(region)
            except (ValueError, TypeError, AttributeError) as e:
                logger.detail(f"地区标记解析失败（已忽略） - text={t[:50]}, 原因={type(e).__name__}")
                continue
    
    region_list = sorted(regions)
    
    return {
        "has_regional_marker": len(region_list) > 0,
        "regions": region_list,
    }
