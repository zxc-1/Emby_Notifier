# -*- coding: utf-8 -*-
"""Hint validation and cleaning functions.

This module provides functions for validating and cleaning hint strings:
- _is_garbage_hint: Check if a hint is too noisy
- _is_generic_share_title: Check if a title is generic/uninformative
- _fast_hint_strong: Check if fast snapshot hints are strong enough
- clean_hints: Normalize and de-duplicate hints
- pick_best_hint: Pick the best hint from a list
"""
from __future__ import annotations

import re
from typing import Any, Dict, Iterable, List, Optional

from core.logging import get_biz_logger_adapter
from ..constants import GENERIC_SHARE_TITLE_PATTERNS

logger = get_biz_logger_adapter(__name__)


def _is_generic_share_title(title: str) -> bool:
    """Check if a share title is generic/uninformative (Requirement 1.4, 2.2).
    
    Generic titles like "合集", "资源", "1080p" should not be used as primary hints.
    When detected, video_samples should be prioritized instead.
    
    Returns:
        True if the title matches any generic pattern.
    """
    t = (title or "").strip()
    if not t:
        return True  # Empty is generic
    
    # Check against all generic patterns
    for pattern in GENERIC_SHARE_TITLE_PATTERNS:
        try:
            if pattern.search(t):
                return True
        except (ValueError, TypeError, AttributeError) as e:
            logger.detail(f"通用标题模式匹配失败（已忽略） - pattern={pattern.pattern}, 原因={type(e).__name__}")
            continue
    
    # Also treat very short non-CJK titles as generic
    if len(t) <= 2 and not re.search(r"[\u4e00-\u9fff]", t):
        return True
    
    return False


def _fast_hint_strong(best: Dict[str, Any]) -> bool:
    """Return True if the "fast" 115 snapshot hints are strong enough.

    Heuristic copied from the legacy resolver.
    """
    try:
        if not isinstance(best, dict):
            return False
        if not best.get("ok"):
            return False
        if not bool(best.get("fallback")):
            # root video found -> fast is already accurate
            return True
        title = str(best.get("share_title") or best.get("hint_name") or best.get("filename") or "").strip()
        if not title:
            return False
        # must have CJK and enough length to avoid collisions
        if not re.search(r"[\u4e00-\u9fff]", title):
            return False
        if len(title) < 4:
            return False
        # avoid noisy tags
        if re.search(
            r"\b(1080p|2160p|x264|x265|h\.?264|h\.?265|webrip|bluray|bdrip|hdr|dv)\b",
            title,
            re.IGNORECASE,
        ):
            return False
        if re.search(r"\b(BDMV|STREAM|PLAYLIST)\b", title, re.IGNORECASE):
            return False
        return True
    except (ValueError, TypeError, AttributeError, KeyError) as e:
        logger.detail(f"快速提示强度检查失败（已忽略） - 原因={type(e).__name__}")
        return False


def _is_garbage_hint(s: str) -> bool:
    """Return True if a hint/name is too noisy to be used for TMDB search."""
    try:
        t = (s or "").strip()
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"字符串转换失败（已忽略） - s={s}, 类型={type(s).__name__}, 原因={type(e).__name__}")
        t = str(s or "").strip()
    if not t:
        return True
    low = t.lower().strip()
    # leading dot like ".MP4"
    if low.startswith("."):
        return True
    # pure container/extension tokens
    if low in {"mp4", "mkv", "avi", "mov", "wmv", "flv", "ts", "m2ts", "mpg", "mpeg"}:
        return True
    # pure digits / too short
    if low.isdigit() or len(low) < 3:
        return True
    # season-only tokens like 'S01' / 'Season 1'
    if re.fullmatch(r"s\d{1,2}", low) or re.fullmatch(r"season\s*\d{1,2}", low):
        return True
    # no CJK/latin letters at all
    if not re.search(r"[A-Za-z\u4e00-\u9fff]", t):
        return True
    # patterns like "0.mp4" / "52525.mkv"
    if re.fullmatch(r"\d{1,6}\.(mp4|mkv|avi|mov|wmv|flv|ts|m2ts|mpg|mpeg)", low):
        return True

    # common category / collection folders (these frequently appear in 115 shares)
    # We only treat them as garbage when the whole hint looks like a tag bucket.
    tag_words = [
        "全集",
        "全",
        "合集",
        "总集",
        "完结",
        "已完结",
        "更新",
        "更新至",
        "电视剧",
        "电影",
        "动漫",
        "动画",
        "综艺",
        "纪录片",
        "短剧",
        "资源",
        "下载",
        "中字",
        "双语",
        "国语",
        "粤语",
        "英语",
        "4k",
        "8k",
        "hdr",
        "dolby",
        "dovi",
        "remux",
        "bluray",
        "bdrip",
        "web",
        "webrip",
        "web-dl",
        "hdtv",
        "1080p",
        "2160p",
        "720p",
        "x264",
        "x265",
        "hevc",
        "avc",
        "aac",
        "dts",
        "truehd",
    ]
    low2 = low.replace(" ", "").replace("-", "").replace("_", "")
    if any(w in low2 for w in tag_words):
        # remove these tag words and see if anything meaningful remains
        rest = low2
        for w in tag_words:
            rest = rest.replace(w, "")
        # keep CJK/latin sequences only
        rest2 = "".join(re.findall(r"[A-Za-z\u4e00-\u9fff]+", rest))
        if not rest2 or len(rest2) < 3:
            return True

    # duplicated directory names like "xxx/xxx" tend to be structural wrappers
    # and should not become the *only* hint. (We still allow them if there are
    # other stronger hints.)
    parts = [p for p in re.split(r"[\\/]+", t) if p]
    if len(parts) >= 2 and parts[-1].lower() == parts[-2].lower() and len(parts[-1]) <= 16:
        return True
    return False


def clean_hints(hints: Iterable[str], *, max_items: int = 24) -> List[str]:
    """Normalize and de-duplicate hint strings, removing obvious garbage."""
    out: List[str] = []
    seen = set()
    for h in hints:
        if h is None:
            continue
        t = str(h).strip()
        if not t or _is_garbage_hint(t):
            continue
        k = t.lower()
        if k in seen:
            continue
        seen.add(k)
        out.append(t)
        if len(out) >= max_items:
            break
    return out


def pick_best_hint(hints: Iterable[str]) -> Optional[str]:
    """Pick the first hint after cleaning; caller can pass ordered hints."""
    xs = clean_hints(hints)
    return xs[0] if xs else None
