# -*- coding: utf-8 -*-
"""Core hint pack building function.

This module provides the main build_hint_pack function that orchestrates
all hint extraction and processing.
"""
from __future__ import annotations

import re
import datetime
from typing import Any, Dict, List, Optional

from core.logging import get_biz_logger_adapter
from ..ports_access import tmdb
from ..batch_group import EpisodeFile, dedup_by_episode, standard_se_rate
from .hints_validation import _is_garbage_hint, clean_hints
from .hints_extraction import _extract_share_fragment_hint

biz = get_biz_logger_adapter(__name__)
logger = get_biz_logger_adapter(__name__)


def build_hint_pack(
    *,
    share_url: str,
    hint_text: Optional[str],
    season_hint: Optional[int],
    best: Optional[Dict[str, Any]],
    evidence_temp_unavailable: bool = False,
    evidence_weak: bool = False,
) -> Dict[str, Any]:
    """Build a structured hint pack from message + share evidence.

    Returns a dict that contains:
      - hints_main/hints_msg/hints_extra
      - hints2: cleaned unique hints (order-preserved)
      - q_title/q_year: best-effort parsed title/year
      - evidence_texts, season_infer, tvish, season_hint_eff
      - share evidence fields: share_title/filename/hint_name/dir_path/video_samples/video_count/vc_reliable

    This is a pure-ish function; it does not perform IO.
    """
    from .hints_episode import _extract_episode_set

    m = tmdb()

    from ..season import _infer_season_from_texts, _infer_season_guess_from_texts, _has_explicit_season_marker
    from ..scoring import _title_quality_score

    hints_main: List[str] = []
    hints_msg: List[str] = []
    hints_extra: List[str] = []

    share_url = (share_url or "").strip()

    if isinstance(hint_text, str) and hint_text.strip():
        hints_msg.append(hint_text.strip())

    frag_hint = _extract_share_fragment_hint(share_url)
    if frag_hint:
        hints_msg.append(frag_hint)

    fname = ""
    hint_name = ""
    share_title = ""
    dir_path: List[str] = []
    video_samples: List[str] = []
    video_files: List[dict] = []
    video_file_names: List[str] = []
    video_count = 0
    video_count_scope = "unknown"
    best_fallback = False
    vc_reliable = False

    b = best if isinstance(best, dict) else {}
    if b and bool(b.get("ok")):
        fname = str(b.get("filename") or "").strip()
        hint_name = str(b.get("hint_name") or "").strip()
        share_title = str(b.get("share_title") or "").strip()
        best_fallback = bool(b.get("fallback"))
        video_count_scope = str(b.get("video_count_scope") or "unknown")
        try:
            video_count = int(b.get("video_count") or 0)
        except (ValueError, TypeError) as e:
            logger.detail(f"video_count 转换失败（已忽略） - video_count={b.get('video_count')}, 类型={type(b.get('video_count')).__name__}, 原因={type(e).__name__}")
            video_count = 0
        vc_reliable = (not best_fallback) and (video_count_scope in {"root", "folder"}) and (video_count > 0)
        dp = b.get("dir_path")
        if isinstance(dp, list):
            dir_path = [x for x in dp if isinstance(x, str) and x.strip()]

        # Strongest hints first (order matters)
        try:
            has_cjk_share_title = bool(share_title and re.search(r"[一-鿿]", share_title))
        except (ValueError, TypeError, AttributeError) as e:
            logger.detail(f"CJK 检测失败（已忽略） - share_title={share_title}, 原因={type(e).__name__}")
            has_cjk_share_title = False

        def _push_main(x: str) -> None:
            xx = str(x or "").strip()
            if xx and (not _is_garbage_hint(xx)):
                hints_main.append(xx)

        def _push_extra(x: str) -> None:
            xx = str(x or "").strip()
            if xx and (not _is_garbage_hint(xx)):
                hints_extra.append(xx)

        if has_cjk_share_title:
            _push_main(share_title)
        _push_main(fname)
        _push_main(hint_name)

        # Collect sample names (low-priority)
        try:
            vs = b.get("video_samples")
            if isinstance(vs, list) and vs:
                for nm in vs[:5]:
                    if not isinstance(nm, str):
                        continue
                    nm2 = nm.strip()
                    if not nm2 or nm2 in {fname, hint_name}:
                        continue
                    if _is_garbage_hint(nm2):
                        continue
                    _push_extra(nm2)
                    video_samples.append(nm2)
        except (ValueError, TypeError, AttributeError, KeyError) as e:
            logger.detail(f"video_samples 收集失败（已忽略） - 原因={type(e).__name__}")
            pass

        # Collect full video file list (for batch/group inference)
        try:
            vfi = b.get("video_files")
            if isinstance(vfi, list) and vfi:
                for it in vfi[:4000]:
                    if isinstance(it, dict):
                        nm = str(it.get("name") or "").strip()
                        if not nm:
                            continue
                        try:
                            sz = int(it.get("size") or 0)
                        except Exception:
                            sz = 0
                        video_files.append({"name": nm, "size": sz})
                        video_file_names.append(nm)
                    elif isinstance(it, str):
                        nm = it.strip()
                        if nm:
                            video_file_names.append(nm)
        except (ValueError, TypeError, AttributeError, KeyError) as e:
            logger.detail(f"video_files 收集失败（已忽略） - 原因={type(e).__name__}")
            pass

        if not has_cjk_share_title:
            _push_main(share_title)

        dir_candidates: List[str] = []
        for dn in dir_path[:8]:
            low = dn.lower()
            if low in {"bdmv", "stream", "playlist", "menu", "menus", "extras", "extra"}:
                continue
            if _is_garbage_hint(dn):
                continue
            dir_candidates.append(dn)
        if dir_candidates:
            dir_candidates.sort(key=lambda x: len(x), reverse=True)
            _push_main(dir_candidates[0])

    # Merge hints and clean
    hints = hints_main + hints_msg + hints_extra
    hints2 = clean_hints(hints, max_items=24)

    def _pick_best_title_year(*sources: str) -> tuple[str, Optional[int]]:
        best_t = ""
        best_y: Optional[int] = None
        best_sc = -1e9
        for s0 in sources:
            try:
                t0, y0, _s = m.parse_title_year_from_filename(str(s0 or ""))
            except (ValueError, TypeError, AttributeError, KeyError) as e:
                logger.detail(f"标题年份解析失败（已忽略） - s0={s0}, 原因={type(e).__name__}")
                continue
            if not t0:
                continue
            t0s = str(t0).strip()
            sc = _title_quality_score(t0s)
            # Source preference: share_title (often CN) should win against inner filenames
            # when quality is similar, to avoid alias collisions.
            try:
                if share_title and str(s0 or "").strip() == share_title:
                    # share_title is a human-chosen label; treat it as highest-signal.
                    sc += 14.0
            except (ValueError, TypeError, AttributeError) as e:
                logger.detail(f"share_title 比较失败（已忽略） - s0={s0}, share_title={share_title}, 原因={type(e).__name__}")
                pass
            if sc > best_sc:
                best_sc = sc
                best_t = t0s
                best_y = (int(y0) if y0 is not None else None)
        return best_t, best_y

    # Batch title (multi-episode): when we have many filenames, derive a stable common series title.
    batch_title = ""
    try:
        if isinstance(video_file_names, list) and len(video_file_names) >= 2:
            t_cands = []
            for nm in video_file_names[:50]:
                try:
                    t0, _y0, _ = m.parse_title_year_from_filename(str(nm or ""))
                except Exception as e:
                    biz.detail("ignored exception in _pick_best_title_year", exc_info=True)
                    continue
                t0 = str(t0 or "").strip()
                if t0:
                    t_cands.append(t0)
            if t_cands:
                from collections import Counter
                batch_title = Counter(t_cands).most_common(1)[0][0]
    except (ValueError, TypeError, AttributeError, KeyError, IndexError) as e:
        logger.detail(f"批量标题提取失败（已忽略） - 原因={type(e).__name__}")
        batch_title = ""

    # NOTE: share_title first (best human label); filenames later (may contain aliases)
    q_title, q_year = _pick_best_title_year(
        share_title,
        batch_title,
        fname,
        hint_name,
        *(dir_path or []),
        *(hints2 or []),
    )

    # Year rescue: sometimes best title comes from a source without year (e.g. share link without fragment).
    # If we still have no year, scan all evidence texts for a plausible 19xx/20xx year.
    if q_year is None:
        try:
            _yr_re = re.compile(r"(?:19\d{2}|20\d{2})")
            _cands: List[int] = []
            for _s in [fname, hint_name, share_title, hint_text, share_url] + list(dir_path or []) + list(hints2 or []):
                if not _s:
                    continue
                for _m in _yr_re.findall(str(_s)):
                    try:
                        _cands.append(int(_m))
                    except (ValueError, TypeError) as e:
                        logger.detail(f"年份候选提取失败（已忽略） - _m={_m}, 原因={type(e).__name__}")
                        pass
            if _cands:
                # choose the most frequent year; tie-break by being closest to current year
                _now = datetime.datetime.now().year
                from collections import Counter
                _cnt = Counter(_cands)
                _best = sorted(_cnt.items(), key=lambda kv: (-kv[1], abs(kv[0] - _now)))[0][0]
                q_year = int(_best)
        except (ValueError, TypeError, AttributeError, KeyError, IndexError) as e:
            logger.detail(f"年份选择失败（已忽略） - 原因={type(e).__name__}")
            pass

    evidence_texts: List[str] = []
    for _x in [fname, hint_name, share_title, *(dir_path or []), *(video_file_names or []), *(video_samples or []), *(hints_msg or [])]:
        try:
            _xs = str(_x or "").strip()
        except (ValueError, TypeError, AttributeError) as e:
            logger.detail(f"证据文本转换失败（已忽略） - _x={_x}, 类型={type(_x).__name__}, 原因={type(e).__name__}")
            _xs = ""
        if _xs and (_xs not in evidence_texts):
            evidence_texts.append(_xs)

    season_guess = _infer_season_guess_from_texts(evidence_texts)
    season_infer = season_guess.season
    try:
        tvish = any(m.detect_tv_hint(x) for x in evidence_texts[:12])
    except (ValueError, TypeError, AttributeError, KeyError) as e:
        logger.detail(f"TV 提示检测失败（已忽略） - 原因={type(e).__name__}")
        tvish = False

    season_hint_eff: Optional[int] = season_hint if season_hint is not None else season_infer
    explicit_season = bool(season_hint is not None) or _has_explicit_season_marker(evidence_texts)


    # ------------------------------------------------------------
    # Batch/group evidence: episode-set extraction
    # ------------------------------------------------------------
    # Use video_samples first (highest-signal filenames), then fallback to other evidence.
    ep_season_from_name, ep_list = _extract_episode_set(list(video_file_names or []) + list(video_samples or []) + list(evidence_texts or []))
    episode_set = ep_list
    episode_count = len(episode_set or [])
    # If we found an explicit SxxEyy season marker, prefer it over heuristic season inference.
    if season_hint_eff is None and isinstance(ep_season_from_name, int) and ep_season_from_name > 0:
        season_hint_eff = int(ep_season_from_name)

    standard_rate = 0.0
    try:
        standard_rate = float(standard_se_rate(video_file_names or video_samples))
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"标准化率计算失败（已忽略） - 原因={type(e).__name__}")
        standard_rate = 0.0

    # Quality dedup: choose best release per episode (only when we have a real file list).
    episode_best_files: List[dict] = []
    episode_dup_count = 0
    try:
        if video_files and (season_hint_eff is not None or episode_count >= 2):
            ep_files = [
                EpisodeFile(name=str(it.get("name") or ""), size=int(it.get("size") or 0))
                for it in (video_files or [])
                if isinstance(it, dict) and str(it.get("name") or "").strip()
            ]
            best_map, dups = dedup_by_episode(ep_files, season_hint=season_hint_eff)
            episode_best_files = [
                {"episode": int(e), "name": f.name, "size": int(f.size or 0)}
                for e, f in sorted(best_map.items(), key=lambda kv: kv[0])
            ]
            episode_dup_count = int(len(dups))
    except (ValueError, TypeError, AttributeError, KeyError) as e:
        logger.detail(f"质量去重失败（已忽略） - 原因={type(e).__name__}")
        episode_best_files = []
        episode_dup_count = 0

    has_msg_hints = bool(hints_msg)
    # IMPORTANT (human-readable-logs + correctness):
    # Do NOT force TV purely because of a *loose* season inference (which can be noisy).
    # Only force TV when we have explicit season markers / tvish cues / multi-file episode evidence.
    force_mt: Optional[str] = "tv" if (tvish or explicit_season or episode_count >= 2) else ("tv" if (vc_reliable and video_count >= 6) else None)

    # Evidence level (for auto-pick gating)
    # L0: 115 temporary unavailable (no reliable evidence)
    # L1: folder/title-only (no actual video filenames) -> NEVER auto-pick
    # L2: at least 1 real video filename sample
    # L3: multiple video samples or reliable multi-file count
    try:
        vsn = len(video_samples or [])
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"video_samples 长度计算失败（已忽略） - 原因={type(e).__name__}")
        vsn = 0
    # paging consistency (115 API can lie about count; missing items makes episode evidence unreliable)
    paging: dict = {}
    try:
        paging = dict((best or {}).get("paging") or {}) if isinstance(best, dict) else {}
    except (ValueError, TypeError, AttributeError, KeyError) as e:
        logger.detail(f"paging 字典提取失败（已忽略） - 原因={type(e).__name__}")
        paging = {}
    try:
        count_mismatch = bool(paging.get("count_mismatch"))
    except (ValueError, TypeError, AttributeError, KeyError) as e:
        logger.detail(f"count_mismatch 提取失败（已忽略） - 原因={type(e).__name__}")
        count_mismatch = False

    if evidence_temp_unavailable:
        evidence_level = 0
        evidence_level_desc = "L0:share_unavailable"
    elif vsn >= 3 or (vc_reliable and video_count >= 6):
        evidence_level = 3
        evidence_level_desc = "L3:multi_video_samples"
    elif vsn >= 1:
        evidence_level = 2
        evidence_level_desc = "L2:video_sample"
    else:
        evidence_level = 1
        evidence_level_desc = "L1:title_only"

    # If 115 reported a different total count than what we could actually page,
    # treat the evidence as weaker: episode_set/video_files might be incomplete.
    # We *do not* drop to L0, but we do make auto-pick more conservative.
    if count_mismatch and evidence_level >= 2:
        evidence_level = max(1, evidence_level - 1)
        evidence_level_desc = f"{evidence_level_desc}:count_mismatch"

    # ------------------------------------------------------------
    # Subtitle group detection (Requirement 5)
    # ------------------------------------------------------------
    from .hints_subtitle import extract_all_subtitle_groups, get_subtitle_group_quality_score
    
    subtitle_groups = []
    subtitle_group_names = []
    subtitle_group_quality = 0.0
    try:
        # Scan evidence texts for subtitle group tags
        subtitle_groups = extract_all_subtitle_groups(evidence_texts)
        subtitle_group_names = [g.name for g in subtitle_groups]
        # Use the highest quality score among detected groups
        if subtitle_groups:
            subtitle_group_quality = max(get_subtitle_group_quality_score(g) for g in subtitle_groups)
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"字幕组检测失败（已忽略） - 原因={type(e).__name__}")
        subtitle_groups = []
        subtitle_group_names = []
        subtitle_group_quality = 0.0

    return {
        "hints_main": hints_main,
        "hints_msg": hints_msg,
        "hints_extra": hints_extra,
        "hints2": hints2,
        "q_title": q_title,
        "q_year": q_year,
        "evidence_texts": evidence_texts,
        "season_infer": season_infer,
        "season_level": str(getattr(season_guess, "level", "none") or "none"),
        "season_source": str(getattr(season_guess, "source", "无") or "无"),
        "tvish": tvish,
        "season_hint_eff": season_hint_eff,
        "episode_set": episode_set,
        "episode_count": int(episode_count),
        "standard_rate": float(standard_rate),
        "batch_title": str(batch_title or ""),
        "episode_best_files": episode_best_files,
        "episode_dup_count": int(episode_dup_count),
        "count_mismatch": bool(count_mismatch),
        "paging": paging,
        "has_msg_hints": has_msg_hints,
        "force_mt": force_mt,
        "share_title": share_title,
        "filename": fname,
        "hint_name": hint_name,
        "dir_path": dir_path,
        "video_samples": video_samples,
        "video_count": video_count,
        "video_files": video_files,
        "vc_reliable": vc_reliable,
        "evidence_temp_unavailable": bool(evidence_temp_unavailable),
        "evidence_weak": bool(evidence_weak),
        "evidence_level": int(evidence_level),
        "evidence_level_desc": str(evidence_level_desc),
        # Subtitle group info (Requirement 5)
        "subtitle_groups": subtitle_groups,
        "subtitle_group_names": subtitle_group_names,
        "subtitle_group_quality": float(subtitle_group_quality),
    }
