# -*- coding: utf-8 -*-
"""Subtitle group detection functions.

This module provides functions for detecting and extracting subtitle group
information from filenames and share titles.

Requirement 5: 字幕组识别
- 5.1: 检测常见字幕组标签
- 5.2: 提取字幕组元数据
- 5.3: 集成到 hint_pack
- 5.5: 支持多种标签格式
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set

from core.logging import get_biz_logger_adapter

logger = get_biz_logger_adapter(__name__)


@dataclass
class SubtitleGroupInfo:
    """Subtitle group metadata.
    
    Attributes:
        name: Canonical name of the subtitle group
        quality: Quality tier ("standard", "high", "premium")
        region: Primary region ("CN", "JP", "KR", "TW", "HK", etc.)
        tags: Content type tags (e.g., ["动漫"], ["电影", "电视剧"])
        aliases: Alternative names/spellings for the group
    """
    name: str
    quality: str = "standard"  # "standard", "high", "premium"
    region: str = "CN"
    tags: List[str] = field(default_factory=list)
    aliases: List[str] = field(default_factory=list)


# Known subtitle groups database
# Quality tiers:
# - premium: Top-tier groups known for exceptional quality
# - high: Well-known groups with consistent quality
# - standard: Other recognized groups
SUBTITLE_GROUPS: Dict[str, SubtitleGroupInfo] = {
    # Premium tier - exceptional quality
    "VCB-Studio": SubtitleGroupInfo(
        "VCB-Studio", "premium", "JP", 
        ["动漫", "高码率"], 
        ["VCB", "VCB-S"]
    ),
    "FZSD": SubtitleGroupInfo(
        "FZSD", "premium", "CN", 
        ["电视剧"], 
        ["风之圣殿"]
    ),
    
    # High tier - well-known groups
    "CASO": SubtitleGroupInfo(
        "CASO", "high", "CN", 
        ["动漫"], 
        []
    ),
    "ANi": SubtitleGroupInfo(
        "ANi", "high", "JP", 
        ["动漫"], 
        ["ANi-Sub"]
    ),
    "CMCT": SubtitleGroupInfo(
        "CMCT", "high", "CN", 
        ["电影"], 
        ["春天"]
    ),
    "CHD": SubtitleGroupInfo(
        "CHD", "high", "CN", 
        ["电影"], 
        ["CHDBits"]
    ),
    "MTeam": SubtitleGroupInfo(
        "MTeam", "high", "CN", 
        ["综合"], 
        ["MT", "馒头"]
    ),
    "HDSky": SubtitleGroupInfo(
        "HDSky", "high", "CN", 
        ["综合"], 
        ["天空"]
    ),
    "PTer": SubtitleGroupInfo(
        "PTer", "high", "CN", 
        ["综合"], 
        ["猫站"]
    ),
    "FRDS": SubtitleGroupInfo(
        "FRDS", "high", "CN", 
        ["综合"], 
        []
    ),
    "HDCTV": SubtitleGroupInfo(
        "HDCTV", "high", "CN", 
        ["电视剧"], 
        []
    ),
    "WiKi": SubtitleGroupInfo(
        "WiKi", "high", "CN", 
        ["综合"], 
        []
    ),
    "CHDWEB": SubtitleGroupInfo(
        "CHDWEB", "high", "CN", 
        ["综合"], 
        []
    ),
    "CHDPAD": SubtitleGroupInfo(
        "CHDPAD", "high", "CN", 
        ["综合"], 
        []
    ),
    
    # Anime-focused groups
    "Lilith-Raws": SubtitleGroupInfo(
        "Lilith-Raws", "high", "JP", 
        ["动漫"], 
        ["Lilith"]
    ),
    "LoliHouse": SubtitleGroupInfo(
        "LoliHouse", "high", "JP", 
        ["动漫"], 
        []
    ),
    "NC-Raws": SubtitleGroupInfo(
        "NC-Raws", "high", "JP", 
        ["动漫"], 
        ["NC"]
    ),
    "Nekomoe": SubtitleGroupInfo(
        "Nekomoe", "high", "JP", 
        ["动漫"], 
        ["喵萌"]
    ),
    "Sakurato": SubtitleGroupInfo(
        "Sakurato", "high", "JP", 
        ["动漫"], 
        []
    ),
    "SweetSub": SubtitleGroupInfo(
        "SweetSub", "high", "JP", 
        ["动漫"], 
        []
    ),
    "SubsPlease": SubtitleGroupInfo(
        "SubsPlease", "high", "JP", 
        ["动漫"], 
        []
    ),
    "Erai-raws": SubtitleGroupInfo(
        "Erai-raws", "high", "JP", 
        ["动漫"], 
        ["Erai"]
    ),
    
    # Chinese subtitle groups
    "人人影视": SubtitleGroupInfo(
        "人人影视", "high", "CN", 
        ["电视剧", "电影"], 
        ["YYeTs", "人人"]
    ),
    "字幕组": SubtitleGroupInfo(
        "字幕组", "standard", "CN", 
        ["综合"], 
        []
    ),
    "FIX字幕侠": SubtitleGroupInfo(
        "FIX字幕侠", "high", "CN", 
        ["电视剧"], 
        ["FIX"]
    ),
    "NEW字幕组": SubtitleGroupInfo(
        "NEW字幕组", "high", "CN", 
        ["电视剧"], 
        ["NEW"]
    ),
    "深影字幕组": SubtitleGroupInfo(
        "深影字幕组", "high", "CN", 
        ["电视剧"], 
        ["深影"]
    ),
    "擦枪字幕组": SubtitleGroupInfo(
        "擦枪字幕组", "high", "CN", 
        ["电视剧"], 
        ["擦枪"]
    ),
    
    # Korean drama groups
    "韩迷": SubtitleGroupInfo(
        "韩迷", "high", "KR", 
        ["韩剧"], 
        []
    ),
    "TSKS": SubtitleGroupInfo(
        "TSKS", "high", "KR", 
        ["韩剧"], 
        ["韩剧社"]
    ),
    
    # Standard tier
    "RARBG": SubtitleGroupInfo(
        "RARBG", "standard", "EN", 
        ["综合"], 
        []
    ),
    "YTS": SubtitleGroupInfo(
        "YTS", "standard", "EN", 
        ["电影"], 
        ["YIFY"]
    ),
    "SPARKS": SubtitleGroupInfo(
        "SPARKS", "standard", "EN", 
        ["电影"], 
        []
    ),
    "GECKOS": SubtitleGroupInfo(
        "GECKOS", "standard", "EN", 
        ["电影"], 
        []
    ),
}

# Build reverse lookup for aliases
_ALIAS_TO_GROUP: Dict[str, str] = {}
for group_name, info in SUBTITLE_GROUPS.items():
    _ALIAS_TO_GROUP[group_name.lower()] = group_name
    for alias in info.aliases:
        _ALIAS_TO_GROUP[alias.lower()] = group_name


# Patterns for subtitle group detection
_SUBTITLE_GROUP_PATTERNS = [
    # [Group-Name] - most common format (supports CJK)
    re.compile(r"\[([A-Za-z0-9\-_\u4e00-\u9fff]+(?:[-_][A-Za-z0-9\u4e00-\u9fff]+)*)\]"),
    # 【字幕组】 - Chinese brackets
    re.compile(r"【([A-Za-z0-9\-_\u4e00-\u9fff]+)】"),
    # @Group - at-mention style
    re.compile(r"@([A-Za-z0-9\-_\u4e00-\u9fff]+)"),
    # (Group) - parentheses (supports CJK)
    re.compile(r"\(([A-Za-z0-9\-_\u4e00-\u9fff]+(?:[-_][A-Za-z0-9\u4e00-\u9fff]+)*)\)"),
]


def detect_subtitle_group(text: str) -> Optional[SubtitleGroupInfo]:
    """Detect subtitle group from text.
    
    Searches for known subtitle group tags in various formats:
    - [CASO], [ANi], [VCB-Studio]
    - 【字幕组】
    - @Group
    - (Group)
    
    Args:
        text: Text to search for subtitle group tags
        
    Returns:
        SubtitleGroupInfo if a known group is found, None otherwise.
    """
    if not text:
        return None
    
    t = str(text or "").strip()
    if not t:
        return None
    
    # Try each pattern
    for pattern in _SUBTITLE_GROUP_PATTERNS:
        try:
            for match in pattern.finditer(t):
                group_tag = match.group(1).strip()
                if not group_tag:
                    continue
                
                # Look up in known groups (case-insensitive)
                group_key = group_tag.lower()
                if group_key in _ALIAS_TO_GROUP:
                    canonical_name = _ALIAS_TO_GROUP[group_key]
                    return SUBTITLE_GROUPS[canonical_name]
        except (ValueError, TypeError, AttributeError, IndexError) as e:
            logger.detail(f"字幕组检测失败（已忽略） - text={t[:50]}, 原因={type(e).__name__}")
            continue
    
    return None


def extract_all_subtitle_groups(texts: List[str]) -> List[SubtitleGroupInfo]:
    """Extract all subtitle groups from multiple texts.
    
    Scans all provided texts and returns unique subtitle groups found.
    
    Args:
        texts: List of texts to search
        
    Returns:
        List of unique SubtitleGroupInfo objects found.
    """
    if not texts:
        return []
    
    found: Dict[str, SubtitleGroupInfo] = {}
    
    for text in texts:
        if not text:
            continue
        
        t = str(text or "").strip()
        if not t:
            continue
        
        # Try each pattern
        for pattern in _SUBTITLE_GROUP_PATTERNS:
            try:
                for match in pattern.finditer(t):
                    group_tag = match.group(1).strip()
                    if not group_tag:
                        continue
                    
                    # Look up in known groups (case-insensitive)
                    group_key = group_tag.lower()
                    if group_key in _ALIAS_TO_GROUP:
                        canonical_name = _ALIAS_TO_GROUP[group_key]
                        if canonical_name not in found:
                            found[canonical_name] = SUBTITLE_GROUPS[canonical_name]
            except (ValueError, TypeError, AttributeError, IndexError) as e:
                logger.detail(f"字幕组提取失败（已忽略） - text={t[:50]}, 原因={type(e).__name__}")
                continue
    
    return list(found.values())


def get_subtitle_group_quality_score(info: Optional[SubtitleGroupInfo]) -> float:
    """Get quality score for a subtitle group.
    
    Args:
        info: SubtitleGroupInfo or None
        
    Returns:
        Quality score: 1.0 for premium, 0.7 for high, 0.4 for standard, 0.0 for unknown
    """
    if info is None:
        return 0.0
    
    quality_scores = {
        "premium": 1.0,
        "high": 0.7,
        "standard": 0.4,
    }
    
    return quality_scores.get(info.quality, 0.0)


def is_anime_subtitle_group(info: Optional[SubtitleGroupInfo]) -> bool:
    """Check if subtitle group is anime-focused.
    
    Args:
        info: SubtitleGroupInfo or None
        
    Returns:
        True if the group is known for anime content.
    """
    if info is None:
        return False
    
    return "动漫" in info.tags
