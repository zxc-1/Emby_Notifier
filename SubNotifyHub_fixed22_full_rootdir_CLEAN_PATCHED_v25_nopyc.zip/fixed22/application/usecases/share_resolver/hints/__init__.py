# -*- coding: utf-8 -*-
"""Hint extraction/cleaning for share TMDB resolver.

This package provides modular hint processing functionality:
- hints_validation: Hint validation and cleaning
- hints_detection: Content type detection (multi-season, mixed, part, regional)
- hints_extraction: Hint extraction from various sources
- hints_episode: Episode set extraction and processing
- hints_subtitle: Subtitle group detection and metadata
- hints_core: Main build_hint_pack function

All public functions are re-exported here for backward compatibility.
"""
from __future__ import annotations

# Re-export all public functions for backward compatibility
from .hints_validation import (
    _is_garbage_hint,
    _is_generic_share_title,
    _fast_hint_strong,
    clean_hints,
    pick_best_hint,
)

from .hints_detection import (
    _detect_multi_season_markers,
    _detect_mixed_content,
    _detect_part_markers,
    _detect_regional_version,
)

from .hints_extraction import (
    _extract_share_fragment_hint,
    _extract_batch_title,
    _extract_strict_year,
    _prioritize_video_samples,
)

from .hints_episode import (
    _extract_episode_set,
)

from .hints_subtitle import (
    SubtitleGroupInfo,
    SUBTITLE_GROUPS,
    detect_subtitle_group,
    extract_all_subtitle_groups,
    get_subtitle_group_quality_score,
    is_anime_subtitle_group,
)

from .hints_core import (
    build_hint_pack,
)

__all__ = [
    # Validation
    "_is_garbage_hint",
    "_is_generic_share_title",
    "_fast_hint_strong",
    "clean_hints",
    "pick_best_hint",
    # Detection
    "_detect_multi_season_markers",
    "_detect_mixed_content",
    "_detect_part_markers",
    "_detect_regional_version",
    # Extraction
    "_extract_share_fragment_hint",
    "_extract_batch_title",
    "_extract_strict_year",
    "_prioritize_video_samples",
    # Episode
    "_extract_episode_set",
    # Subtitle
    "SubtitleGroupInfo",
    "SUBTITLE_GROUPS",
    "detect_subtitle_group",
    "extract_all_subtitle_groups",
    "get_subtitle_group_quality_score",
    "is_anime_subtitle_group",
    # Core
    "build_hint_pack",
]
