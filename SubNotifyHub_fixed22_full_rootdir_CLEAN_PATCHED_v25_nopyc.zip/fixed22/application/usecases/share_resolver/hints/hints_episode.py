# -*- coding: utf-8 -*-
"""Episode set extraction functions.

This module provides functions for extracting episode information:
- _extract_episode_set: Extract episode numbers from evidence texts
"""
from __future__ import annotations

import re
from typing import List, Optional, Tuple

from core.logging import get_biz_logger_adapter

logger = get_biz_logger_adapter(__name__)


def _extract_episode_set(texts: List[str]) -> Tuple[Optional[int], List[int]]:
    """Extract episode set from evidence texts.
    
    Scans evidence texts for episode markers (S01E03, EP12, 第3集, etc.)
    and returns the detected season and sorted unique episode numbers.
    
    Returns:
        Tuple of (season_from_marker, sorted_unique_episodes)
        - season_from_marker: The most frequent season number found, or None
        - sorted_unique_episodes: List of unique episode numbers, sorted
    """
    if not texts:
        return None, []
    
    s_cands: List[int] = []
    eps: List[int] = []
    
    # Common scene formats: S01E03 / s1e3 / S01E03E04
    re_se = re.compile(r"(?i)\bS(?P<s>\d{1,2})\s*E(?P<e>\d{1,3})\b")
    re_e = re.compile(r"(?i)(?:\bEP?\s*)(?P<e>\d{1,3})\b")
    re_cn = re.compile(r"第\s*(?P<e>\d{1,3})\s*集")
    
    for t in texts:
        tt = str(t or "")
        if not tt:
            continue
        
        # Extract SxxEyy patterns
        for m in re_se.finditer(tt):
            try:
                s_cands.append(int(m.group("s")))
                eps.append(int(m.group("e")))
            except (ValueError, TypeError, AttributeError) as e:
                logger.detail(f"剧集解析失败（已忽略） - s={m.group('s')}, e={m.group('e')}, 原因={type(e).__name__}")
        
        # Extract Chinese episode patterns
        for m in re_cn.finditer(tt):
            try:
                eps.append(int(m.group("e")))
            except (ValueError, TypeError, AttributeError) as e:
                logger.detail(f"中文剧集解析失败（已忽略） - e={m.group('e')}, 原因={type(e).__name__}")

    # Only use bare E12 / EP12 when we already have SxxEyy somewhere in evidence.
    if s_cands:
        for t in texts:
            tt = str(t or "")
            if not tt:
                continue
            for m in re_e.finditer(tt):
                try:
                    eps.append(int(m.group("e")))
                except (ValueError, TypeError, AttributeError) as e:
                    logger.detail(f"裸剧集号解析失败（已忽略） - e={m.group('e')}, 原因={type(e).__name__}")

    # Normalize season
    s0: Optional[int] = None
    try:
        if s_cands:
            # Choose the most frequent season marker
            from collections import Counter
            s0 = int(sorted(Counter(s_cands).items(), key=lambda kv: (-kv[1], kv[0]))[0][0])
    except (ValueError, TypeError, AttributeError, KeyError, IndexError) as e:
        logger.detail(f"季度选择失败（已忽略） - 原因={type(e).__name__}")
        s0 = None

    # Normalize episodes
    eps2: List[int] = []
    try:
        seen: set[int] = set()
        for e in eps:
            if not isinstance(e, int):
                continue
            if e <= 0 or e > 2000:
                continue
            if e in seen:
                continue
            seen.add(e)
            eps2.append(e)
        eps2.sort()
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"剧集列表规范化失败（已忽略） - 原因={type(e).__name__}")
        eps2 = []
    
    return s0, eps2
