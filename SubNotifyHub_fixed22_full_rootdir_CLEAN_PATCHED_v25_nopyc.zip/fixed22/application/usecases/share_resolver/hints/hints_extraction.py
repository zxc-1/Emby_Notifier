# -*- coding: utf-8 -*-
"""Hint extraction functions.

This module provides functions for extracting hints from various sources:
- _extract_share_fragment_hint: Extract hint from URL fragment
- _extract_batch_title: Extract common title from batch filenames
- _extract_strict_year: Extract explicit year from CJK titles
- _prioritize_video_samples: Prioritize video samples when title is generic
"""
from __future__ import annotations

import re
from typing import List, Optional
from urllib.parse import unquote, urlparse

from core.logging import get_biz_logger_adapter
from ..ports_access import tmdb
from ..constants import VIDEO_SAMPLE_PRIORITY_ENABLED
from .hints_validation import _is_garbage_hint, _is_generic_share_title

logger = get_biz_logger_adapter(__name__)


def _extract_share_fragment_hint(share_url: str) -> str:
    """Extract hint from URL fragment (e.g., ...#Title.2025.S01...).
    
    Many clients copy links with title information in the fragment.
    
    Returns:
        Extracted hint string, or empty string if none found.
    """
    u = (share_url or '').strip()
    if not u:
        return ''
    try:
        p = urlparse(u)
        frag = unquote(p.fragment or '').strip()
    except (ValueError, TypeError, AttributeError) as e:
        logger.detail(f"URL 解析失败（已忽略） - url={u[:100]}, 原因={type(e).__name__}")
        return ''
    if not frag:
        return ''
    frag = frag.replace('115App', ' ')
    frag = re.sub(r'\s+', ' ', frag).strip()
    m = re.search(r'[一-鿿]', frag)
    if m and m.start() >= 12:
        frag = frag[: m.start()].strip(' _-#')
    if len(frag) > 200:
        frag = frag[:200].strip(' _-#')
    return frag


def _extract_strict_year(title: str) -> Optional[int]:
    """Extract explicit year from CJK title like "剧名(2025)" (Requirement 16.1).
    
    This is stricter than general year extraction - only matches years that are
    explicitly marked with parentheses or brackets in CJK titles.
    
    Returns:
        Year as int if found, None otherwise.
    """
    t = (title or "").strip()
    if not t:
        return None
    
    # Only apply to titles with CJK characters
    if not re.search(r"[\u4e00-\u9fff]", t):
        return None
    
    # Match patterns like: 剧名(2025), 剧名（2025）, 剧名[2025]
    patterns = [
        r"[（(]\s*((?:19|20)\d{2})\s*[）)]",  # (2025) or （2025）
        r"\[\s*((?:19|20)\d{2})\s*\]",         # [2025]
    ]
    
    for pat in patterns:
        try:
            m = re.search(pat, t)
            if m:
                return int(m.group(1))
        except (ValueError, TypeError, AttributeError) as e:
            logger.detail(f"严格年份提取失败（已忽略） - pattern={pat}, 原因={type(e).__name__}")
            continue
    
    return None


def _prioritize_video_samples(
    hints_main: List[str],
    hints_extra: List[str],
    video_samples: List[str],
    share_title: str,
) -> tuple[List[str], List[str]]:
    """Prioritize video_samples when share_title is generic (Requirement 1.1, 1.2).
    
    When the share_title is detected as generic (e.g., "合集", "资源"),
    move video_samples from hints_extra to hints_main for better TMDB matching.
    
    Returns:
        Tuple of (updated_hints_main, updated_hints_extra)
    """
    if not VIDEO_SAMPLE_PRIORITY_ENABLED:
        return hints_main, hints_extra
    
    if not _is_generic_share_title(share_title):
        return hints_main, hints_extra
    
    if not video_samples:
        return hints_main, hints_extra
    
    # Move video samples to main hints
    new_main = list(hints_main)
    new_extra = list(hints_extra)
    
    for sample in video_samples[:3]:  # Limit to top 3 samples
        sample = (sample or "").strip()
        if not sample:
            continue
        if sample in new_main:
            continue
        if _is_garbage_hint(sample):
            continue
        # Insert at the beginning for higher priority
        new_main.insert(0, sample)
        # Remove from extra if present
        if sample in new_extra:
            new_extra.remove(sample)
    
    return new_main, new_extra


def _extract_batch_title(video_file_names: List[str]) -> str:
    """Extract common batch title from multiple video filenames (Requirement 1.3).
    
    When a share contains multiple episodes, extract the most common series title
    from the filenames to use as a stable hint.
    
    Returns:
        The most common title, or empty string if none found.
    """
    if not video_file_names or len(video_file_names) < 2:
        return ""
    
    m = tmdb()
    t_cands: List[str] = []
    
    for nm in video_file_names[:50]:  # Limit to first 50 files
        try:
            t0, _y0, _ = m.parse_title_year_from_filename(str(nm or ""))
        except (ValueError, TypeError, AttributeError, KeyError) as e:
            logger.detail(f"批量标题解析失败（已忽略） - nm={nm}, 原因={type(e).__name__}")
            continue
        t0 = str(t0 or "").strip()
        if t0 and not _is_garbage_hint(t0):
            t_cands.append(t0)
    
    if not t_cands:
        return ""
    
    try:
        from collections import Counter
        return Counter(t_cands).most_common(1)[0][0]
    except (ValueError, TypeError, IndexError, KeyError) as e:
        logger.detail(f"批量标题计数失败（已忽略） - 原因={type(e).__name__}")
        return ""
