from __future__ import annotations

"""Season inference helpers for share TMDB resolver.

Pure functions.

Regression note (vs 1.5.8):
- Older code accepted Chinese numerals like “第二季/第五季”.
- The refactor in 1.6.x accidentally only matched digits (“第2季”), causing
  season hints to be dropped and TV subscriptions to fall back to "全季".

This module restores Chinese numeral support.
"""
import re
from dataclasses import dataclass
from typing import List, Optional

from core.logging import get_biz_logger_adapter
from core.suppress import suppress

logger = get_biz_logger_adapter(__name__)

@dataclass(frozen=True)
class SeasonGuess:
    """Season inference result with explainability.

    level:
      - explicit: explicit season markers (S01/Season 1/第X季)
      - weak: loose fallback (e.g. LokiS01 glued without separators)
      - none: no season inferred
    source:
      A short human-readable description of where the season came from.
    """

    season: Optional[int]
    level: str
    source: str


# Season markers (best-effort):
# - S01 / S1 / Season 1
# - 第1季 / 第01季 / 第二季 / 第五季
_SEASON_RE = re.compile(r"\b(?:S|Season)\s*[._-]?(\d{1,2})\b", re.IGNORECASE)
_CN_SEASON_RE = re.compile(r"第\s*([0-9]{1,3}|[一二三四五六七八九十百两〇零]{1,6})\s*季", re.UNICODE)

# Guard: avoid false-positive seasons from audio channel tags such as "DTS5.1".
# Note: many release names use dot as separator, so we cannot rely on word boundaries.
_AUDIO_GUARD_RE = re.compile(
    r"(?i)DTS(?:[-._ ]?HD(?:[-._ ]?MA)?)?\s*\d{1,2}(?:\.\d)?"
)


def _strip_audio_tokens(text: str) -> str:
    """Remove common audio tokens that can create fake 'S\\d' season hits (e.g. DTS5.1)."""
    try:
        return _AUDIO_GUARD_RE.sub(" ", str(text or ""))
    except Exception as e:
        return suppress(site="share_resolver/season:strip_audio_tokens", exc=e, fallback=str(text or ""))


def _has_explicit_season_marker(texts: List[str]) -> bool:
    """Whether texts contain explicit season markers (NOT counting the loose fallback S\\d)."""
    for raw in (texts or []):
        t = _strip_audio_tokens(str(raw or "").strip())
        if not t:
            continue
        if _SEASON_RE.search(t):
            return True
        if _CN_SEASON_RE.search(t):
            return True
    return False


def _zh_num_to_int(s: str) -> Optional[int]:
    """Very small Chinese numeral -> int converter (1..199).

    Supports: 一二三四五六七八九十百两〇零 and arabic digits.
    """
    if not s:
        return None
    s0 = str(s).strip()
    if not s0:
        return None
    if s0.isdigit():
        try:
            v = int(s0)
            return v if v > 0 else None
        except (ValueError, TypeError) as e:
            logger.detail(f"数字字符串转换失败（已忽略） - s0={s0}, 原因={type(e).__name__}")
            return None

    m = {
        "零": 0,
        "〇": 0,
        "一": 1,
        "二": 2,
        "两": 2,
        "三": 3,
        "四": 4,
        "五": 5,
        "六": 6,
        "七": 7,
        "八": 8,
        "九": 9,
    }

    # "十" special cases
    if s0 == "十":
        return 10

    total = 0
    try:
        if "百" in s0:
            a, b = s0.split("百", 1)
            total += (m.get(a, 0) or 0) * 100
            s0 = b
        if "十" in s0:
            a, b = s0.split("十", 1)
            # "十X" means 10+X; "二十" means 20; "二十三" means 23
            total += ((m.get(a, 1) if a else 1) or 1) * 10
            s0 = b
        if s0:
            total += (m.get(s0, 0) or 0)
    except (ValueError, TypeError, KeyError) as e:
        logger.detail(f"中文数字转换失败（已忽略） - s={s!r}, 原因={type(e).__name__}")
        return None

    return total if total > 0 else None


def _infer_season_from_texts(texts: List[str]) -> Optional[int]:
    """Backward-compatible wrapper returning only the season number (if any)."""
    return _infer_season_guess_from_texts(texts).season


def _infer_season_guess_from_texts(texts: List[str]) -> SeasonGuess:
    """Best-effort season inference from filenames/dir names.

    Returns SeasonGuess with level+source for human-readable logs.
    """
    # Record any audio-channel tokens we filtered out, so the caller can log it.
    audio_hits: List[str] = []
    for raw in (texts or []):
        try:
            _raw = str(raw or "")
        except Exception as e:
            suppress(site="share_resolver/season:str_raw", exc=e, fallback="")
            _raw = ""
        if not _raw:
            continue
        try:
            audio_hits.extend([x.strip() for x in (_AUDIO_GUARD_RE.findall(_raw) or []) if str(x).strip()])
        except Exception as e:
            suppress(site="share_resolver/season:audio_guard_findall", exc=e, fallback=None)

    for raw in (texts or []):
        t0 = str(raw or "")
        t = _strip_audio_tokens(t0).strip()
        if not t:
            continue

        # English markers: S01 / Season 1
        m = _SEASON_RE.search(t)
        if m:
            try:
                s = int(m.group(1))
                if 0 < s <= 60:
                    return SeasonGuess(season=s, level="explicit", source=f"显式季标记:{m.group(0)}")
            except (ValueError, TypeError, AttributeError) as e:
                logger.detail(f"季数解析失败（已忽略） - text={t!r}, 原因={type(e).__name__}")

        # Chinese markers: 第2季 / 第二季
        m = _CN_SEASON_RE.search(t)
        if m:
            s = _zh_num_to_int(m.group(1) or "")
            if s is not None and 0 < s <= 60:
                return SeasonGuess(season=s, level="explicit", source=f"显式季标记:{m.group(0)}")

        # Patterns like "LokiS01" without word boundary due to glue (fallback).
        # Guard against patterns that look like "S5.1" (single-digit after dot).
        m = re.search(r"S(\d{1,2})", t, re.IGNORECASE)
        if m:
            try:
                s = int(m.group(1))
                if 0 < s <= 60:
                    end = m.end(1)
                    if end < len(t) and t[end] == "." and (end + 1 < len(t) and t[end + 1].isdigit()):
                        # Looks like audio channels (S5.1): dot + single digit.
                        # Do NOT block cases like "S01.1080p" (dot + multiple digits).
                        if (end + 2 >= len(t)) or (not t[end + 2].isdigit()):
                            continue
                    return SeasonGuess(season=s, level="weak", source=f"粘连季推断:{m.group(0)}")
            except (ValueError, TypeError, AttributeError) as e:
                logger.detail(f"季数解析失败（已忽略） - text={t!r}, 原因={type(e).__name__}")

    if audio_hits:
        # Tell the user we explicitly filtered audio tokens to avoid fake seasons.
        _uniq = list(dict.fromkeys(audio_hits))
        return SeasonGuess(season=None, level="none", source=f"音轨已过滤:{'|'.join(_uniq[:3])}")
    return SeasonGuess(season=None, level="none", source="无")
