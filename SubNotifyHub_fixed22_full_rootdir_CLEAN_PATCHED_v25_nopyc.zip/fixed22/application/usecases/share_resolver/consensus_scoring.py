"""Multi-hint consensus scoring for TMDB candidate ranking.

This module contains functions for:
- Computing support weight from multiple hints
- Applying support bonus to fused score
- Evidence voting fusion

Extracted for better maintainability (Requirement 7).
"""

from __future__ import annotations

from typing import Any, Dict, List, Optional

from core.logging import get_biz_logger_adapter

from .constants import (
    SUPPORT_MAIN_WEIGHT,
    SUPPORT_MSG_WEIGHT,
    SUPPORT_BONUS_THRESHOLD,
    SUPPORT_BONUS_VALUE,
)

logger = get_biz_logger_adapter(__name__)


def compute_support_weight(
    hint_sources: Dict[str, str],
    hints: List[str],
) -> Dict[str, int]:
    """Compute support weight from hint sources (Requirement 7.4).
    
    Main hints (video filename, season folder) get weight 2.
    Message hints (user input, URL fragment) get weight 1.
    
    Args:
        hint_sources: Dict mapping hint -> source type ("main" or "msg")
        hints: List of hint strings that support this candidate
    
    Returns:
        Dict with:
        - support_count: Total number of supporting hints
        - support_weight: Weighted sum (main=2, msg=1)
        - support_main: Count of main hints
        - support_msg: Count of message hints
    """
    support_count = 0
    support_weight = 0
    support_main = 0
    support_msg = 0
    
    seen_hints = set()
    for h in hints:
        if not h or h in seen_hints:
            continue
        seen_hints.add(h)
        
        support_count += 1
        src = hint_sources.get(h, "msg")
        
        if src == "main":
            support_weight += SUPPORT_MAIN_WEIGHT
            support_main += 1
        else:
            support_weight += SUPPORT_MSG_WEIGHT
            support_msg += 1
    
    return {
        "support_count": support_count,
        "support_weight": support_weight,
        "support_main": support_main,
        "support_msg": support_msg,
    }


def apply_support_bonus(
    fused_score: float,
    support_weight: int,
    coverage: float = 0.0,
    min_coverage: float = 0.55,
) -> float:
    """Apply support bonus to fused score when support is strong (Requirement 7.5).
    
    When support_weight >= SUPPORT_BONUS_THRESHOLD (3), apply bonus of +0.03.
    
    Args:
        fused_score: Current fused score
        support_weight: Total support weight
        coverage: Coverage ratio (0.0 to 1.0)
        min_coverage: Minimum coverage to apply bonus
    
    Returns:
        Adjusted fused score (capped at 1.0)
    """
    if support_weight < SUPPORT_BONUS_THRESHOLD:
        return fused_score
    
    if coverage < min_coverage:
        return fused_score
    
    bonus = SUPPORT_BONUS_VALUE
    return min(1.0, fused_score + bonus)


def compute_top1_support(
    tmdb_id: int,
    media_type: str,
    top1_by_hint: Dict[str, tuple],
    hint_sources: Dict[str, str],
) -> Dict[str, int]:
    """Compute top-1 consensus support for a candidate.
    
    Counts how many hints have this candidate as their top-1 result.
    
    Args:
        tmdb_id: TMDB ID of candidate
        media_type: Media type ("tv" or "movie")
        top1_by_hint: Dict mapping hint -> (tmdb_id, media_type) of top-1 result
        hint_sources: Dict mapping hint -> source type
    
    Returns:
        Dict with:
        - top1_support_count: Number of hints with this as top-1
        - top1_support_weight: Weighted sum
        - top1_support_main: Count of main hints with this as top-1
    """
    mt_l = str(media_type or "movie").lower().strip() or "movie"
    
    top1_count = 0
    top1_weight = 0
    top1_main = 0
    
    for h, (t0, mt0) in top1_by_hint.items():
        try:
            if int(t0) == int(tmdb_id) and str(mt0).lower().strip() == mt_l:
                top1_count += 1
                src = hint_sources.get(h, "msg")
                if src == "main":
                    top1_weight += SUPPORT_MAIN_WEIGHT
                    top1_main += 1
                else:
                    top1_weight += SUPPORT_MSG_WEIGHT
        except (ValueError, TypeError):
            continue
    
    return {
        "top1_support_count": top1_count,
        "top1_support_weight": top1_weight,
        "top1_support_main": top1_main,
    }


def compute_evidence_fusion_bonus(
    base_score: float,
    coverage: float,
    top1_support_weight: int,
    support_weight: int,
    min_coverage: float = 0.55,
) -> float:
    """Compute evidence voting fusion bonus (Requirement 7.5).
    
    Args:
        base_score: Base fused score
        coverage: Coverage ratio
        top1_support_weight: Weight from top-1 consensus
        support_weight: Total support weight
        min_coverage: Minimum coverage to apply bonus
    
    Returns:
        Total bonus to add to fused score
    """
    if coverage < min_coverage:
        return 0.0
    
    bonus = 0.0
    
    # Bonus from top-1 consensus (0.03 per additional top-1 beyond first)
    bonus += 0.03 * max(0, top1_support_weight - 1)
    
    # Bonus from additional support beyond top-1 (0.01 per weight)
    bonus += 0.01 * max(0, support_weight - top1_support_weight)
    
    return bonus


def merge_candidate_support(
    candidate: Dict[str, Any],
    hint: str,
    hint_sources: Dict[str, str],
) -> None:
    """Merge support from a new hint into existing candidate (in-place).
    
    Args:
        candidate: Candidate dict to update
        hint: New hint string
        hint_sources: Dict mapping hint -> source type
    """
    hints = candidate.get("_hints")
    if not isinstance(hints, list):
        hints = []
        candidate["_hints"] = hints
    
    if hint in hints:
        return  # Already counted
    
    hints.append(hint)
    
    # Update counts
    candidate["_support_count"] = int(candidate.get("_support_count") or 0) + 1
    
    src = hint_sources.get(hint, "msg")
    if src == "main":
        candidate["_support_weight"] = int(candidate.get("_support_weight") or 0) + SUPPORT_MAIN_WEIGHT
        candidate["_support_main"] = int(candidate.get("_support_main") or 0) + 1
    else:
        candidate["_support_weight"] = int(candidate.get("_support_weight") or 0) + SUPPORT_MSG_WEIGHT
        candidate["_support_msg"] = int(candidate.get("_support_msg") or 0) + 1


def init_candidate_support(
    candidate: Dict[str, Any],
    hint: str,
    hint_sources: Dict[str, str],
) -> Dict[str, Any]:
    """Initialize support fields for a new candidate.
    
    Args:
        candidate: Base candidate dict
        hint: Initial hint string
        hint_sources: Dict mapping hint -> source type
    
    Returns:
        New candidate dict with support fields initialized
    """
    cc = dict(candidate)
    cc["_hint"] = hint
    cc["_hints"] = [hint]
    
    src = hint_sources.get(hint, "msg")
    if src == "main":
        cc["_support_count"] = 1
        cc["_support_weight"] = SUPPORT_MAIN_WEIGHT
        cc["_support_main"] = 1
        cc["_support_msg"] = 0
    else:
        cc["_support_count"] = 1
        cc["_support_weight"] = SUPPORT_MSG_WEIGHT
        cc["_support_main"] = 0
        cc["_support_msg"] = 1
    
    return cc


def apply_fused_score_with_support(
    candidates: List[Dict[str, Any]],
    hint_sources: Dict[str, str],
    top1_by_hint: Dict[str, tuple],
) -> None:
    """Apply fused score adjustments based on support (in-place).
    
    This combines:
    1. Top-1 consensus bonus
    2. Support weight bonus (Requirement 7.5)
    
    Args:
        candidates: List of candidate dicts to update
        hint_sources: Dict mapping hint -> source type
        top1_by_hint: Dict mapping hint -> (tmdb_id, media_type)
    """
    for d in candidates:
        if not isinstance(d, dict):
            continue
        
        try:
            sc0 = float(
                d.get("_fused_score") 
                if d.get("_fused_score") is not None 
                else (d.get("score") or 0.0)
            )
        except (ValueError, TypeError):
            sc0 = 0.0
        
        try:
            cov0 = float(d.get("coverage") or 0.0)
        except (ValueError, TypeError):
            cov0 = 0.0
        
        try:
            top1w = int(d.get("_top1_support_weight") or 0)
        except (ValueError, TypeError):
            top1w = 0
        
        try:
            supw = int(d.get("_support_weight") or 0)
        except (ValueError, TypeError):
            supw = 0
        
        # Compute evidence fusion bonus
        bonus = compute_evidence_fusion_bonus(sc0, cov0, top1w, supw)
        
        # Apply support bonus if threshold met (Requirement 7.5)
        if supw >= SUPPORT_BONUS_THRESHOLD and cov0 >= 0.55:
            bonus += SUPPORT_BONUS_VALUE
        
        d["_fused_score"] = round(min(1.0, sc0 + bonus), 5)
