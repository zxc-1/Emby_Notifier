"""Anime detection and handling module.

This module provides specialized handling for anime titles:
- Anime evidence detection (Requirement 17.1, 17.4)
- Title normalization (Requirement 17.2)
- Japanese text detection (Requirement 17.3)
- Animation genre bonus (Requirement 17.5)

Extracted for better maintainability and testability.
"""

from __future__ import annotations

import re
from typing import Any, Dict, List, Optional, Set, Tuple

from core.logging import get_biz_logger_adapter

logger = get_biz_logger_adapter(__name__)


# =============================================================================
# Constants
# =============================================================================

# Animation genre ID in TMDB
ANIMATION_GENRE_ID = 16

# Common anime subgroup patterns
SUBGROUP_PATTERNS = [
    r'\[([^\]]+)\]',  # [SubGroup]
    r'【([^】]+)】',  # 【字幕组】
]

# Common anime naming patterns
ANIME_FILENAME_PATTERN = re.compile(
    r'^[\[【]([^\]】]+)[\]】]\s*(.+?)\s*[-_]\s*(\d+)',
    re.IGNORECASE
)

# Season suffix patterns for normalization
SEASON_SUFFIX_PATTERNS = [
    (r'第([一二三四五六七八九十\d]+)季', 'Season {}'),
    (r'Season\s*(\d+)', 'Season {}'),
    (r'シーズン\s*(\d+)', 'Season {}'),
    (r'S(\d+)$', 'Season {}'),
]

# Chinese number mapping
CN_NUMBERS = {
    '一': 1, '二': 2, '三': 3, '四': 4, '五': 5,
    '六': 6, '七': 7, '八': 8, '九': 9, '十': 10,
}

# Hiragana range: U+3040 - U+309F
# Katakana range: U+30A0 - U+30FF
HIRAGANA_RANGE = (0x3040, 0x309F)
KATAKANA_RANGE = (0x30A0, 0x30FF)


# =============================================================================
# Japanese Text Detection (Requirement 17.3)
# =============================================================================

def is_japanese_text(text: str) -> bool:
    """Check if text contains Japanese characters (hiragana/katakana).
    
    Args:
        text: Text to check
    
    Returns:
        True if text contains hiragana or katakana
    """
    if not text:
        return False
    
    for char in text:
        code = ord(char)
        if HIRAGANA_RANGE[0] <= code <= HIRAGANA_RANGE[1]:
            return True
        if KATAKANA_RANGE[0] <= code <= KATAKANA_RANGE[1]:
            return True
    
    return False


def has_cjk_characters(text: str) -> bool:
    """Check if text contains CJK characters.
    
    Args:
        text: Text to check
    
    Returns:
        True if text contains CJK characters
    """
    if not text:
        return False
    
    for char in text:
        code = ord(char)
        # CJK Unified Ideographs
        if 0x4E00 <= code <= 0x9FFF:
            return True
        # CJK Extension A
        if 0x3400 <= code <= 0x4DBF:
            return True
    
    return False


def detect_anime_bilingual_evidence(
    hints: List[str],
    share_title: str,
    filename: str,
) -> Dict[str, Any]:
    """Detect bilingual evidence for anime (Requirement 17.3).
    
    When anime evidence contains both Japanese (hiragana/katakana) and CJK
    characters, treat it as bilingual_evidence.
    
    Args:
        hints: List of hint strings
        share_title: Share title
        filename: Main filename
    
    Returns:
        Dict with has_bilingual, has_japanese, has_cjk
    """
    all_text = hints + [share_title, filename]
    
    has_japanese = False
    has_cjk = False
    
    for text in all_text:
        if not text:
            continue
        if is_japanese_text(text):
            has_japanese = True
        if has_cjk_characters(text):
            has_cjk = True
    
    return {
        "has_bilingual": has_japanese and has_cjk,
        "has_japanese": has_japanese,
        "has_cjk": has_cjk,
    }


# =============================================================================
# Anime Evidence Detection (Requirement 17.1, 17.4)
# =============================================================================

def detect_subgroup_tag(text: str) -> Optional[str]:
    """Extract subgroup tag from text.
    
    Args:
        text: Text to check (usually filename)
    
    Returns:
        Subgroup name if found, None otherwise
    """
    if not text:
        return None
    
    for pattern in SUBGROUP_PATTERNS:
        match = re.search(pattern, text)
        if match:
            return match.group(1)
    
    return None


def detect_anime_evidence(
    filename: str,
    video_samples: List[str],
    genre_ids: Optional[List[int]] = None,
) -> Dict[str, Any]:
    """Detect anime evidence from filename and samples (Requirement 17.1, 17.4).
    
    Detects:
    - Subgroup tags like [SubGroup]
    - Japanese text (hiragana/katakana)
    - Animation genre ID
    - Common anime filename patterns
    
    Args:
        filename: Main filename
        video_samples: List of video sample filenames
        genre_ids: TMDB genre IDs (if available)
    
    Returns:
        Dict with is_anime, subgroup, has_japanese, confidence
    """
    all_files = [filename] + list(video_samples or [])
    
    # Check for subgroup tags
    subgroup = None
    for f in all_files:
        subgroup = detect_subgroup_tag(f)
        if subgroup:
            break
    
    # Check for Japanese text
    has_japanese = any(is_japanese_text(f) for f in all_files if f)
    
    # Check for anime filename pattern
    has_anime_pattern = False
    for f in all_files:
        if f and ANIME_FILENAME_PATTERN.match(f):
            has_anime_pattern = True
            break
    
    # Check genre IDs
    is_animation_genre = False
    if genre_ids and ANIMATION_GENRE_ID in genre_ids:
        is_animation_genre = True
    
    # Compute confidence
    confidence = 0.0
    if subgroup:
        confidence += 0.4
    if has_japanese:
        confidence += 0.3
    if has_anime_pattern:
        confidence += 0.2
    if is_animation_genre:
        confidence += 0.3
    
    # Cap at 1.0
    confidence = min(confidence, 1.0)
    
    is_anime = confidence >= 0.4 or is_animation_genre
    
    return {
        "is_anime": is_anime,
        "subgroup": subgroup,
        "has_japanese": has_japanese,
        "has_anime_pattern": has_anime_pattern,
        "is_animation_genre": is_animation_genre,
        "confidence": confidence,
    }


# =============================================================================
# Title Normalization (Requirement 17.2)
# =============================================================================

def normalize_season_suffix(title: str) -> Tuple[str, Optional[int]]:
    """Normalize season suffixes in anime titles (Requirement 17.2).
    
    Converts various season formats to a standard form:
    - "第X季" -> "Season X"
    - "シーズンX" -> "Season X"
    - "Season X" -> "Season X"
    
    Args:
        title: Title to normalize
    
    Returns:
        Tuple of (normalized_title, season_number)
    """
    if not title:
        return title, None
    
    normalized = title
    season_num = None
    
    for pattern, replacement in SEASON_SUFFIX_PATTERNS:
        match = re.search(pattern, normalized, re.IGNORECASE)
        if match:
            # Extract season number
            num_str = match.group(1)
            if num_str in CN_NUMBERS:
                season_num = CN_NUMBERS[num_str]
            else:
                try:
                    season_num = int(num_str)
                except ValueError:
                    continue
            
            # Replace with normalized form
            normalized = re.sub(pattern, replacement.format(season_num), normalized, flags=re.IGNORECASE)
            break
    
    return normalized, season_num


def remove_subgroup_tags(title: str) -> str:
    """Remove subgroup tags from title.
    
    Args:
        title: Title with potential subgroup tags
    
    Returns:
        Title without subgroup tags
    """
    if not title:
        return title
    
    result = title
    for pattern in SUBGROUP_PATTERNS:
        result = re.sub(pattern, '', result)
    
    return result.strip()


def normalize_anime_title(title: str) -> str:
    """Normalize anime title for matching (Requirement 17.2).
    
    Removes subgroup tags and normalizes season suffixes.
    
    Args:
        title: Title to normalize
    
    Returns:
        Normalized title
    """
    if not title:
        return title
    
    # Remove subgroup tags
    normalized = remove_subgroup_tags(title)
    
    # Normalize season suffix
    normalized, _ = normalize_season_suffix(normalized)
    
    # Clean up whitespace
    normalized = ' '.join(normalized.split())
    
    return normalized


# =============================================================================
# Animation Genre Bonus (Requirement 17.5)
# =============================================================================

def compute_anime_bonus(
    candidate: Dict[str, Any],
    anime_evidence: Dict[str, Any],
    title_similarity: float,
) -> float:
    """Compute anime bonus for candidate (Requirement 17.5).
    
    When anime title similarity is >= 0.85 AND genre matches animation,
    boost confidence by +0.03.
    
    Args:
        candidate: TMDB candidate dict
        anime_evidence: Result from detect_anime_evidence()
        title_similarity: Title similarity score
    
    Returns:
        Bonus to add to score (0.0 or 0.03)
    """
    if not anime_evidence.get("is_anime", False):
        return 0.0
    
    # Check if candidate is animation
    genre_ids = candidate.get("genre_ids", [])
    if ANIMATION_GENRE_ID not in genre_ids:
        return 0.0
    
    # Check title similarity threshold
    if title_similarity < 0.85:
        return 0.0
    
    return 0.03


def should_fetch_alternative_titles(
    candidate: Dict[str, Any],
    anime_evidence: Dict[str, Any],
) -> bool:
    """Check if we should fetch alternative titles for anime (Requirement 17.1).
    
    When media_type is detected as anime (genre_ids contains 16 for animation),
    fetch all alternative_titles including Japanese romaji.
    
    Args:
        candidate: TMDB candidate dict
        anime_evidence: Result from detect_anime_evidence()
    
    Returns:
        True if alternative titles should be fetched
    """
    # Always fetch for anime evidence
    if anime_evidence.get("is_anime", False):
        return True
    
    # Check if candidate is animation
    genre_ids = candidate.get("genre_ids", [])
    if ANIMATION_GENRE_ID in genre_ids:
        return True
    
    return False


# =============================================================================
# Utility Functions
# =============================================================================

def extract_anime_title_from_filename(filename: str) -> Optional[str]:
    """Extract anime title from filename pattern.
    
    Handles patterns like "[SubGroup] Title - 01 [1080p].mkv"
    
    Args:
        filename: Filename to parse
    
    Returns:
        Extracted title or None
    """
    if not filename:
        return None
    
    match = ANIME_FILENAME_PATTERN.match(filename)
    if match:
        return match.group(2).strip()
    
    return None


def get_anime_detection_summary(
    filename: str,
    video_samples: List[str],
    hints: List[str],
    share_title: str,
) -> Dict[str, Any]:
    """Get comprehensive anime detection summary.
    
    Args:
        filename: Main filename
        video_samples: List of video sample filenames
        hints: List of hint strings
        share_title: Share title
    
    Returns:
        Dict with all anime detection results
    """
    # Detect anime evidence
    anime_evidence = detect_anime_evidence(filename, video_samples)
    
    # Detect bilingual evidence
    bilingual = detect_anime_bilingual_evidence(hints, share_title, filename)
    
    # Extract title from filename if anime pattern detected
    extracted_title = None
    if anime_evidence.get("has_anime_pattern", False):
        extracted_title = extract_anime_title_from_filename(filename)
    
    return {
        **anime_evidence,
        "bilingual": bilingual,
        "extracted_title": extracted_title,
    }
