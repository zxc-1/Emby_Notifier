"""Application layer.

This package contains app-level orchestration concerns (validation, workflows,
use-cases) that sit above the domain layer.
"""
