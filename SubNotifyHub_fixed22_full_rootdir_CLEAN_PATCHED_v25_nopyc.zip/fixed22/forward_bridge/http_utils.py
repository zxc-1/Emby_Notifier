from __future__ import annotations

"""HTTP helpers for forward_bridge.

This module centralizes response JSON parsing and provides short, safe
diagnostics for logs/notifications. It prevents fragile direct calls to
``resp.json()`` from crashing API handlers when MediaHelp returns HTML/text.
"""
from core.logging import get_biz_logger
biz = get_biz_logger(__name__)


import json
from typing import Any, Optional, Tuple

import httpx


def short_text(text: str, *, limit: int = 500) -> str:
    if not isinstance(text, str):
        try:
            text = str(text)
        except (ValueError, TypeError):
            biz.detail("文本转换失败（已降级）", type=type(text).__name__)
            return "<non-text>"
    text = text.replace("\r", " ").replace("\n", " ")
    if len(text) <= limit:
        return text
    return text[:limit] + "…"


def resp_brief(resp: httpx.Response) -> str:
    try:
        ct = (resp.headers.get("content-type") or "").split(";", 1)[0].strip()
    except (ValueError, AttributeError, KeyError):
        biz.detail("content-type 解析失败（已降级）", status_code=getattr(resp, 'status_code', '?'))
        ct = ""
    try:
        txt = short_text(resp.text or "", limit=300)
    except (ValueError, AttributeError):
        biz.detail("响应文本读取失败（已降级）", status_code=getattr(resp, 'status_code', '?'))
        txt = "<no body>"
    return f"status={getattr(resp, 'status_code', '?')} content_type={ct} body={txt}"


def safe_json(
    resp: httpx.Response,
    *,
    ctx: str = "",
    default: Optional[Any] = None,
) -> Tuple[Any, Optional[str]]:
    """Parse JSON safely.

    Returns (data, err). If err is not None, parsing failed and data is
    ``default``.
    """
    try:
        return (resp.json(), None)
    except (ValueError, json.JSONDecodeError) as e:
        prefix = f"{ctx}: " if ctx else ""
        return (default, f"{prefix}json_decode_failed: {type(e).__name__}; {resp_brief(resp)}")
    except Exception as e:
        prefix = f"{ctx}: " if ctx else ""
        return (default, f"{prefix}json_parse_failed: {type(e).__name__}; {resp_brief(resp)}")
