from __future__ import annotations

"""Forward-bridge shared runtime state.

v1.6.2 refactor goals:
- Centralize in-memory state (pending subscribe/unsubscribe + bg tasks).
- Replace per-task heartbeat loops with a single tick loop that:
  - extends TTL while the task is still running
  - drops stale entries
- Provide a single place to cancel conflicting tasks and perform shutdown cleanup.

This module intentionally contains *no* FastAPI imports so it can be reused by
tests and non-HTTP entrypoints.
"""

import asyncio
from core.logging import get_biz_logger
import time
from dataclasses import dataclass
from typing import Dict, Optional, Tuple

from core.task_registry import create_task_logged
from ports.stores import get_kv_store, get_kv_store_async

from .config import (
    get_forward_pending_heartbeat_sec,
    get_forward_pending_max_age_sec,
    get_forward_pending_ttl_sec,
)

biz = get_biz_logger(__name__)


Key = Tuple[int, Optional[int]]  # (tmdb_id, season)


@dataclass
class PendingItem:
    kind: str  # 'sub' | 'unsub'
    start_ts: float
    exp_ts: float


class ForwardState:
    def __init__(self) -> None:
        self._lock = asyncio.Lock()
        self._pending: Dict[Key, PendingItem] = {}
        self._tasks: Dict[Key, asyncio.Task] = {}
        self._task_kind: Dict[Key, str] = {}
        self._tick_task: Optional[asyncio.Task] = None
        self._persist_key = "forward:pending:v1"
        self._last_persist_ts: float = 0.0

    def _build_persist_payload_locked(self) -> tuple[dict, int]:
        """Build payload for persistence.

        Must be called with self._lock held.
        """
        max_age = float(self._max_age())
        ttl = int(max(30.0, max_age + 60.0))
        items = []
        now = self._now()
        for (tmdb_id, season), it in list(self._pending.items()):
            if float(it.exp_ts) <= now:
                continue
            items.append(
                {
                    "tmdb_id": int(tmdb_id),
                    "season": int(season) if season is not None else None,
                    "kind": str(it.kind or ""),
                    "start_ts": float(it.start_ts),
                    "exp_ts": float(it.exp_ts),
                }
            )
        return {"items": items}, ttl

    async def _persist_pending_best_effort(self, payload: dict, ttl_sec: int) -> None:
        """Persist pending map into sqlite kv_cache (best-effort, non-blocking).

        Use async KV store to avoid blocking the event loop.
        """
        try:
            await get_kv_store_async().set_json(self._persist_key, payload, ttl_sec=int(ttl_sec))
        except (OSError, IOError, ValueError, RuntimeError, TypeError) as e:
            # never crash request paths
            biz.detail(
                "ℹ️ [持久化状态]失败：无法将 pending 状态写入 SQLite 缓存。"
                "可能原因：数据库文件锁定、磁盘空间不足、写入权限不足、数据序列化失败。"
                "影响：pending 状态不会持久化，重启后可能丢失进行中的订阅/取消订阅任务",
                reason=type(e).__name__,
            )
            pass

    def _load_pending_best_effort(self) -> None:
        try:
            data = get_kv_store().get_json(self._persist_key)
            if not isinstance(data, dict):
                return
            items = data.get("items")
            if not isinstance(items, list):
                return
            now = self._now()
            max_age = float(self._max_age())
            for it in items:
                if not isinstance(it, dict):
                    continue
                try:
                    tmdb_id = int(it.get("tmdb_id") or 0)
                    season = it.get("season")
                    season_v = int(season) if season is not None else None
                    kind = str(it.get("kind") or "sub")
                    start_ts = float(it.get("start_ts") or now)
                    exp_ts = float(it.get("exp_ts") or 0)
                    if tmdb_id <= 0:
                        continue
                    if exp_ts <= now:
                        continue
                    if (now - start_ts) > max_age:
                        continue
                    self._pending[self.key(tmdb_id, season_v)] = PendingItem(kind=kind, start_ts=start_ts, exp_ts=exp_ts)
                    self._task_kind[self.key(tmdb_id, season_v)] = kind
                except (ValueError, TypeError, KeyError) as e:
                    biz.detail("恢复 pending 条目失败（已跳过）", reason=type(e).__name__)
                    continue
        except (OSError, IOError, ValueError, TypeError, KeyError) as e:
            biz.detail("加载持久化 pending 状态失败（已忽略）", reason=type(e).__name__)
            pass

    @staticmethod
    def key(tmdb_id: int, season: Optional[int]) -> Key:
        return (int(tmdb_id), (int(season) if season is not None else None))

    def _now(self) -> float:
        return time.time()

    def _ttl(self) -> float:
        try:
            return float(get_forward_pending_ttl_sec())
        except (ValueError, TypeError) as e:
            biz.detail("解析 pending TTL 失败（已忽略）", reason=type(e).__name__)
            return 10.0

    def _hb(self) -> float:
        try:
            return float(get_forward_pending_heartbeat_sec())
        except (ValueError, TypeError) as e:
            biz.detail("解析 pending 心跳间隔失败（已忽略）", reason=type(e).__name__)
            return 2.0

    def _max_age(self) -> float:
        try:
            return float(get_forward_pending_max_age_sec())
        except (ValueError, TypeError) as e:
            biz.detail("解析 pending 最大存活时间失败（已忽略）", reason=type(e).__name__)
            return 120.0

    async def start(self) -> None:
        async with self._lock:
            if self._tick_task and not self._tick_task.done():
                return
            # Restore persisted pending markers
            try:
                self._load_pending_best_effort()
            except (OSError, IOError, ValueError) as e:
                biz.detail("恢复持久化 pending 状态失败（已忽略）", reason=type(e).__name__)
                pass
            hb = self._hb()
            if hb <= 0:
                return
            self._tick_task = create_task_logged(self._tick_loop(), name="forward_state_tick", log=logger)

    async def shutdown(self) -> None:
        payload: dict = {"items": []}
        ttl_sec: int = int(max(30.0, float(self._max_age()) + 60.0))

        async with self._lock:
            t = self._tick_task
            self._tick_task = None
            tasks = list(self._tasks.values())
            self._tasks.clear()
            self._task_kind.clear()
            self._pending.clear()

            # Build persisted cleared state while holding the lock.
            try:
                payload, ttl_sec = self._build_persist_payload_locked()
            except (ValueError, TypeError) as e:
                biz.detail("构建持久化 payload 失败（已忽略）", reason=type(e).__name__)
                payload = {"items": []}
                ttl_sec = int(max(30.0, float(self._max_age()) + 60.0))

        # Cancel outside lock
        try:
            if t and not t.done():
                t.cancel()
        except (RuntimeError, ValueError) as e:
            biz.detail("取消 tick 任务失败（已忽略）", reason=type(e).__name__)
            pass
        for tt in tasks:
            try:
                if tt and not tt.done():
                    tt.cancel()
            except (RuntimeError, ValueError) as e:
                biz.detail("取消后台任务失败（已忽略）", reason=type(e).__name__)
                pass

        # Best-effort persist cleared state (non-blocking)
        try:
            await self._persist_pending_best_effort(payload, ttl_sec)
        except (OSError, IOError, ValueError) as e:
            biz.detail("持久化清空状态失败（已忽略）", reason=type(e).__name__)
            pass

    async def register_task(self, key: Key, kind: str, task: asyncio.Task) -> None:
        """Register a background task and mark pending.

        If an older task exists for the same key:
        - if it's the *same kind*: we keep the older task running and ignore the new registration
          (caller should check pending_active before scheduling).
        - if it's different kind: cancel the older task (last write wins).
        """
        k = (int(key[0]), (int(key[1]) if key[1] is not None else None))
        now = self._now()
        ttl = self._ttl()

        payload: dict | None = None
        ttl_sec: int = int(max(30.0, float(self._max_age()) + 60.0))

        async with self._lock:
            old = self._tasks.get(k)
            old_kind = self._task_kind.get(k)
            if old and (not old.done()) and old_kind and (old_kind != kind):
                try:
                    old.cancel()
                except (RuntimeError, ValueError) as e:
                    biz.detail("取消旧任务失败（已忽略）", key=str(k), reason=type(e).__name__)
                    pass

            self._tasks[k] = task
            self._task_kind[k] = str(kind or "").strip() or "sub"
            self._pending[k] = PendingItem(kind=self._task_kind[k], start_ts=now, exp_ts=(now + ttl))

            # Persist pending markers (best-effort) - build payload under lock
            try:
                payload, ttl_sec = self._build_persist_payload_locked()
            except (ValueError, TypeError) as e:
                biz.detail("构建持久化 payload 失败（已忽略）", reason=type(e).__name__)
                payload = None

        if payload is not None:
            await self._persist_pending_best_effort(payload, ttl_sec)

    async def clear_pending(self, key: Key) -> None:
        payload: dict | None = None
        ttl_sec: int = int(max(30.0, float(self._max_age()) + 60.0))
        async with self._lock:
            self._pending.pop(key, None)
            self._task_kind.pop(key, None)
            # do not pop task: let it be GC; caller may still hold handle
            try:
                payload, ttl_sec = self._build_persist_payload_locked()
            except (ValueError, TypeError) as e:
                biz.detail("构建持久化 payload 失败（已忽略）", reason=type(e).__name__)
                payload = None

        if payload is not None:
            await self._persist_pending_best_effort(payload, ttl_sec)

    async def mark_pending(self, key: Key, kind: str) -> None:
        now = self._now()
        ttl = self._ttl()
        payload: dict | None = None
        ttl_sec: int = int(max(30.0, float(self._max_age()) + 60.0))
        async with self._lock:
            self._pending[key] = PendingItem(kind=str(kind or "sub"), start_ts=now, exp_ts=(now + ttl))
            self._task_kind[key] = str(kind or "sub")
            try:
                payload, ttl_sec = self._build_persist_payload_locked()
            except (ValueError, TypeError) as e:
                biz.detail("构建持久化 payload 失败（已忽略）", reason=type(e).__name__)
                payload = None

        if payload is not None:
            await self._persist_pending_best_effort(payload, ttl_sec)

    async def cancel_task(self, key: Key) -> None:
        payload: dict | None = None
        ttl_sec: int = int(max(30.0, float(self._max_age()) + 60.0))
        async with self._lock:
            t = self._tasks.pop(key, None)
            self._task_kind.pop(key, None)
            self._pending.pop(key, None)
            try:
                payload, ttl_sec = self._build_persist_payload_locked()
            except (ValueError, TypeError) as e:
                biz.detail("构建持久化 payload 失败（已忽略）", reason=type(e).__name__)
                payload = None

        if payload is not None:
            await self._persist_pending_best_effort(payload, ttl_sec)
        try:
            if t and not t.done():
                t.cancel()
        except (RuntimeError, ValueError) as e:
            biz.detail("取消任务失败（已忽略）", key=str(key), reason=type(e).__name__)
            pass

    def pending_active(self, key: Key, *, kind: Optional[str] = None) -> bool:
        """Check pending (sync, best-effort).

        This is intentionally lock-free: it is used in FastAPI handlers and we
        prefer a slightly stale read over awaiting a lock.
        """
        it = self._pending.get(key)
        if not it:
            return False
        now = self._now()
        if (now - float(it.start_ts)) > self._max_age():
            # stale, best-effort delete
            try:
                self._pending.pop(key, None)
                self._task_kind.pop(key, None)
            except (KeyError, ValueError) as e:
                biz.detail("清理过期 pending 条目失败（已忽略）", key=str(key), reason=type(e).__name__)
                pass
            return False
        if float(it.exp_ts) <= now:
            try:
                self._pending.pop(key, None)
                self._task_kind.pop(key, None)
            except (KeyError, ValueError) as e:
                biz.detail("清理过期 pending 条目失败（已忽略）", key=str(key), reason=type(e).__name__)
                pass
            return False
        if kind and (str(kind) != str(it.kind)):
            return False
        return True

    def task_kind(self, key: Key) -> str:
        return str(self._task_kind.get(key) or "")

    async def _tick_loop(self) -> None:
        hb = max(0.5, self._hb())
        ttl = self._ttl()
        max_age = self._max_age()

        while True:
            await asyncio.sleep(hb)
            now = self._now()

            payload: dict | None = None
            ttl_sec: int = int(max(30.0, float(self._max_age()) + 60.0))

            async with self._lock:
                # Drop finished tasks
                dead = [k for k, t in self._tasks.items() if not t or t.done()]
                for k in dead:
                    self._tasks.pop(k, None)
                    self._task_kind.pop(k, None)

                # Refresh exp_ts for active tasks and clean stale pendings
                for k, it in list(self._pending.items()):
                    if (now - float(it.start_ts)) > float(max_age):
                        self._pending.pop(k, None)
                        continue
                    t = self._tasks.get(k)
                    if t and (not t.done()):
                        # Extend while task is still running
                        it.exp_ts = now + float(ttl)
                        continue
                    # No active task: respect exp_ts
                    if float(it.exp_ts) <= now:
                        self._pending.pop(k, None)

                # Persist occasionally (avoid blocking the loop + reduce sqlite churn).
                if (now - float(self._last_persist_ts)) >= max(5.0, float(hb) * 3.0):
                    try:
                        payload, ttl_sec = self._build_persist_payload_locked()
                        self._last_persist_ts = float(now)
                    except (ValueError, TypeError) as e:
                        biz.detail("构建持久化 payload 失败（已忽略）", reason=type(e).__name__)
                        payload = None

            if payload is not None:
                try:
                    await self._persist_pending_best_effort(payload, ttl_sec)
                except (OSError, IOError, ValueError) as e:
                    biz.detail("持久化 pending 状态失败（已忽略）", reason=type(e).__name__)
                    pass


def get_token_expiry() -> float | None:
    """Best-effort token expiry/age hint for UI.

    The MediaHelp token format does not expose an explicit expiry in this repo.
    We return the token issue timestamp when available, otherwise None.
    """
    try:
        from .auth_state import get_mediahelp_state

        st = get_mediahelp_state()
        if getattr(st, "token", None):
            t = float(getattr(st, "token_time", 0.0) or 0.0)
            return t if t > 0 else None
        return None
    except Exception as e:
        biz.detail("ignored exception in get_token_expiry", exc_info=True)
        return None
