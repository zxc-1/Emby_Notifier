from __future__ import annotations

"""Forward-Bridge: subscription models.

This module holds Pydantic models that describe the normalized shape of the
in-memory subscription cache (SUB_CACHE entries).

We still store dicts in SUB_CACHE for backward compatibility (other modules read
it as a mapping), but we validate the shape at the boundary to prevent silent
schema drift.
"""

from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


class SubCacheEntryModel(BaseModel):
    """Normalized SUB_CACHE entry."""

    uuid: Optional[str] = None
    name: Optional[str] = None
    media_type: Optional[str] = None
    year: Optional[str] = None
    cron: Optional[str] = None
    selected_seasons: List[int] = Field(default_factory=list)
    raw: Dict[str, Any] = Field(default_factory=dict)


__all__ = ["SubCacheEntryModel"]
