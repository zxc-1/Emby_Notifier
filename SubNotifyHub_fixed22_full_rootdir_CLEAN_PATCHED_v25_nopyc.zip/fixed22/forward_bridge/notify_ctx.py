from __future__ import annotations

"""Notification context propagation.

High-level flows (share-link / hotlist / forward subscribe) already know the
source context (source_tag / source_label / source_value) and pass it to
business notifications.

However, low-level MediaHelp request wrappers (mh_request_json / mh_request)
may emit *system* notifications (HTTP 401 -> auto re-login) where the request
layer itself doesn't know who triggered the request.

We use a ContextVar to propagate the current "notify context" across awaits.
"""
from core.logging import get_biz_logger
biz = get_biz_logger(__name__)


from contextvars import ContextVar, Token
from typing import Any, Dict


_notify_ctx: ContextVar[Dict[str, Any]] = ContextVar("forward_bridge_notify_ctx", default={})


def get_notify_ctx() -> Dict[str, Any]:
    try:
        v = _notify_ctx.get() or {}
        return dict(v)
    except (ValueError, TypeError, LookupError):
        biz.detail(
            "ℹ️ [通知上下文获取]失败：无法从 ContextVar 读取当前通知上下文，返回空字典。"
            "可能原因：ContextVar 未初始化、数据类型异常、上下文已被清除。"
            "影响：系统通知（如自动重登录）将缺少来源信息，用户无法追溯触发源"
        )
        return {}


def set_notify_ctx(ctx: Dict[str, Any] | None) -> Token:
    return _notify_ctx.set(dict(ctx or {}))


def reset_notify_ctx(token: Token) -> None:
    try:
        _notify_ctx.reset(token)
    except (ValueError, LookupError):
        # Best-effort; never raise in business flow.
        biz.detail(
            "ℹ️ [通知上下文重置]失败：无法重置 ContextVar 到之前的状态。"
            "可能原因：Token 已失效、ContextVar 状态异常、并发访问冲突。"
            "影响：通知上下文可能泄漏到其他请求，导致通知信息混乱",
            token=str(token)
        )
