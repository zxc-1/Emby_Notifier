from __future__ import annotations

"""Forward-Bridge: single public subscription API.

This module is the *only* place that should:
1) Normalize subscription inputs (tmdb_id/type/year/season/title).
2) Guarantee a non-empty title so MediaHelp won't create "未知标题" tasks.
3) Provide a stable public surface for all subscription entrypoints.

Callers should prefer :func:`ensure_mediahelp_subscription` rather than calling
`create_mediahelp_sub_task()` directly.
"""

from typing import Any, Optional

from core.logging import get_biz_logger

from .models import ForwardSubscribePayload
from .subscriptions_core import fetch_tmdb_by_id, guess_media_type, _tmdb_title
from .subscriptions_tasks import create_mediahelp_sub_task

biz = get_biz_logger("emby_notifier.forward_bridge.subscription_api")


def _norm_year(year: Any) -> Optional[str]:
    if year is None:
        return None
    if isinstance(year, bool):
        return None
    if isinstance(year, (int, float)):
        try:
            y = int(year)
        except (ValueError, TypeError) as e:
            biz.detail(
                "ℹ️ [年份转换]失败：无法将输入的年份值转换为整数。"
                "可能原因：年份值不是数字、包含非法字符、类型不匹配。"
                "影响：年份信息将被忽略，可能影响媒体匹配的准确性",
                input=repr(year),
                error=type(e).__name__
            )
            return None
        return str(y)
    if isinstance(year, str):
        y2 = year.strip()
        return y2 or None
    return None


def _norm_media_type(media_type: Any, season: Any) -> str:
    mt = str(media_type or "").strip().lower()
    if mt not in ("movie", "tv"):
        mt = "tv" if season is not None else "movie"
    # If season is present, it's definitely TV.
    if season is not None and mt != "tv":
        biz.detail("媒体类型已纠正为 TV（因有季号）", 原类型=mt)
        mt = "tv"
    return mt


async def _detect_media_type_by_tmdb(tmdb_id: int) -> Optional[str]:
    """Try to detect whether tmdb_id is movie or tv.

    This is used when callers omit/garble `type` but still pass a title.
    We probe both endpoints and decide based on which returns a usable title.
    Returns None when ambiguous.
    """
    try:
        m = await fetch_tmdb_by_id(tmdb_id, "movie")
        t = await fetch_tmdb_by_id(tmdb_id, "tv")
        has_m = bool(_tmdb_title(m))
        has_t = bool(_tmdb_title(t))
        if has_m and not has_t:
            return "movie"
        if has_t and not has_m:
            return "tv"
    except (ValueError, TypeError, KeyError) as e:
        biz.detail(
            "ℹ️ [媒体类型探测]失败：通过 TMDB API 探测媒体类型时发生异常。"
            "可能原因：TMDB API 请求失败、网络超时、返回数据格式异常。"
            "影响：无法自动纠正错误的媒体类型，可能使用错误的端点创建订阅",
            tmdb_id=tmdb_id,
            error=type(e).__name__
        )
        pass
    return None


async def _resolve_title(tmdb_id: int, media_type: str, name: str, *, type_was_valid: bool) -> tuple[str, str]:
    """Return (title, media_type). May switch media_type if mismatch."""
    # If caller already provided a usable name, keep it, but still try to
    # correct media_type when the caller omitted/garbled `type`.
    if isinstance(name, str) and name.strip():
        if not type_was_valid:
            detected = await _detect_media_type_by_tmdb(tmdb_id)
            if detected and detected != media_type:
                biz.detail("媒体类型已通过 TMDB 纠正", tmdb_id=tmdb_id, 原类型=media_type, 新类型=detected)
                return name.strip(), detected
        return name.strip(), media_type

    meta = await fetch_tmdb_by_id(tmdb_id, media_type)
    title = _tmdb_title(meta)
    if title:
        biz.detail("已通过 TMDB 填充空标题", media_type=media_type, tmdb_id=tmdb_id, title=title[:60])
        return title, media_type

    other = "movie" if media_type == "tv" else "tv"
    meta2 = await fetch_tmdb_by_id(tmdb_id, other)
    title2 = _tmdb_title(meta2)
    if title2:
        biz.detail("媒体类型不匹配已修正，并通过 TMDB 填充标题", tmdb_id=tmdb_id, 原类型=media_type, 新类型=other, title=title2[:60])
        return title2, other

    # Last resort: never allow empty titles; avoid "未知标题" in MediaHelp.
    biz.warning("⚠️ 无法通过 TMDB 解析标题，使用默认值", tmdb_id=tmdb_id)
    return f"TMDB:{tmdb_id}", media_type


async def build_payload(
    *,
    tmdbid: Any,
    name: Any = None,
    type: Any = None,
    year: Any = None,
    season: Any = None,
    source_tag: Any = None,
    source_label: Any = None,
    source_value: Any = None,
) -> ForwardSubscribePayload:
    """Normalize and build a :class:`ForwardSubscribePayload`.

    Guarantees:
    - tmdbid: numeric string
    - name: non-empty
    - year: str|None
    - type: movie|tv (season implies tv)
    """
    try:
        tmdb_int = int(str(tmdbid).strip())
        if tmdb_int <= 0:
            raise ValueError("tmdbid must be positive")
    except Exception as e:
        raise ValueError(f"invalid tmdbid: {tmdbid}") from e

    season_int: Optional[int]
    if season is None or season == "":
        season_int = None
    else:
        try:
            season_int = int(season)
        except Exception as e:
            raise ValueError(f"invalid season: {season}") from e

    mt = _norm_media_type(type, season_int)
    y = _norm_year(year)

    type_raw = str(type or "").strip().lower()
    type_was_valid = type_raw in ("movie", "tv")

    title, mt2 = await _resolve_title(tmdb_int, mt, str(name or ""), type_was_valid=type_was_valid)

    # Some downstream logic still uses guess_media_type; keep fields consistent.
    payload = ForwardSubscribePayload(
        tmdbid=str(tmdb_int),
        name=title,
        type=mt2,
        year=y,
        season=season_int if mt2 == "tv" else None,
        source_tag=(str(source_tag).strip() if source_tag is not None and str(source_tag).strip() else None),
        source_label=(str(source_label).strip() if source_label is not None and str(source_label).strip() else None),
        source_value=(str(source_value).strip() if source_value is not None and str(source_value).strip() else None),
    )

    # Extra safety: if guess_media_type disagrees, log it (do not override).
    try:
        g = guess_media_type(payload)
        if g and g != (payload.type or ""):
            biz.warning(
                "subscription_api guess_media_type 不匹配",
                payload_type=payload.type,
                guess=g,
                tmdbid=payload.tmdbid,
            )
    except (ValueError, TypeError, AttributeError) as e:
        biz.detail(
            "ℹ️ [媒体类型验证]失败：使用 guess_media_type 验证订阅参数时发生异常。"
            "可能原因：订阅参数对象结构异常、必需字段缺失、类型不匹配。"
            "影响：无法验证媒体类型是否一致，可能导致订阅创建使用错误的类型",
            error=type(e).__name__
        )
        pass

    return payload


async def ensure_mediahelp_subscription(
    *,
    tmdbid: Any,
    name: Any = None,
    type: Any = None,
    year: Any = None,
    season: Any = None,
    source_tag: Any = None,
    source_label: Any = None,
    source_value: Any = None,
) -> tuple[bool, str]:
    """Ensure MediaHelp subscription exists (create or update seasons)."""
    p = await build_payload(tmdbid=tmdbid, name=name, type=type, year=year, season=season, source_tag=source_tag, source_label=source_label, source_value=source_value)
    ok, detail = await create_mediahelp_sub_task(p)
    return ok, detail


async def ensure_mediahelp_subscription_from_payload(p: ForwardSubscribePayload) -> tuple[bool, str]:
    """Normalize an existing ForwardSubscribePayload and ensure subscription."""
    return await ensure_mediahelp_subscription(
        tmdbid=p.tmdbid,
        name=p.name,
        type=p.type,
        year=p.year,
        season=p.season,
        source_tag=getattr(p, "source_tag", None),
        source_label=getattr(p, "source_label", None),
        source_value=getattr(p, "source_value", None),
    )
