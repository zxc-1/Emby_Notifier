from __future__ import annotations

import json
from core.logging import get_biz_logger
import time
import threading
from pathlib import Path
from typing import Any, Dict, Optional

from .config import get_mediahelp_token_ttl, log, get_mediahelp_base
from notifier.errors import categorize_exc

biz = get_biz_logger(__name__)

# token 持久化文件（放在容器里的 /data 目录）
DEFAULT_STATE_FILE = Path("/data") / "forward_mediahelp_state.json"


def _normalize_bearer(token: str) -> str:
    t = (token or "").strip()
    if not t:
        return ""
    if not t.lower().startswith("bearer "):
        t = "Bearer " + t
    return t


def mh_abs_url(url: str) -> str:
    """Normalize MediaHelp API URL.

    Accepts absolute URLs or relative paths like '/api/...'. If Settings does not
    provide MEDIAHELP_BASE, returns the original url (best-effort).
    """
    u = (url or "").strip()
    if not u:
        return u
    if u.startswith("http://") or u.startswith("https://"):
        return u
    try:
        base = get_mediahelp_base()
    except (ValueError, TypeError, AttributeError) as e:
        biz.detail("MediaHelp 基础 URL 获取失败（返回原始 URL）", reason=type(e).__name__)
        base = ""
    base = (base or "").rstrip("/")
    if not base:
        return u
    if u.startswith("/"):
        return base + u
    return base + "/" + u


class MediaHelpAuthState:
    """Holds MediaHelp auth runtime state (token + login) with a lock.

    This replaces the legacy module-level globals to avoid split-brain state and
    makes it possible to bind the state into AppContext.
    """

    def __init__(self, *, state_file: Path = DEFAULT_STATE_FILE) -> None:
        self.state_file = state_file
        self._lock = threading.RLock()
        self._init_done = False

        self.token: Optional[str] = None
        self.token_time: float = 0.0
        self.login_username: Optional[str] = None
        self.login_password: Optional[str] = None

    # ------------------------------------------------------------------
    # disk + settings bootstrap
    # ------------------------------------------------------------------

    def _load_saved_token_locked(self) -> None:
        try:
            if not self.state_file.is_file():
                return
            data = json.loads(self.state_file.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as e:
            log(f"⚠️ 读取 MediaHelp token 状态文件失败({categorize_exc(e)}): {e}")
            return

        token = data.get("token")
        ts = data.get("token_time")
        if not token or not isinstance(ts, (int, float)):
            return

        try:
            if (time.time() - float(ts)) > get_mediahelp_token_ttl():
                log("ℹ️ 磁盘中的 MediaHelp token 已过期，忽略。")
                return
        except (ValueError, TypeError) as e:
            biz.detail("token 过期检查失败（已忽略）", ts=ts, reason=type(e).__name__)
            return

        self.token = _normalize_bearer(str(token))
        self.token_time = float(ts)
        log("ℹ️ 已从磁盘恢复 MediaHelp 登录 token。")

    def _save_token_to_disk_locked(self) -> None:
        try:
            import os
            import tempfile

            self.state_file.parent.mkdir(parents=True, exist_ok=True)
            data = {"token": self.token, "token_time": self.token_time}
            payload = json.dumps(data, ensure_ascii=False)

            fd, tmp_name = tempfile.mkstemp(prefix=self.state_file.name + ".", dir=str(self.state_file.parent))
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as f:
                    f.write(payload)
                try:
                    os.chmod(tmp_name, 0o600)
                except (OSError, ValueError) as e:
                    biz.detail("临时文件权限设置失败（已忽略）", path=tmp_name, reason=type(e).__name__)
                Path(tmp_name).replace(self.state_file)
            finally:
                try:
                    if os.path.exists(tmp_name):
                        os.remove(tmp_name)
                except (OSError, ValueError) as e:
                    biz.detail("临时文件清理失败（已忽略）", path=tmp_name, reason=type(e).__name__)
        except Exception as e:
            log(f"⚠️ 保存 MediaHelp token 到磁盘失败({categorize_exc(e)}): {e}")

    def _load_from_settings_locked(self) -> None:
        try:
            from settings.runtime import get_settings
            s = get_settings()
        except (ValueError, TypeError, AttributeError, ImportError) as e:
            biz.detail("设置加载失败（已忽略）", reason=type(e).__name__)
            return
        try:
            tok = getattr(s, "MEDIAHELP_TOKEN", None)
            tok_s = _normalize_bearer(str(tok or "").strip()) if tok else ""
        except (ValueError, TypeError, AttributeError) as e:
            biz.detail("token 读取失败（使用空值）", reason=type(e).__name__)
            tok_s = ""

        if tok_s:
            # If disk had a token already, keep the newer one.
            if tok_s != (self.token or ""):
                self.token = tok_s
                self.token_time = time.time()
                log("ℹ️ 已从 Settings 加载 MediaHelp token。")

        try:
            u = getattr(s, "MEDIAHELP_LOGIN_USERNAME", None)
            p = getattr(s, "MEDIAHELP_LOGIN_PASSWORD", None)
            self.login_username = str(u).strip() if u else None
            self.login_password = str(p).strip() if p else None
        except (ValueError, TypeError, AttributeError) as e:
            biz.detail("登录凭据读取失败（已忽略）", reason=type(e).__name__)

    def init_runtime(self, *, load_disk: bool = True, load_settings: bool = True) -> None:
        """Lazy init: load token from disk + settings (best-effort, once)."""
        with self._lock:
            if self._init_done:
                return
            if load_disk:
                self._load_saved_token_locked()
            if load_settings:
                self._load_from_settings_locked()
            self._init_done = True

    # ------------------------------------------------------------------
    # token helpers
    # ------------------------------------------------------------------

    def set_token(self, token: str) -> None:
        with self._lock:
            t = _normalize_bearer(str(token or ""))
            self.token = t or None
            self.token_time = time.time() if self.token else 0.0
            # persist to disk for fast restart (best-effort)
            if self.token:
                self._save_token_to_disk_locked()

    def have_token(self, *, strict_ttl: bool = True) -> bool:
        with self._lock:
            if not self.token:
                return False
            if not strict_ttl:
                return True
            try:
                return (time.time() - float(self.token_time)) < float(get_mediahelp_token_ttl())
            except (ValueError, TypeError) as e:
                biz.detail("token TTL 检查失败（返回 True）", token_time=self.token_time, reason=type(e).__name__)
                return True

    def headers(self, *, with_auth: bool = True) -> Dict[str, str]:
        hdrs: Dict[str, str] = {"accept": "application/json"}
        with self._lock:
            if with_auth and self.token:
                hdrs["Authorization"] = self.token
        return hdrs


_GLOBAL_STATE: MediaHelpAuthState | None = None
_GLOBAL_LOCK = threading.Lock()


def get_mediahelp_state() -> MediaHelpAuthState:
    global _GLOBAL_STATE
    with _GLOBAL_LOCK:
        if _GLOBAL_STATE is None:
            _GLOBAL_STATE = MediaHelpAuthState()
        return _GLOBAL_STATE


def bind_mediahelp_state(state: MediaHelpAuthState) -> None:
    global _GLOBAL_STATE
    with _GLOBAL_LOCK:
        _GLOBAL_STATE = state
