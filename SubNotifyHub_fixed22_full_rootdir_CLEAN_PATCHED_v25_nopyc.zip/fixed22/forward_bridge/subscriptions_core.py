from __future__ import annotations

"""Forward-Bridge: subscription core (compatibility facade).

Historically this module accumulated:
- models
- season parsing
- MediaHelp API calls
- TMDB lookup
- subscription cache refresh
- subscription update/delete operations

To reduce coupling, implementations are split into focused modules:
- sub_models.py
- seasons.py
- mh_api.py
- tmdb_lookup.py
- sub_cache.py
- sub_ops.py

This file intentionally keeps the old import surface working.
"""

import logging
from core.logging import get_biz_logger_adapter

from core.metrics import metrics
from notifier.errors import categorize_exc
from settings.runtime import get_settings

from core.http import async_request_with_retry

# Keep a stable logger for imports like `from ...subscriptions_core import logger`.
logger = get_biz_logger_adapter(__name__)

# Low-level MediaHelp HTTP helpers (compat)
from .http_client import (  # noqa: E402
    mh_request,
    mh_request_json,
    have_token,
    mh_execute_subscription,
)

# Shared config/logger helper
from .config import (  # noqa: E402
    get_mediahelp_base,
    get_sub_cache_min_interval_sec,
    get_sub_cache_ttl,
    log,
)
from .notifications import notify_mediahelp  # noqa: E402


# Focused modules
from .sub_models import SubCacheEntryModel  # noqa: E402
from .seasons import _parse_selected_seasons, parse_selected_seasons, guess_media_type  # noqa: E402
from .mh_api import (  # noqa: E402
    _mh_url,
    _url_search_movies,
    _url_search_tv_shows,
    _url_defaults,
    _url_create_sub,
    _url_list_sub,
    _url_subscription_base,
    mh_search_media_by_name,
    mh_get_defaults,
    mh_list_subscriptions,
)
from .tmdb_lookup import TMDB_BASE, fetch_tmdb_by_id, _tmdb_title  # noqa: E402
from .sub_cache import (  # noqa: E402
    SUB_CACHE,
    SUB_CACHE_TIME,
    SUB_CACHE_LAST_REFRESH_ATTEMPT,
    get_subscriptions_snapshot,
    get_sub_entry,
    refresh_sub_cache,
    is_season_subscribed_from_cache,
)
from .sub_ops import mh_update_subscription_seasons, mh_delete_subscription  # noqa: E402


__all__ = [
    # Core misc
    "async_request_with_retry",
    "categorize_exc",
    "get_settings",
    "logger",
    "metrics",
    "log",
    "notify_mediahelp",


    # HTTP compat
    "mh_request",
    "mh_request_json",
    "have_token",
    "mh_execute_subscription",

    # Models / parsing
    "SubCacheEntryModel",
    "_parse_selected_seasons",
    "parse_selected_seasons",
    "guess_media_type",

    # MediaHelp API
    "get_mediahelp_base",
    "get_sub_cache_min_interval_sec",
    "get_sub_cache_ttl",
    "_mh_url",
    "_url_search_movies",
    "_url_search_tv_shows",
    "_url_defaults",
    "_url_create_sub",
    "_url_list_sub",
    "_url_subscription_base",
    "mh_search_media_by_name",
    "mh_get_defaults",
    "mh_list_subscriptions",

    # TMDB
    "TMDB_BASE",
    "fetch_tmdb_by_id",
    "_tmdb_title",

    # Cache
    "SUB_CACHE",
    "SUB_CACHE_TIME",
    "SUB_CACHE_LAST_REFRESH_ATTEMPT",
    "get_subscriptions_snapshot",
    "get_sub_entry",
    "refresh_sub_cache",
    "is_season_subscribed_from_cache",

    # Ops
    "mh_update_subscription_seasons",
    "mh_delete_subscription",
]
