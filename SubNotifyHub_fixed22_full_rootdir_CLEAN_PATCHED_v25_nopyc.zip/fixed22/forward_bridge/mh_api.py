from __future__ import annotations

"""Forward-Bridge: MediaHelp API thin client.

This module wraps MediaHelp endpoint URLs and request/response unwrapping.
Business logic (cache refresh, subscription ops) should live in sub_cache/sub_ops.
"""
from core.logging import get_biz_logger
from settings.timeouts import TimeoutCategory, get_timeout

biz = get_biz_logger(__name__)


from typing import Any, Dict, List, Optional

from .config import get_mediahelp_base, log
from .http_client import mh_request_json


# URL 构造（运行时读取 MEDIAHELP_BASE，支持热更新）
def _mh_url(path: str) -> str:
    base = get_mediahelp_base()
    return f"{base}{path}" if base else path


def _url_search_movies() -> str:
    return _mh_url("/api/v1/subscription/search-movies")


def _url_search_tv_shows() -> str:
    return _mh_url("/api/v1/subscription/search-tv-shows")


def _url_defaults() -> str:
    return _mh_url("/api/v1/subscription/config/defaults")


def _url_create_sub() -> str:
    return _mh_url("/api/v1/subscription/create")


def _url_list_sub() -> str:
    return _mh_url("/api/v1/subscription/list")


def _url_subscription_base() -> str:
    return _mh_url("/api/v1/subscription")


def _first_non_empty_str(*values: Optional[str]) -> Optional[str]:
    """返回第一个非空非空格字符串，没有就 None。"""
    for v in values:
        if isinstance(v, str) and v.strip():
            return v.strip()
    return None


async def mh_search_media_by_name(
    name: str,
    media_type: str,
    prefer_tmdb_id: int | None = None,
    prefer_year: str | int | None = None,
) -> Optional[dict]:
    """Search media in MediaHelp by name with better disambiguation.

    选择策略（按优先级）：
      1) 若返回列表中存在 id == prefer_tmdb_id（或 tmdb_id == prefer_tmdb_id），优先选它
      2) 否则若提供 prefer_year，则按 year / release_date / first_air_date 过滤
      3) 最后回退 items[0]

    - movie -> /search-movies
    - tv    -> /search-tv-shows
    其它情况统一按 movie 处理。
    """
    if not name:
        return None

    media_type = (media_type or "").strip().lower()
    if media_type == "tv":
        url = _url_search_tv_shows()
        label = "search-tv-shows"
    else:
        url = _url_search_movies()
        label = "search-movies"

    params = {"query": name}
    status_code, data, err, text_snip = await mh_request_json(
        "GET",
        url,
        ctx=label,
        default={},
        params=params,
        timeout=int(get_timeout(TimeoutCategory.MH_API)),
    )

    if status_code != 200:
        log(f"❌ {label} 失败: {status_code} {text_snip}")
        return None

    if err:
        log(f"⚠️ {err}")
        return None
    data = data or {}

    items = data.get("data") or []
    if not items:
        log(f"⚠️ {label} 返回空列表")
        return None

    def _norm_int(v) -> int | None:
        try:
            if v is None or v == "":
                return None
            if isinstance(v, bool):
                return None
            return int(v)
        except (ValueError, TypeError):
            biz.detail("整数转换失败（已降级）", raw_value=repr(v))
            return None

    def _extract_year(it: dict) -> str | None:
        if not isinstance(it, dict):
            return None
        y = it.get("year")
        if isinstance(y, (int, float)) and not isinstance(y, bool):
            try:
                return str(int(y))
            except (ValueError, TypeError):
                biz.detail("年份转换失败（已降级）", raw_value=repr(y))
        if isinstance(y, str):
            yy = y.strip()
            if yy[:4].isdigit():
                return yy[:4]
        # try dates
        for k in ("release_date", "first_air_date", "air_date"):
            d = it.get(k)
            if isinstance(d, str):
                dd = d.strip()
                if len(dd) >= 4 and dd[:4].isdigit():
                    return dd[:4]
        return None

    best = None

    # 1) Prefer exact TMDB id match
    pref_id = _norm_int(prefer_tmdb_id)
    if pref_id is not None:
        for it in items:
            if not isinstance(it, dict):
                continue
            cand = _norm_int(it.get("id"))
            cand2 = _norm_int(it.get("tmdb_id") or it.get("tmdbid"))
            if cand == pref_id or cand2 == pref_id:
                best = it
                break

    # 2) Prefer year match (only when id not found)
    if best is None and prefer_year is not None:
        try:
            py = str(int(prefer_year)) if isinstance(prefer_year, (int, float)) and not isinstance(prefer_year, bool) else str(prefer_year)
            py = (py or "").strip()
            py = py[:4] if py[:4].isdigit() else py
        except (ValueError, TypeError):
            biz.detail("年份解析失败（已降级）", raw_value=repr(prefer_year))
            py = ""
        if py and py[:4].isdigit():
            for it in items:
                if isinstance(it, dict) and _extract_year(it) == py[:4]:
                    best = it
                    break

    # 3) Fallback
    if best is None:
        best = items[0]

    try:
        log(
            f"✅ {label} 命中: id={best.get('id') if isinstance(best, dict) else None} "
            f"name={(best.get('name') or best.get('title')) if isinstance(best, dict) else None} "
            f"(prefer_id={pref_id}, prefer_year={prefer_year})"
        )
    except (ValueError, TypeError, AttributeError):
        biz.detail("日志打印失败（已降级）", label=label)
        log(f"✅ {label} 命中")
    return best


async def mh_get_defaults() -> Dict[str, Any]:
    """Get MediaHelp defaults (config/defaults), unwrapping common envelope shapes."""
    status_code, root, err, text_snip = await mh_request_json(
        "GET",
        _url_defaults(),
        ctx="config/defaults",
        default={},
        timeout=int(get_timeout(TimeoutCategory.MH_API)),
    )

    if status_code != 200:
        log(f"❌ config/defaults 失败: {status_code} {text_snip}")
        return {}

    if err:
        log(f"⚠️ {err}")
        return {}

    if not isinstance(root, dict):
        return {}

    # Common envelope shape
    data = root.get("data")
    if isinstance(data, dict):
        return data

    # Some deployments return defaults at the top-level (no "data" envelope).
    known_keys = {
        "cloud_type",
        "account_identifier",
        "save_dir",
        "target_directory",
        "cron",
        "quality",
        "quality_preference",
    }
    if any(k in root for k in known_keys):
        envelope_keys = {"code", "message", "success", "timestamp"}
        meaningful = {k: root.get(k) for k in known_keys if k in root}
        if meaningful:
            for v in meaningful.values():
                if v is None:
                    continue
                if isinstance(v, (str, int, bool)):
                    continue
                return {}
            return root
        if set(root.keys()).issubset(envelope_keys):
            return {}

    return {}


async def mh_list_subscriptions() -> List[dict]:
    """List MediaHelp subscriptions, handling common envelope + pagination."""

    page = 1
    page_size = 20
    out: List[dict] = []
    seen: set[str] = set()

    # hard safety cap to prevent infinite loops on buggy servers
    for _ in range(1, 51):
        params = {"page": page, "page_size": page_size}
        status_code, root, err, text_snip = await mh_request_json(
            "GET",
            _url_list_sub(),
            ctx="subscriptions/list",
            default={},
            params=params,
            timeout=int(get_timeout(TimeoutCategory.HTTP_LONG)),
        )

        if status_code != 200:
            log(f"❌ subscriptions/list 失败: {status_code} {text_snip}")
            break
        if err:
            log(f"⚠️ {err}")
            break
        if not isinstance(root, dict):
            break

        data = root.get("data")
        items_obj: Any = None
        total: Optional[int] = None

        if isinstance(data, list):
            items_obj = data
        elif isinstance(data, dict):
            items_obj = (
                data.get("items")
                or data.get("subscriptions")
                or data.get("rows")
                or data.get("list")
                or []
            )
            # pagination hints (best-effort)
            try:
                total = int(data.get("total")) if data.get("total") is not None else None
            except (ValueError, TypeError):
                biz.detail("total 转换失败（已降级）", raw_value=repr(data.get('total')))
                total = None
            try:
                page_size = int(data.get("page_size") or page_size)
            except (ValueError, TypeError):
                biz.detail("page_size 转换失败（已降级）", raw_value=repr(data.get('page_size')))
        else:
            items_obj = root.get("items") or root.get("subscriptions") or []

        if not isinstance(items_obj, list):
            break

        items: List[dict] = [x for x in items_obj if isinstance(x, dict)]
        if not items:
            break

        # de-dup by uuid/id when available
        for it in items:
            uid = str(it.get("uuid") or it.get("id") or "")
            if uid and uid in seen:
                continue
            if uid:
                seen.add(uid)
            out.append(it)

        # stop when last page
        if len(items) < page_size:
            break
        if total is not None and len(out) >= total:
            break

        page += 1

    return out


__all__ = [
    "_mh_url",
    "_url_search_movies",
    "_url_search_tv_shows",
    "_url_defaults",
    "_url_create_sub",
    "_url_list_sub",
    "_url_subscription_base",
    "mh_search_media_by_name",
    "mh_get_defaults",
    "mh_list_subscriptions",
]
