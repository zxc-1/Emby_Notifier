from __future__ import annotations

from core.logging import get_biz_logger
biz = get_biz_logger(__name__)

from datetime import datetime, timezone
from typing import Any, Dict

from .config import log
from .notify_ctx import get_notify_ctx

# 和主项目解耦：import 失败就降级为 no-op
# NOTE: notifier.mediahelp_notify.emit_mediahelp_event(payload) 接口在主项目里是
# 同步函数（返回 Optional[NotificationContent]），不是 async。
try:
    from notifier.mediahelp_notify import MediaHelpNotifyPayload, emit_mediahelp_event
except Exception:  # pragma: no cover
    MediaHelpNotifyPayload = None  # type: ignore
    emit_mediahelp_event = None  # type: ignore[assignment]


def _sanitize(text: str, limit: int = 200) -> str:
    """
    Telegram 在 Markdown / HTML 模式下，对 [], (), `, &, <, > 等都比较敏感。
    不动主项目，只在子项目里把要发过去的字符串做一层清洗+转义。
    """
    if not text:
        return ""

    # 截断，避免一大坨 URL / JSON
    text = text[:limit]

    # 1) 干掉容易破坏 Markdown 结构的符号
    for ch in ("[", "]", "(", ")", "`"):
        text = text.replace(ch, " ")

    # 2) 再按 HTML 风格转义 & < >
    text = (
        text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
    )

    return text


async def notify_mediahelp(event: str, data: Dict[str, Any] | None) -> None:
    """
    统一给主项目发 MediaHelp 相关事件。
    """
    if emit_mediahelp_event is None or MediaHelpNotifyPayload is None:
        log("⚠️ emit_mediahelp_event 未就绪，跳过 MediaHelp 通知")
        return

    raw = data or {}

    # Auto-attach current notify context (source_tag/source_label/source_value)
    # for system events emitted by low-level request wrappers (e.g. 401 re-login).
    try:
        ctx = get_notify_ctx() or {}
        if ctx:
            merged = dict(ctx)
            merged.update(raw)
            raw = merged
    except (ValueError, TypeError, KeyError):
        biz.detail("notify context 获取失败（已忽略）", event=event)
    safe: Dict[str, Any] = {}

    for key, val in raw.items():
        if isinstance(val, str):
            safe[key] = _sanitize(val)
        else:
            safe[key] = val

    ts = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    try:
        # 主项目 emit_mediahelp_event 是同步函数，接收一个 payload 对象。
        payload = MediaHelpNotifyPayload(event=event, data=safe, ts=ts)
        emit_mediahelp_event(payload)
    except Exception as exc:  # pragma: no cover
        log(f"❌ 调用 emit_mediahelp_event 失败: {exc}")