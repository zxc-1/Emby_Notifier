from __future__ import annotations


class MediaHelpError(RuntimeError):
    """Base error for MediaHelp client."""


class MediaHelpAuthError(MediaHelpError):
    """Authentication failed or token invalid."""


def is_retryable_status(status_code: int) -> bool:
    """Whether a response status should be retried."""
    # 408 Request Timeout, 429 Too Many Requests, and 5xx are commonly retryable.
    return status_code in (408, 429) or 500 <= int(status_code) <= 599
