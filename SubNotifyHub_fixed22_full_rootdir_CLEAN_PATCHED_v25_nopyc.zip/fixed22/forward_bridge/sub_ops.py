from __future__ import annotations

"""Forward-Bridge: subscription operations.

Higher level operations that update MediaHelp subscriptions and keep SUB_CACHE in
sync.
"""

from typing import Any, Dict, List, Optional

from core.metrics import metrics
from settings.timeouts import TimeoutCategory, get_timeout

from .config import log
from .http_client import mh_request_json
from .mh_api import _url_subscription_base
from .notifications import notify_mediahelp
from .sub_cache import SUB_CACHE, refresh_sub_cache


async def mh_update_subscription_seasons(
    tmdb_id: int,
    new_seasons: List[int],
    ctx_notify: Optional[Dict[str, Any]] = None,
) -> tuple[bool, str]:
    """Update selected_seasons for a subscription identified by tmdb_id.

    Uses PUT /api/v1/subscription/{uuid}.
    """
    await refresh_sub_cache()
    entry = SUB_CACHE.get(int(tmdb_id))
    if not entry:
        msg = f"subscription for tmdb_id={tmdb_id} not found"
        log(f"❌ {msg}")
        metrics.inc("forwardbridge_sub_update_failed")
        await notify_mediahelp(
            "mediahelp_sub_update_failed",
            {**(ctx_notify or {}), "tmdb_id": tmdb_id, "title": "", "detail": msg},
        )
        return False, msg

    raw = entry.get("raw") or {}
    params = (raw.get("params") or {}).copy()
    params["selected_seasons"] = list(new_seasons or [])

    name = raw.get("name") or params.get("custom_name") or ""
    cron = raw.get("cron") or params.get("cron") or "0 */6 * * *"
    uuid = entry.get("uuid") or raw.get("uuid") or ""
    title_for_notify = name or params.get("custom_name") or ""

    if not uuid:
        msg = f"subscription uuid missing for tmdb_id={tmdb_id}"
        log(f"❌ {msg}")
        metrics.inc("forwardbridge_sub_update_failed")
        await notify_mediahelp(
            "mediahelp_sub_update_failed",
            {**(ctx_notify or {}), "tmdb_id": tmdb_id, "title": title_for_notify, "detail": msg},
        )
        return False, msg

    body = {"name": name, "cron": cron, "params": params}
    url = f"{_url_subscription_base()}/{uuid}"

    log(f"✏️ 更新订阅: tmdb_id={tmdb_id}, uuid={uuid}, seasons={new_seasons}")

    status_code, data, err, text_snip = await mh_request_json(
        "PUT",
        url,
        ctx="subscription/update",
        default={},
        json=body,
        timeout=int(get_timeout(TimeoutCategory.HTTP_LONG)),
    )

    if status_code != 200:
        msg = f"MediaHelp 更新订阅 HTTP 非 200: {status_code}"
        log("❌ " + msg)
        metrics.inc("forwardbridge_sub_update_failed")
        await notify_mediahelp(
            "mediahelp_sub_update_failed",
            {**(ctx_notify or {}), "tmdb_id": tmdb_id, "title": title_for_notify, "detail": msg},
        )
        return False, text_snip

    if err:
        log(f"⚠️ {err}")
        msg = "MediaHelp 更新返回非 JSON"
        metrics.inc("forwardbridge_sub_update_failed")
        await notify_mediahelp(
            "mediahelp_sub_update_failed",
            {**(ctx_notify or {}), "tmdb_id": tmdb_id, "title": title_for_notify, "detail": msg},
        )
        return False, text_snip

    code = (data or {}).get("code") if isinstance(data, dict) else None
    message = str(((data or {}).get("message") or "") if isinstance(data, dict) else "").strip()
    if code not in (None, 0, 200):
        msg = f"MediaHelp 更新订阅失败: code={code}, message={message}"
        log("❌ " + msg)
        metrics.inc("forwardbridge_sub_update_failed")
        await notify_mediahelp(
            "mediahelp_sub_update_failed",
            {**(ctx_notify or {}), "tmdb_id": tmdb_id, "title": title_for_notify, "detail": msg},
        )
        return False, text_snip

    # Update local cache entry
    entry["selected_seasons"] = list(new_seasons or [])
    raw["params"] = params
    entry["raw"] = raw
    SUB_CACHE[int(tmdb_id)] = entry

    log(f"✅ 更新订阅成功，tmdb_id={tmdb_id}, selected_seasons={new_seasons}")
    await notify_mediahelp(
        "mediahelp_sub_updated_seasons",
        {
            **(ctx_notify or {}),
            "tmdb_id": tmdb_id,
            "title": entry.get("name") or params.get("custom_name") or "",
            "selected_seasons": list(new_seasons or []),
        },
    )

    metrics.inc("forwardbridge_sub_update")
    return True, text_snip


async def mh_delete_subscription(
    tmdb_id: int,
    ctx_notify: Optional[Dict[str, Any]] = None,
    trigger_season: Optional[int] = None,
) -> tuple[bool, str]:
    """Delete MediaHelp subscription by tmdb_id (lookup uuid via SUB_CACHE)."""
    await refresh_sub_cache()
    entry = SUB_CACHE.get(int(tmdb_id))
    if not entry:
        msg = f"subscription for tmdb_id={tmdb_id} not found"
        log(f"❌ {msg}")
        metrics.inc("forwardbridge_sub_delete_failed")
        await notify_mediahelp(
            "mediahelp_sub_delete_failed",
            {**(ctx_notify or {}), "tmdb_id": tmdb_id, "title": "", "media_type": "", "season": trigger_season, "detail": msg},
        )
        return False, msg

    raw = entry.get("raw") or {}
    uuid = entry.get("uuid") or raw.get("uuid") or ""
    params = raw.get("params") or {}
    title_for_notify = raw.get("name") or params.get("custom_name") or ""
    media_type = (params.get("media_type") or "").strip().lower()
    selected_seasons = entry.get("selected_seasons") or params.get("selected_seasons") or []

    if not uuid:
        msg = f"subscription uuid missing for tmdb_id={tmdb_id}"
        log(f"❌ {msg}")
        metrics.inc("forwardbridge_sub_delete_failed")
        await notify_mediahelp(
            "mediahelp_sub_delete_failed",
            {**(ctx_notify or {}), "tmdb_id": tmdb_id, "title": title_for_notify, "media_type": media_type, "season": trigger_season, "selected_seasons": selected_seasons, "detail": msg},
        )
        return False, msg

    url = f"{_url_subscription_base()}/{uuid}"
    log(f"🗑️ 删除订阅: tmdb_id={tmdb_id}, uuid={uuid}")

    status_code, data, err, text_snip = await mh_request_json(
        "DELETE",
        url,
        ctx="subscription/delete",
        default={},
        timeout=int(get_timeout(TimeoutCategory.HTTP_LONG)),
    )

    if status_code != 200:
        msg = f"MediaHelp 删除订阅 HTTP 非 200: {status_code}"
        log("❌ " + msg)
        metrics.inc("forwardbridge_sub_delete_failed")
        await notify_mediahelp(
            "mediahelp_sub_delete_failed",
            {**(ctx_notify or {}), "tmdb_id": tmdb_id, "title": title_for_notify, "media_type": media_type, "season": trigger_season, "selected_seasons": selected_seasons, "detail": msg},
        )
        return False, text_snip

    if err:
        log(f"⚠️ {err}")
        msg = "MediaHelp 删除返回非 JSON"
        metrics.inc("forwardbridge_sub_delete_failed")
        await notify_mediahelp(
            "mediahelp_sub_delete_failed",
            {**(ctx_notify or {}), "tmdb_id": tmdb_id, "title": title_for_notify, "media_type": media_type, "season": trigger_season, "selected_seasons": selected_seasons, "detail": msg},
        )
        return False, text_snip

    code = (data or {}).get("code") if isinstance(data, dict) else None
    message = str(((data or {}).get("message") or "") if isinstance(data, dict) else "").strip()
    if code not in (None, 0, 200):
        msg = f"MediaHelp 删除订阅失败: code={code}, message={message}"
        log("❌ " + msg)
        metrics.inc("forwardbridge_sub_delete_failed")
        await notify_mediahelp(
            "mediahelp_sub_delete_failed",
            {**(ctx_notify or {}), "tmdb_id": tmdb_id, "title": title_for_notify, "media_type": media_type, "season": trigger_season, "selected_seasons": selected_seasons, "detail": msg},
        )
        return False, text_snip

    SUB_CACHE.pop(int(tmdb_id), None)
    log(f"✅ 删除订阅成功，tmdb_id={tmdb_id}")
    await notify_mediahelp(
        "mediahelp_sub_deleted",
        {**(ctx_notify or {}), "tmdb_id": tmdb_id, "title": title_for_notify, "media_type": media_type, "season": trigger_season, "selected_seasons": selected_seasons},
    )

    metrics.inc("forwardbridge_sub_delete")
    return True, text_snip


__all__ = ["mh_update_subscription_seasons", "mh_delete_subscription"]
