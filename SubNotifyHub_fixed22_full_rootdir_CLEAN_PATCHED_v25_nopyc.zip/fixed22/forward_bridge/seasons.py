from __future__ import annotations

"""Forward-Bridge: season selection parsing.

This module is pure (no network / no global mutation) and can be unit-tested
independently.
"""
from core.logging import get_biz_logger
biz = get_biz_logger(__name__)


from typing import Any, List

from .models import ForwardSubscribePayload


def _parse_selected_seasons(raw: Any) -> tuple[bool, List[int]]:
    """Parse MediaHelp params.selected_seasons.

    Returns (is_all_seasons, seasons_int).

    We treat the following as "all seasons":
      - None / missing
      - [] / empty string
      - "all" / "ALL" / "*" (string)
      - ["all"] / ["*"] (list)

    Otherwise we try to extract integer season numbers from items.
    """
    if raw is None:
        return True, []

    # strings
    if isinstance(raw, str):
        s = raw.strip().lower()
        if not s or s in ("all", "*", "any"):
            return True, []
        # Extract digits (e.g. "S01", "01")
        try:
            import re

            nums = [int(x) for x in re.findall(r"\d+", s)]
            nums = [n for n in nums if n > 0]
            return (len(nums) == 0), sorted(set(nums))
        except (ValueError, TypeError) as e:
            biz.detail(
                "ℹ️ [季数字符串解析]失败：无法从字符串中提取有效的季数。"
                "可能原因：字符串格式不符合预期、正则表达式匹配失败、数字转换错误。"
                "影响：将该字符串视为无效输入，返回空季数列表",
                input=repr(s),
                reason=type(e).__name__
            )
            return False, []

    # list/tuple
    if isinstance(raw, (list, tuple)):
        if len(raw) == 0:
            return True, []
        # common "all" markers
        lowered = []
        for it in raw:
            if isinstance(it, str):
                lowered.append(it.strip().lower())
        if any(x in ("all", "*", "any") for x in lowered):
            return True, []

        seasons: List[int] = []
        for it in raw:
            try:
                if isinstance(it, int):
                    seasons.append(int(it))
                elif isinstance(it, str):
                    import re

                    for x in re.findall(r"\d+", it):
                        seasons.append(int(x))
                else:
                    seasons.append(int(it))
            except (ValueError, TypeError) as e:
                biz.detail(
                    "ℹ️ [季数列表项解析]失败：无法将列表中的某个元素转换为有效季数，跳过该项。"
                    "可能原因：元素不是数字、字符串格式错误、类型不支持转换。"
                    "影响：该元素将被忽略，不会加入季数列表",
                    item=repr(it),
                    reason=type(e).__name__
                )
                continue
        seasons = [n for n in seasons if isinstance(n, int) and n > 0]
        if not seasons:
            # treat unparseable/empty list as "all" to avoid accidentally narrowing.
            return True, []
        return False, sorted(set(seasons))

    # unknown types: be conservative, treat as all-seasons
    return True, []


def parse_selected_seasons(raw: Any) -> tuple[bool, List[int]]:
    """Public wrapper for season parsing."""
    return _parse_selected_seasons(raw)


def guess_media_type(payload: ForwardSubscribePayload) -> str:
    """根据 Forward type 粗略判断 movie / tv。"""
    t = (payload.type or "").strip().lower()
    if any(k in t for k in ("剧", "tv", "series", "show")):
        return "tv"
    return "movie"


__all__ = ["_parse_selected_seasons", "parse_selected_seasons", "guess_media_type"]
