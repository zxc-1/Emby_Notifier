"""Stable re-export surface for forward_bridge subscription APIs.

Implementations are split into subscriptions_core.py and subscriptions_tasks.py.
This module keeps the historical import path working.
"""

from __future__ import annotations

import warnings

from core.runtime_env import debug_imports_enabled

if debug_imports_enabled():
    warnings.warn(
        "forward_bridge.subscriptions is a compatibility re-export surface; new code should import from forward_bridge.subscription_api or subscriptions_core/subscriptions_tasks.",
        DeprecationWarning,
        stacklevel=2,
    )

from .subscriptions_core import (
    SUB_CACHE,
    SUB_CACHE_TIME,
    TMDB_BASE,
    fetch_tmdb_by_id,
    guess_media_type,
    is_season_subscribed_from_cache,
    logger,
    mh_delete_subscription,
    mh_get_defaults,
    mh_list_subscriptions,
    mh_search_media_by_name,
    mh_update_subscription_seasons,
    parse_selected_seasons,
    refresh_sub_cache,
)

from .subscriptions_tasks import (
    create_mediahelp_sub_task,
    unsubscribe_with_season,
)

# New unified API surface (preferred)
from .subscription_api import (
    build_payload as build_subscribe_payload,
    ensure_mediahelp_subscription,
    ensure_mediahelp_subscription_from_payload,
)

__all__ = [
    "SUB_CACHE",
    "SUB_CACHE_TIME",
    "TMDB_BASE",
    "create_mediahelp_sub_task",
    "fetch_tmdb_by_id",
    "guess_media_type",
    "is_season_subscribed_from_cache",
    "logger",
    "mh_delete_subscription",
    "mh_get_defaults",
    "mh_list_subscriptions",
    "mh_search_media_by_name",
    "mh_update_subscription_seasons",
    "parse_selected_seasons",
    "refresh_sub_cache",
    "unsubscribe_with_season",

    # Preferred unified API
    "build_subscribe_payload",
    "ensure_mediahelp_subscription",
    "ensure_mediahelp_subscription_from_payload",
]
