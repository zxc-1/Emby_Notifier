from __future__ import annotations

from core.logging import get_biz_logger
import time
from typing import Any, Dict

import httpx

from core.http import get_http_client
from core.http import async_request_with_retry

from core.metrics import metrics

from .auth import login_mediahelp, mediahelp_headers
from .auth_state import get_mediahelp_state, mh_abs_url
from .config import log
from .notifications import notify_mediahelp

biz = get_biz_logger(__name__)

async def get_client() -> httpx.AsyncClient:
    return await get_http_client()


async def close_client() -> None:
    """No-op.

    The shared httpx.AsyncClient is managed by core.http_clients and closed by
    the app lifespan hook, not here.
    """
    return None


async def mh_request(
    method: str,
    url: str,
    *,
    with_auth: bool = True,
    retry_on_401: bool = True,
    timeout: float = 15.0,
    **kwargs: Any,
) -> httpx.Response:
    """Unified MediaHelp request (raw Response) with retry/timeout/metrics.

    Prefer mh_request_json() unless you truly need the raw Response.
    NOTE: Caller is responsible for closing the returned Response.
    """
    headers = kwargs.pop("headers", {}) or {}
    base_headers = mediahelp_headers(with_auth=with_auth)
    base_headers.update(headers)

    client = await get_client()

    # Resolve retry/timeout from settings.
    try:
        from settings.runtime import get_settings
        s = get_settings()
        max_attempts = int(getattr(s, "MEDIAHELP_HTTP_MAX_ATTEMPTS", 3) or 3)
        timeout = float(getattr(s, "MEDIAHELP_HTTP_TIMEOUT_SEC", timeout) or timeout)
        bo_first = float(getattr(s, "MEDIAHELP_HTTP_BACKOFF_FIRST_SEC", 0.0) or 0.0)
        bo_base = float(getattr(s, "MEDIAHELP_HTTP_BACKOFF_BASE_SEC", 1.0) or 1.0)
    except (ValueError, TypeError, AttributeError, ImportError):
        biz.detail("配置读取失败（已使用默认值）", default_retry=3, timeout=timeout)
        max_attempts = 3
        bo_first = 0.0
        bo_base = 1.0

    url = mh_abs_url(url)
    if not (url.startswith("http://") or url.startswith("https://")):
        raise httpx.InvalidURL(f"MediaHelp base URL not configured or invalid: {url!r}")

    params = kwargs.pop("params", None)
    json_body = kwargs.pop("json", None)
    data = kwargs.pop("data", None)
    files = kwargs.pop("files", None)

    async def _do(hdrs: Dict[str, str]) -> httpx.Response:
        t0 = time.perf_counter()
        resp = await async_request_with_retry(
            client,
            method,
            url,
            params=params,
            json=json_body,
            data=data,
            files=files,
            headers=hdrs,
            timeout=timeout,
            max_attempts=max_attempts,
            backoff=(bo_first, bo_base),
            log_ctx=f"mediahelp:{method} {url}",
        )
        dur_ms = int((time.perf_counter() - t0) * 1000)
        try:
            metrics.observe("external_request_ms", dur_ms, labels={"service": "mediahelp"})
            if 200 <= int(resp.status_code) < 400:
                metrics.inc("external_success_total", labels={"service": "mediahelp"})
            else:
                metrics.inc("external_error_total", labels={"service": "mediahelp", "status": str(int(resp.status_code))})
        except (ValueError, TypeError, AttributeError, RuntimeError):
            biz.detail("metrics 记录失败（已忽略）", dur_ms=dur_ms, status_code=getattr(resp, 'status_code', '?'))
        return resp

    resp = await _do(base_headers)

    if (
        resp.status_code == 401
        and retry_on_401
        and with_auth
        and (get_mediahelp_state().login_username)
        and (get_mediahelp_state().login_password)
    ):
        log("⚠️ MediaHelp 返回 401，尝试自动重新登录并重试一次")
        try:
            await notify_mediahelp(
                "mediahelp_not_authenticated",
                {"detail": "HTTP 401 / Not authenticated", "login_via": "forward"},
            )
        except (ValueError, TypeError, KeyError, RuntimeError):
            biz.detail("发送未认证通知失败（已忽略）", status_code=401)
        # close before retry to avoid pool leak
        try:
            await resp.aclose()
        except (RuntimeError, OSError):
            biz.detail("响应关闭失败（已忽略）", status_code=getattr(resp, 'status_code', '?'))
        st = get_mediahelp_state()
        ok = await login_mediahelp(st.login_username, st.login_password)  # type: ignore[arg-type]
        if ok:
            try:
                await notify_mediahelp(
                    "mediahelp_login_success",
                    {"username": st.login_username or "", "login_via": "forward"},
                )
            except (ValueError, TypeError, KeyError, RuntimeError):
                biz.detail("发送登录成功通知失败（已忽略）", username=st.login_username)
            base_headers = mediahelp_headers(with_auth=True)
            base_headers.update(headers)
            resp = await _do(base_headers)
        else:
            log("❌ 重新登录 MediaHelp 失败，放弃重试")
            try:
                await notify_mediahelp(
                    "mediahelp_login_failed",
                    {
                        "username": (get_mediahelp_state().login_username or ""),
                        "status_code": 401,
                        "reason": "HTTP 401 / Not authenticated",
                        "login_via": "forward",
                    },
                )
            except (ValueError, TypeError, KeyError, RuntimeError):
                biz.detail("发送登录失败通知失败（已忽略）", username=get_mediahelp_state().login_username)
    return resp
