from __future__ import annotations

"""MediaHelp HTTP client (compatibility facade).

Historically this module re-exported several module-level variables from
forward_bridge.auth (MEDIAHELP_TOKEN, ...). Those were a source of split-brain
state under reloads / multi-module imports.

We now keep the runtime state in :class:`forward_bridge.auth_state.MediaHelpAuthState`
and expose the legacy attributes dynamically via ``__getattr__``.
"""

from core.logging import get_biz_logger_adapter

from .auth import (
    have_token,
    init_mediahelp_runtime,
    login_mediahelp,
    mediahelp_headers,
    persist_mediahelp_token_to_env,
    set_mediahelp_token,
)
from .auth_state import get_mediahelp_state

# client
from .client import get_client, close_client, mh_request

# endpoints
from .endpoints import mh_execute_subscription, mh_request_json, mh_request_text

# retry helper (compat)
from core.http import async_request_with_retry

logger = get_biz_logger_adapter("forward_bridge")


# ---------------------------------------------------------------------------
# Backward-compatible dynamic attributes (read-only)
# ---------------------------------------------------------------------------

def __getattr__(name: str):
    st = get_mediahelp_state()
    if name == "MEDIAHELP_TOKEN":
        return st.token
    if name == "MEDIAHELP_TOKEN_TIME":
        return st.token_time
    if name == "MEDIAHELP_LOGIN_USERNAME":
        return st.login_username
    if name == "MEDIAHELP_LOGIN_PASSWORD":
        return st.login_password
    raise AttributeError(name)


__all__ = [
    # Legacy attrs (provided by __getattr__)
    "MEDIAHELP_TOKEN",
    "MEDIAHELP_TOKEN_TIME",
    "MEDIAHELP_LOGIN_USERNAME",
    "MEDIAHELP_LOGIN_PASSWORD",
    # Auth helpers
    "init_mediahelp_runtime",
    "set_mediahelp_token",
    "persist_mediahelp_token_to_env",
    "have_token",
    "mediahelp_headers",
    "login_mediahelp",
    # Client
    "get_client",
    "close_client",
    "mh_request",
    # Endpoints
    "mh_request_json",
    "mh_request_text",
    "mh_execute_subscription",
    # Retry helper
    "async_request_with_retry",
]
