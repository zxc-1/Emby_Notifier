"""
Forward-Bridge 对外入口。

主项目依然可以这样挂载：
    from forward_bridge.main import app as forward_app
"""
from .routes import app

__all__ = ["app"]