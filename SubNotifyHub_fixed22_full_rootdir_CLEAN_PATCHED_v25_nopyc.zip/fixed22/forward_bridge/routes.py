from __future__ import annotations

import asyncio
import json
from core.logging import get_biz_logger
import uuid
from contextlib import asynccontextmanager
from typing import Any, Dict, Optional, Tuple
from urllib.parse import unquote
from datetime import datetime, timezone

from fastapi import HTTPException
from fastapi import Depends, FastAPI, Request
from fastapi.responses import JSONResponse

from core.logging import set_kind, set_trace_id, get_trace_id
from core.task_registry import create_task_logged

biz = get_biz_logger(__name__)

from .config import (
    get_forward_bridge_debug,
    get_forward_bridge_enabled,
    get_forward_pending_heartbeat_sec,
    get_forward_pending_max_age_sec,
    get_forward_pending_ttl_sec,
    get_mediahelp_base,
    log,
    verify_forward_token,
)

from .http_client import login_mediahelp, persist_mediahelp_token_to_env
from .models import ForwardSubscribePayload, ForwardResponse, ForwardDataResponse
from .notifications import notify_mediahelp
from .subscription_api import ensure_mediahelp_subscription_from_payload
from .subscriptions_core import (
    get_subscriptions_snapshot,
    get_sub_entry,
    is_season_subscribed_from_cache,
    mh_delete_subscription,
    refresh_sub_cache,
)
from .subscriptions_tasks import unsubscribe_with_season

from .state import ForwardState

# One shared state instance for the forward-bridge FastAPI app.
_STATE = ForwardState()


@asynccontextmanager
async def _lifespan(app: FastAPI):
    # Keep lifespan crash-free: forward_bridge can be disabled or MediaHelp misconfigured.
    try:
        await _STATE.start()
    except (RuntimeError, ValueError, OSError) as e:
        biz.detail("forward_state 启动失败（已忽略）", reason=type(e).__name__, err=str(e))
    try:
        yield
    finally:
        try:
            await _STATE.shutdown()
        except (RuntimeError, ValueError, OSError) as e:
            biz.detail("forward_state 关闭失败（已忽略）", reason=type(e).__name__, err=str(e))


app = FastAPI(lifespan=_lifespan)




def _resp(ok: bool, message: str = "", data: Any | None = None, *, code: str | None = None) -> dict:
    """Stable response shape with trace_id (and optional code)."""
    trace_id = ""
    try:
        trace_id = get_trace_id()
    except (AttributeError, ValueError) as e:
        biz.detail("获取 trace_id 失败（已忽略）", reason=type(e).__name__)
        trace_id = ""
    base = dict(ok=bool(ok), message=str(message or ""), trace_id=trace_id)
    if code:
        base["code"] = str(code)
    if data is None:
        return ForwardResponse(**base).model_dump()
    return ForwardDataResponse(**base, data=data).model_dump()



def _pending_key(tmdb_id: int, season: Optional[int]) -> Tuple[int, Optional[int]]:
    return _STATE.key(int(tmdb_id), season)


def _pending_active(tmdb_id: int, season: Optional[int]) -> bool:
    return _STATE.pending_active(_pending_key(tmdb_id, season), kind="sub")


def _pending_unsub_active(tmdb_id: int, season: Optional[int]) -> bool:
    return _STATE.pending_active(_pending_key(tmdb_id, season), kind="unsub")


def ensure_enabled() -> None:
    """FastAPI dependency: reject requests when forward-bridge is disabled."""
    if not bool(get_forward_bridge_enabled()):
        raise HTTPException(status_code=503, detail="forward bridge disabled")

def _parse_tmdb_from_mediaid(mediaid: str) -> Optional[int]:
    """Parse tmdb id from Forward mediaid.

    Forward may send values like:
    - "tmdb:123"
    - "TMDB:tv:123"
    - URL-encoded variants

    We accept case-insensitive prefix and extract the last integer segment.
    """
    raw = unquote(mediaid or "")
    try:
        import re

        nums = re.findall(r"(\d+)", raw)
        if not nums:
            return None
        return int(nums[-1])
    except (ValueError, TypeError, IndexError) as e:
        biz.detail("解析 mediaid 失败（已忽略）", input=repr(mediaid), reason=type(e).__name__)
        return None


async def _bg_ensure_sub(p: ForwardSubscribePayload, tmdb_id: int, season: Optional[int]) -> None:
    """Run real subscribe work in background.

    Goals:
    - keep HTTP response fast (Forward side can toast instantly)
    - do real MediaHelp create/update in background
    - on failure: clear pending and notify via TG
    """
    key = _pending_key(tmdb_id, season)
    try:
        ok, detail = await ensure_mediahelp_subscription_from_payload(p)
        if not ok:
            try:
                await _STATE.clear_pending(key)
            except (ValueError, KeyError, RuntimeError) as e:
                biz.detail("清除 pending 状态失败（已忽略）", key=str(key), reason=type(e).__name__)
                pass
            await notify_mediahelp(
                "forward_subscribe_failed",
                {"tmdb_id": tmdb_id, "season": season, "detail": detail},
            )
            return

        # Success: refresh cache (async) and clear pending
        try:
            create_task_logged(refresh_sub_cache(force=True), name="refresh_sub_cache", log=biz)
        except (RuntimeError, ValueError) as e:
            biz.detail("后台刷新订阅缓存任务创建失败（已忽略）", reason=type(e).__name__)
            pass
        try:
            await _STATE.clear_pending(key)
        except (ValueError, KeyError) as e:
            biz.detail("清除 pending 状态失败（已忽略）", key=str(key), reason=type(e).__name__)
            pass
    except Exception as e:
        try:
            await _STATE.clear_pending(key)
        except (ValueError, KeyError) as e2:
            biz.detail("清除 pending 状态失败（已忽略）", key=str(key), reason=type(e2).__name__)
            pass
        biz.fail("forward_subscribe: 后台订阅任务崩溃", exc_info=True)
        try:
            await notify_mediahelp(
                "forward_subscribe_failed",
                {"tmdb_id": tmdb_id, "season": season, "detail": str(e)},
            )
        except (ValueError, TypeError, KeyError) as e2:
            biz.detail("发送订阅失败通知失败（已忽略）", reason=type(e2).__name__)
            pass


async def _bg_ensure_unsub(tmdb_id: int, season: Optional[int]) -> None:
    """Background unsubscribe for Forward."""
    key = _pending_key(tmdb_id, season)
    try:
        if season is not None:
            result = await unsubscribe_with_season(int(tmdb_id), int(season))
            ok = bool(result.get("ok"))
            detail = result.get("detail") or result.get("message") or ""
        else:
            ok, detail = await mh_delete_subscription(int(tmdb_id))

        if not ok:
            try:
                await _STATE.clear_pending(key)
            except (ValueError, KeyError) as e:
                biz.detail("清除 pending 状态失败（已忽略）", key=str(key), reason=type(e).__name__)
                pass
            await notify_mediahelp(
                "forward_unsubscribe_failed",
                {"tmdb_id": tmdb_id, "season": season, "detail": detail},
            )
            return

        try:
            create_task_logged(refresh_sub_cache(force=True), name="refresh_sub_cache", log=biz)
        except (RuntimeError, ValueError) as e:
            biz.detail("后台刷新订阅缓存任务创建失败（已忽略）", reason=type(e).__name__)
            pass
        try:
            await _STATE.clear_pending(key)
        except (ValueError, KeyError) as e:
            biz.detail("清除 pending 状态失败（已忽略）", key=str(key), reason=type(e).__name__)
            pass
    except Exception as e:
        try:
            await _STATE.clear_pending(key)
        except (ValueError, KeyError) as e2:
            biz.detail("清除 pending 状态失败（已忽略）", key=str(key), reason=type(e2).__name__)
            pass
        biz.fail("forward_unsubscribe: 后台取消订阅任务崩溃", exc_info=True)
        try:
            await notify_mediahelp(
                "forward_unsubscribe_failed",
                {"tmdb_id": tmdb_id, "season": season, "detail": str(e)},
            )
        except (ValueError, TypeError, KeyError) as e2:
            biz.detail("发送取消订阅失败通知失败（已忽略）", reason=type(e2).__name__)
            pass


@app.get("/ping", response_model=ForwardDataResponse)
async def ping() -> Dict[str, Any]:
    log("收到 /ping")
    # Keep as a liveness endpoint. Also expose readiness hints for troubleshooting.
    return _resp(
        True,
        "forward-mediahelp-bridge alive",
        data={
            "enabled": bool(get_forward_bridge_enabled()),
            "mediahelp_base_configured": bool(get_mediahelp_base()),
        },
    )



# -------------------- Debug -------------------- #

@app.get(
    "/debug/sub-cache",
    response_model=ForwardDataResponse,
    dependencies=[Depends(verify_forward_token), Depends(ensure_enabled)],
)
async def debug_sub_cache():
    # 注意：debug 路由永远存在，但是否可用由运行态配置决定（无需重启容器）。
    if not get_forward_bridge_debug():
        raise HTTPException(status_code=404, detail="debug api disabled")

    await refresh_sub_cache()
    items = []
    for tmdb_id, entry in get_subscriptions_snapshot().items():
        items.append(
            {
                "tmdb_id": tmdb_id,
                "name": entry.get("name"),
                "uuid": entry.get("uuid"),
                "cron": entry.get("cron"),
                "selected_seasons": entry.get("selected_seasons") or [],
            }
        )
    return _resp(True, "ok", data={"items": items})

# -------------------- API -------------------- #


@app.post(
    "/api/v1/login/access-token",
    dependencies=[Depends(ensure_enabled), Depends(verify_forward_token)],
)
async def login_access_token(request: Request):
    """
    Forward 配置页 “测试链接”：POST username/password 过来。
    这里帮它去 MediaHelp 登录，并缓存 token。
    """
    form = await request.form()
    username = (form.get("username") or "").strip()
    password = (form.get("password") or "").strip()
    with biz.entry(domain="ForwardBridge", action="测试登录", group_title="Forward 测试登录", username=username):
        biz.step("解析登录表单", i=1, total=4, username=username)
        log(f"📩 Forward 登录: username={username}")
        # 已开启 Forward 联动：仍需要 MEDIAHELP_BASE
        base = get_mediahelp_base()
        if not base:
            biz.fail("MEDIAHELP_BASE 未配置", code="MEDIAHELP_BASE_MISSING")
            log("⚠️ MEDIAHELP_BASE missing (forward-bridge enabled)")
            raise HTTPException(
                status_code=503,
                detail="MEDIAHELP_BASE is not set (forward-bridge enabled)",
            )


        if not username or not password:
            return JSONResponse(_resp(False, "username or password empty", code="USERNAME_OR_PASSWORD_EMPTY"), status_code=422)

        biz.step("调用 MediaHelp 登录", i=2, total=4, username=username)
        ok = await login_mediahelp(username, password)
        if not ok:
            biz.fail("MediaHelp 登录失败", username=username, status_code=401)
            try:
                await notify_mediahelp(
                    "mediahelp_login_failed",
                    {
                        "username": username,
                        "status_code": 401,
                        "reason": "login to MediaHelp failed",
                        "login_via": "forward",
                        "source_tag": "Forward 客户端",
                    },
                )
            except (ValueError, TypeError, KeyError) as e:
                biz.detail("发送登录失败通知失败（已忽略）", reason=type(e).__name__)
                pass
            return JSONResponse(_resp(False, "login to MediaHelp failed", code="MEDIAHELP_LOGIN_FAILED"), status_code=401)

        biz.ok("MediaHelp 登录成功", username=username)
        try:
            await notify_mediahelp(
                "mediahelp_login_success",
                {"username": username, "login_via": "forward", "source_tag": "Forward 客户端"},
            )
        except (ValueError, TypeError, KeyError) as e:
            biz.detail("发送登录成功通知失败（已忽略）", reason=type(e).__name__)
            pass

        # Sync to .env so Admin UI/TG bot see the same persisted token
        biz.step("持久化 token", i=3, total=4)
        try:
            await asyncio.to_thread(persist_mediahelp_token_to_env, source="forward_test_login")
            biz.ok("token 已持久化")
        except Exception as e:
            biz.warning("token 持久化失败", err=f"{type(e).__name__}: {e}")
            biz.detail("Forward：persist mediahelp token to env 失败", exc_info=True)

        biz.step("刷新订阅缓存", i=4, total=4, force=True)
        await refresh_sub_cache(force=True)
        biz.ok("订阅缓存已刷新")

        return JSONResponse(
            {
                "access_token": "forward-mediahelp-bridge",
                "token_type": "bearer",
                "ok": True,
                "msg": "ok",
                "data": {},
            },
            status_code=200,
        )
@app.get(
    "/api/v1/subscribe/user/{username}",
    response_model=ForwardDataResponse,
    dependencies=[Depends(verify_forward_token), Depends(ensure_enabled)],
)
async def forward_user_subscribe_list(username: str, refresh: bool = False):
    with biz.entry(domain="ForwardBridge", action="订阅列表", group_title="Forward 查询订阅", username=username, refresh=bool(refresh)):
        log(f"📥 Forward 查询用户订阅列表: username={username}")
        # Forward 端会频繁拉这个接口；默认走 TTL 缓存避免压垮 MediaHelp。
        biz.step("刷新订阅缓存", i=1, total=2, refresh=bool(refresh), username=username)
        # 如确实需要强刷，Forward 可带 ?refresh=1
        await refresh_sub_cache(force=bool(refresh))
        items = []
        for tmdb_id, entry in get_subscriptions_snapshot().items():
            try:
                items.append(
                    {
                        "tmdb_id": tmdb_id,
                        "name": entry.get("name"),
                        "uuid": entry.get("uuid"),
                        "cron": entry.get("cron"),
                        "selected_seasons": entry.get("selected_seasons") or [],
                        "full_season": not bool(entry.get("selected_seasons") or []),
                    }
                )
            except (ValueError, TypeError, KeyError) as e:
                biz.detail("打印订阅列表项失败（已跳过）", reason=type(e).__name__)
                continue
        items.sort(key=lambda x: int(x.get("tmdb_id") or 0))
        biz.ok("返回订阅列表", username=username, items=len(items))
        biz.step("HTTP 返回", i=2, total=2)
        return _resp(True, "ok", data={"username": username, "items": items})


@app.post(
    "/api/v1/subscribe/",
    response_model=ForwardResponse,
    dependencies=[Depends(verify_forward_token), Depends(ensure_enabled)],
)
async def forward_subscribe(payload: ForwardSubscribePayload):
    biz.detail("📩 收到 Forward 订阅请求", stage="forward_bridge", tmdbid=getattr(payload, "tmdbid", None), season=getattr(payload, "season", None))
    biz.step("解析订阅请求", i=1, total=4, tmdbid=getattr(payload, "tmdbid", None), season=getattr(payload, "season", None))
    log("📩 Forward 订阅请求:")
    try:
        log("  payload = " + json.dumps(payload.model_dump(), ensure_ascii=False))
    except (ValueError, TypeError) as e:
        biz.detail("打印订阅请求 payload 失败（已忽略）", reason=type(e).__name__)
        log("  payload = <print failed>")

    if payload.tmdbid == "-1":
        biz.warning("测试请求：不创建任务", stage="forward_bridge", reason="dry_run")
        log("  tmdbid=-1，测试请求，不创建 MediaHelp 任务")
        return _resp(True, "test only, no action")

    # 解析 tmdb_id / season（只做轻量校验，避免阻塞）
    try:
        tmdb_id = int(payload.tmdbid)
    except (ValueError, TypeError) as e:
        biz.warning("⚠️ TMDB ID 解析失败", 输入=repr(payload.tmdbid))
        detail = f"invalid tmdbid: {payload.tmdbid}"
        return JSONResponse(_resp(False, "tmdbid 无法解析为整数", data={"detail": detail}, code="INVALID_TMDBID"), status_code=422)

    season: Optional[int] = None
    try:
        season = int(payload.season) if payload.season is not None else None
    except (ValueError, TypeError) as e:
        biz.detail("季数解析失败（已忽略）", input=repr(payload.season), reason=type(e).__name__)
        season = None

    key = _pending_key(tmdb_id, season)

    biz.step("pending 去重/互斥", i=2, total=4)

    # ✅ pending + 去重：同一 key 同一动作只跑一个任务；重复点击只延长 TTL
    if _STATE.pending_active(key, kind="sub") and (_STATE.task_kind(key) == "sub"):
        try:
            await _STATE.mark_pending(key, "sub")
        except (ValueError, KeyError) as e:
            biz.detail("延长 pending TTL 失败（已忽略）", key=str(key), reason=type(e).__name__)
            pass
        biz.warning("重复点击：延长 pending TTL", tmdb_id=tmdb_id, season=season)
        biz.step("HTTP 返回", i=4, total=4)
        return _resp(True, "accepted")

    # 若当前有反向动作在跑（unsub），取消它，以最新操作为准
    if _STATE.task_kind(key) == "unsub":
        try:
            await _STATE.cancel_task(key)
        except (ValueError, KeyError) as e:
            biz.detail("取消反向任务失败（已忽略）", key=str(key), reason=type(e).__name__)
            pass

    # 乐观标记 pending（Forward 秒弹）
    try:
        await _STATE.mark_pending(key, "sub")
    except (ValueError, KeyError) as e:
        biz.detail("标记 pending 失败（已忽略）", key=str(key), reason=type(e).__name__)
        pass

    biz.step("调度后台任务", i=3, total=4, action="subscribe")
    # 后台执行真正订阅任务，HTTP 立刻返回
    try:
        task = create_task_logged(
            _bg_ensure_sub(payload, tmdb_id, season),
            name=f"forward_bg_sub:{tmdb_id}:{season}",
            log=biz,
        )
        try:
            await _STATE.register_task(key, "sub", task)
        except (ValueError, KeyError) as e:
            biz.detail("注册后台任务失败（已忽略）", key=str(key), reason=type(e).__name__)
            pass
        biz.ok("已受理订阅请求", tmdb_id=tmdb_id, season=season)
    except (RuntimeError, ValueError) as e:
        try:
            await _STATE.clear_pending(key)
        except (ValueError, KeyError):
            pass
        biz.fail("❌ 创建订阅后台任务失败", tmdb_id=tmdb_id, season=season, error=str(e)[:80])

    return _resp(True, "accepted")


@app.delete(
    "/api/v1/subscribe/",
    response_model=ForwardResponse,
    dependencies=[Depends(verify_forward_token), Depends(ensure_enabled)],
)
async def forward_unsubscribe(payload: ForwardSubscribePayload):
    biz.detail("📩 收到 Forward 取消订阅请求", stage="forward_bridge", tmdbid=getattr(payload, "tmdbid", None), season=getattr(payload, "season", None))
    biz.step("解析取消订阅请求", i=1, total=4, tmdbid=getattr(payload, "tmdbid", None), season=getattr(payload, "season", None))
    log("📩 Forward 取消订阅请求(body):")
    try:
        log("  payload = " + json.dumps(payload.model_dump(), ensure_ascii=False))
    except (ValueError, TypeError) as e:
        biz.detail("打印取消订阅请求 payload 失败（已忽略）", reason=type(e).__name__)
        log("  payload = <print failed>")

    try:
        tmdb_id = int(payload.tmdbid)
    except (ValueError, TypeError) as e:
        biz.warning("⚠️ TMDB ID 解析失败", 输入=repr(payload.tmdbid))
        msg = f"invalid tmdbid in unsubscribe: {payload.tmdbid}"
        log(f"❌ {msg}")
        return JSONResponse(_resp(False, msg, data={"detail": msg}, code="INVALID_TMDBID"), status_code=422)

    season: Optional[int] = None
    try:
        season = int(payload.season) if payload.season is not None else None
    except (ValueError, TypeError) as e:
        biz.detail("季数解析失败（已忽略）", input=repr(payload.season), reason=type(e).__name__)
        season = None

    biz.ok("解析 tmdb_id", tmdb_id=tmdb_id, season=season)
    biz.step("pending 去重/互斥", i=2, total=4, action="unsubscribe")

    key = _pending_key(tmdb_id, season)

    # ✅ pending + 去重：同一 key 同一动作只跑一个任务；重复点击只延长 TTL
    if _STATE.pending_active(key, kind="unsub") and (_STATE.task_kind(key) == "unsub"):
        try:
            await _STATE.mark_pending(key, "unsub")
        except (ValueError, KeyError, RuntimeError):
            biz.detail("延长 pending TTL 失败（已忽略）", key=str(key))
        biz.warning("重复点击：延长 pending TTL", tmdb_id=tmdb_id, season=season)
        biz.step("HTTP 返回", i=4, total=4)
        return _resp(True, "accepted")

    # 若当前有反向动作在跑（sub），取消它，以最新操作为准
    if _STATE.task_kind(key) == "sub":
        try:
            await _STATE.cancel_task(key)
        except (ValueError, KeyError, RuntimeError):
            biz.detail("取消反向任务失败（已忽略）", key=str(key))

    # 乐观标记 pending（Forward 秒弹“未订阅”）
    try:
        await _STATE.mark_pending(key, "unsub")
    except (ValueError, KeyError, RuntimeError):
        biz.detail("标记 pending 失败（已忽略）", key=str(key))

    biz.step("调度后台任务", i=3, total=4, action="unsubscribe")
    # 后台执行真正取消订阅，HTTP 立刻返回
    try:
        task = create_task_logged(
            _bg_ensure_unsub(tmdb_id, season),
            name=f"forward_bg_unsub:{tmdb_id}:{season}",
            log=biz,
        )
        try:
            await _STATE.register_task(key, "unsub", task)
        except (ValueError, KeyError) as e:
            biz.detail("注册后台任务失败（已忽略）", key=str(key), reason=type(e).__name__)
            pass
        biz.ok("已受理取消订阅", tmdb_id=tmdb_id, season=season)
    except (RuntimeError, ValueError) as e:
        try:
            await _STATE.clear_pending(key)
        except (ValueError, KeyError):
            pass
        biz.fail("❌ 创建取消订阅后台任务失败", tmdb_id=tmdb_id, season=season, error=str(e)[:80])

    return _resp(True, "accepted")


@app.delete(
    "/api/v1/subscribe/media/{mediaid}",
    response_model=ForwardDataResponse,
    dependencies=[Depends(verify_forward_token), Depends(ensure_enabled)],
)
async def forward_unsubscribe_by_mediaid(
    mediaid: str,
    season: Optional[int] = None,
):
    biz.detail("📩 收到 Forward mediaid 取消订阅请求", stage="forward_bridge", mediaid=mediaid, season=season)
    biz.step("解析 mediaid 取消订阅", i=1, total=4, mediaid=mediaid, season=season)
    log(f"📩 Forward 取消订阅请求(mediaid): {mediaid} season={season}")

    tmdb_id = _parse_tmdb_from_mediaid(mediaid)
    if tmdb_id is not None:
        biz.ok("解析 tmdb_id", tmdb_id=tmdb_id, season=season)
    biz.step("pending 去重/互斥", i=2, total=4)
    if tmdb_id is None:
        msg = f"invalid mediaid in unsubscribe: {mediaid}"
        log(f"❌ {msg}")
        return JSONResponse(_resp(False, msg, data={"detail": msg}, code="INVALID_MEDIAID"), status_code=422)

    key = _pending_key(tmdb_id, season)

    if _STATE.pending_active(key, kind="unsub") and (_STATE.task_kind(key) == "unsub"):
        try:
            await _STATE.mark_pending(key, "unsub")
        except (ValueError, KeyError) as e:
            biz.detail("延长 pending TTL 失败（已忽略）", key=str(key), reason=type(e).__name__)
            pass
        biz.warning("重复点击：延长 pending TTL", tmdb_id=tmdb_id, season=season)
        biz.step("HTTP 返回", i=4, total=4)
        return _resp(True, "accepted")

    if _STATE.task_kind(key) == "sub":
        try:
            await _STATE.cancel_task(key)
        except (ValueError, KeyError) as e:
            biz.detail("取消反向任务失败（已忽略）", key=str(key), reason=type(e).__name__)
            pass

    try:
        await _STATE.mark_pending(key, "unsub")
    except (ValueError, KeyError) as e:
        biz.detail("标记 pending 失败（已忽略）", key=str(key), reason=type(e).__name__)
        pass

    biz.step("调度后台任务", i=3, total=4, action="unsubscribe")

    try:
        task = create_task_logged(
            _bg_ensure_unsub(int(tmdb_id), season),
            name=f"forward_bg_unsub:{tmdb_id}:{season}",
            log=biz,
        )
        try:
            await _STATE.register_task(key, "unsub", task)
        except (ValueError, KeyError) as e:
            biz.detail("注册后台任务失败（已忽略）", key=str(key), reason=type(e).__name__)
            pass
        biz.ok("已受理取消订阅", tmdb_id=tmdb_id, season=season)
    except (RuntimeError, ValueError) as e:
        try:
            await _STATE.clear_pending(key)
        except (ValueError, KeyError):
            pass
        biz.fail("❌ 创建取消订阅后台任务失败", tmdb_id=tmdb_id, season=season, error=str(e)[:80])

    return _resp(True, "accepted")


@app.get(
    "/api/v1/subscribe/media/{mediaid}",
    response_model=ForwardDataResponse,
    dependencies=[Depends(verify_forward_token), Depends(ensure_enabled)],
)
async def forward_subscribe_status(
    mediaid: str,
    season: Optional[int] = None,
    refresh: bool = False,
):
    log(f"🔍 Forward 查询订阅状态: {mediaid} season={season} refresh={refresh}")

    tmdb_id = _parse_tmdb_from_mediaid(mediaid)
    if tmdb_id is None:
        log(f"⚠️ mediaid 解析 tmdb 失败: {mediaid}")
        return _resp(True, "ok", data={"subscribed": False, "mediaid": mediaid})

    # pending 优先：让 Forward 端的状态查询不被 MediaHelp 网络耗时影响
    if _pending_unsub_active(tmdb_id, season):
        return _resp(True, "ok", data={"subscribed": False, "mediaid": mediaid})
    if _pending_active(tmdb_id, season):
        return _resp(True, "ok", data={"subscribed": True, "mediaid": mediaid})

    if refresh:
        await refresh_sub_cache(force=True)
    else:
        await refresh_sub_cache()

    subscribed = is_season_subscribed_from_cache(tmdb_id, season)
    entry = get_sub_entry(tmdb_id)

    log(
        f"🔎 状态: mediaid={mediaid} tmdb_id={tmdb_id} "
        f"season={season} subscribed={subscribed}"
    )

    data: Dict[str, Any] = {
        "subscribed": subscribed,
        "mediaid": mediaid,
    }

    if entry:
        seasons = entry.get("selected_seasons") or []
        data.update(
            name=entry.get("name"),
            uuid=entry.get("uuid"),
            cron=entry.get("cron"),
            seasons=seasons,
            full_season=not bool(seasons),
        )

    return _resp(True, "ok", data=data)

