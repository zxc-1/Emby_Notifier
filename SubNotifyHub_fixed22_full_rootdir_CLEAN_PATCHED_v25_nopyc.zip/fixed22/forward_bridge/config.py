from __future__ import annotations

import re
from typing import Optional

from fastapi import Header, HTTPException, Request

from core.logging import get_biz_logger
from settings.runtime import get_settings

# 引用全局 Settings 单例（reload_settings 会原地更新它）

def _cur_settings():
    return get_settings()

# 统一 logger - 使用 BizLogger
biz = get_biz_logger("forward_bridge")

# Best-effort redaction for logs.
_SENSITIVE_PATTERNS = [
    (re.compile(r"(?i)(tg_bot_token\s*[:=]\s*)([^\s,;]+)"), r"\1<hidden>"),
    (re.compile(r"(?i)(emby_api_key\s*[:=]\s*)([^\s,;]+)"), r"\1<hidden>"),
    (re.compile(r"(?i)(tmdb_api_key\s*[:=]\s*)([^\s,;]+)"), r"\1<hidden>"),
    (re.compile(r"(?i)(webhook_secret\s*[:=]\s*)([^\s,;]+)"), r"\1<hidden>"),
    (re.compile(r"(?i)(forward_bridge_token\s*[:=]\s*)([^\s,;]+)"), r"\1<hidden>"),
    (re.compile(r"(?i)(x-forward-token\s*[:=]\s*)([^\s,;]+)"), r"\1<hidden>"),
    (re.compile(r"(?i)(password\s*[:=]\s*)([^\s,;]+)"), r"\1<hidden>"),
    # Generic fallback
    (re.compile(r"(?i)(token\s*[:=]\s*)([^\s,;]+)"), r"\1<hidden>"),
]

def _kind_for_msg(msg: str) -> str:
    m = str(msg or "")
    if m.startswith("✅") or m.startswith("OK"):
        return "ok"
    if m.startswith("📥") or "查询" in m or "refresh" in m.lower():
        return "fetch"
    if m.startswith("📩") or "订阅" in m or "取消" in m or "登录" in m or "请求" in m:
        return "run"
    return ""


def log(msg: str) -> None:
    """Forward bridge logger with automatic action coloring."""
    clean = _sanitize_text(str(msg))
    kind = _kind_for_msg(clean)
    # Map emoji prefixes to log levels (keeps warnings/errors colored correctly)
    if clean.startswith("❌"):
        biz.fail(clean, stage="forward_bridge_log", event=kind or None)
        return
    if clean.startswith("⚠️"):
        biz.warning(clean, stage="forward_bridge_log", event=kind or None)
        return
    if kind == "ok":
        biz.ok(clean, stage="forward_bridge_log", event=kind)
    else:
        # run/fetch/other are noisy; keep them as detail by default
        biz.detail(clean, stage="forward_bridge_log", event=kind or None)

def _sanitize_text(text: str) -> str:
    if not text:
        return text
    out = text
    for pat, repl in _SENSITIVE_PATTERNS:
        try:
            out = pat.sub(repl, out)
        except (ValueError, TypeError, AttributeError) as e:
            # Best-effort; never break logging
            biz.detail("敏感信息脱敏失败", error=type(e).__name__)
            continue
    return out

# ① Forward-Bridge 运行时配置：全部从 Settings 单例读取，支持 UI 保存后热更新。
# 注意：Settings 会从 /data/.env 与 /data/.env 读取；admin 保存配置后会 reload_settings()。

def _as_str(v) -> str:
    try:
        return str(v) if v is not None else ""
    except Exception:
        biz.fail("意外异常", exc_info=True)
        return ""

def get_forward_bridge_enabled() -> bool:
    # Runtime flag (hot-reload via Settings singleton).
    # Default is True (see Settings.FORWARD_BRIDGE_ENABLED).
    try:
        return bool(getattr(_cur_settings(), "FORWARD_BRIDGE_ENABLED", True))
    except Exception:
        biz.fail("意外异常", exc_info=True)
        return True



def get_enable_season_filter() -> bool:
    """Whether season-level filtering is enabled.

    Kept for backward compatibility with v40.
    """
    try:
        return bool(getattr(_cur_settings(), "ENABLE_SEASON_FILTER", False))
    except Exception:
        biz.fail("意外异常", exc_info=True)
        return False


def get_mediahelp_base() -> str:
    base = getattr(_cur_settings(), "MEDIAHELP_BASE", None)
    s = _as_str(base).strip()
    return s.rstrip("/") if s else ""

def get_forward_bridge_token() -> str:
    tok = getattr(_cur_settings(), "FORWARD_BRIDGE_TOKEN", None)
    return _as_str(tok).strip()

def get_mediahelp_token_ttl() -> int:
    try:
        return int(getattr(_cur_settings(), "FORWARD_BRIDGE_TOKEN_TTL", 29 * 86400) or 29 * 86400)
    except Exception:
        biz.fail("意外异常", exc_info=True)
        return 29 * 86400

def get_sub_cache_ttl() -> int:
    try:
        return int(getattr(_cur_settings(), "FORWARD_BRIDGE_SUB_CACHE_TTL", 600) or 600)
    except Exception:
        biz.fail("意外异常", exc_info=True)
        return 600


def get_sub_cache_min_interval_sec() -> float:
    """Minimum interval between two real MediaHelp list refreshes.

    This is mainly to protect MediaHelp when Forward polls status frequently.
    Default: 2.0s.
    """
    try:
        return float(getattr(_cur_settings(), "FORWARD_BRIDGE_SUB_CACHE_MIN_INTERVAL_SEC", 2.0) or 2.0)
    except Exception:
        biz.fail("意外异常", exc_info=True)
        return 2.0


def get_forward_pending_ttl_sec() -> float:
    """How long pending state is kept without heartbeats (seconds). Default 20s."""
    try:
        return float(getattr(_cur_settings(), "FORWARD_BRIDGE_PENDING_TTL_SEC", 20.0) or 20.0)
    except (ValueError, TypeError, AttributeError) as e:
        biz.detail("pending TTL 读取失败，使用默认值 20.0", error=type(e).__name__)
        return 20.0


def get_forward_pending_max_age_sec() -> float:
    """Hard cap for a pending state (seconds). Default 180s."""
    try:
        return float(getattr(_cur_settings(), "FORWARD_BRIDGE_PENDING_MAX_AGE_SEC", 180.0) or 180.0)
    except (ValueError, TypeError, AttributeError) as e:
        biz.detail("pending 最大年龄读取失败，使用默认值 180.0", error=type(e).__name__)
        return 180.0


def get_forward_pending_heartbeat_sec() -> float:
    """Heartbeat interval for extending pending while bg tasks are running. Default 5s."""
    try:
        return float(getattr(_cur_settings(), "FORWARD_BRIDGE_PENDING_HEARTBEAT_SEC", 5.0) or 5.0)
    except (ValueError, TypeError, AttributeError) as e:
        biz.detail("pending 心跳间隔读取失败，使用默认值 5.0", error=type(e).__name__)
        return 5.0

def get_forward_bridge_debug() -> bool:
    return bool(getattr(_cur_settings(), "FORWARD_BRIDGE_DEBUG", False))

def get_forward_allow_no_token() -> bool:
    """Whether Forward Bridge is allowed to run WITHOUT a token.

    User requirement:
    - If FORWARD_BRIDGE_TOKEN is NOT set: default is **ALLOW** (backward compatible).
    - Operator can explicitly disable by setting FORWARD_BRIDGE_ALLOW_NO_TOKEN=0/false/no/off.
    - Explicit enable values are: 1/true/yes/on (case-insensitive).

    Default: True.
    """
    try:
        v = getattr(_cur_settings(), "FORWARD_BRIDGE_ALLOW_NO_TOKEN", None)
    except (ValueError, TypeError, AttributeError) as e:
        biz.detail("无 token 允许标志读取失败，使用默认值 None", error=type(e).__name__)
        v = None

    # Default allow (backward compatible)
    if v is None:
        return True

    try:
        s = str(v).strip().lower()
    except (ValueError, TypeError, AttributeError) as e:
        biz.detail("无 token 允许标志转换失败，使用默认值 True", value=repr(v), error=type(e).__name__)
        return True

    if not s:
        return True
    if s in {"1", "true", "yes", "on"}:
        return True
    if s in {"0", "false", "no", "off"}:
        return False
    # Unknown values fall back to default allow
    return True


async def verify_forward_token(
    request: Request,
    x_forward_token: Optional[str] = Header(None),
) -> None:
    """Verify Forward Bridge request token.

    Default behavior (backward compatible):
  - If FORWARD_BRIDGE_TOKEN is set: require `X-Forward-Token: <token>`.
  - If FORWARD_BRIDGE_TOKEN is NOT set: allow requests by default.
    Set FORWARD_BRIDGE_ALLOW_NO_TOKEN=0/false/no/off to explicitly deny.
    """
    token = get_forward_bridge_token()
    if not token:
        if get_forward_allow_no_token():
            return
        try:
            client = getattr(request, 'client', None)
            host = getattr(client, 'host', '?') if client else '?'
        except (ValueError, TypeError, AttributeError) as e:
            biz.detail("客户端信息获取失败，使用默认值", error=type(e).__name__)
            host = '?'
        log(f"❌ Forward 鉴权失败: 未配置 FORWARD_BRIDGE_TOKEN 且已显式禁止无 Token (FORWARD_BRIDGE_ALLOW_NO_TOKEN=0) from={host} path={request.url.path}")
        raise HTTPException(status_code=401, detail="forward token not configured and no-token access is disabled")
    if x_forward_token != token:
        try:
            client = getattr(request, 'client', None)
            host = getattr(client, 'host', '?') if client else '?'
        except (ValueError, TypeError, AttributeError) as e:
            biz.detail("客户端信息获取失败，使用默认值", error=type(e).__name__)
            host = '?'
        log(f"❌ Forward 鉴权失败: 缺少/错误的 X-Forward-Token from={host} path={request.url.path}")
        raise HTTPException(status_code=401, detail="invalid or missing forward token")
