from __future__ import annotations

import re
from typing import Optional, Any

from pydantic import BaseModel, Field, field_validator
from pydantic import AliasChoices


class ForwardSubscribePayload(BaseModel):
    """Forward 发过来的订阅/取消订阅请求体"""

    name: Optional[str] = None
    tmdbid: str
    type: Optional[str] = None
    year: Optional[str] = None
    # Forward 侧可能会用不同字段名传季信息（历史兼容）：
    # - season
    # - season_number / seasonNumber
    # - season_num / seasonNum
    season: Optional[int] = Field(
        default=None,
        validation_alias=AliasChoices(
            "season",
            "season_number",
            "seasonNumber",
            "season_num",
            "seasonNum",
            "seasonNo",
        ),
    )

    # 订阅来源上下文（用于通知模板展示）
    source_tag: Optional[str] = None      # e.g. "🔥 热榜订阅" / "🔗 分享链接" / "🔍 搜索订阅"
    source_label: Optional[str] = None    # e.g. "榜单" / "来源" / "关键词"
    source_value: Optional[str] = None    # e.g. "实时热门电影（包含当前）" / "<分享标题或链接>" / "<搜索关键词>"



    @field_validator("name", mode="before")
    @classmethod
    def _normalize_name(cls, v: Any) -> Any:
        if v is None:
            return None
        if isinstance(v, str):
            v2 = v.strip()
            return v2 or None
        return v


    @field_validator("source_tag", mode="before")
    @classmethod
    def _normalize_source_tag(cls, v: Any) -> Any:
        if v is None:
            return None
        if isinstance(v, str):
            v2 = v.strip()
            return v2 or None
        return v

    @field_validator("source_label", mode="before")
    @classmethod
    def _normalize_source_label(cls, v: Any) -> Any:
        if v is None:
            return None
        if isinstance(v, str):
            v2 = v.strip()
            return v2 or None
        return v

    @field_validator("source_value", mode="before")
    @classmethod
    def _normalize_source_value(cls, v: Any) -> Any:
        if v is None:
            return None
        if isinstance(v, str):
            v2 = v.strip()
            return v2 or None
        return v

    @field_validator("year", mode="before")
    @classmethod
    def _normalize_year(cls, v: Any) -> Any:
        """Accept int/str and normalize to stripped string.

        This prevents pydantic v2 ValidationError when callers pass year=2025 (int).
        """
        if v is None:
            return None
        if isinstance(v, bool):
            # bool is subclass of int, treat as invalid
            raise TypeError("year must be str or int")
        if isinstance(v, int):
            return str(v)
        if isinstance(v, float):
            # only accept integer-like floats
            if int(v) == v:
                return str(int(v))
            raise TypeError("year must be integer-like")
        if isinstance(v, str):
            v2 = v.strip()
            return v2 or None
        raise TypeError("year must be str or int")

    @field_validator("season", mode="before")
    @classmethod
    def _normalize_season(cls, v: Any) -> Any:
        """Accept int/str and normalize season to int.

        Forward/上游可能传：
          - 1 / "1"
          - "S01" / "s02" / "Season 03"
          - "第1季"
        """
        if v is None or v == "":
            return None
        if isinstance(v, bool):
            raise TypeError("season must be int-like")
        if isinstance(v, int):
            return v
        if isinstance(v, float):
            if int(v) == v:
                return int(v)
            raise TypeError("season must be integer-like")
        if isinstance(v, str):
            s = v.strip()
            if not s:
                return None
            # extract the first integer block
            m = re.search(r"(\d{1,3})", s)
            if m:
                return int(m.group(1))
            # no digits -> treat as None
            return None
        # unknown types
        raise TypeError("season must be int-like")



class ForwardResponse(BaseModel):
    ok: bool = True
    message: str = ""
    code: str | None = None
    trace_id: str = Field(default="")

class ForwardDataResponse(ForwardResponse):
    data: Any | None = None
