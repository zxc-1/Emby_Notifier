from __future__ import annotations

"""Forward-Bridge: TMDB lookup helpers.

This module was referenced by subscriptions_core.py but missing in some packages.
It provides a minimal, stable surface:
- TMDB_BASE
- fetch_tmdb_by_id
- _tmdb_title

Implementation delegates to the shared TMDB integration in
:mod:`integrations.tmdb_match`.
"""
from core.logging import get_biz_logger
biz = get_biz_logger(__name__)


from typing import Any, Dict, Optional

from integrations.tmdb_match import fetch_tmdb_detail

TMDB_BASE = "https://www.themoviedb.org"


def _tmdb_title(meta: Optional[Dict[str, Any]]) -> str:
    if not isinstance(meta, dict):
        return ""
    return str(
        meta.get("title")
        or meta.get("name")
        or meta.get("original_title")
        or meta.get("original_name")
        or ""
    ).strip()


async def fetch_tmdb_by_id(tmdb_id: int, media_type: str) -> Optional[Dict[str, Any]]:
    try:
        tid = int(tmdb_id)
    except (ValueError, TypeError) as e:
        biz.detail(
            "ℹ️ [TMDB ID解析]失败：无法将输入值转换为有效的 TMDB ID。"
            "可能原因：输入值不是数字、包含非法字符、为空或 None。"
            "影响：无法通过 TMDB API 获取媒体详细信息，返回空结果",
            input=repr(tmdb_id),
            reason=type(e).__name__
        )
        return None
    if tid <= 0:
        return None

    mt = str(media_type or "").strip().lower() or None
    prefer = "tv" if mt in ("tv", "show", "series") else "movie"
    return await fetch_tmdb_detail(tid, prefer_media_type=prefer)
