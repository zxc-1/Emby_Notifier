from __future__ import annotations

import asyncio
from typing import Dict, Optional

import httpx

from core.http import get_http_client
from core.http import async_request_with_retry
from core.logging import get_biz_logger
from settings.timeouts import TimeoutCategory, get_timeout
from settings.retries import RetryCategory, get_retry_config

from notifier.errors import categorize_exc
from core.metrics import metrics

from .auth_state import get_mediahelp_state, mh_abs_url
from .config import log

biz = get_biz_logger(__name__)

# Get default retry config for MediaHelp API
_MH_RETRY = get_retry_config(RetryCategory.EXTERNAL_SERVICE)


def init_mediahelp_runtime(*, load_disk: bool = True, load_settings: bool = True) -> None:
    """Initialize MediaHelp runtime state (lazy, safe to call multiple times)."""
    try:
        st = get_mediahelp_state()
        st.init_runtime(load_disk=load_disk, load_settings=load_settings)
    except (OSError, IOError, ValueError) as e:
        biz.detail("MediaHelp 运行时初始化失败", error=f"{type(e).__name__}: {e}")


def set_mediahelp_token(token: str, *, persist: bool = True, source: str = "") -> bool:
    """Set MediaHelp Authorization token for current process.

    - persist: when True, save to disk (forward_mediahelp_state.json).
      .env persistence is handled by admin routes / persist_mediahelp_token_to_env().
    """
    try:
        st = get_mediahelp_state()
        st.init_runtime(load_disk=True, load_settings=True)
        if not token or not str(token).strip():
            return False
        st.set_token(str(token))
        if source:
            log(f"✅ MediaHelp token 已更新（source={source}）")
        else:
            log("✅ MediaHelp token 已更新")
        return True
    except (OSError, IOError, ValueError) as e:
        biz.detail("设置 MediaHelp token 失败", error=f"{type(e).__name__}: {e}")
        return False


def persist_mediahelp_token_to_env(token: Optional[str] = None, *, source: str = "") -> bool:
    """Persist MediaHelp token into /data/.env as MEDIAHELP_TOKEN and reload settings (best-effort)."""
    try:
        st = get_mediahelp_state()
        st.init_runtime(load_disk=True, load_settings=True)

        t = str(token or (st.token or "")).strip()
        if not t:
            return False
        # Store raw token without Bearer prefix to keep UI consistent.
        raw = t.split(" ", 1)[1] if t.lower().startswith("bearer ") and " " in t else t

        from core.storage import update_env_file
        from settings.runtime import reload_settings

        ok = update_env_file({"MEDIAHELP_TOKEN": str(raw)})
        if ok:
            reload_settings()
            if source:
                log(f"📝 MediaHelp token 已同步写入 .env（source={source}）")
            else:
                log("📝 MediaHelp token 已同步写入 .env")
        else:
            if source:
                log(f"⚠️ MediaHelp token 写入 .env 失败（source={source}）")
            else:
                log("⚠️ MediaHelp token 写入 .env 失败")
        return bool(ok)
    except (OSError, IOError, ValueError) as e:
        biz.detail("持久化 MediaHelp token 到 .env 失败", error=f"{type(e).__name__}: {e}")
        return False


def have_token() -> bool:
    init_mediahelp_runtime(load_disk=True, load_settings=True)
    try:
        return get_mediahelp_state().have_token(strict_ttl=True)
    except (AttributeError, ValueError) as e:
        biz.detail("检查 token 状态失败", error=type(e).__name__)
        return False


def mediahelp_headers(with_auth: bool = True) -> Dict[str, str]:
    init_mediahelp_runtime(load_disk=True, load_settings=True)

    headers = {
        "Accept": "application/json, text/plain, */*",
        "Content-Type": "application/json;charset=utf-8",
    }
    try:
        st = get_mediahelp_state()
        if with_auth and st.have_token(strict_ttl=True) and st.token:
            headers["Authorization"] = st.token
    except (AttributeError, ValueError) as e:
        biz.detail("构建 MediaHelp 请求头失败", error=type(e).__name__)
        pass
    return headers


async def login_mediahelp(username: str, password: str) -> bool:
    if not username or not password:
        return False

    url = mh_abs_url("/api/v1/auth/login")
    if not (url.startswith("http://") or url.startswith("https://")):
        log("❌ MEDIAHELP_BASE 未配置或无效，无法登录 MediaHelp")
        return False

    client = await get_http_client()
    resp: httpx.Response | None = None
    try:
        resp = await async_request_with_retry(
            client,
            "POST",
            url,
            json={"username": username, "password": password},
            timeout=get_timeout(TimeoutCategory.MH_API),
            max_attempts=_MH_RETRY.max_retries,
            backoff=_MH_RETRY.backoff,
            log_ctx="mediahelp:login",
        )
        if resp.status_code != 200:
            biz.warning("MediaHelp 登录失败", status=resp.status_code, body_snip=(resp.text or "")[:300])
            return False
        try:
            j = resp.json()
        except Exception:
            biz.warning("MediaHelp 登录返回无效 JSON", body_snip=(resp.text or "")[:300])
            return False
        token = ((j.get("data") or {}) if isinstance(j, dict) else {}).get("access_token")
        if not token:
            biz.warning("MediaHelp 登录响应中缺少 access_token", stage="mediahelp_login", reason="missing_access_token")
            return False

        await asyncio.to_thread(set_mediahelp_token, token, persist=True, source="mediahelp_login")
        return True
    finally:
        if resp is not None:
            try:
                await resp.aclose()
            except (OSError, IOError) as e:
                biz.detail("关闭 HTTP 响应失败", error=type(e).__name__)
                pass
