from __future__ import annotations

"""Forward-Bridge: subscription cache.

- Owns the in-memory SUB_CACHE and refresh logic (singleflight + TTL gating)
- Provides read-only helpers for other modules

This module centralizes cache ownership to avoid accidental rebinding and to make
refresh logic independently testable.
"""

import asyncio
from core.logging import get_biz_logger
from core.task_registry import create_task_logged
import time
from typing import Any, Dict, Optional

from settings.runtime import get_settings

from .config import get_sub_cache_min_interval_sec, get_sub_cache_ttl, log
from .http_client import have_token
from .mh_api import mh_list_subscriptions
from .seasons import _parse_selected_seasons
from .sub_models import SubCacheEntryModel

from core.loop_local import loop_local

biz = get_biz_logger(__name__)


# 订阅缓存：tmdb_id -> { uuid, name, cron, selected_seasons, raw }
SUB_CACHE: Dict[int, Dict[str, Any]] = {}
SUB_CACHE_TIME: float = 0.0
SUB_CACHE_LAST_REFRESH_ATTEMPT: float = 0.0


def get_subscriptions_snapshot() -> dict:
    """Return a read-only snapshot of the current subscription cache."""
    try:
        return dict(SUB_CACHE or {})
    except (ValueError, TypeError) as e:
        biz.detail(
            "ℹ️ [缓存快照获取]失败：无法创建订阅缓存的只读副本。"
            "可能原因：缓存数据结构异常、内存不足、并发访问冲突。"
            "影响：返回空字典，调用方无法获取当前订阅状态",
            reason=type(e).__name__
        )
        return {}


def get_sub_entry(tmdb_id: int) -> dict | None:
    """Read a single entry from the subscription cache (no mutation)."""
    try:
        return (SUB_CACHE or {}).get(int(tmdb_id))
    except (ValueError, TypeError) as e:
        biz.detail(
            "ℹ️ [缓存条目读取]失败：无法从订阅缓存中读取指定 TMDB ID 的条目。"
            "可能原因：TMDB ID 格式错误、缓存数据损坏、类型转换失败。"
            "影响：返回 None，调用方无法判断该媒体是否已订阅",
            tmdb_id=repr(tmdb_id),
            reason=type(e).__name__
        )
        return None


def _get_sub_cache_lock() -> asyncio.Lock:
    # Loop-local: asyncio.Lock is bound to the loop it was created in.
    return loop_local("forward_bridge:sub_cache_lock", asyncio.Lock)


def _get_sub_cache_inflight_box() -> Dict[str, Optional[asyncio.Task]]:
    # Loop-local: Task is also loop-bound.
    return loop_local("forward_bridge:sub_cache_inflight", lambda: {"task": None})


async def refresh_sub_cache(force: bool = False) -> None:
    """Refresh SUB_CACHE with singleflight semantics."""
    box = _get_sub_cache_inflight_box()
    t = box.get("task")
    if t and (not t.done()):
        try:
            await t
        except Exception:
            # Previous inflight refresh failed; do not propagate to all callers.
            # If force is requested, proceed with a new refresh attempt.
            biz.detail(
                "ℹ️ [订阅缓存刷新]等待上一轮刷新任务失败：上一轮刷新任务抛出异常。"
                "可能原因：网络连接失败、MediaHelp API 异常、或缓存解析错误。"
                "影响：本次刷新将继续尝试（force=True 时），否则返回并保留旧缓存",
                exc_info=True,
            )
            if not force:
                return
        if not force:
            return

    task = create_task_logged(_refresh_sub_cache_impl(force=force), name="sub_cache_refresh", log=biz)
    box["task"] = task
    try:
        await task
    finally:
        if box.get("task") is task:
            box["task"] = None


async def _refresh_sub_cache_impl(force: bool = False) -> None:
    """Actual refresh implementation under the cache lock."""
    global SUB_CACHE_TIME, SUB_CACHE_LAST_REFRESH_ATTEMPT

    biz.detail("开始刷新订阅缓存")

    if not have_token():
        log("⚠️ 当前没有 MEDIAHELP_TOKEN，跳过刷新 SUB_CACHE")
        return

    now = time.time()

    if not force:
        try:
            min_int = float(get_sub_cache_min_interval_sec())
        except (ValueError, TypeError) as e:
            biz.detail(
                "ℹ️ [刷新间隔解析]失败：无法解析缓存最小刷新间隔配置值。"
                "可能原因：配置值不是数字、格式错误、环境变量未设置。"
                "影响：使用默认值 2.0 秒作为最小刷新间隔",
                reason=type(e).__name__
            )
            min_int = 2.0
        if min_int > 0 and (now - float(SUB_CACHE_LAST_REFRESH_ATTEMPT)) < min_int:
            return
        if SUB_CACHE and (now - SUB_CACHE_TIME) < get_sub_cache_ttl():
            return

    async with _get_sub_cache_lock():
        now = time.time()

        if not force:
            try:
                min_int = float(get_sub_cache_min_interval_sec())
            except (ValueError, TypeError) as e:
                biz.detail(
                    "ℹ️ [刷新间隔解析]失败：在锁内重新解析缓存最小刷新间隔配置值时发生异常。"
                    "可能原因：配置值不是数字、格式错误、环境变量未设置。"
                    "影响：使用默认值 2.0 秒作为最小刷新间隔",
                    reason=type(e).__name__
                )
                min_int = 2.0
            if min_int > 0 and (now - float(SUB_CACHE_LAST_REFRESH_ATTEMPT)) < min_int:
                return

        SUB_CACHE_LAST_REFRESH_ATTEMPT = now
        if not force and SUB_CACHE and (now - SUB_CACHE_TIME) < get_sub_cache_ttl():
            return

        items = await mh_list_subscriptions()
        new_cache: Dict[int, Dict[str, Any]] = {}

        def _extract_sub_name(item: Dict[str, Any], params: Dict[str, Any], sub_info: Dict[str, Any]) -> str:
            for v in (
                sub_info.get("name"),
                sub_info.get("title"),
                params.get("name"),
                params.get("title"),
                item.get("name"),
                item.get("title"),
            ):
                if isinstance(v, str) and v.strip():
                    return v.strip()

            for k in ("meta", "media", "tmdb", "tmdb_meta", "detail", "data"):
                meta = item.get(k)
                if not isinstance(meta, dict):
                    continue
                for kk in (
                    "title",
                    "name",
                    "original_title",
                    "original_name",
                    "display_title",
                    "display_name",
                ):
                    vv = meta.get(kk)
                    if isinstance(vv, str) and vv.strip():
                        return vv.strip()

            return ""

        def _extract_media_type(item: Dict[str, Any], params: Dict[str, Any], sub_info: Dict[str, Any]) -> str:
            for v in (
                sub_info.get("media_type"),
                sub_info.get("type"),
                params.get("media_type"),
                params.get("type"),
                item.get("media_type"),
                item.get("type"),
            ):
                if isinstance(v, str) and v.strip():
                    return v.strip().lower()
            return ""

        def _extract_year(item: Dict[str, Any], params: Dict[str, Any], sub_info: Dict[str, Any]) -> str:
            for v in (
                sub_info.get("year"),
                params.get("year"),
                item.get("year"),
            ):
                if v is None:
                    continue
                try:
                    s = str(v).strip()
                except (ValueError, TypeError) as e:
                    biz.detail(
                        "ℹ️ [年份解析]失败：无法将订阅数据中的年份字段转换为字符串。"
                        "可能原因：年份值类型异常、包含非法字符、转换方法不支持。"
                        "影响：该订阅条目的年份信息将为空，可能影响媒体匹配准确性",
                        value=repr(v),
                        reason=type(e).__name__
                    )
                    s = ""
                if s:
                    return s
            return ""

        for item in items:
            params = item.get("params") or {}
            sub_info = item.get("subscription_info") or {}

            raw_tmdb = (
                params.get("tmdb_id")
                or sub_info.get("tmdb_id")
                or item.get("tmdb_id")
            )
            if raw_tmdb is None:
                continue

            try:
                tmdb_id = int(raw_tmdb)
            except (ValueError, TypeError) as e:
                biz.detail(
                    "ℹ️ [TMDB ID解析]失败：订阅数据中的 TMDB ID 无法转换为整数，跳过该条目。"
                    "可能原因：TMDB ID 字段为空、包含非数字字符、类型不匹配。"
                    "影响：该订阅条目将被忽略，不会加入缓存，可能导致重复订阅",
                    值=repr(raw_tmdb)
                )
                continue

            raw_selected = params.get("selected_seasons")
            is_all, seasons_int = _parse_selected_seasons(raw_selected)
            norm_selected = [] if is_all else seasons_int

            existed = new_cache.get(tmdb_id)
            if existed:
                is_all_old, seasons_old = _parse_selected_seasons(existed.get("selected_seasons"))
                if is_all_old or is_all:
                    existed["selected_seasons"] = []
                else:
                    existed["selected_seasons"] = sorted(set(seasons_old).union(seasons_int))
            else:
                entry = {
                    "uuid": sub_info.get("uuid") or item.get("uuid"),
                    "name": _extract_sub_name(item, params, sub_info),
                    "cron": params.get("cron") or sub_info.get("cron"),
                    "selected_seasons": list(norm_selected or []),
                    "media_type": _extract_media_type(item, params, sub_info),
                    "year": _extract_year(item, params, sub_info),
                    "raw": item if isinstance(item, dict) else {},
                }
                try:
                    new_cache[tmdb_id] = SubCacheEntryModel(**entry).model_dump()
                except Exception:
                    biz.detail(
                        "ℹ️ [缓存条目验证]失败：订阅条目数据结构不符合模型定义，使用原始数据。"
                        "可能原因：必需字段缺失、字段类型不匹配、数据格式变化。"
                        "影响：该条目将以原始格式存储，可能导致后续访问时字段缺失",
                        exc_info=True
                    )
                    new_cache[tmdb_id] = entry

        # Guard: keep old cache on transient empties
        if not new_cache and SUB_CACHE and not force:
            log("⚠️ SUB_CACHE 刷新结果为空，保留旧缓存（可能是临时异常或返回结构变化）")
            return

        SUB_CACHE.clear()
        SUB_CACHE.update(new_cache)
        SUB_CACHE_TIME = now
        log(f"✅ SUB_CACHE 刷新完成，共 {len(SUB_CACHE)} 条记录")


def is_season_subscribed_from_cache(tmdb_id: int, season: Optional[int]) -> bool:
    entry = SUB_CACHE.get(int(tmdb_id))
    if not entry:
        return False

    if not get_settings().ENABLE_SEASON_FILTER:
        return True

    is_all, seasons_int = _parse_selected_seasons(entry.get("selected_seasons"))
    if is_all:
        return True

    if season is None:
        return True

    return int(season) in set(int(x) for x in seasons_int)


__all__ = [
    "SUB_CACHE",
    "SUB_CACHE_TIME",
    "SUB_CACHE_LAST_REFRESH_ATTEMPT",
    "get_subscriptions_snapshot",
    "get_sub_entry",
    "refresh_sub_cache",
    "is_season_subscribed_from_cache",
]


def get_cached_count() -> int:
    """Return number of cached subscriptions in memory."""
    try:
        return int(len(SUB_CACHE or {}))
    except Exception as e:
        biz.detail("ignored exception in get_cached_count", exc_info=True)
        return 0
