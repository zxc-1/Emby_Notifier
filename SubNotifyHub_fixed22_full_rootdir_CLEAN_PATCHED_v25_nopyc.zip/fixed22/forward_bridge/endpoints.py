from __future__ import annotations

from core.logging import get_biz_logger
import time
from typing import Any, Dict, Optional

import httpx

from core.http import async_request_with_retry_json

from notifier.errors import categorize_exc
from core.metrics import metrics

from .auth import login_mediahelp, mediahelp_headers
from .auth_state import get_mediahelp_state, mh_abs_url
from .client import get_client, mh_request
from .config import log
from .http_utils import safe_json, short_text
from .notifications import notify_mediahelp

biz = get_biz_logger(__name__)

async def mh_request_json(
    method: str,
    url: str,
    *,
    ctx: str = "",
    default: Any = None,
    with_auth: bool = True,
    retry_on_401: bool = True,
    timeout: float = 15.0,
    text_snip_len: int = 600,
    **kwargs: Any,
) -> tuple[int, Any, Optional[str], str]:
    """Leak-proof MediaHelp JSON request with unified retry/timeout/metrics.

    Returns: (status_code, data, err, text_snip)

    - Uses core.http_retry.async_request_with_retry_json() for retries.
    - Always closes the response (handled by the retry wrapper).
    - Optional single 401 re-login retry when with_auth=True.
    """
    headers = kwargs.pop("headers", {}) or {}
    base_headers = mediahelp_headers(with_auth=with_auth)
    base_headers.update(headers)

    client = await get_client()

    # Resolve retry/timeout from settings (defaults are safe).
    try:
        from settings.runtime import get_settings
        s = get_settings()
        max_attempts = int(getattr(s, "MEDIAHELP_HTTP_MAX_ATTEMPTS", 3) or 3)
        timeout = float(getattr(s, "MEDIAHELP_HTTP_TIMEOUT_SEC", timeout) or timeout)
        bo_first = float(getattr(s, "MEDIAHELP_HTTP_BACKOFF_FIRST_SEC", 0.0) or 0.0)
        bo_base = float(getattr(s, "MEDIAHELP_HTTP_BACKOFF_BASE_SEC", 1.0) or 1.0)
    except (ValueError, TypeError, AttributeError) as e:
        biz.detail("MediaHelp HTTP 配置解析失败（使用默认值）", reason=type(e).__name__)
        max_attempts = 3
        bo_first = 0.0
        bo_base = 1.0

    url = mh_abs_url(url)
    if not (url.startswith("http://") or url.startswith("https://")):
        raise httpx.InvalidURL(f"MediaHelp base URL not configured or invalid: {url!r}")

    # Map common request kwargs for retry helper.
    params = kwargs.pop("params", None)
    json_body = kwargs.pop("json", None)
    data = kwargs.pop("data", None)
    files = kwargs.pop("files", None)

    async def _do_request(hdrs: Dict[str, str]) -> tuple[int, Any, str, int]:
        t0 = time.perf_counter()
        status, data_obj, text_snip = await async_request_with_retry_json(
            client,
            method,
            url,
            params=params,
            json=json_body,
            data=data,
            files=files,
            headers=hdrs,
            timeout=timeout,
            max_attempts=max_attempts,
            backoff=(bo_first, bo_base),
            log_ctx=f"mediahelp:{ctx or url}",
            text_snip_len=text_snip_len,
        )
        dur_ms = int((time.perf_counter() - t0) * 1000)
        # metrics
        try:
            metrics.observe("external_request_ms", dur_ms, labels={"service": "mediahelp"})
            if 200 <= int(status) < 400:
                metrics.inc("external_success_total", labels={"service": "mediahelp"})
            else:
                metrics.inc("external_error_total", labels={"service": "mediahelp", "status": str(int(status))})
        except (ValueError, TypeError, AttributeError) as e:
            biz.detail("指标记录失败（已忽略）", status=status, reason=type(e).__name__)
        return int(status), data_obj, text_snip, dur_ms

    status, data_obj, text_snip, _ = await _do_request(base_headers)

    if (
        status == 401
        and retry_on_401
        and with_auth
        and (get_mediahelp_state().login_username)
        and (get_mediahelp_state().login_password)
    ):
        log("⚠️ MediaHelp 返回 401，尝试自动重新登录并重试一次")
        try:
            await notify_mediahelp(
                "mediahelp_not_authenticated",
                {"detail": "HTTP 401 / Not authenticated", "login_via": "forward"},
            )
        except (ValueError, TypeError, httpx.HTTPError) as e:
            biz.detail("MediaHelp 通知发送失败（已忽略）", event="not_authenticated", reason=type(e).__name__)
        st = get_mediahelp_state()
        ok = await login_mediahelp(st.login_username, st.login_password)  # type: ignore[arg-type]
        if ok:
            try:
                await notify_mediahelp(
                    "mediahelp_login_success",
                    {"username": st.login_username or "", "login_via": "forward"},
                )
            except (ValueError, TypeError, httpx.HTTPError) as e:
                biz.detail("MediaHelp 通知发送失败（已忽略）", event="login_success", reason=type(e).__name__)
            base_headers = mediahelp_headers(with_auth=True)
            base_headers.update(headers)
            status, data_obj, text_snip, _ = await _do_request(base_headers)
        else:
            log("❌ 重新登录 MediaHelp 失败，放弃重试")
            try:
                await notify_mediahelp(
                    "mediahelp_login_failed",
                    {
                        "username": (get_mediahelp_state().login_username or ""),
                        "status_code": 401,
                        "reason": "HTTP 401 / Not authenticated",
                        "login_via": "forward",
                    },
                )
            except (ValueError, TypeError, httpx.HTTPError) as e:
                biz.detail("MediaHelp 通知发送失败（已忽略）", event="login_failed", reason=type(e).__name__)

    # Normalize return fields
    if data_obj is None:
        data_obj = default
    err: Optional[str] = None
    if status >= 400:
        err = f"HTTP {status}"
    return status, data_obj, err, str(text_snip or "")

async def mh_request_text(
    method: str,
    url: str,
    *,
    with_auth: bool = True,
    retry_on_401: bool = True,
    timeout: float = 15.0,
    text_snip_len: int = 600,
    **kwargs: Any,
) -> tuple[int, str, str]:
    """Leak-proof MediaHelp text request.

    Returns: (status_code, text, text_snip)
    """
    resp: httpx.Response | None = None
    try:
        # Defensive: allow callers to pass these via **kwargs without causing duplicate-kw TypeError.
        kwargs.pop('with_auth', None)
        kwargs.pop('retry_on_401', None)
        kwargs.pop('timeout', None)
        resp = await mh_request(
            method,
            url,
            with_auth=with_auth,
            retry_on_401=retry_on_401,
            timeout=timeout,
            **kwargs,
        )
        txt = ""
        try:
            txt = resp.text or ""
        except (ValueError, TypeError, AttributeError, UnicodeDecodeError) as e:
            biz.detail("响应文本读取失败（返回空字符串）", reason=type(e).__name__)
            txt = ""
        snip = short_text(txt, limit=int(text_snip_len or 0) or 600) if text_snip_len else ""
        return int(getattr(resp, "status_code", 0) or 0), txt, snip
    finally:
        if resp is not None:
            try:
                await resp.aclose()
            except (httpx.HTTPError, RuntimeError) as e:
                biz.detail("响应关闭失败（已忽略）", reason=type(e).__name__)


async def mh_execute_subscription(uuid: str) -> tuple[bool, str]:
    """触发 MediaHelp 的订阅执行。"""
    url = mh_abs_url(f"/api/v1/subscription/{uuid}/execute")
    resp: httpx.Response | None = None
    try:
        resp = await mh_request("POST", url, timeout=30)
        if resp is None:
            return False, "mh_request_returned_none"

        text_snip = ""
        try:
            text_snip = (resp.text or "")[:600]
        except (ValueError, TypeError, AttributeError, UnicodeDecodeError) as e:
            biz.detail("响应文本片段读取失败（返回空字符串）", reason=type(e).__name__)
            text_snip = ""

        if resp.status_code != 200:
            return False, text_snip

        data, err = safe_json(resp, ctx="subscription/execute", default={})
        if err:
            return False, text_snip

        code = data.get("code")
        message = str(data.get("message") or "")
        if code in (0, 200, None):
            return True, message or "ok"
        return False, message or text_snip
    finally:
        if resp is not None:
            try:
                await resp.aclose()
            except (httpx.HTTPError, RuntimeError) as e:
                biz.detail("响应关闭失败（已忽略）", reason=type(e).__name__)
