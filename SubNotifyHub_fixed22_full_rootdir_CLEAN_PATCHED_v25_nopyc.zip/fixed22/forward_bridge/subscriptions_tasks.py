from __future__ import annotations

"""Forward-Bridge: subscription task orchestration.

P0-1 refactor: split heavy task creation/update/unsubscribe logic here.
"""
from core.logging import get_biz_logger
biz = get_biz_logger(__name__)


import json
import asyncio
from typing import Any, Dict, List, Optional

from .http_utils import resp_brief, safe_json
from .models import ForwardSubscribePayload
from settings.urls import get_tmdb_image_url
from .subscriptions_core import (
    SUB_CACHE,
    _parse_selected_seasons,
    _tmdb_title,
    _url_create_sub,
    categorize_exc,
    fetch_tmdb_by_id,
    get_settings,
    guess_media_type,
    log,
    metrics,
    mh_delete_subscription,
    mh_execute_subscription,
    mh_get_defaults,
    mh_request_json,
    mh_search_media_by_name,
    mh_update_subscription_seasons,
    notify_mediahelp,
    refresh_sub_cache,
)

from .notify_ctx import set_notify_ctx

from core.task_registry import create_task_logged


async def create_mediahelp_sub_task(
    p: ForwardSubscribePayload,
) -> tuple[bool, str]:
    """Business-log wrapped entry.

    Keeps the original behavior while making logs step-based and grouped.
    """
    with biz.entry(
        domain="ForwardBridge",
        action="订阅任务",
        group_title="MediaHelp 订阅任务",
        title_name=getattr(p, "name", None),
        tmdb_id=getattr(p, "tmdbid", None),
        year=getattr(p, "year", None),
        season=getattr(p, "season", None),
    ):
        biz.step("开始", i=1, total=5)
        return await _create_mediahelp_sub_task_impl(p)


async def _create_mediahelp_sub_task_impl(
    p: ForwardSubscribePayload,
) -> tuple[bool, str]:
    """
    确保 MediaHelp 中存在对应的订阅任务：
      - 如果不存在 -> 创建新任务（POST /subscription/create）
      - 如果已存在 -> 根据季信息更新 selected_seasons（PUT /subscription/{uuid}）
    """
    biz.detail(
        "开始创建 MediaHelp 订阅任务",
        stage="mediahelp_sub_create",
        name=getattr(p, "name", None),
        tmdbid=getattr(p, "tmdbid", None),
        year=getattr(p, "year", None),
        season=getattr(p, "season", None),
    )
    # Notification context (source / year). Used by TG templates.
    ctx_notify = {
        "year": getattr(p, "year", None),
        "source_tag": getattr(p, "source_tag", None),
        "source_label": getattr(p, "source_label", None),
        "source_value": getattr(p, "source_value", None),
    }
    media_type = guess_media_type(p)
    ctx_notify["media_type"] = media_type

    # Propagate notify context down to request-level system events (401 auto re-login).
    # NOTE: ContextVar is per-task; create_mediahelp_sub_task is typically awaited as a
    # dedicated op and won't leak across unrelated flows.
    set_notify_ctx({k: v for k, v in ctx_notify.items() if v is not None and str(v).strip()})

    biz.step("解析 TMDB ID", i=2, total=5)
    # 解析 tmdb_id
    try:
        tmdb_id = int(p.tmdbid)
    except (ValueError, TypeError) as e:
        msg = f"invalid tmdbid: {p.tmdbid}"
        biz.warning("⚠️ TMDB ID 解析失败", 输入=repr(p.tmdbid))
        log(f"❌ {msg}")
        metrics.inc("forwardbridge_sub_create_failed")
        await notify_mediahelp(
            "mediahelp_sub_create_failed",
            {
                **ctx_notify,
                "tmdb_id": None,
                "title": p.name or "",
                "season": p.season,
                "detail": msg,
            },
        )
        return False, msg

    biz.ok("TMDB ID 解析成功", tmdb_id=tmdb_id, media_type=media_type)

    biz.step("检查订阅缓存", i=3, total=5)
    # 先看看缓存里有没有订阅任务（尽量不阻塞“秒弹”体验）
    # 说明：
    #   - 以前这里会 await refresh_sub_cache()，如果前面有 status 查询触发了刷新锁，订阅会被卡住几秒。
    #   - 这里改成：先用现有缓存做判断；缓存缺失时仅做“短等待 + 后台刷新”，绝不长时间阻塞订阅创建。
    entry = SUB_CACHE.get(tmdb_id)

    if entry is None:
        # 最多等 0.25s 让缓存刷新一下（如果正在刷新，会自动在后台继续，不会阻塞）
        try:
            await asyncio.wait_for(asyncio.shield(refresh_sub_cache()), timeout=0.25)
        except asyncio.TimeoutError:
            pass
        except Exception:
            biz.detail(
                "ℹ️ [订阅缓存刷新]异常已抑制：后台刷新订阅缓存时发生异常。"
                "可能原因：网络超时、MediaHelp 服务暂时不可用、缓存锁竞争。"
                "影响：本次订阅创建将使用旧缓存数据，可能导致重复订阅判断不准确",
                exc_info=True
            )

        entry = SUB_CACHE.get(tmdb_id)

        # 仍然没有就后台再刷新一次（不 await）
        if entry is None:
            try:
                create_task_logged(refresh_sub_cache(), name="refresh_sub_cache", log=biz)
            except (RuntimeError, ValueError) as e:
                biz.detail(
                    "ℹ️ [后台任务创建]失败：无法创建后台刷新订阅缓存的异步任务。"
                    "可能原因：事件循环未运行、任务队列已满、运行时环境限制。"
                    "影响：订阅缓存不会自动更新，下次订阅操作可能使用过期数据",
                    reason=type(e).__name__
                )
                pass

    title_for_notify = p.name or ""

    # ------------------ 已经有订阅任务的情况 ------------------ #
    if entry:
        biz.step("命中已有订阅：判断/更新季", i=4, total=5)
        log(f"ℹ️ 检测到已有订阅任务: tmdb_id={tmdb_id}")

        # 不按季 / 不是剧集 / 没有季信息 -> 直接认为已订阅
        if (not get_settings().ENABLE_SEASON_FILTER) or media_type != "tv" or p.season is None:
            log("ℹ️ 不按季逻辑/电影/无季信息，已有任务即视为已订阅")
            await notify_mediahelp(
                "mediahelp_sub_already",
                {**ctx_notify, "tmdb_id": tmdb_id,
                    "title": entry.get("name") or title_for_notify,
                    "reason": "not_season_mode_or_not_tv",
                },
            )
            metrics.inc("forwardbridge_sub_create")
            return True, "already subscribed"

        is_all, seasons_int = _parse_selected_seasons(entry.get("selected_seasons"))

        # 全季订阅（selected_seasons 为空/缺失/标记 all）-> 任何季都算已订阅，不更新 seasons
        if is_all:
            log("ℹ️ 已为全季订阅(selected_seasons 为空/全季)，无需更新")
            await notify_mediahelp(
                "mediahelp_sub_already",
                {**ctx_notify, 
                    "tmdb_id": tmdb_id,
                    "title": entry.get("name") or title_for_notify,
                    "reason": "all_seasons",
                },
            )
            metrics.inc("forwardbridge_sub_create")
            return True, "already subscribed (all seasons)"

        # 若 seasons_int 为空（解析失败），保守当作全季，避免意外把订阅收窄
        if not seasons_int:
            log("ℹ️ selected_seasons 解析为空，按全季处理，避免收窄订阅")
            await notify_mediahelp(
                "mediahelp_sub_already",
                {**ctx_notify, 
                    "tmdb_id": tmdb_id,
                    "title": entry.get("name") or title_for_notify,
                    "reason": "all_seasons_parse_empty",
                },
            )
            metrics.inc("forwardbridge_sub_create")
            return True, "already subscribed (all seasons)"

        season_int = int(p.season)

        if season_int in set(seasons_int):
            log(f"ℹ️ 当前季已在 selected_seasons 中: {seasons_int}，无需更新")
            await notify_mediahelp(
                "mediahelp_sub_already",
                {**ctx_notify, 
                    "tmdb_id": tmdb_id,
                    "title": entry.get("name") or title_for_notify,
                    "season": season_int,
                    "reason": "season_already_in_list",
                },
            )
            metrics.inc("forwardbridge_sub_create")
            return True, "already subscribed this season"

        new_seasons = sorted(set(seasons_int + [season_int]))
        log(f"ℹ️ 需要追加季 {season_int}，更新后的 seasons={new_seasons}")
        ok, detail = await mh_update_subscription_seasons(tmdb_id, new_seasons, ctx_notify=ctx_notify)
        if ok:
            metrics.inc("forwardbridge_sub_create")
            # 更新季成功后，自动触发 MediaHelp “立即执行”
            raw = entry.get("raw") or {}
            sub_uuid = entry.get("uuid") or raw.get("uuid")
            run_title = entry.get("name") or title_for_notify
            if sub_uuid:
                log(f"ℹ️ 更新季成功，触发订阅立即执行: uuid={sub_uuid}, title={run_title}")
                await mh_execute_subscription(str(sub_uuid))
            else:
                log("⚠️ 更新季成功，但未找到订阅 uuid，无法立即执行")
        else:
            metrics.inc("forwardbridge_sub_create_failed")
        return ok, detail

        # ------------------ 没有订阅任务 -> 创建新任务 ------------------ #

    biz.step("创建新订阅任务", i=4, total=5)
    log(f"ℹ️ 未找到订阅任务，准备创建新任务: tmdb_id={tmdb_id}")

    defaults = await mh_get_defaults()
    cloud_type = defaults.get("cloud_type")
    account_identifier = defaults.get("account_identifier")
    target_directory = defaults.get("save_dir") or defaults.get("target_directory")

    # Some MediaHelp deployments reject null for these fields. Use empty strings
    # so the server can apply its own defaults.
    cloud_type = str(cloud_type or "")
    account_identifier = str(account_identifier or "")
    target_directory = str(target_directory or "")
    cron = defaults.get("cron") or "0 */6 * * *"

    # Debug (safe): print which defaults are being used without leaking full identifiers
    try:
        acct = str(account_identifier) if account_identifier is not None else ""
        acct_mask = (acct[:3] + "***" + acct[-3:]) if len(acct) >= 8 else (acct or "<empty>")
        log(f"ℹ️ defaults: cloud_type={cloud_type or '<empty>'}, account={acct_mask}, target_directory={target_directory or '<empty>'}")
    except (ValueError, TypeError, IndexError) as e:
        biz.detail(
            "ℹ️ [配置日志]打印失败：无法格式化默认配置信息用于日志输出。"
            "可能原因：账号标识符格式异常、字符串长度不足、类型转换失败。"
            "影响：仅影响调试日志输出，不影响订阅创建功能",
            reason=type(e).__name__
        )
        pass

    # 质量策略：
    #  - 先看 defaults 里有没有显式配置
    #  - 如果没有，或者是 1080p，就当作“没特别配置”，统一用 auto（自动最优）
    raw_quality = None
    if isinstance(defaults, dict):
        raw_quality = defaults.get("quality") or defaults.get("quality_preference")

    if isinstance(raw_quality, str):
        raw_quality = raw_quality.strip().lower()
    else:
        raw_quality = ""

    if not raw_quality or raw_quality == "1080p":
        quality_pref = "auto"
    else:
        quality_pref = raw_quality

    log(f"ℹ️ 使用质量偏好: {quality_pref}")

    # ---------- 影片/剧集元信息 ----------
    # Forward 传来的名字，去掉首尾空格
    name = (p.name or "").strip()

    meta: Optional[dict] = None

    # 1) 有名字时，先用名字在 MediaHelp 搜
    if name:
        meta = await mh_search_media_by_name(name, media_type, prefer_tmdb_id=tmdb_id, prefer_year=p.year)
    elif tmdb_id:
        # Some MediaHelp deployments allow searching by TMDB numeric id directly.
        # This lets MH enrich metadata even when Forward doesn't pass a name.
        try:
            meta = await mh_search_media_by_name(str(tmdb_id), media_type, prefer_tmdb_id=tmdb_id, prefer_year=p.year)
        except (ValueError, TypeError, KeyError) as e:
            biz.detail(
                "ℹ️ [TMDB搜索]失败：使用 TMDB ID 在 MediaHelp 搜索媒体信息时发生异常。"
                "可能原因：TMDB ID 格式错误、MediaHelp API 返回结构变化、网络请求失败。"
                "影响：将尝试使用其他方式获取媒体元信息，可能导致标题或海报缺失",
                tmdb_id=tmdb_id,
                reason=type(e).__name__
            )
            meta = None

    # 1.5) 防跑偏护栏：若 MH 搜索命中与期望 tmdb_id 不一致，丢弃该 meta，避免错误标题/海报带入创建请求。
    try:
        if tmdb_id and isinstance(meta, dict):
            hit_id = meta.get("id") or meta.get("tmdb_id") or meta.get("tmdbid")
            try:
                hit_id_int = int(hit_id) if hit_id is not None and hit_id != "" else None
            except (ValueError, TypeError) as e:
                biz.detail(
                    "ℹ️ [ID解析]失败：无法解析 MediaHelp 搜索结果中的 TMDB ID。"
                    "可能原因：返回的 ID 格式不是数字、字段值为空、类型不匹配。"
                    "影响：无法验证搜索结果是否匹配预期媒体，可能使用错误的元信息",
                    hit_id=repr(hit_id),
                    reason=type(e).__name__
                )
                hit_id_int = None
            if hit_id_int is not None and hit_id_int != int(tmdb_id):
                log(f"⚠️ MH 搜索命中与期望 tmdb_id 不一致，已丢弃: hit={hit_id_int} expect={tmdb_id}")
                meta = None
    except (ValueError, TypeError, KeyError, AttributeError) as e:
        biz.detail(
            "ℹ️ [一致性检查]失败：验证 MediaHelp 搜索结果与预期 TMDB ID 是否一致时发生异常。"
            "可能原因：搜索结果数据结构异常、必需字段缺失、类型转换错误。"
            "影响：可能使用不匹配的媒体信息创建订阅，导致标题或海报错误",
            reason=type(e).__name__
        )
        pass

    # 2) 如果没搜到（或 MH 返回的 meta 不含标题），并且有 tmdb_id，用 TMDB id 补一次信息。
    #    另外：有些客户端会把 movie/tv type 传错，导致 TMDB 走错端点(404)，
    #    进而出现「TMDB id 对，但标题变未知标题」的现象。
    if tmdb_id:
        # ✅ v65 fix:
        #   - v64 在 name 为空时会先用 tmdb_id 去 MH search，这经常拿到“有标题但 poster_path 为空”的结果，
        #     导致订阅卡片没有海报。这里：只要标题缺失 *或* poster 缺失，都用 TMDB 同类型端点补全一次。
        need_enrich = False
        if meta is None or not _tmdb_title(meta):
            need_enrich = True
        elif isinstance(meta, dict) and not meta.get("poster_path"):
            need_enrich = True

        if need_enrich:
            meta_same = await fetch_tmdb_by_id(tmdb_id, media_type)
            # TMDB 同类型端点优先：只要能取到标题，就用它覆盖（同时补齐 poster 等字段）
            if meta_same is not None and _tmdb_title(meta_same):
                meta = meta_same
            elif meta is None:
                meta = meta_same

        # 兜底：type 可能被传错，或同类型端点仍取不到标题 -> 仅在标题缺失时尝试另一个端点
        if meta is None or not _tmdb_title(meta):
            other_type = "movie" if media_type == "tv" else "tv"
            meta2 = await fetch_tmdb_by_id(tmdb_id, other_type)
            if meta2 is not None and _tmdb_title(meta2):
                log(f"⚠️ TMDB type 可能不匹配/标题为空: {media_type} -> {other_type} (id={tmdb_id})")
                meta = meta2
                media_type = other_type

    if meta:
        # 电影：title/original_title/release_date
        # 剧集：name/original_name/first_air_date
        title = _tmdb_title(meta) or (name or "未知标题")
        original_title = (
            (meta.get("original_title") if isinstance(meta, dict) else None)
            or (meta.get("original_name") if isinstance(meta, dict) else None)
            or title
        )
        release_date = (
            meta.get("release_date")
            or meta.get("first_air_date")
            or ""
        )
        overview = meta.get("overview") or ""
        poster_path = meta.get("poster_path") or ""
        # ✅ 关键：如果是 TMDB 相对路径，就补成完整 URL，跟手动订阅一致
        if poster_path and not poster_path.startswith("http"):
            poster_path = get_tmdb_image_url(poster_path)

        # ✅ v65 fix: 如果 MH 搜索命中但没给 poster，再兜底用 TMDB 补一次海报（避免灰色占位）
        if tmdb_id and not poster_path:
            try:
                meta_p = await fetch_tmdb_by_id(tmdb_id, media_type)
                if isinstance(meta_p, dict) and meta_p.get("poster_path"):
                    poster_path = meta_p.get("poster_path") or ""
                    if poster_path and not poster_path.startswith("http"):
                        poster_path = get_tmdb_image_url(poster_path)
            except (ValueError, TypeError, KeyError) as e:
                # 不影响订阅创建
                biz.detail(
                    "ℹ️ [海报补充]失败：从 TMDB 获取海报路径时发生异常。"
                    "可能原因：TMDB API 请求失败、返回数据格式异常、网络超时。"
                    "影响：订阅卡片可能显示灰色占位图，不影响订阅功能本身",
                    tmdb_id=tmdb_id,
                    reason=type(e).__name__
                )
                pass

        vote_average = meta.get("vote_average") or 0
        search_keywords = name or title
    else:
        # MediaHelp 和 TMDB 都没给出元信息，只好用占位名称
        log("⚠️ 未找到任何元信息，使用占位名称")
        title = name or (f"TMDB:{tmdb_id}" if tmdb_id else "未知标题")
        original_title = title
        release_date = ""
        overview = ""
        poster_path = ""
        vote_average = 0
        search_keywords = name or title

    # ---------- 处理季信息 ----------
    selected_seasons: List[int] = []
    if get_settings().ENABLE_SEASON_FILTER and p.season is not None and media_type == "tv":
        selected_seasons = [int(p.season)]
        log(f"📺 当前启用按季订阅, selected_seasons = {selected_seasons}")
    else:
        log("📺 当前为全季订阅模式，selected_seasons = []")

    # 4. 按“老版本 MediaHelp”需要的扁平字段构造 body
    body = {
        "tmdb_id": tmdb_id,
        "title": title,
        "original_title": original_title,
        "media_type": media_type,
        "release_date": release_date,
        "overview": overview,
        "poster_path": poster_path,
        "vote_average": vote_average,
        "search_keywords": search_keywords,
        "quality_preference": quality_pref,
        "target_directory": target_directory,
        "target_dir_id": "",
        "target_path": "",
        "cron": cron,
        "cloud_type": cloud_type,
        "account_identifier": account_identifier,
        "custom_name": name or title,
        "selected_seasons": selected_seasons,
        "user_custom_links": [],
    }

    # ✅ v65.4 fix:
    # 与 v40 行为一致：显式传入 defaults 解析出的 target_directory/cloud_type/account_identifier。
    # 说明：部分云盘（如天翼云）订阅任务执行时必须绑定账号；同时 tv 的 TMDB 目录匹配
    # 也依赖创建任务时的 target_directory。若省略这些字段，MediaHelp 可能不会自动兜底，
    # 从而出现“必须指定 tianyiyun 账号”或“未找到与 tv 类型匹配的 TMDB 目录配置”。

    log("➡️ 调用 MediaHelp /subscription/create")
    # 不再输出完整 URL 和 BODY，避免泄露隐私信息
    # log("   URL = " + _url_create_sub())
    # log("   BODY = " + json.dumps(body, ensure_ascii=False))
    log("   请求字段: " + ", ".join(body.keys()))

    resp_text: str = ""
    try:
        status_code, data, err, text_snip = await mh_request_json(
            "POST",
            _url_create_sub(),
            ctx="subscription/create",
            default={},
            json=body,
            timeout=30,
        )
        resp_text = text_snip or ""

        # HTTP 非 200
        if status_code != 200:
            short_detail = f"HTTP {status_code}"
            if isinstance(data, dict):
                err_code = data.get("code")
                err_msg = (data.get("message") or "").strip()
                if err_msg and err_code is not None:
                    short_detail = f"HTTP {status_code} / code={err_code}: {err_msg}"
                elif err_msg:
                    short_detail = f"HTTP {status_code}: {err_msg}"
            elif resp_text:
                short_detail = f"HTTP {status_code}: {resp_text}"

            # 兜底：MediaHelp 用 400 表示“相同配置已存在”
            # 这种情况本质上是 already subscribed，而不是“创建失败”。
            # 触发原因通常是：SUB_CACHE 刷新延迟 / 并发创建 / 或 Forward 侧幂等判断更严格。
            # 对用户侧期望：应该提示“已存在（未重复创建）”。
            if status_code == 400 and isinstance(data, dict):
                _msg = (data.get("message") or "").strip()
                if "已存在相同配置" in _msg or ("已存在" in _msg and "订阅" in _msg):
                    log(f"ℹ️ MediaHelp 返回已存在：{short_detail}")
                    metrics.inc("forwardbridge_sub_already_via_400")
                    await notify_mediahelp(
                        "mediahelp_sub_already",
                        {
                            **ctx_notify,
                            "tmdb_id": tmdb_id,
                            "title": title,
                            "season": int(p.season) if p.season is not None else None,
                            "detail": short_detail,
                        },
                    )
                    return True, resp_text

            msg = f"MediaHelp 创建订阅 HTTP 非 200: {short_detail}"
            log("❌ " + msg)
            metrics.inc("forwardbridge_sub_create_failed")
            await notify_mediahelp(
                "mediahelp_sub_create_failed",
                {**ctx_notify, "tmdb_id": tmdb_id,
                    "title": title,
                    "season": int(p.season) if p.season is not None else None,
                    "detail": short_detail,
                },
            )
            return False, resp_text

        # 解析 JSON
        if err:
            msg = f"MediaHelp 创建返回非 JSON: {err}"
            log("⚠️ " + msg)
            metrics.inc("forwardbridge_sub_create_failed")
            await notify_mediahelp(
                "mediahelp_sub_create_failed",
                {**ctx_notify, "tmdb_id": tmdb_id,
                    "title": title,
                    "season": int(p.season) if p.season is not None else None,
                    "detail": msg,
                },
            )
            return False, resp_text
        if not isinstance(data, dict):
            data = {}
        else:
            data = data or {}

        code = data.get("code")
        message = (data.get("message") or "").strip()

        if code not in (None, 0, 200):
            msg = f"MediaHelp 创建订阅失败: code={code}, message={message}"
            log("❌ " + msg)
            metrics.inc("forwardbridge_sub_create_failed")
            await notify_mediahelp(
                "mediahelp_sub_create_failed",
                {**ctx_notify, "tmdb_id": tmdb_id,
                    "title": title,
                    "season": int(p.season) if p.season is not None else None,
                    "detail": msg,
                },
            )
            return False, resp_text

        # 走到这里就是 MediaHelp 业务上也认为创建成功了
        log(f"✅ 创建订阅成功: {title} ({tmdb_id})")
        create_task_logged(refresh_sub_cache(force=True), name="refresh_sub_cache", log=biz)

        # 通知：新建订阅
        await notify_mediahelp(
            "mediahelp_sub_created",
            {**ctx_notify, "tmdb_id": tmdb_id,
                "title": title,
                "season": int(p.season) if p.season is not None else None,
                "selected_seasons": selected_seasons,},
        )

        metrics.inc("forwardbridge_sub_create")
        return True, resp_text
    finally:
        # mh_request_json() 内部已负责关闭 HTTP response，这里无需再处理
        pass


async def unsubscribe_with_season(tmdb_id: int, season: int) -> Dict[str, Any]:
    """
    公共“按季取消订阅”逻辑：
      - 有 selected_seasons 列表：移除指定季；为空则删除整个任务
      - selected_seasons 为空：视为全季订阅，直接删除整个任务
    """
    await refresh_sub_cache()
    entry = SUB_CACHE.get(tmdb_id)
    selected = (entry or {}).get("selected_seasons") or []

    if selected:
        new_seasons = [s for s in selected if int(s) != season]
        if new_seasons:
            ok, detail = await mh_update_subscription_seasons(
                tmdb_id, [int(s) for s in new_seasons]
            )
            if not ok:
                return {"ok": False, "detail": detail}
            return {"ok": True, "message": "updated_seasons"}

        ok, detail = await mh_delete_subscription(tmdb_id, trigger_season=season)
        if not ok:
            return {"ok": False, "detail": detail}
        return {"ok": True, "message": "deleted_all_seasons"}

    ok, detail = await mh_delete_subscription(tmdb_id, trigger_season=season)
    if not ok:
        return {"ok": False, "detail": detail}
    return {"ok": True, "message": "deleted_full_subscription"}