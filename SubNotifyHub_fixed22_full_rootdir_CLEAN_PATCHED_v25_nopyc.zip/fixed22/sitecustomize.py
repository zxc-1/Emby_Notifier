"""Site customizations for this project.

Goal: keep test and maintenance runs quiet and future-proof by silencing a couple of
well-known third-party warnings that can appear in constrained environments.

We only filter very specific messages/categories (no blanket ignores).

If ddtrace auto-instrumentation is present, we delegate to its bootstrap sitecustomize
after installing filters so it can still run without producing noisy warnings.
"""

from __future__ import annotations

import warnings

# ddtrace/vendor/psutil: can emit this in minimal containers without /proc/vmstat
warnings.filterwarnings(
    "ignore",
    message=r".*swap memory stats couldn't be determined.*",
    category=RuntimeWarning,
)

# Common exact form observed in CI: "'sin' and 'sout' swap memory stats couldn't be determined ..."
warnings.filterwarnings(
    "ignore",
    message=r"'sin' and 'sout' swap memory stats couldn't be determined.*",
    category=RuntimeWarning,
)

# Some psutil builds include 'sin'/'sout' prefix; keep a broader match.
warnings.filterwarnings(
    "ignore",
    message=r".*'sin'.*'sout'.*swap memory stats couldn't be determined.*",
    category=RuntimeWarning,
)

# Extra safety: only within psutil modules.
warnings.filterwarnings(
    "ignore",
    message=r".*swap memory stats couldn't be determined.*",
    category=RuntimeWarning,
    module=r".*psutil.*",
)

# python-multipart: upstream PendingDeprecationWarning in some dependency stacks
warnings.filterwarnings(
    "ignore",
    message=r"Please use `import python_multipart` instead\.",
    category=PendingDeprecationWarning,
)

from core.logging import get_biz_logger

biz = get_biz_logger(__name__)

# If ddtrace is installed and expects to run via sitecustomize, run it after filters.
try:
    import importlib

    importlib.import_module("ddtrace.bootstrap.sitecustomize")
except Exception:
    biz.detail("⚠️ 加载 ddtrace.bootstrap.sitecustomize 失败", exc_info=True)
