"""Compatibility shim for the (optional) `sqlitetools` dependency.

Some upstream 115 SDK tooling imports `sqlitetools` but doesn't always ship it
as a hard dependency. Our service doesn't call those tooling APIs, yet the
import can still fail and block startup. This module provides a small subset of
helpers so the import can succeed.

If you actually need advanced DB helpers, install the real `sqlitetools`
package instead.
"""

from __future__ import annotations

import sqlite3
from collections.abc import Iterable, Mapping
from pathlib import Path
from typing import Any, Optional, Sequence, Tuple, Union


Connection = sqlite3.Connection
Cursor = sqlite3.Cursor


def connect(dbfile: Union[str, Path, Connection, Cursor], /, **kwargs: Any) -> Connection:
    """Return a sqlite3.Connection.

    Accepts a path, an existing Connection, or a Cursor.
    """
    if isinstance(dbfile, sqlite3.Connection):
        return dbfile
    if isinstance(dbfile, sqlite3.Cursor):
        return dbfile.connection
    path = str(dbfile)
    con = sqlite3.connect(path, **kwargs)
    con.row_factory = sqlite3.Row
    return con


def execute(
    con_or_cur: Union[Connection, Cursor],
    sql: str,
    params: Sequence[Any] | Mapping[str, Any] = (),
    /,
) -> Cursor:
    """Execute SQL and return cursor."""
    cur = con_or_cur if isinstance(con_or_cur, sqlite3.Cursor) else con_or_cur.cursor()
    cur.execute(sql, params)
    return cur


def query(
    con_or_cur: Union[Connection, Cursor],
    sql: str,
    params: Sequence[Any] | Mapping[str, Any] = (),
    /,
) -> list[dict[str, Any]]:
    """Execute a query and return rows as list of dict."""
    cur = execute(con_or_cur, sql, params)
    rows = cur.fetchall()
    return [dict(r) for r in rows]


def find(
    con_or_cur: Union[Connection, Cursor],
    sql: str,
    params: Sequence[Any] | Mapping[str, Any] = (),
    /,
) -> Optional[dict[str, Any]]:
    """Execute a query and return the first row as dict (or None)."""
    cur = execute(con_or_cur, sql, params)
    row = cur.fetchone()
    return None if row is None else dict(row)


def upsert_items(
    con_or_cur: Union[Connection, Cursor],
    table: str,
    items: Iterable[Mapping[str, Any]],
    /,
    *,
    conflict_keys: Sequence[str] = (),
) -> int:
    """Very small UPSERT helper.

    - `conflict_keys` controls the ON CONFLICT target.
    - Returns number of processed items.

    This is only meant to satisfy imports. It's good enough for simple use.
    """
    cur = con_or_cur if isinstance(con_or_cur, sqlite3.Cursor) else con_or_cur.cursor()
    items_list = list(items)
    if not items_list:
        return 0

    cols = list(items_list[0].keys())
    placeholders = ",".join(["?"] * len(cols))
    col_list = ",".join([f'"{c}"' for c in cols])

    if conflict_keys:
        target = ",".join([f'"{c}"' for c in conflict_keys])
        update_cols = [c for c in cols if c not in conflict_keys]
        set_expr = ",".join([f'"{c}"=excluded."{c}"' for c in update_cols])
        sql = f'INSERT INTO "{table}" ({col_list}) VALUES ({placeholders}) '
        if set_expr:
            sql += f'ON CONFLICT({target}) DO UPDATE SET {set_expr}'
        else:
            sql += f'ON CONFLICT({target}) DO NOTHING'
    else:
        sql = f'INSERT INTO "{table}" ({col_list}) VALUES ({placeholders})'

    cur.executemany(sql, [tuple(it.get(c) for c in cols) for it in items_list])
    return len(items_list)
