"""ASGI entrypoint.

Keep this file tiny so imports stay fast and side-effects stay centralized.
"""

from core.bootstrap import create_app


app = create_app()
