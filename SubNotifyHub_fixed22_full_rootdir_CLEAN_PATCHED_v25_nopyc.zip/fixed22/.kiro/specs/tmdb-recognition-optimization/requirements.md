# Requirements Document

## Introduction

本文档定义了 115 分享链接 TMDB 识别逻辑的优化需求。当前系统已实现完整的多文件证据收集、多 hint 共识机制和剧集一致性评分，但在某些场景下仍存在识别准确率和自动选择率的优化空间。

## Glossary

- **Share_Resolver**: 115 分享链接到 TMDB ID 的解析系统
- **Hint_Pack**: 从分享链接提取的搜索提示包，包含 hints_main（主要提示）、hints_msg（消息提示）、hints_extra（额外提示）
- **Evidence_Level**: 证据等级（L0-L3），表示 115 证据的可靠程度
- **Auto_Pick**: 自动选择机制，当置信度足够高时自动绑定 TMDB ID
- **Support_Count**: 多 hint 共识计数，表示有多少个 hint 指向同一候选
- **Episode_Score**: 剧集一致性评分，基于本地剧集集合与 TMDB 季度总集数的匹配度
- **Fused_Score**: 融合评分，综合 title 相似度、coverage、support 权重等因素
- **Stage_A**: 第一阶段 TMDB 搜索（full 模式，使用主要 hint）
- **Stage_B**: 第二阶段 TMDB 搜索（light 模式，使用次要 hint）
- **Bilingual_Evidence**: 双语证据，同时包含 CJK 和拉丁字符的 hint

## Requirements

### Requirement 1: video_samples 优先级提升

**User Story:** As a user, I want the system to give higher priority to video filename samples, so that recognition accuracy improves when share_title is generic but filenames are specific.

#### Acceptance Criteria

1. WHEN video_samples contain specific title information (e.g., "Show.Name.S01E01.1080p.mkv") AND share_title is generic (e.g., "电视剧合集"), THEN THE Share_Resolver SHALL prioritize video_samples over share_title for hint generation
2. WHEN video_samples are available, THE Share_Resolver SHALL include at least one video_sample in hints_main instead of hints_extra
3. WHEN multiple video_samples share a common title pattern, THE Share_Resolver SHALL extract and use the batch_title as a high-priority hint
4. THE Share_Resolver SHALL detect generic share_titles using a configurable pattern list (e.g., "合集", "全集", "资源")

### Requirement 2: share_title 智能利用

**User Story:** As a user, I want the system to intelligently use share_title based on its quality, so that high-quality CJK titles improve recognition while generic titles don't pollute results.

#### Acceptance Criteria

1. WHEN share_title contains CJK characters AND has length >= 4 AND does not match garbage patterns, THEN THE Share_Resolver SHALL classify it as high-quality and add to hints_main
2. WHEN share_title matches garbage patterns (e.g., "1080p", "BDMV", "合集"), THEN THE Share_Resolver SHALL exclude it from hints_main
3. WHEN share_title quality score is below threshold, THE Share_Resolver SHALL demote it to hints_extra
4. THE Share_Resolver SHALL compute a title_quality_score for share_title considering CJK presence, length, and absence of technical tags

### Requirement 3: 自动选择阈值优化

**User Story:** As a user, I want the system to auto-pick more confidently when evidence is strong, so that I don't need to manually confirm obvious matches.

#### Acceptance Criteria

1. WHEN evidence_level >= L3 AND top candidate has score >= 0.90 AND coverage >= 0.70 AND gap >= 0.08, THEN THE Auto_Pick SHALL return True
2. WHEN episode_score >= 0.50 AND standard_rate >= 0.85 AND score >= 0.85, THEN THE Auto_Pick SHALL return True for TV shows
3. WHEN support_count >= 2 AND support_main >= 1 AND score >= 0.82, THEN THE Auto_Pick SHALL return True
4. WHEN only one candidate exists AND score >= 0.88 AND coverage >= 0.75, THEN THE Auto_Pick SHALL return True with strength "strong"
5. IF evidence_level <= L1, THEN THE Auto_Pick SHALL return False regardless of scores

### Requirement 4: Stage-A/Stage-B 搜索策略优化

**User Story:** As a user, I want the system to make smarter decisions about when to run Stage-B search, so that recognition speed improves without sacrificing accuracy.

#### Acceptance Criteria

1. WHEN Stage-A produces a candidate with score >= 0.95 AND coverage >= 0.85 AND gap >= 0.15, THEN THE Share_Resolver SHALL skip Stage-B
2. WHEN bilingual_evidence is detected (CJK + Latin hints), THEN THE Share_Resolver SHALL always run Stage-B
3. WHEN Stage-A top candidate has year mismatch >= 2 with q_year, THEN THE Share_Resolver SHALL run Stage-B
4. WHEN Stage-A produces no candidates with score >= 0.70, THEN THE Share_Resolver SHALL run Stage-B with expanded hints
5. THE Share_Resolver SHALL deduplicate Stage-B hints by normalized (title, year, season) to avoid redundant TMDB calls

### Requirement 5: 年份匹配增强

**User Story:** As a user, I want the system to better handle year information, so that remakes and same-name titles from different years are correctly distinguished.

#### Acceptance Criteria

1. WHEN q_year is extracted from evidence AND candidate year differs by >= 2, THEN THE Share_Resolver SHALL apply a score penalty of -0.05
2. WHEN strict_year is detected from CJK title pattern like "剧名(2025)", THEN THE Share_Resolver SHALL treat year-off-by-1 as negative signal
3. WHEN candidate year is missing (None), THEN THE Share_Resolver SHALL apply a score penalty of -0.02
4. WHEN q_year matches candidate year exactly, THEN THE Share_Resolver SHALL apply a score bonus of +0.03
5. THE Share_Resolver SHALL attempt to fetch candidate year from TMDB detail when top candidates have missing years

### Requirement 6: 剧集一致性评分增强

**User Story:** As a user, I want the system to better validate TV show matches using episode information, so that wrong season/show bindings are avoided.

#### Acceptance Criteria

1. WHEN episode_set contains >= 3 episodes AND season_hint_eff is known, THEN THE Share_Resolver SHALL fetch season episode count from TMDB
2. WHEN local episode numbers fall within TMDB season range, THE Share_Resolver SHALL compute episode_score as coverage ratio
3. WHEN episode_score >= 0.45 AND score >= 0.80, THEN THE Share_Resolver SHALL boost fused_score
4. WHEN episode numbers exceed TMDB season total by > 20%, THEN THE Share_Resolver SHALL apply a penalty to that candidate
5. THE Share_Resolver SHALL limit episode consistency API calls to top 8 candidates to control latency

### Requirement 7: 多 hint 共识机制增强

**User Story:** As a user, I want the system to better leverage consensus from multiple hints, so that collision-prone titles are handled more safely.

#### Acceptance Criteria

1. WHEN selected_hints_count >= 2 AND top1_support_count >= 2, THEN THE Share_Resolver SHALL increase confidence in auto-pick
2. WHEN has_main_hint is True AND support_main >= 1, THEN THE Share_Resolver SHALL relax consensus requirements
3. WHEN collision_risky is True (short generic title), THEN THE Share_Resolver SHALL require support_count >= 2 for auto-pick
4. THE Share_Resolver SHALL compute support_weight giving main hints weight 2 and message hints weight 1
5. WHEN top candidate has support_weight >= 3, THEN THE Share_Resolver SHALL apply a fused_score bonus of +0.03

### Requirement 8: 缓存命中优化

**User Story:** As a user, I want the system to better utilize learned caches, so that repeated queries for the same title are faster and more accurate.

#### Acceptance Criteria

1. WHEN title_cache hit has confidence >= 0.82 AND coverage >= 0.60, THEN THE Share_Resolver SHALL return cached result directly
2. WHEN series_cache hit has confidence >= 0.80 AND year matches within 2, THEN THE Share_Resolver SHALL return cached result for TV shows
3. WHEN cached mapping validation fails (score < 0.72), THEN THE Share_Resolver SHALL disable the bad mapping
4. THE Share_Resolver SHALL use cached_fp_tid as a seed candidate competing with search results
5. WHEN strong_tv evidence exists AND cached mapping points to movie, THEN THE Share_Resolver SHALL reject the cached mapping

### Requirement 9: 短标题碰撞防护

**User Story:** As a user, I want the system to handle short or generic titles more carefully, so that common collision-prone titles like "Up", "Her", "Home" don't auto-bind to wrong entries.

#### Acceptance Criteria

1. WHEN query_title has <= 2 tokens AND contains collision-prone words (e.g., "love", "home", "family", "man", "world"), THEN THE Share_Resolver SHALL require score >= 0.95 AND coverage >= 0.92 for auto-pick
2. WHEN query_title has <= 1 token, THEN THE Share_Resolver SHALL require score >= 0.93 AND coverage >= 0.90 for auto-pick
3. THE Share_Resolver SHALL maintain a configurable collision_words set for both English and Chinese common words
4. WHEN collision_risky is True AND support_count < 2, THEN THE Share_Resolver SHALL NOT auto-pick unless evidence is extremely strong (score >= 0.97, coverage >= 0.92)
5. WHEN Stage-A produces a short-title match, THE Share_Resolver SHALL NOT early-stop unless score >= 0.985 AND gap >= 0.18

### Requirement 10: 错误处理与重试机制

**User Story:** As a user, I want the system to gracefully handle TMDB API failures and network issues, so that temporary errors don't cause permanent wrong bindings.

#### Acceptance Criteria

1. WHEN TMDB API returns timeout or 5xx error, THEN THE Share_Resolver SHALL retry up to 2 times with exponential backoff
2. WHEN TMDB API is temporarily unavailable, THE Share_Resolver SHALL NOT persist any mapping (return reason="tmdb_unavailable")
3. WHEN fetch_share_evidence fails with temp_unavailable, THE Share_Resolver SHALL set evidence_level to L0 and block auto-pick
4. THE Share_Resolver SHALL log all API failures with structured context (share_code_hash, hint_count, error_type)
5. WHEN pre_resolve stage fails, THE Share_Resolver SHALL continue to build_candidate_sets stage instead of returning early

### Requirement 11: 多季/多部处理增强

**User Story:** As a user, I want the system to correctly handle multi-season packs and multi-part movies, so that season-specific bindings are accurate.

#### Acceptance Criteria

1. WHEN evidence contains multiple season markers (e.g., S01-S03), THE Share_Resolver SHALL prefer the lowest season number for initial binding
2. WHEN share contains both movie and TV content (e.g., trilogy + TV series), THE Share_Resolver SHALL NOT auto-pick and require manual selection
3. WHEN season_hint_eff differs from episode_set season markers, THE Share_Resolver SHALL use the season marker from episode_set
4. THE Share_Resolver SHALL detect "Part 1", "Part 2" patterns and treat them as separate entries requiring confirmation
5. WHEN TV show has multiple versions (e.g., US vs UK), THE Share_Resolver SHALL use year and origin_country to disambiguate

### Requirement 12: 别名与翻译处理增强

**User Story:** As a user, I want the system to better handle title aliases and translations, so that CJK titles correctly match their English TMDB entries and vice versa.

#### Acceptance Criteria

1. WHEN bilingual_evidence is detected (CJK + Latin hints), THE Share_Resolver SHALL always run Stage-B to query both languages
2. THE Share_Resolver SHALL fetch alternative_titles from TMDB detail and include them in similarity scoring
3. WHEN CJK hint produces no candidates but Latin hint produces strong match, THE Share_Resolver SHALL verify the match against CJK alias
4. THE Share_Resolver SHALL normalize romanized CJK titles (e.g., "Qing Nian" -> "轻年") for better matching
5. WHEN share_title is CJK AND filename is Latin, THE Share_Resolver SHALL give higher weight to share_title (human-chosen label)

### Requirement 13: 性能优化 - API 调用减少

**User Story:** As a user, I want the system to minimize TMDB API calls, so that recognition is faster and rate limits are not exceeded.

#### Acceptance Criteria

1. THE Share_Resolver SHALL deduplicate Stage-B hints by normalized (title, year, season) to avoid redundant TMDB calls
2. WHEN Stage-A produces a candidate with score >= 0.95 AND coverage >= 0.85 AND gap >= 0.15 AND NOT bilingual_evidence, THEN THE Share_Resolver SHALL skip Stage-B
3. THE Share_Resolver SHALL limit episode consistency API calls to top 8 candidates
4. THE Share_Resolver SHALL use concurrent requests (Semaphore=3) for episode_score enrichment
5. THE Share_Resolver SHALL cache TMDB detail responses in-memory for the duration of a single resolve request

### Requirement 14: 日志与可观测性增强

**User Story:** As a developer, I want comprehensive logging of the recognition pipeline, so that I can debug mis-bindings and tune thresholds.

#### Acceptance Criteria

1. THE Share_Resolver SHALL log each stage completion with timing and key metrics (hint_count, candidate_count, top_score)
2. THE Share_Resolver SHALL include decision_trace in all return values showing the path taken (e.g., "pre:title_cache", "stageA_stable", "auto_pick")
3. WHEN auto_pick returns False, THE Share_Resolver SHALL log the specific gate that blocked it (e.g., "collision_risky", "year_mismatch", "low_coverage")
4. THE Share_Resolver SHALL log all score adjustments (year_affinity, episode_score, support_bonus) with before/after values
5. THE Share_Resolver SHALL provide a debug mode that returns full candidate scoring breakdown

### Requirement 15: 115 分页一致性处理

**User Story:** As a user, I want the system to detect and handle 115 API paging inconsistencies, so that incomplete evidence doesn't cause wrong bindings.

#### Acceptance Criteria

1. WHEN 115 API reports video_count != actual paged items, THE Share_Resolver SHALL set count_mismatch flag
2. WHEN count_mismatch is True, THE Share_Resolver SHALL downgrade evidence_level by 1 (e.g., L3 -> L2)
3. WHEN count_mismatch is True AND score < 0.92, THE Share_Resolver SHALL NOT auto-pick
4. THE Share_Resolver SHALL log paging inconsistencies with expected vs actual counts
5. WHEN count_mismatch is True AND selected_hints_count >= 2, THE Share_Resolver SHALL require multi-hint consensus for auto-pick

### Requirement 16: Strict Year 模式增强

**User Story:** As a user, I want the system to respect explicit year markers in CJK titles, so that remakes and same-name titles from different years are correctly distinguished.

#### Acceptance Criteria

1. WHEN CJK title contains explicit year pattern like "剧名(2025)" or "剧名（2025）", THE Share_Resolver SHALL extract strict_year
2. WHEN strict_year is set AND candidate year differs by 1, THE Share_Resolver SHALL apply a penalty of -0.02 (instead of bonus)
3. WHEN strict_year is set AND candidate year differs by >= 2, THE Share_Resolver SHALL apply a penalty of -0.05
4. WHEN strict_year is set, THE Share_Resolver SHALL NOT early-stop Stage-A if top candidate year != strict_year
5. THE Share_Resolver SHALL prefer CJK title with strict_year as primary_hint over English alias

### Requirement 17: 动漫特殊处理

**User Story:** As a user, I want the system to better handle anime titles with multiple language aliases, so that Japanese/English/Chinese anime titles are correctly matched.

#### Acceptance Criteria

1. WHEN media_type is detected as anime (genre_ids contains 16 for animation), THE Share_Resolver SHALL fetch all alternative_titles including Japanese romaji
2. WHEN anime title contains common suffixes like "第X季", "Season X", "シーズンX", THE Share_Resolver SHALL normalize them for matching
3. WHEN anime evidence contains both Japanese (hiragana/katakana) and CJK characters, THE Share_Resolver SHALL treat it as bilingual_evidence
4. THE Share_Resolver SHALL recognize common anime naming patterns (e.g., "[SubGroup] Title - 01 [1080p].mkv")
5. WHEN anime title similarity is >= 0.85 AND genre matches animation, THE Share_Resolver SHALL boost confidence by +0.03

### Requirement 18: 续集/前传检测

**User Story:** As a user, I want the system to correctly distinguish sequels and prequels from original titles, so that "复仇者联盟2" doesn't match "复仇者联盟".

#### Acceptance Criteria

1. WHEN query_title contains sequel markers (2, II, 续集, Part 2, 第二部), THE Share_Resolver SHALL require candidate title to also contain sequel markers
2. WHEN query_title does NOT contain sequel markers BUT candidate title does, THE Share_Resolver SHALL apply a penalty of -0.10
3. THE Share_Resolver SHALL detect common sequel patterns in both CJK and Latin (e.g., "2", "II", "III", "第二季", "续集", "前传")
4. WHEN sequel number in query differs from candidate (e.g., query="复仇者联盟2" vs candidate="复仇者联盟3"), THE Share_Resolver SHALL apply a penalty of -0.15
5. THE Share_Resolver SHALL normalize sequel markers for comparison (e.g., "II" == "2", "第二部" == "Part 2")

### Requirement 19: 快速提示强度检测

**User Story:** As a user, I want the system to quickly assess hint quality before full processing, so that obviously weak hints don't waste API calls.

#### Acceptance Criteria

1. WHEN share evidence is retrieved in fast mode (fallback=True), THE Share_Resolver SHALL evaluate hint strength using _fast_hint_strong()
2. WHEN fast hint is strong (CJK title >= 4 chars, no technical tags), THE Share_Resolver SHALL proceed with normal processing
3. WHEN fast hint is weak, THE Share_Resolver SHALL attempt full evidence retrieval before TMDB search
4. THE Share_Resolver SHALL detect technical tags (1080p, x264, BDMV, etc.) as indicators of weak hints
5. WHEN hint contains only technical tags without meaningful title, THE Share_Resolver SHALL set evidence_level to L1

### Requirement 20: 质量去重（多版本处理）

**User Story:** As a user, I want the system to handle multiple release versions of the same episode, so that duplicate files don't confuse episode counting.

#### Acceptance Criteria

1. WHEN multiple video files map to the same episode number, THE Share_Resolver SHALL select the best quality version
2. THE Share_Resolver SHALL prefer larger file size as indicator of better quality
3. THE Share_Resolver SHALL track episode_dup_count for logging and confidence adjustment
4. WHEN episode_dup_count > 0 AND episode_best_files covers >= 75% of episode_set, THE Share_Resolver SHALL maintain confidence
5. THE Share_Resolver SHALL use episode_best_files (deduplicated) for episode_score calculation instead of raw video_files

