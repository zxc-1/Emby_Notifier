# Design Document: TMDB Recognition Optimization

## Overview

本设计文档描述 115 分享链接 TMDB 识别逻辑的优化方案。优化目标是提高识别准确率、增加自动选择率、减少 API 调用、增强系统健壮性。

系统采用分阶段流水线架构：
1. **证据收集阶段** - 从 115 分享链接提取视频文件信息
2. **Hint 构建阶段** - 将证据转换为可搜索的提示包
3. **预解析阶段** - 尝试从缓存/显式 ID 快速命中
4. **候选生成阶段** - 分阶段 TMDB 搜索并合并候选
5. **决策阶段** - 基于多维度评分决定是否自动选择
6. **持久化阶段** - 保存映射关系

## Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                        Share Resolver Pipeline                       │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────────────┐  │
│  │   115 API    │───▶│  Evidence    │───▶│    Hint Pack         │  │
│  │  (snapshot)  │    │  Collector   │    │    Builder           │  │
│  └──────────────┘    └──────────────┘    └──────────────────────┘  │
│                                                    │                 │
│                                                    ▼                 │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────────────┐  │
│  │   Cache      │◀──▶│  Pre-Resolve │◀───│   hints_main/msg/    │  │
│  │   Layer      │    │    Stage     │    │   extra/hints2       │  │
│  └──────────────┘    └──────────────┘    └──────────────────────┘  │
│         │                   │                      │                 │
│         │                   ▼                      ▼                 │
│         │            ┌──────────────┐    ┌──────────────────────┐  │
│         │            │  Stage-A     │───▶│    Candidate         │  │
│         │            │  (full)      │    │    Merger            │  │
│         │            └──────────────┘    └──────────────────────┘  │
│         │                   │                      │                 │
│         │                   ▼                      │                 │
│         │            ┌──────────────┐              │                 │
│         │            │  Stage-B     │──────────────┘                 │
│         │            │  (light)     │                                │
│         │            └──────────────┘                                │
│         │                                          │                 │
│         │                                          ▼                 │
│         │                                 ┌──────────────────────┐  │
│         │                                 │   Episode Score      │  │
│         │                                 │   Enrichment         │  │
│         │                                 └──────────────────────┘  │
│         │                                          │                 │
│         │                                          ▼                 │
│         │                                 ┌──────────────────────┐  │
│         └────────────────────────────────▶│   Decision Engine    │  │
│                                           │   (Auto-Pick)        │  │
│                                           └──────────────────────┘  │
│                                                    │                 │
│                                                    ▼                 │
│                                           ┌──────────────────────┐  │
│                                           │   Persistence        │  │
│                                           │   Layer              │  │
│                                           └──────────────────────┘  │
└─────────────────────────────────────────────────────────────────────┘
```

## Components and Interfaces

### 1. Evidence Collector (`snapshot.py`)

**职责**: 从 115 分享链接收集视频文件证据

**接口**:
```python
async def fetch_share_evidence(
    share_url: str,
    share_code: str,
    receive_code: str,
    decision_trace: List[str]
) -> Dict[str, Any]:
    """
    Returns:
        ok: bool
        best: Dict with share_title, filename, hint_name, dir_path, 
              video_samples, video_files, video_count, paging
        file_sig: str (content signature)
        evidence_weak: bool
        temp_unavailable: bool
    """
```

### 2. Hint Pack Builder (`hints.py`)

**职责**: 将证据转换为结构化的搜索提示包

**接口**:
```python
def build_hint_pack(
    share_url: str,
    hint_text: Optional[str],
    season_hint: Optional[int],
    best: Optional[Dict[str, Any]],
    evidence_temp_unavailable: bool,
    evidence_weak: bool
) -> Dict[str, Any]:
    """
    Returns:
        hints_main: List[str]  # 主要提示（高优先级）
        hints_msg: List[str]   # 消息提示
        hints_extra: List[str] # 额外提示（低优先级）
        hints2: List[str]      # 清洗后的去重提示
        q_title: str           # 最佳标题
        q_year: Optional[int]  # 最佳年份
        evidence_level: int    # L0-L3
        episode_set: List[int] # 剧集集合
        standard_rate: float   # SxxEyy 标准化率
        ...
    """
```

**新增函数**:
```python
def _title_quality_score(title: str) -> float:
    """计算标题质量分数，考虑 CJK 存在、长度、技术标签缺失"""

def _is_generic_share_title(title: str) -> bool:
    """检测是否为通用分享标题（合集、全集、资源等）"""

def _extract_strict_year(title: str) -> Optional[int]:
    """从 CJK 标题中提取显式年份，如 '剧名(2025)'"""
```

### 3. Pre-Resolve Stage (`tmdb_lookup.py`)

**职责**: 尝试从缓存/显式 ID 快速命中

**接口**:
```python
async def pre_resolve_from_names_and_caches(
    q_title: str,
    q_year: Optional[int],
    season_hint_eff: Optional[int],
    tvish: bool,
    vc_reliable: bool,
    video_count: int,
    hints2: List[str],
    filename: str,
    hint_name: str,
    share_title: str,
    dir_path: List[str],
    cached_weak: Optional[Dict[str, Any]],
    decision_trace: Optional[List[str]]
) -> Dict[str, Any]:
    """
    Returns:
        picked: Optional[Dict]  # 命中的候选
        from_source: str        # 来源（title_cache/series_cache/imdb_find/...）
        cached_fp_tid: Optional[int]  # 用于后续 seed
        seed_candidates: List[Dict]   # 种子候选
    """
```

### 4. Candidate Generator (`tmdb_lookup.py`)

**职责**: 分阶段 TMDB 搜索并合并候选

**接口**:
```python
async def build_candidate_sets(
    hints_main: List[str],
    hints_msg: List[str],
    hints_extra: List[str],
    hints2: List[str],
    q_title: str,
    q_year: Optional[int],
    force_mt: Optional[str],
    season_hint_eff: Optional[int],
    episode_set: Optional[List[int]],
    cached_fp_tid: Optional[int],
    seed_candidates: Optional[List[Dict[str, Any]]]
) -> Dict[str, Any]:
    """
    Returns:
        cands_all: List[Dict]      # 所有候选（按 fused_score 排序）
        cands_show: List[Dict]     # UI 展示候选
        selected_hints: List[str]  # 实际使用的 hints
        has_main_hint: bool
        used_season/used_title/used_year/used_mt
    """
```

**新增内部函数**:
```python
def _stage_a_stable(g: Dict[str, Any], strict_year: Optional[int], q_year: Optional[int]) -> bool:
    """判断 Stage-A 结果是否足够稳定可以跳过 Stage-B"""

def _hint_query_key(h: str) -> Tuple[str, int, int]:
    """生成 hint 的规范化查询键用于去重"""

def _apply_year_affinity(cands: List[Dict], year_ref: int, strict_year: Optional[int]) -> None:
    """应用年份亲和度调整"""
```

### 5. Decision Engine (`decide.py` + `autopick.py`)

**职责**: 基于多维度评分决定是否自动选择

**接口**:
```python
async def decide_best_candidate(
    cands_all: List[Dict[str, Any]],
    q_title: str,
    q_year: Optional[int],
    used_title: str,
    used_year: Optional[int],
    used_mt: str,
    used_season: Optional[int],
    force_mt: Optional[str],
    has_main_hint: bool,
    selected_hints_count: int,
    evidence_level: int,
    evidence_level_desc: Optional[str],
    standard_rate: float,
    episode_set: Optional[List[int]],
    episode_best_files: Optional[List[Dict[str, Any]]],
    episode_dup_count: int,
    count_mismatch: bool
) -> Dict[str, Any]:
    """
    Returns:
        ok_pick: bool
        picked: Optional[Dict]
        auto_strength: str  # 'strong' | 'weak'
        cands_all: List[Dict]  # 可能更新后的候选
        gated: bool  # 是否被证据等级门控
    """
```

```python
def should_auto_pick(
    scores: List[Tuple[Candidate, float]],
    ctx: Optional[Dict[str, Any]] = None
) -> bool:
    """
    核心自动选择策略，考虑：
    - 分数/覆盖率/间隙
    - 多 hint 共识
    - 碰撞风险
    - 年份匹配
    - 剧集一致性
    - 证据等级
    """
```

### 6. Scoring Utilities (`scoring.py`)

**新增函数**:
```python
def compute_collision_risk(q_title: str) -> Tuple[bool, List[str]]:
    """
    计算标题碰撞风险
    Returns:
        collision_risky: bool
        matched_words: List[str]  # 匹配到的碰撞词
    """

COLLISION_WORDS_EN = {
    "man", "one", "family", "home", "love", "world", "life", 
    "day", "night", "story", "journey", "young", "girl", "boy",
    "woman", "time", "dream", "star", "king", "queen", "game"
}

COLLISION_WORDS_CJK = {
    "男人", "一个", "家庭", "家", "爱情", "世界", "人生", 
    "故事", "旅程", "青春", "女孩", "男孩"
}
```

### 7. Video Samples Prioritizer (`hints.py`)

**职责**: 实现 video_samples 优先级提升逻辑

**新增函数**:
```python
def _prioritize_video_samples(
    video_samples: List[str],
    share_title: str,
    hints_main: List[str],
    hints_extra: List[str]
) -> Tuple[List[str], List[str]]:
    """
    当 share_title 是通用标题但 video_samples 包含具体信息时，
    将 video_samples 提升到 hints_main
    
    Returns:
        updated_hints_main: List[str]
        updated_hints_extra: List[str]
    """

def _extract_batch_title(video_samples: List[str]) -> Optional[str]:
    """
    从多个视频样本中提取共同的批次标题
    例如: ["Show.Name.S01E01.mkv", "Show.Name.S01E02.mkv"] -> "Show Name"
    """

def _is_specific_video_sample(sample: str) -> bool:
    """
    判断视频样本是否包含具体的标题信息（而非纯技术标签）
    例如: "Show.Name.S01E01.1080p.mkv" -> True
          "1080p.HEVC.mkv" -> False
    """

# 通用分享标题模式（可配置）
GENERIC_SHARE_TITLE_PATTERNS = [
    r"合集", r"全集", r"资源", r"分享", r"打包",
    r"collection", r"complete", r"pack",
    r"^\d+p$",  # 纯分辨率
    r"^BDMV$", r"^REMUX$",
]
```

**算法流程**:
```
1. 检测 share_title 是否匹配 GENERIC_SHARE_TITLE_PATTERNS
2. 如果是通用标题 AND video_samples 非空:
   a. 遍历 video_samples，找出 _is_specific_video_sample() 为 True 的样本
   b. 尝试 _extract_batch_title() 提取共同标题
   c. 如果成功提取 batch_title，加入 hints_main 最前面
   d. 将最具体的 video_sample 也加入 hints_main
3. 如果 share_title 是高质量标题，保持原有优先级
```

### 8. Multi-Season/Multi-Part Handler (`hints.py` + `decide.py`)

**职责**: 处理多季打包和多部电影的识别

**新增函数**:
```python
def _detect_multi_season_markers(
    video_samples: List[str],
    dir_path: List[str]
) -> Tuple[bool, List[int], int]:
    """
    检测多季标记
    Returns:
        is_multi_season: bool
        season_numbers: List[int]  # 检测到的季度列表，如 [1, 2, 3]
        preferred_season: int      # 推荐使用的季度（最小值）
    """

def _detect_mixed_content(
    video_samples: List[str],
    candidates: List[Dict]
) -> Tuple[bool, str]:
    """
    检测是否包含混合内容（电影+剧集）
    Returns:
        is_mixed: bool
        reason: str  # 如 "trilogy_and_tv", "movie_and_tv"
    """

def _detect_part_markers(filename: str) -> Tuple[bool, Optional[int]]:
    """
    检测 Part 1/2/3 等标记
    Returns:
        has_part: bool
        part_number: Optional[int]
    """

def _detect_regional_version(
    title: str,
    year: Optional[int],
    candidates: List[Dict]
) -> Optional[str]:
    """
    检测地区版本（US vs UK 等）
    Returns:
        region_hint: Optional[str]  # 如 "US", "UK", "JP"
    """

# Part 标记正则
PART_PATTERNS = [
    r"[.\s_-]Part[.\s_-]?(\d+)",
    r"[.\s_-]Pt[.\s_-]?(\d+)",
    r"第(\d+)部",
    r"[.\s_-](\d+)of\d+",
]
```

**决策逻辑**:
```
1. 多季检测:
   - 如果 is_multi_season=True，设置 season_hint_eff = preferred_season（最小值）
   - 在 decision_trace 中记录 "multi_season:S01-S03->S01"

2. 混合内容检测:
   - 如果 is_mixed=True，强制 auto_pick=False
   - 返回 reason="mixed_content:{reason}"

3. Part 检测:
   - 如果 has_part=True，强制 auto_pick=False
   - 返回 reason="part_movie_needs_confirm"

4. 地区版本:
   - 如果检测到多个地区版本候选，使用 year + origin_country 区分
   - 优先匹配 q_year 对应的版本
```

### 9. Alias & Translation Handler (`tmdb_lookup.py`)

**职责**: 处理别名和翻译匹配

**新增函数**:
```python
async def _fetch_alternative_titles(
    tmdb_id: int,
    media_type: str
) -> List[str]:
    """
    从 TMDB 获取 alternative_titles
    Returns:
        titles: List[str]  # 包含所有语言的别名
    """

def _normalize_romanized_cjk(title: str) -> Optional[str]:
    """
    尝试将罗马音转换为 CJK
    例如: "Qing Nian" -> 可能匹配 "青年" 或 "轻年"
    注意: 这是启发式匹配，不保证准确
    """

def _compute_alias_similarity(
    query: str,
    candidate_title: str,
    alternative_titles: List[str]
) -> float:
    """
    计算查询与候选的相似度，考虑别名
    Returns:
        max_similarity: float  # 与主标题或任一别名的最大相似度
    """

def _detect_bilingual_evidence(hints: List[str]) -> bool:
    """
    检测是否存在双语证据（同时有 CJK 和 Latin）
    """

def _weight_cjk_share_title(
    share_title: str,
    filename: str,
    current_weight: float
) -> float:
    """
    当 share_title 是 CJK 而 filename 是 Latin 时，
    提升 share_title 的权重（人工选择的标签更可靠）
    """
```

**别名匹配流程**:
```
1. Stage-A 完成后，对 top 5 候选获取 alternative_titles
2. 重新计算相似度，使用 _compute_alias_similarity()
3. 如果某候选通过别名匹配得分显著提升，更新其 fused_score
4. 在 decision_trace 中记录 "alias_boost:{tmdb_id}:{old_score}->{new_score}"
```

### 10. Debug Mode Handler (`usecase.py`)

**职责**: 提供详细的调试信息输出

**新增函数**:
```python
def _build_debug_response(
    cands_all: List[Dict],
    decision_trace: List[str],
    hint_pack: Dict,
    stage_a_result: Dict,
    stage_b_result: Optional[Dict],
    timing: Dict[str, float]
) -> Dict[str, Any]:
    """
    构建完整的调试响应
    Returns:
        debug_info: Dict containing:
            - hint_pack: 完整的 hint 包信息
            - candidates: 所有候选的详细评分分解
            - decision_trace: 决策路径
            - timing: 各阶段耗时
            - score_breakdown: 每个候选的评分组成
    """

@dataclass
class CandidateScoreBreakdown:
    """候选评分分解"""
    tmdb_id: int
    base_score: float           # 原始相似度
    coverage: float             # 覆盖率
    year_adjustment: float      # 年份调整 (+0.03 / -0.02 / -0.05)
    episode_adjustment: float   # 剧集一致性调整
    support_adjustment: float   # 多 hint 共识调整
    alias_adjustment: float     # 别名匹配调整
    fused_score: float          # 最终融合分数
    gates_passed: List[str]     # 通过的门控
    gates_blocked: List[str]    # 被阻止的门控
```

**调试模式启用**:
```python
# 通过参数启用
async def resolve_share_to_tmdb(
    ...,
    debug_mode: bool = False  # 新增参数
) -> Dict[str, Any]:
    if debug_mode:
        return _build_debug_response(...)
```

### 11. Anime Handler (`hints.py` + `tmdb_lookup.py`)

**职责**: 处理动漫标题的特殊匹配逻辑

**新增函数**:
```python
def _detect_anime_evidence(
    video_samples: List[str],
    hints: List[str]
) -> Tuple[bool, List[str]]:
    """
    检测是否为动漫内容
    Returns:
        is_anime: bool
        subgroup_tags: List[str]  # 检测到的字幕组标签，如 ["Sakurato", "ANi"]
    """

def _normalize_anime_title(title: str) -> str:
    """
    规范化动漫标题
    - 移除字幕组标签 [SubGroup]
    - 规范化季度后缀 (第X季 -> Season X)
    - 处理日文假名
    """

def _extract_anime_season_from_title(title: str) -> Optional[int]:
    """
    从动漫标题中提取季度
    支持: 第2季, Season 2, S2, 2nd Season, シーズン2
    """

def _is_japanese_text(text: str) -> bool:
    """检测是否包含日文假名（平假名/片假名）"""
    return bool(re.search(r'[\u3040-\u309f\u30a0-\u30ff]', text))

# 常见字幕组标签
ANIME_SUBGROUP_PATTERNS = [
    r'\[([A-Za-z0-9_-]+)\]',  # [SubGroup]
    r'【([^】]+)】',           # 【字幕组】
]

# 动漫季度后缀模式
ANIME_SEASON_PATTERNS = [
    r'第(\d+)季',
    r'Season\s*(\d+)',
    r'S(\d+)',
    r'(\d+)(?:st|nd|rd|th)\s*Season',
    r'シーズン(\d+)',
]
```

**动漫检测流程**:
```
1. 检查文件名是否匹配 ANIME_SUBGROUP_PATTERNS
2. 检查是否包含日文假名
3. 检查 TMDB 候选的 genre_ids 是否包含 16 (Animation)
4. 如果是动漫:
   a. 获取所有 alternative_titles（包括日文罗马音）
   b. 规范化标题进行匹配
   c. 对 Animation 类型候选给予 +0.03 bonus
```

### 12. Sequel/Prequel Detector (`scoring.py`)

**职责**: 检测和处理续集/前传标题

**新增函数**:
```python
def _detect_sequel_markers(title: str) -> Tuple[bool, Optional[int], str]:
    """
    检测续集标记
    Returns:
        has_sequel: bool
        sequel_number: Optional[int]  # 1, 2, 3, ...
        marker_type: str  # 'numeric', 'roman', 'cjk', 'none'
    """

def _normalize_sequel_number(marker: str) -> Optional[int]:
    """
    规范化续集编号
    'II' -> 2, '第二部' -> 2, 'Part 2' -> 2
    """

def _sequel_match_penalty(
    query_sequel: Optional[int],
    candidate_sequel: Optional[int]
) -> float:
    """
    计算续集不匹配惩罚
    - 查询有续集标记但候选没有: -0.10
    - 查询没有续集标记但候选有: -0.10
    - 续集编号不同: -0.15
    - 完全匹配: 0.0
    """

# 续集标记模式
SEQUEL_PATTERNS = {
    'numeric': [r'\b(\d+)\b$', r'(\d+)$'],  # 末尾数字
    'roman': [r'\b(II|III|IV|V|VI|VII|VIII|IX|X)\b'],
    'cjk': [r'第([一二三四五六七八九十]+)部', r'第(\d+)部', r'续集', r'前传'],
    'english': [r'Part\s*(\d+)', r'Chapter\s*(\d+)', r'Volume\s*(\d+)'],
}

ROMAN_TO_INT = {'I': 1, 'II': 2, 'III': 3, 'IV': 4, 'V': 5, 'VI': 6, 'VII': 7, 'VIII': 8, 'IX': 9, 'X': 10}
CJK_TO_INT = {'一': 1, '二': 2, '三': 3, '四': 4, '五': 5, '六': 6, '七': 7, '八': 8, '九': 9, '十': 10}
```

### 13. Fast Hint Evaluator (`hints.py`)

**职责**: 快速评估提示质量，避免无效 API 调用

**现有函数增强**:
```python
def _fast_hint_strong(best: Dict[str, Any]) -> bool:
    """
    评估快速模式下的提示强度
    
    强提示条件:
    - 非 fallback 模式（找到根视频）
    - 或: CJK 标题 >= 4 字符 且 无技术标签
    
    弱提示条件:
    - fallback 模式 且 标题过短
    - 或: 标题仅包含技术标签
    """

def _contains_only_technical_tags(title: str) -> bool:
    """
    检测标题是否仅包含技术标签
    技术标签: 1080p, 2160p, x264, x265, HEVC, BDMV, REMUX, etc.
    """

# 技术标签正则
TECHNICAL_TAG_PATTERN = re.compile(
    r'\b(1080p|2160p|720p|4k|8k|x264|x265|h\.?264|h\.?265|hevc|avc|'
    r'webrip|bluray|bdrip|hdr|dv|dolby|dts|truehd|atmos|'
    r'remux|bdmv|stream|playlist)\b',
    re.IGNORECASE
)
```

### 14. Quality Deduplicator (`batch_group.py`)

**职责**: 处理同一集的多个版本，选择最佳质量

**现有函数说明**:
```python
@dataclass
class EpisodeFile:
    name: str
    size: int  # 文件大小（字节）

def dedup_by_episode(
    files: List[EpisodeFile],
    season_hint: Optional[int] = None
) -> Tuple[Dict[int, EpisodeFile], List[EpisodeFile]]:
    """
    按集号去重，保留最大文件
    
    Returns:
        best_map: Dict[episode_number, best_file]
        duplicates: List[EpisodeFile]  # 被去重的文件
    """

def standard_se_rate(filenames: List[str]) -> float:
    """
    计算 SxxEyy 标准化率
    返回符合标准命名的文件比例 (0.0 - 1.0)
    """
```

**去重逻辑**:
```
1. 解析每个文件的集号 (SxxEyy 或 第X集)
2. 按集号分组
3. 每组选择文件大小最大的作为 best
4. 其余文件标记为 duplicates
5. 返回 episode_best_files 和 episode_dup_count
```



## Data Models

### Evidence Level Enum

```python
class EvidenceLevel(IntEnum):
    L0_UNAVAILABLE = 0   # 115 暂时不可用，无可靠证据
    L1_TITLE_ONLY = 1    # 仅有标题/文件夹名，无实际视频文件名
    L2_VIDEO_SAMPLE = 2  # 至少 1 个真实视频文件名样本
    L3_MULTI_SAMPLES = 3 # 多个视频样本或可靠的多文件计数
```

### Hint Source Enum

```python
class HintSource(str, Enum):
    MAIN = "main"    # 主要提示（视频文件名、季度文件夹）
    MSG = "msg"      # 消息提示（用户输入、URL fragment）
    EXTRA = "extra"  # 额外提示（低优先级样本）
```

### Candidate Model

```python
@dataclass
class Candidate:
    tmdb_id: int
    media_type: str  # 'movie' | 'tv'
    title: str
    year: Optional[int] = None
    rating: Optional[float] = None
    vote_count: Optional[int] = None
    score: Optional[float] = None
    coverage: Optional[float] = None
    extra: Optional[Dict[str, Any]] = None
    
    # Support metrics
    _support_count: int = 0
    _support_weight: int = 0
    _support_main: int = 0
    _support_msg: int = 0
    _top1_support_count: int = 0
    _top1_support_weight: int = 0
    _top1_support_main: int = 0
    
    # Scoring components
    _fused_score: Optional[float] = None
    _episode_score: Optional[float] = None
    _year_score: Optional[float] = None
    _total_score: Optional[float] = None
```

### Auto-Pick Context

```python
@dataclass
class AutoPickContext:
    selected_hints_count: int
    has_main_hint: bool
    require_consensus: bool
    force_media_type: Optional[str]
    query_title: str
    query_year: Optional[int]
    standard_rate: float
    episode_count: int
    episode_best_count: int
    episode_dup_count: int
    count_mismatch: bool
    evidence_level: int
    strict_year: Optional[int]
```

### Decision Trace

```python
@dataclass
class DecisionTrace:
    stages: List[str]  # e.g., ["start", "pre:title_cache", "stageA_stable", "auto_pick"]
    gates_blocked: List[str]  # e.g., ["collision_risky", "year_mismatch"]
    score_adjustments: List[Dict[str, Any]]  # before/after values
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Evidence Level Gating

*For any* share resolution request where evidence_level <= L1, the system SHALL NOT auto-pick regardless of candidate scores.

**Validates: Requirements 3.5, 10.3**

### Property 2: Collision Risk Protection

*For any* query_title with <= 2 tokens containing collision-prone words, the system SHALL require score >= 0.95 AND coverage >= 0.92 for auto-pick.

**Validates: Requirements 9.1, 9.4**

### Property 3: Year Affinity Consistency

*For any* candidate with year information, applying year affinity adjustments SHALL be idempotent (applying twice produces same result as applying once).

**Validates: Requirements 5.1, 5.2, 5.3, 5.4**

### Property 4: Strict Year Penalty

*For any* CJK title with explicit year pattern like "剧名(2025)", candidates with year != strict_year SHALL receive a penalty (not bonus) even for year-off-by-1.

**Validates: Requirements 16.2, 16.3**

### Property 5: Stage-B Bilingual Guarantee

*For any* hint set containing both CJK and Latin characters, Stage-B SHALL always run regardless of Stage-A results.

**Validates: Requirements 4.2, 12.1**

### Property 6: Hint Deduplication

*For any* set of Stage-B hints, after deduplication by normalized (title, year, season), no two hints SHALL produce the same TMDB query.

**Validates: Requirements 4.5, 13.1**

### Property 7: Episode Score Bounds

*For any* TV candidate with episode_score computed, the value SHALL be in range [0.0, 1.0].

**Validates: Requirements 6.2, 6.3**

### Property 8: Support Weight Calculation

*For any* candidate, _support_weight SHALL equal sum of (2 for each main hint + 1 for each msg hint) that support it.

**Validates: Requirements 7.4**

### Property 9: Cache Validation Threshold

*For any* cached mapping validation, if score < 0.72, the mapping SHALL be disabled (not returned as valid).

**Validates: Requirements 8.3**

### Property 10: Count Mismatch Downgrade

*For any* evidence with count_mismatch=True, evidence_level SHALL be downgraded by 1 (but not below L1).

**Validates: Requirements 15.2**

### Property 11: Multi-Season Preference

*For any* evidence containing multiple season markers (e.g., S01-S03), the system SHALL prefer the lowest season number.

**Validates: Requirements 11.1**

### Property 12: Media Type Guard

*For any* resolution with force_mt="tv", auto-pick SHALL NOT select a movie candidate.

**Validates: Requirements 3.5 (implicit), 8.5**

### Property 13: Single Candidate Strength

*For any* auto-pick with only one candidate, auto_strength SHALL be "weak" unless score >= 0.88 AND coverage >= 0.75.

**Validates: Requirements 3.4**

### Property 14: Fused Score Monotonicity

*For any* candidate, _fused_score SHALL be >= base score after applying all bonuses (support, episode, year).

**Validates: Requirements 7.5**

### Property 15: API Call Limit

*For any* episode consistency enrichment, API calls SHALL be limited to top 8 candidates.

**Validates: Requirements 6.5, 13.3**

### Property 16: Video Sample Priority

*For any* share with generic share_title (matching GENERIC_SHARE_TITLE_PATTERNS) AND specific video_samples, at least one video_sample SHALL appear in hints_main.

**Validates: Requirements 1.1, 1.2**

### Property 17: Batch Title Extraction

*For any* set of video_samples sharing a common title pattern, _extract_batch_title() SHALL return a non-empty string that is a substring of each sample's parsed title.

**Validates: Requirements 1.3**

### Property 18: Mixed Content Blocking

*For any* share containing both movie and TV content (detected by _detect_mixed_content()), auto_pick SHALL return False.

**Validates: Requirements 11.2**

### Property 19: Part Movie Blocking

*For any* filename containing Part markers (Part 1, Part 2, 第1部, etc.), auto_pick SHALL return False and require manual confirmation.

**Validates: Requirements 11.4**

### Property 20: Alias Similarity Monotonicity

*For any* candidate, _compute_alias_similarity() with alternative_titles SHALL return a value >= the similarity without alternative_titles.

**Validates: Requirements 12.2**

### Property 21: CJK Share Title Weight

*For any* share where share_title is CJK AND filename is Latin, the effective weight of share_title in hint selection SHALL be >= 1.5x the weight of filename.

**Validates: Requirements 12.5**

### Property 22: Debug Mode Completeness

*For any* resolve request with debug_mode=True, the response SHALL contain hint_pack, candidates with score_breakdown, decision_trace, and timing information.

**Validates: Requirements 14.5**

### Property 23: Anime Detection Accuracy

*For any* video filename matching ANIME_SUBGROUP_PATTERNS or containing Japanese kana, _detect_anime_evidence() SHALL return is_anime=True.

**Validates: Requirements 17.1, 17.4**

### Property 24: Sequel Marker Consistency

*For any* query_title with sequel markers (2, II, 第二部, etc.), if candidate_title lacks sequel markers, the system SHALL apply a penalty of -0.10.

**Validates: Requirements 18.1, 18.2**

### Property 25: Sequel Number Mismatch Penalty

*For any* query with sequel_number != candidate sequel_number (e.g., query="复仇者联盟2" vs candidate="复仇者联盟3"), the system SHALL apply a penalty of -0.15.

**Validates: Requirements 18.4**

### Property 26: Fast Hint Strength Detection

*For any* share evidence with fallback=True AND title containing only technical tags, _fast_hint_strong() SHALL return False.

**Validates: Requirements 19.2, 19.4**

### Property 27: Episode Deduplication Correctness

*For any* set of video files with duplicate episode numbers, dedup_by_episode() SHALL return exactly one file per episode (the largest by size).

**Validates: Requirements 20.1, 20.2**

### Property 28: Episode Best Files Coverage

*For any* episode_best_files and episode_set, if len(episode_best_files) >= 0.75 * len(episode_set), the system SHALL NOT reduce confidence due to duplicates.

**Validates: Requirements 20.4**

## Error Handling

### TMDB API Errors

```python
class TMDBAPIError(Exception):
    """Base class for TMDB API errors"""
    pass

class TMDBTimeoutError(TMDBAPIError):
    """TMDB API timeout"""
    retryable = True
    max_retries = 2
    backoff_base = 1.0  # seconds

class TMDBRateLimitError(TMDBAPIError):
    """TMDB API rate limit exceeded"""
    retryable = True
    max_retries = 3
    backoff_base = 2.0

class TMDBUnavailableError(TMDBAPIError):
    """TMDB API temporarily unavailable (5xx)"""
    retryable = True
    max_retries = 2
    backoff_base = 1.5
```

### 115 API Errors

```python
class Share115Error(Exception):
    """Base class for 115 share errors"""
    pass

class Share115TempUnavailable(Share115Error):
    """115 API temporarily unavailable"""
    reason_code = "share115_temp_unavailable"

class Share115PasswordRequired(Share115Error):
    """Share requires password"""
    reason_code = "share115_password_required"

class Share115Expired(Share115Error):
    """Share has expired"""
    reason_code = "share115_expired"

class Share115PagingMismatch(Share115Error):
    """Paging count mismatch detected"""
    reason_code = "share115_paging_mismatch"
```

### Retry Strategy

```python
async def with_retry(
    func: Callable,
    max_retries: int = 2,
    backoff_base: float = 1.0,
    retryable_exceptions: Tuple[Type[Exception], ...] = (TMDBTimeoutError, TMDBUnavailableError)
) -> Any:
    """
    Exponential backoff retry wrapper.
    
    Backoff formula: backoff_base * (2 ** attempt)
    - Attempt 0: immediate
    - Attempt 1: backoff_base seconds
    - Attempt 2: backoff_base * 2 seconds
    """
    for attempt in range(max_retries + 1):
        try:
            return await func()
        except retryable_exceptions as e:
            if attempt == max_retries:
                raise
            await asyncio.sleep(backoff_base * (2 ** attempt))
```

### Error Response Format

```python
def make_error_response(
    reason: str,
    share_code: Optional[str] = None,
    evidence_error: Optional[Dict] = None,
    decision_trace: Optional[List[str]] = None
) -> Dict[str, Any]:
    return {
        "ok": False,
        "reason": reason,
        "share_code": share_code,
        "evidence_error": evidence_error,
        "decision_trace": decision_trace or [],
    }
```

## Testing Strategy

### Unit Tests

单元测试覆盖核心纯函数：

1. **Hint Processing**
   - `_is_garbage_hint()` - 垃圾提示检测
   - `_title_quality_score()` - 标题质量评分
   - `_is_generic_share_title()` - 通用标题检测
   - `_extract_strict_year()` - 严格年份提取
   - `clean_hints()` - 提示清洗去重

2. **Scoring Functions**
   - `compute_collision_risk()` - 碰撞风险计算
   - `_apply_year_affinity()` - 年份亲和度调整
   - `_stage_a_stable()` - Stage-A 稳定性判断

3. **Decision Logic**
   - `should_auto_pick()` - 自动选择策略
   - Evidence level gating
   - Collision word detection

### Property-Based Tests

使用 `hypothesis` 库进行属性测试，每个测试至少运行 100 次迭代。

测试标注格式：**Feature: tmdb-recognition-optimization, Property N: property_text**

```python
# Example property test structure
from hypothesis import given, strategies as st, settings

@settings(max_examples=100)
@given(
    score=st.floats(min_value=0.0, max_value=1.0),
    coverage=st.floats(min_value=0.0, max_value=1.0),
    evidence_level=st.integers(min_value=0, max_value=3)
)
def test_evidence_level_gating(score, coverage, evidence_level):
    """
    Feature: tmdb-recognition-optimization, Property 1: Evidence Level Gating
    Validates: Requirements 3.5, 10.3
    """
    # ... test implementation
```

### Integration Tests

集成测试覆盖完整流水线：

1. **Cache Hit Scenarios**
   - Title cache hit with validation
   - Series cache hit with year check
   - Cache miss fallback to search

2. **Stage-A/Stage-B Scenarios**
   - Stage-A stable early-stop
   - Bilingual evidence forcing Stage-B
   - Year mismatch triggering Stage-B

3. **Auto-Pick Scenarios**
   - High confidence auto-pick
   - Collision risk blocking
   - Evidence level gating

### Test Data Generators

```python
# Hypothesis strategies for domain objects
hint_strategy = st.text(
    alphabet=st.characters(whitelist_categories=('L', 'N', 'P')),
    min_size=1,
    max_size=100
)

year_strategy = st.integers(min_value=1900, max_value=2030)

candidate_strategy = st.fixed_dictionaries({
    'tmdb_id': st.integers(min_value=1, max_value=999999),
    'media_type': st.sampled_from(['movie', 'tv']),
    'title': st.text(min_size=1, max_size=100),
    'year': st.one_of(st.none(), year_strategy),
    'score': st.floats(min_value=0.0, max_value=1.0),
    'coverage': st.floats(min_value=0.0, max_value=1.0),
})
```

## Implementation Notes

### Performance Considerations

1. **API Call Reduction**
   - Stage-B hint deduplication by normalized query key
   - Episode score enrichment limited to top 8 candidates
   - In-memory caching of TMDB detail responses per request

2. **Concurrency**
   - Semaphore(3) for episode score API calls
   - Semaphore(1) for Stage-B guesses (avoid rate limiting)

3. **Early Exit Points**
   - Cache hit fast path
   - Stage-A stable early-stop (when not bilingual)
   - Evidence level L0/L1 blocking auto-pick

### Logging Guidelines

```python
# Stage completion logging
biz.step("阶段名称", i=stage_num, total=total_stages, **metrics)

# Success logging
biz.ok("操作成功", **result_metrics)

# Warning logging
biz.warn("需要注意", **warning_metrics)

# Decision trace
decision_trace.append(f"gate:{gate_name}")
decision_trace.append(f"score_adj:{field}:{before}->{after}")
```

### Configuration Points

```python
# Thresholds (可配置)
TITLE_CACHE_MIN_CONFIDENCE = 0.82
TITLE_CACHE_MIN_COVERAGE = 0.60
SERIES_CACHE_MIN_CONFIDENCE = 0.80
SERIES_CACHE_MAX_YEAR_DIFF = 2

STAGE_A_STABLE_SCORE = 0.93
STAGE_A_STABLE_COVERAGE = 0.60
STAGE_A_EARLY_STOP_SCORE = 0.95
STAGE_A_EARLY_STOP_COVERAGE = 0.85
STAGE_A_EARLY_STOP_GAP = 0.15

COLLISION_RISK_MIN_SCORE = 0.95
COLLISION_RISK_MIN_COVERAGE = 0.92
SHORT_TITLE_MIN_SCORE = 0.93
SHORT_TITLE_MIN_COVERAGE = 0.90

EPISODE_SCORE_TOP_K = 8
EPISODE_SCORE_CONCURRENCY = 3

YEAR_EXACT_BONUS = 0.03
YEAR_OFF_BY_1_BONUS = 0.015
YEAR_OFF_BY_1_STRICT_PENALTY = -0.02
YEAR_OFF_BY_2_PENALTY = -0.02
YEAR_OFF_BY_3_PENALTY = -0.05
YEAR_MISSING_PENALTY = -0.02

# Video Sample Priority (Requirement 1)
VIDEO_SAMPLE_PRIORITY_ENABLED = True
CJK_SHARE_TITLE_WEIGHT_BOOST = 1.5

# Multi-Season/Part Detection (Requirement 11)
MULTI_SEASON_PREFER_LOWEST = True
PART_MOVIE_BLOCK_AUTO_PICK = True
MIXED_CONTENT_BLOCK_AUTO_PICK = True

# Alias Matching (Requirement 12)
ALIAS_FETCH_TOP_K = 5
ALIAS_SIMILARITY_BOOST_THRESHOLD = 0.1

# Debug Mode (Requirement 14)
DEBUG_MODE_INCLUDE_TIMING = True
DEBUG_MODE_INCLUDE_ALL_CANDIDATES = True

# Anime Detection (Requirement 17)
ANIME_GENRE_ID = 16  # TMDB Animation genre
ANIME_CONFIDENCE_BOOST = 0.03
ANIME_BILINGUAL_FORCE_STAGE_B = True

# Sequel Detection (Requirement 18)
SEQUEL_MISSING_PENALTY = -0.10
SEQUEL_MISMATCH_PENALTY = -0.15

# Fast Hint Evaluation (Requirement 19)
FAST_HINT_MIN_CJK_LENGTH = 4
FAST_HINT_REQUIRE_NO_TECH_TAGS = True

# Quality Deduplication (Requirement 20)
DEDUP_PREFER_LARGER_SIZE = True
DEDUP_COVERAGE_THRESHOLD = 0.75
```

## Sequence Diagrams

### Main Resolution Flow

```mermaid
sequenceDiagram
    participant Client
    participant UseCase as resolve_share_to_tmdb
    participant Evidence as fetch_share_evidence
    participant Hints as build_hint_pack
    participant PreResolve as pre_resolve_from_names_and_caches
    participant CandGen as build_candidate_sets
    participant Decision as decide_best_candidate
    participant Persist as save_mapping

    Client->>UseCase: resolve(share_url, hint_text, ...)
    UseCase->>Evidence: fetch_share_evidence(share_url)
    Evidence-->>UseCase: {ok, best, file_sig, evidence_weak}
    
    UseCase->>Hints: build_hint_pack(best, ...)
    Note over Hints: _prioritize_video_samples()<br/>_detect_multi_season_markers()
    Hints-->>UseCase: {hints_main, hints_msg, hints_extra, q_title, q_year, evidence_level}
    
    UseCase->>PreResolve: pre_resolve_from_names_and_caches(...)
    alt Cache Hit
        PreResolve-->>UseCase: {picked, from_source}
        UseCase->>Persist: save_mapping(picked)
        UseCase-->>Client: {ok: true, picked}
    else Cache Miss
        PreResolve-->>UseCase: {picked: null, cached_fp_tid, seed_candidates}
    end
    
    UseCase->>CandGen: build_candidate_sets(hints, ...)
    Note over CandGen: Stage-A (full)<br/>_stage_a_stable() check<br/>Stage-B (light) if needed<br/>_fetch_alternative_titles()
    CandGen-->>UseCase: {cands_all, cands_show, selected_hints}
    
    UseCase->>Decision: decide_best_candidate(cands_all, ...)
    Note over Decision: _detect_mixed_content()<br/>_detect_part_markers()<br/>should_auto_pick()
    Decision-->>UseCase: {ok_pick, picked, auto_strength, gated}
    
    alt Auto Pick Success
        UseCase->>Persist: save_mapping(picked)
        UseCase-->>Client: {ok: true, picked, auto_strength}
    else Manual Selection Required
        UseCase-->>Client: {ok: false, reason, cands_show}
    end
```

### Video Sample Priority Flow

```mermaid
flowchart TD
    A[Start: build_hint_pack] --> B{share_title matches<br/>GENERIC_PATTERNS?}
    B -->|No| C[Use share_title in hints_main]
    B -->|Yes| D{video_samples<br/>available?}
    D -->|No| E[Use share_title anyway<br/>with low confidence]
    D -->|Yes| F[_is_specific_video_sample<br/>for each sample]
    F --> G{Found specific<br/>samples?}
    G -->|No| E
    G -->|Yes| H[_extract_batch_title]
    H --> I{batch_title<br/>extracted?}
    I -->|Yes| J[Add batch_title to hints_main[0]]
    I -->|No| K[Add best video_sample to hints_main]
    J --> L[Add best video_sample to hints_main]
    K --> L
    L --> M[Demote share_title to hints_extra]
    C --> N[Continue to Stage-A]
    E --> N
    M --> N
```

### Auto-Pick Decision Flow

```mermaid
flowchart TD
    A[Start: should_auto_pick] --> B{evidence_level <= L1?}
    B -->|Yes| Z[Return False<br/>gate:evidence_level]
    B -->|No| C{is_mixed_content?}
    C -->|Yes| Z1[Return False<br/>gate:mixed_content]
    C -->|No| D{has_part_marker?}
    D -->|Yes| Z2[Return False<br/>gate:part_movie]
    D -->|No| E{collision_risky?}
    E -->|Yes| F{score >= 0.95 AND<br/>coverage >= 0.92?}
    F -->|No| G{support_count >= 2?}
    G -->|No| Z3[Return False<br/>gate:collision_risky]
    G -->|Yes| H[Continue with relaxed threshold]
    F -->|Yes| H
    E -->|No| H
    H --> I{Check auto-pick conditions}
    I -->|L3 + high score| J[Return True<br/>strength: strong]
    I -->|episode_score high| K[Return True<br/>strength: strong]
    I -->|support consensus| L[Return True<br/>strength: weak]
    I -->|single candidate| M{score >= 0.88?}
    M -->|Yes| N[Return True<br/>strength: strong]
    M -->|No| O[Return True<br/>strength: weak]
    I -->|None matched| Z4[Return False<br/>gate:threshold]
```
