# Implementation Plan: URL Constants Centralization

## Overview

创建 `settings/urls.py` 模块集中管理外部服务 URL，然后迁移现有硬编码 URL。

## Tasks

- [x] 1. 创建 URL 常量模块
  - [x] 1.1 创建 `settings/urls.py`
    - 实现 `URLCategory` 枚举
    - 定义 `_URL_DEFAULTS` 字典
    - 实现 `get_url()` 函数（支持环境变量覆盖）
    - 实现所有辅助函数
    - _Requirements: 1.1, 1.2, 2.1-2.7, 3.1-3.7, 4.1-4.4, 6.1-6.3_

- [x] 2. 编写属性测试
  - [x] 2.1 创建 `tests/test_url_properties.py`
    - **Property 1: Telegram API URL 格式正确性**
    - **Validates: Requirements 3.1**
  - [x] 2.2 编写 Property 2-3: TMDB URL 格式正确性
    - **Property 2: TMDB API URL 格式正确性**
    - **Property 3: TMDB Image URL 格式正确性**
    - **Validates: Requirements 3.2, 3.3**
  - [x] 2.3 编写 Property 4-5: Detail URL 格式正确性
    - **Property 4: TMDB Detail URL 格式正确性**
    - **Property 5: IMDB URL 格式正确性**
    - **Validates: Requirements 3.4, 3.5**
  - [x] 2.4 编写 Property 6-7: Search/Share URL 格式正确性
    - **Property 6: Douban Search URL 格式正确性**
    - **Property 7: 115 Share URL 格式正确性**
    - **Validates: Requirements 3.6, 3.7**
  - _Requirements: 3.1-3.7_

- [x] 3. 迁移 Telegram API URL
  - 更新 `integrations/telegram_client.py`
  - 更新 `tg_bot/infra/telegram_api.py`
  - 更新 `notifier/telegram/telegram_notifier.py`
  - _Requirements: 5.1_

- [x] 4. 迁移 TMDB URL
  - 更新 `integrations/tmdb_gateway.py`
  - 更新 `integrations/tmdb_match/search.py`
  - 更新 `integrations/tmdb_match/aliases.py`
  - 更新 `notifier/metadata/tmdb_client.py`
  - 更新 `notifier/templates/zh_cn_common.py`
  - 更新 `notifier/service/pipeline_content.py`
  - 更新 `tg_bot/features/share/share_format.py`
  - _Requirements: 5.2_

- [x] 5. 迁移 115 云 URL
  - 更新 `integrations/cloud115/qrcode.py`
  - 更新 `integrations/cloud115/client.py`
  - 更新 `integrations/share115/share115_client.py`
  - 更新 `tg_bot/common/parser.py`
  - 更新 `tg_bot/common/parser_share.py`
  - 更新 `tg_bot/storage/tables/pending_choice.py`
  - 更新 `tg_bot/app/handlers_share.py`
  - _Requirements: 5.3_

- [x] 6. 迁移 Douban/IMDB URL
  - 更新 `notifier/utils.py`
  - 更新 `notifier/templates/zh_cn_common.py`
  - _Requirements: 5.4_

- [x] 7. 验证和测试
  - 运行属性测试
  - 运行现有测试套件
  - 验证所有迁移的 URL 功能正常
  - _Requirements: 5.5_

## Notes

- 所有任务都是必需的
- 迁移时保持向后兼容性
- 帮助文本中的示例 URL 不需要迁移（如 `/bind` 命令的用法说明）
- 测试文件中的示例 URL 不需要迁移
