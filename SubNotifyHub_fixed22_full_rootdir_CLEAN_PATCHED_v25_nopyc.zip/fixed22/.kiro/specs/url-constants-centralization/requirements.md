# Requirements Document

## Introduction

集中管理项目中所有外部服务 URL 常量，创建 `settings/urls.py` 模块，统一管理 API 基础 URL、服务端点等配置，提高代码可维护性和配置灵活性。

## Glossary

- **URL_Registry**: URL 注册表，集中存储所有外部服务 URL 常量的模块
- **Service_URL**: 外部服务的基础 URL 或 API 端点
- **URL_Category**: URL 分类枚举，按服务类型组织 URL

## Requirements

### Requirement 1: URL 分类管理

**User Story:** As a developer, I want URLs organized by service category, so that I can easily find and manage related URLs.

#### Acceptance Criteria

1. THE URL_Registry SHALL define URL categories using an enumeration type
2. THE URL_Registry SHALL support the following categories: TELEGRAM, TMDB, CLOUD115, DOUBAN, IMDB
3. WHEN a new service is added, THE URL_Registry SHALL allow extending categories without modifying existing code

### Requirement 2: URL 常量定义

**User Story:** As a developer, I want all external service URLs defined in one place, so that I can avoid hardcoding URLs throughout the codebase.

#### Acceptance Criteria

1. THE URL_Registry SHALL define base URLs for Telegram API (`https://api.telegram.org`)
2. THE URL_Registry SHALL define base URLs for TMDB API (`https://api.themoviedb.org/3`)
3. THE URL_Registry SHALL define base URLs for TMDB image service (`https://image.tmdb.org/t/p`)
4. THE URL_Registry SHALL define base URLs for 115 cloud services (webapi, qrcodeapi, passportapi, lixian)
5. THE URL_Registry SHALL define base URLs for Douban search (`https://www.douban.com/search`)
6. THE URL_Registry SHALL define base URLs for IMDB (`https://www.imdb.com`)
7. THE URL_Registry SHALL define base URLs for TMDB website (`https://www.themoviedb.org`)

### Requirement 3: URL 构建辅助函数

**User Story:** As a developer, I want helper functions to build complete URLs, so that I can construct URLs consistently.

#### Acceptance Criteria

1. THE URL_Registry SHALL provide `get_telegram_api_url(token, method)` function to build Telegram API URLs
2. THE URL_Registry SHALL provide `get_tmdb_api_url(path)` function to build TMDB API URLs
3. THE URL_Registry SHALL provide `get_tmdb_image_url(path, size)` function to build TMDB image URLs
4. THE URL_Registry SHALL provide `get_tmdb_detail_url(media_type, tmdb_id)` function to build TMDB detail page URLs
5. THE URL_Registry SHALL provide `get_imdb_url(imdb_id)` function to build IMDB URLs
6. THE URL_Registry SHALL provide `get_douban_search_url(query)` function to build Douban search URLs
7. THE URL_Registry SHALL provide `get_115_share_url(share_code, password)` function to build 115 share URLs

### Requirement 4: 环境变量覆盖

**User Story:** As a system administrator, I want to override URLs via environment variables, so that I can configure different environments without code changes.

#### Acceptance Criteria

1. THE URL_Registry SHALL support environment variable overrides with format `URL_{CATEGORY}_{NAME}`
2. WHEN an environment variable is set, THE URL_Registry SHALL use the environment value instead of the default
3. THE URL_Registry SHALL validate URL format before accepting environment overrides
4. IF an invalid URL is provided via environment variable, THEN THE URL_Registry SHALL log a warning and use the default value

### Requirement 5: 代码迁移

**User Story:** As a developer, I want existing hardcoded URLs replaced with centralized constants, so that the codebase is consistent.

#### Acceptance Criteria

1. THE codebase SHALL replace all hardcoded Telegram API URLs with URL_Registry functions
2. THE codebase SHALL replace all hardcoded TMDB API URLs with URL_Registry functions
3. THE codebase SHALL replace all hardcoded 115 cloud URLs with URL_Registry functions
4. THE codebase SHALL replace all hardcoded Douban/IMDB URLs with URL_Registry functions
5. WHEN migrating URLs, THE codebase SHALL maintain backward compatibility with existing functionality

### Requirement 6: 文档和类型安全

**User Story:** As a developer, I want clear documentation and type hints, so that I can use the URL registry correctly.

#### Acceptance Criteria

1. THE URL_Registry SHALL include docstrings for all public functions and classes
2. THE URL_Registry SHALL use type hints for all function parameters and return values
3. THE URL_Registry SHALL export all public symbols via `__all__`
