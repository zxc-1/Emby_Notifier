# Design Document: URL Constants Centralization

## Overview

创建 `settings/urls.py` 模块，集中管理项目中所有外部服务 URL 常量。该模块遵循项目现有的 `settings/timeouts.py` 和 `settings/retries.py` 的设计模式，提供枚举分类、默认值、环境变量覆盖和辅助函数。

## Architecture

```
settings/
├── urls.py          # 新增：URL 常量和辅助函数
├── timeouts.py      # 现有：超时配置
├── retries.py       # 现有：重试配置
└── ...
```

### 设计原则

1. **一致性**: 遵循 `timeouts.py` 和 `retries.py` 的设计模式
2. **可配置性**: 支持环境变量覆盖
3. **类型安全**: 完整的类型提示
4. **向后兼容**: 迁移不影响现有功能

## Components and Interfaces

### URLCategory 枚举

```python
class URLCategory(str, Enum):
    """URL 分类枚举。"""
    
    # Telegram
    TELEGRAM_API = "telegram_api"
    
    # TMDB
    TMDB_API = "tmdb_api"
    TMDB_IMAGE = "tmdb_image"
    TMDB_WEB = "tmdb_web"
    
    # 115 Cloud
    CLOUD115_WEBAPI = "cloud115_webapi"
    CLOUD115_QRCODE = "cloud115_qrcode"
    CLOUD115_PASSPORT = "cloud115_passport"
    CLOUD115_LIXIAN = "cloud115_lixian"
    CLOUD115_SHARE = "cloud115_share"
    
    # Other services
    DOUBAN_SEARCH = "douban_search"
    IMDB_TITLE = "imdb_title"
```

### URL 默认值

```python
_URL_DEFAULTS: dict[URLCategory, str] = {
    URLCategory.TELEGRAM_API: "https://api.telegram.org",
    URLCategory.TMDB_API: "https://api.themoviedb.org/3",
    URLCategory.TMDB_IMAGE: "https://image.tmdb.org/t/p",
    URLCategory.TMDB_WEB: "https://www.themoviedb.org",
    URLCategory.CLOUD115_WEBAPI: "https://webapi.115.com",
    URLCategory.CLOUD115_QRCODE: "https://qrcodeapi.115.com",
    URLCategory.CLOUD115_PASSPORT: "https://passportapi.115.com",
    URLCategory.CLOUD115_LIXIAN: "https://lixian.115.com",
    URLCategory.CLOUD115_SHARE: "https://115.com/s",
    URLCategory.DOUBAN_SEARCH: "https://www.douban.com/search",
    URLCategory.IMDB_TITLE: "https://www.imdb.com/title",
}
```

### 核心函数

```python
def get_url(category: URLCategory) -> str:
    """获取指定分类的 URL。
    
    优先使用环境变量 URL_{CATEGORY} 的值，否则使用默认值。
    """

def get_telegram_api_url(token: str, method: str) -> str:
    """构建 Telegram API URL。
    
    Returns: https://api.telegram.org/bot{token}/{method}
    """

def get_tmdb_api_url(path: str) -> str:
    """构建 TMDB API URL。
    
    Returns: https://api.themoviedb.org/3{path}
    """

def get_tmdb_image_url(path: str, size: str = "w500") -> str:
    """构建 TMDB 图片 URL。
    
    Returns: https://image.tmdb.org/t/p/{size}{path}
    """

def get_tmdb_detail_url(media_type: str, tmdb_id: int) -> str:
    """构建 TMDB 详情页 URL。
    
    Returns: https://www.themoviedb.org/{movie|tv}/{tmdb_id}
    """

def get_imdb_url(imdb_id: str) -> str:
    """构建 IMDB URL。
    
    Returns: https://www.imdb.com/title/{imdb_id}
    """

def get_douban_search_url(query: str) -> str:
    """构建豆瓣搜索 URL。
    
    Returns: https://www.douban.com/search?q={url_encoded_query}
    """

def get_115_share_url(share_code: str, password: Optional[str] = None) -> str:
    """构建 115 分享链接。
    
    Returns: https://115.com/s/{share_code}?password={password}
    """
```

## Data Models

本模块不涉及复杂数据模型，主要使用：
- `URLCategory` 枚举
- 字符串常量字典 `_URL_DEFAULTS`

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Telegram API URL 格式正确性

*For any* valid token string and method string, `get_telegram_api_url(token, method)` should return a URL that:
- Starts with the Telegram API base URL
- Contains `/bot{token}/` in the path
- Ends with the method name

**Validates: Requirements 3.1**

### Property 2: TMDB API URL 格式正确性

*For any* valid path string, `get_tmdb_api_url(path)` should return a URL that:
- Starts with the TMDB API base URL
- Contains the provided path

**Validates: Requirements 3.2**

### Property 3: TMDB Image URL 格式正确性

*For any* valid image path and size, `get_tmdb_image_url(path, size)` should return a URL that:
- Starts with the TMDB image base URL
- Contains the size parameter
- Contains the image path

**Validates: Requirements 3.3**

### Property 4: TMDB Detail URL 格式正确性

*For any* media_type in ("movie", "tv") and any positive tmdb_id, `get_tmdb_detail_url(media_type, tmdb_id)` should return a URL that:
- Starts with the TMDB web base URL
- Contains the correct media type path segment
- Contains the tmdb_id

**Validates: Requirements 3.4**

### Property 5: IMDB URL 格式正确性

*For any* valid imdb_id string, `get_imdb_url(imdb_id)` should return a URL that:
- Starts with the IMDB title base URL
- Contains the imdb_id

**Validates: Requirements 3.5**

### Property 6: Douban Search URL 格式正确性

*For any* query string, `get_douban_search_url(query)` should return a URL that:
- Starts with the Douban search base URL
- Contains URL-encoded query parameter

**Validates: Requirements 3.6**

### Property 7: 115 Share URL 格式正确性

*For any* share_code and optional password, `get_115_share_url(share_code, password)` should return a URL that:
- Starts with the 115 share base URL
- Contains the share_code
- If password is provided, contains the password parameter

**Validates: Requirements 3.7**

## Error Handling

1. **无效环境变量**: 如果环境变量值不是有效 URL，记录警告并使用默认值
2. **空参数**: 辅助函数应处理空字符串参数，返回合理的默认行为
3. **URL 编码**: `get_douban_search_url` 应正确处理特殊字符的 URL 编码

## Testing Strategy

### 单元测试

- 验证所有 URL 常量定义正确
- 验证环境变量覆盖功能
- 验证辅助函数的边界情况

### 属性测试

使用 Hypothesis 库进行属性测试：

```python
from hypothesis import given, strategies as st

@given(st.text(min_size=1), st.text(min_size=1))
def test_telegram_api_url_format(token, method):
    """Property 1: Telegram API URL 格式正确性"""
    url = get_telegram_api_url(token, method)
    assert url.startswith(get_url(URLCategory.TELEGRAM_API))
    assert f"/bot{token}/" in url
    assert url.endswith(method)
```

### 集成测试

- 验证迁移后的代码功能不变
- 验证现有测试套件通过
