# Implementation Plan: Docker Multi-Stage Build

## Overview

实现 Docker 多阶段构建，优化镜像体积和安全性。

## Tasks

- [x] 1. 更新 .dockerignore 文件
  - 添加测试文件排除 (tests/, .pytest_cache/, .hypothesis/)
  - 添加文档排除 (docs/, *.md)
  - 添加开发文件排除 (.kiro/, .env, .vscode/)
  - 添加 Python 缓存排除 (__pycache__, *.pyc)
  - 添加 Git 文件排除 (.git, .gitignore)
  - _Requirements: 2.2, 2.3, 4.2_

- [x] 2. 重写 Dockerfile 为多阶段构建
  - [x] 2.1 创建 Builder 阶段
    - 使用 python:3.12-slim 基础镜像
    - 添加 ARG PYTHON_VERSION 支持
    - 安装 pip 依赖到独立目录
    - _Requirements: 1.1, 1.2, 6.1_
  - [x] 2.2 创建 Runtime 阶段
    - 使用 python:3.12-slim 基础镜像
    - 添加 ARG APP_PORT 支持
    - 从 Builder 复制依赖
    - 复制应用源代码
    - _Requirements: 1.3, 1.4, 2.1, 6.2_
  - [x] 2.3 添加安全配置
    - 创建非 root 用户 (appuser)
    - 设置文件所有权
    - 切换到非 root 用户运行
    - _Requirements: 4.1, 4.3, 4.4_
  - [x] 2.4 添加健康检查
    - 配置 HEALTHCHECK 指令
    - 设置 interval, timeout, retries 参数
    - _Requirements: 5.1, 5.2, 5.3_

- [x] 3. 优化构建缓存
  - 调整 COPY 指令顺序
  - 先复制 requirements.txt，再安装依赖
  - 最后复制源代码
  - _Requirements: 3.1, 3.2, 3.3, 3.4_

- [x] 4. 更新 docker-compose.yaml
  - 添加 build args 配置
  - 添加开发模式卷挂载
  - 更新健康检查配置
  - 验证端口映射
  - _Requirements: 7.1, 7.3, 7.4_

- [x] 5. 添加健康检查端点
  - 确认 /health 端点存在
  - 如不存在则添加简单健康检查路由
  - _Requirements: 5.2, 5.4_

- [x] 6. 验证构建
  - 构建新镜像
  - 比较镜像大小
  - 验证容器启动
  - 验证健康检查
  - _Requirements: 2.4, 7.2_

- [x] 7. 编写文档
  - 创建 docs/docker-build.md
  - 包含构建命令、参数说明、故障排除
  - _Requirements: 6.3, 6.4_

## Notes

- 所有任务都是必需的
- 构建验证需要 Docker 环境
- 健康检查依赖 curl 命令

