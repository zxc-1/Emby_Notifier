# Design Document: Docker Multi-Stage Build

## Overview

本设计实现 Docker 多阶段构建，将构建过程分为 Builder 和 Runtime 两个阶段。Builder 阶段安装所有依赖，Runtime 阶段仅包含运行所需的最小文件集，从而减小镜像体积、提高安全性。

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    Multi-Stage Build                        │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌─────────────────────┐    ┌─────────────────────────┐    │
│  │   Builder Stage     │    │    Runtime Stage        │    │
│  │                     │    │                         │    │
│  │  • python:3.12-slim │    │  • python:3.12-slim     │    │
│  │  • pip install      │───▶│  • COPY --from=builder  │    │
│  │  • build deps       │    │  • Non-root user        │    │
│  │  • site-packages    │    │  • HEALTHCHECK          │    │
│  │                     │    │  • Minimal footprint    │    │
│  └─────────────────────┘    └─────────────────────────┘    │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## Components and Interfaces

### 1. Dockerfile 结构

```dockerfile
# ============================================
# Stage 1: Builder
# ============================================
ARG PYTHON_VERSION=3.12
FROM python:${PYTHON_VERSION}-slim AS builder

WORKDIR /build

# 安装构建依赖
RUN apt-get update && apt-get install -y --no-install-recommends \
    build-essential \
    && rm -rf /var/lib/apt/lists/*

# 复制并安装 Python 依赖
COPY requirements/requirements.txt requirements.txt
RUN pip install --no-cache-dir --target=/build/deps -r requirements.txt

# ============================================
# Stage 2: Runtime
# ============================================
FROM python:${PYTHON_VERSION}-slim AS runtime

ARG APP_PORT=8000

# 创建非 root 用户
RUN groupadd --gid 1000 appgroup && \
    useradd --uid 1000 --gid appgroup --shell /bin/bash appuser

WORKDIR /app

# 安装运行时系统依赖
RUN apt-get update && apt-get install -y --no-install-recommends \
    ca-certificates \
    curl \
    && rm -rf /var/lib/apt/lists/*

# 从 builder 复制依赖
COPY --from=builder /build/deps /usr/local/lib/python3.12/site-packages

# 复制应用代码
COPY --chown=appuser:appgroup . .

# 切换到非 root 用户
USER appuser

# 暴露端口
EXPOSE ${APP_PORT}

# 健康检查
HEALTHCHECK --interval=30s --timeout=10s --start-period=5s --retries=3 \
    CMD curl -f http://localhost:${APP_PORT}/health || exit 1

# 启动命令
CMD ["uvicorn", "app:app", "--host", "0.0.0.0", "--port", "8000", "--workers", "1", "--no-access-log"]
```

### 2. .dockerignore 更新

```
# Git
.git
.gitignore

# Python
__pycache__
*.py[cod]
*$py.class
*.so
.Python
.hypothesis

# Virtual environments
venv/
.venv/
env/

# IDE
.idea/
.vscode/
*.swp
*.swo

# Testing
tests/
.pytest_cache/
htmlcov/
.coverage
coverage.xml

# Documentation
docs/
*.md
!README.md

# Development
.kiro/
.env
.env.*
*.log

# Build artifacts
dist/
build/
*.egg-info/

# Temporary files
tmp/
temp/
*.tmp
```

### 3. docker-compose.yaml 更新

```yaml
version: '3.8'

services:
  app:
    build:
      context: .
      dockerfile: Dockerfile
      args:
        PYTHON_VERSION: "3.12"
        APP_PORT: "8000"
    ports:
      - "8000:8000"
    environment:
      - TZ=Asia/Shanghai
    volumes:
      # 开发模式：挂载源代码
      - ./app.py:/app/app.py:ro
      - ./admin:/app/admin:ro
      - ./api:/app/api:ro
      - ./core:/app/core:ro
      - ./settings:/app/settings:ro
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 10s
    restart: unless-stopped
```

## Data Models

本设计不涉及数据模型变更。

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

由于 Docker 构建优化主要涉及配置文件的静态结构，大多数验收标准通过示例测试和集成测试验证，而非属性测试。

### 可测试的示例验证

以下验收标准可通过解析配置文件进行示例验证：

1. **Dockerfile 结构验证** (Requirements 1.1, 1.3, 2.1)
   - 验证包含 Builder 和 Runtime 两个阶段
   - 验证使用 COPY --from=builder 指令
   - 验证基础镜像为 python:3.12-slim

2. **安全配置验证** (Requirements 4.1, 4.2)
   - 验证包含 USER 指令切换非 root 用户
   - 验证 .dockerignore 排除敏感文件

3. **健康检查验证** (Requirements 5.1, 5.3)
   - 验证包含 HEALTHCHECK 指令
   - 验证健康检查参数配置

4. **构建参数验证** (Requirements 6.1, 6.2)
   - 验证包含 PYTHON_VERSION ARG
   - 验证包含 APP_PORT ARG

### 需要集成测试的验证

以下验收标准需要实际构建和运行测试：

- 镜像体积比较 (Requirement 2.4)
- 构建缓存行为 (Requirements 3.2, 3.4)
- 容器运行时行为 (Requirements 4.4, 5.2, 5.4)
- docker-compose 启动验证 (Requirement 7.2)

## Error Handling

### 构建失败处理

1. **依赖安装失败**
   - 检查 requirements.txt 语法
   - 验证网络连接
   - 检查 pip 源配置

2. **COPY 指令失败**
   - 验证源文件存在
   - 检查 .dockerignore 是否误排除

3. **健康检查失败**
   - 验证 /health 端点存在
   - 检查端口配置一致性
   - 调整 start_period 等待时间

## Testing Strategy

### 单元测试

由于本设计主要涉及配置文件，不需要传统单元测试。

### 集成测试

1. **构建测试**
   ```bash
   # 构建镜像
   docker build -t app:test .
   
   # 验证镜像大小
   docker images app:test --format "{{.Size}}"
   ```

2. **运行测试**
   ```bash
   # 启动容器
   docker run -d --name app-test -p 8000:8000 app:test
   
   # 等待启动
   sleep 5
   
   # 健康检查
   curl -f http://localhost:8000/health
   
   # 清理
   docker stop app-test && docker rm app-test
   ```

3. **docker-compose 测试**
   ```bash
   # 启动服务
   docker-compose up -d
   
   # 验证服务状态
   docker-compose ps
   
   # 健康检查
   curl -f http://localhost:8000/health
   
   # 清理
   docker-compose down
   ```

### 安全扫描

```bash
# 使用 trivy 扫描镜像漏洞
trivy image app:test

# 检查非 root 用户
docker run --rm app:test whoami
# 应输出: appuser
```

