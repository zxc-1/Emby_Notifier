# Implementation Plan: Hotlist Data Integration

## Overview

增强热榜订阅管理页面的前端功能，添加缓存、错误处理和用户体验优化。后端 API 已存在，主要工作在前端。

## Tasks

- [x] 1. 实现前端缓存模块
  - [x] 1.1 创建 HotlistCache 对象
    - 实现 get/set/isValid/invalidate/getStale 方法
    - 设置 2 分钟 TTL
    - _Requirements: 9.1, 9.2_

  - [x] 1.2 编写缓存 TTL 属性测试
    - **Property 5: Cache TTL Enforcement**
    - **Validates: Requirements 9.1, 9.3**

- [x] 2. 实现 HotlistAPI 模块
  - [x] 2.1 封装 API 调用方法
    - 实现 fetchList, addSubscription, deleteSubscription, patchSubscription, backfillNext
    - 统一错误处理
    - _Requirements: 8.1, 8.2, 8.3_

  - [x] 2.2 编写 API 响应格式属性测试
    - **Property 4: API Response Format Consistency**
    - **Validates: Requirements 8.1, 8.2, 8.3, 8.4**

- [x] 3. 增强数据加载逻辑
  - [x] 3.1 实现 stale-while-revalidate 模式
    - 优先显示缓存数据
    - 后台刷新最新数据
    - _Requirements: 9.2_

  - [x] 3.2 添加骨架屏加载状态
    - 在数据加载时显示骨架屏
    - _Requirements: 1.3_

  - [x] 3.3 实现错误状态和重试
    - 网络错误时显示缓存数据 + 错误提示
    - 添加重试按钮
    - _Requirements: 1.4, 10.3_

- [x] 4. 增强订阅列表渲染
  - [x] 4.1 优化订阅卡片渲染
    - 确保显示 title, chat_id, mode
    - 显示过滤规则标签
    - _Requirements: 1.2, 1.5_

  - [x] 4.2 编写订阅渲染属性测试
    - **Property 1: Subscription Rendering Completeness**
    - **Validates: Requirements 1.2, 1.5**

- [x] 5. 增强内置榜单渲染
  - [x] 5.1 优化内置榜单卡片
    - 根据订阅状态显示不同按钮
    - _Requirements: 2.2, 2.3_

  - [x] 5.2 编写内置榜单状态属性测试
    - **Property 2: Builtin Subscription Status Consistency**
    - **Validates: Requirements 2.2, 2.3**

- [x] 6. Checkpoint - 渲染功能完成
  - 确保订阅列表和内置榜单正确渲染
  - 测试缓存和错误处理

- [x] 7. 增强添加订阅功能
  - [x] 7.1 优化添加订阅模态框
    - 添加加载状态
    - 优化错误提示
    - _Requirements: 3.1, 3.2, 3.3, 3.4_

  - [x] 7.2 实现添加后缓存失效
    - 添加成功后清除缓存并刷新
    - _Requirements: 9.3_

- [x] 8. 增强编辑规则功能
  - [x] 8.1 优化规则编辑模态框
    - 确保正确填充现有值
    - 添加加载状态
    - _Requirements: 4.1, 4.2, 4.3_

  - [x] 8.2 编写过滤器填充属性测试
    - **Property 6: Filter Modal Population**
    - **Validates: Requirements 4.2**

  - [x] 8.3 实现保存后缓存失效
    - 保存成功后清除缓存并刷新
    - _Requirements: 4.4, 4.5, 9.3_

- [x] 9. 增强删除功能
  - [x] 9.1 优化删除确认和反馈
    - 添加加载状态
    - 删除成功后动画移除卡片
    - _Requirements: 5.1, 5.2, 5.3, 5.4_

- [x] 10. 增强刷新/回溯功能
  - [x] 10.1 优化刷新按钮状态
    - 添加加载指示器
    - 显示成功/失败提示
    - _Requirements: 6.1, 6.2, 6.3, 6.4_

- [x] 11. 增强统计信息
  - [x] 11.1 优化统计计算和显示
    - 确保计算准确
    - 数据变化时立即更新
    - _Requirements: 7.1, 7.2, 7.3, 7.4_

  - [x] 11.2 编写统计计算属性测试
    - **Property 3: Statistics Calculation Accuracy**
    - **Validates: Requirements 7.1, 7.2, 7.3**

- [x] 12. 添加 Toast 通知系统
  - [x] 12.1 实现 Toast 组件
    - 支持 success/error/info 类型
    - 自动消失
    - _Requirements: 10.2, 10.3_

- [x] 13. 添加缓存时间显示
  - [x] 13.1 显示"上次更新"时间
    - 在页面显示缓存数据时间
    - _Requirements: 9.4_

- [x] 14. Final Checkpoint
  - 确保所有功能正常工作
  - 验证缓存和错误处理

## Notes

- 所有任务都是必须完成的，包括属性测试
- 后端 API 已存在，无需修改
- 前端使用渐进式增强，保持向后兼容
- 属性测试使用 Hypothesis (Python)
