# Design Document: Hotlist Data Integration

## Overview

本设计文档描述热榜订阅管理页面（Hotlist）与后端 API 数据打通的技术方案。核心目标是增强现有页面的数据加载、缓存策略、错误处理和用户体验。

设计采用以下架构模式：
- **API 层**: 复用现有 `admin/routes_hotlist.py` 的 API 端点
- **前端层**: 增强 `static/js/hotlist.js`，添加缓存和错误处理
- **数据流**: 采用 stale-while-revalidate 模式，优先展示缓存数据

### 现有代码复用分析

| 功能 | 现有代码位置 | 复用方式 |
|------|-------------|---------|
| 订阅列表 API | `admin/routes_hotlist.py:admin_hotlist_json()` | ✅ 直接复用 |
| 添加订阅 API | `admin/routes_hotlist.py:admin_hotlist_add()` | ✅ 直接复用 |
| 删除订阅 API | `admin/routes_hotlist.py:admin_hotlist_delete()` | ✅ 直接复用 |
| 修改规则 API | `admin/routes_hotlist.py:admin_hotlist_patch()` | ✅ 直接复用 |
| 回溯 API | `admin/routes_hotlist.py:admin_hotlist_backfill_next()` | ✅ 直接复用 |
| 前端渲染 | `static/js/hotlist.js` | ✅ 增强，添加缓存和错误处理 |

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        Frontend (Browser)                        │
├─────────────────────────────────────────────────────────────────┤
│  hotlist.js                                                      │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │ HotlistAPI   │  │ HotlistCache │  │ HotlistUI    │          │
│  │ - fetchList  │  │ - get/set    │  │ - renderSubs │          │
│  │ - addSub     │  │ - isValid    │  │ - renderBuilt│          │
│  │ - deleteSub  │  │ - invalidate │  │ - showToast  │          │
│  │ - patchSub   │  │ - getStale   │  │ - showModal  │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼ HTTP/JSON
┌─────────────────────────────────────────────────────────────────┐
│                        Backend (FastAPI)                         │
├─────────────────────────────────────────────────────────────────┤
│  /admin/hotlist.json    → 获取订阅列表和内置榜单                  │
│  /admin/hotlist/add     → 添加订阅                               │
│  /admin/hotlist/delete  → 删除订阅                               │
│  /admin/hotlist/patch   → 修改订阅规则                           │
│  /admin/hotlist/backfill_next → 触发回溯                         │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                        Data Sources                              │
├─────────────────────────────────────────────────────────────────┤
│  douban_hotlist.store │ douban_hotlist.builtins │ Settings      │
└─────────────────────────────────────────────────────────────────┘
```

## Components and Interfaces

### 1. Backend API (已存在，无需修改)

#### 1.1 Hotlist List API (`/admin/hotlist.json`)

```python
@router.get("/admin/hotlist.json")
async def admin_hotlist_json(request: Request) -> Dict[str, Any]:
    """返回热榜管理数据"""
    return {
        "ok": True,
        "builtins": list[Dict],      # 内置榜单列表
        "subs": list[Dict],          # 用户订阅列表
        "snapshots": Dict[str, Any], # 榜单快照
        "ignore_counts": Dict[str, int], # 忽略计数
        "pref_chat_id": int          # 偏好 chat_id
    }
```

#### 1.2 Add Subscription API (`/admin/hotlist/add`)

```python
@router.post("/admin/hotlist/add")
async def admin_hotlist_add(request: Request) -> Dict[str, Any]:
    """添加订阅"""
    # Body: { chat_id, url/list_key, mode, sub_policy, backfill_first }
    return {"ok": True, "list_key": str, "list_url": str}
```

#### 1.3 Delete Subscription API (`/admin/hotlist/delete`)

```python
@router.post("/admin/hotlist/delete")
async def admin_hotlist_delete(request: Request) -> Dict[str, Any]:
    """删除订阅"""
    # Body: { chat_id, list_key }
    return {"ok": True}
```

#### 1.4 Patch Subscription API (`/admin/hotlist/patch`)

```python
@router.post("/admin/hotlist/patch")
async def admin_hotlist_patch(request: Request) -> Dict[str, Any]:
    """修改订阅规则"""
    # Body: { chat_id, list_key, mode?, patch: Dict }
    return {"ok": True}
```

### 2. Frontend Components (需要增强)

#### 2.1 HotlistAPI Module

```javascript
const HotlistAPI = {
    async fetchList() {
        const res = await fetch('/admin/hotlist.json');
        return await res.json();
    },
    
    async addSubscription(data) {
        const res = await fetch('/admin/hotlist/add', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(data)
        });
        return await res.json();
    },
    
    async deleteSubscription(chatId, listKey) { /* ... */ },
    async patchSubscription(chatId, listKey, patch) { /* ... */ },
    async backfillNext(chatId, listKey, start) { /* ... */ }
};
```

#### 2.2 HotlistCache Module

```javascript
const HotlistCache = {
    KEY: 'snh_hotlist_cache',
    TTL: 2 * 60 * 1000,  // 2 minutes
    
    get() { /* 获取缓存数据 */ },
    set(data) { /* 设置缓存数据 */ },
    isValid() { /* 检查缓存是否有效 */ },
    invalidate() { /* 清除缓存 */ },
    getStale() { /* 获取过期数据用于 stale-while-revalidate */ }
};
```

#### 2.3 HotlistUI Module

```javascript
const HotlistUI = {
    renderSubscriptions(subs) { /* 渲染订阅列表 */ },
    renderBuiltins(builtins, subscribedKeys) { /* 渲染内置榜单 */ },
    updateStats(subs, ignoreCounts) { /* 更新统计信息 */ },
    
    showSkeleton() { /* 显示骨架屏 */ },
    hideSkeleton() { /* 隐藏骨架屏 */ },
    
    showToast(message, type) { /* 显示提示 */ },
    showError(message, retryFn) { /* 显示错误状态 */ },
    
    openAddModal() { /* 打开添加模态框 */ },
    openEditModal(sub) { /* 打开编辑模态框 */ }
};
```

## Data Models

### Frontend Data Structures

```typescript
interface HotlistState {
    builtins: BuiltinList[];
    subs: Subscription[];
    snapshots: Record<string, Snapshot>;
    ignoreCounts: Record<string, number>;
    prefChatId: number;
    isLoading: boolean;
    error: string | null;
}

interface Subscription {
    chat_id: number;
    list_key: string;
    list_url: string;
    mode: 'incremental' | 'digest';
    filters: FilterRules;
    created_ts: number;
    updated_ts: number;
}

interface FilterRules {
    notify_new_items?: boolean;
    notify_auto_result?: boolean;
    top_n?: number;
    auto_rules?: {
        min_rating?: number;
        year_min?: number;
        year_max?: number;
        media?: 'movie' | 'tv';
        region?: string;
        kw_white?: string[];
        kw_black?: string[];
        block_unrated?: boolean;
    };
}

interface BuiltinList {
    key: string;
    title: string;
    url: string;
}

interface CacheEntry {
    data: HotlistState;
    timestamp: number;
}
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Subscription Rendering Completeness

*For any* subscription with non-null `list_key`, `chat_id`, and `mode` fields, the rendered subscription card SHALL display all three values. If the subscription has `filters.auto_rules` with any non-empty values, the card SHALL display corresponding filter tags.

**Validates: Requirements 1.2, 1.5**

### Property 2: Builtin Subscription Status Consistency

*For any* builtin list, if its `key` exists in the current subscriptions list, the UI SHALL show "已订阅" badge; otherwise, it SHALL show "订阅" button. These two states are mutually exclusive.

**Validates: Requirements 2.2, 2.3**

### Property 3: Statistics Calculation Accuracy

*For any* subscription list and ignore_counts object:
- Total count SHALL equal `subs.length`
- Active count SHALL equal count of subs where `filters.notify_new_items !== false`
- Ignore total SHALL equal sum of all values in `ignore_counts`

**Validates: Requirements 7.1, 7.2, 7.3**

### Property 4: API Response Format Consistency

*For any* API endpoint under `/admin/hotlist/*`, the response SHALL contain `ok` (boolean) field. When `ok` is false, a `detail` string field SHALL be present. The `/admin/hotlist.json` response SHALL contain `builtins`, `subs`, `snapshots`, `ignore_counts` fields.

**Validates: Requirements 8.1, 8.2, 8.3, 8.4**

### Property 5: Cache TTL Enforcement

*For any* cached hotlist data, the cache entry SHALL be considered invalid when the current time exceeds `timestamp + TTL` (2 minutes). After any mutation operation (add/delete/patch), the cache SHALL be invalidated immediately.

**Validates: Requirements 9.1, 9.3**

### Property 6: Filter Modal Population

*For any* subscription with `filters.auto_rules` containing values, when the edit modal opens, all existing filter values SHALL be populated in the corresponding form fields.

**Validates: Requirements 4.2**

## Error Handling

### Frontend Error Handling

1. **Network Error**: Show cached data + "离线模式" indicator, provide retry button
2. **API Error (ok: false)**: Show error toast with detail message
3. **Parse Error**: Log to console, show generic error message
4. **Timeout**: Retry once, then show timeout message

```javascript
async function fetchWithFallback() {
    try {
        const data = await HotlistAPI.fetchList();
        if (data.ok) {
            HotlistCache.set(data);
            return { data, fromCache: false };
        } else {
            throw new Error(data.detail || '请求失败');
        }
    } catch (error) {
        const cached = HotlistCache.getStale();
        if (cached) {
            return { data: cached, fromCache: true, error };
        }
        throw error;
    }
}
```

### Mutation Error Handling

```javascript
async function withMutationFeedback(operation, successMsg) {
    try {
        const result = await operation();
        if (result.ok) {
            HotlistUI.showToast(successMsg, 'success');
            HotlistCache.invalidate();
            await loadData();
        } else {
            HotlistUI.showToast(result.detail || '操作失败', 'error');
        }
        return result;
    } catch (error) {
        HotlistUI.showToast('网络错误，请重试', 'error');
        throw error;
    }
}
```

## Testing Strategy

### Unit Tests

1. **Cache Logic**: Test TTL calculation, invalidation, stale data retrieval
2. **Statistics Calculation**: Test count calculations with various data
3. **Filter Tag Generation**: Test tag rendering for different filter combinations
4. **API Response Parsing**: Test handling of various response formats

### Property-Based Tests

使用 Hypothesis (Python) 进行属性测试：

1. **Property 3 (Statistics)**: Generate random subscription lists, verify count calculations
2. **Property 4 (API Format)**: Generate random API responses, verify schema compliance
3. **Property 5 (Cache TTL)**: Generate random timestamps, verify cache validity logic

### Integration Tests

1. **Add/Delete Flow**: Verify subscription appears/disappears after mutation
2. **Edit Flow**: Verify filter changes persist after save
3. **Cache Behavior**: Verify stale-while-revalidate works correctly

### Test Configuration

- Minimum 100 iterations per property test
- Tag format: `Feature: hotlist-data-integration, Property {N}: {description}`
