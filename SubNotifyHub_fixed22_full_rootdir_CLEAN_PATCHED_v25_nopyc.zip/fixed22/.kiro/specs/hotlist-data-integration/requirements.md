# Requirements Document

## Introduction

本功能旨在将热榜订阅管理页面（Hotlist）的前端与后端 API 数据打通，实现动态数据加载和交互。当前页面已有基础的 API 调用，但需要增强数据展示、错误处理、缓存策略和用户体验。

## Glossary

- **Hotlist_Page**: 热榜订阅管理页面，展示用户的订阅列表和内置榜单
- **Subscription**: 用户对某个豆瓣榜单的订阅记录
- **Builtin_List**: 系统内置的常用豆瓣榜单列表
- **Snapshot**: 榜单的最新抓取快照，包含条目列表
- **Filter_Rules**: 订阅的过滤规则，如最低评分、年份范围等
- **Ignore_Set**: 用户已忽略的条目集合

## Requirements

### Requirement 1: 订阅列表动态加载

**User Story:** As a user, I want to see my hotlist subscriptions with real-time status, so that I can manage my subscriptions effectively.

#### Acceptance Criteria

1. WHEN the hotlist page loads, THE Hotlist_Page SHALL request subscription data from `/admin/hotlist.json` API
2. WHEN subscription data is received, THE Hotlist_Page SHALL render subscription cards with title, chat_id, mode, and filter rules
3. WHILE subscription data is loading, THE Hotlist_Page SHALL display skeleton loading placeholders
4. IF the subscription API request fails, THEN THE Hotlist_Page SHALL display cached data or error state with retry option
5. WHEN a subscription has active filters, THE Hotlist_Page SHALL display filter tags (评分、年份、类型等)

### Requirement 2: 内置榜单展示

**User Story:** As a user, I want to browse built-in hotlists, so that I can quickly subscribe to popular lists.

#### Acceptance Criteria

1. WHEN the user switches to "内置榜单" tab, THE Hotlist_Page SHALL display all available built-in lists
2. WHEN a built-in list is already subscribed, THE Hotlist_Page SHALL show "已订阅" badge and "取消订阅" button
3. WHEN a built-in list is not subscribed, THE Hotlist_Page SHALL show "订阅" button
4. WHEN the user clicks "查看", THE Hotlist_Page SHALL open the Douban list page in a new tab

### Requirement 3: 添加订阅功能

**User Story:** As a user, I want to add new subscriptions by URL or list key, so that I can track custom hotlists.

#### Acceptance Criteria

1. WHEN the user clicks "添加订阅", THE Hotlist_Page SHALL display a modal with URL input and policy selection
2. WHEN the user submits a valid URL/key, THE Hotlist_Page SHALL call `/admin/hotlist/add` API
3. IF the add request succeeds, THEN THE Hotlist_Page SHALL close the modal and refresh the subscription list
4. IF the add request fails, THEN THE Hotlist_Page SHALL display an error message without closing the modal
5. WHEN adding a subscription, THE Hotlist_Page SHALL support both "仅新增" and "分页回溯" policies

### Requirement 4: 编辑订阅规则

**User Story:** As a user, I want to edit filter rules for my subscriptions, so that I can customize notification criteria.

#### Acceptance Criteria

1. WHEN the user clicks edit button on a subscription, THE Hotlist_Page SHALL display a rules editor modal
2. WHEN the rules modal opens, THE Hotlist_Page SHALL populate current filter values
3. THE Hotlist_Page SHALL support editing: 最低评分, 年份范围, 媒体类型, 地区, 类型标签, 排除关键词
4. WHEN the user saves rules, THE Hotlist_Page SHALL call `/admin/hotlist/patch` API
5. IF the patch request succeeds, THEN THE Hotlist_Page SHALL close the modal and refresh the subscription

### Requirement 5: 删除订阅功能

**User Story:** As a user, I want to delete subscriptions I no longer need, so that I can keep my list clean.

#### Acceptance Criteria

1. WHEN the user clicks delete button, THE Hotlist_Page SHALL display a confirmation dialog
2. IF the user confirms deletion, THEN THE Hotlist_Page SHALL call `/admin/hotlist/delete` API
3. IF the delete request succeeds, THEN THE Hotlist_Page SHALL remove the subscription card with animation
4. IF the delete request fails, THEN THE Hotlist_Page SHALL display an error message

### Requirement 6: 刷新/回溯功能

**User Story:** As a user, I want to manually refresh a subscription, so that I can trigger immediate data fetch.

#### Acceptance Criteria

1. WHEN the user clicks refresh button, THE Hotlist_Page SHALL call `/admin/hotlist/backfill_next` API
2. WHILE the refresh is in progress, THE Hotlist_Page SHALL show a loading indicator on the button
3. IF the refresh succeeds, THEN THE Hotlist_Page SHALL display a success toast
4. IF the refresh fails, THEN THE Hotlist_Page SHALL display an error toast

### Requirement 7: 统计信息展示

**User Story:** As a user, I want to see subscription statistics, so that I can understand my subscription status at a glance.

#### Acceptance Criteria

1. WHEN subscription data is loaded, THE Hotlist_Page SHALL display total subscription count
2. THE Hotlist_Page SHALL display active subscription count (notify_new_items enabled)
3. THE Hotlist_Page SHALL display total ignored items count across all subscriptions
4. WHEN statistics change, THE Hotlist_Page SHALL update the display immediately

### Requirement 8: API 响应格式标准化

**User Story:** As a developer, I want consistent API response formats, so that I can reliably handle responses.

#### Acceptance Criteria

1. THE API SHALL return JSON responses with `ok` (boolean) and optional `detail` (error message) fields
2. WHEN a request succeeds, THE API SHALL set `ok: true` and include relevant data
3. WHEN a request fails, THE API SHALL set `ok: false` and include error detail
4. THE `/admin/hotlist.json` API SHALL include `builtins`, `subs`, `snapshots`, `ignore_counts` fields

### Requirement 9: 数据缓存策略

**User Story:** As a user, I want fast page loads, so that I can have a responsive experience.

#### Acceptance Criteria

1. THE Hotlist_Page SHALL cache subscription data in localStorage with TTL of 2 minutes
2. WHEN cached data exists, THE Hotlist_Page SHALL display cached data immediately while fetching fresh data
3. WHEN the user performs a mutation (add/delete/patch), THE Hotlist_Page SHALL invalidate cache and refresh
4. THE Hotlist_Page SHALL display "上次更新" timestamp for cached data

### Requirement 10: 错误处理和用户反馈

**User Story:** As a user, I want clear feedback on my actions, so that I know what's happening.

#### Acceptance Criteria

1. WHEN an API request is in progress, THE Hotlist_Page SHALL disable the action button and show loading state
2. WHEN an API request succeeds, THE Hotlist_Page SHALL show a success toast notification
3. WHEN an API request fails, THE Hotlist_Page SHALL show an error toast with retry option
4. IF network is unavailable, THEN THE Hotlist_Page SHALL display offline indicator

