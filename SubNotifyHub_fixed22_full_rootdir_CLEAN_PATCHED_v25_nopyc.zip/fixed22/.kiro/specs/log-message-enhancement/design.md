# Design Document: Log Message Enhancement

## Overview

本设计文档描述如何将第九部分迁移的日志消息从简短描述改进为详细的"人话版"描述。核心工作是为每条日志消息添加三要素：问题描述、可能原因、影响/建议。

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                      改进前（简短描述）                          │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  biz.detail("ℹ️ 初始化数据库失败", 更新ID=id, 错误=e)    │  │
│  └──────────────────────────────────────────────────────────┘  │
│                              ↓                                  │
│                         改进工作                                │
│                              ↓                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  biz.detail(                                             │  │
│  │      "ℹ️ 初始化数据库失败：无法连接到 SQLite 数据库..."  │  │
│  │      "可能原因：磁盘空间不足、文件权限问题..."           │  │
│  │      "建议：检查数据目录权限和磁盘空间",                 │  │
│  │      更新ID=id, 错误=e,                                  │  │
│  │  )                                                       │  │
│  └──────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

## Components and Interfaces

### 1. 日志消息模板结构

每条日志消息应包含以下结构化元素：

```python
# 错误/警告消息结构
MESSAGE = (
    "[emoji] [操作描述]：[具体问题]。"
    "可能原因：[原因1]、[原因2]或[原因3]。"
    "[影响/建议]：[具体说明]"
)

# 信息消息结构
MESSAGE = (
    "[emoji] [操作描述]：[详细说明]。"
    "[后续处理说明]"
)

# 成功消息结构
MESSAGE = (
    "[emoji] [操作描述]完成：[完成状态描述]"
)
```

### 2. 模块分类与消息模板

#### 2.1 Storage Tables 模块

这些模块处理数据库操作，错误通常与 SQLite 相关：

```python
# 数据库初始化失败
_LOG_DB_INIT_FAILED = (
    "ℹ️ 初始化数据库失败：无法连接到 SQLite 数据库，{功能}将无法持久化。"
    "可能原因：磁盘空间不足、文件权限问题或数据库文件损坏。"
    "建议：检查数据目录权限和磁盘空间"
)

# 数据库写入失败
_LOG_DB_WRITE_FAILED = (
    "ℹ️ {操作}失败：无法将数据写入数据库。"
    "可能原因：数据库锁定、磁盘空间不足或表结构损坏。"
    "影响：{影响描述}"
)

# 数据库查询失败
_LOG_DB_QUERY_FAILED = (
    "ℹ️ {操作}失败：无法从数据库读取数据。"
    "可能原因：数据库文件损坏或查询语句错误。"
    "影响：{影响描述}"
)

# 数据解析失败
_LOG_PARSE_FAILED = (
    "ℹ️ {操作}失败：无法解析{数据类型}。"
    "可能原因：数据格式不符合预期或数据损坏。"
    "影响：{影响描述}"
)
```

#### 2.2 Notifier Worker 模块

这些模块处理通知队列，错误通常与异步处理相关：

```python
# 队列操作
_LOG_QUEUE_FULL = (
    "❌ 队列已满且不等待，已写入死信：通知队列已达到最大容量，任务已保存到死信文件。"
    "可能原因：通知处理速度跟不上入队速度。"
    "建议：检查是否有大量通知同时触发，或考虑增加 NOTIFIER_WORKER_CONCURRENCY"
)

_LOG_WORKER_STOPPED = (
    "⚠️ 通知 Worker 已停止，丢弃任务：系统正在关闭，新的通知任务将不会被处理。"
    "影响：此通知将丢失，如需重新发送请在系统重启后手动触发"
)

# 重试相关
_LOG_RETRY_PARSE_FAILED = (
    "⚠️ 解析重试参数失败：无法从异常对象中提取重试等待时间。"
    "可能原因：异常对象格式不符合预期。"
    "影响：将使用默认退避策略"
)

# 死信相关
_LOG_DEADLETTER_WRITE_FAILED = (
    "⚠️ 写入死信文件失败：无法保存失败的通知任务。"
    "可能原因：磁盘空间不足或文件权限问题。"
    "影响：该任务将丢失，无法后续重放"
)
```

#### 2.3 Share 功能模块

这些模块处理分享链接，错误通常与外部服务相关：

```python
# 配置获取
_LOG_CONFIG_FAILED = (
    "ℹ️ 获取{配置项}失败：无法读取配置值。"
    "可能原因：环境变量未设置或配置文件格式错误。"
    "影响：{影响描述}"
)

# 外部服务调用
_LOG_SERVICE_FAILED = (
    "ℹ️ {服务}调用失败：无法完成请求。"
    "可能原因：网络连接问题或服务不可用。"
    "影响：{影响描述}"
)

# 缓存操作
_LOG_CACHE_FAILED = (
    "ℹ️ {操作}缓存失败：无法更新本地缓存。"
    "可能原因：内存不足或缓存状态异常。"
    "影响：将使用旧的缓存数据，可能不是最新状态"
)
```

## Data Models

### 日志消息三要素

| 要素 | 说明 | 示例 |
|------|------|------|
| 问题描述 | 发生了什么 | "无法连接到 SQLite 数据库" |
| 可能原因 | 为什么发生 | "磁盘空间不足、文件权限问题或数据库文件损坏" |
| 影响/建议 | 怎么处理 | "检查数据目录权限和磁盘空间" |

### Emoji 使用规范

| 日志级别 | Emoji | 使用场景 |
|---------|-------|---------|
| biz.fail | ❌ | 严重错误，需要立即处理 |
| biz.warn | ⚠️ | 警告，可能影响功能但不致命 |
| biz.info | ℹ️ | 一般信息，记录状态变化 |
| biz.detail | ℹ️ | 详细信息，调试用途 |
| biz.ok | ✅ | 成功完成，确认状态 |



## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do.*

根据 prework 分析，本功能的所有需求都是关于日志消息内容和格式的改进，属于代码质量改进而非功能性变更。这些需求更适合通过代码审查和静态分析来验证，而非运行时的属性测试。

**无可自动化测试的属性**

原因：
1. 日志消息是硬编码的字符串，其内容在编译时就已确定
2. 验证日志消息是否"详细"或"包含三要素"需要人工判断
3. 格式规范可以通过 linter 或代码审查来保证

## Error Handling

### 日志消息改进原则

1. **保持原有行为** - 只修改日志消息内容，不改变错误处理逻辑
2. **不影响业务** - 日志消息的改进不应影响任何业务流程
3. **保持性能** - 多行字符串拼接在 Python 中是编译时优化的，不影响运行时性能

### 改进注意事项

```python
# 原代码
biz.detail("ℹ️ 初始化数据库失败", 更新ID=update_id, 错误=str(e))

# 改进后 - 使用多行字符串拼接
biz.detail(
    "ℹ️ 初始化数据库失败：无法连接到 SQLite 数据库，失败更新将无法持久化。"
    "可能原因：磁盘空间不足、文件权限问题或数据库文件损坏。"
    "建议：检查数据目录权限和磁盘空间",
    更新ID=update_id,
    错误=str(e),
)
```

## Testing Strategy

### 验证方式

由于本功能是日志消息内容的改进，主要通过以下方式验证：

1. **代码审查** - 确保每条日志消息包含三要素
2. **手动测试** - 触发错误场景，检查日志输出是否符合预期
3. **静态分析** - 使用 grep 或脚本检查日志消息格式

### 验证脚本示例

```bash
# 检查是否所有 biz.detail/warn/fail 调用都包含"可能原因"或"影响"
grep -r "biz\.\(detail\|warn\|fail\)" tg_bot/storage/tables/ | grep -v "可能原因\|影响\|建议"
```

### 回归测试

运行现有的单元测试确保改进不影响功能：

```bash
pytest tests/unit/tg_bot/storage/ -v
pytest tests/unit/notifier/ -v
```

## Implementation Notes

### 文件修改清单

#### Storage Tables 模块（7 个文件）
- `tg_bot/storage/tables/failed_updates.py` - 约 12 处日志
- `tg_bot/storage/tables/offline.py` - 约 10 处日志
- `tg_bot/storage/tables/pending_choice.py` - 约 10 处日志
- `tg_bot/storage/tables/pending_rule_input.py` - 约 2 处日志
- `tg_bot/storage/tables/share_map.py` - 约 8 处日志
- `tg_bot/storage/tables/title_series.py` - 约 8 处日志
- `tg_bot/storage/tables/user_settings.py` - 约 1 处日志

#### Notifier Worker 模块（3 个文件）
- `notifier/worker.py` - 约 20 处日志
- `notifier/worker_retry.py` - 约 6 处日志
- `notifier/worker_deadletter.py` - 约 10 处日志

#### Share 功能模块（3 个文件）
- `tg_bot/features/share/share_usecase.py` - 约 15 处日志
- `tg_bot/features/share/share_mh.py` - 约 25 处日志
- `tg_bot/features/mediahelp/handlers.py` - 约 10 处日志

### 改进优先级

1. **高优先级** - 用户可见的错误/警告消息（biz.fail, biz.warn）
2. **中优先级** - 运维相关的信息消息（biz.info, biz.ok）
3. **低优先级** - 调试用的详细消息（biz.detail）
