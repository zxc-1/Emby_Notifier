# Implementation Plan: Log Message Enhancement

## Overview

本实现计划将第九部分迁移的日志消息从简短描述改进为详细的"人话版"描述，为每条日志消息添加三要素：问题描述、可能原因、影响/建议。

## Tasks

- [x] 1. 改进 Storage Tables 模块的日志消息
  - [x] 1.1 改进 `tg_bot/storage/tables/failed_updates.py`
  - [x] 1.2 改进 `tg_bot/storage/tables/offline.py`
  - [x] 1.3 改进 `tg_bot/storage/tables/pending_choice.py`
  - [x] 1.4 改进 `tg_bot/storage/tables/pending_rule_input.py`
  - [x] 1.5 改进 `tg_bot/storage/tables/share_map.py`
  - [x] 1.6 改进 `tg_bot/storage/tables/title_series.py`
  - [x] 1.7 改进 `tg_bot/storage/tables/user_settings.py`

- [x] 2. Checkpoint - 确保 Storage Tables 模块测试通过

- [x] 3. 改进 Notifier Worker 模块的日志消息
  - [x] 3.1 改进 `notifier/worker.py`
  - [x] 3.2 改进 `notifier/worker_retry.py`
  - [x] 3.3 改进 `notifier/worker_deadletter.py`

- [x] 4. Checkpoint - 确保 Notifier 模块测试通过

- [x] 5. 改进 Share 功能模块的日志消息
  - [x] 5.1 改进 `tg_bot/features/share/share_usecase.py`
  - [x] 5.2 改进 `tg_bot/features/share/share_mh.py`
  - [x] 5.3 改进 `tg_bot/features/mediahelp/handlers.py`

- [x] 6. Checkpoint - 确保 Share 功能模块测试通过

- [x] 7. Final Checkpoint - 确保所有测试通过

- [x] 8. 改进 Storage 核心模块的日志消息（补充）
  - [x] 8.1 改进 `tg_bot/storage/schema.py` - 约 15 处日志
  - [x] 8.2 改进 `tg_bot/storage/db.py` - 约 3 处日志

- [x] 9. 改进 Infra 模块的日志消息（补充）
  - [x] 9.1 改进 `tg_bot/infra/telegram_api.py` - 约 12 处日志
  - [x] 9.2 改进 `tg_bot/infra/polling.py` - 约 12 处日志
  - [x] 9.3 改进 `tg_bot/infra/webhook_setup.py` - 约 3 处日志
  - [x] 9.4 改进 `tg_bot/infra/share_resolver_repo.py` - 1 处日志
  - [x] 9.5 改进 `tg_bot/infra/outbox.py` - 约 5 处日志

- [x] 10. 改进 Services 模块的日志消息（补充）
  - [x] 10.1 改进 `tg_bot/services/tg_polling_service.py` - 约 3 处日志

- [x] 11. 改进 Common 模块的日志消息（补充）
  - [x] 11.1 改进 `tg_bot/common/session_manager.py` - 约 12 处日志
  - [x] 11.2 改进 `tg_bot/common/pick_ui.py` - 约 2 处日志
  - [x] 11.3 改进 `tg_bot/common/parser_urls.py` - 约 1 处日志
  - [x] 11.4 改进 `tg_bot/common/parser_commands.py` - 约 4 处日志
  - [x] 11.5 改进 `tg_bot/common/parser_share.py` - 约 20 处日志
  - [x] 11.6 改进 `tg_bot/common/parser.py` - 约 6 处日志

- [x] 12. Final Verification - 所有 54 个单元测试通过

## Notes

- 每个任务都引用了具体的需求以便追溯
- Checkpoint 任务用于确保增量验证
- 改进时只修改日志消息内容，不改变错误处理逻辑
- 使用多行字符串拼接保持代码整洁，避免单行超过 120 字符
- 所有日志消息已改为"三要素"格式：问题描述、可能原因、影响/建议
