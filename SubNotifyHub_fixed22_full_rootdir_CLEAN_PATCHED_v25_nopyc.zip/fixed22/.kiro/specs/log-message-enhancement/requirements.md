# Requirements Document

## Introduction

在 human-readable-logs 规范的第九部分迁移中，虽然已将 `logger.info/warning/error` 改成了 BizLogger 方法，但日志消息内容仍然过于简短，不符合"人话版"日志的标准。

根据 Requirement 5 的要求，每条日志消息应该：
1. 使用中文描述正在执行的操作
2. 清晰说明操作的目的、过程和结果
3. 错误消息应说明出了什么问题、可能的原因、以及建议的解决方法
4. 警告消息应说明为什么跳过、有什么影响、以及是否需要用户处理

本规范专门针对第九部分涉及的模块，将简短的日志消息改进为详细的"人话版"描述。

## Glossary

- **BizLogger**: 业务日志 DSL，提供 `step()`、`ok()`、`warn()`、`fail()`、`info()`、`detail()` 等方法
- **人话版日志**: 使用详细中文描述的日志，包含操作描述、原因说明和建议措施
- **三要素**: 问题描述 + 可能原因 + 建议措施

## Requirements

### Requirement 1: Storage Tables 模块日志详细化

**User Story:** As a 运维人员, I want 数据库操作日志包含详细的错误原因和解决建议, so that 我能快速定位和解决数据库问题。

#### Acceptance Criteria

1. THE `tg_bot/storage/tables/failed_updates.py` 中的日志消息 SHALL 包含三要素（问题描述、可能原因、建议措施）
2. THE `tg_bot/storage/tables/offline.py` 中的日志消息 SHALL 包含三要素
3. THE `tg_bot/storage/tables/pending_choice.py` 中的日志消息 SHALL 包含三要素
4. THE `tg_bot/storage/tables/pending_rule_input.py` 中的日志消息 SHALL 包含三要素
5. THE `tg_bot/storage/tables/share_map.py` 中的日志消息 SHALL 包含三要素
6. THE `tg_bot/storage/tables/title_series.py` 中的日志消息 SHALL 包含三要素
7. THE `tg_bot/storage/tables/user_settings.py` 中的日志消息 SHALL 包含三要素

#### 日志消息改进示例

| 文件 | 当前消息 | 改进后消息 |
|-----|---------|----------|
| failed_updates.py | `ℹ️ 初始化数据库失败` | `ℹ️ 初始化数据库失败：无法连接到 SQLite 数据库，失败更新将无法持久化。可能原因：磁盘空间不足、文件权限问题或数据库文件损坏。建议：检查数据目录权限和磁盘空间` |
| failed_updates.py | `ℹ️ 记录失败更新失败` | `ℹ️ 记录失败更新失败：无法将失败的 Telegram 更新写入死信表，该记录将丢失。可能原因：数据库锁定、磁盘空间不足或表结构损坏。影响：无法通过管理界面查看此失败记录，但不影响正常消息处理` |
| offline.py | `ℹ️ 离线去重清理失败` | `ℹ️ 离线去重清理失败：无法清理过期的离线任务去重记录。可能原因：数据库锁定或磁盘 I/O 错误。影响：去重表可能逐渐增大，但不影响正常功能` |
| pending_choice.py | `ℹ️ 导入分享链接构建模块失败` | `ℹ️ 导入分享链接构建模块失败：无法加载 share_format 模块。可能原因：模块文件缺失或 Python 路径配置错误。影响：将使用原始链接格式` |

### Requirement 2: Notifier Worker 模块日志详细化

**User Story:** As a 运维人员, I want 通知处理日志包含详细的状态信息, so that 我能了解通知队列的运行状况。

#### Acceptance Criteria

1. THE `notifier/worker.py` 中的日志消息 SHALL 包含详细的业务描述
2. THE `notifier/worker_retry.py` 中的日志消息 SHALL 包含三要素
3. THE `notifier/worker_deadletter.py` 中的日志消息 SHALL 包含三要素

#### 日志消息改进示例

| 文件 | 当前消息 | 改进后消息 |
|-----|---------|----------|
| worker.py | `死信文件清理完成` | `✅ 死信文件清理完成：已清理过期的失败通知记录，释放磁盘空间` |
| worker.py | `死信文件清理失败` | `⚠️ 死信文件清理失败：无法删除过期的死信文件。可能原因：文件被占用或权限不足。影响：磁盘空间可能逐渐增大，建议手动检查 deadletter 目录` |
| worker.py | `通知 worker 已停止，丢弃任务` | `⚠️ 通知 Worker 已停止，丢弃任务：系统正在关闭，新的通知任务将不会被处理。影响：此通知将丢失，如需重新发送请在系统重启后手动触发` |
| worker.py | `队列已满且不等待，已写入死信` | `❌ 队列已满且不等待，已写入死信：通知队列已达到最大容量，任务已保存到死信文件。可能原因：通知处理速度跟不上入队速度。建议：检查是否有大量通知同时触发，或考虑增加 NOTIFIER_WORKER_CONCURRENCY` |
| worker_retry.py | `⚠️ 解析 retry_after 属性失败` | `⚠️ 解析 retry_after 属性失败：无法从异常对象中提取重试等待时间。可能原因：异常对象格式不符合预期。影响：将使用默认退避策略` |
| worker_deadletter.py | `删除过期死信文件失败` | `⚠️ 删除过期死信文件失败：无法删除指定的死信文件。可能原因：文件被其他进程占用或权限不足。影响：该文件将在下次清理时重试` |

### Requirement 3: Share 功能模块日志详细化

**User Story:** As a 用户, I want 分享链接处理日志清晰易懂, so that 我能了解分享链接的处理状态。

#### Acceptance Criteria

1. THE `tg_bot/features/share/share_usecase.py` 中的日志消息 SHALL 包含详细的业务描述
2. THE `tg_bot/features/share/share_mh.py` 中的日志消息 SHALL 包含详细的业务描述
3. THE `tg_bot/features/mediahelp/handlers.py` 中的日志消息 SHALL 包含三要素

#### 日志消息改进示例

| 文件 | 当前消息 | 改进后消息 |
|-----|---------|----------|
| share_usecase.py | `ℹ️ 获取 115 Cookie 失败` | `ℹ️ 获取 115 Cookie 失败：无法读取 CLOUD115_COOKIE 配置。可能原因：环境变量未设置或配置文件格式错误。影响：将跳过 115 网盘相关功能` |
| share_usecase.py | `ℹ️ 获取分享标题失败` | `ℹ️ 获取分享标题失败：无法从分享链接中提取标题信息。可能原因：链接格式不标准或网络请求失败。影响：将使用默认标题` |
| share_mh.py | `ℹ️ 设置通知上下文失败` | `ℹ️ 设置通知上下文失败：无法设置通知来源标签。可能原因：上下文管理器状态异常。影响：通知消息中可能缺少来源标识` |
| share_mh.py | `ℹ️ 刷新订阅缓存失败` | `ℹ️ 刷新订阅缓存失败：无法从 MediaHelp 服务获取最新订阅列表。可能原因：网络连接问题或 MediaHelp 服务不可用。影响：将使用缓存的订阅数据，可能不是最新状态` |

### Requirement 4: 日志消息格式规范

**User Story:** As a 开发者, I want 所有日志消息遵循统一的格式规范, so that 日志风格一致且易于阅读。

#### Acceptance Criteria

1. THE Log_Message SHALL 遵循格式：`[emoji] [操作描述]：[详细说明]。[可能原因]。[影响/建议]`
2. THE Error_Message (biz.fail) SHALL 使用 ❌ emoji 并包含解决建议
3. THE Warning_Message (biz.warn) SHALL 使用 ⚠️ emoji 并说明影响
4. THE Info_Message (biz.info/detail) SHALL 使用 ℹ️ emoji 并说明后续处理
5. THE Success_Message (biz.ok) SHALL 使用 ✅ emoji 并说明完成状态

#### 格式模板

```
# 错误消息模板
❌ [操作]失败：[具体问题]。可能原因：[原因列表]。建议：[解决方法]

# 警告消息模板
⚠️ [操作]异常：[具体情况]。可能原因：[原因列表]。影响：[对用户/系统的影响]

# 信息消息模板
ℹ️ [操作]：[详细描述]。[后续处理说明]

# 成功消息模板
✅ [操作]完成：[完成状态描述]
```

### Requirement 5: 保持代码简洁

**User Story:** As a 开发者, I want 日志消息改进不影响代码可读性, so that 代码仍然易于维护。

#### Acceptance Criteria

1. THE Log_Message SHALL 使用多行字符串拼接保持代码整洁
2. THE Log_Message SHALL 避免单行超过 120 字符
3. THE Log_Message SHALL 使用 f-string 或 format 进行变量插值
4. THE KV_Fields SHALL 继续使用中文字段名

#### 代码示例

```python
# 推荐写法：多行字符串拼接
biz.detail(
    "ℹ️ 初始化数据库失败：无法连接到 SQLite 数据库，失败更新将无法持久化。"
    "可能原因：磁盘空间不足、文件权限问题或数据库文件损坏。"
    "建议：检查数据目录权限和磁盘空间",
    更新ID=update_id,
    错误=str(e),
)

# 不推荐：单行过长
biz.detail("ℹ️ 初始化数据库失败：无法连接到 SQLite 数据库，失败更新将无法持久化。可能原因：磁盘空间不足、文件权限问题或数据库文件损坏。建议：检查数据目录权限和磁盘空间", 更新ID=update_id, 错误=str(e))
```
