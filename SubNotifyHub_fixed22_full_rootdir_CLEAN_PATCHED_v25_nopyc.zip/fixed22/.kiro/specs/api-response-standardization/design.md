# Design Document: API Response Standardization

## Overview

本设计统一项目所有 API 端点的响应格式，建立一致的响应结构。所有成功响应使用 `{success: true, data: ...}` 格式，所有错误响应使用 `{success: false, error: {...}}` 格式。

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                    API Response Layer                       │
├─────────────────────────────────────────────────────────────┤
│                                                             │
│  ┌─────────────────────┐    ┌─────────────────────────┐    │
│  │   Response Models   │    │   Response Helpers      │    │
│  │                     │    │                         │    │
│  │  • ApiResponse[T]   │    │  • success_response()   │    │
│  │  • ErrorDetail      │    │  • error_response()     │    │
│  │  • ErrorResponse    │    │  • validation_error()   │    │
│  │                     │    │                         │    │
│  └─────────────────────┘    └─────────────────────────┘    │
│                                                             │
│  ┌─────────────────────────────────────────────────────┐   │
│  │              Exception Handlers                      │   │
│  │                                                      │   │
│  │  ValidationError → 400 VALIDATION_ERROR             │   │
│  │  NotFoundError   → 404 NOT_FOUND                    │   │
│  │  ConflictError   → 409 CONFLICT                     │   │
│  │  HTTPException   → 4xx/5xx HTTP_ERROR               │   │
│  │  Exception       → 500 INTERNAL_ERROR               │   │
│  │                                                      │   │
│  └─────────────────────────────────────────────────────┘   │
│                                                             │
└─────────────────────────────────────────────────────────────┘
```

## Components and Interfaces

### 1. 响应模型 (`api/responses.py`)

```python
from datetime import datetime, timezone
from typing import Any, Generic, Optional, TypeVar
from pydantic import BaseModel, Field

T = TypeVar("T")


class ErrorDetail(BaseModel):
    """错误详情"""
    code: str = Field(..., description="错误码，大写下划线格式")
    message: str = Field(..., description="错误消息")
    details: Optional[dict[str, Any]] = Field(None, description="额外错误信息")


class ApiResponse(BaseModel, Generic[T]):
    """统一 API 响应格式"""
    success: bool = Field(..., description="请求是否成功")
    data: Optional[T] = Field(None, description="响应数据")
    error: Optional[ErrorDetail] = Field(None, description="错误信息")
    timestamp: str = Field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat(),
        description="响应时间戳 (ISO 8601)"
    )
    trace_id: Optional[str] = Field(None, description="请求追踪 ID")


# 类型别名
SuccessResponse = ApiResponse[T]
ErrorResponse = ApiResponse[None]
```

### 2. 响应辅助函数

```python
from fastapi.responses import JSONResponse
from typing import Any, Optional


def success_response(
    data: Any = None,
    trace_id: Optional[str] = None,
    status_code: int = 200,
) -> JSONResponse:
    """创建成功响应"""
    body = ApiResponse(
        success=True,
        data=data,
        trace_id=trace_id,
    )
    return JSONResponse(content=body.model_dump(), status_code=status_code)


def error_response(
    code: str,
    message: str,
    trace_id: Optional[str] = None,
    details: Optional[dict] = None,
    status_code: int = 400,
) -> JSONResponse:
    """创建错误响应"""
    body = ApiResponse(
        success=False,
        error=ErrorDetail(code=code, message=message, details=details),
        trace_id=trace_id,
    )
    return JSONResponse(content=body.model_dump(), status_code=status_code)


def validation_error(
    message: str,
    field_errors: dict[str, str],
    trace_id: Optional[str] = None,
) -> JSONResponse:
    """创建验证错误响应"""
    return error_response(
        code="VALIDATION_ERROR",
        message=message,
        details={"fields": field_errors},
        trace_id=trace_id,
        status_code=400,
    )
```

### 3. 标准错误码

| 错误码 | HTTP 状态码 | 说明 |
|--------|------------|------|
| `VALIDATION_ERROR` | 400 | 请求参数验证失败 |
| `INVALID_JSON` | 400 | JSON 解析失败 |
| `UNAUTHORIZED` | 401 | 未认证 |
| `FORBIDDEN` | 403 | 无权限 |
| `NOT_FOUND` | 404 | 资源不存在 |
| `CONFLICT` | 409 | 资源冲突 |
| `QUEUE_FULL` | 503 | 队列已满 |
| `WORKER_NOT_STARTED` | 503 | Worker 未启动 |
| `TEMPORARY_ERROR` | 503 | 临时错误 |
| `INTERNAL_ERROR` | 500 | 内部错误 |

### 4. 响应示例

**成功响应:**
```json
{
  "success": true,
  "data": {
    "status": "ok",
    "version": "1.6.17.90"
  },
  "error": null,
  "timestamp": "2026-01-16T10:30:00.000Z",
  "trace_id": "abc123def456"
}
```

**错误响应:**
```json
{
  "success": false,
  "data": null,
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid request parameters",
    "details": {
      "fields": {
        "email": "Invalid email format"
      }
    }
  },
  "timestamp": "2026-01-16T10:30:00.000Z",
  "trace_id": "abc123def456"
}
```

## Data Models

### ApiResponse 模型

```python
class ApiResponse(BaseModel, Generic[T]):
    success: bool
    data: Optional[T] = None
    error: Optional[ErrorDetail] = None
    timestamp: str
    trace_id: Optional[str] = None
```

### ErrorDetail 模型

```python
class ErrorDetail(BaseModel):
    code: str
    message: str
    details: Optional[dict[str, Any]] = None
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: 成功响应结构一致性

*For any* API endpoint that returns a successful response, the response SHALL contain `success=true`, a `data` field, and a valid ISO 8601 `timestamp`.

**Validates: Requirements 1.1, 1.2, 1.3**

### Property 2: 错误响应结构一致性

*For any* API endpoint that returns an error response, the response SHALL contain `success=false`, an `error` object with `code` and `message` fields, and a `trace_id`.

**Validates: Requirements 2.1, 2.2, 2.4**

### Property 3: 错误码格式一致性

*For any* error response, the `error.code` field SHALL match the pattern `^[A-Z][A-Z0-9_]*$` (uppercase letters, digits, and underscores).

**Validates: Requirements 2.3**

## Error Handling

### 异常到响应映射

| 异常类型 | HTTP 状态码 | 错误码 |
|---------|------------|--------|
| `ValidationError` | 400 | `VALIDATION_ERROR` |
| `NotFoundError` | 404 | `NOT_FOUND` |
| `ConflictError` | 409 | `CONFLICT` |
| `PermissionError` | 403 | `FORBIDDEN` |
| `TemporaryError` | 503 | `TEMPORARY_ERROR` |
| `ConfigError` | 500 | `CONFIG_ERROR` |
| `HTTPException` | 原状态码 | `HTTP_ERROR` |
| `Exception` | 500 | `INTERNAL_ERROR` |

## Testing Strategy

### 单元测试

1. 测试 `ApiResponse` 模型序列化
2. 测试 `success_response()` 辅助函数
3. 测试 `error_response()` 辅助函数
4. 测试错误码格式验证

### 属性测试

使用 hypothesis 生成随机数据测试：

1. **Property 1**: 成功响应结构一致性
2. **Property 2**: 错误响应结构一致性
3. **Property 3**: 错误码格式一致性

### 集成测试

1. 测试各端点返回标准格式
2. 测试异常处理器返回标准格式
3. 测试 trace_id 传递

