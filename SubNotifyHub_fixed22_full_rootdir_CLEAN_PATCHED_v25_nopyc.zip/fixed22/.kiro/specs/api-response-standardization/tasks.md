# Implementation Plan: API Response Standardization

## Overview

统一项目所有 API 端点的响应格式，创建标准响应模型和辅助函数。

## Tasks

- [x] 1. 创建响应模型和辅助函数
  - [x] 1.1 创建 `api/responses.py`
    - 实现 `ErrorDetail` 模型
    - 实现 `ApiResponse[T]` 泛型模型
    - 实现 `success_response()` 辅助函数
    - 实现 `error_response()` 辅助函数
    - 实现 `validation_error()` 辅助函数
    - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5_

- [x] 2. 编写属性测试
  - [x] 2.1 创建 `tests/test_api_response_properties.py`
    - **Property 1: 成功响应结构一致性**
    - **Validates: Requirements 1.1, 1.2, 1.3**
  - [x] 2.2 编写 Property 2: 错误响应结构一致性
    - **Property 2: 错误响应结构一致性**
    - **Validates: Requirements 2.1, 2.2, 2.4**
  - [x] 2.3 编写 Property 3: 错误码格式一致性
    - **Property 3: 错误码格式一致性**
    - **Validates: Requirements 2.3**
  - _Requirements: 1.1, 1.2, 1.3, 2.1, 2.2, 2.3, 2.4_

- [x] 3. 更新错误处理器
  - 更新 `bootstrap/http_errors.py`
  - 使用新的 `error_response()` 函数
  - 保持现有错误码兼容
  - _Requirements: 6.1, 6.2, 6.3, 6.4_

- [x] 4. 迁移 health 端点
  - 更新 `api/health.py`
  - 使用 `success_response()` 包装响应
  - _Requirements: 5.1_

- [x] 5. 迁移 webhook 端点
  - 更新 `api/webhook.py`
  - 使用标准响应格式
  - _Requirements: 5.2_

- [x] 6. 迁移 mediahelp 端点
  - 更新 `api/mediahelp.py`
  - 使用标准响应格式
  - _Requirements: 5.3_

- [x] 7. 迁移 tg_bot 端点
  - 更新 `api/tg_bot.py`
  - 使用标准响应格式
  - _Requirements: 5.4_

- [x] 8. 迁移 metrics 端点
  - 更新 `api/metrics.py`
  - 使用标准响应格式（保留 Prometheus 格式端点）
  - _Requirements: 5.5_

- [x] 9. 迁移 debug 端点
  - 更新 `api/debug.py`
  - 使用标准响应格式
  - _Requirements: 5.6_

- [x] 10. 验证和测试
  - 运行属性测试
  - 运行现有测试套件
  - 验证所有端点返回标准格式
  - 更新集成测试以适应新响应格式
  - _Requirements: 5.7_

## Notes

- 所有任务都是必需的
- 保持向后兼容性，旧字段可以保留在 data 中
- Prometheus metrics 端点保持原格式（纯文本）

