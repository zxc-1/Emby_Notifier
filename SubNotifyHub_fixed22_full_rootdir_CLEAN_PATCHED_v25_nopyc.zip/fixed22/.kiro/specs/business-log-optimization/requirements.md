# Requirements Document

## Introduction

本项目旨在将整个项目的日志系统优化为详细的业务日志（Business Logging）。当前项目已有 `core/bizlog.py` 和 `core/bizlogger_adapter.py` 提供业务日志基础设施，但大部分业务模块仍使用传统的 `logging.getLogger()` 方式，缺乏统一的业务语义、结构化字段和可追踪性。

优化目标是让所有业务流程的日志具备：
- 清晰的业务语义（步骤、阶段、结果）
- 结构化的上下文字段（trace_id、span_id、kv 等）
- 统一的视觉标识（✅/⚠️/❌ 等 emoji）
- 可追踪的调用链路（group 嵌套、entry 入口）

## Glossary

- **BizLogger**: 业务日志 DSL 封装类，提供 `step()`、`ok()`、`warn()`、`fail()`、`group()` 等语义化方法
- **BizLoggerAdapter**: stdlib logging 的适配器，自动注入业务日志语义（kind、emoji 前缀）
- **LogContext**: 日志上下文变量集合，包含 trace_id、phase、step、indent 等
- **Entry**: 业务流程入口点，设置 domain/action 并创建 group
- **Group**: 带缩进和自动汇总的日志分组
- **Kind**: 日志类型标识（user_action、ok、warn、fail、meta）
- **KV**: 结构化键值对字段，用于日志的额外信息
- **Span**: 调用链路追踪单元，包含 span_id 和 parent_span_id

## Requirements

### Requirement 1: 统一业务日志入口

**User Story:** As a 开发者, I want 所有业务模块使用统一的业务日志入口, so that 日志风格一致且易于维护。

#### Acceptance Criteria

1. WHEN 业务模块需要记录日志 THEN THE Module SHALL 使用 `get_biz_logger()` 或 `get_biz_logger_adapter()` 获取日志实例
2. THE BizLogger SHALL 提供 `step()`、`ok()`、`warn()`、`fail()`、`info()`、`detail()` 方法用于不同语义的日志
3. THE BizLoggerAdapter SHALL 自动为 `warning()` 和 `error()` 添加 emoji 前缀（⚠️/❌）
4. WHEN 使用 `get_biz_logger_adapter()` THEN THE Adapter SHALL 保持与 stdlib logging 的 API 兼容性

### Requirement 2: 业务流程分组与追踪

**User Story:** As a 运维人员, I want 业务流程日志按逻辑分组并可追踪, so that 我能快速定位问题所在的业务环节。

#### Acceptance Criteria

1. WHEN 进入业务流程入口 THEN THE BizLogger SHALL 使用 `entry()` 上下文管理器设置 domain 和 action
2. WHEN 业务流程包含多个步骤 THEN THE BizLogger SHALL 使用 `group()` 上下文管理器创建带缩进的日志分组
3. WHEN `group()` 正常结束 THEN THE BizLogger SHALL 自动输出汇总行（包含 ok/skip/fail 计数和耗时）
4. IF `group()` 内发生异常 THEN THE BizLogger SHALL 输出 ❌ 标记的失败汇总行并重新抛出异常
5. THE LogContext SHALL 维护 span_id 和 parent_span_id 用于调用链路追踪

### Requirement 3: 结构化日志字段

**User Story:** As a 日志分析系统, I want 日志包含结构化字段, so that 我能进行高效的日志检索和聚合分析。

#### Acceptance Criteria

1. THE BizLogger SHALL 支持通过 `**kv` 参数传递任意结构化字段
2. THE LogFormatter SHALL 将 kv 字段格式化为 `key=value` 形式追加到日志行末尾
3. WHEN 使用 JSON 格式输出 THEN THE JsonLineFormatter SHALL 将 kv 字段作为独立的 JSON 对象输出
4. THE LogContext SHALL 自动注入 trace_id、phase、step、indent、span_id 到每条日志记录
5. THE AutoKVFilter SHALL 将 LogRecord 的非标准属性自动合并到 kv 字段

### Requirement 4: 步骤化日志输出

**User Story:** As a 用户, I want 看到清晰的步骤进度日志, so that 我能了解当前操作执行到哪一步。

#### Acceptance Criteria

1. THE BizLogger.step() SHALL 支持 `i` 和 `total` 参数输出 "第N步/共M步" 格式
2. WHEN 处理批量项目 THEN THE BizLogger SHALL 提供 `ok_item()`、`warn_item()`、`fail_item()` 方法输出带序号的结果
3. THE BizLogger SHALL 支持 `detail()` 和 `detail_step()` 方法用于可选的详细日志（受 BIZ_DETAIL 环境变量控制）
4. WHEN BIZ_ITEM_SAMPLE 启用 THEN THE BizLogger SHALL 只输出头尾若干条项目日志以避免刷屏

### Requirement 5: 日志级别与颜色标识

**User Story:** As a 开发者, I want 日志有清晰的级别和颜色标识, so that 我能快速识别重要信息。

#### Acceptance Criteria

1. THE BizTextFormatter SHALL 根据日志级别和 kind 字段应用不同颜色
2. THE Formatter SHALL 使用以下颜色方案区分不同类型日志：
   - 绿色（\x1b[32m）：成功操作（ok、success、user_action、run、fetch）
   - 黄色（\x1b[33m）：警告信息（warn、skip）
   - 红色（\x1b[31m）：错误信息（fail、error）
   - 青色（\x1b[36m）：调试/详细信息（detail、debug）
   - 蓝色（\x1b[34m）：元信息（meta、group 汇总行）
   - 灰色/暗淡（\x1b[2m）：时间戳、位置信息等辅助字段
3. THE BizLogger SHALL 使用统一的 emoji 标识：✅ 成功、⚠️ 警告、❌ 失败、▶️ 开始、ℹ️ 信息
4. WHEN LOG_COLOR=0 或非 TTY 输出 THEN THE Formatter SHALL 禁用颜色输出
5. THE Formatter SHALL 支持 pipe 和 classic 两种输出风格（通过 LOG_STYLE 配置）
6. THE Formatter SHALL 支持通过 LOG_COLOR_SCHEME 环境变量自定义颜色方案（可选）

### Requirement 6: 模块迁移覆盖

**User Story:** As a 项目维护者, I want 所有核心业务模块迁移到业务日志, so that 整个项目日志风格统一。

#### Acceptance Criteria

1. THE Notifier_Module SHALL 使用 BizLogger 记录通知处理流程（入队、处理、重试、死信）
2. THE TG_Bot_Module SHALL 使用 BizLogger 记录消息处理流程（命令解析、回调处理、API 调用）
3. THE Hotlist_Module SHALL 使用 BizLogger 记录热榜轮询流程（抓取、解析、订阅、去重）
4. THE TMDB_Match_Module SHALL 使用 BizLogger 记录匹配流程（搜索、评分、自动选择）
5. THE Share115_Module SHALL 使用 BizLogger 记录分享解析流程（URL 解析、文件列表、保存）
6. THE Forward_Bridge_Module SHALL 使用 BizLogger 记录转发桥接流程（认证、订阅、通知）

### Requirement 7: 日志配置与控制

**User Story:** As a 运维人员, I want 灵活配置日志行为, so that 我能根据环境调整日志详细程度。

#### Acceptance Criteria

1. THE Logging_System SHALL 支持通过 LOG_LEVEL 环境变量控制日志级别
2. THE Logging_System SHALL 支持通过 BIZ_DETAIL 环境变量控制详细日志输出（支持 domain 过滤）
3. THE Logging_System SHALL 支持通过 LOG_FILE 环境变量配置文件日志路径
4. THE Logging_System SHALL 支持通过 LOG_FILE_FORMAT 环境变量选择文件日志格式（text/json）
5. WHEN 配置 LOG_PIPE_FIXED_COLS=1 THEN THE Formatter SHALL 输出固定列宽格式便于对齐

### Requirement 8: 错误处理与重试日志

**User Story:** As a 运维人员, I want 错误和重试有详细的日志记录, so that 我能分析失败原因和重试策略。

#### Acceptance Criteria

1. WHEN 发生异常 THEN THE BizLogger.fail() SHALL 记录异常类型、消息和堆栈
2. WHEN 任务重试 THEN THE Worker SHALL 记录重试次数、退避时间和错误分类
3. WHEN 任务写入死信 THEN THE Worker SHALL 记录死信原因和任务元数据
4. THE BizLogger SHALL 支持 `set_result()` 方法设置 group 的最终结论（覆盖自动推断）

### Requirement 9: 性能与节流

**User Story:** As a 系统, I want 日志系统不影响业务性能, so that 高频操作不会因日志而变慢。

#### Acceptance Criteria

1. THE BizLogger.warn() SHALL 支持基于 reason 字段的节流（BIZ_THROTTLE_REASON）
2. THE BizLogger SHALL 支持 `detail_item()` 方法的采样输出（BIZ_ITEM_SAMPLE）
3. THE Logging_System SHALL 使用 RotatingFileHandler 限制日志文件大小
4. THE LogContext SHALL 使用 contextvars 实现线程/协程安全的上下文传递
