# Design Document: Business Log Optimization

## Overview

本设计文档描述如何将项目日志系统优化为详细的业务日志。核心思路是：

1. **保留现有基础设施** - `core/bizlog.py`、`core/bizlogger_adapter.py`、`core/logging_setup.py` 已提供完善的业务日志框架
2. **增强颜色和格式化** - 扩展 `BizTextFormatter` 支持更丰富的颜色方案
3. **模块迁移** - 将各业务模块从传统 logging 迁移到 BizLogger/BizLoggerAdapter
4. **统一日志模式** - 建立标准的日志使用模式和最佳实践

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                      Business Modules                            │
│  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐           │
│  │ Notifier │ │  TG Bot  │ │ Hotlist  │ │  TMDB    │  ...      │
│  └────┬─────┘ └────┬─────┘ └────┬─────┘ └────┬─────┘           │
│       │            │            │            │                   │
│       ▼            ▼            ▼            ▼                   │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │              BizLogger / BizLoggerAdapter                │    │
│  │  • step() ok() warn() fail() group() entry()            │    │
│  │  • info() warning() error() (adapter)                   │    │
│  └────────────────────────┬────────────────────────────────┘    │
│                           │                                      │
│                           ▼                                      │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                    LogContext (contextvars)              │    │
│  │  • trace_id, span_id, parent_span_id                    │    │
│  │  • phase, step, indent                                  │    │
│  │  • req_method, req_path, kind                           │    │
│  └────────────────────────┬────────────────────────────────┘    │
│                           │                                      │
│                           ▼                                      │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                    Logging Filters                       │    │
│  │  • ContextKindFilter    • ContextTraceFilter            │    │
│  │  • ContextFlowFilter    • ContextSpanFilter             │    │
│  │  • ContextIndentFilter  • AutoKVFilter                  │    │
│  └────────────────────────┬────────────────────────────────┘    │
│                           │                                      │
│                           ▼                                      │
│  ┌─────────────────────────────────────────────────────────┐    │
│  │                    Formatters                            │    │
│  │  • BizTextFormatter (console, colored)                  │    │
│  │  • JsonLineFormatter (file, structured)                 │    │
│  └────────────────────────┬────────────────────────────────┘    │
│                           │                                      │
│                           ▼                                      │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │    stdout    │  │    stderr    │  │   log file   │          │
│  │  (INFO/DEBUG)│  │ (WARN/ERROR) │  │ (all levels) │          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
└─────────────────────────────────────────────────────────────────┘
```

## Components and Interfaces

### 1. BizLogger (core/bizlog.py)

业务日志 DSL 封装，提供语义化的日志方法。

```python
class BizLogger:
    def __init__(self, name: str) -> None: ...
    
    # 步骤日志
    def step(self, msg: str, *, i: int = None, total: int = None, **kv) -> None: ...
    def detail_step(self, msg: str, *, i: int = None, total: int = None, **kv) -> None: ...
    
    # 结果日志
    def ok(self, msg: str, **kv) -> None: ...
    def warn(self, msg: str, **kv) -> None: ...
    def fail(self, msg: str, *, exc: Exception = None, **kv) -> None: ...
    
    # 批量项目日志
    def ok_item(self, msg: str, *, i: int, total: int, **kv) -> None: ...
    def warn_item(self, msg: str, *, i: int, total: int, **kv) -> None: ...
    def fail_item(self, msg: str, *, i: int, total: int, exc: Exception = None, **kv) -> None: ...
    
    # 详细日志（受 BIZ_DETAIL 控制）
    def detail(self, msg: str, **kv) -> None: ...
    def detail_item(self, msg: str, *, i: int, total: int, **kv) -> None: ...
    
    # 分组与入口
    @contextmanager
    def group(self, group_title: str, **kv) -> Iterator[None]: ...
    
    @contextmanager
    def entry(self, *, domain: str, action: str, group_title: str = None, **kv) -> Iterator[None]: ...
    
    # 结果覆盖
    def set_result(self, level: str, msg: str = '完成', **kv) -> None: ...
```

### 2. BizLoggerAdapter (core/bizlogger_adapter.py)

stdlib logging 适配器，保持 API 兼容性同时注入业务语义。

```python
class BizLoggerAdapter(logging.LoggerAdapter):
    def info(self, msg, *args, **kwargs) -> None: ...
    def warning(self, msg, *args, **kwargs) -> None: ...  # 自动添加 ⚠️
    def error(self, msg, *args, **kwargs) -> None: ...    # 自动添加 ❌
    def exception(self, msg, *args, exc_info=True, **kwargs) -> None: ...

def get_biz_logger_adapter(name: str, *, extra: dict = None) -> BizLoggerAdapter: ...
```

### 3. BizTextFormatter (core/logging_setup.py)

增强的文本格式化器，支持丰富的颜色方案。

```python
# 颜色方案
_ANSI = {
    "reset": "\x1b[0m",
    "green": "\x1b[32m",      # 成功
    "yellow": "\x1b[33m",     # 警告
    "red": "\x1b[31m",        # 错误
    "cyan": "\x1b[36m",       # 详细/调试
    "blue": "\x1b[34m",       # 元信息
    "dim": "\x1b[2m",         # 暗淡（辅助信息）
    "bold": "\x1b[1m",        # 粗体
}

# Kind 到颜色的映射
_KIND_COLORS = {
    "ok": "green",
    "success": "green",
    "user_action": "green",
    "run": "green",
    "fetch": "green",
    "warn": "yellow",
    "skip": "yellow",
    "fail": "red",
    "error": "red",
    "detail": "cyan",
    "debug": "cyan",
    "meta": "blue",
}

class BizTextFormatter(logging.Formatter):
    def __init__(self, *, style: str, use_color: bool) -> None: ...
    def _colorize(self, record: logging.LogRecord, text: str) -> str: ...
    def _colorize_field(self, field: str, color: str) -> str: ...
    def format(self, record: logging.LogRecord) -> str: ...
```

### 4. LogContext (core/logctx.py)

日志上下文变量管理。

```python
# Context variables
_kind_var: ContextVar[str]
_trace_var: ContextVar[str]
_step_var: ContextVar[str]
_phase_var: ContextVar[str]
_span_id_var: ContextVar[str]
_parent_span_id_var: ContextVar[str]
_indent_var: ContextVar[int]
_req_path_var: ContextVar[str]
_req_method_var: ContextVar[str]

# Getters
def get_kind() -> str: ...
def get_trace_id() -> str: ...
def get_step() -> str: ...
def get_phase() -> str: ...
def get_span_id() -> str: ...
def get_parent_span_id() -> str: ...
def get_indent() -> int: ...

# Context managers
@contextmanager
def set_kind(kind: str) -> Iterator[None]: ...
@contextmanager
def set_trace_id(trace_id: str) -> Iterator[None]: ...
@contextmanager
def set_phase(phase: str) -> Iterator[None]: ...
@contextmanager
def set_step(step: str) -> Iterator[None]: ...
@contextmanager
def set_span(span_id: str, parent_span_id: str = "") -> Iterator[None]: ...
@contextmanager
def set_indent(level: int) -> Iterator[None]: ...
@contextmanager
def inc_indent(delta: int = 1) -> Iterator[None]: ...
```

## Data Models

### LogRecord 扩展字段

```python
@dataclass
class BizLogRecord:
    # 标准字段
    ts: str              # 时间戳
    level: str           # 日志级别
    logger: str          # logger 名称
    func: str            # 函数名
    line: int            # 行号
    message: str         # 日志消息
    
    # 业务字段
    kind: str            # 日志类型 (ok/warn/fail/user_action/meta/...)
    trace_id: str        # 追踪 ID
    span_id: str         # Span ID
    parent_span_id: str  # 父 Span ID
    phase: str           # 业务阶段
    step: str            # 业务步骤
    indent: int          # 缩进级别
    
    # 请求上下文
    req_method: str      # HTTP 方法
    req_path: str        # 请求路径
    
    # 结构化字段
    kv: Dict[str, Any]   # 键值对
```

### 日志输出格式

**Pipe 风格（默认）：**
```
2026-01-14 10:30:45 | INFO | notifier.worker:enqueue:180 | Notifier/入队 | ▶️ 通知入队 | trace_id=abc123
2026-01-14 10:30:45 | INFO | notifier.worker:enqueue:182 |   第1步/共4步 构建入队任务
2026-01-14 10:30:45 | INFO | notifier.worker:enqueue:185 |   第2步/共4步 计算 dedup 签名 | dedup_key=xxx
2026-01-14 10:30:45 | INFO | notifier.worker:enqueue:190 |   ✅ 完成 通知入队 | duration_ms=15 ok=1
```

**JSON 风格（文件）：**
```json
{"ts":"2026-01-14 10:30:45","level":"INFO","logger":"notifier.worker","func":"enqueue","line":180,"message":"▶️ 通知入队","kind":"user_action","trace_id":"abc123","phase":"Notifier","step":"入队","indent":0,"kv":{"domain":"Notifier","action":"入队"}}
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: BizLogger 方法输出正确的 emoji 和格式

*For any* 日志消息和 kv 参数，调用 BizLogger 的 `ok()`、`warn()`、`fail()`、`step()` 方法后，输出的日志消息应包含对应的 emoji 前缀（✅/⚠️/❌）和正确的消息格式。

**Validates: Requirements 1.2, 5.3**

### Property 2: BizLoggerAdapter 自动添加 emoji 前缀

*For any* 日志消息，调用 BizLoggerAdapter 的 `warning()` 方法后输出应包含 ⚠️ 前缀，调用 `error()` 方法后输出应包含 ❌ 前缀（除非消息已包含 emoji）。

**Validates: Requirements 1.3**

### Property 3: entry() 正确设置 logctx

*For any* domain 和 action 参数，在 `entry()` 上下文管理器内部，`get_phase()` 应返回 domain，`get_step()` 应返回 action。

**Validates: Requirements 2.1**

### Property 4: group() 缩进和汇总行为

*For any* group_title，在 `group()` 上下文管理器内部：
- 日志的 indent 应比外部增加 1
- 正常退出时应输出包含 ok/skip/fail 计数和 duration_ms 的汇总行
- 异常退出时应输出 ❌ 标记的汇总行并重新抛出异常

**Validates: Requirements 2.2, 2.3, 2.4**

### Property 5: span_id 链路追踪

*For any* 嵌套的 `group()` 调用，内层 group 的 parent_span_id 应等于外层 group 的 span_id，形成正确的调用链路。

**Validates: Requirements 2.5**

### Property 6: kv 参数传递和格式化

*For any* kv 参数字典，BizLogger 方法应将其传递到 LogRecord，BizTextFormatter 应将其格式化为 `key=value` 形式追加到日志行末尾。

**Validates: Requirements 3.1, 3.2**

### Property 7: JSON 格式输出

*For any* 包含 kv 字段的日志记录，JsonLineFormatter 应输出有效的 JSON 行，其中 kv 字段作为独立的 JSON 对象。

**Validates: Requirements 3.3**

### Property 8: 上下文自动注入

*For any* 设置了 trace_id、phase、step、indent、span_id 的上下文，所有日志记录应自动包含这些字段。

**Validates: Requirements 3.4**

### Property 9: AutoKVFilter 合并

*For any* LogRecord 的非标准属性（不在 _STD 和 _RESERVED 集合中），AutoKVFilter 应将其合并到 record.kv 字段。

**Validates: Requirements 3.5**

### Property 10: step() 步骤格式

*For any* i 和 total 参数，`step()` 方法应输出 "第{i}步/共{total}步" 格式的前缀。

**Validates: Requirements 4.1**

### Property 11: item 方法序号输出

*For any* i 和 total 参数，`ok_item()`、`warn_item()`、`fail_item()` 方法应输出包含 `({i}/{total})` 格式序号的日志。

**Validates: Requirements 4.2**

### Property 12: detail 环境变量控制

*For any* 日志消息，当 BIZ_DETAIL 环境变量未设置或为空时，`detail()` 和 `detail_step()` 方法不应输出日志；当设置为 "1" 或 "true" 时应输出日志。

**Validates: Requirements 4.3**

### Property 13: 采样输出

*For any* 批量项目日志，当 BIZ_ITEM_SAMPLE 启用时，只有头部（BIZ_ITEM_HEAD）和尾部（BIZ_ITEM_TAIL）的项目应被输出，中间项目应被跳过。

**Validates: Requirements 4.4, 9.2**

### Property 14: 颜色方案应用

*For any* 日志记录，BizTextFormatter 应根据 kind 字段应用正确的 ANSI 颜色代码：
- ok/success/user_action/run/fetch → 绿色
- warn/skip → 黄色
- fail/error → 红色
- detail/debug → 青色
- meta → 蓝色

**Validates: Requirements 5.1, 5.2**

### Property 15: 颜色禁用

*For any* 日志输出，当 LOG_COLOR=0 或输出目标非 TTY 时，输出不应包含 ANSI 颜色代码。

**Validates: Requirements 5.4**

### Property 16: 输出风格

*For any* 日志记录，当 LOG_STYLE=pipe 时应使用 `|` 分隔符格式，当 LOG_STYLE=classic 时应使用方括号格式。

**Validates: Requirements 5.5**

### Property 17: fail() 异常记录

*For any* 异常对象传递给 `fail()` 方法的 exc 参数，日志记录应包含异常类型、消息，并且 exc_info 应被设置以便输出堆栈。

**Validates: Requirements 8.1**

### Property 18: set_result() 覆盖

*For any* 在 `group()` 内调用 `set_result(level, msg, **kv)`，group 退出时的汇总行应使用指定的 level 和 msg，而非自动推断的值。

**Validates: Requirements 8.4**

### Property 19: warn() 节流

*For any* 相同 reason 字段的连续 `warn()` 调用，当 BIZ_THROTTLE_REASON 启用时，在 BIZ_THROTTLE_SECONDS 时间窗口内只有第一次调用应输出日志。

**Validates: Requirements 9.1**

### Property 20: 并发上下文隔离

*For any* 并发执行的协程，每个协程设置的 logctx 变量（trace_id、phase、step 等）应相互隔离，不会互相影响。

**Validates: Requirements 9.4**



## Error Handling

### 日志系统错误处理原则

1. **永不崩溃** - 日志系统的任何错误都不应导致业务流程中断
2. **静默降级** - 格式化失败时回退到简单字符串输出
3. **防御性编程** - 所有外部输入（kv 参数、环境变量）都需要类型检查和异常捕获

### 错误处理策略

```python
# 1. Filter 错误处理
class AutoKVFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        try:
            # ... 处理逻辑
        except Exception:
            # 永不阻止日志输出
            return True

# 2. Formatter 错误处理
class BizTextFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        try:
            # ... 格式化逻辑
        except Exception:
            # 回退到基本格式
            return f"{record.levelname}: {record.getMessage()}"

# 3. BizLogger 错误处理
class BizLogger:
    def _emit(self, level, msg, **kwargs):
        try:
            # ... 日志输出
        except Exception:
            # 静默失败，不影响业务
            pass
```

### 常见错误场景

| 场景 | 处理方式 |
|------|---------|
| kv 参数包含不可序列化对象 | 使用 `str()` 转换或跳过该字段 |
| 环境变量格式错误 | 使用默认值 |
| 文件日志写入失败 | 记录警告，继续控制台输出 |
| 上下文变量未设置 | 返回空字符串或默认值 |
| group() 内异常 | 输出失败汇总后重新抛出 |

## Testing Strategy

### 测试框架

- **单元测试**: pytest
- **属性测试**: hypothesis
- **Mock**: unittest.mock

### 测试分层

```
tests/
├── unit/
│   ├── test_bizlog.py           # BizLogger 单元测试
│   ├── test_bizlogger_adapter.py # Adapter 单元测试
│   ├── test_logging_setup.py    # Formatter/Filter 单元测试
│   └── test_logctx.py           # LogContext 单元测试
├── property/
│   ├── test_bizlog_properties.py    # BizLogger 属性测试
│   ├── test_formatter_properties.py # Formatter 属性测试
│   └── test_logctx_properties.py    # LogContext 属性测试
└── integration/
    └── test_logging_integration.py  # 集成测试
```

### 属性测试配置

```python
from hypothesis import given, strategies as st, settings

# 最小 100 次迭代
@settings(max_examples=100)
@given(
    msg=st.text(min_size=1, max_size=200),
    kv=st.dictionaries(
        keys=st.text(min_size=1, max_size=20).filter(str.isidentifier),
        values=st.one_of(st.text(), st.integers(), st.floats(allow_nan=False), st.booleans()),
        max_size=10
    )
)
def test_bizlogger_kv_property(msg, kv):
    """Feature: business-log-optimization, Property 6: kv 参数传递和格式化"""
    # ... 测试实现
```

### 测试覆盖要求

| 组件 | 单元测试 | 属性测试 |
|------|---------|---------|
| BizLogger | ✅ 所有公开方法 | ✅ Property 1, 4, 6, 10, 11, 17, 18 |
| BizLoggerAdapter | ✅ warning/error | ✅ Property 2 |
| LogContext | ✅ 所有 getter/setter | ✅ Property 3, 5, 8, 20 |
| BizTextFormatter | ✅ format 方法 | ✅ Property 14, 15, 16 |
| JsonLineFormatter | ✅ format 方法 | ✅ Property 7 |
| AutoKVFilter | ✅ filter 方法 | ✅ Property 9 |
| 采样逻辑 | ✅ _should_log_item | ✅ Property 13 |
| 节流逻辑 | ✅ _throttle_allow | ✅ Property 19 |
| detail 控制 | ✅ is_detail_enabled | ✅ Property 12 |

### Mock 策略

```python
# 捕获日志输出
import logging
from io import StringIO

def capture_logs(logger_name: str):
    """捕获指定 logger 的输出"""
    stream = StringIO()
    handler = logging.StreamHandler(stream)
    handler.setFormatter(BizTextFormatter(style="pipe", use_color=False))
    logger = logging.getLogger(logger_name)
    logger.addHandler(handler)
    return stream, handler

# 模拟环境变量
import os
from unittest.mock import patch

@patch.dict(os.environ, {"BIZ_DETAIL": "1"})
def test_detail_enabled():
    # ...
```

### 并发测试

```python
import asyncio
from hypothesis import given, strategies as st

@given(trace_ids=st.lists(st.text(min_size=8, max_size=16), min_size=2, max_size=10))
async def test_concurrent_context_isolation(trace_ids):
    """Feature: business-log-optimization, Property 20: 并发上下文隔离"""
    results = {}
    
    async def worker(tid: str):
        with set_trace_id(tid):
            await asyncio.sleep(0.001)  # 模拟异步操作
            results[tid] = get_trace_id()
    
    await asyncio.gather(*[worker(tid) for tid in trace_ids])
    
    for tid in trace_ids:
        assert results[tid] == tid, f"Context leaked: expected {tid}, got {results[tid]}"
```
