# Implementation Plan: Business Log Optimization

## Overview

本实现计划将项目日志系统优化为详细的业务日志。主要工作包括：
1. 增强现有日志基础设施（颜色方案、格式化）
2. 为各业务模块迁移到 BizLogger/BizLoggerAdapter
3. 编写属性测试验证正确性

## Tasks

- [x] 1. 增强日志格式化器颜色方案
  - [x] 1.1 扩展 BizTextFormatter 颜色映射
    - 在 `core/logging_setup.py` 中添加 cyan、blue 颜色定义
    - 添加 _KIND_COLORS 映射表
    - 更新 _colorize() 方法支持更多 kind 类型
    - _Requirements: 5.1, 5.2_
  - [x] 1.2 编写颜色方案属性测试
    - **Property 14: 颜色方案应用**
    - **Validates: Requirements 5.1, 5.2**
  - [x] 1.3 添加 LOG_COLOR_SCHEME 环境变量支持
    - 支持自定义颜色方案配置
    - _Requirements: 5.6_

- [x] 2. 增强 BizLogger 功能
  - [x] 2.1 添加 info() 方法的 emoji 支持
    - 添加 ℹ️ 信息 emoji
    - _Requirements: 5.3_
  - [x] 2.2 编写 BizLogger 方法属性测试
    - **Property 1: BizLogger 方法输出正确的 emoji 和格式**
    - **Validates: Requirements 1.2, 5.3**
  - [x] 2.3 编写 step() 格式属性测试
    - **Property 10: step() 步骤格式**
    - **Validates: Requirements 4.1**
  - [x] 2.4 编写 item 方法属性测试
    - **Property 11: item 方法序号输出**
    - **Validates: Requirements 4.2**

- [x] 3. 增强 group() 和 entry() 功能
  - [x] 3.1 编写 group() 缩进和汇总属性测试
    - **Property 4: group() 缩进和汇总行为**
    - **Validates: Requirements 2.2, 2.3, 2.4**
  - [x] 3.2 编写 entry() 上下文属性测试
    - **Property 3: entry() 正确设置 logctx**
    - **Validates: Requirements 2.1**
  - [x] 3.3 编写 span_id 链路追踪属性测试
    - **Property 5: span_id 链路追踪**
    - **Validates: Requirements 2.5**
  - [x] 3.4 编写 set_result() 覆盖属性测试
    - **Property 18: set_result() 覆盖**
    - **Validates: Requirements 8.4**

- [x] 4. Checkpoint - 核心功能测试
  - 确保所有核心功能测试通过，如有问题请询问用户

- [x] 5. 增强结构化日志功能
  - [x] 5.1 编写 kv 参数属性测试
    - **Property 6: kv 参数传递和格式化**
    - **Validates: Requirements 3.1, 3.2**
  - [x] 5.2 编写 JSON 格式输出属性测试
    - **Property 7: JSON 格式输出**
    - **Validates: Requirements 3.3**
  - [x] 5.3 编写上下文自动注入属性测试
    - **Property 8: 上下文自动注入**
    - **Validates: Requirements 3.4**
  - [x] 5.4 编写 AutoKVFilter 属性测试
    - **Property 9: AutoKVFilter 合并**
    - **Validates: Requirements 3.5**

- [x] 6. 增强 BizLoggerAdapter
  - [x] 6.1 编写 Adapter emoji 前缀属性测试
    - **Property 2: BizLoggerAdapter 自动添加 emoji 前缀**
    - **Validates: Requirements 1.3**

- [x] 7. 增强环境变量控制功能
  - [x] 7.1 编写 detail 环境变量控制属性测试
    - **Property 12: detail 环境变量控制**
    - **Validates: Requirements 4.3**
  - [x] 7.2 编写采样输出属性测试
    - **Property 13: 采样输出**
    - **Validates: Requirements 4.4, 9.2**
  - [x] 7.3 编写颜色禁用属性测试
    - **Property 15: 颜色禁用**
    - **Validates: Requirements 5.4**
  - [x] 7.4 编写输出风格属性测试
    - **Property 16: 输出风格**
    - **Validates: Requirements 5.5**

- [x] 8. 增强错误处理和性能功能
  - [x] 8.1 编写 fail() 异常记录属性测试
    - **Property 17: fail() 异常记录**
    - **Validates: Requirements 8.1**
  - [x] 8.2 编写 warn() 节流属性测试
    - **Property 19: warn() 节流**
    - **Validates: Requirements 9.1**
  - [x] 8.3 编写并发上下文隔离属性测试
    - **Property 20: 并发上下文隔离**
    - **Validates: Requirements 9.4**

- [x] 9. Checkpoint - 属性测试完成
  - 确保所有属性测试通过，如有问题请询问用户

- [x] 10. 迁移 Notifier 模块
  - [x] 10.1 迁移 notifier/worker.py
    - 确保使用 BizLogger 的 entry()、group()、step() 模式
    - 统一错误处理日志格式
    - _Requirements: 6.1_
  - [x] 10.2 迁移 notifier/service/ 目录
    - 迁移 pipeline 相关模块
    - _Requirements: 6.1_

- [x] 11. 迁移 TG Bot 模块
  - [x] 11.1 迁移 tg_bot/app/ 目录
    - 迁移 router.py、parse_urls.py、handlers_share.py、handlers_cloud115.py、command_router.py
    - 将 `logging.getLogger` 替换为 `get_biz_logger_adapter`
    - _Requirements: 6.2_
  - [x] 11.2 迁移 tg_bot/infra/ 目录
    - 迁移 telegram_api.py、polling.py、webhook_setup.py
    - 将 `logging.getLogger` 替换为 `get_biz_logger_adapter`
    - _Requirements: 6.2_
  - [x] 11.3 迁移 tg_bot/features/cloud115/ 目录
    - 迁移 service.py、persistence.py、offline_submit_usecase.py、offline_submit_poll.py、templates.py
    - 将 `logging.getLogger` 替换为 `get_biz_logger_adapter`
    - _Requirements: 6.2_
  - [x] 11.4 迁移 tg_bot/common/parser.py
    - 将 `logging.getLogger` 替换为 `get_biz_logger_adapter`
    - _Requirements: 6.2_

- [x] 12. 迁移 Hotlist 模块
  - [x] 12.1 迁移 douban_hotlist/poller.py
    - 已使用 BizLogger 和 BizLoggerAdapter
    - _Requirements: 6.3_
  - [x] 12.2 迁移 douban_hotlist/ 其他文件
    - backfill.py、client.py、notify.py、parser.py、resolver.py、rules.py、store.py、utils.py 已迁移
    - _Requirements: 6.3_

- [x] 13. 迁移 TMDB Match 模块
  - [x] 13.1 迁移 integrations/tmdb_match/ 目录
    - 迁移 client.py、search.py、tmdb_match_core.py、tmdb_match_guess.py
    - 将 `logging.getLogger` 替换为 `get_biz_logger_adapter`
    - _Requirements: 6.4_

- [x] 14. 迁移 Share115 模块
  - [x] 14.1 迁移 integrations/share115/ 目录
    - share115_client.py、share115_errors.py、share115_extract.py、share115_limits.py、share115_resolve.py、share115_url.py 已迁移
    - _Requirements: 6.5_

- [x] 15. 迁移 Forward Bridge 模块
  - [x] 15.1 迁移 forward_bridge/ 目录
    - 迁移 config.py、http_client.py、subscription_api.py
    - 将 `logging.getLogger` 替换为 `get_biz_logger_adapter`
    - _Requirements: 6.6_

- [x] 16. Checkpoint - 模块迁移完成
  - 确保所有模块迁移完成，运行集成测试验证
  - 如有问题请询问用户

- [x] 17. 最终验证
  - [x] 17.1 运行完整测试套件
    - 确保所有单元测试和属性测试通过
  - [x] 17.2 验证日志输出格式
    - 手动检查各模块的日志输出是否符合预期

## Notes

- 所有任务均为必需任务，确保全面测试覆盖
- 每个属性测试任务对应设计文档中的一个 Correctness Property
- 模块迁移任务应保持向后兼容，不破坏现有功能
- Checkpoint 任务用于阶段性验证，确保增量开发的稳定性
