# Implementation Plan: Database Connection Pool

## Overview

实现 SQLite 数据库连接池，支持同步和异步两种模式，提供连接复用、健康检查和优雅关闭功能。

## Tasks

- [x] 1. 创建目录结构和配置模块
  - 创建 `core/db/` 目录
  - 创建 `core/db/__init__.py` 导出公共接口
  - 创建 `core/db/pool_config.py` 实现 `PoolConfig` 数据类
  - 支持环境变量覆盖：`DB_POOL_MIN_SIZE`, `DB_POOL_MAX_SIZE`, `DB_POOL_MAX_IDLE_TIME`, `DB_POOL_TIMEOUT`
  - _Requirements: 3.1, 3.2, 3.3, 3.4_

- [x] 2. 实现同步连接池
  - 创建 `core/db/sync_pool.py`
  - 实现 `SyncConnectionPool` 类（线程安全）
  - 实现 `acquire()`, `release()`, `connection()` 上下文管理器
  - 实现健康检查和 `close()` 方法
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 4.1, 4.2, 5.1, 5.3, 5.4_

- [x] 3. 实现异步连接池
  - 创建 `core/db/async_pool.py`
  - 实现 `AsyncConnectionPool` 类
  - 实现异步 `acquire()`, `release()`, `connection()` 上下文管理器
  - 实现异步健康检查和 `close()` 方法
  - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 5.2, 5.3, 5.4_

- [x] 4. 实现全局池管理器
  - 创建 `core/db/pool_manager.py`
  - 实现 `get_sync_pool()`, `get_async_pool()` 获取或创建池
  - 实现 `close_all_pools()`, `close_all_async_pools()` 关闭所有池
  - 实现 `get_all_pool_stats()` 获取所有池统计
  - _Requirements: 7.1, 8.1, 8.2_

- [x] 5. 编写属性测试 - 线程安全
  - [x] 5.1 创建 `tests/test_db_pool_properties.py`
  - [x] 5.2 编写 Property 1: 同步连接池线程安全测试
    - **Property 1: 同步连接池线程安全**
    - **Validates: Requirements 1.2, 1.3**
  - _Requirements: 1.2, 1.3_

- [x] 6. 编写属性测试 - 连接复用
  - [x] 6.1 编写 Property 2: 连接复用测试
    - **Property 2: 连接复用**
    - **Validates: Requirements 1.4, 2.4**
  - _Requirements: 1.4, 2.4_

- [x] 7. 编写属性测试 - 健康检查
  - [x] 7.1 编写 Property 3: 健康检查测试
    - **Property 3: 健康检查**
    - **Validates: Requirements 1.5, 1.6, 4.1, 4.2**
  - _Requirements: 1.5, 1.6, 4.1, 4.2_

- [x] 8. 编写属性测试 - 上下文管理器
  - [x] 8.1 编写 Property 5: 上下文管理器行为测试
    - **Property 5: 上下文管理器行为**
    - **Validates: Requirements 5.3, 5.4**
  - _Requirements: 5.3, 5.4_

- [x] 9. 编写属性测试 - 指标准确性
  - [x] 9.1 编写 Property 6: 指标准确性测试
    - **Property 6: 指标准确性**
    - **Validates: Requirements 7.1**
  - _Requirements: 7.1_

- [x] 10. 编写属性测试 - 优雅关闭
  - [x] 10.1 编写 Property 7: 优雅关闭测试
    - **Property 7: 优雅关闭**
    - **Validates: Requirements 8.1, 8.2**
  - _Requirements: 8.1, 8.2_

- [x] 11. 迁移 tg_bot/storage/db.py
  - 修改 `_conn()` 函数使用连接池
  - 保持现有 API 兼容性
  - 添加 `close_db()` 函数
  - _Requirements: 6.1, 6.2, 6.3_

- [x] 12. 迁移 core/cache/persist_cache.py
  - 修改数据库连接使用连接池
  - 保持现有 API 兼容性
  - _Requirements: 6.1, 6.2, 6.3_

- [x] 13. 集成监控指标
  - 集成到现有 metrics 端点
  - 添加池耗尽警告日志
  - _Requirements: 7.2, 7.3_

- [x] 14. 集成应用生命周期
  - 在 `app.py` 的 lifespan 中添加池关闭逻辑
  - 验证应用关闭时池正确清理
  - _Requirements: 8.3_

- [x] 15. 编写迁移文档
  - 创建 `docs/database-pool-migration.md`
  - 包含使用方法、配置说明、迁移步骤
  - _Requirements: 6.4_

- [x] 16. 运行完整测试套件
  - 运行所有属性测试
  - 运行现有数据库相关测试
  - 验证所有测试通过

## Notes

- 每个属性测试运行 100 次迭代
- 使用 hypothesis 库进行属性测试
- 所有任务都是必需的（无可选标记）
