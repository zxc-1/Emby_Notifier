# Design Document: Database Connection Pool

## Overview

本设计文档描述数据库连接池的技术方案。核心目标是通过连接复用提高数据库操作效率，支持同步和异步两种模式。

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      Application Layer                       │
│  (tg_bot/storage, core/cache/persist_cache, etc.)           │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    Connection Pool Layer                     │
│  ┌─────────────────────┐  ┌─────────────────────────────┐   │
│  │    SyncPool         │  │       AsyncPool             │   │
│  │  (sqlite3 based)    │  │    (aiosqlite based)        │   │
│  └─────────────────────┘  └─────────────────────────────┘   │
│  ┌─────────────────────┐  ┌─────────────────────────────┐   │
│  │   PoolConfig        │  │      PoolMetrics            │   │
│  │  (settings)         │  │    (monitoring)             │   │
│  └─────────────────────┘  └─────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                      SQLite Database                         │
└─────────────────────────────────────────────────────────────┘
```

## Components and Interfaces

### 1. 连接池配置 (`core/db/pool_config.py`)

```python
from dataclasses import dataclass
from typing import Optional
import os

@dataclass(frozen=True)
class PoolConfig:
    """连接池配置"""
    min_size: int = 1           # 最小连接数
    max_size: int = 10          # 最大连接数
    max_idle_time: float = 300  # 空闲连接最大存活时间（秒）
    connection_timeout: float = 30  # 获取连接超时（秒）
    health_check_interval: float = 60  # 健康检查间隔（秒）
    
    @classmethod
    def from_env(cls) -> "PoolConfig":
        """从环境变量加载配置"""
        return cls(
            min_size=int(os.getenv("DB_POOL_MIN_SIZE", "1")),
            max_size=int(os.getenv("DB_POOL_MAX_SIZE", "10")),
            max_idle_time=float(os.getenv("DB_POOL_MAX_IDLE_TIME", "300")),
            connection_timeout=float(os.getenv("DB_POOL_TIMEOUT", "30")),
        )
```

### 2. 同步连接池 (`core/db/sync_pool.py`)

```python
import sqlite3
import threading
import time
from queue import Queue, Empty
from typing import Optional, Callable
from contextlib import contextmanager

class SyncConnectionPool:
    """线程安全的同步 SQLite 连接池"""
    
    def __init__(self, db_path: str, config: PoolConfig):
        self._db_path = db_path
        self._config = config
        self._pool: Queue[tuple[sqlite3.Connection, float]] = Queue()
        self._lock = threading.Lock()
        self._active_count = 0
        self._total_created = 0
        self._total_reused = 0
        self._closed = False
        
        # 预创建最小连接数
        for _ in range(config.min_size):
            conn = self._create_connection()
            self._pool.put((conn, time.time()))
    
    def _create_connection(self) -> sqlite3.Connection:
        """创建新连接"""
        conn = sqlite3.connect(
            self._db_path,
            check_same_thread=False,
            timeout=self._config.connection_timeout,
        )
        # 设置 pragmas
        conn.execute("PRAGMA journal_mode=WAL;")
        conn.execute("PRAGMA synchronous=NORMAL;")
        conn.execute("PRAGMA foreign_keys=ON;")
        conn.execute(f"PRAGMA busy_timeout={int(self._config.connection_timeout * 1000)};")
        
        with self._lock:
            self._total_created += 1
        return conn
    
    def _is_healthy(self, conn: sqlite3.Connection) -> bool:
        """检查连接是否健康"""
        try:
            conn.execute("SELECT 1").fetchone()
            return True
        except sqlite3.Error:
            return False
    
    def acquire(self) -> sqlite3.Connection:
        """获取连接"""
        if self._closed:
            raise RuntimeError("Pool is closed")
        
        # 尝试从池中获取
        while True:
            try:
                conn, created_at = self._pool.get_nowait()
                # 检查是否过期
                if time.time() - created_at > self._config.max_idle_time:
                    conn.close()
                    continue
                # 健康检查
                if not self._is_healthy(conn):
                    conn.close()
                    continue
                with self._lock:
                    self._active_count += 1
                    self._total_reused += 1
                return conn
            except Empty:
                break
        
        # 创建新连接
        with self._lock:
            if self._active_count >= self._config.max_size:
                raise RuntimeError("Pool exhausted")
            self._active_count += 1
        
        return self._create_connection()
    
    def release(self, conn: sqlite3.Connection, *, discard: bool = False) -> None:
        """释放连接回池"""
        with self._lock:
            self._active_count -= 1
        
        if discard or self._closed:
            conn.close()
            return
        
        # 检查池是否已满
        if self._pool.qsize() >= self._config.max_size:
            conn.close()
            return
        
        self._pool.put((conn, time.time()))
    
    @contextmanager
    def connection(self, *, auto_commit: bool = True):
        """上下文管理器获取连接"""
        conn = self.acquire()
        discard = False
        try:
            yield conn
            if auto_commit:
                conn.commit()
        except Exception:
            conn.rollback()
            discard = True
            raise
        finally:
            self.release(conn, discard=discard)
    
    def close(self, timeout: float = 5.0) -> None:
        """关闭连接池"""
        self._closed = True
        deadline = time.time() + timeout
        
        # 等待活跃连接释放
        while self._active_count > 0 and time.time() < deadline:
            time.sleep(0.1)
        
        # 关闭池中所有连接
        while True:
            try:
                conn, _ = self._pool.get_nowait()
                conn.close()
            except Empty:
                break
    
    @property
    def stats(self) -> dict:
        """获取池统计信息"""
        return {
            "active": self._active_count,
            "idle": self._pool.qsize(),
            "total_created": self._total_created,
            "total_reused": self._total_reused,
        }
```

### 3. 异步连接池 (`core/db/async_pool.py`)

```python
import asyncio
import aiosqlite
import time
from typing import Optional
from contextlib import asynccontextmanager

class AsyncConnectionPool:
    """异步 SQLite 连接池"""
    
    def __init__(self, db_path: str, config: PoolConfig):
        self._db_path = db_path
        self._config = config
        self._pool: asyncio.Queue[tuple[aiosqlite.Connection, float]] = asyncio.Queue()
        self._lock = asyncio.Lock()
        self._active_count = 0
        self._total_created = 0
        self._total_reused = 0
        self._closed = False
    
    async def _create_connection(self) -> aiosqlite.Connection:
        """创建新连接"""
        conn = await aiosqlite.connect(self._db_path)
        await conn.execute("PRAGMA journal_mode=WAL;")
        await conn.execute("PRAGMA synchronous=NORMAL;")
        await conn.execute("PRAGMA foreign_keys=ON;")
        
        async with self._lock:
            self._total_created += 1
        return conn
    
    async def _is_healthy(self, conn: aiosqlite.Connection) -> bool:
        """检查连接是否健康"""
        try:
            await conn.execute("SELECT 1")
            return True
        except Exception:
            return False
    
    async def acquire(self) -> aiosqlite.Connection:
        """获取连接"""
        if self._closed:
            raise RuntimeError("Pool is closed")
        
        # 尝试从池中获取
        while True:
            try:
                conn, created_at = self._pool.get_nowait()
                if time.time() - created_at > self._config.max_idle_time:
                    await conn.close()
                    continue
                if not await self._is_healthy(conn):
                    await conn.close()
                    continue
                async with self._lock:
                    self._active_count += 1
                    self._total_reused += 1
                return conn
            except asyncio.QueueEmpty:
                break
        
        # 创建新连接
        async with self._lock:
            if self._active_count >= self._config.max_size:
                raise RuntimeError("Pool exhausted")
            self._active_count += 1
        
        return await self._create_connection()
    
    async def release(self, conn: aiosqlite.Connection, *, discard: bool = False) -> None:
        """释放连接回池"""
        async with self._lock:
            self._active_count -= 1
        
        if discard or self._closed:
            await conn.close()
            return
        
        if self._pool.qsize() >= self._config.max_size:
            await conn.close()
            return
        
        await self._pool.put((conn, time.time()))
    
    @asynccontextmanager
    async def connection(self, *, auto_commit: bool = True):
        """异步上下文管理器获取连接"""
        conn = await self.acquire()
        discard = False
        try:
            yield conn
            if auto_commit:
                await conn.commit()
        except Exception:
            await conn.rollback()
            discard = True
            raise
        finally:
            await self.release(conn, discard=discard)
    
    async def close(self, timeout: float = 5.0) -> None:
        """关闭连接池"""
        self._closed = True
        deadline = time.time() + timeout
        
        while self._active_count > 0 and time.time() < deadline:
            await asyncio.sleep(0.1)
        
        while True:
            try:
                conn, _ = self._pool.get_nowait()
                await conn.close()
            except asyncio.QueueEmpty:
                break
```

### 4. 全局池管理 (`core/db/pool_manager.py`)

```python
from typing import Optional
import threading

_sync_pools: dict[str, SyncConnectionPool] = {}
_async_pools: dict[str, AsyncConnectionPool] = {}
_lock = threading.Lock()

def get_sync_pool(db_path: str, config: Optional[PoolConfig] = None) -> SyncConnectionPool:
    """获取或创建同步连接池"""
    with _lock:
        if db_path not in _sync_pools:
            cfg = config or PoolConfig.from_env()
            _sync_pools[db_path] = SyncConnectionPool(db_path, cfg)
        return _sync_pools[db_path]

async def get_async_pool(db_path: str, config: Optional[PoolConfig] = None) -> AsyncConnectionPool:
    """获取或创建异步连接池"""
    if db_path not in _async_pools:
        cfg = config or PoolConfig.from_env()
        _async_pools[db_path] = AsyncConnectionPool(db_path, cfg)
    return _async_pools[db_path]

def close_all_pools() -> None:
    """关闭所有连接池"""
    for pool in _sync_pools.values():
        pool.close()
    _sync_pools.clear()

async def close_all_async_pools() -> None:
    """关闭所有异步连接池"""
    for pool in _async_pools.values():
        await pool.close()
    _async_pools.clear()
```

## Data Models

### PoolConfig
```python
@dataclass
class PoolConfig:
    min_size: int           # 最小连接数
    max_size: int           # 最大连接数
    max_idle_time: float    # 空闲连接最大存活时间
    connection_timeout: float  # 获取连接超时
```

### PoolStats
```python
@dataclass
class PoolStats:
    active: int             # 活跃连接数
    idle: int               # 空闲连接数
    total_created: int      # 总创建数
    total_reused: int       # 总复用数
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system.*

### Property 1: 同步连接池线程安全

*For any* 并发线程数 N，同时获取连接时，活跃连接数不应超过 max_size，且不应出现竞态条件。

**Validates: Requirements 1.2, 1.3**

### Property 2: 连接复用

*For any* 连接获取-释放序列，释放后的健康连接应该被后续请求复用，而不是创建新连接。

**Validates: Requirements 1.4, 2.4**

### Property 3: 健康检查

*For any* 从池中获取的连接，如果健康检查失败，应该被丢弃并创建新连接。

**Validates: Requirements 1.5, 1.6, 4.1, 4.2**

### Property 4: 配置生效

*For any* 配置参数，环境变量覆盖应该优先于默认值；无效配置应该回退到默认值。

**Validates: Requirements 3.1, 3.2, 3.4**

### Property 5: 上下文管理器行为

*For any* 使用上下文管理器的代码块，正常退出时应该提交事务并释放连接；异常退出时应该回滚事务并释放连接。

**Validates: Requirements 5.3, 5.4**

### Property 6: 指标准确性

*For any* 连接池操作序列，统计指标（active, idle, total_created, total_reused）应该准确反映实际状态。

**Validates: Requirements 7.1**

### Property 7: 优雅关闭

*For any* 关闭操作，应该等待活跃连接释放（带超时），然后关闭所有池中连接。

**Validates: Requirements 8.1, 8.2**

## Error Handling

### 连接获取错误
- 池耗尽：抛出 RuntimeError，记录当前池状态
- 连接创建失败：传播原始异常

### 连接使用错误
- 执行错误：回滚事务，标记连接为无效
- 连接断开：丢弃连接，下次获取时创建新连接

### 关闭错误
- 超时未释放：强制关闭剩余连接，记录警告

## Testing Strategy

### 单元测试
- 测试连接池创建和配置
- 测试连接获取和释放
- 测试健康检查
- 测试上下文管理器

### 属性测试
- **Property 1**: 多线程并发获取连接
- **Property 2**: 连接复用验证
- **Property 3**: 模拟失效连接
- **Property 5**: 异常场景测试
- **Property 6**: 指标准确性验证

### 测试配置
- 每个属性测试运行 100 次迭代
