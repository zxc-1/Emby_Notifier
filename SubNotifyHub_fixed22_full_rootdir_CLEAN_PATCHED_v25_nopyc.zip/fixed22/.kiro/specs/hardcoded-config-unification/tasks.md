# Implementation Plan: Hardcoded Config Unification

## Overview

本实现计划将代码中的硬编码配置值统一管理。实现分为配置模块创建、属性测试、代码迁移、文档更新四个阶段。

## Tasks

- [x] 1. 创建超时配置模块
  - [x] 1.1 创建 `settings/timeouts.py`
    - 定义 TimeoutCategory 枚举
    - 定义默认值映射 _TIMEOUT_DEFAULTS
    - 实现 get_timeout() 函数
    - 实现 get_db_busy_timeout_ms() 函数
    - _Requirements: 1.1, 1.2, 1.3, 1.4_
  - [x] 1.2 编写超时配置属性测试
    - **Property 1: 超时配置获取**
    - **Validates: Requirements 1.3, 1.4**

- [x] 2. 创建重试配置模块
  - [x] 2.1 创建 `settings/retries.py`
    - 定义 RetryCategory 枚举
    - 定义 RetryConfig 数据类
    - 定义默认值映射 _RETRY_DEFAULTS
    - 实现 get_retry_config() 函数
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5_
  - [x] 2.2 编写重试配置属性测试
    - **Property 2: 重试配置获取**
    - **Validates: Requirements 2.3, 2.4, 2.5**

- [x] 3. 创建缓存配置模块
  - [x] 3.1 创建 `settings/caches.py`
    - 定义 CacheTTL 和 CacheSize 枚举
    - 定义 CacheConfig 数据类
    - 定义默认值映射
    - 实现 get_cache_ttl(), get_cache_size(), get_cache_config() 函数
    - _Requirements: 3.1, 3.2, 3.3, 3.4_
  - [x] 3.2 编写缓存配置属性测试
    - **Property 3: 缓存配置获取**
    - **Validates: Requirements 3.3, 3.4**

- [x] 4. 创建数据库配置模块
  - [x] 4.1 创建 `settings/database.py`
    - 定义 DBConfig 枚举
    - 定义默认值映射 _DB_DEFAULTS
    - 实现 get_db_config() 函数
    - _Requirements: 4.1, 4.2, 4.3, 4.4_
  - [x] 4.2 编写数据库配置属性测试
    - **Property 4: 数据库配置获取**
    - **Validates: Requirements 4.3, 4.4**

- [x] 5. Checkpoint - 配置模块测试
  - 确保所有配置模块测试通过，如有问题请询问用户

- [x] 6. 编写配置验证属性测试
  - [x] 6.1 编写配置验证属性测试
    - **Property 5: 配置验证**
    - **Validates: Requirements 6.1, 6.2, 6.3, 6.4**
  - [x] 6.2 编写默认值保持属性测试
    - **Property 6: 默认值保持**
    - **Validates: Requirements 5.5, 8.1**

- [x] 7. 迁移 core 模块硬编码值
  - [x] 7.1 迁移 `core/http_clients.py`
    - 替换 timeout=10.0 为 get_timeout(TimeoutCategory.HTTP_DEFAULT)
    - _Requirements: 5.1_
  - [x] 7.2 迁移 `core/http_retry.py`
    - 替换硬编码超时和重试值
    - _Requirements: 5.1, 5.2_
  - [x] 7.3 迁移 `core/persist_cache.py`
    - 替换 timeout=30, busy_timeout=5000 为配置引用
    - _Requirements: 5.4_

- [x] 8. 迁移 tg_bot 模块硬编码值
  - [x] 8.1 迁移 `tg_bot/storage/db.py`
    - 替换 timeout=30, busy_timeout=5000 为配置引用
    - _Requirements: 5.4_
  - [x] 8.2 迁移 `tg_bot/storage/tables/*.py`
    - 替换 retries=3, retries=2 为配置引用
    - _Requirements: 5.2_
  - [x] 8.3 迁移 `tg_bot/infra/telegram_api.py`
    - 替换 timeout=12.0, max_attempts=3 为配置引用
    - _Requirements: 5.1, 5.2_
  - [x] 8.4 迁移 `tg_bot/infra/webhook_setup.py`
    - 替换 timeout=15.0, max_attempts=3 为配置引用
    - _Requirements: 5.1, 5.2_

- [x] 9. Checkpoint - tg_bot 迁移测试
  - 确保 tg_bot 模块迁移后测试通过，如有问题请询问用户

- [x] 10. 迁移 integrations 模块硬编码值
  - [x] 10.1 迁移 `integrations/tmdb_match/*.py`
    - 替换 timeout=8.0, max_attempts=3 为配置引用
    - _Requirements: 5.1, 5.2_
  - [x] 10.2 迁移 `integrations/tmdb_gateway.py`
    - 替换 timeout=10.0 为配置引用
    - _Requirements: 5.1_
  - [x] 10.3 迁移 `integrations/cloud115/qrcode.py`
    - 替换 timeout=15.0, timeout=10.0, max_attempts=3 为配置引用
    - _Requirements: 5.1, 5.2_

- [x] 11. 迁移 forward_bridge 模块硬编码值
  - [x] 11.1 迁移 `forward_bridge/mh_api.py`
    - 替换 timeout=15, timeout=30 为配置引用
    - _Requirements: 5.1_
  - [x] 11.2 迁移 `forward_bridge/sub_ops.py`
    - 替换 timeout=30 为配置引用
    - _Requirements: 5.1_
  - [x] 11.3 迁移 `forward_bridge/auth.py`
    - 替换 timeout=15.0, max_attempts=3 为配置引用
    - _Requirements: 5.1, 5.2_

- [x] 12. 迁移 notifier 模块硬编码值
  - [x] 12.1 迁移 `notifier/service/emby.py`
    - 替换 timeout=8.0 为配置引用
    - _Requirements: 5.1_
  - [x] 12.2 迁移 `notifier/telegram/telegram_media.py`
    - 替换 timeout=12.0 为配置引用
    - _Requirements: 5.1_
  - [x] 12.3 迁移 `notifier/telegram/telegram_notifier.py`
    - 替换 timeout=20.0 为配置引用
    - _Requirements: 5.1_
  - [x] 12.4 迁移 `notifier/worker.py`
    - 替换 timeout=1.0 为配置引用
    - _Requirements: 5.1_

- [x] 13. Checkpoint - 全部迁移测试
  - 确保所有模块迁移后测试通过，如有问题请询问用户

- [x] 14. 更新配置文档
  - [x] 14.1 更新 `docs/SETTINGS.md`
    - 添加超时配置说明
    - 添加重试配置说明
    - 添加缓存配置说明
    - 添加数据库配置说明
    - 包含默认值、有效范围、使用示例
    - _Requirements: 7.1, 7.2, 7.3_
  - [x] 14.2 创建迁移指南
    - 在 docs/ 目录创建 CONFIG_MIGRATION.md
    - 说明如何从旧配置迁移到新配置
    - _Requirements: 8.3_

- [x] 15. 最终验证
  - [x] 15.1 运行完整测试套件
    - 确保所有单元测试和属性测试通过
  - [x] 15.2 验证默认值一致性
    - 确认所有默认值与原硬编码值一致
  - [x] 15.3 验证环境变量覆盖
    - 测试环境变量是否正确覆盖默认值

## Notes

- 所有任务均为必需任务，确保全面测试覆盖
- 每个属性测试任务对应设计文档中的一个 Correctness Property
- 迁移任务应保持向后兼容，默认值与原硬编码值一致
- Checkpoint 任务用于阶段性验证，确保增量开发的稳定性
- 迁移顺序：core → tg_bot → integrations → forward_bridge → notifier
