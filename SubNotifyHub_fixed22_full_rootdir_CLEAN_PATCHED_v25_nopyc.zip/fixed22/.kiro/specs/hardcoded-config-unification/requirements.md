# Requirements Document

## Introduction

本项目旨在统一管理代码中的硬编码配置值。当前代码中存在大量硬编码的超时值、重试次数、缓存大小等配置，分散在各个模块中，难以统一调整和维护。

主要问题：
- 超时值硬编码：`timeout=8.0`, `timeout=12.0`, `timeout=30` 等分散在 50+ 处
- 重试次数硬编码：`max_attempts=3`, `retries=3` 等分散在 30+ 处
- 缓存配置硬编码：TTL、大小限制等
- 数据库配置硬编码：`busy_timeout=5000`, `timeout=30` 等
- 难以针对不同环境调整配置

## Glossary

- **Timeout_Config**: 超时配置，包括 HTTP 超时、数据库超时、任务超时等
- **Retry_Config**: 重试配置，包括最大重试次数、退避策略等
- **Cache_Config**: 缓存配置，包括 TTL、大小限制等
- **Config_Provider**: 配置提供者，统一管理和提供配置值
- **Environment_Override**: 环境变量覆盖，允许通过环境变量调整配置

## Requirements

### Requirement 1: 创建统一的超时配置模块

**User Story:** 作为开发者，我希望所有超时值集中管理，以便统一调整和维护。

#### Acceptance Criteria

1. THE System SHALL create a `settings/timeouts.py` module containing all timeout configurations
2. THE System SHALL define timeout categories: HTTP_DEFAULT, HTTP_LONG, HTTP_SHORT, DB_CONNECT, DB_BUSY, TASK_DEFAULT, TASK_LONG
3. THE System SHALL support environment variable overrides for each timeout category
4. WHEN a timeout value is needed, THE System SHALL provide it via `get_timeout(category)` function

### Requirement 2: 创建统一的重试配置模块

**User Story:** 作为开发者，我希望所有重试配置集中管理，以便统一调整重试策略。

#### Acceptance Criteria

1. THE System SHALL create a `settings/retries.py` module containing all retry configurations
2. THE System SHALL define retry categories: HTTP_DEFAULT, HTTP_CRITICAL, DB_DEFAULT, TG_API, EXTERNAL_SERVICE
3. THE System SHALL support environment variable overrides for each retry category
4. WHEN a retry configuration is needed, THE System SHALL provide it via `get_retry_config(category)` function
5. THE System SHALL include max_retries, backoff_base, backoff_max for each category

### Requirement 3: 创建统一的缓存配置模块

**User Story:** 作为开发者，我希望所有缓存配置集中管理，以便统一调整缓存策略。

#### Acceptance Criteria

1. THE System SHALL create a `settings/caches.py` module containing all cache configurations
2. THE System SHALL define cache categories: TTL_SHORT, TTL_MEDIUM, TTL_LONG, SIZE_SMALL, SIZE_MEDIUM, SIZE_LARGE
3. THE System SHALL support environment variable overrides for each cache category
4. WHEN a cache configuration is needed, THE System SHALL provide it via `get_cache_config(category)` function

### Requirement 4: 创建统一的数据库配置模块

**User Story:** 作为开发者，我希望所有数据库配置集中管理，以便统一调整数据库行为。

#### Acceptance Criteria

1. THE System SHALL create a `settings/database.py` module containing all database configurations
2. THE System SHALL define configurations: CONNECT_TIMEOUT, BUSY_TIMEOUT, RETRY_COUNT, WAL_MODE
3. THE System SHALL support environment variable overrides for each configuration
4. WHEN a database configuration is needed, THE System SHALL provide it via `get_db_config(key)` function

### Requirement 5: 迁移现有硬编码值

**User Story:** 作为开发者，我希望现有的硬编码值被替换为配置引用。

#### Acceptance Criteria

1. THE System SHALL replace all hardcoded timeout values with `get_timeout()` calls
2. THE System SHALL replace all hardcoded retry values with `get_retry_config()` calls
3. THE System SHALL replace all hardcoded cache values with `get_cache_config()` calls
4. THE System SHALL replace all hardcoded database values with `get_db_config()` calls
5. WHEN migrating, THE System SHALL preserve the original default values

### Requirement 6: 配置验证

**User Story:** 作为运维人员，我希望配置值被验证，以防止无效配置导致系统问题。

#### Acceptance Criteria

1. THE System SHALL validate timeout values are positive numbers
2. THE System SHALL validate retry counts are non-negative integers
3. THE System SHALL validate cache sizes are positive integers
4. WHEN an invalid configuration is detected, THE System SHALL log a warning and use default value

### Requirement 7: 配置文档

**User Story:** 作为运维人员，我希望有完整的配置文档，以便了解可调整的配置项。

#### Acceptance Criteria

1. THE System SHALL document all configurable values in `docs/SETTINGS.md`
2. THE System SHALL include default values, valid ranges, and usage descriptions
3. THE System SHALL provide example configurations for common scenarios

### Requirement 8: 向后兼容性

**User Story:** 作为开发者，我希望配置统一不破坏现有功能。

#### Acceptance Criteria

1. THE System SHALL maintain all existing default values
2. THE System SHALL ensure all existing tests pass after migration
3. THE System SHALL provide a migration guide for custom deployments

