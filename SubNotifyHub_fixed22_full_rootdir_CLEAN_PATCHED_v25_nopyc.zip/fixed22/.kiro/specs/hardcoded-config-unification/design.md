# Design Document: Hardcoded Config Unification

## Overview

本设计文档描述硬编码配置值统一的技术方案。核心目标是将分散在代码中的超时值、重试次数、缓存配置等集中管理，支持环境变量覆盖，提高配置的可维护性。

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      Application Layer                       │
│  (notifier, tg_bot, forward_bridge, integrations, etc.)     │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    Configuration Layer                       │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │  timeouts   │  │   retries   │  │      caches         │  │
│  │   .py       │  │    .py      │  │       .py           │  │
│  └─────────────┘  └─────────────┘  └─────────────────────┘  │
│  ┌─────────────┐  ┌─────────────────────────────────────┐   │
│  │  database   │  │           config_provider           │   │
│  │    .py      │  │              .py                    │   │
│  └─────────────┘  └─────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    Environment Variables                     │
│  TIMEOUT_HTTP_DEFAULT=10.0  RETRY_HTTP_MAX=3  etc.          │
└─────────────────────────────────────────────────────────────┘
```

## Components and Interfaces

### 1. 超时配置模块 (`settings/timeouts.py`)

```python
"""Timeout configurations - centralized timeout management."""

from enum import Enum
from typing import Optional
import os

from core.logging import get_biz_logger_adapter

logger = get_biz_logger_adapter(__name__)


class TimeoutCategory(str, Enum):
    """Timeout categories."""
    # HTTP timeouts
    HTTP_DEFAULT = "http_default"      # 默认 HTTP 超时
    HTTP_SHORT = "http_short"          # 短超时（快速失败）
    HTTP_LONG = "http_long"            # 长超时（大文件、慢接口）
    
    # Database timeouts
    DB_CONNECT = "db_connect"          # 数据库连接超时
    DB_BUSY = "db_busy"                # SQLite busy timeout
    
    # Task timeouts
    TASK_DEFAULT = "task_default"      # 默认任务超时
    TASK_LONG = "task_long"            # 长任务超时
    TASK_SHORT = "task_short"          # 短任务超时
    
    # External service timeouts
    TG_API = "tg_api"                  # Telegram API 超时
    TMDB_API = "tmdb_api"              # TMDB API 超时
    CLOUD115_API = "cloud115_api"      # 115 API 超时
    MH_API = "mh_api"                  # MediaHelp API 超时


# Default values (matching original hardcoded values)
_TIMEOUT_DEFAULTS: dict[TimeoutCategory, float] = {
    TimeoutCategory.HTTP_DEFAULT: 10.0,
    TimeoutCategory.HTTP_SHORT: 5.0,
    TimeoutCategory.HTTP_LONG: 30.0,
    TimeoutCategory.DB_CONNECT: 30.0,
    TimeoutCategory.DB_BUSY: 5.0,  # seconds (SQLite busy_timeout is in ms)
    TimeoutCategory.TASK_DEFAULT: 30.0,
    TimeoutCategory.TASK_LONG: 120.0,
    TimeoutCategory.TASK_SHORT: 10.0,
    TimeoutCategory.TG_API: 12.0,
    TimeoutCategory.TMDB_API: 8.0,
    TimeoutCategory.CLOUD115_API: 15.0,
    TimeoutCategory.MH_API: 15.0,
}


def get_timeout(category: TimeoutCategory, default: Optional[float] = None) -> float:
    """Get timeout value for a category.
    
    Checks environment variable first, then falls back to default.
    Environment variable format: TIMEOUT_{CATEGORY_NAME}
    Example: TIMEOUT_HTTP_DEFAULT=15.0
    """
    env_key = f"TIMEOUT_{category.value.upper()}"
    env_val = os.environ.get(env_key)
    
    if env_val is not None:
        try:
            val = float(env_val)
            if val > 0:
                return val
            logger.warning(
                "Invalid timeout value (must be positive): %s=%s, using default",
                env_key, env_val
            )
        except ValueError:
            logger.warning(
                "Invalid timeout value (not a number): %s=%s, using default",
                env_key, env_val
            )
    
    if default is not None:
        return default
    
    return _TIMEOUT_DEFAULTS.get(category, 10.0)


def get_db_busy_timeout_ms() -> int:
    """Get SQLite busy timeout in milliseconds."""
    return int(get_timeout(TimeoutCategory.DB_BUSY) * 1000)
```

### 2. 重试配置模块 (`settings/retries.py`)

```python
"""Retry configurations - centralized retry management."""

from dataclasses import dataclass
from enum import Enum
from typing import Optional, Tuple
import os

from core.logging import get_biz_logger_adapter

logger = get_biz_logger_adapter(__name__)


class RetryCategory(str, Enum):
    """Retry categories."""
    HTTP_DEFAULT = "http_default"      # 默认 HTTP 重试
    HTTP_CRITICAL = "http_critical"    # 关键 HTTP 请求（更多重试）
    DB_DEFAULT = "db_default"          # 数据库操作重试
    TG_API = "tg_api"                  # Telegram API 重试
    EXTERNAL_SERVICE = "external"      # 外部服务重试


@dataclass(frozen=True)
class RetryConfig:
    """Retry configuration."""
    max_retries: int
    backoff_base: float
    backoff_max: float
    backoff: Tuple[float, float]  # (min, max) for compatibility
    
    @classmethod
    def create(cls, max_retries: int, backoff_base: float = 1.0, 
               backoff_max: float = 30.0) -> "RetryConfig":
        return cls(
            max_retries=max_retries,
            backoff_base=backoff_base,
            backoff_max=backoff_max,
            backoff=(0.0, backoff_base),
        )


# Default values (matching original hardcoded values)
_RETRY_DEFAULTS: dict[RetryCategory, RetryConfig] = {
    RetryCategory.HTTP_DEFAULT: RetryConfig.create(3, 1.0, 30.0),
    RetryCategory.HTTP_CRITICAL: RetryConfig.create(5, 1.0, 60.0),
    RetryCategory.DB_DEFAULT: RetryConfig.create(3, 0.1, 5.0),
    RetryCategory.TG_API: RetryConfig.create(3, 0.6, 10.0),
    RetryCategory.EXTERNAL_SERVICE: RetryConfig.create(3, 1.0, 30.0),
}


def get_retry_config(category: RetryCategory) -> RetryConfig:
    """Get retry configuration for a category.
    
    Checks environment variables first, then falls back to defaults.
    Environment variable format: RETRY_{CATEGORY}_MAX, RETRY_{CATEGORY}_BACKOFF_BASE
    """
    base_key = f"RETRY_{category.value.upper()}"
    default = _RETRY_DEFAULTS.get(category, RetryConfig.create(3))
    
    max_retries = default.max_retries
    backoff_base = default.backoff_base
    backoff_max = default.backoff_max
    
    # Check environment overrides
    max_env = os.environ.get(f"{base_key}_MAX")
    if max_env:
        try:
            val = int(max_env)
            if val >= 0:
                max_retries = val
        except ValueError:
            logger.warning("Invalid retry max: %s=%s", f"{base_key}_MAX", max_env)
    
    base_env = os.environ.get(f"{base_key}_BACKOFF_BASE")
    if base_env:
        try:
            val = float(base_env)
            if val >= 0:
                backoff_base = val
        except ValueError:
            logger.warning("Invalid backoff base: %s=%s", f"{base_key}_BACKOFF_BASE", base_env)
    
    return RetryConfig.create(max_retries, backoff_base, backoff_max)
```

### 3. 缓存配置模块 (`settings/caches.py`)

```python
"""Cache configurations - centralized cache management."""

from dataclasses import dataclass
from enum import Enum
from typing import Optional
import os

from core.logging import get_biz_logger_adapter

logger = get_biz_logger_adapter(__name__)


class CacheTTL(str, Enum):
    """Cache TTL categories."""
    SHORT = "short"      # 短期缓存（1-5 分钟）
    MEDIUM = "medium"    # 中期缓存（5-30 分钟）
    LONG = "long"        # 长期缓存（1-24 小时）
    PERSISTENT = "persistent"  # 持久缓存（天级别）


class CacheSize(str, Enum):
    """Cache size categories."""
    SMALL = "small"      # 小缓存（100-500 条）
    MEDIUM = "medium"    # 中缓存（500-2000 条）
    LARGE = "large"      # 大缓存（2000-10000 条）


@dataclass(frozen=True)
class CacheConfig:
    """Cache configuration."""
    ttl_seconds: int
    max_size: int


# Default TTL values (seconds)
_TTL_DEFAULTS: dict[CacheTTL, int] = {
    CacheTTL.SHORT: 60,        # 1 minute
    CacheTTL.MEDIUM: 600,      # 10 minutes
    CacheTTL.LONG: 3600,       # 1 hour
    CacheTTL.PERSISTENT: 86400,  # 1 day
}

# Default size values
_SIZE_DEFAULTS: dict[CacheSize, int] = {
    CacheSize.SMALL: 200,
    CacheSize.MEDIUM: 1000,
    CacheSize.LARGE: 5000,
}


def get_cache_ttl(category: CacheTTL) -> int:
    """Get cache TTL in seconds."""
    env_key = f"CACHE_TTL_{category.value.upper()}"
    env_val = os.environ.get(env_key)
    
    if env_val:
        try:
            val = int(env_val)
            if val > 0:
                return val
        except ValueError:
            logger.warning("Invalid cache TTL: %s=%s", env_key, env_val)
    
    return _TTL_DEFAULTS.get(category, 600)


def get_cache_size(category: CacheSize) -> int:
    """Get cache max size."""
    env_key = f"CACHE_SIZE_{category.value.upper()}"
    env_val = os.environ.get(env_key)
    
    if env_val:
        try:
            val = int(env_val)
            if val > 0:
                return val
        except ValueError:
            logger.warning("Invalid cache size: %s=%s", env_key, env_val)
    
    return _SIZE_DEFAULTS.get(category, 1000)


def get_cache_config(ttl: CacheTTL, size: CacheSize) -> CacheConfig:
    """Get combined cache configuration."""
    return CacheConfig(
        ttl_seconds=get_cache_ttl(ttl),
        max_size=get_cache_size(size),
    )
```

### 4. 数据库配置模块 (`settings/database.py`)

```python
"""Database configurations - centralized database settings."""

from enum import Enum
from typing import Any
import os

from core.logging import get_biz_logger_adapter

logger = get_biz_logger_adapter(__name__)


class DBConfig(str, Enum):
    """Database configuration keys."""
    CONNECT_TIMEOUT = "connect_timeout"    # 连接超时（秒）
    BUSY_TIMEOUT = "busy_timeout"          # SQLite busy timeout（毫秒）
    RETRY_COUNT = "retry_count"            # 重试次数
    WAL_MODE = "wal_mode"                  # 是否启用 WAL 模式
    CHECK_SAME_THREAD = "check_same_thread"  # SQLite check_same_thread


# Default values (matching original hardcoded values)
_DB_DEFAULTS: dict[DBConfig, Any] = {
    DBConfig.CONNECT_TIMEOUT: 30,
    DBConfig.BUSY_TIMEOUT: 5000,  # milliseconds
    DBConfig.RETRY_COUNT: 3,
    DBConfig.WAL_MODE: True,
    DBConfig.CHECK_SAME_THREAD: False,
}


def get_db_config(key: DBConfig) -> Any:
    """Get database configuration value.
    
    Checks environment variable first, then falls back to default.
    Environment variable format: DB_{KEY_NAME}
    """
    env_key = f"DB_{key.value.upper()}"
    env_val = os.environ.get(env_key)
    default = _DB_DEFAULTS.get(key)
    
    if env_val is None:
        return default
    
    # Type-specific parsing
    if key in (DBConfig.CONNECT_TIMEOUT, DBConfig.BUSY_TIMEOUT, DBConfig.RETRY_COUNT):
        try:
            val = int(env_val)
            if val >= 0:
                return val
            logger.warning("Invalid DB config (must be non-negative): %s=%s", env_key, env_val)
        except ValueError:
            logger.warning("Invalid DB config (not an integer): %s=%s", env_key, env_val)
        return default
    
    if key in (DBConfig.WAL_MODE, DBConfig.CHECK_SAME_THREAD):
        return env_val.lower() in ("1", "true", "yes", "on")
    
    return env_val
```

## Data Models

### TimeoutConfig
```python
@dataclass
class TimeoutConfig:
    """超时配置"""
    category: TimeoutCategory
    value: float
    source: str  # "default" | "env"
```

### RetryConfig
```python
@dataclass
class RetryConfig:
    """重试配置"""
    max_retries: int
    backoff_base: float
    backoff_max: float
    backoff: Tuple[float, float]
```

### CacheConfig
```python
@dataclass
class CacheConfig:
    """缓存配置"""
    ttl_seconds: int
    max_size: int
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: 超时配置获取

*For any* 超时类别，`get_timeout()` 应该返回正数值；如果设置了有效的环境变量，应该返回环境变量值；否则返回默认值。

**Validates: Requirements 1.3, 1.4**

### Property 2: 重试配置获取

*For any* 重试类别，`get_retry_config()` 应该返回包含 max_retries, backoff_base, backoff_max 的配置；如果设置了有效的环境变量，应该使用环境变量值。

**Validates: Requirements 2.3, 2.4, 2.5**

### Property 3: 缓存配置获取

*For any* 缓存类别，`get_cache_ttl()` 和 `get_cache_size()` 应该返回正整数；如果设置了有效的环境变量，应该使用环境变量值。

**Validates: Requirements 3.3, 3.4**

### Property 4: 数据库配置获取

*For any* 数据库配置键，`get_db_config()` 应该返回正确类型的值；如果设置了有效的环境变量，应该使用环境变量值。

**Validates: Requirements 4.3, 4.4**

### Property 5: 配置验证

*For any* 无效的配置值（负数、非数字等），系统应该记录警告并返回默认值，而不是抛出异常。

**Validates: Requirements 6.1, 6.2, 6.3, 6.4**

### Property 6: 默认值保持

*For any* 配置类别，默认值应该与原硬编码值一致，确保向后兼容。

**Validates: Requirements 5.5, 8.1**

## Error Handling

### 配置解析错误

- 无效的环境变量值：记录警告，使用默认值
- 缺失的配置类别：使用通用默认值
- 类型转换失败：记录警告，使用默认值

### 配置验证错误

- 负数超时值：使用默认值
- 负数重试次数：使用 0
- 负数缓存大小：使用默认值

## Testing Strategy

### 单元测试

- 测试每个配置模块的默认值
- 测试环境变量覆盖
- 测试无效值处理

### 属性测试

使用 Hypothesis 库进行属性测试：

- **Property 1**: 生成随机超时类别和环境变量值，验证返回值
- **Property 2**: 生成随机重试类别和环境变量值，验证配置完整性
- **Property 3**: 生成随机缓存类别和环境变量值，验证返回值
- **Property 5**: 生成随机无效值，验证错误处理
- **Property 6**: 验证所有默认值与原硬编码值一致

### 测试配置

- 每个属性测试运行 100 次迭代
- 使用 `@settings(max_examples=100)` 配置 Hypothesis
