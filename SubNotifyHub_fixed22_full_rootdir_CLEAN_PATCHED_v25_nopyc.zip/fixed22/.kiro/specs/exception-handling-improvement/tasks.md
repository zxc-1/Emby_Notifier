# Implementation Plan: Exception Handling Improvement

## Overview

本实现计划将建立统一的异常处理机制，包括异常类别定义、处理工具类、恢复策略和指标收集。实现分为核心基础设施、属性测试、模块迁移三个阶段。

## Tasks

- [x] 1. 创建异常类别和映射
  - [x] 1.1 创建 `core/exceptions.py` 异常类别定义
    - 定义 AppException 基类
    - 定义 NetworkError, DatabaseError, ValidationError, ConfigurationError, ExternalServiceError
    - 每个异常类包含 category, cause, context 属性
    - _Requirements: 2.1_
  - [x] 1.2 创建 `core/exception_mapping.py` 异常映射
    - 定义 EXCEPTION_MAPPING 字典
    - 实现 map_exception() 函数
    - 映射 httpx, sqlite3, 标准库异常
    - _Requirements: 2.3_
  - [x] 1.3 编写异常映射属性测试
    - **Property 3: 异常映射正确性**
    - **Validates: Requirements 2.3**

- [x] 2. 创建 safe_call 装饰器
  - [x] 2.1 创建 `core/safe_call.py`
    - 实现 safe_call 装饰器
    - 支持同步和异步函数
    - 支持 catch, default, on_error, log_level 参数
    - 集成 BizLogger 记录异常
    - _Requirements: 1.1, 1.3, 1.4, 1.5, 1.6_
  - [x] 2.2 编写 safe_call 异常捕获属性测试
    - **Property 1: safe_call 装饰器异常捕获**
    - **Validates: Requirements 1.1, 1.4, 1.5**
  - [x] 2.3 编写 safe_call 日志完整性属性测试
    - **Property 2: safe_call 装饰器日志完整性**
    - **Validates: Requirements 1.3, 3.1, 3.3**
  - [x] 2.4 编写回调函数属性测试
    - **Property 10: 回调函数调用**
    - **Validates: Requirements 1.6**

- [x] 3. 创建 safe_context 上下文管理器
  - [x] 3.1 创建 `core/safe_context.py`
    - 实现 safe_context 同步上下文管理器
    - 实现 async_safe_context 异步上下文管理器
    - 支持 catch, default, on_error, context_name 参数
    - _Requirements: 1.2_
  - [x] 3.2 编写异常上下文完整性属性测试
    - **Property 4: 异常上下文完整性**
    - **Validates: Requirements 3.1, 3.2, 3.3**

- [x] 4. Checkpoint - 核心工具类测试
  - 确保所有核心工具类测试通过，如有问题请询问用户

- [x] 5. 创建恢复策略
  - [x] 5.1 创建 `core/recovery.py`
    - 实现 RetryStrategy 类
    - 实现 CircuitBreaker 类
    - 实现 with_retry 装饰器
    - _Requirements: 5.1, 5.2, 5.3_
  - [x] 5.2 编写重试策略指数退避属性测试
    - **Property 5: 重试策略指数退避**
    - **Validates: Requirements 5.1**
  - [x] 5.3 编写熔断器状态转换属性测试
    - **Property 6: 熔断器状态转换**
    - **Validates: Requirements 5.3**

- [x] 6. 创建异常指标收集
  - [x] 6.1 创建 `core/exception_metrics.py`
    - 实现 ExceptionMetrics 单例类
    - 实现 record(), get_counts(), check_threshold() 方法
    - 集成到现有 metrics 端点
    - _Requirements: 6.1, 6.2, 6.3, 6.4_
  - [x] 6.2 编写异常指标计数属性测试
    - **Property 7: 异常指标计数准确性**
    - **Validates: Requirements 6.1**

- [x] 7. 创建专用异常处理器
  - [x] 7.1 创建 `core/db_exception_handler.py`
    - 实现数据库异常处理逻辑
    - 连接错误重试，完整性错误不重试
    - 确保连接正确关闭
    - _Requirements: 7.1, 7.2, 7.3, 7.4_
  - [x] 7.2 编写数据库异常重试属性测试
    - **Property 8: 数据库异常重试行为**
    - **Validates: Requirements 7.1, 7.3**
  - [x] 7.3 创建 `core/http_exception_handler.py`
    - 实现 HTTP 异常处理逻辑
    - 超时/连接错误重试，4xx 不重试，5xx 重试
    - 确保连接正确关闭
    - _Requirements: 8.1, 8.2, 8.3, 8.4, 8.5_
  - [x] 7.4 编写 HTTP 异常重试属性测试
    - **Property 9: HTTP 异常重试行为**
    - **Validates: Requirements 8.2, 8.3, 8.4**

- [x] 8. Checkpoint - 恢复策略测试
  - 确保所有恢复策略测试通过，如有问题请询问用户

- [x] 9. 创建静默异常扫描工具
  - [x] 9.1 创建 `tools/scan_swallowed_exceptions.py`
    - 扫描 `except Exception: pass` 模式
    - 扫描 `except Exception: logger.exception` 模式
    - 输出文件路径、行号、代码片段
    - 按优先级排序（core > integrations > tools）
    - _Requirements: 4.1, 4.2, 4.4_

- [x] 10. 迁移 core 模块异常处理
  - [x] 10.1 迁移 `core/cache.py`
    - 替换宽泛异常捕获为具体异常类型
    - 使用 safe_call 或 safe_context
    - _Requirements: 4.3_
  - [x] 10.2 迁移 `core/http_clients.py`
    - 替换宽泛异常捕获为具体异常类型
    - 使用 http_exception_handler
    - _Requirements: 4.3_
  - [x] 10.3 迁移 `core/persist_cache.py`
    - 替换宽泛异常捕获为具体异常类型
    - 使用 db_exception_handler
    - _Requirements: 4.3_

- [x] 11. 迁移 tg_bot 模块异常处理
  - [x] 11.1 迁移 `tg_bot/storage/` 目录
    - 迁移 db.py, tables/*.py
    - 使用 db_exception_handler
    - _Requirements: 4.3_
  - [x] 11.2 迁移 `tg_bot/infra/` 目录
    - 迁移 telegram_api.py, polling.py, webhook_setup.py, outbox.py
    - 使用 http_exception_handler
    - _Requirements: 4.3_

- [x] 12. 迁移 integrations 模块异常处理
  - [x] 12.1 迁移 `integrations/cloud115/` 目录
    - 使用 http_exception_handler
    - _Requirements: 4.3_
  - [x] 12.2 迁移 `integrations/tmdb_match/` 目录
    - 使用 http_exception_handler
    - _Requirements: 4.3_

- [x] 13. 迁移 tools 模块异常处理
  - [x] 13.1 迁移 `tools/` 目录
    - 使用 safe_call 或 safe_context
    - 保持工具脚本的简洁性
    - _Requirements: 4.3_

- [x] 14. Checkpoint - 模块迁移完成
  - 确保所有模块迁移完成，运行完整测试套件验证
  - 如有问题请询问用户

- [x] 15. 集成和文档
  - [x] 15.1 更新 `api/metrics.py` 暴露异常指标
    - 添加 /api/metrics/exceptions 端点
    - _Requirements: 6.2_
  - [x] 15.2 创建异常处理使用文档
    - 在 docs/ 目录创建 EXCEPTION_HANDLING.md
    - 包含使用示例和最佳实践

- [x] 16. 最终验证
  - [x] 16.1 运行完整测试套件
    - 确保所有单元测试和属性测试通过
  - [x] 16.2 运行静默异常扫描工具
    - 确认没有遗漏的宽泛异常捕获
  - [x] 16.3 验证异常指标端点
    - 手动测试 /api/metrics/exceptions 端点

## Notes

- 所有任务均为必需任务，确保全面测试覆盖
- 每个属性测试任务对应设计文档中的一个 Correctness Property
- 模块迁移任务应保持向后兼容，不破坏现有功能
- Checkpoint 任务用于阶段性验证，确保增量开发的稳定性
- 迁移优先级：core > tg_bot > integrations > tools
