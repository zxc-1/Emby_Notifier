# Design Document: Exception Handling Improvement

## Overview

本设计文档描述异常处理改进的技术方案。核心目标是建立统一的异常处理机制，替换现有的宽泛异常捕获模式，提高系统的可维护性和可调试性。

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                      Application Layer                       │
│  (admin, api, tg_bot, notifier, forward_bridge, etc.)       │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                   Exception Handling Layer                   │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │ @safe_call  │  │safe_context │  │ ExceptionMetrics    │  │
│  │  decorator  │  │   manager   │  │    collector        │  │
│  └─────────────┘  └─────────────┘  └─────────────────────┘  │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────┐  │
│  │  Recovery   │  │  Exception  │  │   Error Context     │  │
│  │ Strategies  │  │   Mapping   │  │     Builder         │  │
│  └─────────────┘  └─────────────┘  └─────────────────────┘  │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                    Exception Categories                      │
│  ┌───────────┐ ┌───────────┐ ┌───────────┐ ┌─────────────┐  │
│  │ Network   │ │ Database  │ │Validation │ │ External    │  │
│  │  Error    │ │  Error    │ │  Error    │ │ Service Err │  │
│  └───────────┘ └───────────┘ └───────────┘ └─────────────┘  │
└─────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────┐
│                      Logging Layer                           │
│                    (BizLogger integration)                   │
└─────────────────────────────────────────────────────────────┘
```

## Components and Interfaces

### 1. 异常类别定义 (`core/exceptions.py`)

```python
from typing import Optional, Any

class AppException(Exception):
    """应用异常基类"""
    category: str = "unknown"
    
    def __init__(self, message: str, *, cause: Optional[Exception] = None, 
                 context: Optional[dict] = None):
        super().__init__(message)
        self.cause = cause
        self.context = context or {}

class NetworkError(AppException):
    """网络相关错误：连接超时、DNS 解析失败等"""
    category = "network"

class DatabaseError(AppException):
    """数据库相关错误：连接失败、查询超时、完整性错误等"""
    category = "database"

class ValidationError(AppException):
    """数据验证错误：格式错误、类型错误等"""
    category = "validation"

class ConfigurationError(AppException):
    """配置错误：缺少必需配置、配置值无效等"""
    category = "configuration"

class ExternalServiceError(AppException):
    """外部服务错误：第三方 API 调用失败等"""
    category = "external_service"
```

### 2. 异常映射 (`core/exception_mapping.py`)

```python
import sqlite3
import httpx

# 第三方异常到内部异常的映射
EXCEPTION_MAPPING = {
    # HTTP/网络异常
    httpx.TimeoutException: NetworkError,
    httpx.ConnectError: NetworkError,
    httpx.ReadTimeout: NetworkError,
    ConnectionError: NetworkError,
    TimeoutError: NetworkError,
    
    # 数据库异常
    sqlite3.OperationalError: DatabaseError,
    sqlite3.IntegrityError: DatabaseError,
    sqlite3.DatabaseError: DatabaseError,
    
    # 验证异常
    ValueError: ValidationError,
    TypeError: ValidationError,
    KeyError: ValidationError,
}

def map_exception(exc: Exception) -> AppException:
    """将第三方异常映射为内部异常类别"""
    for exc_type, app_exc_type in EXCEPTION_MAPPING.items():
        if isinstance(exc, exc_type):
            return app_exc_type(str(exc), cause=exc)
    return AppException(str(exc), cause=exc)
```

### 3. 异常处理装饰器 (`core/safe_call.py`)

```python
from functools import wraps
from typing import TypeVar, Callable, Optional, Any, Tuple, Type
import uuid
import asyncio

T = TypeVar('T')

def safe_call(
    *,
    catch: Tuple[Type[Exception], ...] = (Exception,),
    default: Any = None,
    on_error: Optional[Callable[[Exception], None]] = None,
    log_level: str = "error",
    include_traceback: bool = True,
) -> Callable[[Callable[..., T]], Callable[..., T]]:
    """
    安全调用装饰器，统一处理异常。
    
    Args:
        catch: 要捕获的异常类型元组
        default: 异常时的默认返回值
        on_error: 异常时的回调函数
        log_level: 日志级别
        include_traceback: 是否包含堆栈跟踪
    """
    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @wraps(func)
        def sync_wrapper(*args, **kwargs) -> T:
            error_id = str(uuid.uuid4())[:8]
            try:
                return func(*args, **kwargs)
            except catch as e:
                _handle_exception(e, func, error_id, log_level, 
                                  include_traceback, on_error)
                return default
        
        @wraps(func)
        async def async_wrapper(*args, **kwargs) -> T:
            error_id = str(uuid.uuid4())[:8]
            try:
                return await func(*args, **kwargs)
            except catch as e:
                _handle_exception(e, func, error_id, log_level,
                                  include_traceback, on_error)
                return default
        
        if asyncio.iscoroutinefunction(func):
            return async_wrapper
        return sync_wrapper
    return decorator
```

### 4. 上下文管理器 (`core/safe_context.py`)

```python
from contextlib import contextmanager, asynccontextmanager
from typing import Optional, Any, Tuple, Type, Callable
import uuid

@contextmanager
def safe_context(
    *,
    catch: Tuple[Type[Exception], ...] = (Exception,),
    default: Any = None,
    on_error: Optional[Callable[[Exception], None]] = None,
    context_name: str = "unknown",
):
    """
    安全上下文管理器，用于包装代码块。
    
    Usage:
        with safe_context(catch=(ValueError,), default=[], context_name="parse_data"):
            result = parse_data(raw)
    """
    error_id = str(uuid.uuid4())[:8]
    try:
        yield
    except catch as e:
        _handle_exception(e, context_name, error_id, "error", True, on_error)

@asynccontextmanager
async def async_safe_context(
    *,
    catch: Tuple[Type[Exception], ...] = (Exception,),
    default: Any = None,
    on_error: Optional[Callable[[Exception], None]] = None,
    context_name: str = "unknown",
):
    """异步版本的安全上下文管理器"""
    error_id = str(uuid.uuid4())[:8]
    try:
        yield
    except catch as e:
        _handle_exception(e, context_name, error_id, "error", True, on_error)
```

### 5. 恢复策略 (`core/recovery.py`)

```python
from typing import TypeVar, Callable, Optional, Any
import asyncio
import time

T = TypeVar('T')

class RetryStrategy:
    """重试策略"""
    def __init__(self, max_retries: int = 3, backoff_base: float = 1.0,
                 backoff_max: float = 30.0):
        self.max_retries = max_retries
        self.backoff_base = backoff_base
        self.backoff_max = backoff_max
    
    def get_delay(self, attempt: int) -> float:
        """计算指数退避延迟"""
        delay = self.backoff_base * (2 ** attempt)
        return min(delay, self.backoff_max)

class CircuitBreaker:
    """熔断器"""
    def __init__(self, failure_threshold: int = 5, 
                 recovery_timeout: float = 30.0):
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.failures = 0
        self.last_failure_time: Optional[float] = None
        self.state = "closed"  # closed, open, half-open
    
    def record_failure(self) -> None:
        self.failures += 1
        self.last_failure_time = time.time()
        if self.failures >= self.failure_threshold:
            self.state = "open"
    
    def record_success(self) -> None:
        self.failures = 0
        self.state = "closed"
    
    def can_execute(self) -> bool:
        if self.state == "closed":
            return True
        if self.state == "open":
            if time.time() - self.last_failure_time > self.recovery_timeout:
                self.state = "half-open"
                return True
            return False
        return True  # half-open
```

### 6. 异常指标收集 (`core/exception_metrics.py`)

```python
from collections import defaultdict
from threading import Lock
from typing import Dict
import time

class ExceptionMetrics:
    """异常指标收集器"""
    _instance = None
    _lock = Lock()
    
    def __new__(cls):
        if cls._instance is None:
            with cls._lock:
                if cls._instance is None:
                    cls._instance = super().__new__(cls)
                    cls._instance._init()
        return cls._instance
    
    def _init(self):
        self.counts: Dict[str, Dict[str, int]] = defaultdict(lambda: defaultdict(int))
        self.last_reset = time.time()
        self._lock = Lock()
    
    def record(self, category: str, module: str) -> None:
        with self._lock:
            self.counts[category][module] += 1
    
    def get_counts(self) -> Dict[str, Dict[str, int]]:
        with self._lock:
            return dict(self.counts)
    
    def check_threshold(self, category: str, threshold: int) -> bool:
        with self._lock:
            total = sum(self.counts[category].values())
            return total >= threshold
```

## Data Models

### ErrorContext

```python
@dataclass
class ErrorContext:
    """异常上下文信息"""
    error_id: str           # 唯一错误 ID
    module: str             # 模块路径
    function: str           # 函数名
    category: str           # 异常类别
    message: str            # 错误消息
    timestamp: float        # 时间戳
    span_id: Optional[str]  # 链路追踪 ID
    trace_id: Optional[str] # 追踪 ID
    extra: Dict[str, Any]   # 额外业务上下文
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: safe_call 装饰器异常捕获

*For any* 函数和指定的异常类型，当函数抛出该类型异常时，装饰器应该捕获异常并返回配置的默认值，而不是让异常传播。

**Validates: Requirements 1.1, 1.4, 1.5**

### Property 2: safe_call 装饰器日志完整性

*For any* 被捕获的异常，日志输出应该包含模块名、函数名、error_id 和异常消息。

**Validates: Requirements 1.3, 3.1, 3.3**

### Property 3: 异常映射正确性

*For any* 第三方异常类型，如果存在映射关系，则 `map_exception` 应该返回对应的内部异常类型；如果不存在映射，则返回 `AppException`。

**Validates: Requirements 2.3**

### Property 4: 异常上下文完整性

*For any* 记录的异常，上下文应该包含 error_id、module、function、category、message 和 timestamp 字段。

**Validates: Requirements 3.1, 3.2, 3.3**

### Property 5: 重试策略指数退避

*For any* 重试尝试次数 n，退避延迟应该等于 `min(base * 2^n, max_delay)`。

**Validates: Requirements 5.1**

### Property 6: 熔断器状态转换

*For any* 熔断器，当连续失败次数达到阈值时状态应该从 closed 变为 open；当恢复超时后状态应该变为 half-open；成功执行后状态应该变为 closed。

**Validates: Requirements 5.3**

### Property 7: 异常指标计数准确性

*For any* 记录的异常，对应类别和模块的计数应该增加 1。

**Validates: Requirements 6.1**

### Property 8: 数据库异常重试行为

*For any* 数据库连接错误，系统应该重试；*For any* 数据库完整性错误，系统不应该重试。

**Validates: Requirements 7.1, 7.3**

### Property 9: HTTP 异常重试行为

*For any* HTTP 超时或连接错误，系统应该重试；*For any* HTTP 4xx 错误，系统不应该重试；*For any* HTTP 5xx 错误，系统应该重试。

**Validates: Requirements 8.2, 8.3, 8.4**

### Property 10: 回调函数调用

*For any* 配置了 on_error 回调的 safe_call，当异常发生时回调函数应该被调用且接收到异常对象。

**Validates: Requirements 1.6**

## Error Handling

### 异常处理层级

1. **业务层**：捕获具体业务异常，执行业务恢复逻辑
2. **基础设施层**：捕获网络、数据库等基础设施异常，执行重试/熔断
3. **全局层**：捕获未处理异常，记录 CRITICAL 日志

### 异常传播规则

- 可恢复异常：在当前层处理，不传播
- 不可恢复异常：记录日志后传播到上层
- 未知异常：记录 CRITICAL 日志，包装为 AppException 后传播

## Testing Strategy

### 单元测试

- 测试 `@safe_call` 装饰器的各种配置组合
- 测试 `safe_context` 上下文管理器
- 测试异常映射的正确性
- 测试重试策略的退避计算
- 测试熔断器的状态转换

### 属性测试

使用 Hypothesis 库进行属性测试：

- **Property 1-2**: 生成随机函数和异常，验证装饰器行为
- **Property 3**: 生成随机异常类型，验证映射结果
- **Property 5**: 生成随机重试次数，验证退避延迟
- **Property 6**: 生成随机失败/成功序列，验证状态转换
- **Property 7**: 生成随机异常记录，验证计数准确性
- **Property 8-9**: 生成随机异常类型，验证重试决策

### 测试配置

- 每个属性测试运行 100 次迭代
- 使用 `@settings(max_examples=100)` 配置 Hypothesis
