# Requirements Document

## Introduction

本功能旨在优化通知配置页面（Settings Page）的前端数据集成，实现与 hotlist/forward/tgbot 页面类似的缓存策略、错误处理和用户体验增强。当前页面已有基础的 API 调用和表单处理，但缺乏缓存机制、统一的 API 封装层、完善的错误处理、加载状态指示、活动日志和离线指示器。

## Glossary

- **Settings_Page**: 通知配置页面，用于管理 Emby 服务器、TMDB、通知器、处理流程和高级设置
- **Settings_Config**: 通知配置数据，包含 Emby 配置、Webhook 配置、通知器配置、Pipeline 配置、去重配置和高级配置
- **Settings_Status**: 系统运行状态，包含 Emby 连接状态、TMDB 配置状态、通知器就绪状态、Webhook 配置状态、115 云盘配置状态
- **SettingsCache**: 前端本地缓存模块，用于缓存配置和状态数据
- **SettingsAPI**: 前端 API 封装模块，统一处理所有 API 调用
- **Activity_Log**: 页面操作活动日志，记录用户操作历史
- **Notifier**: 通知发送器，负责将消息发送到配置的渠道
- **Pipeline**: 通知处理流水线，定义消息处理的步骤顺序

## Requirements

### Requirement 1: 配置数据加载与缓存

**User Story:** As a user, I want the configuration page to load quickly with cached data, so that I can have a responsive experience.

#### Acceptance Criteria

1. WHEN the Settings page loads, THE Settings_Page SHALL request configuration data from `/admin/settings/config.json` API
2. WHEN configuration data is received, THE Settings_Page SHALL populate all form fields with the received values
3. THE Settings_Page SHALL cache configuration data in localStorage with TTL of 2 minutes
4. WHEN cached data exists, THE Settings_Page SHALL display cached data immediately while fetching fresh data (stale-while-revalidate)
5. IF the configuration API request fails, THEN THE Settings_Page SHALL display cached data or show error state with retry option

### Requirement 2: 状态数据加载与显示

**User Story:** As a user, I want to see real-time status of system components, so that I can monitor the service health.

#### Acceptance Criteria

1. WHEN the Settings page loads, THE Settings_Page SHALL request status data from `/admin/settings/status.json` API
2. WHEN status data is received, THE Settings_Page SHALL update Emby 状态、Webhook 状态、通知器状态、TMDB 状态、115 云盘状态显示
3. THE Settings_Page SHALL auto-refresh status every 30 seconds
4. THE Settings_Page SHALL cache status data in localStorage with TTL of 30 seconds
5. WHILE status data is loading, THE Settings_Page SHALL show "检测中..." indicator
6. IF the status API request fails, THEN THE Settings_Page SHALL show "连接失败" and use cached data if available

### Requirement 3: 配置保存功能

**User Story:** As a user, I want to save my configuration changes, so that they persist across sessions.

#### Acceptance Criteria

1. WHEN the user clicks "保存配置", THE Settings_Page SHALL collect all form values and call `/admin/settings/config` API
2. WHILE the save request is in progress, THE Settings_Page SHALL disable the save button and show loading state
3. IF the save request succeeds, THEN THE Settings_Page SHALL show success toast, invalidate cache, and add activity log
4. IF the save request fails, THEN THE Settings_Page SHALL show error toast with detail message
5. WHEN configuration is saved, THE Settings_Page SHALL update the cached data

### Requirement 4: Emby 连接测试

**User Story:** As a user, I want to test Emby connection, so that I can verify my configuration is correct.

#### Acceptance Criteria

1. WHEN the user clicks "测试连接", THE Settings_Page SHALL validate Emby 地址 and API Key are not empty
2. IF Emby 地址 or API Key is empty, THEN THE Settings_Page SHALL show warning toast
3. WHILE the test request is in progress, THE Settings_Page SHALL show "正在测试连接..." toast and disable the button
4. IF the test succeeds, THEN THE Settings_Page SHALL show success toast and add activity log
5. IF the test fails, THEN THE Settings_Page SHALL show error toast with detail message

### Requirement 5: 115 云盘连接测试

**User Story:** As a user, I want to test 115 cloud connection, so that I can verify my Cookie is valid.

#### Acceptance Criteria

1. WHEN the user clicks "测试 115 连接", THE Settings_Page SHALL validate 115 Cookie is not empty
2. IF 115 Cookie is empty, THEN THE Settings_Page SHALL show warning toast
3. WHILE the test request is in progress, THE Settings_Page SHALL show loading state on the button
4. IF the test succeeds, THEN THE Settings_Page SHALL show success toast and add activity log
5. IF the test fails, THEN THE Settings_Page SHALL show error toast with detail message

### Requirement 6: 危险操作功能

**User Story:** As a user, I want to perform dangerous operations with confirmation, so that I can manage the system safely.

#### Acceptance Criteria

1. WHEN the user clicks "清空死信队列", THE Settings_Page SHALL show confirmation dialog before calling `/admin/settings/clear_deadletter` API
2. WHEN the user clicks "清空去重缓存", THE Settings_Page SHALL show confirmation dialog before calling `/admin/settings/clear_dedup` API
3. WHEN the user clicks "重置为默认配置", THE Settings_Page SHALL show double confirmation dialog before calling `/admin/settings/reset` API
4. WHILE any dangerous operation is in progress, THE Settings_Page SHALL disable the button and show loading state
5. IF a dangerous operation succeeds, THEN THE Settings_Page SHALL show success toast, refresh config, and add activity log
6. IF a dangerous operation fails, THEN THE Settings_Page SHALL show error toast with detail message

### Requirement 7: 活动日志记录

**User Story:** As a user, I want to see recent activity logs, so that I can track what operations have been performed.

#### Acceptance Criteria

1. WHEN an operation is performed, THE Settings_Page SHALL add a timestamped entry to the activity log
2. THE Settings_Page SHALL display up to 10 most recent activity entries
3. THE Settings_Page SHALL persist activity log to localStorage
4. WHEN the page loads, THE Settings_Page SHALL restore activity log from localStorage

### Requirement 8: API 响应格式标准化

**User Story:** As a developer, I want consistent API response formats, so that I can reliably handle responses.

#### Acceptance Criteria

1. THE API SHALL return JSON responses with `ok` (boolean) field
2. WHEN a request succeeds, THE API SHALL set `ok: true` and include relevant data
3. WHEN a request fails, THE API SHALL set `ok: false` and include `detail` (error message) field
4. THE `/admin/settings/config.json` API SHALL include `config` object with all configuration fields
5. THE `/admin/settings/status.json` API SHALL include `status` object with `emby_connected`, `tmdb_configured`, `notifier_ready`, `webhook_configured`, `cloud115_configured` fields

### Requirement 9: 缓存时间显示

**User Story:** As a user, I want to see when data was last updated, so that I know how fresh the displayed data is.

#### Acceptance Criteria

1. THE Settings_Page SHALL display "上次更新" timestamp when showing cached data
2. WHEN data is refreshed, THE Settings_Page SHALL update the timestamp display
3. THE Settings_Page SHALL format timestamp in user-friendly format (e.g., "刚刚", "1 分钟前")

### Requirement 10: 错误处理和用户反馈

**User Story:** As a user, I want clear feedback on my actions, so that I know what's happening.

#### Acceptance Criteria

1. WHEN an API request is in progress, THE Settings_Page SHALL disable the action button and show loading state
2. WHEN an API request succeeds, THE Settings_Page SHALL show a success toast notification
3. WHEN an API request fails, THE Settings_Page SHALL show an error toast with detail message
4. IF network is unavailable, THEN THE Settings_Page SHALL display offline indicator and use cached data
5. THE Settings_Page SHALL provide retry option for failed requests

### Requirement 11: 表单辅助功能

**User Story:** As a user, I want helpful form features, so that I can configure the service easily.

#### Acceptance Criteria

1. WHEN the user clicks password toggle button, THE Settings_Page SHALL toggle password visibility
2. WHEN the user clicks "生成随机 Secret" button, THE Settings_Page SHALL generate a 32-character random token
3. WHEN a token is generated, THE Settings_Page SHALL show the token in plain text and show success toast

### Requirement 12: 配置导入导出

**User Story:** As a user, I want to import and export configuration, so that I can backup and restore settings.

#### Acceptance Criteria

1. WHEN the user clicks "导出配置", THE Settings_Page SHALL download current configuration as JSON file
2. WHEN the user clicks "导入配置", THE Settings_Page SHALL open file picker for JSON file
3. WHEN a valid configuration file is selected, THE Settings_Page SHALL populate form fields with imported values
4. IF the imported file is invalid, THEN THE Settings_Page SHALL show error toast

