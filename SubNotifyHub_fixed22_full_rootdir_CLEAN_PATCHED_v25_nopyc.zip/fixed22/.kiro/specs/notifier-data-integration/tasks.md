# Implementation Plan: Settings Page Data Integration

## Overview

本实现计划将通知配置页面（Settings Page）的前端与后端 API 数据打通，实现动态数据加载、缓存策略、错误处理和用户体验增强。实现语言为 JavaScript，复用现有的 `static/js/settings.js` 文件并进行增强。

## Tasks

- [x] 1. 新增后端 Status API
  - [x] 1.1 在 `admin/routes_settings.py` 中添加 `/admin/settings/status.json` 端点
    - 返回 `emby_connected`, `tmdb_configured`, `notifier_ready`, `webhook_configured`, `cloud115_configured` 状态
    - 返回格式: `{ "ok": true, "status": { ... } }`
    - _Requirements: 2.1, 2.2, 8.4, 8.5_

- [x] 2. 实现 SettingsCache 缓存模块
  - [x] 2.1 创建 SettingsCache 对象，定义缓存键和 TTL 常量
    - CONFIG_KEY: 'snh_settings_config_cache'
    - STATUS_KEY: 'snh_settings_status_cache'
    - ACTIVITY_KEY: 'snh_settings_activity_log'
    - CONFIG_TTL: 2 分钟
    - STATUS_TTL: 30 秒
    - _Requirements: 1.3, 2.4_
  
  - [x] 2.2 实现 get/set/isValid/invalidate/getStale/getAge 方法
    - get(key): 从 localStorage 获取缓存数据
    - set(key, data, ttl): 设置缓存数据，包含 timestamp 和 ttl
    - isValid(key): 检查缓存是否在 TTL 内
    - invalidate(key): 清除指定缓存
    - getStale(key): 获取过期数据用于 stale-while-revalidate
    - getAge(key): 获取缓存年龄（毫秒）
    - _Requirements: 1.3, 1.4, 2.4, 3.5_
  
  - [x] 2.3 实现 formatAge 方法
    - 格式化缓存时间为用户友好格式
    - < 1 分钟: "刚刚"
    - < 1 小时: "N 分钟前"
    - >= 1 小时: "N 小时前"
    - 无缓存: "未知"
    - _Requirements: 9.1, 9.2, 9.3_
  
  - [x] 2.4 编写 SettingsCache 属性测试
    - **Property 1: Cache TTL Enforcement** - 缓存在 TTL 内有效，过期后无效
    - **Property 2: Cache Age Formatting** - 时间格式化正确
    - **Validates: Requirements 1.3, 2.4, 9.1, 9.2, 9.3**

- [x] 3. 实现 SettingsAPI 模块
  - [x] 3.1 创建 SettingsAPI 对象，实现配置相关 API
    - getConfig(): GET /admin/settings/config.json
    - saveConfig(config): POST /admin/settings/config
    - _Requirements: 1.1, 3.1_
  
  - [x] 3.2 实现状态和测试相关 API
    - getStatus(): GET /admin/settings/status.json
    - testEmby(url, key): POST /admin/settings/test_emby
    - test115(cookie): POST /admin/settings/test_115
    - _Requirements: 2.1, 4.1, 5.1_
  
  - [x] 3.3 实现危险操作 API
    - clearDeadletter(): POST /admin/settings/clear_deadletter
    - clearDedup(): POST /admin/settings/clear_dedup
    - resetConfig(): POST /admin/settings/reset
    - _Requirements: 6.1, 6.2, 6.3_
  
  - [x] 3.4 编写 API 响应格式属性测试
    - **Property 3: API Response Format Consistency** - 所有 API 返回 `ok` 字段
    - **Validates: Requirements 8.1, 8.2, 8.3**

- [x] 4. Checkpoint - 确保缓存和 API 模块测试通过
  - 确保所有测试通过，如有问题请询问用户。

- [x] 5. 实现 ActivityLog 活动日志模块
  - [x] 5.1 创建 ActivityLog 对象，实现日志管理
    - MAX_ENTRIES: 10
    - add(msg): 添加日志条目，包含时间戳
    - getAll(): 获取所有日志
    - save(logs): 保存到 localStorage
    - render(logs): 渲染日志到 DOM
    - init(): 初始化，从 localStorage 恢复
    - _Requirements: 7.1, 7.2, 7.3, 7.4_
  
  - [x] 5.2 编写 ActivityLog 属性测试
    - **Property 4: Activity Log Management** - 日志最多保留 10 条，新日志在前
    - **Validates: Requirements 7.1, 7.2, 7.3**

- [x] 6. 实现数据加载和表单填充功能
  - [x] 6.1 实现 loadConfigWithCache 函数
    - 使用 stale-while-revalidate 模式
    - 先显示缓存数据，后台获取最新数据
    - 失败时显示缓存或错误状态
    - _Requirements: 1.1, 1.4, 1.5_
  
  - [x] 6.2 实现 fillForm 函数
    - 将配置数据填充到表单字段
    - 处理 Emby、Webhook、Notifier、Pipeline、Dedup、Advanced 配置
    - _Requirements: 1.2_
  
  - [x] 6.3 实现 collectFormData 函数
    - 收集表单数据用于保存
    - 处理复选框、文本框、下拉框、数字输入
    - _Requirements: 3.1_
  
  - [x] 6.4 编写表单填充和收集属性测试
    - **Property 5: Form Population Completeness** - 所有配置字段正确填充
    - **Property 6: Form Data Collection Accuracy** - 收集的数据与表单值一致
    - **Validates: Requirements 1.2, 3.1**

- [x] 7. 实现状态显示和自动刷新
  - [x] 7.1 实现 loadStatusWithCache 函数
    - 使用 stale-while-revalidate 模式
    - 更新各组件状态显示
    - _Requirements: 2.1, 2.2, 2.5, 2.6_
  
  - [x] 7.2 实现 updateStatusDisplay 函数
    - 更新 Emby 状态、TMDB 状态、通知器状态、Webhook 状态、115 状态
    - 处理 null/undefined 情况显示"检测中..."
    - _Requirements: 2.2, 2.5_
  
  - [x] 7.3 实现 startStatusAutoRefresh 函数
    - 每 30 秒自动刷新状态
    - 页面卸载时清除定时器
    - _Requirements: 2.3_
  
  - [x] 7.4 编写状态显示属性测试
    - **Property 7: Status Display Completeness** - 所有状态字段正确显示
    - **Validates: Requirements 2.2**

- [x] 8. Checkpoint - 确保数据加载和显示功能测试通过
  - 确保所有测试通过，如有问题请询问用户。

- [x] 9. 实现配置保存和操作反馈
  - [x] 9.1 重构 saveConfig 函数
    - 使用 withMutationFeedback 包装
    - 显示加载状态，禁用按钮
    - 成功后清除缓存，添加活动日志
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5_
  
  - [x] 9.2 实现 withMutationFeedback 辅助函数
    - 统一处理操作反馈
    - 管理按钮加载状态
    - 处理成功/失败 Toast
    - _Requirements: 10.1, 10.2, 10.3_

- [x] 10. 实现连接测试功能
  - [x] 10.1 重构 testEmbyConnection 函数
    - 验证 Emby 地址和 API Key 非空
    - 显示加载状态
    - 成功/失败显示对应 Toast
    - 添加活动日志
    - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5_
  
  - [x] 10.2 重构 test115Connection 函数
    - 验证 115 Cookie 非空
    - 显示加载状态
    - 成功/失败显示对应 Toast
    - 添加活动日志
    - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5_

- [x] 11. 实现危险操作功能
  - [x] 11.1 重构 clearDeadletter 函数
    - 显示确认对话框
    - 显示加载状态
    - 添加活动日志
    - _Requirements: 6.1, 6.4, 6.5, 6.6_
  
  - [x] 11.2 重构 clearDedup 函数
    - 显示确认对话框
    - 显示加载状态
    - 添加活动日志
    - _Requirements: 6.2, 6.4, 6.5, 6.6_
  
  - [x] 11.3 重构 resetConfig 函数
    - 显示双重确认对话框
    - 显示加载状态
    - 成功后刷新配置
    - 添加活动日志
    - _Requirements: 6.3, 6.4, 6.5, 6.6_

- [x] 12. Checkpoint - 确保所有操作功能测试通过
  - 确保所有测试通过，如有问题请询问用户。

- [x] 13. 实现表单辅助功能
  - [x] 13.1 实现 generateSecret 函数
    - 生成 32 位随机字母数字 Token
    - 填充到 Webhook Secret 字段
    - 显示成功 Toast
    - _Requirements: 11.2, 11.3_
  
  - [x] 13.2 保持 togglePassword 函数
    - 切换密码/敏感字段可见性
    - _Requirements: 11.1_
  
  - [x] 13.3 编写 Token 生成属性测试
    - **Property 8: Token Generation** - 生成的 Token 长度为 32，仅包含字母数字
    - **Validates: Requirements 11.2, 11.3**

- [x] 14. 实现配置导入导出功能
  - [x] 14.1 实现 exportConfig 函数
    - 收集当前配置
    - 下载为 JSON 文件
    - _Requirements: 12.1_
  
  - [x] 14.2 实现 importConfig 函数
    - 打开文件选择器
    - 解析 JSON 文件
    - 填充表单字段
    - 处理无效文件错误
    - _Requirements: 12.2, 12.3, 12.4_

- [x] 15. 实现缓存时间指示器和离线指示器
  - [x] 15.1 实现 updateCacheIndicator 函数
    - 显示"上次更新"时间
    - 使用 formatAge 格式化
    - _Requirements: 9.1, 9.2, 9.3_
  
  - [x] 15.2 实现 showOfflineIndicator 函数
    - 检测网络状态
    - 显示离线提示
    - _Requirements: 10.4_
  
  - [x] 15.3 实现 showRetryOption 函数
    - 显示重试按钮
    - 点击后重新加载数据
    - _Requirements: 1.5, 10.5_

- [x] 16. 更新 HTML 模板
  - [x] 16.1 添加活动日志容器
    - 在页面添加活动日志卡片
    - _Requirements: 7.1_
  
  - [x] 16.2 添加缓存时间指示器
    - 在配置卡片头部添加更新时间显示
    - _Requirements: 9.1_
  
  - [x] 16.3 添加状态显示区域
    - 添加各组件状态指示器
    - _Requirements: 2.2_

- [x] 17. 更新页面初始化逻辑
  - [x] 17.1 重构 DOMContentLoaded 事件处理
    - 初始化 ActivityLog
    - 使用 loadConfigWithCache 加载配置
    - 使用 loadStatusWithCache 加载状态
    - 启动状态自动刷新
    - 绑定所有事件处理器
    - _Requirements: 1.1, 2.1, 2.3, 7.4_

- [x] 18. Final Checkpoint - 确保所有测试通过
  - 确保所有测试通过，如有问题请询问用户。

## Notes

- 所有任务（包括测试任务）均为必需任务
- 每个任务引用具体的需求条款以确保可追溯性
- 检查点确保增量验证
- 属性测试验证通用正确性属性
- 单元测试验证具体示例和边界情况
