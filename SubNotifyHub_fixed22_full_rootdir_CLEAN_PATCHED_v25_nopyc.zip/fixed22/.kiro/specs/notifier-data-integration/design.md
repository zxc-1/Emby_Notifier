# Design Document: Settings Page Data Integration

## Overview

本设计文档描述通知配置页面（Settings Page）与后端 API 数据打通的技术方案。核心目标是增强现有页面的数据加载、缓存策略、错误处理和用户体验，与 hotlist/forward/tgbot 页面保持一致的架构模式。

设计采用以下架构模式：
- **API 层**: 复用现有后端 API 端点，新增 status.json 端点
- **前端层**: 增强 `static/js/settings.js`，添加 SettingsCache 和 SettingsAPI 模块
- **数据流**: 采用 stale-while-revalidate 模式，优先展示缓存数据

### 现有代码复用分析

| 功能 | 现有代码位置 | 复用方式 |
|------|-------------|---------|
| 配置获取 API | `/admin/settings/config.json` | ✅ 直接复用 |
| 配置保存 API | `/admin/settings/config` | ✅ 直接复用 |
| 状态获取 API | `/admin/settings/status.json` | 🆕 需要新增 |
| Emby 测试 API | `/admin/settings/test_emby` | ✅ 直接复用 |
| 115 测试 API | `/admin/settings/test_115` | ✅ 直接复用 |
| 清空死信 API | `/admin/settings/clear_deadletter` | ✅ 直接复用 |
| 清空去重 API | `/admin/settings/clear_dedup` | ✅ 直接复用 |
| 重置配置 API | `/admin/settings/reset` | ✅ 直接复用 |
| 前端渲染 | `static/js/settings.js` | ✅ 增强，添加缓存和错误处理 |
| Toast 通知 | `static/js/common.js:showToast()` | ✅ 直接复用 |

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        Frontend (Browser)                        │
├─────────────────────────────────────────────────────────────────┤
│  settings.js                                                     │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │ SettingsAPI  │  │SettingsCache│  │ SettingsUI   │          │
│  │ - getConfig  │  │ - get/set    │  │ - fillForm   │          │
│  │ - saveConfig │  │ - isValid    │  │ - updateStat │          │
│  │ - getStatus  │  │ - invalidate │  │ - showToast  │          │
│  │ - testEmby   │  │ - getStale   │  │ - addActivity│          │
│  │ - test115    │  │ - getAge     │  │ - setLoading │          │
│  │ - clearDead  │  │ - formatAge  │  │ - showOffline│          │
│  │ - clearDedup │  │ - clearAll   │  └──────────────┘          │
│  │ - resetConf  │  └──────────────┘                             │
│  └──────────────┘                                               │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼ HTTP/JSON
┌─────────────────────────────────────────────────────────────────┐
│                        Backend (FastAPI)                         │
├─────────────────────────────────────────────────────────────────┤
│  /admin/settings/config.json   → 获取配置                        │
│  /admin/settings/config        → 保存配置                        │
│  /admin/settings/status.json   → 获取状态 (新增)                 │
│  /admin/settings/test_emby     → 测试 Emby 连接                  │
│  /admin/settings/test_115      → 测试 115 连接                   │
│  /admin/settings/clear_deadletter → 清空死信队列                 │
│  /admin/settings/clear_dedup   → 清空去重缓存                    │
│  /admin/settings/reset         → 重置配置                        │
└─────────────────────────────────────────────────────────────────┘
```

## Components and Interfaces

### 1. Backend API

#### 1.1 Config API (`/admin/settings/config.json`) - 已存在

```python
@router.get("/admin/settings/config.json")
async def get_settings_config() -> Dict[str, Any]:
    """返回通知配置"""
    return {
        "ok": True,
        "config": {
            # Emby
            "emby_base_url": str,
            "emby_api_key": str,
            "emby_wait_image": bool,
            "emby_wait_image_max": int,
            # Webhook
            "webhook_secret": str,
            "webhook_allowed_ips": str,
            "webhook_trust_proxy": bool,
            # Notifier
            "notifier_types": str,
            "notifier_queue_size": int,
            "notifier_concurrency": int,
            "notifier_timeout": int,
            "notifier_enqueue_timeout": int,
            "notifier_parallel": bool,
            "notifier_require_all": bool,
            "notifier_dry_run": bool,
            # Retry
            "notifier_max_retry": int,
            "notifier_backoff_base": float,
            "notifier_backoff_max": int,
            "notifier_jitter": float,
            # Aggregate
            "notifier_agg_window": int,
            "notifier_agg_max": int,
            # Pipeline
            "pipeline_steps": str,
            "pipeline_strict": bool,
            # Dedup
            "episode_dedup_strategy": str,
            "dedup_ttl": int,
            "dedup_max_size": int,
            "dedup_persistent": bool,
            # Advanced
            "tmdb_api_key": str,
            "cloud115_cookie": str,
            "log_level": str,
            "debug_history_size": int,
            "debug_enable_api": bool
        }
    }
```

#### 1.2 Status API (`/admin/settings/status.json`) - 需要新增

```python
@router.get("/admin/settings/status.json")
async def get_settings_status() -> Dict[str, Any]:
    """返回系统运行状态"""
    settings = get_settings()
    return {
        "ok": True,
        "status": {
            "emby_connected": bool,      # Emby 是否已配置且可连接
            "tmdb_configured": bool,     # TMDB API Key 是否已配置
            "notifier_ready": bool,      # 通知器是否就绪
            "webhook_configured": bool,  # Webhook Secret 是否已配置
            "cloud115_configured": bool  # 115 Cookie 是否已配置
        }
    }
```

### 2. Frontend Components (需要增强)

#### 2.1 SettingsCache Module

```javascript
const SettingsCache = {
    CONFIG_KEY: 'snh_settings_config_cache',
    STATUS_KEY: 'snh_settings_status_cache',
    ACTIVITY_KEY: 'snh_settings_activity_log',
    CONFIG_TTL: 2 * 60 * 1000,   // 2 minutes for config
    STATUS_TTL: 30 * 1000,       // 30 seconds for status
    
    // 获取缓存数据
    get(key) {
        try {
            const raw = localStorage.getItem(key);
            if (!raw) return null;
            return JSON.parse(raw);
        } catch (e) {
            return null;
        }
    },
    
    // 设置缓存数据
    set(key, data, ttl) {
        try {
            const item = { data, timestamp: Date.now(), ttl };
            localStorage.setItem(key, JSON.stringify(item));
        } catch (e) {
            console.warn('Cache set failed:', e);
        }
    },
    
    // 检查缓存是否有效
    isValid(key) {
        const item = this.get(key);
        if (!item) return false;
        return Date.now() - item.timestamp < item.ttl;
    },
    
    // 清除缓存
    invalidate(key) {
        localStorage.removeItem(key);
    },
    
    // 获取过期数据（用于 stale-while-revalidate）
    getStale(key) {
        const item = this.get(key);
        return item ? item.data : null;
    },
    
    // 获取缓存年龄（毫秒）
    getAge(key) {
        const item = this.get(key);
        if (!item) return Infinity;
        return Date.now() - item.timestamp;
    },
    
    // 格式化缓存时间
    formatAge(key) {
        const age = this.getAge(key);
        if (age === Infinity) return '未知';
        if (age < 60000) return '刚刚';
        if (age < 3600000) return `${Math.floor(age / 60000)} 分钟前`;
        return `${Math.floor(age / 3600000)} 小时前`;
    },
    
    // 清除所有缓存
    clearAll() {
        localStorage.removeItem(this.CONFIG_KEY);
        localStorage.removeItem(this.STATUS_KEY);
        localStorage.removeItem(this.ACTIVITY_KEY);
    }
};
```

#### 2.2 SettingsAPI Module

```javascript
const SettingsAPI = {
    // 获取配置
    async getConfig() {
        const res = await fetch('/admin/settings/config.json');
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return await res.json();
    },
    
    // 保存配置
    async saveConfig(config) {
        const res = await fetch('/admin/settings/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(config)
        });
        return await res.json();
    },
    
    // 获取状态
    async getStatus() {
        const res = await fetch('/admin/settings/status.json');
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return await res.json();
    },
    
    // 测试 Emby 连接
    async testEmby(url, key) {
        const res = await fetch('/admin/settings/test_emby', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ url, key })
        });
        return await res.json();
    },
    
    // 测试 115 连接
    async test115(cookie) {
        const res = await fetch('/admin/settings/test_115', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ cookie })
        });
        return await res.json();
    },
    
    // 清空死信队列
    async clearDeadletter() {
        const res = await fetch('/admin/settings/clear_deadletter', { method: 'POST' });
        return await res.json();
    },
    
    // 清空去重缓存
    async clearDedup() {
        const res = await fetch('/admin/settings/clear_dedup', { method: 'POST' });
        return await res.json();
    },
    
    // 重置配置
    async resetConfig() {
        const res = await fetch('/admin/settings/reset', { method: 'POST' });
        return await res.json();
    }
};
```

#### 2.3 Activity Log Module

```javascript
const ActivityLog = {
    MAX_ENTRIES: 10,
    
    // 添加日志
    add(msg) {
        const logs = this.getAll();
        const entry = {
            time: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }),
            msg
        };
        logs.unshift(entry);
        if (logs.length > this.MAX_ENTRIES) {
            logs.length = this.MAX_ENTRIES;
        }
        this.save(logs);
        this.render(logs);
    },
    
    // 获取所有日志
    getAll() {
        const raw = localStorage.getItem(SettingsCache.ACTIVITY_KEY);
        if (!raw) return [];
        try {
            return JSON.parse(raw);
        } catch (e) {
            return [];
        }
    },
    
    // 保存日志
    save(logs) {
        localStorage.setItem(SettingsCache.ACTIVITY_KEY, JSON.stringify(logs));
    },
    
    // 渲染日志
    render(logs) {
        const container = document.getElementById('activityLog');
        if (!container) return;
        
        if (logs.length === 0) {
            container.innerHTML = '<div class="activity-empty">暂无活动记录</div>';
            return;
        }
        
        container.innerHTML = logs.map(log => `
            <div class="activity-item">
                <span class="activity-time">${escapeHtml(log.time)}</span>
                <span class="activity-msg">${escapeHtml(log.msg)}</span>
            </div>
        `).join('');
    },
    
    // 初始化
    init() {
        this.render(this.getAll());
    }
};
```

#### 2.4 数据加载模式

```javascript
// Stale-while-revalidate 模式
async function loadConfigWithCache() {
    // 1. 先显示缓存数据
    const cached = SettingsCache.getStale(SettingsCache.CONFIG_KEY);
    if (cached && cached.config) {
        fillForm(cached.config);
        updateCacheIndicator('config');
    }
    
    // 2. 后台获取最新数据
    try {
        const data = await SettingsAPI.getConfig();
        if (data.ok) {
            SettingsCache.set(SettingsCache.CONFIG_KEY, data, SettingsCache.CONFIG_TTL);
            fillForm(data.config);
            updateCacheIndicator('config');
        }
    } catch (error) {
        if (!cached) {
            showError('加载配置失败', () => loadConfigWithCache());
        }
    }
}

// 状态自动刷新
let statusInterval = null;

async function loadStatusWithCache() {
    const cached = SettingsCache.getStale(SettingsCache.STATUS_KEY);
    if (cached && cached.status) {
        updateStatusDisplay(cached.status);
    }
    
    try {
        const data = await SettingsAPI.getStatus();
        if (data.ok && data.status) {
            SettingsCache.set(SettingsCache.STATUS_KEY, data, SettingsCache.STATUS_TTL);
            updateStatusDisplay(data.status);
        }
    } catch (error) {
        if (!cached) {
            updateStatusDisplay(null);
        }
    }
}

function startStatusAutoRefresh() {
    if (statusInterval) clearInterval(statusInterval);
    statusInterval = setInterval(loadStatusWithCache, 30000);
}
```

## Data Models

### Frontend Data Structures

```typescript
interface SettingsConfig {
    // Emby
    emby_base_url: string;
    emby_api_key: string;
    emby_wait_image: boolean;
    emby_wait_image_max: number;
    // Webhook
    webhook_secret: string;
    webhook_allowed_ips: string;
    webhook_trust_proxy: boolean;
    // Notifier
    notifier_types: string;
    notifier_queue_size: number;
    notifier_concurrency: number;
    notifier_timeout: number;
    notifier_enqueue_timeout: number;
    notifier_parallel: boolean;
    notifier_require_all: boolean;
    notifier_dry_run: boolean;
    // Retry
    notifier_max_retry: number;
    notifier_backoff_base: number;
    notifier_backoff_max: number;
    notifier_jitter: number;
    // Aggregate
    notifier_agg_window: number;
    notifier_agg_max: number;
    // Pipeline
    pipeline_steps: string;
    pipeline_strict: boolean;
    // Dedup
    episode_dedup_strategy: string;
    dedup_ttl: number;
    dedup_max_size: number;
    dedup_persistent: boolean;
    // Advanced
    tmdb_api_key: string;
    cloud115_cookie: string;
    log_level: string;
    debug_history_size: number;
    debug_enable_api: boolean;
}

interface SettingsStatus {
    emby_connected: boolean;
    tmdb_configured: boolean;
    notifier_ready: boolean;
    webhook_configured: boolean;
    cloud115_configured: boolean;
}

interface CacheEntry<T> {
    data: T;
    timestamp: number;
    ttl: number;
}

interface ActivityLogEntry {
    time: string;      // HH:MM format
    msg: string;
}

interface APIResponse<T = any> {
    ok: boolean;
    detail?: string;
    config?: SettingsConfig;
    status?: SettingsStatus;
}
```

