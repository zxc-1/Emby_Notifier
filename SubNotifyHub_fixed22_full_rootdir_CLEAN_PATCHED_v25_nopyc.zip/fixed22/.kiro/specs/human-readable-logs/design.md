# Design Document: Human-Readable Logs

## Overview

本设计文档描述如何将项目日志系统改进为"人话版"日志。核心工作包括：

1. **迁移遗留日志** - 将所有 `logger.info/warning/error` 改成 BizLogger 方法
2. **详细化日志消息** - 让每条日志都清楚说明在做什么、为什么、以及如何处理
3. **强制颜色输出** - 支持 `LOG_FORCE_COLOR=1` 在 Docker 环境下启用颜色

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                      迁移前（遗留日志）                          │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  logger = get_biz_logger_adapter(__name__)               │  │
│  │  logger.info("tg webhook: setWebhook ok")                │  │
│  │  logger.warning("tg_poll: HTTP error")                   │  │
│  └──────────────────────────────────────────────────────────┘  │
│                              ↓                                  │
│                         迁移工作                                │
│                              ↓                                  │
│  ┌──────────────────────────────────────────────────────────┐  │
│  │  biz = get_biz_logger(__name__)                          │  │
│  │  biz.ok("✅ Telegram Webhook 设置成功...")               │  │
│  │  biz.warn("⚠️ 切换轮询模式时网络错误...")                │  │
│  └──────────────────────────────────────────────────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

## Components and Interfaces

### 1. 颜色控制增强 (core/runtime_env.py)

```python
def should_use_log_color() -> bool:
    """Whether console logging should use ANSI colors.
    
    Priority:
    1. LOG_COLOR=0 → disable (highest priority)
    2. NO_COLOR (any value) → disable
    3. LOG_FORCE_COLOR=1 → enable (ignore TTY check)
    4. Default: TTY check
    """
    # LOG_COLOR=0 has highest priority
    v = str(os.getenv("LOG_COLOR", "")).strip().lower()
    if v in ("0", "false", "no", "off"):
        return False
    
    # NO_COLOR standard
    if str(os.getenv("NO_COLOR", "")).strip():
        return False
    
    # LOG_FORCE_COLOR=1 forces color
    force = str(os.getenv("LOG_FORCE_COLOR", "")).strip().lower()
    if force in ("1", "true", "yes", "on"):
        return True
    
    # Default: TTY check (existing behavior)
    return sys.stderr.isatty() or sys.stdout.isatty()
```

### 2. BizLogger 使用模式

迁移后的代码应使用以下模式：

```python
from core.logging import get_biz_logger

biz = get_biz_logger(__name__)

# 信息日志
biz.info("ℹ️ 详细的中文描述...")

# 成功日志
biz.ok("✅ 操作成功的详细描述...")

# 警告日志
biz.warn("⚠️ 警告的详细描述，包括原因和建议...")

# 错误日志
biz.fail("❌ 错误的详细描述，包括原因和解决方法...", exc=e)

# 带上下文的日志
with biz.entry(domain="TG机器人", action="Webhook"):
    biz.step("第1步 检查配置...")
    biz.ok("✅ 配置检查通过")
```

### 3. 日志消息模板

每个模块应定义清晰的日志消息常量：

```python
# tg_bot/infra/webhook_setup.py

_LOG_WEBHOOK_DISABLED = (
    "ℹ️ Telegram Webhook 设置已跳过：入站功能已禁用"
    "（TG_BOT_INBOUND_ENABLED=false），如需接收消息请启用"
)

_LOG_WEBHOOK_NO_URL = (
    "⚠️ Telegram Webhook 设置已跳过：未配置 Webhook 地址。"
    "请设置 TG_BOT_WEBHOOK_URL 或同时设置 "
    "TG_BOT_WEBHOOK_BASE_URL 和 TG_BOT_WEBHOOK_SECRET"
)

_LOG_WEBHOOK_SUCCESS = (
    "✅ Telegram Webhook 设置成功，"
    "Telegram 服务器将把消息推送到此地址"
)

_LOG_WEBHOOK_FAILED = (
    "❌ Telegram Webhook 设置失败：{desc}。"
    "请检查 Webhook 地址是否可从公网访问、SSL 证书是否有效"
)
```

## Data Models

### 日志消息结构

每条日志消息应包含以下元素：

```
[emoji] [操作描述]：[详细说明]。[建议/后续步骤]
```

示例：
- `✅ Telegram Webhook 设置成功，Telegram 服务器将把消息推送到此地址`
- `⚠️ 超时配置无效：TMDB_TIMEOUT="abc" 不是数字，将使用默认值 10.0 秒`
- `❌ 发送 Telegram 消息失败：消息内容类型错误（内部 bug），已返回错误提示给用户`

### KV 字段命名规范

| 英文字段 | 中文字段 |
|---------|---------|
| url | 地址 |
| chat_id | 聊天ID |
| status_code | 状态码 |
| error | 错误 |
| method | 方法 |
| timeout | 超时 |
| retry | 重试 |
| queue_size | 队列状态 |
| duration_ms | 耗时 |
| offset | 偏移量 |

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do.*

### Property 1: 颜色控制优先级

*For any* 环境变量组合，颜色输出应遵循以下优先级：
1. LOG_COLOR=0 → 禁用颜色
2. NO_COLOR 非空 → 禁用颜色
3. LOG_FORCE_COLOR=1 → 启用颜色（忽略 TTY）
4. 默认 → TTY 检测

**Validates: Requirements 6.1, 6.2, 6.3**

### Property 2: JSON 日志完整性

*For any* 日志记录，当输出为 JSON 格式时，应包含所有必要字段：ts、level、logger、message、kind、trace_id、span_id、phase、step、indent、kv。

**Validates: Requirements 7.1, 7.4**

### Property 3: BIZ_DETAIL 控制

*For any* 调用 `biz.detail()` 或 `biz.detail_step()`，当 BIZ_DETAIL 未设置或为空时不应输出日志；当设置为 "1" 或 "true" 时应输出日志。

**Validates: Requirements 7.3**

## Error Handling

### 日志迁移错误处理原则

1. **保持原有行为** - 迁移后的日志应保持原有的错误处理逻辑
2. **不影响业务** - 日志输出失败不应影响业务流程
3. **静默降级** - 如果 BizLogger 方法失败，应静默降级而非抛出异常

### 迁移注意事项

```python
# 原代码
try:
    ...
except Exception as e:
    logger.warning("operation failed", exc_info=True)

# 迁移后
try:
    ...
except Exception as e:
    biz.warn("⚠️ 操作失败：详细描述...", exc=e)
```

## Testing Strategy

### 测试框架

- **单元测试**: pytest
- **属性测试**: hypothesis

### 测试覆盖

| 组件 | 测试类型 | 说明 |
|------|---------|------|
| should_use_log_color() | 属性测试 | 验证颜色控制优先级 |
| JsonLineFormatter | 属性测试 | 验证 JSON 输出完整性 |
| is_detail_enabled() | 属性测试 | 验证 BIZ_DETAIL 控制 |
| 各模块迁移 | 示例测试 | 验证日志输出格式正确 |

### 属性测试配置

```python
from hypothesis import given, strategies as st, settings

@settings(max_examples=100)
@given(
    log_color=st.sampled_from(["", "0", "1", "false", "true"]),
    no_color=st.sampled_from(["", "1"]),
    force_color=st.sampled_from(["", "0", "1", "true"]),
)
def test_color_priority(log_color, no_color, force_color):
    """Feature: human-readable-logs, Property 1: 颜色控制优先级"""
    with patch.dict(os.environ, {
        "LOG_COLOR": log_color,
        "NO_COLOR": no_color,
        "LOG_FORCE_COLOR": force_color,
    }, clear=True):
        result = should_use_log_color()
        
        # LOG_COLOR=0 has highest priority
        if log_color in ("0", "false"):
            assert result is False
        # NO_COLOR disables
        elif no_color:
            assert result is False
        # LOG_FORCE_COLOR=1 enables
        elif force_color in ("1", "true"):
            assert result is True
```

## Migration Checklist

### TG Bot 模块

- [ ] `tg_bot/infra/polling.py` - 约 10 处日志
- [ ] `tg_bot/infra/webhook_setup.py` - 约 5 处日志
- [ ] `tg_bot/infra/telegram_api.py` - 约 8 处日志
- [ ] `tg_bot/infra/outbox.py` - 约 2 处日志
- [ ] `tg_bot/storage/db.py` - 约 1 处日志
- [ ] `tg_bot/common/parser.py` - 约 1 处日志
- [ ] `tg_bot/features/mediahelp/handlers.py` - 约 1 处日志

### Settings 模块

- [ ] `settings/urls.py` - 约 1 处日志
- [ ] `settings/timeouts.py` - 约 2 处日志
- [ ] `settings/retries.py` - 约 6 处日志
- [ ] `settings/database.py` - 约 2 处日志
- [ ] `settings/caches.py` - 约 4 处日志
- [ ] `settings/runtime.py` - 约 2 处日志
- [ ] `settings/base.py` - 约 1 处日志

### Notifier 模块

- [ ] `notifier/worker_deadletter.py` - 约 1 处日志
- [ ] `notifier/templates/registry.py` - 约 1 处日志

### 其他模块

- [ ] `core/` 目录下的遗留日志
- [ ] `integrations/` 目录下的遗留日志
- [ ] `douban_hotlist/` 目录下的遗留日志
- [ ] `forward_bridge/` 目录下的遗留日志
