# Requirements Document

## Introduction

当前项目日志系统存在以下问题：

1. **遗留的普通日志** - 很多模块仍使用 `logger.info/warning/error`，没有迁移到 BizLogger
2. **日志消息不够详细** - 很多消息是英文或简短的技术术语，看不懂在做什么
3. **颜色没有生效** - 在 Docker 或非 TTY 环境下，颜色被自动禁用

本次优化分两步：
1. **第一步：迁移遗留日志** - 把所有 `logger.info/warning/error` 改成 BizLogger 的方法
2. **第二步：优化日志内容** - 让每条日志消息都清晰描述在做什么

## Glossary

- **BizLogger**: 业务日志 DSL，提供 `step()`、`ok()`、`warn()`、`fail()`、`info()` 等方法
- **Legacy_Log**: 遗留的普通日志，使用 `logger.info/warning/error`
- **LOG_FORCE_COLOR**: 环境变量，强制启用颜色输出

## Requirements

### Requirement 1: 迁移 TG Bot 模块的遗留日志

**User Story:** As a 开发者, I want TG Bot 模块使用统一的业务日志, so that 日志风格一致。

#### Acceptance Criteria

1. THE `tg_bot/infra/polling.py` SHALL 将所有 `logger.info/warning` 改成 BizLogger 方法
2. THE `tg_bot/infra/webhook_setup.py` SHALL 将所有 `logger.info/warning` 改成 BizLogger 方法
3. THE `tg_bot/infra/telegram_api.py` SHALL 将所有 `logger.warning/error` 改成 BizLogger 方法
4. THE `tg_bot/infra/outbox.py` SHALL 将所有 `logger.warning` 改成 BizLogger 方法
5. THE `tg_bot/storage/db.py` SHALL 将 `logger.info` 改成 BizLogger 方法
6. THE `tg_bot/common/parser.py` SHALL 将 `logger.info` 改成 BizLogger 方法
7. THE `tg_bot/features/mediahelp/handlers.py` SHALL 将 `logger.warning` 改成 BizLogger 方法

#### 迁移映射规则

| 原方法 | 新方法 | 说明 |
|-------|-------|------|
| `logger.info(msg)` | `biz.info(msg)` 或 `biz.ok(msg)` | 信息或成功 |
| `logger.warning(msg)` | `biz.warn(msg)` | 警告 |
| `logger.error(msg)` | `biz.fail(msg)` | 错误 |
| `logger.debug(msg)` | `biz.detail(msg)` | 详细信息（受 BIZ_DETAIL 控制） |

### Requirement 2: 迁移 Settings 模块的遗留日志

**User Story:** As a 开发者, I want Settings 模块使用统一的业务日志, so that 配置加载过程清晰可见。

#### Acceptance Criteria

1. THE `settings/urls.py` SHALL 将 `logger.warning` 改成 BizLogger 方法
2. THE `settings/timeouts.py` SHALL 将 `logger.warning` 改成 BizLogger 方法
3. THE `settings/retries.py` SHALL 将 `logger.warning` 改成 BizLogger 方法
4. THE `settings/database.py` SHALL 将 `logger.warning` 改成 BizLogger 方法
5. THE `settings/caches.py` SHALL 将 `logger.warning` 改成 BizLogger 方法
6. THE `settings/runtime.py` SHALL 将 `logger.info` 改成 BizLogger 方法
7. THE `settings/base.py` SHALL 将 `logger.warning` 改成 BizLogger 方法

### Requirement 3: 迁移 Notifier 模块的遗留日志

**User Story:** As a 开发者, I want Notifier 模块使用统一的业务日志, so that 通知处理过程清晰可见。

#### Acceptance Criteria

1. THE `notifier/worker_deadletter.py` SHALL 将 `logger.warning` 改成 BizLogger 方法
2. THE `notifier/templates/registry.py` SHALL 将 `logger.warning` 改成 BizLogger 方法
3. THE `notifier/telegram/telegram_notifier.py` SHALL 将所有遗留日志改成 BizLogger 方法

### Requirement 4: 迁移其他模块的遗留日志

**User Story:** As a 开发者, I want 所有模块使用统一的业务日志, so that 整个项目日志风格一致。

#### Acceptance Criteria

1. THE `core/` 目录下的所有模块 SHALL 将遗留日志改成 BizLogger 方法
2. THE `integrations/` 目录下的所有模块 SHALL 将遗留日志改成 BizLogger 方法
3. THE `douban_hotlist/` 目录下的所有模块 SHALL 将遗留日志改成 BizLogger 方法
4. THE `forward_bridge/` 目录下的所有模块 SHALL 将遗留日志改成 BizLogger 方法

### Requirement 5: 日志消息中文化和详细化

**User Story:** As a 用户, I want 所有日志消息都是中文且详细, so that 我能理解系统每一步在做什么。

#### Acceptance Criteria

1. THE Log_Message SHALL 使用中文描述正在执行的操作
2. THE Log_Message SHALL 清晰说明操作的目的、过程和结果
3. THE Error_Message SHALL 说明出了什么问题、可能的原因、以及建议的解决方法
4. THE Warning_Message SHALL 说明为什么跳过、有什么影响、以及是否需要用户处理
5. THE KV_Fields SHALL 使用有意义的中文字段名

#### TG Bot 模块日志消息改进

| 文件 | 当前消息 | 改进后消息 |
|-----|---------|----------|
| webhook_setup.py | `tg webhook: inbound disabled; skip setWebhook` | `ℹ️ Telegram Webhook 设置已跳过：入站功能已禁用（TG_BOT_INBOUND_ENABLED=false），如需接收消息请启用` |
| webhook_setup.py | `tg webhook: missing TG_BOT_WEBHOOK_URL...` | `⚠️ Telegram Webhook 设置已跳过：未配置 Webhook 地址。请设置 TG_BOT_WEBHOOK_URL 或同时设置 TG_BOT_WEBHOOK_BASE_URL 和 TG_BOT_WEBHOOK_SECRET` |
| webhook_setup.py | `tg webhook: setWebhook failed (no response)` | `❌ Telegram Webhook 设置失败：API 无响应，请检查网络连接和 TG_BOT_TOKEN 是否正确` |
| webhook_setup.py | `tg webhook: setWebhook ok url=%s` | `✅ Telegram Webhook 设置成功，Telegram 服务器将把消息推送到此地址` |
| webhook_setup.py | `tg webhook: setWebhook failed ok=%s desc=%s` | `❌ Telegram Webhook 设置失败：{错误描述}。请检查 Webhook 地址是否可从公网访问、SSL 证书是否有效` |
| polling.py | `tg_poll: bot commands synced` | `✅ Telegram 机器人命令菜单已同步，用户可以在聊天框中看到 /start、/help 等命令提示` |
| polling.py | `tg_poll: ensure_polling_mode HTTP error` | `⚠️ 切换到轮询模式时网络错误：{错误类型}。将在下次循环重试，不影响已有功能` |
| polling.py | `tg_poll: ensure_bot_commands HTTP error` | `⚠️ 同步机器人命令菜单时网络错误：{错误类型}。命令仍可使用，只是菜单提示可能不显示` |
| polling.py | `tg_poll: process_update transient error` | `⚠️ 处理 Telegram 消息时遇到临时错误（第 {attempt} 次），将自动重试` |
| telegram_api.py | `tg_bot: missing TG_BOT_TOKEN; cannot reply` | `⚠️ 无法发送 Telegram 消息：未配置 TG_BOT_TOKEN。请在环境变量或配置文件中设置机器人 Token` |
| telegram_api.py | `tg_bot: invalid outgoing text type` | `❌ 发送 Telegram 消息失败：消息内容类型错误（内部 bug），已返回错误提示给用户` |
| telegram_api.py | `tg_bot: API failed method=%s desc=%s` | `⚠️ Telegram API 调用失败：{方法名} - {错误描述}。如果是 "Too Many Requests" 请稍后重试` |
| telegram_api.py | `tg_get_updates error` | `⚠️ 获取 Telegram 新消息失败：{错误信息}。轮询将继续，可能会有短暂延迟` |
| outbox.py | `tg outbox queue full for chat_id=%s; bypassing outbox` | `⚠️ 消息发送队列已满（聊天 ID: {chat_id}），绕过队列直接发送。如果频繁出现请检查是否有消息风暴` |

#### Settings 模块日志消息改进

| 文件 | 当前消息 | 改进后消息 |
|-----|---------|----------|
| urls.py | `Invalid URL value: %s=%s, using default` | `⚠️ URL 配置无效：{配置项}="{值}" 不是有效的 URL 格式，将使用默认值。请检查是否包含 http:// 或 https://` |
| timeouts.py | `Invalid timeout value (must be positive finite)` | `⚠️ 超时配置无效：{配置项}="{值}" 必须是正数，将使用默认值 {默认值} 秒` |
| timeouts.py | `Invalid timeout value (not a number)` | `⚠️ 超时配置无效：{配置项}="{值}" 不是数字，将使用默认值 {默认值} 秒` |
| retries.py | `Invalid retry max (must be non-negative)` | `⚠️ 重试次数配置无效：{配置项}="{值}" 必须是非负整数，将使用默认值 {默认值} 次` |
| retries.py | `Invalid backoff base (must be non-negative finite)` | `⚠️ 退避基数配置无效：{配置项}="{值}" 必须是非负数，将使用默认值 {默认值} 秒` |
| database.py | `Invalid DB config (must be non-negative)` | `⚠️ 数据库配置无效：{配置项}="{值}" 必须是非负整数，将使用默认值` |
| caches.py | `Invalid cache TTL (must be positive)` | `⚠️ 缓存 TTL 配置无效：{配置项}="{值}" 必须是正整数（秒），将使用默认值 {默认值} 秒` |
| caches.py | `Invalid cache size (must be positive)` | `⚠️ 缓存大小配置无效：{配置项}="{值}" 必须是正整数，将使用默认值 {默认值}` |
| runtime.py | `settings: reload done (new singleton)` | `✅ 配置首次加载完成，所有设置已生效` |
| runtime.py | `settings: reload done` | `✅ 配置热重载完成，新设置已生效（无需重启）` |
| base.py | `TG bot features enabled but TG_BOT_TOKEN is empty` | `⚠️ Telegram 机器人功能已启用但未配置 Token：TG_JOB_ENABLED={job} TG_BOT_INBOUND_ENABLED={inbound}。相关功能将在运行时跳过，请设置 TG_BOT_TOKEN` |

#### Notifier 模块日志消息改进

| 文件 | 当前消息 | 改进后消息 |
|-----|---------|----------|
| worker_deadletter.py | `write deadletter failed` | `⚠️ 写入死信文件失败：无法保存失败的通知任务，该任务将丢失。请检查磁盘空间和写入权限` |
| templates/registry.py | `template registry overwrite: %s (%s -> %s)` | `⚠️ 模板注册覆盖：模板 "{模板名}" 被新实现替换（{旧实现} → {新实现}），如非预期请检查是否有重复注册` |

#### Storage 模块日志消息改进

| 文件 | 当前消息 | 改进后消息 |
|-----|---------|----------|
| db.py | `tg_bot 数据库连接池已关闭` | `✅ Telegram 机器人数据库连接池已关闭，所有连接已释放` |
| parser.py | `cloud115_offline: url detect miss` | `ℹ️ 检测到 ed2k/magnet 链接但未能提取 115 离线 URL，可能是格式不标准` |
| mediahelp/handlers.py | `update subscription failed: %s %s` | `⚠️ 更新 MediaHelp 订阅失败：HTTP 状态码={code}，响应={响应片段}。订阅可能未生效` |

### Requirement 6: 强制颜色输出

**User Story:** As a Docker 用户, I want 在容器日志中看到颜色, so that 我能快速区分成功/警告/错误。

#### Acceptance Criteria

1. WHEN LOG_FORCE_COLOR=1 THEN THE Formatter SHALL 强制启用 ANSI 颜色（忽略 TTY 检测）
2. WHEN LOG_COLOR=0 THEN THE Formatter SHALL 禁用颜色（优先级最高）
3. THE Default_Behavior SHALL 保持现有逻辑（TTY 检测）
4. THE Color_Scheme SHALL 使用现有的 kind 到颜色映射

### Requirement 7: 向后兼容

**User Story:** As a 开发者, I want 保留开发者调试能力, so that 我能定位问题。

#### Acceptance Criteria

1. THE JSON_Log SHALL 保持完整的结构化数据（不受人话版影响）
2. THE File_Log SHALL 可配置为 JSON 格式（LOG_FILE_FORMAT=json）
3. THE Debug_Log SHALL 通过 BIZ_DETAIL 环境变量控制详细日志输出
4. THE Trace_Info SHALL 在 JSON 日志中保留（trace_id、span_id 等）

### Requirement 8: 示例输出对比

#### 示例 1：Telegram Webhook 设置流程

**当前日志：**
```
2026-01-16 10:30:45 | INFO | tg_bot.infra.webhook_setup:setup:62 | tg webhook: inbound disabled; skip setWebhook
2026-01-16 10:30:46 | WARNING | tg_bot.infra.webhook_setup:setup:67 | tg webhook: missing TG_BOT_WEBHOOK_URL (or TG_BOT_WEBHOOK_BASE_URL + TG_BOT_WEBHOOK_SECRET); skip setWebhook
2026-01-16 10:30:47 | INFO | tg_bot.infra.webhook_setup:setup:90 | tg webhook: setWebhook ok url=https://example.com/webhook
```

**改进后日志：**
```
2026-01-16 10:30:45 | INFO | TG机器人/Webhook | ℹ️ Telegram Webhook 设置已跳过：入站功能已禁用（TG_BOT_INBOUND_ENABLED=false），如需接收消息请启用
2026-01-16 10:30:46 | WARNING | TG机器人/Webhook | ⚠️ Telegram Webhook 设置已跳过：未配置 Webhook 地址。请设置 TG_BOT_WEBHOOK_URL 或同时设置 TG_BOT_WEBHOOK_BASE_URL 和 TG_BOT_WEBHOOK_SECRET
2026-01-16 10:30:47 | INFO | TG机器人/Webhook | ✅ Telegram Webhook 设置成功，Telegram 服务器将把消息推送到此地址 | 地址=https://example.com/webhook
```

#### 示例 2：Telegram 轮询启动流程

**当前日志：**
```
2026-01-16 10:30:45 | INFO | tg_bot.infra.polling:run_polling:230 | offset=0 | step=tg_poll phase=boot
2026-01-16 10:30:46 | INFO | tg_bot.infra.polling:ensure_polling_mode:120 | deleteWebhook ok | step=tg_poll phase=mode
2026-01-16 10:30:47 | INFO | tg_bot.infra.polling:ensure_bot_commands:163 | tg_poll: bot commands synced
2026-01-16 10:30:48 | INFO | tg_bot.infra.polling:run_polling:275 | offset=0 | step=tg_poll phase=started
```

**改进后日志：**
```
2026-01-16 10:30:45 | INFO | TG机器人/轮询 | ▶️ 开始启动 Telegram 消息轮询服务 | 初始偏移量=0
2026-01-16 10:30:46 | INFO | TG机器人/轮询 | ✅ 已切换到轮询模式（删除 Webhook 成功），将主动拉取新消息
2026-01-16 10:30:47 | INFO | TG机器人/轮询 | ✅ Telegram 机器人命令菜单已同步，用户可以在聊天框中看到 /start、/help 等命令提示
2026-01-16 10:30:48 | INFO | TG机器人/轮询 | ✅ Telegram 消息轮询服务启动完成，开始监听新消息 | 偏移量=0
```

#### 示例 3：配置加载警告

**当前日志：**
```
2026-01-16 10:30:45 | WARNING | settings.timeouts:get_timeout:118 | Invalid timeout value (not a number): TMDB_TIMEOUT=abc, using default
2026-01-16 10:30:45 | WARNING | settings.retries:get_retry_config:147 | Invalid retry max (not an integer): TMDB_RETRY_MAX=xyz, using default
2026-01-16 10:30:45 | WARNING | settings.base:__init__:323 | TG bot features enabled but TG_BOT_TOKEN is empty; TG inbound/jobs may be skipped at runtime
```

**改进后日志：**
```
2026-01-16 10:30:45 | WARNING | 配置/超时 | ⚠️ 超时配置无效：TMDB_TIMEOUT="abc" 不是数字，将使用默认值 10.0 秒
2026-01-16 10:30:45 | WARNING | 配置/重试 | ⚠️ 重试次数配置无效：TMDB_RETRY_MAX="xyz" 必须是非负整数，将使用默认值 3 次
2026-01-16 10:30:45 | WARNING | 配置/验证 | ⚠️ Telegram 机器人功能已启用但未配置 Token：TG_JOB_ENABLED=true TG_BOT_INBOUND_ENABLED=true。相关功能将在运行时跳过，请设置 TG_BOT_TOKEN
```

#### 示例 4：消息处理错误

**当前日志：**
```
2026-01-16 10:30:45 | WARNING | tg_bot.infra.polling:run_polling:319 | tg_poll: process_update transient error update_id=12345 attempt=1 err=ConnectTimeout
2026-01-16 10:30:46 | WARNING | tg_bot.infra.telegram_api:_tg_call_json:187 | tg_bot: API failed method=sendMessage desc=Too Many Requests: retry after 30
2026-01-16 10:30:47 | WARNING | tg_bot.infra.outbox:enqueue:96 | tg outbox queue full for chat_id=123456; bypassing outbox
```

**改进后日志：**
```
2026-01-16 10:30:45 | WARNING | TG机器人/轮询 | ⚠️ 处理 Telegram 消息时遇到临时错误（第 1 次），将自动重试 | 消息ID=12345 错误=ConnectTimeout
2026-01-16 10:30:46 | WARNING | TG机器人/API | ⚠️ Telegram API 调用失败：sendMessage - 请求过于频繁，需等待 30 秒后重试
2026-01-16 10:30:47 | WARNING | TG机器人/发送队列 | ⚠️ 消息发送队列已满（聊天 ID: 123456），绕过队列直接发送。如果频繁出现请检查是否有消息风暴
```

#### 示例 5：通知处理流程（已有 BizLogger）

**当前日志（已经比较好，但可以更详细）：**
```
2026-01-16 10:30:45 | INFO | notifier.worker:enqueue:203 | Notifier/入队 | ▶️ 通知入队
2026-01-16 10:30:45 | INFO | notifier.worker:enqueue:205 | Notifier/入队 |   第1步/共4步 构建入队任务
2026-01-16 10:30:45 | INFO | notifier.worker:enqueue:212 | Notifier/入队 |   第2步/共4步 计算 dedup 签名
```

**改进后日志（更详细的业务描述）：**
```
2026-01-16 10:30:45 | INFO | 通知/入队 | ▶️ 开始处理新的媒体通知入队请求
2026-01-16 10:30:45 | INFO | 通知/入队 |   第1步/共4步 构建入队任务：解析 Webhook 数据，提取媒体信息
2026-01-16 10:30:45 | INFO | 通知/入队 |   第2步/共4步 计算去重签名：根据媒体 ID 和事件类型生成唯一标识，避免重复通知
2026-01-16 10:30:45 | INFO | 通知/入队 |   第3步/共4步 检查是否重复：查询最近 5 分钟内是否已处理过相同通知
2026-01-16 10:30:45 | INFO | 通知/入队 |   第4步/共4步 写入处理队列：将任务加入后台队列等待处理
2026-01-16 10:30:45 | INFO | 通知/入队 |   ✅ 通知入队成功，将在后台异步处理 | 队列状态=1/100
```
