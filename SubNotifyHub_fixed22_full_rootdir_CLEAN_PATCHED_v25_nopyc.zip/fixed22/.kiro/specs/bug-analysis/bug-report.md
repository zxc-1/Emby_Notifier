# 项目 Bug 分析报告

生成时间：2026-01-17

## 执行摘要

通过全面的静态代码分析和模式检测，发现了以下几类潜在问题：

1. **资源泄漏风险**：1 处文件句柄未正确关闭
2. **SQL 注入风险**：3 处动态 SQL 构建（已验证安全）
3. **异常处理问题**：5 处静默异常（已优化但仍需关注）
4. **异步任务管理**：多处 `asyncio.create_task` 使用（大部分已正确管理）
5. **编码问题**：潜在的中文编码处理风险

---

## 🔴 高优先级问题

### 1. 文件锁资源泄漏

**位置**：`core/storage/file_lock.py:51`

**问题描述**：
```python
f = open(lock_path, "a+b")  # ❌ 未使用 with 语句
```

文件句柄在异常情况下可能无法正确关闭，尽管 finally 块中有 `f.close()`，但如果 `open()` 本身失败，变量 `f` 未定义会导致 finally 块报错。

**影响**：
- 文件描述符泄漏
- 在高并发场景下可能耗尽系统资源
- Windows 上可能导致文件锁定无法释放

**建议修复**：
```python
# 方案 1：使用 with 语句
with open(lock_path, "a+b") as f:
    # ... 锁定逻辑

# 方案 2：确保 f 初始化
f = None
try:
    f = open(lock_path, "a+b")
    # ... 锁定逻辑
finally:
    if f is not None:
        try:
            f.close()
        except OSError:
            pass
```

---

### 2. SQL 动态构建（已验证安全但需文档说明）

**位置**：
- `tg_bot/storage/tables/offline.py:194`
- `tg_bot/storage/tables/jobs.py:115`
- `tg_bot/storage/schema.py:440-473`

**问题描述**：
使用 f-string 构建 SQL 语句，虽然当前实现是安全的（使用占位符），但容易被误解为 SQL 注入风险。

**示例**：
```python
# offline.py:194 - 安全：ph 是占位符字符串，part 通过参数传递
ph = ",".join(["?"] * len(part))
rows = c.execute(f"SELECT k, cnt FROM offline_seen WHERE k IN ({ph})", part).fetchall()

# jobs.py:115 - 安全：cols 是列名列表，vals 通过参数传递
c.execute(f"UPDATE tg_job SET {', '.join(cols)} WHERE job_id=?", tuple(vals))

# schema.py:440 - 安全：bak 是硬编码的表名
c.execute(f"DROP TABLE IF EXISTS {bak}")
```

**影响**：
- 代码审查时容易被标记为安全问题
- 新开发者可能模仿这种模式但使用不当

**建议**：
1. 添加注释说明为何安全
2. 考虑使用 SQL 构建器库（如 SQLAlchemy）
3. 在代码审查清单中明确这些模式

---

## 🟡 中优先级问题

### 3. 静默异常处理

**扫描结果**：发现 5 处静默异常，全部为 CORE 优先级

**详细列表**：

#### 3.1 `core/fs.py:260` 和 `core/storage/fs.py:260`
```python
except Exception:
    logger.exception("dump_env_file failed: %s", path)
```
**问题**：捕获所有异常但只记录日志，不重新抛出
**影响**：环境文件写入失败可能被静默忽略
**建议**：根据业务需求决定是否需要重新抛出

#### 3.2 `core/plugins/registry.py:171`
```python
except Exception:
    logger.exception("plugin hook failed: %s (%s)", getattr(fn, "__name__", str(fn)), phase)
    # Do not raise here; strictness is controlled by the loader / settings.
```
**问题**：插件钩子失败被静默处理
**影响**：插件错误可能导致功能异常但不易发现
**建议**：已有注释说明，考虑添加配置项控制是否抛出

#### 3.3 `core/services/manager.py:47`
```python
except Exception:
    logger.exception("service stop failed: %s", getattr(svc, "name", type(svc).__name__))
```
**问题**：服务停止失败被静默处理
**影响**：服务清理失败可能导致资源泄漏
**建议**：考虑收集失败的服务列表并在最后报告

#### 3.4 `core/suppress.py:47`
```python
except Exception:
    # Last resort: swallow everything; do not print to stdout/stderr here.
    pass
```
**问题**：完全静默的异常处理
**影响**：这是设计意图（最后防线），但需要确保只在必要时使用
**建议**：已有注释说明，保持现状

---

### 4. 异步任务管理

**发现**：15 处 `asyncio.create_task` 调用

**分析结果**：
- ✅ 大部分已正确管理（添加到集合并在 done_callback 中移除）
- ✅ Worker 中的延迟任务已正确跟踪
- ⚠️ 部分任务未显式等待完成

**需要关注的位置**：

#### 4.1 `tg_bot/infra/outbox.py:120`
```python
st.workers[cid] = asyncio.create_task(self._worker_loop(cid, st))
```
**状态**：✅ 已存储在字典中，可以追踪
**建议**：确保在清理时等待所有 worker 完成

#### 4.2 `notifier/worker.py:480`
```python
task = asyncio.create_task(self._delayed_requeue(env, backoff))
self._delayed_tasks.add(task)
task.add_done_callback(lambda t: self._delayed_tasks.discard(t))
```
**状态**：✅ 已正确管理
**建议**：保持现状

#### 4.3 `application/recent_entries.py:242`
```python
t = asyncio.create_task(_runner())
self._cover_tasks.add(t)
t.add_done_callback(lambda _t: self._cover_tasks.discard(_t))
```
**状态**：✅ 已正确管理
**建议**：保持现状

---

## 🟢 低优先级问题

### 5. 调试代码残留

**扫描结果**：
- ✅ 无 `import pdb` 或 `breakpoint()` 调用
- ⚠️ 工具脚本中有 `print()` 语句（正常）
- ✅ 无遗留的调试日志

---

### 6. 代码质量标记

**TODO/FIXME 统计**：
- 大部分是日志消息中的说明文本
- 无紧急的 FIXME 或 BUG 标记
- 建议：定期审查 TODO 列表

---

## 📊 测试覆盖情况

### 属性测试状态
```
✅ tests/property/ - 所有测试通过
✅ tests/contract/ - 数据库异常处理测试完整
✅ tests/integration/ - 集成测试覆盖主要流程
```

### 发现的测试相关问题
- 测试名称中包含 "error" 是正常的（测试错误处理）
- 无失败的测试用例

---

## 🔧 修复优先级建议

### 立即修复（本周内）
1. **文件锁资源泄漏**（`core/storage/file_lock.py`）
   - 风险：高
   - 工作量：小（1-2 小时）
   - 影响范围：所有使用文件锁的模块

### 短期修复（本月内）
2. **SQL 构建文档化**
   - 风险：低（当前是安全的）
   - 工作量：小（添加注释）
   - 影响范围：代码可维护性

3. **异常处理审查**
   - 风险：中
   - 工作量：中（需要业务判断）
   - 影响范围：错误恢复能力

### 长期改进
4. **异步任务生命周期管理**
   - 风险：低（当前已基本正确）
   - 工作量：中（添加统一的任务管理器）
   - 影响范围：系统稳定性

---

## 📝 代码审查清单

基于本次分析，建议在代码审查时关注：

- [ ] 文件操作是否使用 `with` 语句
- [ ] 异常处理是否有明确的业务意图
- [ ] SQL 构建是否使用参数化查询
- [ ] 异步任务是否正确管理生命周期
- [ ] 资源清理是否在 finally 块中执行
- [ ] 日志级别是否合适（debug/info/warn/error）

---

## 🎯 总结

**整体代码质量**：良好

**主要优点**：
- 异常处理大部分已优化（使用 `safe_call` 装饰器）
- 异步任务管理较为规范
- 测试覆盖率较高
- 无明显的安全漏洞

**需要改进**：
- 文件锁实现需要修复资源泄漏风险
- 部分异常处理需要明确业务意图
- SQL 构建需要更好的文档说明

**风险评估**：
- 🔴 高风险：1 个（文件锁）
- 🟡 中风险：5 个（异常处理）
- 🟢 低风险：其他

---

## 附录：扫描工具输出

### 静默异常扫描
```
总计发现: 5 处静默异常
按优先级分布:
  CORE: 5
按模式分布:
  except Exception: logger.exception only: 4
  except Exception: pass: 1
```

### 异步任务统计
```
asyncio.create_task 调用: 15 处
- 已正确管理: 13 处
- 需要审查: 2 处
```

---

**报告生成者**：Kiro AI Assistant  
**分析方法**：静态代码分析 + 模式匹配 + 工具扫描  
**覆盖范围**：整个项目代码库（除测试和工具脚本）
