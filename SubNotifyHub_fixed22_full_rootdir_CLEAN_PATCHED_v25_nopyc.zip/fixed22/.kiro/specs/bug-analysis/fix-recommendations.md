# Bug 修复建议

## 1. 文件锁资源泄漏修复

### 问题文件
`core/storage/file_lock.py`

### 当前代码
```python
@contextmanager
def file_lock(lock_path: Path, *, timeout_sec: float = 10.0) -> Iterator[None]:
    lock_path.parent.mkdir(parents=True, exist_ok=True)

    # Use binary mode for Windows msvcrt locking compatibility.
    f = open(lock_path, "a+b")  # ❌ 问题：未使用 with 语句
    mode: str | None = None

    try:
        # ... 锁定逻辑
        yield
    finally:
        # ... 解锁逻辑
        try:
            f.close()  # ⚠️ 如果 open() 失败，f 未定义
        except OSError as e:
            logger.debug(f"文件锁文件关闭失败（已忽略） - path={lock_path}, 原因={type(e).__name__}")
```

### 推荐修复方案

#### 方案 A：使用嵌套 with 语句（推荐）
```python
@contextmanager
def file_lock(lock_path: Path, *, timeout_sec: float = 10.0) -> Iterator[None]:
    """Acquire an exclusive advisory lock on ``lock_path`` (best-effort)."""
    lock_path.parent.mkdir(parents=True, exist_ok=True)

    # Use binary mode for Windows msvcrt locking compatibility.
    with open(lock_path, "a+b") as f:  # ✅ 自动管理文件句柄
        mode: str | None = None

        try:
            # 1) POSIX flock
            try:
                import fcntl  # type: ignore

                start = time.time()
                while True:
                    try:
                        fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
                        mode = "fcntl"
                        break
                    except BlockingIOError:
                        if (time.time() - start) >= float(timeout_sec):
                            fcntl.flock(f.fileno(), fcntl.LOCK_EX)
                            mode = "fcntl"
                            break
                        time.sleep(0.05)
            except Exception as e_fcntl:
                # 2) Windows msvcrt locking
                try:
                    import msvcrt  # type: ignore

                    # Ensure file has at least 1 byte
                    try:
                        f.seek(0, 2)
                        if f.tell() <= 0:
                            f.write(b"\0")
                            f.flush()
                    except (OSError, ValueError) as e:
                        logger.debug(f"文件锁初始化失败（已忽略） - path={lock_path}, 原因={type(e).__name__}")
                    
                    try:
                        f.seek(0)
                    except (OSError, ValueError) as e:
                        logger.debug(f"文件指针重置失败（已忽略） - path={lock_path}, 原因={type(e).__name__}")

                    start = time.time()
                    while True:
                        try:
                            msvcrt.locking(f.fileno(), msvcrt.LK_NBLCK, 1)
                            mode = "msvcrt"
                            break
                        except OSError:
                            if (time.time() - start) >= float(timeout_sec):
                                msvcrt.locking(f.fileno(), msvcrt.LK_LOCK, 1)
                                mode = "msvcrt"
                                break
                            time.sleep(0.05)
                except Exception as e2:
                    _warn_no_lock_once(f"fcntl_error={type(e_fcntl).__name__}; msvcrt_error={type(e2).__name__}")
                    mode = None

            yield

        finally:
            # Unlock (best-effort)
            if mode == "fcntl":
                try:
                    import fcntl  # type: ignore
                    fcntl.flock(f.fileno(), fcntl.LOCK_UN)
                except (OSError, ValueError) as e:
                    logger.debug(f"fcntl 文件锁释放失败（已忽略） - path={lock_path}, 原因={type(e).__name__}")
            elif mode == "msvcrt":
                try:
                    import msvcrt  # type: ignore
                    try:
                        f.seek(0)
                    except (OSError, ValueError) as e:
                        logger.debug(f"msvcrt 文件指针重置失败（已忽略） - path={lock_path}, 原因={type(e).__name__}")
                    msvcrt.locking(f.fileno(), msvcrt.LK_UNLCK, 1)
                except (OSError, ValueError) as e:
                    logger.debug(f"msvcrt 文件锁释放失败（已忽略） - path={lock_path}, 原因={type(e).__name__}")
            # ✅ 文件会在 with 块结束时自动关闭
```

#### 方案 B：显式初始化（备选）
```python
@contextmanager
def file_lock(lock_path: Path, *, timeout_sec: float = 10.0) -> Iterator[None]:
    lock_path.parent.mkdir(parents=True, exist_ok=True)

    f = None  # ✅ 显式初始化
    try:
        f = open(lock_path, "a+b")
        mode: str | None = None

        # ... 锁定逻辑
        yield

    finally:
        # Unlock (best-effort)
        if f is not None:  # ✅ 检查是否成功打开
            try:
                # ... 解锁逻辑
            finally:
                try:
                    f.close()
                except OSError as e:
                    logger.debug(f"文件锁文件关闭失败（已忽略） - path={lock_path}, 原因={type(e).__name__}")
```

### 测试建议
```python
# tests/unit/test_file_lock.py

def test_file_lock_handles_open_failure(tmp_path):
    """测试文件打开失败时不会泄漏资源"""
    # 创建一个无法打开的路径（权限问题）
    lock_path = tmp_path / "readonly" / "test.lock"
    lock_path.parent.mkdir()
    lock_path.parent.chmod(0o444)  # 只读
    
    with pytest.raises(PermissionError):
        with file_lock(lock_path):
            pass
    
    # 验证没有文件描述符泄漏
    # （可以通过 psutil 或 /proc/self/fd 检查）

def test_file_lock_closes_on_exception(tmp_path):
    """测试异常时文件正确关闭"""
    lock_path = tmp_path / "test.lock"
    
    with pytest.raises(RuntimeError):
        with file_lock(lock_path):
            raise RuntimeError("test error")
    
    # 验证文件已关闭（可以再次打开）
    with open(lock_path, "r"):
        pass
```

---

## 2. SQL 构建文档化

### 需要添加注释的位置

#### 2.1 `tg_bot/storage/tables/offline.py:194`
```python
# ✅ 安全：ph 是占位符字符串 "?,?,?..."，part 通过参数传递
# 不存在 SQL 注入风险，因为用户数据不会拼接到 SQL 字符串中
ph = ",".join(["?"] * len(part))
rows = c.execute(f"SELECT k, cnt FROM offline_seen WHERE k IN ({ph})", part).fetchall()
```

#### 2.2 `tg_bot/storage/tables/jobs.py:115`
```python
# ✅ 安全：cols 是内部控制的列名列表，vals 通过参数化查询传递
# 列名不来自用户输入，值使用占位符，符合安全实践
c.execute(f"UPDATE tg_job SET {', '.join(cols)} WHERE job_id=?", tuple(vals))
```

#### 2.3 `tg_bot/storage/schema.py:440`
```python
# ✅ 安全：bak 是硬编码的表名常量，不包含用户输入
bak = "share_tmdb_map_bak"
c.execute(f"DROP TABLE IF EXISTS {bak}")
```

### 代码审查清单更新
在项目的 `CONTRIBUTING.md` 或 `.github/PULL_REQUEST_TEMPLATE.md` 中添加：

```markdown
## SQL 安全检查清单

- [ ] 所有用户输入都通过参数化查询传递（使用 `?` 占位符）
- [ ] 动态表名/列名来自白名单或内部常量
- [ ] f-string 中的 SQL 片段已添加安全注释
- [ ] 复杂查询已通过 SQL 注入测试
```

---

## 3. 异常处理改进

### 3.1 环境文件写入失败处理

#### 当前代码
```python
# core/fs.py:260
except Exception:
    logger.exception("dump_env_file failed: %s", path)
```

#### 建议改进
```python
except Exception as e:
    logger.exception("dump_env_file failed: %s", path)
    # 根据业务需求决定是否重新抛出
    if isinstance(e, (PermissionError, OSError)):
        # 文件系统错误应该让调用者知道
        raise
    # 其他异常（如编码错误）可以静默处理
```

### 3.2 插件钩子失败处理

#### 当前代码
```python
# core/plugins/registry.py:171
except Exception:
    logger.exception("plugin hook failed: %s (%s)", getattr(fn, "__name__", str(fn)), phase)
    # Do not raise here; strictness is controlled by the loader / settings.
```

#### 建议改进
```python
except Exception as e:
    logger.exception("plugin hook failed: %s (%s)", getattr(fn, "__name__", str(fn)), phase)
    
    # 检查是否启用严格模式
    if getattr(get_settings(), "PLUGIN_STRICT_MODE", False):
        raise
    
    # 记录失败的插件以便后续诊断
    self._failed_hooks.append({
        "hook": getattr(fn, "__name__", str(fn)),
        "phase": phase,
        "error": str(e),
        "timestamp": time.time()
    })
```

### 3.3 服务停止失败处理

#### 当前代码
```python
# core/services/manager.py:47
except Exception:
    logger.exception("service stop failed: %s", getattr(svc, "name", type(svc).__name__))
```

#### 建议改进
```python
failed_services = []

for svc in reversed(self._services):
    try:
        await svc.stop()
        logger.debug("service stopped: %s", getattr(svc, "name", type(svc).__name__))
    except Exception as e:
        logger.exception("service stop failed: %s", getattr(svc, "name", type(svc).__name__))
        failed_services.append({
            "service": getattr(svc, "name", type(svc).__name__),
            "error": str(e)
        })

# 在所有服务停止后报告失败情况
if failed_services:
    logger.warning(
        "Some services failed to stop cleanly: %s",
        ", ".join(s["service"] for s in failed_services)
    )
    # 可选：根据配置决定是否抛出异常
    if getattr(get_settings(), "SERVICE_STOP_STRICT", False):
        raise RuntimeError(f"Failed to stop {len(failed_services)} service(s)")
```

---

## 4. 异步任务生命周期管理

### 4.1 统一的任务管理器

创建一个统一的任务管理器来跟踪所有后台任务：

```python
# core/task_manager.py

from typing import Set, Optional
import asyncio
import logging

logger = logging.getLogger(__name__)

class TaskManager:
    """统一管理异步任务的生命周期"""
    
    def __init__(self):
        self._tasks: Set[asyncio.Task] = set()
        self._lock = asyncio.Lock()
        self._closed = False
    
    async def create_task(
        self,
        coro,
        *,
        name: Optional[str] = None,
        track: bool = True
    ) -> asyncio.Task:
        """创建并跟踪异步任务"""
        if self._closed:
            raise RuntimeError("TaskManager is closed")
        
        task = asyncio.create_task(coro, name=name)
        
        if track:
            async with self._lock:
                self._tasks.add(task)
            task.add_done_callback(self._task_done)
        
        return task
    
    def _task_done(self, task: asyncio.Task):
        """任务完成回调"""
        try:
            self._tasks.discard(task)
            
            # 检查任务是否有异常
            if not task.cancelled():
                exc = task.exception()
                if exc:
                    logger.error(
                        "Background task failed: %s",
                        task.get_name(),
                        exc_info=exc
                    )
        except Exception as e:
            logger.debug(f"任务清理失败（已忽略） - 原因={type(e).__name__}")
    
    async def wait_all(self, timeout: Optional[float] = None):
        """等待所有任务完成"""
        if not self._tasks:
            return
        
        try:
            await asyncio.wait_for(
                asyncio.gather(*self._tasks, return_exceptions=True),
                timeout=timeout
            )
        except asyncio.TimeoutError:
            logger.warning(
                "Timeout waiting for %d tasks to complete",
                len(self._tasks)
            )
    
    async def cancel_all(self):
        """取消所有任务"""
        async with self._lock:
            tasks = list(self._tasks)
        
        for task in tasks:
            if not task.done():
                task.cancel()
        
        # 等待取消完成
        if tasks:
            await asyncio.gather(*tasks, return_exceptions=True)
    
    async def close(self):
        """关闭管理器并清理所有任务"""
        self._closed = True
        await self.cancel_all()
```

### 4.2 在现有代码中使用

```python
# notifier/worker.py

class NotifierWorker:
    def __init__(self, handler: Handler) -> None:
        self._handler = handler
        self._task_manager = TaskManager()  # ✅ 使用统一管理器
        # ... 其他初始化
    
    async def _run_loop(self, worker_id: int) -> None:
        # ... 现有逻辑
        
        # 创建延迟重试任务
        task = await self._task_manager.create_task(
            self._delayed_requeue(env, backoff),
            name=f"delayed-requeue-{trace_id}"
        )
    
    async def stop(self) -> None:
        self._stopped = True
        
        # 等待所有延迟任务完成
        await self._task_manager.wait_all(timeout=30.0)
        await self._task_manager.close()
```

---

## 5. 编码问题预防

### 5.1 文件读写统一封装

```python
# core/fs_utils.py

from pathlib import Path
from typing import Union

def read_text_safe(path: Union[str, Path], encoding: str = "utf-8") -> str:
    """安全读取文本文件，自动处理 BOM"""
    path = Path(path)
    
    # 检测 BOM
    with open(path, "rb") as f:
        header = f.read(3)
    
    if header == b"\xef\xbb\xbf":
        # UTF-8 with BOM
        return path.read_text(encoding="utf-8-sig")
    else:
        return path.read_text(encoding=encoding)

def write_text_safe(
    path: Union[str, Path],
    content: str,
    encoding: str = "utf-8",
    preserve_bom: bool = True
) -> None:
    """安全写入文本文件，可选保留 BOM"""
    path = Path(path)
    
    # 检查原文件是否有 BOM
    has_bom = False
    if path.exists():
        with open(path, "rb") as f:
            header = f.read(3)
        has_bom = (header == b"\xef\xbb\xbf")
    
    # 决定编码
    if preserve_bom and has_bom:
        final_encoding = "utf-8-sig"
    else:
        final_encoding = encoding
    
    path.write_text(content, encoding=final_encoding)
```

### 5.2 在项目中使用

```python
# 替换所有直接的文件读写
# 旧代码
content = Path("config.txt").read_text()

# 新代码
from core.fs_utils import read_text_safe
content = read_text_safe("config.txt")
```

---

## 实施计划

### 第 1 周
- [ ] 修复文件锁资源泄漏（优先级：高）
- [ ] 添加文件锁单元测试
- [ ] 代码审查并合并

### 第 2 周
- [ ] 为 SQL 构建添加安全注释
- [ ] 更新代码审查清单
- [ ] 团队培训：SQL 安全最佳实践

### 第 3 周
- [ ] 改进异常处理（环境文件、插件、服务）
- [ ] 添加配置项控制严格模式
- [ ] 更新文档

### 第 4 周
- [ ] 实现统一的任务管理器
- [ ] 迁移现有代码使用新管理器
- [ ] 性能测试和压力测试

### 持续改进
- [ ] 定期运行静态分析工具
- [ ] 监控生产环境的异常日志
- [ ] 收集用户反馈并优化

---

## 验证清单

修复完成后，使用以下清单验证：

- [ ] 所有单元测试通过
- [ ] 集成测试通过
- [ ] 静态分析工具无新增警告
- [ ] 代码覆盖率未降低
- [ ] 性能测试无明显退化
- [ ] 文档已更新
- [ ] 团队已培训
- [ ] 生产环境监控已配置

---

**文档版本**：1.0  
**最后更新**：2026-01-17  
**维护者**：开发团队
