# Implementation Plan: Missing API Endpoints

## Overview

实现 Dashboard 子页面（Settings、Forward、TG Bot）所需的缺失 API 端点。按照现有代码风格，在对应的路由文件中添加 GET 端点，从 `get_settings()` 读取配置并返回 JSON 响应。

## Tasks

- [x] 1. 实现敏感字段掩码工具函数
  - [x] 1.1 在 `admin/routes_base.py` 中添加 `mask_sensitive()` 函数
    - 实现掩码逻辑：长度 > 8 显示首尾各 4 字符，中间用 `****` 替代
    - 长度 <= 8 全部用 `****` 替代
    - 空值返回空字符串
    - _Requirements: 6.1, 6.2, 6.3_
  - [x] 1.2 编写 `mask_sensitive()` 的属性测试
    - **Property 7: Sensitive Field Masking**
    - **Validates: Requirements 1.10, 6.1, 6.2, 6.3, 6.4**

- [x] 2. 实现 Settings Config API
  - [x] 2.1 在 `admin/routes_settings.py` 中添加 `/admin/settings/config.json` GET 端点
    - 从 `get_settings()` 读取所有配置字段
    - 对敏感字段（emby_api_key, webhook_secret, tmdb_api_key, cloud115_cookie）调用 `mask_sensitive()`
    - 返回 `{"ok": true, "config": {...}}`
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 1.10, 1.11_
  - [x] 2.2 编写 Settings Config API 的属性测试
    - **Property 2: Settings Config Field Completeness**
    - **Validates: Requirements 1.2-1.9**

- [x] 3. 实现 Forward Config API
  - [x] 3.1 创建 `admin/routes_forward.py` 文件并添加 `/admin/forward/config.json` GET 端点
    - 从 `get_settings()` 读取 Forward 相关配置
    - 对 mediahelp_password 调用 `mask_sensitive()`
    - 返回 `{"ok": true, "config": {...}}`
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9, 2.10_
  - [x] 3.2 编写 Forward Config API 的属性测试
    - **Property 3: Forward Config Field Completeness**
    - **Validates: Requirements 2.2-2.9**

- [x] 4. 实现 Forward Status API
  - [x] 4.1 在 `admin/routes_forward.py` 中添加 `/admin/forward/status.json` GET 端点
    - 检查 bridge 运行状态
    - 检查 MediaHelp 连接状态
    - 获取 token 过期时间
    - 获取缓存的订阅数量
    - 返回 `{"ok": true, "status": {...}}`
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6_
  - [x] 4.2 编写 Forward Status API 的属性测试
    - **Property 4: Forward Status Field Completeness**
    - **Validates: Requirements 3.2-3.5**

- [x] 5. Checkpoint - 确保 Forward API 测试通过
  - Ensure all tests pass, ask the user if questions arise.

- [x] 6. 实现 TgBot Config API
  - [x] 6.1 在 `admin/routes_tg_bot.py` 中添加 `/admin/tgbot/config.json` GET 端点
    - 从 `get_settings()` 读取 TG Bot 相关配置
    - 对敏感字段（bot_token, webhook_secret, cloud115_cookie）调用 `mask_sensitive()`
    - 返回 `{"ok": true, "config": {...}}`
    - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.7, 4.8, 4.9, 4.10_
  - [x] 6.2 编写 TgBot Config API 的属性测试
    - **Property 5: TgBot Config Field Completeness**
    - **Validates: Requirements 4.2-4.9**

- [x] 7. 实现 TgBot Info API
  - [x] 7.1 在 `admin/routes_tg_bot.py` 中添加 `/admin/tgbot/info.json` GET 端点
    - 检查 bot token 是否配置
    - 调用 Telegram API `getMe` 获取 bot 信息
    - 获取当前运行模式和队列大小
    - 返回 `{"ok": true, "bot": {...}}` 或 `{"ok": false, "detail": "..."}`
    - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5, 5.6, 5.7_
  - [x] 7.2 编写 TgBot Info API 的属性测试
    - **Property 6: TgBot Info Field Completeness**
    - **Validates: Requirements 5.2-5.5**

- [x] 8. 注册新路由
  - [x] 8.1 在 `admin/routes.py` 中注册 `routes_forward.py` 的路由
    - 导入 routes_forward 模块
    - 将 router 添加到主路由
    - _Requirements: 2.1, 3.1_

- [x] 9. Final Checkpoint - 确保所有测试通过
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- All tasks are required for comprehensive testing
- Each task references specific requirements for traceability
- Checkpoints ensure incremental validation
- Property tests validate universal correctness properties
- 所有 API 端点都需要 admin 认证 (`Depends(get_admin_user)`)
- 敏感字段必须使用 `mask_sensitive()` 函数进行掩码处理
