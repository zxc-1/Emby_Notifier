# Design Document: Missing API Endpoints

## Overview

本设计文档描述了为 Dashboard 子页面（Settings、Forward、TG Bot）实现缺失 API 端点的技术方案。这些 API 端点将从 `get_settings()` 读取配置值，并以 JSON 格式返回给前端，同时对敏感字段进行掩码处理。

## Architecture

### 系统架构

```mermaid
graph TB
    subgraph Frontend
        A[settings.js] --> |GET /admin/settings/config.json| B[Settings API]
        C[forward.js] --> |GET /admin/forward/config.json| D[Forward API]
        C --> |GET /admin/forward/status.json| D
        E[tgbot.js] --> |GET /admin/tgbot/config.json| F[TgBot API]
        E --> |GET /admin/tgbot/info.json| F
    end
    
    subgraph Backend
        B --> G[routes_settings.py]
        D --> H[routes_forward.py]
        F --> I[routes_tg_bot.py]
        G --> J[get_settings]
        H --> J
        I --> J
        J --> K[Settings Model]
    end
    
    subgraph Security
        L[get_admin_user] --> G
        L --> H
        L --> I
        M[mask_sensitive] --> G
        M --> H
        M --> I
    end
```

### 数据流

1. 前端 JS 发起 GET 请求到对应的 API 端点
2. FastAPI 路由处理器验证 admin 认证
3. 从 `get_settings()` 获取当前配置
4. 对敏感字段进行掩码处理
5. 返回 JSON 响应 `{"ok": true, "config": {...}}` 或 `{"ok": true, "status": {...}}`

## Components and Interfaces

### 1. 敏感字段掩码工具函数

```python
def mask_sensitive(value: str, show_chars: int = 4) -> str:
    """Mask sensitive values, showing only first and last N characters.
    
    Args:
        value: The sensitive value to mask
        show_chars: Number of characters to show at start and end
        
    Returns:
        Masked string like "abcd****efgh" or empty string if value is empty
    """
```

### 2. Settings Config API

**端点**: `GET /admin/settings/config.json`

**响应格式**:
```python
{
    "ok": True,
    "config": {
        # Emby 配置
        "emby_base_url": str,
        "emby_api_key": str,  # masked
        "emby_wait_image": bool,
        "emby_wait_image_max": int,
        
        # Webhook 配置
        "webhook_secret": str,  # masked
        "webhook_allowed_ips": str,
        "webhook_trust_proxy": bool,
        
        # 通知器配置
        "notifier_types": str,
        "notifier_queue_size": int,
        "notifier_concurrency": int,
        "notifier_timeout": float,
        "notifier_enqueue_timeout": float,
        "notifier_parallel": bool,
        "notifier_require_all": bool,
        "notifier_dry_run": bool,
        
        # 重试策略
        "notifier_max_retry": int,
        "notifier_backoff_base": float,
        "notifier_backoff_max": float,
        "notifier_jitter": float,
        
        # 消息聚合
        "notifier_agg_window": float,
        "notifier_agg_max": int,
        
        # Pipeline 配置
        "pipeline_steps": str,
        "pipeline_strict": bool,
        
        # 去重配置
        "episode_dedup_strategy": str,
        "dedup_ttl": int,
        "dedup_max_size": int,
        "dedup_persistent": bool,
        
        # 高级配置
        "tmdb_api_key": str,  # masked
        "cloud115_cookie": str,  # masked
        "log_level": str,
        "debug_history_size": int,
        "debug_enable_api": bool,
    }
}
```

### 3. Forward Config API

**端点**: `GET /admin/forward/config.json`

**响应格式**:
```python
{
    "ok": True,
    "config": {
        "enabled": bool,
        "sub_cache_ttl": int,
        "debug": bool,
        "season_filter": bool,
        "allow_public_notify": bool,
        "token": str,
        "allow_no_token": bool,
        "mediahelp_base": str,
        "mediahelp_username": str,
        "mediahelp_password": str,  # masked
    }
}
```

### 4. Forward Status API

**端点**: `GET /admin/forward/status.json`

**响应格式**:
```python
{
    "ok": True,
    "status": {
        "bridge_ok": bool,
        "mh_connected": bool,
        "token_expires": int | None,
        "cached_subs": int,
    }
}
```

### 5. TgBot Config API

**端点**: `GET /admin/tgbot/config.json`

**响应格式**:
```python
{
    "ok": True,
    "config": {
        # Bot 凭证
        "bot_token": str,  # masked
        "chat_id": str,
        
        # 运行模式
        "bot_mode": str,
        "poll_timeout": int,
        "poll_drop_pending": bool,
        
        # Webhook 配置
        "webhook_url": str,
        "webhook_secret": str,  # masked
        "webhook_drop_pending": bool,
        "webhook_return_ok": bool,
        
        # 功能开关
        "job_enabled": bool,
        "inbound_enabled": bool,
        "outbox_enabled": bool,
        
        # 消息设置
        "parse_mode": str,
        "rate_limit": int,
        
        # 访问控制
        "allowed_user_ids": List[int],
        
        # 115 云盘配置
        "cloud115_cookie": str,  # masked
        "cloud115_qr_app": str,
        "cloud115_dup_mode": str,
        "cloud115_dup_window": int,
        "cloud115_health_enabled": bool,
        "cloud115_poll_on_submit": bool,
        
        # 功能模块
        "features": List[str],
        "features_disabled": List[str],
    }
}
```

### 6. TgBot Info API

**端点**: `GET /admin/tgbot/info.json`

**响应格式**:
```python
{
    "ok": True,
    "bot": {
        "first_name": str,
        "username": str,
        "photo_url": str | None,
        "mode": str,
        "queue_size": int,
    }
}
```

## Data Models

### 配置字段映射

| 前端字段 | Settings 属性 | 类型 | 敏感 |
|---------|--------------|------|------|
| emby_base_url | EMBY_BASE_URL | str | No |
| emby_api_key | EMBY_API_KEY | str | Yes |
| webhook_secret | WEBHOOK_SECRET | str | Yes |
| notifier_types | NOTIFIER_TYPES | str | No |
| tmdb_api_key | TMDB_API_KEY | str | Yes |
| cloud115_cookie | CLOUD115_COOKIE | str | Yes |
| bot_token | TG_BOT_TOKEN | str | Yes |
| mediahelp_password | MEDIAHELP_LOGIN_PASSWORD | str | Yes |

### 状态检测逻辑

**Forward Bridge 状态**:
- `bridge_ok`: 检查 `FORWARD_BRIDGE_ENABLED` 且 `MEDIAHELP_BASE` 已配置
- `mh_connected`: 检查 `MEDIAHELP_TOKEN` 是否存在且有效
- `token_expires`: 从 forward_bridge 模块获取 token 过期时间
- `cached_subs`: 从 sub_cache 获取缓存的订阅数量

**TG Bot 信息**:
- 调用 Telegram API `getMe` 获取 bot 信息
- 从 tg_bot 模块获取当前运行模式和队列大小



## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

Based on the prework analysis, the following properties have been identified:

### Property 1: API Response Format Consistency

*For any* authenticated GET request to a config/status/info endpoint, the response SHALL be a valid JSON object containing an "ok" field (boolean) and the appropriate data field ("config", "status", or "bot").

**Validates: Requirements 1.1, 2.1, 3.1, 4.1, 5.1**

### Property 2: Settings Config Field Completeness

*For any* Settings configuration state, the `/admin/settings/config.json` response SHALL contain all required fields: emby_base_url, emby_api_key, emby_wait_image, emby_wait_image_max, webhook_secret, webhook_allowed_ips, webhook_trust_proxy, notifier_types, notifier_queue_size, notifier_concurrency, notifier_timeout, notifier_enqueue_timeout, notifier_parallel, notifier_require_all, notifier_dry_run, notifier_max_retry, notifier_backoff_base, notifier_backoff_max, notifier_jitter, notifier_agg_window, notifier_agg_max, pipeline_steps, pipeline_strict, episode_dedup_strategy, dedup_ttl, dedup_max_size, dedup_persistent, tmdb_api_key, cloud115_cookie, log_level, debug_history_size, debug_enable_api.

**Validates: Requirements 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9**

### Property 3: Forward Config Field Completeness

*For any* Forward configuration state, the `/admin/forward/config.json` response SHALL contain all required fields: enabled, sub_cache_ttl, debug, season_filter, allow_public_notify, token, allow_no_token, mediahelp_base, mediahelp_username, mediahelp_password.

**Validates: Requirements 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9**

### Property 4: Forward Status Field Completeness

*For any* Forward status query, the `/admin/forward/status.json` response SHALL contain all required fields: bridge_ok, mh_connected, token_expires, cached_subs.

**Validates: Requirements 3.2, 3.3, 3.4, 3.5**

### Property 5: TgBot Config Field Completeness

*For any* TgBot configuration state, the `/admin/tgbot/config.json` response SHALL contain all required fields: bot_token, chat_id, bot_mode, poll_timeout, poll_drop_pending, webhook_url, webhook_secret, webhook_drop_pending, webhook_return_ok, job_enabled, inbound_enabled, outbox_enabled, parse_mode, rate_limit, allowed_user_ids, cloud115_cookie, cloud115_qr_app, cloud115_dup_mode, cloud115_dup_window, cloud115_health_enabled, cloud115_poll_on_submit, features, features_disabled.

**Validates: Requirements 4.2, 4.3, 4.4, 4.5, 4.6, 4.7, 4.8, 4.9**

### Property 6: TgBot Info Field Completeness

*For any* successful TgBot info query (when bot is configured), the `/admin/tgbot/info.json` response SHALL contain all required fields: first_name, username, photo_url, mode, queue_size.

**Validates: Requirements 5.2, 5.3, 5.4, 5.5**

### Property 7: Sensitive Field Masking

*For any* non-empty sensitive field value with length > 8, the masked output SHALL show the first 4 characters, followed by asterisks, followed by the last 4 characters. For values with length <= 8, the output SHALL be entirely asterisks. For empty/null values, the output SHALL be an empty string.

**Validates: Requirements 1.10, 6.1, 6.2, 6.3, 6.4**

## Error Handling

### Authentication Errors

- All endpoints require admin authentication via `Depends(get_admin_user)`
- Unauthenticated requests return HTTP 401 with `{"detail": "Not authenticated"}`

### Configuration Read Errors

- If `get_settings()` fails, return HTTP 500 with `{"ok": false, "detail": "Failed to load settings"}`
- Individual field access errors are caught and logged, returning default values

### External Service Errors (TgBot Info)

- If Telegram API call fails, return `{"ok": false, "detail": "Bot not connected"}`
- If bot token is not configured, return `{"ok": false, "detail": "Bot token not configured"}`

## Testing Strategy

### Unit Tests

Unit tests will verify:
- Individual field extraction from Settings object
- Masking function behavior for various input lengths
- Error handling for missing/invalid configurations

### Property-Based Tests

Property-based tests using `hypothesis` will verify:
- Response format consistency across random configurations
- Field completeness for all endpoints
- Masking behavior for arbitrary string inputs

**Test Configuration**:
- Minimum 100 iterations per property test
- Each test tagged with: **Feature: missing-api-endpoints, Property N: {property_text}**

### Integration Tests

Integration tests will verify:
- End-to-end API calls with mocked authentication
- Correct HTTP status codes for authenticated/unauthenticated requests
- Response parsing by frontend JS (simulated)
