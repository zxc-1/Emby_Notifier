# Requirements Document

## Introduction

本功能旨在实现 Dashboard 子页面（Settings、Forward、TG Bot）所需的缺失 API 端点。当前前端 JS 调用的配置获取 API 在后端不存在，导致页面显示 mock 数据而非真实配置。

## Glossary

- **Settings_API**: Settings 页面配置获取 API，返回 Emby、Webhook、通知器等配置
- **Forward_API**: Forward Bridge 页面配置和状态 API
- **TgBot_API**: TG Bot 页面配置和信息 API
- **Config_Endpoint**: 返回配置数据的 GET 端点，格式为 `{"ok": true, "config": {...}}`
- **Status_Endpoint**: 返回状态数据的 GET 端点，格式为 `{"ok": true, "status": {...}}`
- **Masked_Value**: 敏感字段的掩码值，如 `****` 或部分显示

## Requirements

### Requirement 1: Settings 配置获取 API

**User Story:** As a user, I want to retrieve Settings page configuration via API, so that the frontend can display real configuration values instead of mock data.

#### Acceptance Criteria

1. WHEN a GET request is made to `/admin/settings/config.json`, THE Settings_API SHALL return a JSON response with `{"ok": true, "config": {...}}`
2. THE Settings_API SHALL include Emby configuration fields (emby_base_url, emby_api_key, emby_wait_image, emby_wait_image_max)
3. THE Settings_API SHALL include Webhook configuration fields (webhook_secret, webhook_allowed_ips, webhook_trust_proxy)
4. THE Settings_API SHALL include Notifier configuration fields (notifier_types, notifier_queue_size, notifier_concurrency, notifier_timeout, etc.)
5. THE Settings_API SHALL include retry strategy fields (notifier_max_retry, notifier_backoff_base, notifier_backoff_max, notifier_jitter)
6. THE Settings_API SHALL include message aggregation fields (notifier_agg_window, notifier_agg_max)
7. THE Settings_API SHALL include Pipeline configuration fields (pipeline_steps, pipeline_strict)
8. THE Settings_API SHALL include dedup configuration fields (episode_dedup_strategy, dedup_ttl, dedup_max_size, dedup_persistent)
9. THE Settings_API SHALL include advanced configuration fields (tmdb_api_key, cloud115_cookie, log_level, debug_history_size, debug_enable_api)
10. THE Settings_API SHALL mask sensitive fields (emby_api_key, webhook_secret, tmdb_api_key, cloud115_cookie) by returning partial values with asterisks
11. IF the request lacks admin authentication, THEN THE Settings_API SHALL return 401 Unauthorized

### Requirement 2: Forward 配置获取 API

**User Story:** As a user, I want to retrieve Forward Bridge configuration via API, so that the frontend can display real Forward settings.

#### Acceptance Criteria

1. WHEN a GET request is made to `/admin/forward/config.json`, THE Forward_API SHALL return a JSON response with `{"ok": true, "config": {...}}`
2. THE Forward_API SHALL include enabled status (enabled: bool)
3. THE Forward_API SHALL include cache TTL (sub_cache_ttl: int)
4. THE Forward_API SHALL include debug mode (debug: bool)
5. THE Forward_API SHALL include season filter (season_filter: bool)
6. THE Forward_API SHALL include public notify setting (allow_public_notify: bool)
7. THE Forward_API SHALL include token configuration (token: str, allow_no_token: bool)
8. THE Forward_API SHALL include MediaHelp configuration (mediahelp_base, mediahelp_username, mediahelp_password)
9. THE Forward_API SHALL mask the mediahelp_password field
10. IF the request lacks admin authentication, THEN THE Forward_API SHALL return 401 Unauthorized

### Requirement 3: Forward 状态获取 API

**User Story:** As a user, I want to retrieve Forward Bridge status via API, so that the frontend can display real-time connection status.

#### Acceptance Criteria

1. WHEN a GET request is made to `/admin/forward/status.json`, THE Forward_API SHALL return a JSON response with `{"ok": true, "status": {...}}`
2. THE Forward_API SHALL include bridge running status (bridge_ok: bool)
3. THE Forward_API SHALL include MediaHelp connection status (mh_connected: bool)
4. THE Forward_API SHALL include token expiry timestamp (token_expires: int or null)
5. THE Forward_API SHALL include cached subscriptions count (cached_subs: int)
6. IF the request lacks admin authentication, THEN THE Forward_API SHALL return 401 Unauthorized

### Requirement 4: TG Bot 配置获取 API

**User Story:** As a user, I want to retrieve TG Bot configuration via API, so that the frontend can display real bot settings.

#### Acceptance Criteria

1. WHEN a GET request is made to `/admin/tgbot/config.json`, THE TgBot_API SHALL return a JSON response with `{"ok": true, "config": {...}}`
2. THE TgBot_API SHALL include bot credentials (bot_token, chat_id) with bot_token masked
3. THE TgBot_API SHALL include bot mode configuration (bot_mode, poll_timeout, poll_drop_pending)
4. THE TgBot_API SHALL include webhook configuration (webhook_url, webhook_secret, webhook_drop_pending, webhook_return_ok) with webhook_secret masked
5. THE TgBot_API SHALL include feature toggles (job_enabled, inbound_enabled, outbox_enabled)
6. THE TgBot_API SHALL include message settings (parse_mode, rate_limit)
7. THE TgBot_API SHALL include access control (allowed_user_ids: list)
8. THE TgBot_API SHALL include 115 cloud configuration (cloud115_cookie, cloud115_qr_app, cloud115_dup_mode, cloud115_dup_window, cloud115_health_enabled, cloud115_poll_on_submit) with cloud115_cookie masked
9. THE TgBot_API SHALL include feature modules (features, features_disabled)
10. IF the request lacks admin authentication, THEN THE TgBot_API SHALL return 401 Unauthorized

### Requirement 5: TG Bot 信息获取 API

**User Story:** As a user, I want to retrieve TG Bot runtime information via API, so that the frontend can display bot status and identity.

#### Acceptance Criteria

1. WHEN a GET request is made to `/admin/tgbot/info.json`, THE TgBot_API SHALL return a JSON response with `{"ok": true, "bot": {...}}`
2. THE TgBot_API SHALL include bot identity (first_name, username)
3. THE TgBot_API SHALL include bot avatar URL (photo_url: str or null)
4. THE TgBot_API SHALL include current running mode (mode: str)
5. THE TgBot_API SHALL include message queue size (queue_size: int)
6. IF the bot is not configured or not connected, THEN THE TgBot_API SHALL return `{"ok": false, "detail": "..."}`
7. IF the request lacks admin authentication, THEN THE TgBot_API SHALL return 401 Unauthorized

### Requirement 6: 敏感字段掩码处理

**User Story:** As a security-conscious user, I want sensitive configuration values to be masked in API responses, so that credentials are not exposed in network traffic or browser dev tools.

#### Acceptance Criteria

1. WHEN returning sensitive fields (tokens, passwords, cookies, secrets), THE API SHALL mask them by showing only partial characters
2. THE API SHALL use a consistent masking format: first 4 characters + asterisks + last 4 characters for long values
3. IF a sensitive field is empty or null, THEN THE API SHALL return an empty string
4. THE API SHALL mask the following fields: emby_api_key, webhook_secret, tmdb_api_key, cloud115_cookie, bot_token, mediahelp_password, webhook_secret (TG Bot)
