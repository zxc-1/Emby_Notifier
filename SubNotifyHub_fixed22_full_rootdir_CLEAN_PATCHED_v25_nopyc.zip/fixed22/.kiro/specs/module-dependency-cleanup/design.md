# Design Document: Module Dependency Cleanup

## Overview

本设计文档描述 core 模块重组的技术方案。核心目标是将 50+ 个文件按功能域拆分为清晰的子模块，提高代码的可维护性和可导航性，同时保持向后兼容。

## Architecture

### 重组前结构
```
core/
├── bizlog.py
├── bizlogger_adapter.py
├── logging_setup.py
├── logctx.py
├── http_clients.py
├── http_retry.py
├── http_exception_handler.py
├── cache.py
├── persist_cache.py
├── poster_cache.py
├── poster_cache_evict.py
├── poster_cache_fetch.py
├── poster_cache_fs.py
├── poster_cache_keys.py
├── stores.py
├── fs.py
├── file_lock.py
├── env_store.py
├── plugin_api.py
├── plugin_loader.py
├── plugin_registry.py
├── exceptions.py
├── exception_mapping.py
├── exception_metrics.py
├── safe_call.py
├── safe_context.py
├── recovery.py
├── db_exception_handler.py
└── ... (其他 20+ 文件)
```

### 重组后结构
```
core/
├── logging/
│   ├── __init__.py          # Public API exports
│   ├── bizlog.py             # BizLogger 实现
│   ├── bizlogger_adapter.py  # Adapter 实现
│   ├── logging_setup.py      # 日志初始化
│   └── logctx.py             # 日志上下文
├── http/
│   ├── __init__.py           # Public API exports
│   ├── clients.py            # HTTP 客户端 (原 http_clients.py)
│   ├── retry.py              # 重试逻辑 (原 http_retry.py)
│   └── exception_handler.py  # HTTP 异常处理
├── cache/
│   ├── __init__.py           # Public API exports
│   ├── ttl_cache.py          # TTL 缓存 (原 cache.py)
│   ├── persist_cache.py      # 持久化缓存
│   └── poster_cache.py       # 海报缓存 (合并 5 个文件)
├── storage/
│   ├── __init__.py           # Public API exports
│   ├── blob_store.py         # Blob 存储 (原 stores.py)
│   ├── fs.py                 # 文件系统工具
│   ├── file_lock.py          # 文件锁
│   └── env_store.py          # 环境变量存储
├── plugins/
│   ├── __init__.py           # Public API exports
│   ├── api.py                # 插件 API (原 plugin_api.py)
│   ├── loader.py             # 插件加载器 (原 plugin_loader.py)
│   └── registry.py           # 插件注册表 (原 plugin_registry.py)
├── exceptions/
│   ├── __init__.py           # Public API exports
│   ├── base.py               # 异常基类 (原 exceptions.py)
│   ├── mapping.py            # 异常映射 (原 exception_mapping.py)
│   ├── metrics.py            # 异常指标 (原 exception_metrics.py)
│   ├── safe_call.py          # 安全调用装饰器
│   ├── safe_context.py       # 安全上下文管理器
│   ├── recovery.py           # 恢复策略
│   └── db_handler.py         # 数据库异常处理
├── __init__.py               # 向后兼容导出
├── bootstrap.py              # 应用启动
├── context.py                # 应用上下文
├── metrics.py                # 指标收集
├── roles.py                  # 角色管理
├── runtime_ctx.py            # 运行时上下文
├── runtime_env.py            # 运行时环境
└── ... (其他独立模块)
```

## Components and Interfaces

### 1. 子模块 Public API 设计

#### core/logging/__init__.py
```python
"""Logging submodule - unified logging infrastructure."""

from .bizlog import BizLogger, get_biz_logger
from .bizlogger_adapter import BizLoggerAdapter, get_biz_logger_adapter
from .logging_setup import init_logging, log_ok, log_run
from .logctx import (
    get_trace_id, set_trace_id,
    get_span_id, set_span_id,
    get_kind, set_kind,
    logctx,
)

__all__ = [
    "BizLogger", "get_biz_logger",
    "BizLoggerAdapter", "get_biz_logger_adapter",
    "init_logging", "log_ok", "log_run",
    "get_trace_id", "set_trace_id",
    "get_span_id", "set_span_id",
    "get_kind", "set_kind",
    "logctx",
]
```

#### core/http/__init__.py
```python
"""HTTP submodule - HTTP client and retry utilities."""

from .clients import (
    create_http_client,
    get_http_client,
    close_http_client,
)
from .retry import async_request_with_retry
from .exception_handler import (
    handle_http_exception,
    is_retryable_http_error,
)

__all__ = [
    "create_http_client", "get_http_client", "close_http_client",
    "async_request_with_retry",
    "handle_http_exception", "is_retryable_http_error",
]
```

#### core/cache/__init__.py
```python
"""Cache submodule - caching infrastructure."""

from .ttl_cache import TTLCache, get_or_set, aget_or_set
from .persist_cache import kv_get, kv_set, kv_delete
from .poster_cache import PosterCache, get_poster_cache

__all__ = [
    "TTLCache", "get_or_set", "aget_or_set",
    "kv_get", "kv_set", "kv_delete",
    "PosterCache", "get_poster_cache",
]
```

#### core/storage/__init__.py
```python
"""Storage submodule - file system and blob storage."""

from .blob_store import BlobStore, FsBlobStore
from .fs import load_env_file, dump_env_file
from .file_lock import file_lock
from .env_store import EnvStore

__all__ = [
    "BlobStore", "FsBlobStore",
    "load_env_file", "dump_env_file",
    "file_lock",
    "EnvStore",
]
```

#### core/plugins/__init__.py
```python
"""Plugins submodule - plugin system infrastructure."""

from .api import PLUGIN_API_VERSION, PluginAPI
from .loader import load_plugins
from .registry import PluginRegistry, PluginInfo

__all__ = [
    "PLUGIN_API_VERSION", "PluginAPI",
    "load_plugins",
    "PluginRegistry", "PluginInfo",
]
```

#### core/exceptions/__init__.py
```python
"""Exceptions submodule - exception handling infrastructure."""

from .base import (
    AppException,
    NetworkError,
    DatabaseError,
    ValidationError,
    ConfigurationError,
    ExternalServiceError,
)
from .mapping import map_exception, get_exception_category, EXCEPTION_MAPPING
from .metrics import ExceptionMetrics, get_exception_metrics
from .safe_call import safe_call
from .safe_context import safe_context, async_safe_context
from .recovery import RetryStrategy, CircuitBreaker, with_retry

__all__ = [
    "AppException", "NetworkError", "DatabaseError",
    "ValidationError", "ConfigurationError", "ExternalServiceError",
    "map_exception", "get_exception_category", "EXCEPTION_MAPPING",
    "ExceptionMetrics", "get_exception_metrics",
    "safe_call",
    "safe_context", "async_safe_context",
    "RetryStrategy", "CircuitBreaker", "with_retry",
]
```

### 2. 向后兼容层设计

#### core/__init__.py (向后兼容导出)
```python
"""Core module - backward compatibility exports.

DEPRECATED: Import from submodules directly.
- from core.logging import BizLogger
- from core.http import get_http_client
- from core.cache import TTLCache
"""

import warnings

def _deprecated_import(name: str, new_path: str):
    warnings.warn(
        f"Importing {name} from 'core' is deprecated. "
        f"Use 'from {new_path} import {name}' instead.",
        DeprecationWarning,
        stacklevel=3,
    )

# Lazy imports for backward compatibility
def __getattr__(name: str):
    if name in ("BizLogger", "get_biz_logger"):
        _deprecated_import(name, "core.logging")
        from .logging import BizLogger, get_biz_logger
        return BizLogger if name == "BizLogger" else get_biz_logger
    # ... more lazy imports
    raise AttributeError(f"module 'core' has no attribute '{name}'")
```

#### 旧路径兼容模块 (core/bizlog.py)
```python
"""DEPRECATED: Use core.logging.bizlog instead."""

import warnings
warnings.warn(
    "Importing from 'core.bizlog' is deprecated. "
    "Use 'from core.logging import BizLogger, get_biz_logger' instead.",
    DeprecationWarning,
    stacklevel=2,
)

from core.logging.bizlog import *  # noqa: F401, F403
```

### 3. 迁移脚本设计

```python
# tools/migrate_imports.py
"""Migration script to update import paths."""

import re
from pathlib import Path
from typing import Dict, List, Tuple

IMPORT_MAPPINGS: Dict[str, str] = {
    "from core.bizlog import": "from core.logging import",
    "from core.bizlogger_adapter import": "from core.logging import",
    "from core.logging_setup import": "from core.logging import",
    "from core.logctx import": "from core.logging import",
    "from core.http_clients import": "from core.http import",
    "from core.http_retry import": "from core.http import",
    "from core.cache import": "from core.cache import",
    "from core.persist_cache import": "from core.cache import",
    "from core.stores import": "from core.storage import",
    "from core.fs import": "from core.storage import",
    "from core.file_lock import": "from core.storage import",
    "from core.plugin_api import": "from core.plugins import",
    "from core.plugin_loader import": "from core.plugins import",
    "from core.plugin_registry import": "from core.plugins import",
    "from core.exceptions import": "from core.exceptions import",
    "from core.exception_mapping import": "from core.exceptions import",
    "from core.safe_call import": "from core.exceptions import",
    "from core.safe_context import": "from core.exceptions import",
    "from core.recovery import": "from core.exceptions import",
}

def migrate_file(path: Path, dry_run: bool = True) -> List[Tuple[int, str, str]]:
    """Migrate imports in a single file."""
    changes = []
    content = path.read_text(encoding="utf-8")
    lines = content.splitlines()
    
    for i, line in enumerate(lines):
        for old, new in IMPORT_MAPPINGS.items():
            if old in line:
                new_line = line.replace(old, new)
                changes.append((i + 1, line, new_line))
                lines[i] = new_line
    
    if changes and not dry_run:
        path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    
    return changes
```

## Data Models

### ModuleInfo
```python
@dataclass
class ModuleInfo:
    """模块信息"""
    name: str                    # 模块名
    path: Path                   # 模块路径
    public_symbols: List[str]    # 公开符号列表
    dependencies: List[str]      # 依赖的其他模块
    deprecated: bool = False     # 是否已废弃
```

### ImportMapping
```python
@dataclass
class ImportMapping:
    """导入映射"""
    old_path: str               # 旧导入路径
    new_path: str               # 新导入路径
    symbols: List[str]          # 涉及的符号
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: 子模块 Public API 完整性

*For any* 子模块，其 `__init__.py` 应该导出所有预期的公开符号，且这些符号应该可以正常导入和使用。

**Validates: Requirements 1.2, 2.2, 3.2, 4.3, 5.2, 6.2, 7.2**

### Property 2: 向后兼容导入

*For any* 旧的导入路径，导入操作应该成功且返回与新路径相同的对象。

**Validates: Requirements 1.3, 8.1**

### Property 3: 废弃警告

*For any* 使用旧导入路径的导入，系统应该发出 DeprecationWarning，且警告消息应该包含新的导入路径。

**Validates: Requirements 2.3, 3.3, 8.2**

### Property 4: 无循环依赖

*For any* 子模块组合，导入顺序不应该导致循环依赖错误。

**Validates: Requirements 1.4**

### Property 5: 符号等价性

*For any* 从旧路径导入的符号和从新路径导入的符号，它们应该是同一个对象（`is` 比较为 True）。

**Validates: Requirements 8.1**

## Error Handling

### 导入错误处理

- 如果子模块导入失败，应该提供清晰的错误消息
- 向后兼容层应该优雅处理缺失的模块

### 迁移错误处理

- 迁移脚本应该在修改前备份文件
- 迁移失败时应该回滚更改

## Testing Strategy

### 单元测试

- 测试每个子模块的 `__init__.py` 导出
- 测试向后兼容导入
- 测试废弃警告

### 属性测试

使用 Hypothesis 库进行属性测试：

- **Property 1**: 生成子模块列表，验证公开符号可导入
- **Property 2-3**: 生成旧导入路径，验证兼容性和警告
- **Property 4**: 生成导入顺序排列，验证无循环依赖
- **Property 5**: 生成符号列表，验证等价性

### 集成测试

- 运行完整测试套件验证重构不破坏功能
- 验证迁移脚本正确更新导入

### 测试配置

- 每个属性测试运行 100 次迭代
- 使用 `@settings(max_examples=100)` 配置 Hypothesis
