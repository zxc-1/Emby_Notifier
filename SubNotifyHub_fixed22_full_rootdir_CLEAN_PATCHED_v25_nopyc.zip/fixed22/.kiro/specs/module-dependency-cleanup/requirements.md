# Requirements Document

## Introduction

本项目旨在清理和重组模块依赖关系，提高代码的可维护性和可测试性。当前 `core/` 目录包含 50+ 个文件，职责混杂，需要按功能域拆分为更清晰的子模块。

主要问题：
- `core/` 目录文件过多，难以导航和理解
- 相关功能分散在多个文件中（如 poster_cache_*.py 有 5 个文件）
- 部分模块职责不清晰，存在循环依赖风险
- 缺乏清晰的分层架构

## Glossary

- **Core_Module**: `core/` 目录下的基础设施模块
- **Feature_Module**: 业务功能模块（如 notifier, tg_bot, forward_bridge）
- **Submodule**: 按功能域组织的子目录（如 `core/logging/`, `core/http/`）
- **Public_API**: 模块对外暴露的接口，通过 `__init__.py` 导出
- **Internal_API**: 模块内部使用的接口，不对外暴露

## Requirements

### Requirement 1: core 模块拆分为功能子模块

**User Story:** 作为开发者，我希望 core 模块按功能域组织，以便快速定位和理解代码。

#### Acceptance Criteria

1. THE System SHALL organize core modules into submodules: logging, http, cache, storage, plugins, exceptions
2. WHEN a submodule is created, THE System SHALL provide a clear `__init__.py` with public API exports
3. THE System SHALL maintain backward compatibility by re-exporting from original paths
4. THE System SHALL ensure no circular imports exist between submodules

### Requirement 2: 日志模块整合

**User Story:** 作为开发者，我希望所有日志相关代码集中在一个子模块中。

#### Acceptance Criteria

1. THE System SHALL create `core/logging/` submodule containing: bizlog.py, bizlogger_adapter.py, logging_setup.py, logctx.py
2. THE System SHALL provide unified imports via `from core.logging import BizLogger, get_biz_logger_adapter`
3. WHEN importing from old paths, THE System SHALL emit deprecation warnings

### Requirement 3: HTTP 模块整合

**User Story:** 作为开发者，我希望所有 HTTP 相关代码集中在一个子模块中。

#### Acceptance Criteria

1. THE System SHALL create `core/http/` submodule containing: http_clients.py, http_retry.py, http_exception_handler.py
2. THE System SHALL provide unified imports via `from core.http import get_http_client, async_request_with_retry`
3. WHEN importing from old paths, THE System SHALL emit deprecation warnings

### Requirement 4: 缓存模块整合

**User Story:** 作为开发者，我希望所有缓存相关代码集中在一个子模块中。

#### Acceptance Criteria

1. THE System SHALL create `core/cache/` submodule containing: cache.py, persist_cache.py, poster_cache*.py (合并为单一模块)
2. THE System SHALL merge poster_cache_*.py files into a single poster_cache.py with clear internal organization
3. THE System SHALL provide unified imports via `from core.cache import TTLCache, PosterCache`

### Requirement 5: 存储模块整合

**User Story:** 作为开发者，我希望所有存储相关代码集中在一个子模块中。

#### Acceptance Criteria

1. THE System SHALL create `core/storage/` submodule containing: stores.py, fs.py, file_lock.py, env_store.py
2. THE System SHALL provide unified imports via `from core.storage import BlobStore, file_lock`

### Requirement 6: 插件模块整合

**User Story:** 作为开发者，我希望所有插件相关代码集中在一个子模块中。

#### Acceptance Criteria

1. THE System SHALL create `core/plugins/` submodule containing: plugin_api.py, plugin_loader.py, plugin_registry.py
2. THE System SHALL provide unified imports via `from core.plugins import PluginRegistry, load_plugins`

### Requirement 7: 异常模块整合

**User Story:** 作为开发者，我希望所有异常相关代码集中在一个子模块中。

#### Acceptance Criteria

1. THE System SHALL create `core/exceptions/` submodule containing: exceptions.py, exception_mapping.py, exception_metrics.py, safe_call.py, safe_context.py, recovery.py, db_exception_handler.py
2. THE System SHALL provide unified imports via `from core.exceptions import AppException, safe_call, CircuitBreaker`

### Requirement 8: 向后兼容性

**User Story:** 作为开发者，我希望重构不破坏现有代码。

#### Acceptance Criteria

1. THE System SHALL maintain all existing import paths working
2. WHEN using deprecated import paths, THE System SHALL log a deprecation warning with migration guidance
3. THE System SHALL provide a migration script to update import paths in codebase
4. THE System SHALL ensure all existing tests pass after refactoring

### Requirement 9: 依赖关系文档

**User Story:** 作为开发者，我希望有清晰的模块依赖关系文档。

#### Acceptance Criteria

1. THE System SHALL generate a module dependency graph
2. THE System SHALL document the public API of each submodule
3. THE System SHALL provide guidelines for adding new modules

