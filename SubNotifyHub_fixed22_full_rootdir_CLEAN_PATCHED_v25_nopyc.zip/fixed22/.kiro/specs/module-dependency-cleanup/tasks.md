# Implementation Plan: Module Dependency Cleanup

## Overview

本实现计划将 core 模块按功能域重组为清晰的子模块。实现分为子模块创建、向后兼容层、迁移工具、属性测试四个阶段。

## Tasks

- [x] 1. 创建 logging 子模块
  - [x] 1.1 创建 `core/logging/` 目录结构
    - 创建 `core/logging/__init__.py`
    - 移动 bizlog.py → core/logging/bizlog.py
    - 移动 bizlogger_adapter.py → core/logging/bizlogger_adapter.py
    - 移动 logging_setup.py → core/logging/logging_setup.py
    - 移动 logctx.py → core/logging/logctx.py
    - _Requirements: 2.1_
  - [x] 1.2 创建 logging 子模块 Public API
    - 在 __init__.py 中导出所有公开符号
    - 确保 `from core.logging import BizLogger, get_biz_logger_adapter` 可用
    - _Requirements: 2.2_
  - [x] 1.3 创建旧路径兼容模块
    - 创建 core/bizlog.py 兼容层（发出废弃警告）
    - 创建 core/bizlogger_adapter.py 兼容层
    - 创建 core/logging_setup.py 兼容层
    - 创建 core/logctx.py 兼容层
    - _Requirements: 2.3, 8.1, 8.2_

- [x] 2. 创建 http 子模块
  - [x] 2.1 创建 `core/http/` 目录结构
    - 创建 `core/http/__init__.py`
    - 移动 http_clients.py → core/http/clients.py
    - 移动 http_retry.py → core/http/retry.py
    - 移动 http_exception_handler.py → core/http/exception_handler.py
    - _Requirements: 3.1_
  - [x] 2.2 创建 http 子模块 Public API
    - 在 __init__.py 中导出所有公开符号
    - 确保 `from core.http import get_http_client, async_request_with_retry` 可用
    - _Requirements: 3.2_
  - [x] 2.3 创建旧路径兼容模块
    - 创建 core/http_clients.py 兼容层
    - 创建 core/http_retry.py 兼容层
    - 创建 core/http_exception_handler.py 兼容层
    - _Requirements: 3.3, 8.1, 8.2_

- [x] 3. 创建 cache 子模块
  - [x] 3.1 创建 `core/cache/` 目录结构
    - 创建 `core/cache/__init__.py`
    - 移动 cache.py → core/cache/ttl_cache.py
    - 移动 persist_cache.py → core/cache/persist_cache.py
    - _Requirements: 4.1_
  - [x] 3.2 合并 poster_cache 相关文件
    - 合并 poster_cache.py, poster_cache_evict.py, poster_cache_fetch.py, poster_cache_fs.py, poster_cache_keys.py
    - 创建 core/cache/poster_cache.py（合并后的单一模块）
    - _Requirements: 4.2_
  - [x] 3.3 创建 cache 子模块 Public API
    - 在 __init__.py 中导出所有公开符号
    - 确保 `from core.cache import TTLCache, PosterCache` 可用
    - _Requirements: 4.3_
  - [x] 3.4 创建旧路径兼容模块
    - 创建 core/cache.py 兼容层
    - 创建 core/persist_cache.py 兼容层
    - 创建 core/poster_cache.py 等兼容层
    - _Requirements: 8.1, 8.2_

- [x] 4. Checkpoint - 核心子模块测试
  - 确保 logging, http, cache 子模块测试通过，如有问题请询问用户

- [x] 5. 创建 storage 子模块
  - [x] 5.1 创建 `core/storage/` 目录结构
    - 创建 `core/storage/__init__.py`
    - 移动 stores.py → core/storage/blob_store.py
    - 移动 fs.py → core/storage/fs.py
    - 移动 file_lock.py → core/storage/file_lock.py
    - 移动 env_store.py → core/storage/env_store.py
    - _Requirements: 5.1_
  - [x] 5.2 创建 storage 子模块 Public API
    - 在 __init__.py 中导出所有公开符号
    - 确保 `from core.storage import BlobStore, file_lock` 可用
    - _Requirements: 5.2_
  - [x] 5.3 创建旧路径兼容模块
    - 创建 core/stores.py 兼容层
    - 创建 core/fs.py 兼容层
    - 创建 core/file_lock.py 兼容层
    - 创建 core/env_store.py 兼容层
    - _Requirements: 8.1, 8.2_

- [x] 6. 创建 plugins 子模块
  - [x] 6.1 创建 `core/plugins/` 目录结构
    - 创建 `core/plugins/__init__.py`
    - 移动 plugin_api.py → core/plugins/api.py
    - 移动 plugin_loader.py → core/plugins/loader.py
    - 移动 plugin_registry.py → core/plugins/registry.py
    - _Requirements: 6.1_
  - [x] 6.2 创建 plugins 子模块 Public API
    - 在 __init__.py 中导出所有公开符号
    - 确保 `from core.plugins import PluginRegistry, load_plugins` 可用
    - _Requirements: 6.2_
  - [x] 6.3 创建旧路径兼容模块
    - 创建 core/plugin_api.py 兼容层
    - 创建 core/plugin_loader.py 兼容层
    - 创建 core/plugin_registry.py 兼容层
    - _Requirements: 8.1, 8.2_

- [x] 7. 创建 exceptions 子模块
  - [x] 7.1 创建 `core/exceptions/` 目录结构
    - 创建 `core/exceptions/__init__.py`
    - 移动 exceptions.py → core/exceptions/base.py
    - 移动 exception_mapping.py → core/exceptions/mapping.py
    - 移动 exception_metrics.py → core/exceptions/metrics.py
    - 移动 safe_call.py → core/exceptions/safe_call.py
    - 移动 safe_context.py → core/exceptions/safe_context.py
    - 移动 recovery.py → core/exceptions/recovery.py
    - 移动 db_exception_handler.py → core/exceptions/db_handler.py
    - _Requirements: 7.1_
  - [x] 7.2 创建 exceptions 子模块 Public API
    - 在 __init__.py 中导出所有公开符号
    - 确保 `from core.exceptions import AppException, safe_call, CircuitBreaker` 可用
    - _Requirements: 7.2_
  - [x] 7.3 创建旧路径兼容模块
    - 创建 core/exceptions.py 兼容层
    - 创建 core/exception_mapping.py 兼容层
    - 创建 core/safe_call.py 兼容层
    - 创建 core/safe_context.py 兼容层
    - 创建 core/recovery.py 兼容层
    - _Requirements: 8.1, 8.2_

- [x] 8. Checkpoint - 所有子模块测试
  - 确保所有子模块测试通过，如有问题请询问用户

- [x] 9. 编写属性测试
  - [x] 9.1 编写子模块 Public API 完整性属性测试
    - **Property 1: 子模块 Public API 完整性**
    - **Validates: Requirements 1.2, 2.2, 3.2, 4.3, 5.2, 6.2, 7.2**
  - [x] 9.2 编写向后兼容导入属性测试
    - **Property 2: 向后兼容导入**
    - **Validates: Requirements 1.3, 8.1**
  - [x] 9.3 编写废弃警告属性测试
    - **Property 3: 废弃警告**
    - **Validates: Requirements 2.3, 3.3, 8.2**
  - [x] 9.4 编写无循环依赖属性测试
    - **Property 4: 无循环依赖**
    - **Validates: Requirements 1.4**
  - [x] 9.5 编写符号等价性属性测试
    - **Property 5: 符号等价性**
    - **Validates: Requirements 8.1**

- [x] 10. 创建迁移工具
  - [x] 10.1 创建 `tools/migrate_imports.py`
    - 实现导入路径扫描
    - 实现导入路径替换
    - 支持 dry-run 模式
    - 支持备份和回滚
    - _Requirements: 8.3_
  - [x] 10.2 运行迁移工具更新项目导入
    - 更新 admin/, api/, application/ 目录
    - 更新 bootstrap/, compat/ 目录
    - 更新 notifier/, tg_bot/, forward_bridge/ 目录
    - 更新 integrations/, douban_hotlist/ 目录
    - _Requirements: 8.3_

- [x] 11. Checkpoint - 迁移完成
  - 确保所有导入已更新，运行完整测试套件验证
  - 如有问题请询问用户

- [x] 12. 生成依赖关系文档
  - [x] 12.1 创建 `tools/generate_dependency_graph.py`
    - 分析模块导入关系
    - 生成 Mermaid 格式依赖图
    - _Requirements: 9.1_
  - [x] 12.2 创建 `docs/MODULE_STRUCTURE.md`
    - 文档化每个子模块的 Public API
    - 提供添加新模块的指南
    - _Requirements: 9.2, 9.3_

- [x] 13. 最终验证
  - [x] 13.1 运行完整测试套件
    - 确保所有单元测试和属性测试通过
  - [x] 13.2 验证废弃警告
    - 确认旧路径导入产生正确的废弃警告
  - [x] 13.3 验证依赖图
    - 确认没有循环依赖

## Notes

- 所有任务均为必需任务，确保全面测试覆盖
- 每个属性测试任务对应设计文档中的一个 Correctness Property
- 子模块创建应保持向后兼容，不破坏现有功能
- Checkpoint 任务用于阶段性验证，确保增量开发的稳定性
- 迁移顺序：logging → http → cache → storage → plugins → exceptions
