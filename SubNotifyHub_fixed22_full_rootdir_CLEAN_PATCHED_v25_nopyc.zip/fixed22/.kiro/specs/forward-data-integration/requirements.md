# Requirements Document

## Introduction

本功能旨在优化 Forward Bridge 配置页面的前端数据集成，实现与 hotlist 页面类似的缓存策略、错误处理和用户体验增强。当前页面已有基础的 API 调用，但缺乏缓存机制、统一的 API 封装层和完善的错误处理。

## Glossary

- **Forward_Page**: Forward Bridge 配置页面，用于管理 MediaHelp 连接和订阅转发设置
- **Forward_Config**: Forward Bridge 的配置数据，包含启用状态、MediaHelp 地址、Token 等
- **Forward_Status**: Forward Bridge 的运行状态，包含连接状态、Token 过期时间、缓存订阅数等
- **MediaHelp**: 媒体订阅管理服务，Forward Bridge 通过它管理订阅
- **Activity_Log**: 页面操作活动日志，记录用户操作历史
- **ForwardCache**: 前端本地缓存模块，用于缓存配置和状态数据
- **ForwardAPI**: 前端 API 封装模块，统一处理所有 API 调用

## Requirements

### Requirement 1: 配置数据加载与缓存

**User Story:** As a user, I want the configuration page to load quickly with cached data, so that I can have a responsive experience.

#### Acceptance Criteria

1. WHEN the Forward page loads, THE Forward_Page SHALL request configuration data from `/admin/forward/config.json` API
2. WHEN configuration data is received, THE Forward_Page SHALL populate all form fields with the received values
3. THE Forward_Page SHALL cache configuration data in localStorage with TTL of 2 minutes
4. WHEN cached data exists, THE Forward_Page SHALL display cached data immediately while fetching fresh data (stale-while-revalidate)
5. IF the configuration API request fails, THEN THE Forward_Page SHALL display cached data or show error state with retry option

### Requirement 2: 状态数据加载与显示

**User Story:** As a user, I want to see real-time status of Forward Bridge, so that I can monitor the service health.

#### Acceptance Criteria

1. WHEN the Forward page loads, THE Forward_Page SHALL request status data from `/admin/forward/status.json` API
2. WHEN status data is received, THE Forward_Page SHALL update Bridge 状态、MediaHelp 连接、Token 过期、缓存订阅数显示
3. THE Forward_Page SHALL auto-refresh status every 30 seconds
4. THE Forward_Page SHALL cache status data in localStorage with TTL of 30 seconds
5. WHILE status data is loading, THE Forward_Page SHALL show "检测中..." indicator
6. IF the status API request fails, THEN THE Forward_Page SHALL show "连接失败" and use cached data if available

### Requirement 3: 配置保存功能

**User Story:** As a user, I want to save my configuration changes, so that they persist across sessions.

#### Acceptance Criteria

1. WHEN the user clicks "保存配置", THE Forward_Page SHALL collect all form values and call `/admin/forward/config` API
2. WHILE the save request is in progress, THE Forward_Page SHALL disable the save button and show loading state
3. IF the save request succeeds, THEN THE Forward_Page SHALL show success toast, invalidate cache, and add activity log
4. IF the save request fails, THEN THE Forward_Page SHALL show error toast with detail message
5. WHEN configuration is saved, THE Forward_Page SHALL update the cached data

### Requirement 4: MediaHelp 连接测试

**User Story:** As a user, I want to test MediaHelp connection, so that I can verify my configuration is correct.

#### Acceptance Criteria

1. WHEN the user clicks "测试连接", THE Forward_Page SHALL validate MediaHelp 地址 is not empty
2. IF MediaHelp 地址 is empty, THEN THE Forward_Page SHALL show warning toast
3. WHILE the test request is in progress, THE Forward_Page SHALL show "正在测试连接..." toast and disable the button
4. IF the test succeeds, THEN THE Forward_Page SHALL show success toast and add activity log
5. IF the test fails, THEN THE Forward_Page SHALL show error toast with detail message

### Requirement 5: 快捷操作功能

**User Story:** As a user, I want quick action buttons for common operations, so that I can manage the service efficiently.

#### Acceptance Criteria

1. WHEN the user clicks "清除缓存", THE Forward_Page SHALL show confirmation dialog before calling `/admin/forward/clear_cache` API
2. WHEN the user clicks "刷新 Token", THE Forward_Page SHALL call `/admin/forward/refresh_token` API
3. WHEN the user clicks "同步订阅", THE Forward_Page SHALL call `/admin/forward/sync_subs` API and show progress toast
4. WHILE any quick action is in progress, THE Forward_Page SHALL disable the button and show loading state
5. IF a quick action succeeds, THEN THE Forward_Page SHALL show success toast, refresh status, and add activity log
6. IF a quick action fails, THEN THE Forward_Page SHALL show error toast with detail message

### Requirement 6: 活动日志记录

**User Story:** As a user, I want to see recent activity logs, so that I can track what operations have been performed.

#### Acceptance Criteria

1. WHEN an operation is performed, THE Forward_Page SHALL add a timestamped entry to the activity log
2. THE Forward_Page SHALL display up to 10 most recent activity entries
3. THE Forward_Page SHALL persist activity log to localStorage
4. WHEN the page loads, THE Forward_Page SHALL restore activity log from localStorage

### Requirement 7: API 响应格式标准化

**User Story:** As a developer, I want consistent API response formats, so that I can reliably handle responses.

#### Acceptance Criteria

1. THE API SHALL return JSON responses with `ok` (boolean) field
2. WHEN a request succeeds, THE API SHALL set `ok: true` and include relevant data
3. WHEN a request fails, THE API SHALL set `ok: false` and include `detail` (error message) field
4. THE `/admin/forward/config.json` API SHALL include `config` object with all configuration fields
5. THE `/admin/forward/status.json` API SHALL include `status` object with `bridge_ok`, `mh_connected`, `token_expires`, `cached_subs` fields

### Requirement 8: 缓存时间显示

**User Story:** As a user, I want to see when data was last updated, so that I know how fresh the displayed data is.

#### Acceptance Criteria

1. THE Forward_Page SHALL display "上次更新" timestamp when showing cached data
2. WHEN data is refreshed, THE Forward_Page SHALL update the timestamp display
3. THE Forward_Page SHALL format timestamp in user-friendly format (e.g., "刚刚", "1 分钟前")

### Requirement 9: 错误处理和用户反馈

**User Story:** As a user, I want clear feedback on my actions, so that I know what's happening.

#### Acceptance Criteria

1. WHEN an API request is in progress, THE Forward_Page SHALL disable the action button and show loading state
2. WHEN an API request succeeds, THE Forward_Page SHALL show a success toast notification
3. WHEN an API request fails, THE Forward_Page SHALL show an error toast with detail message
4. IF network is unavailable, THEN THE Forward_Page SHALL display offline indicator and use cached data
5. THE Forward_Page SHALL provide retry option for failed requests

### Requirement 10: 表单辅助功能

**User Story:** As a user, I want helpful form features, so that I can configure the service easily.

#### Acceptance Criteria

1. WHEN the user clicks password toggle button, THE Forward_Page SHALL toggle password visibility
2. WHEN the user clicks "生成随机 Token" button, THE Forward_Page SHALL generate a 32-character random token
3. WHEN a token is generated, THE Forward_Page SHALL show the token in plain text and show success toast
