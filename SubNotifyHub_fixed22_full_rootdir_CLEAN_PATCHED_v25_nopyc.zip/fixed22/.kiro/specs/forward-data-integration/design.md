# Design Document: Forward Bridge Data Integration

## Overview

本设计文档描述 Forward Bridge 配置页面与后端 API 数据打通的技术方案。核心目标是增强现有页面的数据加载、缓存策略、错误处理和用户体验，与 hotlist 页面保持一致的架构模式。

设计采用以下架构模式：
- **API 层**: 复用现有后端 API 端点
- **前端层**: 增强 `static/js/forward.js`，添加 ForwardCache 和 ForwardAPI 模块
- **数据流**: 采用 stale-while-revalidate 模式，优先展示缓存数据

### 现有代码复用分析

| 功能 | 现有代码位置 | 复用方式 |
|------|-------------|---------|
| 配置获取 API | `/admin/forward/config.json` | ✅ 直接复用 |
| 配置保存 API | `/admin/forward/config` | ✅ 直接复用 |
| 状态获取 API | `/admin/forward/status.json` | ✅ 直接复用 |
| 测试连接 API | `/admin/forward/test_mediahelp` | ✅ 直接复用 |
| 清除缓存 API | `/admin/forward/clear_cache` | ✅ 直接复用 |
| 刷新 Token API | `/admin/forward/refresh_token` | ✅ 直接复用 |
| 同步订阅 API | `/admin/forward/sync_subs` | ✅ 直接复用 |
| 前端渲染 | `static/js/forward.js` | ✅ 增强，添加缓存和错误处理 |
| Toast 通知 | `static/js/common.js:showToast()` | ✅ 直接复用 |

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        Frontend (Browser)                        │
├─────────────────────────────────────────────────────────────────┤
│  forward.js                                                      │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │ ForwardAPI   │  │ ForwardCache │  │ ForwardUI    │          │
│  │ - getConfig  │  │ - get/set    │  │ - fillForm   │          │
│  │ - saveConfig │  │ - isValid    │  │ - updateStat │          │
│  │ - getStatus  │  │ - invalidate │  │ - showToast  │          │
│  │ - testConn   │  │ - getStale   │  │ - addActivity│          │
│  │ - clearCache │  │ - getAge     │  │ - setLoading │          │
│  │ - refreshTkn │  └──────────────┘  └──────────────┘          │
│  │ - syncSubs   │                                               │
│  └──────────────┘                                               │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼ HTTP/JSON
┌─────────────────────────────────────────────────────────────────┐
│                        Backend (FastAPI)                         │
├─────────────────────────────────────────────────────────────────┤
│  /admin/forward/config.json    → 获取配置                        │
│  /admin/forward/config         → 保存配置                        │
│  /admin/forward/status.json    → 获取状态                        │
│  /admin/forward/test_mediahelp → 测试 MediaHelp 连接             │
│  /admin/forward/clear_cache    → 清除订阅缓存                    │
│  /admin/forward/refresh_token  → 刷新 MediaHelp Token            │
│  /admin/forward/sync_subs      → 同步订阅                        │
└─────────────────────────────────────────────────────────────────┘
```

## Components and Interfaces

### 1. Backend API (已存在，无需修改)

#### 1.1 Config API (`/admin/forward/config.json`)

```python
@router.get("/admin/forward/config.json")
async def get_forward_config() -> Dict[str, Any]:
    """返回 Forward Bridge 配置"""
    return {
        "ok": True,
        "config": {
            "enabled": bool,
            "token_ttl": int,
            "sub_cache_ttl": int,
            "debug": bool,
            "season_filter": bool,
            "allow_public_notify": bool,
            "token": str,
            "allow_no_token": bool,
            "mediahelp_base": str,
            "mediahelp_token": str,
            "mediahelp_username": str,
            "mediahelp_password": str
        }
    }
```

#### 1.2 Status API (`/admin/forward/status.json`)

```python
@router.get("/admin/forward/status.json")
async def get_forward_status() -> Dict[str, Any]:
    """返回 Forward Bridge 运行状态"""
    return {
        "ok": True,
        "status": {
            "bridge_ok": bool,
            "mh_connected": bool,
            "token_expires": int | None,  # Unix timestamp
            "cached_subs": int
        }
    }
```

### 2. Frontend Components (需要增强)

#### 2.1 ForwardCache Module

```javascript
const ForwardCache = {
    CONFIG_KEY: 'snh_forward_config_cache',
    STATUS_KEY: 'snh_forward_status_cache',
    CONFIG_TTL: 2 * 60 * 1000,   // 2 minutes for config
    STATUS_TTL: 30 * 1000,       // 30 seconds for status
    
    // 获取缓存数据
    get(key) {
        try {
            const raw = localStorage.getItem(key);
            if (!raw) return null;
            const item = JSON.parse(raw);
            return item;
        } catch (e) {
            return null;
        }
    },
    
    // 设置缓存数据
    set(key, data, ttl) {
        try {
            const item = { data, timestamp: Date.now(), ttl };
            localStorage.setItem(key, JSON.stringify(item));
        } catch (e) {
            console.warn('Cache set failed:', e);
        }
    },
    
    // 检查缓存是否有效
    isValid(key) {
        const item = this.get(key);
        if (!item) return false;
        return Date.now() - item.timestamp < item.ttl;
    },
    
    // 清除缓存
    invalidate(key) {
        localStorage.removeItem(key);
    },
    
    // 获取过期数据（用于 stale-while-revalidate）
    getStale(key) {
        const item = this.get(key);
        return item ? item.data : null;
    },
    
    // 获取缓存年龄（毫秒）
    getAge(key) {
        const item = this.get(key);
        if (!item) return Infinity;
        return Date.now() - item.timestamp;
    },
    
    // 格式化缓存时间
    formatAge(key) {
        const age = this.getAge(key);
        if (age === Infinity) return '未知';
        if (age < 60000) return '刚刚';
        if (age < 3600000) return `${Math.floor(age / 60000)} 分钟前`;
        return `${Math.floor(age / 3600000)} 小时前`;
    }
};
```

#### 2.2 ForwardAPI Module

```javascript
const ForwardAPI = {
    // 获取配置
    async getConfig() {
        const res = await fetch('/admin/forward/config.json');
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return await res.json();
    },
    
    // 保存配置
    async saveConfig(config) {
        const res = await fetch('/admin/forward/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(config)
        });
        return await res.json();
    },
    
    // 获取状态
    async getStatus() {
        const res = await fetch('/admin/forward/status.json');
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return await res.json();
    },
    
    // 测试 MediaHelp 连接
    async testConnection(params) {
        const res = await fetch('/admin/forward/test_mediahelp', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(params)
        });
        return await res.json();
    },
    
    // 清除缓存
    async clearCache() {
        const res = await fetch('/admin/forward/clear_cache', { method: 'POST' });
        return await res.json();
    },
    
    // 刷新 Token
    async refreshToken() {
        const res = await fetch('/admin/forward/refresh_token', { method: 'POST' });
        return await res.json();
    },
    
    // 同步订阅
    async syncSubscriptions() {
        const res = await fetch('/admin/forward/sync_subs', { method: 'POST' });
        return await res.json();
    }
};
```

#### 2.3 数据加载模式

```javascript
// Stale-while-revalidate 模式
async function loadConfigWithCache() {
    // 1. 先显示缓存数据
    const cached = ForwardCache.getStale(ForwardCache.CONFIG_KEY);
    if (cached) {
        fillForm(cached.config);
        updateCacheIndicator('config');
    }
    
    // 2. 后台获取最新数据
    try {
        const data = await ForwardAPI.getConfig();
        if (data.ok) {
            ForwardCache.set(ForwardCache.CONFIG_KEY, data, ForwardCache.CONFIG_TTL);
            fillForm(data.config);
            updateCacheIndicator('config');
        }
    } catch (error) {
        if (!cached) {
            showError('加载配置失败', () => loadConfigWithCache());
        }
    }
}
```

## Data Models

### Frontend Data Structures

```typescript
interface ForwardConfig {
    enabled: boolean;
    token_ttl: number;
    sub_cache_ttl: number;
    debug: boolean;
    season_filter: boolean;
    allow_public_notify: boolean;
    token: string;
    allow_no_token: boolean;
    mediahelp_base: string;
    mediahelp_token: string;
    mediahelp_username: string;
    mediahelp_password: string;
}

interface ForwardStatus {
    bridge_ok: boolean;
    mh_connected: boolean;
    token_expires: number | null;  // Unix timestamp
    cached_subs: number;
}

interface CacheEntry<T> {
    data: T;
    timestamp: number;
    ttl: number;
}

interface ActivityLogEntry {
    time: string;      // HH:MM format
    msg: string;
}

interface APIResponse<T = any> {
    ok: boolean;
    detail?: string;
    config?: ForwardConfig;
    status?: ForwardStatus;
    count?: number;
    data?: T;
}
```



## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Form Population Completeness

*For any* valid ForwardConfig object with non-null fields, when `fillForm(config)` is called, all corresponding form input elements SHALL have their values set to match the config object fields.

**Validates: Requirements 1.2**

### Property 2: Status Display Completeness

*For any* valid ForwardStatus object, when `updateStatusDisplay(status)` is called, the status display elements SHALL show:
- Bridge 状态: "运行中" if `bridge_ok` is true, "已停止" otherwise
- MediaHelp 连接: "已连接" if `mh_connected` is true, "未连接" otherwise
- Token 过期: formatted days remaining if `token_expires` is set, "--" otherwise
- 缓存订阅数: the value of `cached_subs`

**Validates: Requirements 2.2**

### Property 3: Cache TTL Enforcement

*For any* cached data entry with timestamp T and TTL value:
- `isValid()` SHALL return true when current time < T + TTL
- `isValid()` SHALL return false when current time >= T + TTL
- After `invalidate()` is called, `isValid()` SHALL return false
- After `set()` is called, `getStale()` SHALL return the stored data

**Validates: Requirements 1.3, 2.4, 3.5**

### Property 4: Form Data Collection Accuracy

*For any* form state with input values, when `collectFormData()` is called, the returned config object SHALL contain:
- All checkbox values as booleans matching their checked state
- All text input values as trimmed strings
- All number input values as integers (with defaults for empty/invalid)

**Validates: Requirements 3.1**

### Property 5: Activity Log Management

*For any* sequence of activity log operations:
- After `addActivity(msg)`, the log SHALL contain an entry with the message and current timestamp
- The log SHALL never contain more than 10 entries (oldest entries are removed)
- After `save()`, localStorage SHALL contain the log data
- After `load()`, the log SHALL be restored from localStorage

**Validates: Requirements 6.1, 6.2, 6.3**

### Property 6: API Response Format Consistency

*For any* API endpoint under `/admin/forward/*`:
- The response SHALL contain `ok` (boolean) field
- When `ok` is false, a `detail` string field SHALL be present
- `/admin/forward/config.json` response SHALL contain `config` object with all config fields
- `/admin/forward/status.json` response SHALL contain `status` object with `bridge_ok`, `mh_connected`, `token_expires`, `cached_subs` fields

**Validates: Requirements 7.1, 7.2, 7.3, 7.4, 7.5**

### Property 7: Cache Age Formatting

*For any* cache age value in milliseconds:
- Age < 60000 (1 minute) SHALL format as "刚刚"
- Age >= 60000 and < 3600000 (1 hour) SHALL format as "N 分钟前"
- Age >= 3600000 SHALL format as "N 小时前"
- Infinity (no cache) SHALL format as "未知"

**Validates: Requirements 8.3**

### Property 8: Token Generation

*For any* call to `generateToken()`:
- The generated token SHALL be exactly 32 characters long
- The token SHALL only contain alphanumeric characters (A-Z, a-z, 0-9)
- Each generated token SHALL be different (with high probability)

**Validates: Requirements 10.2**

## Error Handling

### Frontend Error Handling

1. **Network Error**: Show cached data + "离线模式" indicator, provide retry button
2. **API Error (ok: false)**: Show error toast with detail message
3. **Parse Error**: Log to console, show generic error message
4. **Timeout**: Retry once, then show timeout message

```javascript
async function fetchWithFallback(fetchFn, cacheKey) {
    try {
        const data = await fetchFn();
        if (data.ok) {
            ForwardCache.set(cacheKey, data, ForwardCache.CONFIG_TTL);
            return { data, fromCache: false };
        } else {
            throw new Error(data.detail || '请求失败');
        }
    } catch (error) {
        const cached = ForwardCache.getStale(cacheKey);
        if (cached) {
            return { data: cached, fromCache: true, error };
        }
        throw error;
    }
}
```

### Mutation Error Handling

```javascript
async function withMutationFeedback(operation, successMsg, btn) {
    const originalText = btn?.innerHTML;
    try {
        if (btn) {
            btn.disabled = true;
            btn.innerHTML = '<span class="spinner-small"></span>处理中...';
        }
        
        const result = await operation();
        if (result.ok) {
            showToast(successMsg, 'success');
            ForwardCache.invalidate(ForwardCache.CONFIG_KEY);
            addActivity(successMsg);
        } else {
            showToast(result.detail || '操作失败', 'error');
        }
        return result;
    } catch (error) {
        showToast('网络错误，请重试', 'error');
        throw error;
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = originalText;
        }
    }
}
```

### Quick Action Error Handling

```javascript
async function executeQuickAction(actionFn, actionName, btn) {
    return withMutationFeedback(
        async () => {
            const result = await actionFn();
            if (result.ok) {
                await refreshStatus();  // 刷新状态
            }
            return result;
        },
        `${actionName}成功`,
        btn
    );
}
```

## Testing Strategy

### Unit Tests

1. **Cache Logic**: Test TTL calculation, invalidation, stale data retrieval
2. **Form Population**: Test form field population with various config values
3. **Status Display**: Test status display with various status values
4. **Activity Log**: Test log addition, limit enforcement, persistence
5. **Cache Age Formatting**: Test formatting for various age values
6. **Token Generation**: Test token length and character set

### Property-Based Tests

使用 Hypothesis (Python) 进行属性测试：

1. **Property 3 (Cache TTL)**: Generate random timestamps and TTL values, verify cache validity logic
2. **Property 4 (Form Collection)**: Generate random form values, verify collection accuracy
3. **Property 5 (Activity Log)**: Generate random activity sequences, verify log management
4. **Property 6 (API Format)**: Generate random API responses, verify schema compliance
5. **Property 7 (Cache Age)**: Generate random age values, verify formatting
6. **Property 8 (Token)**: Generate multiple tokens, verify length and uniqueness

### Integration Tests

1. **Config Load Flow**: Verify stale-while-revalidate works correctly
2. **Save Flow**: Verify save triggers cache invalidation and activity log
3. **Quick Actions**: Verify each quick action triggers correct API and updates status
4. **Error Recovery**: Verify fallback to cache on API failure

### Test Configuration

- Minimum 100 iterations per property test
- Tag format: `Feature: forward-data-integration, Property {N}: {description}`
- Property tests use Hypothesis (Python) for backend validation
- Frontend tests use Jest with mock localStorage
