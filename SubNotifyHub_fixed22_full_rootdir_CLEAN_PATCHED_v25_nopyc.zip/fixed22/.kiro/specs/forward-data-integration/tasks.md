# Implementation Plan: Forward Bridge Data Integration

## Overview

增强 Forward Bridge 配置页面的前端功能，添加缓存、错误处理和用户体验优化。后端 API 已存在，主要工作在前端 JavaScript。

## Tasks

- [x] 1. 实现前端缓存模块
  - [x] 1.1 创建 ForwardCache 对象
    - 实现 get/set/isValid/invalidate/getStale/getAge/formatAge 方法
    - 配置数据 TTL 设置为 2 分钟，状态数据 TTL 设置为 30 秒
    - _Requirements: 1.3, 2.4_

  - [x] 1.2 编写缓存 TTL 属性测试
    - **Property 3: Cache TTL Enforcement**
    - **Validates: Requirements 1.3, 2.4, 3.5**

- [x] 2. 实现 ForwardAPI 模块
  - [x] 2.1 封装 API 调用方法
    - 实现 getConfig, saveConfig, getStatus, testConnection, clearCache, refreshToken, syncSubscriptions
    - 统一错误处理
    - _Requirements: 7.1, 7.2, 7.3_

  - [x] 2.2 编写 API 响应格式属性测试
    - **Property 6: API Response Format Consistency**
    - **Validates: Requirements 7.1, 7.2, 7.3, 7.4, 7.5**

- [x] 3. 增强配置数据加载
  - [x] 3.1 实现 stale-while-revalidate 模式
    - 优先显示缓存数据
    - 后台刷新最新数据
    - _Requirements: 1.4_

  - [x] 3.2 增强表单填充逻辑
    - 确保所有配置字段正确填充
    - _Requirements: 1.2_

  - [x] 3.3 编写表单填充属性测试
    - **Property 1: Form Population Completeness**
    - **Validates: Requirements 1.2**

  - [x] 3.4 实现错误状态和重试
    - 网络错误时显示缓存数据 + 错误提示
    - 添加重试按钮
    - _Requirements: 1.5, 9.4, 9.5_

- [x] 4. 增强状态数据加载
  - [x] 4.1 实现状态数据缓存
    - 30 秒 TTL 缓存
    - stale-while-revalidate 模式
    - _Requirements: 2.4_

  - [x] 4.2 优化状态显示逻辑
    - 确保 Bridge 状态、MediaHelp 连接、Token 过期、缓存订阅数正确显示
    - _Requirements: 2.2_

  - [x] 4.3 编写状态显示属性测试
    - **Property 2: Status Display Completeness**
    - **Validates: Requirements 2.2**

  - [x] 4.4 实现加载状态指示
    - 显示"检测中..."指示器
    - _Requirements: 2.5_

- [x] 5. Checkpoint - 数据加载功能完成
  - 确保配置和状态数据正确加载和显示
  - 测试缓存和错误处理

- [x] 6. 增强配置保存功能
  - [x] 6.1 优化表单数据收集
    - 收集所有表单值
    - 正确处理 checkbox、text、number 类型
    - _Requirements: 3.1_

  - [x] 6.2 编写表单数据收集属性测试
    - **Property 4: Form Data Collection Accuracy**
    - **Validates: Requirements 3.1**

  - [x] 6.3 添加保存加载状态
    - 禁用按钮并显示 loading
    - _Requirements: 3.2_

  - [x] 6.4 实现保存后缓存失效
    - 保存成功后清除缓存并刷新
    - _Requirements: 3.3, 3.5_

- [x] 7. 增强 MediaHelp 连接测试
  - [x] 7.1 添加输入验证
    - 验证 MediaHelp 地址非空
    - _Requirements: 4.1, 4.2_

  - [x] 7.2 添加测试加载状态
    - 显示"正在测试连接..."
    - 禁用按钮
    - _Requirements: 4.3_

  - [x] 7.3 优化测试结果反馈
    - 成功/失败 toast 和活动日志
    - _Requirements: 4.4, 4.5_

- [x] 8. 增强快捷操作功能
  - [x] 8.1 优化清除缓存操作
    - 添加确认对话框
    - 添加加载状态
    - _Requirements: 5.1, 5.4_

  - [x] 8.2 优化刷新 Token 操作
    - 添加加载状态
    - 成功后刷新状态
    - _Requirements: 5.2, 5.4, 5.5_

  - [x] 8.3 优化同步订阅操作
    - 显示进度 toast
    - 显示同步数量
    - _Requirements: 5.3, 5.4, 5.5, 5.6_

- [x] 9. 增强活动日志功能
  - [x] 9.1 优化活动日志管理
    - 限制最多 10 条
    - 持久化到 localStorage
    - 页面加载时恢复
    - _Requirements: 6.1, 6.2, 6.3, 6.4_

  - [x] 9.2 编写活动日志属性测试
    - **Property 5: Activity Log Management**
    - **Validates: Requirements 6.1, 6.2, 6.3**

- [x] 10. 添加缓存时间显示
  - [x] 10.1 实现缓存时间指示器
    - 显示"上次更新"时间
    - 格式化为友好格式（刚刚、N 分钟前）
    - _Requirements: 8.1, 8.2, 8.3_

  - [x] 10.2 编写缓存时间格式化属性测试
    - **Property 7: Cache Age Formatting**
    - **Validates: Requirements 8.3**

- [x] 11. 增强表单辅助功能
  - [x] 11.1 优化密码显示/隐藏
    - 确保 togglePassword 正常工作
    - _Requirements: 10.1_

  - [x] 11.2 优化 Token 生成
    - 生成 32 位随机 Token
    - 显示成功 toast
    - _Requirements: 10.2, 10.3_

  - [x] 11.3 编写 Token 生成属性测试
    - **Property 8: Token Generation**
    - **Validates: Requirements 10.2**

- [x] 12. 统一错误处理和用户反馈
  - [x] 12.1 实现统一的 API 错误处理
    - 网络错误、API 错误、超时处理
    - _Requirements: 9.1, 9.2, 9.3_

  - [x] 12.2 添加离线指示器
    - 网络不可用时显示
    - _Requirements: 9.4_

- [x] 13. Final Checkpoint
  - 确保所有功能正常工作
  - 验证缓存和错误处理
  - 运行所有属性测试

## Notes

- 所有任务都是必须完成的，包括属性测试
- 后端 API 已存在，无需修改
- 前端使用渐进式增强，保持向后兼容
- 属性测试使用 Hypothesis (Python) 或 Jest (JavaScript)
- 复用 common.js 中的 showToast 函数
