# Requirements Document

## Introduction

本文档定义了前端公共模块重构的需求。当前项目有 4 个前端 JS 文件（settings.js、tgbot.js、forward.js、hotlist.js）存在大量代码重复，包括缓存模块、活动日志、表单辅助函数、工具函数等。本次重构旨在将这些重复代码抽取为通用公共模块，减少代码量约 40%，提高可维护性，同时保持向后兼容。

## Glossary

- **Cache_Factory**: 通用缓存工厂函数，用于创建具有统一接口的缓存实例
- **Activity_Logger**: 活动日志工厂函数，用于创建页面级活动日志实例
- **Form_Helper**: 表单辅助函数模块，提供统一的表单值读写操作
- **Mutation_Feedback**: 操作反馈辅助函数，用于处理异步操作的 UI 状态
- **Config_IO**: 配置导入导出模块，提供统一的配置文件导入导出功能
- **Page_Module**: 页面级 JS 模块（settings.js、tgbot.js、forward.js、hotlist.js）
- **TTL**: Time To Live，缓存有效期

## Requirements

### Requirement 1: 通用缓存工厂

**User Story:** As a 开发者, I want 使用统一的缓存工厂创建缓存实例, so that 我可以避免在每个页面重复编写相同的缓存逻辑。

#### Acceptance Criteria

1. THE Cache_Factory SHALL 提供 createCache(prefix, options) 函数，返回具有统一接口的缓存实例
2. WHEN 调用 cache.get(key) THEN THE Cache_Factory SHALL 返回缓存数据或 null
3. WHEN 调用 cache.set(key, data, ttl) THEN THE Cache_Factory SHALL 将数据存储到 localStorage
4. WHEN 调用 cache.isValid(key) THEN THE Cache_Factory SHALL 返回缓存是否在 TTL 内有效
5. WHEN 调用 cache.invalidate(key) THEN THE Cache_Factory SHALL 从 localStorage 移除指定缓存
6. WHEN 调用 cache.getStale(key) THEN THE Cache_Factory SHALL 返回缓存数据（忽略 TTL）
7. WHEN 调用 cache.getAge(key) THEN THE Cache_Factory SHALL 返回缓存年龄（毫秒）
8. WHEN 调用 cache.formatAge(key) THEN THE Cache_Factory SHALL 返回人类可读的时间格式
9. WHEN 调用 cache.clearAll() THEN THE Cache_Factory SHALL 清除该实例的所有缓存键
10. IF localStorage 操作失败 THEN THE Cache_Factory SHALL 捕获异常并返回安全默认值

### Requirement 2: 活动日志工厂

**User Story:** As a 开发者, I want 使用统一的活动日志工厂创建日志实例, so that 我可以在不同页面复用相同的日志功能。

#### Acceptance Criteria

1. THE Activity_Logger SHALL 提供 createActivityLog(cacheKey, containerId, options) 函数
2. WHEN 调用 logger.add(msg) THEN THE Activity_Logger SHALL 添加带时间戳的日志条目
3. WHEN 日志条目超过 MAX_ENTRIES THEN THE Activity_Logger SHALL 自动移除最旧的条目
4. WHEN 调用 logger.getAll() THEN THE Activity_Logger SHALL 返回所有日志条目数组
5. WHEN 调用 logger.render() THEN THE Activity_Logger SHALL 将日志渲染到指定 DOM 容器
6. WHEN 调用 logger.init() THEN THE Activity_Logger SHALL 从 localStorage 恢复并渲染日志
7. WHEN 日志为空 THEN THE Activity_Logger SHALL 显示"暂无活动记录"占位符
8. IF DOM 容器不存在 THEN THE Activity_Logger SHALL 静默跳过渲染

### Requirement 3: 表单辅助函数模块

**User Story:** As a 开发者, I want 使用统一的表单辅助函数, so that 我可以简化表单值的读写操作。

#### Acceptance Criteria

1. THE Form_Helper SHALL 提供 setInputValue(id, value) 函数设置输入框值
2. THE Form_Helper SHALL 提供 getInputValue(id) 函数获取输入框值（自动 trim）
3. THE Form_Helper SHALL 提供 setCheckbox(id, checked) 函数设置复选框状态
4. THE Form_Helper SHALL 提供 getCheckbox(id) 函数获取复选框状态
5. THE Form_Helper SHALL 提供 getNumberValue(id, defaultVal) 函数获取数字值
6. THE Form_Helper SHALL 提供 setSelectValue(id, value) 函数设置下拉框值
7. IF 元素不存在 THEN THE Form_Helper SHALL 返回安全默认值而非抛出异常

### Requirement 4: 操作反馈辅助函数

**User Story:** As a 开发者, I want 使用统一的操作反馈函数, so that 我可以简化异步操作的 UI 状态管理。

#### Acceptance Criteria

1. THE Mutation_Feedback SHALL 提供 withMutationFeedback(btn, loadingKey, asyncFn, successMsg, errorPrefix) 函数
2. WHEN 操作开始 THEN THE Mutation_Feedback SHALL 禁用按钮并显示 loading 状态
3. WHEN 操作成功 THEN THE Mutation_Feedback SHALL 显示成功 toast 并返回结果
4. WHEN 操作失败 THEN THE Mutation_Feedback SHALL 显示错误 toast 并返回结果
5. WHEN 操作完成 THEN THE Mutation_Feedback SHALL 恢复按钮原始状态
6. IF 网络错误 THEN THE Mutation_Feedback SHALL 显示"网络错误"提示

### Requirement 5: 工具函数模块

**User Story:** As a 开发者, I want 使用统一的工具函数, so that 我可以避免在每个页面重复定义相同的工具函数。

#### Acceptance Criteria

1. THE common.js SHALL 提供 escapeHtml(str) 函数进行 HTML 转义
2. THE common.js SHALL 提供 togglePassword(inputId) 函数切换密码可见性
3. THE common.js SHALL 提供 generateToken(inputId, length) 函数生成随机令牌
4. THE common.js SHALL 提供 updateOfflineIndicator() 函数更新离线状态指示器
5. IF showToast 未定义 THEN THE Page_Module SHALL 使用 common.js 提供的默认实现

### Requirement 6: 配置导入导出模块

**User Story:** As a 开发者, I want 使用统一的配置导入导出函数, so that 我可以在不同页面复用相同的导入导出逻辑。

#### Acceptance Criteria

1. THE Config_IO SHALL 提供 createConfigIO(collectFn, fillFn, filename) 工厂函数
2. WHEN 调用 io.export() THEN THE Config_IO SHALL 将配置导出为 JSON 文件
3. WHEN 调用 io.import() THEN THE Config_IO SHALL 从 JSON 文件导入配置并填充表单
4. IF 导入文件格式错误 THEN THE Config_IO SHALL 显示错误提示
5. WHEN 导入成功 THEN THE Config_IO SHALL 显示"配置已导入，请检查后保存"提示

### Requirement 7: 向后兼容性

**User Story:** As a 开发者, I want 重构后的代码保持向后兼容, so that 现有页面无需修改 HTML 模板。

#### Acceptance Criteria

1. THE Page_Module SHALL 保留原有模块名作为别名（如 SettingsCache = createCache('settings')）
2. THE Page_Module SHALL 保留原有函数签名和行为
3. WHEN 页面加载 THEN THE Page_Module SHALL 在公共模块之后加载
4. THE Page_Module SHALL 仅保留业务逻辑代码，移除重复的通用代码

### Requirement 8: 代码组织结构

**User Story:** As a 开发者, I want 公共模块按功能分离到独立文件, so that 我可以按需加载和维护。

#### Acceptance Criteria

1. THE 项目 SHALL 创建 common-cache.js 文件包含缓存工厂
2. THE 项目 SHALL 创建 common-activity.js 文件包含活动日志工厂
3. THE 项目 SHALL 创建 common-form.js 文件包含表单辅助函数和操作反馈函数
4. THE common.js SHALL 扩展包含 escapeHtml、togglePassword、generateToken 等工具函数
5. WHEN HTML 页面加载 THEN THE 公共模块 SHALL 在页面 JS 之前加载

