# Implementation Plan: Frontend Common Modules

## Overview

本实现计划将前端重复代码重构为通用公共模块。采用增量方式，先创建公共模块，再逐步精简各页面 JS 文件，最后添加测试。

## Tasks

- [x] 1. 创建缓存工厂模块 (common-cache.js)
  - [x] 1.1 创建 `static/js/common-cache.js` 文件
    - 实现 createCache(prefix, options) 工厂函数
    - 实现 get、set、isValid、invalidate、getStale、getAge、formatAge、clearAll 方法
    - 添加 localStorage 异常处理
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 1.6, 1.7, 1.8, 1.9, 1.10_

  - [x] 1.2 编写缓存模块属性测试
    - **Property 1: Cache Round-Trip Consistency**
    - **Property 2: Cache TTL Validation**
    - **Property 3: Cache Invalidation**
    - **Property 13: Cache Error Handling**
    - **Validates: Requirements 1.2, 1.3, 1.4, 1.5, 1.6, 1.10**

- [x] 2. 创建活动日志模块 (common-activity.js)
  - [x] 2.1 创建 `static/js/common-activity.js` 文件
    - 实现 createActivityLog(cacheKey, containerId, options) 工厂函数
    - 实现 add、getAll、save、render、init 方法
    - 添加 DOM 容器不存在时的容错处理
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8_

  - [x] 2.2 编写活动日志模块属性测试
    - **Property 4: Activity Log Entry Limit**
    - **Property 5: Activity Log Round-Trip**
    - **Validates: Requirements 2.2, 2.3, 2.4**

- [x] 3. 创建表单辅助模块 (common-form.js)
  - [x] 3.1 创建 `static/js/common-form.js` 文件
    - 实现 setInputValue、getInputValue、setCheckbox、getCheckbox、getNumberValue、setSelectValue 函数
    - 实现 withMutationFeedback 操作反馈函数
    - 实现 createConfigIO 配置导入导出工厂
    - 添加元素不存在时的安全默认值处理
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6, 3.7, 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 6.1, 6.2, 6.3, 6.4, 6.5_

  - [x] 3.2 编写表单辅助模块属性测试
    - **Property 6: Form Value Round-Trip**
    - **Property 7: Checkbox State Round-Trip**
    - **Property 10: Mutation Feedback State Management**
    - **Property 11: Config Export-Import Round-Trip**
    - **Property 12: Safe Default on Missing Element**
    - **Validates: Requirements 3.1, 3.2, 3.3, 3.4, 3.7, 4.2, 4.5, 6.2, 6.3**

- [x] 4. 扩展 common.js 工具函数
  - [x] 4.1 扩展 `static/js/common.js` 文件
    - 确保 escapeHtml 函数存在且正确实现
    - 确保 togglePassword 函数存在
    - 确保 generateToken 函数存在
    - 添加 updateOfflineIndicator 函数
    - 添加 showToast 兜底实现
    - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5_

  - [x] 4.2 编写工具函数属性测试
    - **Property 8: HTML Escape Correctness**
    - **Property 9: Token Generation Length**
    - **Validates: Requirements 5.1, 5.3**

- [x] 5. Checkpoint - 验证公共模块
  - 确保所有公共模块文件已创建
  - 确保所有测试通过
  - 询问用户是否有问题

- [x] 6. 重构 settings.js
  - [x] 6.1 重构 `static/js/settings.js`
    - 移除 SettingsCache 模块定义，改用 createCache('settings', {...})
    - 移除 ActivityLog 模块定义，改用 createActivityLog(...)
    - 移除重复的表单辅助函数
    - 移除重复的工具函数
    - 保留 SettingsCache 和 ActivityLog 作为别名
    - 保留 SettingsAPI 和业务逻辑代码
    - _Requirements: 7.1, 7.2, 7.4_

- [x] 7. 重构 tgbot.js
  - [x] 7.1 重构 `static/js/tgbot.js`
    - 移除 TgBotCache 模块定义，改用 createCache('tgbot', {...})
    - 移除 ActivityLog 模块定义，改用 createActivityLog(...)
    - 移除重复的表单辅助函数
    - 移除重复的工具函数
    - 保留 TgBotCache 和 ActivityLog 作为别名
    - 保留 TgBotAPI 和业务逻辑代码
    - _Requirements: 7.1, 7.2, 7.4_

- [x] 8. 重构 forward.js
  - [x] 8.1 重构 `static/js/forward.js`
    - 移除 ForwardCache 模块定义，改用 createCache('forward', {...})
    - 移除重复的活动日志函数（addActivity、renderActivities 等）
    - 移除重复的表单辅助函数
    - 移除重复的工具函数
    - 保留 ForwardCache 作为别名
    - 保留 ForwardAPI 和业务逻辑代码
    - _Requirements: 7.1, 7.2, 7.4_

- [x] 9. 重构 hotlist.js
  - [x] 9.1 重构 `static/js/hotlist.js`
    - 移除 HotlistCache 模块定义，改用 createCache('hotlist', {...})
    - 移除重复的工具函数（escapeHtml、showToast）
    - 保留 HotlistCache 作为别名
    - 保留 HotlistAPI 和业务逻辑代码
    - _Requirements: 7.1, 7.2, 7.4_

- [x] 10. 更新 HTML 模板加载顺序
  - [x] 10.1 更新 HTML 模板文件
    - 在各页面 JS 之前添加公共模块引用
    - 加载顺序：common.js → common-cache.js → common-activity.js → common-form.js → 页面 JS
    - _Requirements: 7.3, 8.5_

- [x] 11. Checkpoint - 验证重构结果
  - 确保所有页面功能正常
  - 确保向后兼容性（原有模块名仍可用）
  - 确保所有测试通过
  - 询问用户是否有问题

- [x] 12. Final checkpoint - 完成验收
  - 确保所有测试通过
  - 验证代码量减少约 40%
  - 询问用户是否有问题

## Notes

- 所有任务均为必需，包括测试任务
- 每个任务引用具体需求以确保可追溯性
- Checkpoint 任务用于增量验证
- 属性测试验证通用正确性属性
- 单元测试验证具体示例和边界情况

