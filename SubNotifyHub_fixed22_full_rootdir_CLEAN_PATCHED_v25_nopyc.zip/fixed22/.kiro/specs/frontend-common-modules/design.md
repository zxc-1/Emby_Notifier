# Design Document: Frontend Common Modules

## Overview

本设计文档描述前端公共模块重构的技术方案。通过工厂模式将 4 个页面 JS 文件中的重复代码抽取为通用公共模块，实现代码复用、减少维护成本。

### 设计目标

1. **消除代码重复** - 将缓存、日志、表单辅助等通用功能抽取为公共模块
2. **保持向后兼容** - 现有页面 HTML 无需修改，保留原有模块名作为别名
3. **减少代码量** - 预计减少约 40% 的重复代码
4. **提高可维护性** - 统一接口，集中维护

### 文件结构

```
static/js/
├── common.js              # 现有，扩展工具函数
├── common-cache.js        # 新建，通用缓存工厂
├── common-activity.js     # 新建，活动日志模块
├── common-form.js         # 新建，表单辅助函数
├── settings.js            # 精简，只保留业务逻辑
├── tgbot.js               # 精简
├── forward.js             # 精简
└── hotlist.js             # 精简
```

## Architecture

```mermaid
graph TB
    subgraph "公共模块层"
        CC[common-cache.js<br/>缓存工厂]
        CA[common-activity.js<br/>活动日志]
        CF[common-form.js<br/>表单辅助]
        CJ[common.js<br/>工具函数]
    end
    
    subgraph "页面模块层"
        S[settings.js]
        T[tgbot.js]
        F[forward.js]
        H[hotlist.js]
    end
    
    subgraph "HTML 页面"
        SP[admin_settings.html]
        TP[admin_tgbot.html]
        FP[admin_forward.html]
        HP[admin_hotlist.html]
    end
    
    CC --> S
    CC --> T
    CC --> F
    CC --> H
    
    CA --> S
    CA --> T
    CA --> F
    
    CF --> S
    CF --> T
    CF --> F
    
    CJ --> S
    CJ --> T
    CJ --> F
    CJ --> H
    
    S --> SP
    T --> TP
    F --> FP
    H --> HP
```

## Components and Interfaces

### 1. Cache Factory (common-cache.js)

缓存工厂模块，提供统一的 localStorage 缓存接口。

```javascript
/**
 * 创建缓存实例
 * @param {string} prefix - 缓存键前缀，如 'settings', 'tgbot'
 * @param {Object} options - 配置选项
 * @param {Object} options.keys - 缓存键映射 {CONFIG: 'config', STATUS: 'status'}
 * @param {Object} options.ttls - TTL 映射 {CONFIG: 120000, STATUS: 30000}
 * @returns {CacheInstance} 缓存实例
 */
function createCache(prefix, options = {}) {
    const { keys = {}, ttls = {} } = options;
    
    // 生成完整缓存键
    const getFullKey = (key) => `snh_${prefix}_${key}_cache`;
    
    return {
        // 获取缓存数据
        get(key) { /* ... */ },
        
        // 设置缓存数据
        set(key, data, ttl) { /* ... */ },
        
        // 检查缓存是否有效
        isValid(key) { /* ... */ },
        
        // 清除指定缓存
        invalidate(key) { /* ... */ },
        
        // 获取过期数据（stale-while-revalidate）
        getStale(key) { /* ... */ },
        
        // 获取缓存年龄（毫秒）
        getAge(key) { /* ... */ },
        
        // 格式化缓存时间
        formatAge(key) { /* ... */ },
        
        // 清除所有缓存
        clearAll() { /* ... */ },
        
        // 预定义键的快捷访问
        CONFIG_KEY: getFullKey(keys.CONFIG || 'config'),
        STATUS_KEY: getFullKey(keys.STATUS || 'status'),
        ACTIVITY_KEY: getFullKey(keys.ACTIVITY || 'activity_log'),
        CONFIG_TTL: ttls.CONFIG || 2 * 60 * 1000,
        STATUS_TTL: ttls.STATUS || 30 * 1000
    };
}
```

### 2. Activity Logger (common-activity.js)

活动日志工厂模块，提供页面级活动日志功能。

```javascript
/**
 * 创建活动日志实例
 * @param {string} cacheKey - localStorage 存储键
 * @param {string} containerId - DOM 容器 ID
 * @param {Object} options - 配置选项
 * @param {number} options.maxEntries - 最大条目数，默认 10
 * @returns {ActivityLogInstance} 日志实例
 */
function createActivityLog(cacheKey, containerId, options = {}) {
    const { maxEntries = 10 } = options;
    
    return {
        MAX_ENTRIES: maxEntries,
        
        // 添加日志条目
        add(msg) { /* ... */ },
        
        // 获取所有日志
        getAll() { /* ... */ },
        
        // 保存日志到 localStorage
        save(logs) { /* ... */ },
        
        // 渲染日志到 DOM
        render(logs) { /* ... */ },
        
        // 初始化，从 localStorage 恢复
        init() { /* ... */ }
    };
}
```

### 3. Form Helper (common-form.js)

表单辅助函数模块，提供统一的表单值读写操作。

```javascript
// 设置输入框值
function setInputValue(id, value) {
    const el = document.getElementById(id);
    if (el) el.value = value || '';
}

// 获取输入框值
function getInputValue(id) {
    const el = document.getElementById(id);
    return el ? el.value.trim() : '';
}

// 设置复选框状态
function setCheckbox(id, checked) {
    const el = document.getElementById(id);
    if (el) el.checked = !!checked;
}

// 获取复选框状态
function getCheckbox(id) {
    const el = document.getElementById(id);
    return el ? el.checked : false;
}

// 获取数字值
function getNumberValue(id, defaultVal) {
    const el = document.getElementById(id);
    const val = parseFloat(el?.value);
    return isNaN(val) ? defaultVal : val;
}

// 设置下拉框值
function setSelectValue(id, value) {
    const el = document.getElementById(id);
    if (el) el.value = value || '';
}
```

### 4. Mutation Feedback (common-form.js)

操作反馈辅助函数，处理异步操作的 UI 状态。

```javascript
/**
 * 带反馈的异步操作包装器
 * @param {HTMLElement} btn - 按钮元素
 * @param {string} loadingKey - 状态键（用于防重复提交）
 * @param {Function} asyncFn - 异步操作函数
 * @param {string} successMsg - 成功消息
 * @param {string} errorPrefix - 错误消息前缀
 * @param {Object} state - 状态对象（包含 loading 属性）
 * @returns {Promise<Object>} 操作结果
 */
async function withMutationFeedback(btn, loadingKey, asyncFn, successMsg, errorPrefix, state = {}) {
    if (state.loading?.[loadingKey]) return;
    
    const originalHtml = btn?.innerHTML;
    
    if (state.loading) state.loading[loadingKey] = true;
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<span class="spinner-small"></span> 处理中...';
    }
    
    try {
        const result = await asyncFn();
        if (result.ok) {
            showToast(successMsg, 'success');
            return result;
        } else {
            showToast(`${errorPrefix}: ${result.detail || '未知错误'}`, 'error');
            return result;
        }
    } catch (err) {
        showToast('网络错误，请检查连接', 'error');
        return { ok: false, detail: err.message };
    } finally {
        if (state.loading) state.loading[loadingKey] = false;
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = originalHtml;
        }
    }
}
```

### 5. Config IO (common-form.js)

配置导入导出工厂函数。

```javascript
/**
 * 创建配置导入导出实例
 * @param {Function} collectFn - 收集表单数据的函数
 * @param {Function} fillFn - 填充表单的函数
 * @param {string} filename - 导出文件名
 * @param {Object} options - 配置选项
 * @returns {ConfigIOInstance} 导入导出实例
 */
function createConfigIO(collectFn, fillFn, filename, options = {}) {
    const { onExport, onImport } = options;
    
    return {
        // 导出配置
        export() {
            const config = collectFn();
            const blob = new Blob([JSON.stringify(config, null, 2)], { type: 'application/json' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = filename;
            a.click();
            URL.revokeObjectURL(url);
            showToast('配置已导出', 'success');
            if (onExport) onExport();
        },
        
        // 导入配置
        import() {
            const input = document.createElement('input');
            input.type = 'file';
            input.accept = '.json';
            input.onchange = async (e) => {
                const file = e.target.files[0];
                if (!file) return;
                
                try {
                    const text = await file.text();
                    const config = JSON.parse(text);
                    fillFn(config);
                    showToast('配置已导入，请检查后保存', 'success');
                    if (onImport) onImport();
                } catch (err) {
                    showToast('导入失败：文件格式错误', 'error');
                }
            };
            input.click();
        }
    };
}
```

### 6. Utility Functions (common.js 扩展)

工具函数扩展，确保所有页面可用。

```javascript
// HTML 转义（如果未定义）
if (typeof escapeHtml !== 'function') {
    window.escapeHtml = function(str) {
        if (!str) return '';
        return String(str)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;');
    };
}

// 密码显示切换（如果未定义）
if (typeof togglePassword !== 'function') {
    window.togglePassword = function(inputId) {
        const input = document.getElementById(inputId);
        if (!input) return;
        input.type = input.type === 'password' ? 'text' : 'password';
    };
}

// 生成随机令牌（如果未定义）
if (typeof generateToken !== 'function') {
    window.generateToken = function(inputId, length = 32) {
        const input = document.getElementById(inputId);
        if (!input) return;
        
        const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
        let token = '';
        for (let i = 0; i < length; i++) {
            token += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        input.value = token;
        input.type = 'text';
        showToast('已生成随机令牌', 'success');
    };
}

// 离线指示器更新
function updateOfflineIndicator() {
    let indicator = document.getElementById('offlineIndicator');
    const isOnline = navigator.onLine;
    
    if (!isOnline) {
        if (!indicator) {
            indicator = document.createElement('div');
            indicator.id = 'offlineIndicator';
            indicator.className = 'offline-indicator';
            indicator.innerHTML = '<span>📡 离线模式 - 显示缓存数据</span>';
            document.body.appendChild(indicator);
        }
        indicator.style.display = 'flex';
    } else if (indicator) {
        indicator.style.display = 'none';
    }
}
```

## Data Models

### CacheEntry

localStorage 中存储的缓存条目结构：

```javascript
{
    data: Object,      // 缓存的数据
    timestamp: number, // 缓存时间戳（毫秒）
    ttl: number        // TTL（毫秒）
}
```

### ActivityLogEntry

活动日志条目结构：

```javascript
{
    time: string,  // 格式化时间，如 "14:30"
    msg: string    // 日志消息
}
```

### CacheInstance

缓存实例接口：

```javascript
{
    get(key: string): CacheEntry | null,
    set(key: string, data: Object, ttl: number): void,
    isValid(key: string): boolean,
    invalidate(key: string): void,
    getStale(key: string): Object | null,
    getAge(key: string): number,
    formatAge(key: string): string,
    clearAll(): void,
    CONFIG_KEY: string,
    STATUS_KEY: string,
    ACTIVITY_KEY: string,
    CONFIG_TTL: number,
    STATUS_TTL: number
}
```

### ActivityLogInstance

活动日志实例接口：

```javascript
{
    MAX_ENTRIES: number,
    add(msg: string): void,
    getAll(): ActivityLogEntry[],
    save(logs: ActivityLogEntry[]): void,
    render(logs?: ActivityLogEntry[]): void,
    init(): void
}
```



## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Cache Round-Trip Consistency

*For any* cache instance, prefix, key, and valid data object, calling `set(key, data, ttl)` followed by `get(key)` SHALL return an object containing the original data.

**Validates: Requirements 1.2, 1.3**

### Property 2: Cache TTL Validation

*For any* cache instance and key with expired TTL (age > ttl), calling `isValid(key)` SHALL return `false`, while `getStale(key)` SHALL still return the cached data.

**Validates: Requirements 1.4, 1.6**

### Property 3: Cache Invalidation

*For any* cache instance and key, calling `invalidate(key)` SHALL result in subsequent `get(key)` returning `null`.

**Validates: Requirements 1.5**

### Property 4: Activity Log Entry Limit

*For any* activity log instance with MAX_ENTRIES = N, after adding M entries where M > N, calling `getAll()` SHALL return an array with exactly N entries (the most recent ones).

**Validates: Requirements 2.3**

### Property 5: Activity Log Round-Trip

*For any* activity log instance and message string, calling `add(msg)` followed by `getAll()` SHALL return an array where the first entry contains the original message.

**Validates: Requirements 2.2, 2.4**

### Property 6: Form Value Round-Trip

*For any* input element ID and string value, calling `setInputValue(id, value)` followed by `getInputValue(id)` SHALL return the trimmed original value.

**Validates: Requirements 3.1, 3.2**

### Property 7: Checkbox State Round-Trip

*For any* checkbox element ID and boolean value, calling `setCheckbox(id, checked)` followed by `getCheckbox(id)` SHALL return the original boolean value.

**Validates: Requirements 3.3, 3.4**

### Property 8: HTML Escape Correctness

*For any* string containing HTML special characters (`<`, `>`, `&`, `"`), calling `escapeHtml(str)` SHALL return a string where all special characters are replaced with their HTML entities, and the result SHALL NOT contain any unescaped special characters.

**Validates: Requirements 5.1**

### Property 9: Token Generation Length

*For any* positive integer length, calling `generateToken(inputId, length)` SHALL set the input value to a string of exactly that length, containing only alphanumeric characters.

**Validates: Requirements 5.3**

### Property 10: Mutation Feedback State Management

*For any* button element and async function, calling `withMutationFeedback()` SHALL:
- Disable the button during operation
- Restore the button's original HTML after operation completes (success or failure)

**Validates: Requirements 4.2, 4.5**

### Property 11: Config Export-Import Round-Trip

*For any* valid configuration object, exporting via `io.export()` and importing via `io.import()` SHALL result in the form being filled with equivalent values.

**Validates: Requirements 6.2, 6.3**

### Property 12: Safe Default on Missing Element

*For any* non-existent element ID, all Form_Helper functions SHALL return safe default values (empty string, false, or defaultVal) without throwing exceptions.

**Validates: Requirements 3.7**

### Property 13: Cache Error Handling

*For any* localStorage operation that throws an exception, Cache_Factory methods SHALL catch the exception and return safe default values (null, false, Infinity, or '未知').

**Validates: Requirements 1.10**

## Error Handling

### localStorage 异常处理

所有 localStorage 操作都应包装在 try-catch 中：

```javascript
try {
    localStorage.setItem(key, JSON.stringify(item));
} catch (e) {
    console.warn('Cache.set failed:', e);
    // 静默失败，不影响页面功能
}
```

常见异常场景：
- 存储配额超限（QuotaExceededError）
- 隐私模式下 localStorage 不可用
- 数据序列化失败

### DOM 元素不存在处理

所有 DOM 操作都应检查元素存在性：

```javascript
function setInputValue(id, value) {
    const el = document.getElementById(id);
    if (el) el.value = value || '';
    // 元素不存在时静默跳过
}
```

### 网络请求异常处理

异步操作应捕获网络异常：

```javascript
try {
    const result = await asyncFn();
    // 处理结果
} catch (err) {
    showToast('网络错误，请检查连接', 'error');
    return { ok: false, detail: err.message };
}
```

### JSON 解析异常处理

配置导入应处理无效 JSON：

```javascript
try {
    const config = JSON.parse(text);
    fillFn(config);
} catch (err) {
    showToast('导入失败：文件格式错误', 'error');
}
```

## Testing Strategy

### 测试方法

本项目采用双重测试策略：

1. **单元测试** - 验证具体示例和边界情况
2. **属性测试** - 验证跨所有输入的通用属性

### 测试框架

- **单元测试**: Jest
- **属性测试**: fast-check (JavaScript PBT 库)
- **DOM 模拟**: jsdom

### 属性测试配置

```javascript
// 每个属性测试至少运行 100 次迭代
fc.assert(
    fc.property(
        fc.string(),
        (input) => {
            // 属性断言
        }
    ),
    { numRuns: 100 }
);
```

### 测试标签格式

每个属性测试必须包含注释引用设计文档属性：

```javascript
// Feature: frontend-common-modules, Property 1: Cache Round-Trip Consistency
// Validates: Requirements 1.2, 1.3
test('cache set then get returns same data', () => {
    fc.assert(
        fc.property(
            fc.string(),
            fc.jsonValue(),
            (key, data) => {
                cache.set(key, data, 60000);
                const result = cache.get(key);
                return deepEqual(result.data, data);
            }
        ),
        { numRuns: 100 }
    );
});
```

### 测试覆盖范围

| 模块 | 单元测试 | 属性测试 |
|------|---------|---------|
| common-cache.js | 边界情况、异常处理 | Property 1-3, 13 |
| common-activity.js | 空状态、DOM 渲染 | Property 4-5 |
| common-form.js | 元素不存在处理 | Property 6-7, 10, 12 |
| common.js | 特殊字符转义 | Property 8-9 |
| Config IO | 文件格式错误 | Property 11 |

### 测试文件结构

```
tests/
├── unit/
│   ├── common-cache.test.js
│   ├── common-activity.test.js
│   ├── common-form.test.js
│   └── common.test.js
└── property/
    ├── cache.property.test.js
    ├── activity.property.test.js
    ├── form.property.test.js
    └── config-io.property.test.js
```

