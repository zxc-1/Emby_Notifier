# Requirements Document

## Introduction

清理项目中的废弃代码和兼容层。这些代码在模块重构后保留用于向后兼容，但现在已无实际使用，应当移除以减少代码复杂度和维护负担。

## Glossary

- **Compat_Layer**: 兼容层，位于 `compat/` 目录，提供旧导入路径的重定向
- **Shim_Module**: 垫片模块，位于 `tg_bot/` 根目录，重定向到新的子模块
- **Deprecation_Warning**: 废弃警告，导入时发出的警告信息
- **Test_Contract**: 测试契约，验证废弃模块行为的测试文件

## Requirements

### Requirement 1: 移除 compat 兼容层

**User Story:** As a developer, I want to remove the compat compatibility layer, so that the codebase is cleaner and easier to maintain.

#### Acceptance Criteria

1. THE system SHALL remove all files in the `compat/` directory
2. THE system SHALL remove the `compat/` directory itself
3. THE system SHALL update any imports that reference `compat.*` modules
4. WHEN the cleanup is complete, THE codebase SHALL NOT contain any `compat` imports

### Requirement 2: 移除 tg_bot 垫片模块

**User Story:** As a developer, I want to remove deprecated shim modules in tg_bot, so that the module structure is cleaner.

#### Acceptance Criteria

1. THE system SHALL remove `tg_bot/telegram_api.py` (shim to `tg_bot.infra.telegram_api`)
2. THE system SHALL remove `tg_bot/polling.py` (shim to `tg_bot.infra.polling`)
3. THE system SHALL remove `tg_bot/patterns.py` (shim to `tg_bot.common.patterns`)
4. THE system SHALL remove `tg_bot/service.py` (shim to `tg_bot.app.dispatcher`)
5. THE system SHALL remove `tg_bot/account_flow.py` (shim to `tg_bot.features.account`)
6. THE system SHALL remove `tg_bot/cloud115_flow_core.py` (shim to `tg_bot.features.cloud115`)
7. THE system SHALL remove `tg_bot/http_other_flow.py` (shim to `tg_bot.features.http_other`)
8. THE system SHALL remove `tg_bot/mediahelp_flow.py` (shim to `tg_bot.features.mediahelp`)
9. THE system SHALL remove `tg_bot/share_flow.py` (shim to `tg_bot.features.share`)

### Requirement 3: 更新相关测试

**User Story:** As a developer, I want tests to be updated after removing deprecated code, so that the test suite remains valid.

#### Acceptance Criteria

1. THE system SHALL remove or update tests that specifically test deprecated import warnings
2. THE system SHALL remove `tests/contract/test_compat_deprecation_warnings.py`
3. THE system SHALL update `tests/contract/test_no_deprecated_imports.py` to remove compat references
4. WHEN all tests are run, THE test suite SHALL pass without errors

### Requirement 4: 更新检查工具

**User Story:** As a developer, I want code checking tools to be updated, so that they don't reference removed modules.

#### Acceptance Criteria

1. THE system SHALL update `tools/check_layering.py` to remove compat-related checks
2. THE system SHALL update any other tools that reference deprecated modules
3. WHEN the tools are run, THE tools SHALL execute without errors

### Requirement 5: 清理文档引用

**User Story:** As a developer, I want documentation to be updated, so that it doesn't reference removed modules.

#### Acceptance Criteria

1. THE system SHALL update `docs/MODULE_STRUCTURE.md` to remove deprecated module references
2. THE system SHALL update any other documentation that references deprecated modules
3. WHEN the documentation is reviewed, THE documentation SHALL NOT reference removed modules

