# Design Document: Deprecated Code Cleanup

## Overview

本设计移除项目中不再使用的废弃代码和兼容层，包括 `compat/` 目录和 `tg_bot/` 中的垫片模块。这些代码在模块重构后保留用于向后兼容，但经过分析已无实际使用。

## Architecture

```
清理前:
├── compat/                          # 待删除
│   ├── __init__.py
│   ├── bootstrap_app_factory.py
│   ├── bootstrap_lifespan.py
│   ├── bootstrap_preflight.py
│   ├── bootstrap_wiring.py
│   ├── notifier_telegram.py
│   └── settings_all.py
├── tg_bot/
│   ├── telegram_api.py              # 待删除 (shim)
│   ├── polling.py                   # 待删除 (shim)
│   ├── patterns.py                  # 待删除 (shim)
│   ├── service.py                   # 待删除 (shim)
│   ├── account_flow.py              # 待删除 (shim)
│   ├── cloud115_flow_core.py        # 待删除 (shim)
│   ├── http_other_flow.py           # 待删除 (shim)
│   ├── mediahelp_flow.py            # 待删除 (shim)
│   └── share_flow.py                # 待删除 (shim)

清理后:
├── tg_bot/
│   ├── app/                         # 保留 - 实际实现
│   ├── common/                      # 保留 - 实际实现
│   ├── features/                    # 保留 - 实际实现
│   ├── infra/                       # 保留 - 实际实现
│   └── ...
```

## Components and Interfaces

### 1. 待删除的 compat 文件

| 文件 | 重定向目标 | 状态 |
|------|-----------|------|
| `compat/bootstrap_app_factory.py` | `bootstrap.bootstrap_app_factory` | 无使用 |
| `compat/bootstrap_lifespan.py` | `bootstrap.bootstrap_lifespan` | 无使用 |
| `compat/bootstrap_preflight.py` | `bootstrap.bootstrap_preflight` | 无使用 |
| `compat/bootstrap_wiring.py` | `bootstrap.bootstrap_wiring` | 无使用 |
| `compat/notifier_telegram.py` | `notifier.telegram` | 无使用 |
| `compat/settings_all.py` | `settings.all` | 无使用 |

### 2. 待删除的 tg_bot 垫片文件

| 文件 | 重定向目标 | 状态 |
|------|-----------|------|
| `tg_bot/telegram_api.py` | `tg_bot.infra.telegram_api` | 无使用 |
| `tg_bot/polling.py` | `tg_bot.infra.polling` | 无使用 |
| `tg_bot/patterns.py` | `tg_bot.common.patterns` | 无使用 |
| `tg_bot/service.py` | `tg_bot.app.dispatcher` | 无使用 |
| `tg_bot/account_flow.py` | `tg_bot.features.account` | 无使用 |
| `tg_bot/cloud115_flow_core.py` | `tg_bot.features.cloud115` | 无使用 |
| `tg_bot/http_other_flow.py` | `tg_bot.features.http_other` | 无使用 |
| `tg_bot/mediahelp_flow.py` | `tg_bot.features.mediahelp` | 无使用 |
| `tg_bot/share_flow.py` | `tg_bot.features.share` | 无使用 |

### 3. 待更新的测试文件

| 文件 | 操作 |
|------|------|
| `tests/contract/test_compat_deprecation_warnings.py` | 删除 |
| `tests/contract/test_no_deprecated_imports.py` | 更新，移除 compat 相关 |
| `tests/contract/test_config_deprecation_warnings.py` | 保留（测试 notifier.config 废弃） |

### 4. 待更新的工具文件

| 文件 | 操作 |
|------|------|
| `tools/check_layering.py` | 移除 compat 相关检查 |

### 5. 待更新的文档

| 文件 | 操作 |
|------|------|
| `docs/MODULE_STRUCTURE.md` | 移除废弃模块引用 |

## Data Models

本设计不涉及数据模型变更。

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

由于这是代码清理任务，主要涉及文件删除和更新操作，所有验收标准通过示例验证而非属性测试。

### 验证方法

1. **文件存在性检查**
   - 验证 `compat/` 目录不存在
   - 验证垫片文件不存在

2. **导入搜索验证**
   - 搜索代码库确认无 `from compat.` 或 `import compat.` 导入
   - 搜索代码库确认无废弃垫片模块导入

3. **测试套件验证**
   - 运行完整测试套件确认通过

## Error Handling

### 删除前检查

1. **使用检查**：删除前确认模块无实际使用
2. **备份建议**：建议用户在删除前提交当前代码

### 回滚策略

如果删除后发现问题：
1. 使用 Git 恢复删除的文件
2. 检查是否有遗漏的导入更新

## Testing Strategy

### 验证步骤

1. **删除前**
   ```bash
   # 搜索 compat 导入
   grep -r "from compat\." --include="*.py" .
   grep -r "import compat\." --include="*.py" .
   
   # 搜索废弃垫片导入
   grep -r "from tg_bot\.telegram_api" --include="*.py" .
   grep -r "from tg_bot\.polling" --include="*.py" .
   ```

2. **删除后**
   ```bash
   # 运行测试套件
   python -m pytest tests/ -v
   
   # 运行检查工具
   python -m tools.check_layering
   ```

3. **最终验证**
   ```bash
   # 确认目录已删除
   ls compat/  # 应报错：目录不存在
   
   # 确认文件已删除
   ls tg_bot/telegram_api.py  # 应报错：文件不存在
   ```

