# Implementation Plan: Deprecated Code Cleanup

## Overview

移除项目中不再使用的废弃代码和兼容层，减少代码复杂度。

## Tasks

- [x] 1. 删除 compat 兼容层
  - [x] 1.1 删除 `compat/bootstrap_app_factory.py`
  - [x] 1.2 删除 `compat/bootstrap_lifespan.py`
  - [x] 1.3 删除 `compat/bootstrap_preflight.py`
  - [x] 1.4 删除 `compat/bootstrap_wiring.py`
  - [x] 1.5 删除 `compat/notifier_telegram.py`
  - [x] 1.6 删除 `compat/settings_all.py`
  - [x] 1.7 删除 `compat/__init__.py` 和目录
  - _Requirements: 1.1, 1.2_

- [x] 2. 删除 tg_bot 垫片模块
  - [x] 2.1 删除 `tg_bot/telegram_api.py`
  - [x] 2.2 删除 `tg_bot/polling.py`
  - [x] 2.3 删除 `tg_bot/patterns.py`
  - [x] 2.4 删除 `tg_bot/service.py`
  - [x] 2.5 删除 `tg_bot/account_flow.py`
  - [x] 2.6 删除 `tg_bot/cloud115_flow_core.py`
  - [x] 2.7 删除 `tg_bot/http_other_flow.py`
  - [x] 2.8 删除 `tg_bot/mediahelp_flow.py`
  - [x] 2.9 删除 `tg_bot/share_flow.py`
  - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9_

- [x] 3. 更新测试文件
  - [x] 3.1 删除 `tests/contract/test_compat_deprecation_warnings.py`
  - [x] 3.2 更新 `tests/contract/test_no_deprecated_imports.py`
    - 移除 compat 相关的排除路径和检查模式
  - _Requirements: 3.1, 3.2, 3.3_

- [x] 4. 更新检查工具
  - 更新 `tools/check_layering.py`
  - 移除 compat 相关的检查逻辑
  - _Requirements: 4.1, 4.2_

- [x] 5. 更新文档
  - 更新 `docs/MODULE_STRUCTURE.md`
  - 移除废弃模块的引用
  - _Requirements: 5.1, 5.2_

- [x] 6. 验证清理结果
  - 搜索确认无废弃导入
  - 运行测试套件
  - 运行检查工具
  - _Requirements: 1.3, 1.4, 3.4, 4.3_

## Notes

- 所有任务都是必需的
- 删除前已确认无实际使用
- 如有问题可通过 Git 恢复

