# Design Document: Full Data Integration

## Overview

本设计文档描述了将所有 Admin 页面底层服务对接到真实数据的技术方案。系统采用分层架构，前端通过 RESTful API 与后端服务交互，后端服务负责与各外部系统（Emby、115 云盘、MediaHelp、Telegram）通信。

### 设计目标

1. **统一 API 响应格式** - 所有 API 返回标准化的 JSON 响应
2. **服务状态实时检测** - 提供各服务的连接状态检测能力
3. **配置热重载** - 支持配置修改后立即生效
4. **错误处理与回滚** - 配置保存失败时自动回滚
5. **渐进式数据加载** - 支持 SSE 实时推送扫描进度

## Architecture

```mermaid
graph TB
    subgraph Frontend["前端层"]
        Dashboard[仪表盘页面]
        Settings[设置页面]
        Hotlist[热榜页面]
        Dedup[媒体管理页面]
        TGBot[TG Bot 页面]
    end

    subgraph API["API 层"]
        DashboardAPI[/api/dashboard/*]
        SettingsAPI[/admin/settings/*]
        HotlistAPI[/admin/hotlist/*]
        DedupAPI[/api/dedup/*]
        Cloud115API[/admin/tg-bot/115/*]
        MediaHelpAPI[/admin/tg-bot/mediahelp/*]
    end

    subgraph Services["服务层"]
        RecentStore[RecentStore]
        HotlistStore[HotlistStore]
        SettingsService[SettingsService]
        DedupService[DedupService]
        Cloud115Client[Cloud115Client]
        MediaHelpClient[MediaHelpClient]
    end

    subgraph External["外部系统"]
        Emby[Emby Server]
        Cloud115[115 云盘]
        MediaHelp[MediaHelp]
        Telegram[Telegram]
        SQLite[(SQLite DB)]
        EnvFile[(.env 文件)]
    end

    Dashboard --> DashboardAPI
    Settings --> SettingsAPI
    Hotlist --> HotlistAPI
    Dedup --> DedupAPI
    TGBot --> Cloud115API
    TGBot --> MediaHelpAPI

    DashboardAPI --> RecentStore
    DashboardAPI --> HotlistStore
    SettingsAPI --> SettingsService
    HotlistAPI --> HotlistStore
    DedupAPI --> DedupService
    Cloud115API --> Cloud115Client
    MediaHelpAPI --> MediaHelpClient

    RecentStore --> SQLite
    HotlistStore --> SQLite
    SettingsService --> EnvFile
    DedupService --> Emby
    DedupService --> Cloud115
    Cloud115Client --> Cloud115
    MediaHelpClient --> MediaHelp
```

## Components and Interfaces

### 1. Dashboard API 组件

负责提供仪表盘所需的统计数据和服务状态。

```python
# 接口定义
class DashboardAPI:
    async def get_stats() -> DashboardStats:
        """获取仪表盘统计数据"""
        pass
    
    async def get_services() -> ServiceStatusList:
        """获取服务连接状态"""
        pass
    
    async def get_hotlist_preview() -> HotlistPreview:
        """获取热榜订阅概览"""
        pass
    
    async def get_chart(range: str) -> ChartData:
        """获取趋势图数据"""
        pass
```

### 2. Settings Service 组件

负责配置的读取、验证、保存和热重载。

```python
class SettingsService:
    async def save_settings(form_data: dict) -> SaveResult:
        """保存设置到 .env 并热重载"""
        pass
    
    async def get_status() -> SettingsStatus:
        """获取配置状态"""
        pass
    
    async def rollback(changed_keys: list, old_env: dict) -> bool:
        """回滚配置到原始状态"""
        pass
```

### 3. Hotlist Service 组件

负责热榜订阅的 CRUD 操作。

```python
class HotlistService:
    async def list_subscriptions(chat_id: int = None) -> list:
        """获取订阅列表"""
        pass
    
    async def add_subscription(chat_id: int, list_key: str, ...) -> bool:
        """添加订阅"""
        pass
    
    async def delete_subscription(chat_id: int, list_key: str) -> bool:
        """删除订阅"""
        pass
    
    async def patch_subscription(chat_id: int, list_key: str, patch: dict) -> bool:
        """更新订阅配置"""
        pass
    
    async def backfill_next(chat_id: int, list_key: str, start: int = None) -> dict:
        """触发回填"""
        pass
```

### 4. Cloud115 Service 组件

负责 115 云盘的连接测试、扫码登录和目录管理。

```python
class Cloud115Service:
    async def test_connection() -> TestResult:
        """测试 Cookie 有效性"""
        pass
    
    async def start_qrcode(app: str) -> QRCodeResult:
        """生成扫码登录二维码"""
        pass
    
    async def poll_qrcode(qid: str, qtoken: str) -> PollResult:
        """轮询扫码状态"""
        pass
    
    async def list_downpath() -> list:
        """获取下载目录列表"""
        pass
```

### 5. MediaHelp Service 组件

负责 MediaHelp 的登录和连接测试。

```python
class MediaHelpService:
    async def login(username: str, password: str) -> LoginResult:
        """登录并获取 Token"""
        pass
    
    async def test_connection() -> TestResult:
        """测试 Token 有效性"""
        pass
```

### 6. Dedup Service 组件

负责媒体去重扫描和清理操作。

```python
class DedupService:
    async def start_scan(options: ScanOptions) -> str:
        """启动扫描任务，返回 task_id"""
        pass
    
    async def get_task_status(task_id: str) -> TaskStatus:
        """获取任务状态"""
        pass
    
    async def cancel_task(task_id: str) -> bool:
        """取消任务"""
        pass
    
    async def get_duplicate_groups(task_id: str = None) -> list:
        """获取重复组列表"""
        pass
    
    async def clean_files(request: CleanRequest) -> CleanResult:
        """执行清理操作"""
        pass
```

## Data Models

### API 响应模型

```python
from dataclasses import dataclass
from typing import Any, Optional
from datetime import datetime

@dataclass
class APIResponse:
    """标准化 API 响应"""
    success: bool
    data: Optional[Any] = None
    error: Optional[dict] = None  # {"code": str, "message": str}
    timestamp: str = None
    
    def __post_init__(self):
        if self.timestamp is None:
            self.timestamp = datetime.now(timezone.utc).isoformat()

@dataclass
class ErrorInfo:
    """错误信息"""
    code: str
    message: str
```

### 仪表盘数据模型

```python
@dataclass
class DashboardStats:
    """仪表盘统计数据"""
    media_total: int
    weekly_additions: int
    hotlist_count: int
    active_lists: int
    pending_count: int

@dataclass
class ServiceStatus:
    """服务状态"""
    status: str  # "online" | "offline"
    detail: str
    mode: Optional[str] = None  # for telegram
    token_age: Optional[int] = None  # for mediahelp

@dataclass
class ChartData:
    """趋势图数据"""
    labels: list[str]
    values: list[int]
    range: str
    total: int
```

### 热榜数据模型

```python
@dataclass
class Subscription:
    """热榜订阅"""
    chat_id: int
    list_key: str
    list_url: str
    list_name: str
    mode: str  # "incremental" | "digest"
    filters: dict
    created_at: datetime
    updated_at: datetime

@dataclass
class SubscriptionSnapshot:
    """订阅快照"""
    list_key: str
    items: list[dict]
    fetched_at: datetime
```

### 去重数据模型

```python
@dataclass
class ScanOptions:
    """扫描选项"""
    target: str  # "115" | "emby" | "all"
    video_only: bool = True
    recursive: bool = True
    path_filter: Optional[str] = None

@dataclass
class TaskStatus:
    """任务状态"""
    task_id: str
    status: str  # "pending" | "running" | "completed" | "failed" | "cancelled"
    progress: float
    scanned_count: int
    total_count: int
    current_path: Optional[str]
    duplicate_groups: int
    duplicate_files: int
    reclaimable_size: int
    error_message: Optional[str]
    started_at: Optional[datetime]
    completed_at: Optional[datetime]

@dataclass
class DuplicateGroup:
    """重复组"""
    group_id: str
    media_title: str
    media_id: str
    media_type: str
    match_type: str
    file_count: int
    total_size: int
    reclaimable_size: int
    recommended_file_id: str
    best_score: float
    worst_score: float
    is_exact_duplicate: bool
    files: list['DuplicateFile']

@dataclass
class CleanRequest:
    """清理请求"""
    file_ids: list[str]
    action: str  # "move" | "trash" | "delete"
    target_dir: Optional[str] = None

@dataclass
class CleanResult:
    """清理结果"""
    success_count: int
    failed_count: int
    released_size: int
    failed_files: list[dict]
```

### 配置状态模型

```python
@dataclass
class SettingsStatus:
    """配置状态"""
    emby_connected: bool
    tmdb_configured: bool
    notifier_ready: bool
    webhook_configured: bool
    cloud115_configured: bool
```



## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: 数据库查询计数一致性

*For any* 数据库状态和查询请求，API 返回的计数值应该与数据库中符合条件的记录数量完全一致。

**Validates: Requirements 1.1, 1.3, 4.1**

### Property 2: 时间范围过滤正确性

*For any* 时间范围参数（7天或30天）和任意数据库状态，返回的记录应该只包含在指定时间范围内创建的记录，且不遗漏任何符合条件的记录。

**Validates: Requirements 1.2, 3.1, 3.2, 12.2, 12.3**

### Property 3: 配置存在性检测

*For any* 配置状态组合，服务状态检测应该正确反映配置是否完整：当且仅当所有必需字段都非空时，状态为 online。

**Validates: Requirements 2.1, 2.2, 2.4, 7.6**

### Property 4: 趋势数据排序

*For any* 趋势数据请求，返回的 labels 数组应该按日期升序排列，且 values 数组与 labels 数组一一对应。

**Validates: Requirements 3.4**

### Property 5: 订阅 CRUD 一致性

*For any* 订阅操作序列（添加、修改、删除），数据库状态应该正确反映所有操作的累积效果：添加后可查询到，修改后字段更新，删除后不可查询。

**Validates: Requirements 4.2, 4.3, 4.4, 4.5**

### Property 6: 配置持久化往返

*For any* 有效的配置数据，保存到 .env 文件后重新加载，应该得到与原始数据等价的配置值。

**Validates: Requirements 5.4, 6.2, 7.2**

### Property 7: 配置回滚完整性

*For any* 配置保存操作，如果验证失败，.env 文件应该恢复到操作前的状态，不留下部分修改。

**Validates: Requirements 7.4, 8.5**

### Property 8: 输入验证拒绝无效数据

*For any* 无效输入（缺少必填字段、格式错误），API 应该返回错误响应而不是接受数据。

**Validates: Requirements 4.2, 7.1, 8.1, 8.2**

### Property 9: 用户 ID 去重

*For any* 包含重复用户 ID 的输入列表，解析后的结果应该不包含重复项，且保留所有唯一 ID。

**Validates: Requirements 8.3**

### Property 10: API 响应格式一致性

*For any* API 请求，响应应该包含 success 布尔字段、timestamp ISO 8601 格式字段，成功时包含 data 字段，失败时包含 error 对象。

**Validates: Requirements 10.1, 10.2, 10.3, 10.4**

### Property 11: 分页结果正确性

*For any* 分页参数（page、page_size）和数据集，返回的结果数量应该不超过 page_size，且跳过正确数量的记录。

**Validates: Requirements 9.6**

### Property 12: 任务状态一致性

*For any* 扫描任务，查询状态应该返回与任务实际状态一致的信息，包括进度、已扫描数量、重复组数量。

**Validates: Requirements 9.1, 9.2, 9.4**

### Property 13: Token 有效时长计算

*For any* Token 创建时间，计算的有效时长应该等于当前时间与创建时间的差值（以天为单位）。

**Validates: Requirements 2.5**

### Property 14: 入库记录来源标识

*For any* 入库记录，响应应该包含来源字段（Emby 或 115），且来源值与记录的实际来源一致。

**Validates: Requirements 12.4**

## Error Handling

### 1. 外部服务不可用

| 场景 | 处理策略 | 用户反馈 |
|------|---------|---------|
| Emby 服务不可用 | 返回缓存数据或默认值 | 显示 "Emby 服务暂时不可用" |
| 115 云盘 API 超时 | 重试 3 次，间隔 1s | 显示 "115 服务响应超时，请稍后重试" |
| MediaHelp API 失败 | 记录日志，返回错误详情 | 显示具体错误信息 |
| Telegram API 失败 | 异步重试，不阻塞主流程 | 静默失败，记录日志 |

### 2. 数据库错误

| 场景 | 处理策略 | 用户反馈 |
|------|---------|---------|
| SQLite 连接失败 | 重试连接，最多 3 次 | 返回 500 错误 |
| 查询超时 | 取消查询，返回部分结果 | 显示 "查询超时，请缩小范围" |
| 数据完整性错误 | 记录日志，跳过错误记录 | 返回可用数据 |

### 3. 配置错误

| 场景 | 处理策略 | 用户反馈 |
|------|---------|---------|
| .env 文件不存在 | 创建默认配置文件 | 提示 "已创建默认配置" |
| 配置格式错误 | 拒绝保存，保留原配置 | 显示具体格式错误 |
| 必填字段缺失 | 拒绝保存，返回缺失字段列表 | 显示 "请填写必填字段: xxx" |
| 写入失败 | 回滚到原始状态 | 显示 "保存失败，已恢复原配置" |

### 4. 输入验证错误

| 场景 | 处理策略 | HTTP 状态码 |
|------|---------|------------|
| 缺少必填参数 | 返回参数名称和说明 | 400 |
| 参数类型错误 | 返回期望类型和实际类型 | 400 |
| 参数值超出范围 | 返回有效范围 | 400 |
| 资源不存在 | 返回资源标识 | 404 |

### 5. 并发和竞态条件

| 场景 | 处理策略 |
|------|---------|
| 同时保存配置 | 使用文件锁，后者等待 |
| 同时启动扫描 | 返回已存在的任务 ID |
| 扫描中删除文件 | 跳过已删除文件，继续扫描 |

## Testing Strategy

### 测试方法

本项目采用双重测试策略：

1. **单元测试** - 验证具体示例、边界情况和错误条件
2. **属性测试** - 验证跨所有输入的通用属性

两种测试互补，共同提供全面覆盖。

### 属性测试配置

- **测试框架**: pytest + hypothesis
- **最小迭代次数**: 每个属性测试 100 次
- **标签格式**: `# Feature: full-data-integration, Property {number}: {property_text}`

### 单元测试范围

单元测试聚焦于：
- 具体示例验证正确行为
- 边界情况（空数据、极值）
- 错误条件和异常处理
- 组件间集成点

### 属性测试范围

属性测试聚焦于：
- 数据库查询计数一致性
- 时间范围过滤正确性
- 配置持久化往返
- API 响应格式一致性
- 分页结果正确性

### 测试文件结构

```
tests/
├── unit/
│   ├── test_dashboard_api.py      # 仪表盘 API 单元测试
│   ├── test_settings_service.py   # 设置服务单元测试
│   ├── test_hotlist_service.py    # 热榜服务单元测试
│   ├── test_cloud115_service.py   # 115 服务单元测试
│   └── test_dedup_service.py      # 去重服务单元测试
├── property/
│   ├── test_db_query_properties.py    # 数据库查询属性测试
│   ├── test_config_properties.py      # 配置持久化属性测试
│   ├── test_api_response_properties.py # API 响应属性测试
│   └── test_pagination_properties.py  # 分页属性测试
└── integration/
    ├── test_emby_integration.py   # Emby 集成测试
    ├── test_cloud115_integration.py # 115 集成测试
    └── test_mediahelp_integration.py # MediaHelp 集成测试
```

### Mock 策略

| 组件 | Mock 方式 |
|------|----------|
| 外部 API (Emby, 115, MediaHelp) | 使用 responses 或 httpx_mock |
| 数据库 | 使用内存 SQLite |
| 文件系统 | 使用 tmp_path fixture |
| 时间 | 使用 freezegun |

### 测试数据生成

使用 hypothesis 策略生成测试数据：

```python
from hypothesis import strategies as st

# 媒体记录策略
media_record = st.fixed_dictionaries({
    'id': st.integers(min_value=1),
    'title': st.text(min_size=1, max_size=100),
    'created_at': st.datetimes(),
    'source': st.sampled_from(['emby', '115'])
})

# 配置策略
config_data = st.fixed_dictionaries({
    'EMBY_BASE_URL': st.text(min_size=1) | st.none(),
    'EMBY_API_KEY': st.text(min_size=1) | st.none(),
    'TG_BOT_TOKEN': st.text(min_size=1) | st.none()
})
```
