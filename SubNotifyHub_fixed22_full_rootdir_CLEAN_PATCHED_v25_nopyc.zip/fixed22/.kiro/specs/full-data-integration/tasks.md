# Implementation Plan: Full Data Integration

## Overview

本实现计划将所有 Admin 页面的底层服务对接到真实数据源。采用渐进式实现策略，按页面模块逐步完成数据对接，每个模块完成后进行验证。

## Tasks

- [x] 1. 仪表盘数据对接
  - [x] 1.1 实现 Dashboard 统计数据 API
    - 修改 `admin/routes_dashboard_api.py`
    - 从 `recent_store` 获取媒体总数
    - 从 `hotlist_store` 获取订阅数量
    - 计算最近 7 天新增数量
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5_
  
  - [x] 1.2 实现服务状态检测 API
    - 检测 Emby 配置完整性
    - 检测 Telegram Bot Token
    - 检测 MediaHelp Token 及有效时长
    - 检测 115 云盘 Cookie
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6_
  
  - [x] 1.3 实现趋势图数据 API
    - 实现周趋势（7天）数据聚合
    - 实现月趋势（30天）数据聚合
    - 按日期升序返回数据
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5_
  
  - [x] 1.4 编写 Dashboard API 属性测试
    - **Property 1: 数据库查询计数一致性**
    - **Property 2: 时间范围过滤正确性**
    - **Property 4: 趋势数据排序**
    - **Validates: Requirements 1.1, 1.2, 1.3, 3.1, 3.2, 3.4**

- [x] 2. Checkpoint - 仪表盘验证
  - 确保所有测试通过，如有问题请告知

- [x] 3. 热榜订阅数据对接
  - [x] 3.1 实现热榜订阅列表 API
    - 修改 `admin/routes_hotlist.py`
    - 从 SQLite 获取所有订阅
    - 返回订阅快照和忽略计数
    - _Requirements: 4.1, 4.7_
  
  - [x] 3.2 实现热榜订阅 CRUD API
    - 实现添加订阅（含验证和基线初始化）
    - 实现删除订阅
    - 实现修改订阅配置
    - _Requirements: 4.2, 4.3, 4.4, 4.5_
  
  - [x] 3.3 实现热榜回填 API
    - 实现触发回填操作
    - _Requirements: 4.6_
  
  - [x] 3.4 编写热榜服务属性测试
    - **Property 5: 订阅 CRUD 一致性**
    - **Validates: Requirements 4.2, 4.3, 4.4, 4.5**

- [x] 4. Checkpoint - 热榜验证
  - 确保所有测试通过，如有问题请告知

- [x] 5. 115 云盘数据对接
  - [x] 5.1 实现 115 连接测试 API
    - 修改 `admin/routes_cloud115.py`
    - 使用 Cookie 调用 API 验证
    - 返回明确的错误信息
    - _Requirements: 5.1, 5.6_
  
  - [x] 5.2 实现扫码登录 API
    - 生成二维码并返回 base64
    - 实现轮询状态（从缓存读取）
    - 扫码完成后持久化 Cookie
    - _Requirements: 5.2, 5.3, 5.4_
  
  - [x] 5.3 实现下载目录列表 API
    - 返回所有可用下载目录
    - _Requirements: 5.5_
  
  - [x] 5.4 编写 115 服务属性测试
    - **Property 6: 配置持久化往返**
    - **Validates: Requirements 5.4**

- [x] 6. Checkpoint - 115 云盘验证
  - 确保所有测试通过，如有问题请告知

- [x] 7. MediaHelp 数据对接
  - [x] 7.1 实现 MediaHelp 登录 API
    - 修改 `admin/routes_mediahelp.py`
    - 调用登录 API 获取 Token
    - 持久化 Token 到运行时和 .env
    - 发送 Telegram 通知
    - _Requirements: 6.1, 6.2, 6.3, 6.4_
  
  - [x] 7.2 实现 MediaHelp 连接测试 API
    - 调用订阅列表 API 验证 Token
    - _Requirements: 6.5_

- [x] 8. Checkpoint - MediaHelp 验证
  - 确保所有测试通过，如有问题请告知

- [x] 9. 设置配置数据对接
  - [x] 9.1 实现设置保存 API
    - 修改 `admin/routes_settings.py`
    - 验证必填字段
    - 原子性写入 .env 文件
    - 热重载配置到运行时
    - _Requirements: 7.1, 7.2, 7.3_
  
  - [x] 9.2 实现配置回滚机制
    - 验证失败时回滚 .env
    - 空值表示不修改敏感配置
    - _Requirements: 7.4, 7.5_
  
  - [x] 9.3 实现配置状态 API
    - 返回各服务配置状态
    - _Requirements: 7.6_
  
  - [x] 9.4 编写设置服务属性测试
    - **Property 3: 配置存在性检测**
    - **Property 7: 配置回滚完整性**
    - **Property 8: 输入验证拒绝无效数据**
    - **Validates: Requirements 7.1, 7.4, 7.6**

- [x] 10. Checkpoint - 设置验证
  - 确保所有测试通过，如有问题请告知

- [x] 11. TG Bot 配置数据对接
  - [x] 11.1 实现 TG Bot 设置保存 API
    - 修改 `admin/routes_tg_bot.py`
    - 验证并规范化 CLOUD115_QR_APP
    - 验证并规范化 CLOUD115_DUP_MODE
    - 解析并去重用户 ID
    - _Requirements: 8.1, 8.2, 8.3, 8.4, 8.5_
  
  - [x] 11.2 编写 TG Bot 属性测试
    - **Property 9: 用户 ID 去重**
    - **Validates: Requirements 8.3**

- [x] 12. Checkpoint - TG Bot 验证
  - 确保所有测试通过，如有问题请告知

- [x] 13. 媒体去重数据对接
  - [x] 13.1 实现扫描任务 API
    - 修改 `admin/routes_dedup_api.py`
    - 创建扫描任务并返回 task_id
    - 实现任务状态查询
    - 实现任务取消
    - _Requirements: 9.1, 9.2_
  
  - [x] 13.2 实现 SSE 进度推送
    - 实时推送扫描进度更新
    - _Requirements: 9.3_
  
  - [x] 13.3 实现重复组列表 API
    - 返回重复组列表和可回收空间
    - 支持分页、排序和过滤
    - _Requirements: 9.4, 9.6_
  
  - [x] 13.4 实现清理操作 API
    - 根据 action 处理文件
    - _Requirements: 9.5_
  
  - [x] 13.5 编写去重服务属性测试
    - **Property 11: 分页结果正确性**
    - **Property 12: 任务状态一致性**
    - **Validates: Requirements 9.1, 9.2, 9.4, 9.6**

- [x] 14. Checkpoint - 媒体去重验证
  - 确保所有测试通过，如有问题请告知

- [x] 15. 入库监控数据对接
  - [x] 15.1 实现入库监控 API
    - 返回最近入库的媒体列表
    - 返回今日、本周、本月统计
    - 支持时间范围筛选
    - 显示来源标识
    - _Requirements: 12.1, 12.2, 12.3, 12.4_
  
  - [x] 15.2 编写入库监控属性测试
    - **Property 14: 入库记录来源标识**
    - **Validates: Requirements 12.4**

- [x] 16. API 响应格式标准化
  - [x] 16.1 实现统一响应包装器
    - 创建 `admin/utils/response.py`
    - 实现 success/error 响应格式
    - 添加 timestamp 字段
    - _Requirements: 10.1, 10.2, 10.3, 10.4, 10.5_
  
  - [x] 16.2 应用响应包装器到所有 API
    - 更新所有路由使用统一响应格式
    - _Requirements: 10.1, 10.2, 10.3, 10.4, 10.5_
  
  - [x] 16.3 编写 API 响应属性测试
    - **Property 10: API 响应格式一致性**
    - **Validates: Requirements 10.1, 10.2, 10.3, 10.4**

- [x] 17. Final Checkpoint - 全面验证
  - 确保所有测试通过
  - 验证所有页面数据对接正常
  - 如有问题请告知

## Notes

- 所有任务均为必需，包括测试任务
- 每个任务引用具体需求以便追溯
- Checkpoint 确保增量验证
- 属性测试验证通用正确性属性
- 单元测试验证具体示例和边界情况
