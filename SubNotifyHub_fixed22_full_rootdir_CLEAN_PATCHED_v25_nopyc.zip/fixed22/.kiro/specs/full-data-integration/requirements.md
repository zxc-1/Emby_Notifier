# Requirements Document

## Introduction

本文档定义了将所有 Admin 页面底层服务对接到真实数据的需求。项目当前有多个管理页面（仪表盘、设置、热榜、媒体管理、TG Bot、115 云盘、MediaHelp），部分页面已完成数据对接，但仍有硬编码数据或未对接真实服务的情况。本功能旨在确保所有页面都能从真实后端服务获取数据，提供一致的用户体验。

## Glossary

- **Dashboard**: 仪表盘页面，展示系统概览统计数据和服务状态
- **Emby**: 媒体服务器，提供媒体库管理和播放功能
- **MediaHelp**: 媒体助手服务，提供订阅和转发功能
- **Cloud115**: 115 云盘服务，提供云存储和离线下载功能
- **TG_Bot**: Telegram Bot 服务，提供消息通知和交互功能
- **Hotlist**: 豆瓣热榜订阅服务，提供热门影视推荐
- **Dedup_Service**: 媒体去重服务，提供重复文件检测和清理功能
- **Settings_Service**: 配置管理服务，提供系统配置的读写功能
- **API_Response**: 标准化的 API 响应格式，包含 success、data、timestamp 字段

## Requirements

### Requirement 1: 仪表盘统计数据对接

**User Story:** As a 系统管理员, I want 在仪表盘看到真实的统计数据, so that 我能了解系统的实际运行状态。

#### Acceptance Criteria

1. WHEN 用户访问仪表盘页面 THEN THE Dashboard SHALL 从 recent_store 获取媒体总数并显示
2. WHEN 用户访问仪表盘页面 THEN THE Dashboard SHALL 计算并显示最近 7 天的新增媒体数量
3. WHEN 用户访问仪表盘页面 THEN THE Dashboard SHALL 从 hotlist_store 获取热榜订阅数量并显示
4. WHEN 用户访问仪表盘页面 THEN THE Dashboard SHALL 显示活跃热榜列表数量
5. IF recent_store 不可用 THEN THE Dashboard SHALL 显示 0 作为默认值并记录日志

### Requirement 2: 服务连接状态检测

**User Story:** As a 系统管理员, I want 实时查看各服务的连接状态, so that 我能快速发现并处理服务异常。

#### Acceptance Criteria

1. WHEN 用户请求服务状态 THEN THE Dashboard SHALL 检测 Emby 配置是否完整（URL 和 API Key）
2. WHEN 用户请求服务状态 THEN THE Dashboard SHALL 检测 Telegram Bot Token 是否已配置
3. WHEN 用户请求服务状态 THEN THE Dashboard SHALL 检测 MediaHelp Token 是否有效
4. WHEN 用户请求服务状态 THEN THE Dashboard SHALL 检测 115 云盘 Cookie 是否已配置
5. WHEN MediaHelp Token 存在 THEN THE Dashboard SHALL 计算并显示 Token 有效时长
6. THE API_Response SHALL 返回每个服务的状态（online/offline）和详细信息

### Requirement 3: 趋势图数据对接

**User Story:** As a 系统管理员, I want 查看媒体入库趋势图, so that 我能分析系统的使用模式。

#### Acceptance Criteria

1. WHEN 用户请求周趋势数据 THEN THE Dashboard SHALL 返回最近 7 天每天的入库数量
2. WHEN 用户请求月趋势数据 THEN THE Dashboard SHALL 返回最近 30 天每天的入库数量
3. WHEN 请求的时间范围无效 THEN THE Dashboard SHALL 返回 400 错误和错误信息
4. THE Dashboard SHALL 按日期升序返回数据标签和对应数值
5. IF recent_store 不可用 THEN THE Dashboard SHALL 返回全零数组

### Requirement 4: 热榜订阅数据对接

**User Story:** As a 系统管理员, I want 在 Web 界面管理热榜订阅, so that 我不必依赖 Telegram 进行订阅管理。

#### Acceptance Criteria

1. WHEN 用户访问热榜页面 THEN THE Hotlist_Service SHALL 从 SQLite 数据库获取所有订阅列表
2. WHEN 用户添加订阅 THEN THE Hotlist_Service SHALL 验证 chat_id 和 list_key 的有效性
3. WHEN 用户添加订阅 THEN THE Hotlist_Service SHALL 初始化基线数据
4. WHEN 用户删除订阅 THEN THE Hotlist_Service SHALL 从数据库移除订阅记录
5. WHEN 用户修改订阅配置 THEN THE Hotlist_Service SHALL 更新订阅的 filters 字段
6. WHEN 用户触发回填 THEN THE Hotlist_Service SHALL 执行下一页回填操作
7. THE Hotlist_Service SHALL 返回每个订阅的快照数据和忽略计数

### Requirement 5: 115 云盘数据对接

**User Story:** As a 系统管理员, I want 在 Web 界面管理 115 云盘连接, so that 我能方便地配置和测试云盘功能。

#### Acceptance Criteria

1. WHEN 用户测试 115 连接 THEN THE Cloud115 SHALL 使用 Cookie 调用 API 验证有效性
2. WHEN 用户请求扫码登录 THEN THE Cloud115 SHALL 生成二维码并返回 base64 编码的 PNG
3. WHEN 用户轮询扫码状态 THEN THE Cloud115 SHALL 从缓存读取状态而非直接请求 115 API
4. WHEN 扫码完成 THEN THE Cloud115 SHALL 获取 Cookie 并持久化到 .env 文件
5. WHEN 用户请求下载目录列表 THEN THE Cloud115 SHALL 返回所有可用的下载目录
6. IF Cookie 无效或过期 THEN THE Cloud115 SHALL 返回明确的错误信息

### Requirement 6: MediaHelp 数据对接

**User Story:** As a 系统管理员, I want 在 Web 界面管理 MediaHelp 连接, so that 我能方便地登录和测试 MediaHelp 服务。

#### Acceptance Criteria

1. WHEN 用户登录 MediaHelp THEN THE MediaHelp_Service SHALL 调用登录 API 获取 Token
2. WHEN 登录成功 THEN THE MediaHelp_Service SHALL 持久化 Token 到运行时和 .env 文件
3. WHEN 登录成功 THEN THE MediaHelp_Service SHALL 发送 Telegram 通知
4. WHEN 登录失败 THEN THE MediaHelp_Service SHALL 发送失败通知并返回错误详情
5. WHEN 用户测试 MediaHelp 连接 THEN THE MediaHelp_Service SHALL 调用订阅列表 API 验证 Token 有效性

### Requirement 7: 设置配置数据对接

**User Story:** As a 系统管理员, I want 在 Web 界面修改系统配置, so that 配置能立即生效而无需重启服务。

#### Acceptance Criteria

1. WHEN 用户保存基础设置 THEN THE Settings_Service SHALL 验证必填字段（EMBY_BASE_URL、EMBY_API_KEY）
2. WHEN 用户保存设置 THEN THE Settings_Service SHALL 原子性写入 .env 文件
3. WHEN 写入成功 THEN THE Settings_Service SHALL 热重载配置到运行时
4. IF 配置验证失败 THEN THE Settings_Service SHALL 回滚 .env 文件到原始状态
5. WHEN 用户保存敏感配置（Token、Secret）THEN THE Settings_Service SHALL 空值表示不修改
6. THE Settings_Service SHALL 返回配置状态（emby_connected、tmdb_configured 等）

### Requirement 8: TG Bot 配置数据对接

**User Story:** As a 系统管理员, I want 在 Web 界面配置 TG Bot, so that 我能管理 Bot 的入站设置和用户权限。

#### Acceptance Criteria

1. WHEN 用户保存 TG Bot 设置 THEN THE TG_Bot SHALL 验证并规范化 CLOUD115_QR_APP 值
2. WHEN 用户保存 TG Bot 设置 THEN THE TG_Bot SHALL 验证并规范化 CLOUD115_DUP_MODE 值
3. WHEN 用户保存允许用户列表 THEN THE TG_Bot SHALL 解析并去重用户 ID
4. WHEN 保存成功 THEN THE TG_Bot SHALL 返回生效的配置值
5. IF 配置验证失败 THEN THE TG_Bot SHALL 回滚并返回错误信息

### Requirement 9: 媒体去重数据对接

**User Story:** As a 系统管理员, I want 扫描和清理重复媒体文件, so that 我能释放存储空间。

#### Acceptance Criteria

1. WHEN 用户启动扫描 THEN THE Dedup_Service SHALL 创建扫描任务并返回 task_id
2. WHEN 用户查询扫描状态 THEN THE Dedup_Service SHALL 返回进度、已扫描数量、重复组数量
3. WHEN 用户订阅 SSE 进度 THEN THE Dedup_Service SHALL 实时推送扫描进度更新
4. WHEN 扫描完成 THEN THE Dedup_Service SHALL 返回重复组列表和可回收空间大小
5. WHEN 用户执行清理 THEN THE Dedup_Service SHALL 根据 action（move/trash/delete）处理文件
6. THE Dedup_Service SHALL 支持分页、排序和过滤重复组列表

### Requirement 10: API 响应格式标准化

**User Story:** As a 前端开发者, I want 所有 API 返回统一的响应格式, so that 我能用一致的方式处理响应。

#### Acceptance Criteria

1. THE API_Response SHALL 包含 success 布尔字段表示请求是否成功
2. WHEN 请求成功 THEN THE API_Response SHALL 包含 data 字段存放业务数据
3. WHEN 请求失败 THEN THE API_Response SHALL 包含 error 对象（code 和 message）
4. THE API_Response SHALL 包含 timestamp 字段记录响应时间（ISO 8601 格式）
5. WHEN 发生服务器错误 THEN THE API_Response SHALL 返回 500 状态码和错误详情

### Requirement 12: 入库监控数据对接

**User Story:** As a 系统管理员, I want 监控媒体入库状态, so that 我能及时发现入库异常。

#### Acceptance Criteria

1. WHEN 用户请求入库监控数据 THEN THE Dedup_Service SHALL 返回最近入库的媒体列表
2. WHEN 用户请求入库统计 THEN THE Dedup_Service SHALL 返回今日、本周、本月的入库数量
3. THE Dedup_Service SHALL 支持按时间范围筛选入库记录
4. THE Dedup_Service SHALL 显示每条入库记录的来源（Emby/115）
