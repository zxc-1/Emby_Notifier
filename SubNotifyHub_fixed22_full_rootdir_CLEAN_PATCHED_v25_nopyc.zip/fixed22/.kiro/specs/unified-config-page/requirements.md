# Requirements Document

## Introduction

将现有的三个独立配置页面（Settings、TG Bot、Forward）合并为一个统一的"配置"页面。新页面使用可折叠的配置组来组织不同功能模块的配置项，提供更好的用户体验和更清晰的配置层次结构。

## Glossary

- **Config_Page**: 统一配置页面，包含所有配置组的容器页面
- **Config_Group**: 可折叠的配置组，用于组织相关配置项
- **Config_Card**: 配置卡片，包含具体的配置表单字段
- **Settings_API**: 后端配置数据 API 端点
- **Form_Handler**: 表单提交处理器

## Requirements

### Requirement 1: 统一配置页面结构

**User Story:** As a 用户, I want 在一个页面中管理所有配置, so that 我可以更方便地查看和修改系统设置。

#### Acceptance Criteria

1. THE Config_Page SHALL 包含五个可折叠的配置组：基础配置、通知配置、Telegram 配置、115 云盘配置、Forward 配置
2. WHEN 用户点击配置组标题 THEN THE Config_Page SHALL 展开或折叠该配置组
3. THE Config_Page SHALL 默认展开第一个配置组（基础配置）
4. WHEN 页面加载时 THE Config_Page SHALL 从各 API 端点获取配置数据并填充表单
5. THE Config_Page SHALL 在页面顶部显示统一的保存按钮

### Requirement 2: 基础配置组

**User Story:** As a 用户, I want 配置 Emby 服务器和 Webhook 设置, so that 系统可以接收媒体库更新通知。

#### Acceptance Criteria

1. THE Config_Group SHALL 包含 Emby 配置卡片（地址、API Key、等待封面设置）
2. THE Config_Group SHALL 包含 TMDB 配置卡片（API Key）
3. THE Config_Group SHALL 包含 Webhook 配置卡片（Secret、允许 IP、代理信任）
4. WHEN 用户点击"测试连接"按钮 THEN THE Config_Page SHALL 验证 Emby 连接并显示结果
5. THE Config_Page SHALL 对敏感字段（API Key、Secret）进行掩码显示

### Requirement 3: 通知配置组

**User Story:** As a 用户, I want 配置通知渠道和重试策略, so that 我可以控制通知的发送方式。

#### Acceptance Criteria

1. THE Config_Group SHALL 包含通知器设置（类型、队列大小、并发数、超时）
2. THE Config_Group SHALL 包含重试策略设置（最大重试、退避基数、最大退避、抖动）
3. THE Config_Group SHALL 包含消息聚合设置（聚合窗口、最大聚合数）
4. THE Config_Group SHALL 包含处理流程设置（Pipeline 步骤、严格模式）
5. THE Config_Group SHALL 包含去重策略设置（策略、TTL、缓存大小、持久化）

### Requirement 4: Telegram 配置组

**User Story:** As a 用户, I want 配置 Telegram Bot 凭证和运行模式, so that 系统可以通过 Telegram 发送通知。

#### Acceptance Criteria

1. THE Config_Group SHALL 包含 Bot 凭证设置（Token、Chat ID）
2. THE Config_Group SHALL 包含运行模式设置（Polling/Webhook）
3. THE Config_Group SHALL 包含访问控制设置（允许的用户 ID）
4. WHEN 用户点击"测试连接"按钮 THEN THE Config_Page SHALL 验证 Bot Token 并显示 Bot 信息
5. THE Config_Page SHALL 对 Bot Token 进行掩码显示

### Requirement 5: 115 云盘配置组

**User Story:** As a 用户, I want 配置 115 云盘 Cookie 和去重设置, so that 系统可以解析 115 分享链接。

#### Acceptance Criteria

1. THE Config_Group SHALL 包含 Cookie 配置（Cookie 值、扫码登录方式）
2. THE Config_Group SHALL 包含去重设置（去重模式、去重窗口）
3. THE Config_Group SHALL 包含健康检查开关和提交后轮询开关
4. WHEN 用户点击"扫码登录"按钮 THEN THE Config_Page SHALL 显示二维码登录界面
5. WHEN 用户点击"健康检查"按钮 THEN THE Config_Page SHALL 验证 Cookie 有效性

### Requirement 6: Forward 配置组

**User Story:** As a 用户, I want 配置 Forward Bridge 和 MediaHelp 连接, so that 系统可以与 MediaHelp 服务集成。

#### Acceptance Criteria

1. THE Config_Group SHALL 包含 Bridge 设置（启用开关、缓存 TTL、调试模式）
2. THE Config_Group SHALL 包含 MediaHelp 配置（地址、用户名、密码）
3. THE Config_Group SHALL 包含鉴权配置（Token、允许无 Token 访问）
4. WHEN 用户点击"测试连接"按钮 THEN THE Config_Page SHALL 验证 MediaHelp 连接
5. THE Config_Page SHALL 对密码字段进行掩码显示

### Requirement 7: 配置保存与验证

**User Story:** As a 用户, I want 保存配置时得到即时反馈, so that 我知道配置是否成功保存。

#### Acceptance Criteria

1. WHEN 用户点击保存按钮 THEN THE Form_Handler SHALL 收集所有配置组的表单数据
2. WHEN 保存请求发送时 THE Config_Page SHALL 显示加载状态
3. IF 保存成功 THEN THE Config_Page SHALL 显示成功提示
4. IF 保存失败 THEN THE Config_Page SHALL 显示错误信息并保持表单数据
5. THE Form_Handler SHALL 仅提交已修改的配置项以减少不必要的写入

### Requirement 8: 配置状态显示

**User Story:** As a 用户, I want 查看各组件的连接状态, so that 我可以快速了解系统健康状况。

#### Acceptance Criteria

1. THE Config_Page SHALL 在侧边栏显示配置状态摘要
2. THE Config_Page SHALL 显示 Emby 连接状态（已连接/未配置）
3. THE Config_Page SHALL 显示 Telegram Bot 状态（已连接/未配置）
4. THE Config_Page SHALL 显示 115 云盘状态（已配置/未配置）
5. THE Config_Page SHALL 显示 Forward Bridge 状态（运行中/未配置）

### Requirement 9: 统一后端 API

**User Story:** As a 开发者, I want 使用统一的 API 端点获取和保存配置, so that 前端代码更简洁且减少网络请求。

#### Acceptance Criteria

1. THE Settings_API SHALL 提供统一的 `/admin/config.json` GET 端点返回所有配置数据
2. THE Settings_API SHALL 提供统一的 `/admin/config` POST 端点保存所有配置数据
3. THE Settings_API SHALL 在响应中按配置组组织数据（settings、tgbot、forward、cloud115）
4. THE Settings_API SHALL 保留现有的分离端点以保持向后兼容
5. WHEN 保存配置时 THE Settings_API SHALL 仅更新已修改的配置项

### Requirement 10: 响应式布局

**User Story:** As a 用户, I want 在不同设备上都能正常使用配置页面, so that 我可以在手机或平板上管理配置。

#### Acceptance Criteria

1. THE Config_Page SHALL 在桌面端显示双栏布局（主配置区 + 状态侧边栏）
2. WHEN 屏幕宽度小于 1024px THEN THE Config_Page SHALL 切换为单栏布局
3. THE Config_Group SHALL 在移动端保持可折叠功能
4. THE Config_Card SHALL 在移动端自适应宽度
5. THE Config_Page SHALL 确保所有交互元素在触摸设备上可用
