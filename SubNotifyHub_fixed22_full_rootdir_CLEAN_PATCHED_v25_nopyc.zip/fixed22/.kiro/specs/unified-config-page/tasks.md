# Implementation Plan: Unified Config Page

## Overview

将三个独立配置页面合并为统一配置页面，采用可折叠配置组的 UI 模式，后端提供统一的 API 端点。实现顺序：后端 API → 前端页面 → 集成测试。

## Tasks

- [x] 1. 创建统一配置 API 端点
  - [x] 1.1 创建 `admin/routes_config.py` 模块
    - 定义 `router` 和基础导入
    - 实现配置数据构建辅助函数
    - _Requirements: 9.1, 9.3_
  
  - [x] 1.2 实现 GET `/admin/config.json` 端点
    - 聚合 settings、notifier、telegram、cloud115、forward 配置
    - 构建状态数据（emby_connected、tg_connected 等）
    - 对敏感字段调用 mask_sensitive
    - _Requirements: 9.1, 9.3, 2.5_
  
  - [x] 1.3 实现 POST `/admin/config` 端点
    - 解析请求体中的配置组数据
    - 实现变更检测逻辑
    - 写入 .env 并重载配置
    - 实现失败回滚机制
    - _Requirements: 9.2, 9.5, 7.5_
  
  - [x]* 1.4 编写 API 端点属性测试
    - **Property 4: API 响应结构完整性**
    - **Validates: Requirements 9.1, 9.3**
  
  - [x]* 1.5 编写变更检测属性测试
    - **Property 3: 变更字段检测**
    - **Validates: Requirements 7.5, 9.5**

- [x] 2. 注册路由并验证 API
  - [x] 2.1 在 `admin/routes.py` 中注册 `routes_config.router`
    - 添加导入和 include_router
    - _Requirements: 9.1_
  
  - [x]* 2.2 编写 API 单元测试
    - 测试 GET 端点返回正确结构
    - 测试 POST 端点正确保存配置
    - 测试未授权请求返回 401
    - _Requirements: 9.1, 9.2_

- [x] 3. Checkpoint - 确保后端 API 测试通过
  - 确保所有测试通过，如有问题请询问用户。

- [x] 4. 创建统一配置页面模板
  - [x] 4.1 创建 `templates/pages/admin_config.html` 基础结构
    - 页面头部（标题、导入/导出/保存按钮）
    - 主内容区和侧边栏布局
    - _Requirements: 1.1, 1.5_
  
  - [x] 4.2 实现基础配置组 HTML
    - Emby 配置卡片（地址、API Key、等待封面）
    - TMDB 配置卡片（API Key）
    - Webhook 配置卡片（Secret、允许 IP、代理信任）
    - _Requirements: 2.1, 2.2, 2.3_
  
  - [x] 4.3 实现通知配置组 HTML
    - 通知器设置卡片
    - 重试策略卡片
    - 消息聚合卡片
    - 处理流程卡片
    - 去重策略卡片
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5_
  
  - [x] 4.4 实现 Telegram 配置组 HTML
    - Bot 凭证卡片（Token、Chat ID）
    - 运行模式卡片
    - 访问控制卡片
    - _Requirements: 4.1, 4.2, 4.3_
  
  - [x] 4.5 实现 115 云盘配置组 HTML
    - Cookie 配置卡片
    - 去重设置卡片
    - 健康检查开关
    - _Requirements: 5.1, 5.2, 5.3_
  
  - [x] 4.6 实现 Forward 配置组 HTML
    - Bridge 设置卡片
    - MediaHelp 配置卡片
    - 鉴权配置卡片
    - _Requirements: 6.1, 6.2, 6.3_
  
  - [x] 4.7 实现状态侧边栏 HTML
    - 配置状态摘要
    - 快捷操作按钮
    - _Requirements: 8.1, 8.2, 8.3, 8.4, 8.5_

- [x] 5. 创建配置页面 CSS 样式
  - [x] 5.1 创建 `static/css/config.css`
    - 可折叠配置组样式
    - 配置卡片样式
    - 响应式布局（桌面双栏、移动单栏）
    - _Requirements: 10.1, 10.2, 10.3, 10.4_

- [x] 6. 创建配置页面 JavaScript
  - [x] 6.1 创建 `static/js/config.js` 主模块
    - ConfigPage 类实现
    - 初始化和事件绑定
    - _Requirements: 1.4_
  
  - [x] 6.2 实现配置组折叠功能
    - ConfigGroup 类实现
    - 展开/折叠动画
    - 默认展开第一个配置组
    - _Requirements: 1.2, 1.3_
  
  - [x] 6.3 实现配置加载和表单填充
    - 调用 GET `/admin/config.json`
    - 填充所有表单字段
    - 处理敏感字段显示
    - _Requirements: 1.4, 2.5_
  
  - [x] 6.4 实现配置保存功能
    - 收集所有配置组表单数据
    - 实现变更检测（getChangedFields）
    - 调用 POST `/admin/config`
    - 显示保存结果
    - _Requirements: 7.1, 7.2, 7.3, 7.4, 7.5_
  
  - [x] 6.5 实现状态刷新功能
    - 更新侧边栏状态显示
    - _Requirements: 8.1, 8.2, 8.3, 8.4, 8.5_
  
  - [x] 6.6 实现测试连接功能
    - Emby 测试连接
    - TG Bot 测试连接
    - 115 健康检查
    - MediaHelp 测试连接
    - _Requirements: 2.4, 4.4, 5.5, 6.4_

- [x] 7. Checkpoint - 确保前端功能正常
  - 确保所有测试通过，如有问题请询问用户。

- [x] 8. 注册页面路由
  - [x] 8.1 在 `admin/routes_pages.py` 中添加配置页面路由
    - 添加 `/admin/config` 页面路由
    - 渲染 `admin_config.html` 模板
    - _Requirements: 1.1_
  
  - [x] 8.2 更新导航菜单
    - 将"通知配置"改为"配置"
    - 移除 TG Bot 和 Forward 的独立菜单项（可选保留）
    - _Requirements: 1.1_

- [x] 9. 编写属性测试
  - [x]* 9.1 编写敏感字段掩码属性测试
    - **Property 2: 敏感字段掩码处理**
    - **Validates: Requirements 2.5, 4.5, 6.5**
  
  - [x]* 9.2 编写配置组折叠属性测试
    - **Property 1: 配置组折叠状态切换**
    - **Validates: Requirements 1.2**

- [x] 10. Final Checkpoint - 确保所有测试通过
  - 确保所有测试通过，如有问题请询问用户。

## Notes

- 任务标记 `*` 的为可选测试任务，可跳过以加快 MVP 开发
- 每个任务都引用了具体的需求条款以保证可追溯性
- 检查点用于确保增量验证
- 属性测试验证通用正确性属性
- 单元测试验证具体示例和边界情况
