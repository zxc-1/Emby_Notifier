# Design Document: Unified Config Page

## Overview

本设计文档描述将三个独立配置页面（Settings、TG Bot、Forward）合并为统一配置页面的技术方案。采用可折叠配置组的 UI 模式，后端提供统一的 API 端点聚合所有配置数据。

### 设计目标

1. **用户体验提升**：单页面管理所有配置，减少页面切换
2. **代码复用**：统一的配置组件和表单处理逻辑
3. **API 简化**：单一端点获取/保存所有配置
4. **向后兼容**：保留现有 API 端点

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                      Unified Config Page                        │
├─────────────────────────────────────────────────────────────────┤
│  ┌─────────────────────────────────────────────────────────┐   │
│  │                    Config Header                         │   │
│  │  [导入] [导出]                              [保存配置]   │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                 │
│  ┌─────────────────────────────────┐  ┌───────────────────┐   │
│  │         Main Content            │  │    Sidebar        │   │
│  │  ┌───────────────────────────┐  │  │  ┌─────────────┐  │   │
│  │  │ ▼ 基础配置                │  │  │  │ 配置状态    │  │   │
│  │  │   - Emby 配置             │  │  │  │ ✓ Emby      │  │   │
│  │  │   - TMDB 配置             │  │  │  │ ✓ TG Bot    │  │   │
│  │  │   - Webhook 配置          │  │  │  │ ○ 115       │  │   │
│  │  └───────────────────────────┘  │  │  │ ✓ Forward   │  │   │
│  │  ┌───────────────────────────┐  │  │  └─────────────┘  │   │
│  │  │ ▶ 通知配置                │  │  │  ┌─────────────┐  │   │
│  │  └───────────────────────────┘  │  │  │ 快捷操作    │  │   │
│  │  ┌───────────────────────────┐  │  │  │ [测试连接]  │  │   │
│  │  │ ▶ Telegram 配置           │  │  │  │ [清除缓存]  │  │   │
│  │  └───────────────────────────┘  │  │  └─────────────┘  │   │
│  │  ┌───────────────────────────┐  │  └───────────────────┘   │
│  │  │ ▶ 115 云盘配置            │  │                          │
│  │  └───────────────────────────┘  │                          │
│  │  ┌───────────────────────────┐  │                          │
│  │  │ ▶ Forward 配置            │  │                          │
│  │  └───────────────────────────┘  │                          │
│  └─────────────────────────────────┘                          │
└─────────────────────────────────────────────────────────────────┘
```

### 数据流

```
┌──────────┐     GET /admin/config.json      ┌──────────────┐
│  Browser │ ──────────────────────────────► │   FastAPI    │
│          │ ◄────────────────────────────── │   Backend    │
│          │     { settings, tgbot, ...}     │              │
│          │                                 │              │
│          │     POST /admin/config          │              │
│          │ ──────────────────────────────► │              │
│          │     { changed_fields }          │              │
│          │ ◄────────────────────────────── │              │
│          │     { ok: true, flash }         │              │
└──────────┘                                 └──────────────┘
```

## Components and Interfaces

### 前端组件

#### 1. ConfigPage 主组件

```javascript
// static/js/config.js

class ConfigPage {
    constructor() {
        this.groups = ['settings', 'notifier', 'telegram', 'cloud115', 'forward'];
        this.originalData = {};
        this.currentData = {};
    }
    
    async init() {
        await this.loadConfig();
        this.bindEvents();
        this.renderStatus();
    }
    
    async loadConfig() {
        const resp = await fetch('/admin/config.json');
        const data = await resp.json();
        if (data.ok) {
            this.originalData = data.config;
            this.currentData = JSON.parse(JSON.stringify(data.config));
            this.populateForms();
        }
    }
    
    async saveConfig() {
        const changes = this.getChangedFields();
        if (Object.keys(changes).length === 0) {
            showToast('没有需要保存的更改', 'info');
            return;
        }
        
        const resp = await fetch('/admin/config', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(changes)
        });
        
        const result = await resp.json();
        if (result.ok) {
            showToast(result.flash?.body || '配置已保存', 'success');
            this.originalData = JSON.parse(JSON.stringify(this.currentData));
        } else {
            showToast(result.detail || '保存失败', 'error');
        }
    }
    
    getChangedFields() {
        const changes = {};
        for (const group of this.groups) {
            const groupChanges = {};
            const original = this.originalData[group] || {};
            const current = this.currentData[group] || {};
            
            for (const [key, value] of Object.entries(current)) {
                if (JSON.stringify(original[key]) !== JSON.stringify(value)) {
                    groupChanges[key] = value;
                }
            }
            
            if (Object.keys(groupChanges).length > 0) {
                changes[group] = groupChanges;
            }
        }
        return changes;
    }
}
```

#### 2. ConfigGroup 可折叠组件

```javascript
// static/js/config-group.js

class ConfigGroup {
    constructor(element) {
        this.element = element;
        this.header = element.querySelector('.config-group-header');
        this.content = element.querySelector('.config-group-content');
        this.expanded = element.dataset.expanded === 'true';
        
        this.header.addEventListener('click', () => this.toggle());
    }
    
    toggle() {
        this.expanded = !this.expanded;
        this.element.dataset.expanded = this.expanded;
        this.content.style.maxHeight = this.expanded 
            ? this.content.scrollHeight + 'px' 
            : '0';
    }
    
    expand() {
        this.expanded = true;
        this.element.dataset.expanded = 'true';
        this.content.style.maxHeight = this.content.scrollHeight + 'px';
    }
    
    collapse() {
        this.expanded = false;
        this.element.dataset.expanded = 'false';
        this.content.style.maxHeight = '0';
    }
}
```

### 后端接口

#### 1. 统一配置 GET 端点

```python
# admin/routes_config.py

@router.get("/admin/config.json", response_class=JSONResponse)
async def admin_config_all(
    request: Request, 
    user: str = Depends(get_admin_user)
) -> Dict[str, Any]:
    """返回所有配置数据的统一端点。
    
    Returns:
        {
            "ok": True,
            "config": {
                "settings": { ... },    # 基础配置
                "notifier": { ... },    # 通知配置
                "telegram": { ... },    # Telegram 配置
                "cloud115": { ... },    # 115 云盘配置
                "forward": { ... }      # Forward 配置
            },
            "status": {
                "emby_connected": bool,
                "tg_connected": bool,
                "cloud115_configured": bool,
                "forward_ok": bool
            }
        }
    """
    settings = get_settings()
    
    config = {
        "settings": _build_settings_config(settings),
        "notifier": _build_notifier_config(settings),
        "telegram": _build_telegram_config(settings),
        "cloud115": _build_cloud115_config(settings),
        "forward": _build_forward_config(settings),
    }
    
    status = await _build_status(settings)
    
    return {"ok": True, "config": config, "status": status}
```

#### 2. 统一配置 POST 端点

```python
@router.post("/admin/config", response_class=JSONResponse)
async def save_admin_config(
    request: Request,
    user: str = Depends(get_admin_user)
) -> Dict[str, Any]:
    """保存配置的统一端点。
    
    Request Body:
        {
            "settings": { "EMBY_BASE_URL": "...", ... },
            "telegram": { "TG_BOT_TOKEN": "...", ... },
            ...
        }
    
    Returns:
        { "ok": True, "flash": { "title": "已保存", "body": "..." } }
    """
    body = await request.json()
    
    env_path = ENV_PATH
    old_env = await asyncio.to_thread(load_env_file, env_path)
    new_env = dict(old_env)
    changed_keys = []
    
    # 处理各配置组
    for group, fields in body.items():
        handler = CONFIG_HANDLERS.get(group)
        if handler:
            group_changes = await handler(fields, old_env, new_env, get_settings())
            changed_keys.extend(group_changes)
    
    if not changed_keys:
        return {"ok": True, "flash": {"title": "无变更", "body": "未检测到配置变更"}}
    
    # 写入 .env
    try:
        from core.storage import update_env_file
        changes = {k: new_env.get(k) for k in changed_keys}
        await asyncio.to_thread(update_env_file, changes)
    except Exception as e:
        return {"ok": False, "detail": f"写入配置失败: {e}"}
    
    # 重载配置
    try:
        await asyncio.to_thread(reload_settings)
        await _apply_runtime_settings(request.app, changed_keys)
    except Exception as e:
        # 回滚
        rollback = {k: old_env.get(k) for k in changed_keys}
        await asyncio.to_thread(update_env_file, rollback)
        await asyncio.to_thread(reload_settings)
        return {"ok": False, "detail": f"配置校验失败: {e}"}
    
    return {
        "ok": True,
        "flash": {
            "title": "已保存",
            "body": f"配置已保存（更新 {len(changed_keys)} 项）"
        }
    }
```

## Data Models

### 配置数据结构

```python
# 统一配置响应模型
class UnifiedConfigResponse(TypedDict):
    ok: bool
    config: ConfigData
    status: StatusData

class ConfigData(TypedDict):
    settings: SettingsConfig
    notifier: NotifierConfig
    telegram: TelegramConfig
    cloud115: Cloud115Config
    forward: ForwardConfig

class SettingsConfig(TypedDict):
    emby_base_url: str
    emby_api_key: str  # masked
    emby_wait_image: bool
    emby_wait_image_max: int
    tmdb_api_key: str  # masked
    webhook_secret: str  # masked
    webhook_allowed_ips: str
    webhook_trust_proxy: bool

class NotifierConfig(TypedDict):
    notifier_types: str
    notifier_queue_size: int
    notifier_concurrency: int
    notifier_timeout: float
    notifier_enqueue_timeout: float
    notifier_parallel: bool
    notifier_require_all: bool
    notifier_dry_run: bool
    notifier_max_retry: int
    notifier_backoff_base: float
    notifier_backoff_max: float
    notifier_jitter: float
    notifier_agg_window: float
    notifier_agg_max: int
    pipeline_steps: str
    pipeline_strict: bool
    episode_dedup_strategy: str
    dedup_ttl: int
    dedup_max_size: int
    dedup_persistent: bool

class TelegramConfig(TypedDict):
    bot_token: str  # masked
    chat_id: str
    bot_mode: str
    poll_timeout: int
    inbound_enabled: bool
    allowed_user_ids: List[int]
    webhook_secret: str  # masked

class Cloud115Config(TypedDict):
    cookie: str  # masked
    qr_app: str
    dup_mode: str
    dup_window: int
    health_enabled: bool
    poll_on_submit: bool

class ForwardConfig(TypedDict):
    enabled: bool
    sub_cache_ttl: int
    debug: bool
    season_filter: bool
    allow_public_notify: bool
    token: str
    allow_no_token: bool
    mediahelp_base: str
    mediahelp_username: str
    mediahelp_password: str  # masked

class StatusData(TypedDict):
    emby_connected: bool
    tg_connected: bool
    cloud115_configured: bool
    forward_ok: bool
```

### 配置键映射

```python
# 配置组到环境变量的映射
CONFIG_KEY_MAPPING = {
    "settings": {
        "emby_base_url": "EMBY_BASE_URL",
        "emby_api_key": "EMBY_API_KEY",
        "emby_wait_image": "EMBY_WAIT_FOR_IMAGE_ENABLED",
        "emby_wait_image_max": "EMBY_WAIT_FOR_IMAGE_MAX_WAIT",
        "tmdb_api_key": "TMDB_API_KEY",
        "webhook_secret": "WEBHOOK_SECRET",
        "webhook_allowed_ips": "WEBHOOK_ALLOWED_IPS",
        "webhook_trust_proxy": "WEBHOOK_TRUST_PROXY_HEADERS",
    },
    "notifier": {
        "notifier_types": "NOTIFIER_TYPES",
        "notifier_queue_size": "NOTIFIER_MAX_QUEUE_SIZE",
        # ... 其他映射
    },
    "telegram": {
        "bot_token": "TG_BOT_TOKEN",
        "chat_id": "TG_CHAT_ID",
        "bot_mode": "TG_BOT_MODE",
        # ... 其他映射
    },
    "cloud115": {
        "cookie": "CLOUD115_COOKIE",
        "qr_app": "CLOUD115_QR_APP",
        "dup_mode": "CLOUD115_DUP_MODE",
        "dup_window": "CLOUD115_DUP_WINDOW_MINUTES",
        # ... 其他映射
    },
    "forward": {
        "enabled": "FORWARD_BRIDGE_ENABLED",
        "mediahelp_base": "MEDIAHELP_BASE",
        # ... 其他映射
    },
}
```



## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: 配置组折叠状态切换

*For any* 配置组元素，当用户点击其标题时，该配置组的展开状态应该翻转（展开变折叠，折叠变展开）。

**Validates: Requirements 1.2**

### Property 2: 敏感字段掩码处理

*For any* 非空敏感字段值（API Key、Token、Cookie、Password），`mask_sensitive` 函数应该返回一个掩码字符串，该字符串：
- 长度大于 0
- 包含掩码字符（如 `*`）
- 不等于原始值

**Validates: Requirements 2.5, 4.5, 6.5**

### Property 3: 变更字段检测

*For any* 原始配置数据和当前配置数据，`getChangedFields` 函数应该：
- 仅返回值发生变化的字段
- 不返回值相同的字段
- 返回的字段集合是原始数据和当前数据差异的精确表示

**Validates: Requirements 7.5, 9.5**

### Property 4: API 响应结构完整性

*For any* 有效的 GET `/admin/config.json` 请求，响应应该：
- 包含 `ok: true`
- 包含 `config` 对象，其中包含所有预定义的配置组键（settings、notifier、telegram、cloud115、forward）
- 包含 `status` 对象，其中包含所有状态字段

**Validates: Requirements 9.1, 9.3**

### Property 5: 配置保存往返一致性

*For any* 有效的配置变更，通过 POST `/admin/config` 保存后，再通过 GET `/admin/config.json` 获取，变更的字段值应该与保存时提交的值一致（敏感字段除外，因为会被掩码）。

**Validates: Requirements 9.2**

## Error Handling

### 前端错误处理

| 错误场景 | 处理方式 |
|---------|---------|
| API 请求失败 | 显示 Toast 错误提示，保持表单数据不变 |
| 配置加载超时 | 显示重试按钮，允许用户手动重试 |
| 表单验证失败 | 高亮错误字段，显示具体错误信息 |
| 保存失败 | 显示错误详情，不清空表单数据 |
| 网络断开 | 显示离线提示，禁用保存按钮 |

### 后端错误处理

| 错误场景 | HTTP 状态码 | 响应格式 |
|---------|------------|---------|
| 未授权访问 | 401 | `{"ok": false, "detail": "未授权"}` |
| 配置验证失败 | 400 | `{"ok": false, "detail": "配置校验失败: ..."}` |
| 写入 .env 失败 | 500 | `{"ok": false, "detail": "写入配置失败: ..."}` |
| 重载配置失败 | 500 | `{"ok": false, "detail": "配置重载失败: ..."}` + 自动回滚 |

### 回滚机制

```python
async def save_with_rollback(changes: Dict, old_env: Dict) -> Result:
    """保存配置，失败时自动回滚。"""
    try:
        # 1. 写入新配置
        await update_env_file(changes)
        
        # 2. 重载配置
        await reload_settings()
        
        # 3. 应用运行时设置
        await apply_runtime_settings(changed_keys)
        
        return Result.ok()
    except Exception as e:
        # 回滚到旧配置
        rollback = {k: old_env.get(k) for k in changes.keys()}
        await update_env_file(rollback)
        await reload_settings()
        
        return Result.error(f"配置保存失败，已回滚: {e}")
```

## Testing Strategy

### 测试方法

本功能采用双重测试策略：
- **单元测试**：验证具体示例、边界情况和错误条件
- **属性测试**：验证跨所有输入的通用属性

### 单元测试

1. **API 端点测试**
   - GET `/admin/config.json` 返回正确结构
   - POST `/admin/config` 正确保存配置
   - 未授权请求返回 401
   - 无效配置返回 400

2. **配置组件测试**
   - 配置组默认展开状态
   - 点击切换展开/折叠
   - 表单数据正确填充

3. **表单处理测试**
   - 敏感字段掩码显示
   - 变更检测正确性
   - 保存按钮状态管理

### 属性测试

使用 `hypothesis` 库进行属性测试，每个测试至少运行 100 次迭代。

```python
# tests/property/test_config_properties.py

from hypothesis import given, strategies as st

# Feature: unified-config-page, Property 2: 敏感字段掩码处理
@given(st.text(min_size=1, max_size=100))
def test_mask_sensitive_property(value: str):
    """对于任意非空字符串，mask_sensitive 应返回掩码值。"""
    result = mask_sensitive(value)
    assert len(result) > 0
    assert "*" in result or "＊" in result
    assert result != value

# Feature: unified-config-page, Property 3: 变更字段检测
@given(
    st.dictionaries(st.text(min_size=1), st.text()),
    st.dictionaries(st.text(min_size=1), st.text())
)
def test_get_changed_fields_property(original: dict, current: dict):
    """对于任意两个字典，getChangedFields 应只返回差异字段。"""
    changes = get_changed_fields(original, current)
    
    # 所有返回的字段都应该是真正变化的
    for key, value in changes.items():
        assert key not in original or original[key] != value
    
    # 所有相同的字段都不应该在返回值中
    for key in original:
        if key in current and original[key] == current[key]:
            assert key not in changes

# Feature: unified-config-page, Property 4: API 响应结构完整性
@given(st.just(None))  # 无需输入参数
def test_api_response_structure_property(_):
    """API 响应应包含所有预定义的配置组。"""
    response = get_config_response()
    
    assert response["ok"] is True
    assert "config" in response
    
    required_groups = ["settings", "notifier", "telegram", "cloud115", "forward"]
    for group in required_groups:
        assert group in response["config"]
    
    assert "status" in response
```

### 测试覆盖目标

| 测试类型 | 覆盖目标 |
|---------|---------|
| 单元测试 | 所有 API 端点、所有配置组件 |
| 属性测试 | 5 个核心属性 |
| 集成测试 | 完整的配置保存流程 |
| E2E 测试 | 关键用户流程（可选） |
