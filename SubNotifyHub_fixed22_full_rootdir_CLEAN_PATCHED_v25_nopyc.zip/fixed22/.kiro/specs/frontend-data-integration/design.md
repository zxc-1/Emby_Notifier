# Design Document: Frontend Data Integration

## Overview

本设计文档描述前端首页（Dashboard）与后端 API 数据打通的技术方案。核心目标是将当前硬编码的静态数据替换为动态 API 数据，实现实时数据展示。

设计采用以下架构模式：
- **API 层**: 基于现有 `admin/routes_pages.py` 代码，提取为独立 JSON API
- **前端层**: 使用 fetch + localStorage 缓存实现数据获取和缓存
- **数据流**: 采用 stale-while-revalidate 模式，优先展示缓存数据，后台刷新

### 现有代码复用分析

| 功能 | 现有代码位置 | 复用方式 |
|------|-------------|---------|
| 最近入库 API | `admin/routes_pages.py:admin_recent_json()` | ✅ 直接复用，增强返回字段 |
| 统计数据构建 | `admin/routes_pages.py:220-240` | ✅ 提取为独立函数 |
| 服务状态检测 | `admin/routes_pages.py:243-250` | ✅ 提取为独立 API |
| MediaHelp 状态 | `admin/routes_pages.py:185-200` | ✅ 复用检测逻辑 |
| 热榜订阅查询 | `douban_hotlist/store.py:list_subscriptions()` | ✅ 直接调用 |
| 前端缓存工具 | `static/js/common.js:ConfigCache` | ✅ 扩展为 DashboardCache |

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        Frontend (Browser)                        │
├─────────────────────────────────────────────────────────────────┤
│  dashboard.js                                                    │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │ DashboardAPI │  │ CacheManager │  │ UIRenderer   │          │
│  │ - fetchStats │  │ - get/set    │  │ - renderStats│          │
│  │ - fetchRecent│  │ - isValid    │  │ - renderCards│          │
│  │ - fetchStatus│  │ - invalidate │  │ - renderChart│          │
│  └──────────────┘  └──────────────┘  └──────────────┘          │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼ HTTP/JSON
┌─────────────────────────────────────────────────────────────────┐
│                        Backend (FastAPI)                         │
├─────────────────────────────────────────────────────────────────┤
│  /api/dashboard/stats     → StatsAggregator                     │
│  /api/dashboard/recent    → RecentEntriesStore                  │
│  /api/dashboard/services  → ServiceStatusChecker                │
│  /api/dashboard/hotlist   → HotlistService                      │
│  /api/dashboard/chart     → ChartDataProvider                   │
│  /admin/recent.json       → (existing, enhanced)                │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                        Data Sources                              │
├─────────────────────────────────────────────────────────────────┤
│  RecentEntriesStore │ HotlistDB │ Settings │ HealthCounters     │
└─────────────────────────────────────────────────────────────────┘
```

## Components and Interfaces

### 1. Backend API Components

#### 1.1 Dashboard Stats API (`/api/dashboard/stats`)

```python
@router.get("/api/dashboard/stats")
async def dashboard_stats(request: Request) -> JSONResponse:
    """聚合仪表盘统计数据"""
    return {
        "success": True,
        "data": {
            "media_total": int,        # 媒体总数
            "weekly_additions": int,   # 本周入库数
            "hotlist_count": int,      # 热榜订阅数
            "active_lists": int,       # 活跃榜单数
            "pending_count": int,      # 待处理数
        },
        "timestamp": str  # ISO 8601
    }
```

#### 1.2 Recent Entries API (`/api/dashboard/recent`)

```python
@router.get("/api/dashboard/recent")
async def dashboard_recent(
    request: Request,
    limit: int = 12,
    include_posters: bool = True
) -> JSONResponse:
    """获取最近入库列表"""
    return {
        "success": True,
        "data": {
            "items": [
                {
                    "id": str,
                    "media_type": str,      # movie/series/episode
                    "display_title": str,
                    "year": int,
                    "genre": str,
                    "rating": float,
                    "poster_url": str,
                    "tags": list[str],
                    "added_at": str,        # ISO 8601
                }
            ],
            "total": int,
            "has_more": bool
        },
        "timestamp": str
    }
```

#### 1.3 Service Status API (`/api/dashboard/services`)

```python
@router.get("/api/dashboard/services")
async def dashboard_services(request: Request) -> JSONResponse:
    """获取服务连接状态"""
    return {
        "success": True,
        "data": {
            "emby": {"status": "online"|"offline"|"unknown", "detail": str},
            "telegram": {"status": str, "mode": "polling"|"webhook"},
            "mediahelp": {"status": str, "token_age": int},
            "cloud115": {"status": str, "detail": str}
        },
        "timestamp": str
    }
```

#### 1.4 Hotlist Preview API (`/api/dashboard/hotlist`)

```python
@router.get("/api/dashboard/hotlist")
async def dashboard_hotlist(
    request: Request,
    limit: int = 3
) -> JSONResponse:
    """获取热榜订阅预览"""
    return {
        "success": True,
        "data": {
            "subscriptions": [
                {
                    "list_key": str,
                    "list_name": str,
                    "item_count": int,
                    "last_updated": str
                }
            ],
            "total": int
        },
        "timestamp": str
    }
```

#### 1.5 Chart Data API (`/api/dashboard/chart`)

```python
@router.get("/api/dashboard/chart")
async def dashboard_chart(
    request: Request,
    range: str = "week"  # week | month
) -> JSONResponse:
    """获取入库趋势图表数据"""
    return {
        "success": True,
        "data": {
            "labels": list[str],   # 日期标签
            "values": list[int],   # 入库数量
            "range": str
        },
        "timestamp": str
    }
```

### 2. Frontend Components

#### 2.1 DashboardAPI Module

```javascript
const DashboardAPI = {
    BASE_URL: '/api/dashboard',
    
    async fetchStats() { /* ... */ },
    async fetchRecent(limit = 12) { /* ... */ },
    async fetchServices() { /* ... */ },
    async fetchHotlist(limit = 3) { /* ... */ },
    async fetchChart(range = 'week') { /* ... */ },
    async fetchPosters(limit = 24) { /* ... */ }
};
```

#### 2.2 DashboardCache Module

```javascript
const DashboardCache = {
    PREFIX: 'snh_dash_',
    TTL: 5 * 60 * 1000,  // 5 minutes
    
    get(key) { /* ... */ },
    set(key, data) { /* ... */ },
    isValid(key) { /* ... */ },
    invalidate(key) { /* ... */ },
    clear() { /* ... */ }
};
```

#### 2.3 DashboardRenderer Module

```javascript
const DashboardRenderer = {
    renderStats(data) { /* ... */ },
    renderRecentCards(items) { /* ... */ },
    renderServiceStatus(services) { /* ... */ },
    renderHotlistPreview(subscriptions) { /* ... */ },
    renderChart(chartData) { /* ... */ },
    renderPosterWall(posters) { /* ... */ },
    
    showSkeleton(section) { /* ... */ },
    hideSkeleton(section) { /* ... */ }
};
```

## Data Models

### Backend Models

```python
from pydantic import BaseModel
from typing import Optional, List
from datetime import datetime

class DashboardStats(BaseModel):
    media_total: int
    weekly_additions: int
    hotlist_count: int
    active_lists: int
    pending_count: int

class RecentEntry(BaseModel):
    id: str
    media_type: str
    display_title: str
    year: Optional[int]
    genre: Optional[str]
    rating: Optional[float]
    poster_url: Optional[str]
    tags: List[str] = []
    added_at: datetime

class ServiceStatus(BaseModel):
    status: str  # online | offline | unknown
    detail: Optional[str]
    mode: Optional[str]  # for telegram
    token_age: Optional[int]  # for mediahelp

class HotlistSubscription(BaseModel):
    list_key: str
    list_name: str
    item_count: int
    last_updated: Optional[datetime]

class ChartData(BaseModel):
    labels: List[str]
    values: List[int]
    range: str
```

### Frontend Data Structures

```typescript
interface DashboardStats {
    media_total: number;
    weekly_additions: number;
    hotlist_count: number;
    active_lists: number;
    pending_count: number;
}

interface RecentEntry {
    id: string;
    media_type: 'movie' | 'series' | 'episode';
    display_title: string;
    year?: number;
    genre?: string;
    rating?: number;
    poster_url?: string;
    tags: string[];
    added_at: string;
}

interface ServiceStatus {
    status: 'online' | 'offline' | 'unknown';
    detail?: string;
    mode?: 'polling' | 'webhook';
    token_age?: number;
}

interface CacheEntry<T> {
    data: T;
    timestamp: number;
    ttl: number;
}
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: API Response Format Consistency

*For any* API endpoint under `/api/dashboard/*`, the response SHALL contain `success` (boolean), `data` (object or null), and `timestamp` (ISO 8601 string) fields. When `success` is false, an `error` object with `code` and `message` fields SHALL be present.

**Validates: Requirements 7.1, 7.2, 7.3, 7.4**

### Property 2: Recent Entries Limit Enforcement

*For any* request to `/api/dashboard/recent` with a `limit` parameter, the returned `items` array length SHALL be less than or equal to the specified limit, and SHALL never exceed the configured maximum (50).

**Validates: Requirements 2.1**

### Property 3: Statistics Data Completeness

*For any* successful response from `/api/dashboard/stats`, the `data` object SHALL contain all required fields: `media_total`, `weekly_additions`, `hotlist_count`, `active_lists`, and `pending_count`, each as non-negative integers.

**Validates: Requirements 1.2**

### Property 4: Service Status Indicator Mapping

*For any* service in the `/api/dashboard/services` response, the `status` field SHALL be one of: "online", "offline", or "unknown". The frontend SHALL render a green indicator for "online", red for "offline", and yellow/gray for "unknown".

**Validates: Requirements 3.1, 3.2, 3.3, 3.5**

### Property 5: Hotlist Subscription Preview Limit

*For any* request to `/api/dashboard/hotlist` with a `limit` parameter, the returned `subscriptions` array length SHALL be less than or equal to the specified limit.

**Validates: Requirements 4.1, 4.2**

### Property 6: Chart Data Label-Value Alignment

*For any* response from `/api/dashboard/chart`, the `labels` array and `values` array SHALL have equal lengths, and each value SHALL be a non-negative integer.

**Validates: Requirements 6.1, 6.2, 6.3**

### Property 7: Cache TTL Enforcement

*For any* cached dashboard data, the cache entry SHALL be considered invalid and refreshed when the current time exceeds `timestamp + TTL` (5 minutes). Stale cache entries SHALL NOT be served without triggering a background refresh.

**Validates: Requirements 8.1, 8.2**

### Property 8: Poster Wall Slot Filling

*For any* poster wall render, exactly 24 poster slots SHALL be filled. If fewer than 24 actual posters are available, the remaining slots SHALL be filled with default TMDB poster URLs.

**Validates: Requirements 9.1, 9.2, 9.3**

### Property 9: Entry Rendering Completeness

*For any* recent entry with non-null `display_title`, `poster_url`, and `rating` fields, the rendered poster card SHALL display all three values. Missing optional fields SHALL result in appropriate fallback rendering (placeholder image, hidden rating, etc.).

**Validates: Requirements 2.2, 2.3, 2.4**

### Property 10: Error State Fallback

*For any* API request failure, the frontend SHALL either display cached data (if valid) or show a user-friendly error state with retry option. The UI SHALL NOT display broken/empty states without explanation.

**Validates: Requirements 1.4, 3.5**

## Error Handling

### Backend Error Handling

1. **Data Source Unavailable**: Return partial data with `warnings` array indicating which sources failed
2. **Authentication Required**: Return 401 with `UNAUTHORIZED` error code
3. **Rate Limiting**: Return 429 with `RATE_LIMITED` error code and `retry_after` header
4. **Internal Error**: Return 500 with `INTERNAL_ERROR` code, log full stack trace

```python
async def safe_fetch_stats() -> DashboardStats:
    """Fetch stats with graceful degradation"""
    stats = DashboardStats(
        media_total=0,
        weekly_additions=0,
        hotlist_count=0,
        active_lists=0,
        pending_count=0
    )
    warnings = []
    
    try:
        stats.media_total = await get_media_count()
    except Exception as e:
        warnings.append(f"media_total: {e}")
        
    # ... similar for other fields
    
    return stats, warnings
```

### Frontend Error Handling

1. **Network Error**: Show cached data + "离线模式" indicator
2. **API Error**: Show error toast + retry button
3. **Parse Error**: Log to console, show fallback UI
4. **Timeout**: Retry once, then show timeout message

```javascript
async function fetchWithFallback(key, fetcher) {
    try {
        const data = await fetcher();
        DashboardCache.set(key, data);
        return { data, fromCache: false };
    } catch (error) {
        const cached = DashboardCache.get(key);
        if (cached) {
            return { data: cached, fromCache: true, error };
        }
        throw error;
    }
}
```

## Testing Strategy

### Unit Tests

1. **API Response Validation**: Test each endpoint returns correct schema
2. **Cache Logic**: Test TTL calculation, invalidation, storage limits
3. **Renderer Functions**: Test HTML output for various data states
4. **Error Handlers**: Test fallback behavior for each error type

### Property-Based Tests

使用 Hypothesis (Python) 和 fast-check (JavaScript) 进行属性测试：

1. **Property 1 (API Format)**: Generate random API responses, verify schema compliance
2. **Property 2 (Limit Enforcement)**: Generate random limits, verify array length constraints
3. **Property 6 (Chart Alignment)**: Generate random chart data, verify label-value alignment
4. **Property 7 (Cache TTL)**: Generate random timestamps, verify cache validity logic
5. **Property 8 (Poster Slots)**: Generate random poster counts, verify slot filling

### Integration Tests

1. **End-to-End Data Flow**: Verify data flows from backend to rendered UI
2. **Cache Behavior**: Verify stale-while-revalidate pattern works correctly
3. **Error Recovery**: Verify UI recovers gracefully from API failures

### Test Configuration

- Minimum 100 iterations per property test
- Tag format: `Feature: frontend-data-integration, Property {N}: {description}`
