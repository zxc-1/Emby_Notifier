# Implementation Plan: Frontend Data Integration

## Overview

基于现有后端代码，将 Dashboard 页面的静态数据替换为动态 API 数据。主要工作是提取现有逻辑为独立 API，并在前端实现数据获取和渲染。

## Tasks

- [x] 1. 创建 Dashboard API 路由模块
  - 新建 `admin/routes_dashboard_api.py`
  - 从 `routes_pages.py` 提取统计数据构建逻辑
  - 在 `admin/routes.py` 中注册新路由
  - _Requirements: 7.1, 7.2, 7.3, 7.4_

- [x] 2. 实现统计数据 API
  - [x] 2.1 实现 `/api/dashboard/stats` 端点
    - 复用 `routes_pages.py` 中的 stats 构建逻辑
    - 返回 media_total, weekly_additions, hotlist_count 等字段
    - _Requirements: 1.1, 1.2_

  - [x] 2.2* 编写统计数据 API 单元测试
    - 测试响应格式和字段完整性
    - _Requirements: 1.2_

- [x] 3. 实现服务状态 API
  - [x] 3.1 实现 `/api/dashboard/services` 端点
    - 复用现有 Emby/Telegram/MediaHelp/115 状态检测逻辑
    - 返回各服务的 status 和 detail
    - _Requirements: 3.1, 3.2, 3.3, 3.5_

  - [x] 3.2* 编写服务状态 API 单元测试
    - 测试各服务状态返回值
    - _Requirements: 3.1_

- [x] 4. 增强最近入库 API
  - [x] 4.1 增强 `/admin/recent.json` 返回字段
    - 添加 year, genre, rating, tags 字段
    - 添加 poster_url 字段（优先 web_cover_url）
    - _Requirements: 2.1, 2.2, 2.3_

  - [ ] 4.2* 编写最近入库 API 属性测试
    - **Property 2: Recent Entries Limit Enforcement**
    - **Validates: Requirements 2.1**

- [x] 5. 实现热榜预览 API
  - [x] 5.1 实现 `/api/dashboard/hotlist` 端点
    - 调用 `douban_hotlist.store.list_subscriptions()`
    - 返回前 3 个订阅的 list_name 和 item_count
    - _Requirements: 4.1, 4.2_

  - [ ] 5.2* 编写热榜预览 API 单元测试
    - 测试订阅数量限制
    - _Requirements: 4.1_

- [x] 6. 实现图表数据 API
  - [x] 6.1 实现 `/api/dashboard/chart` 端点
    - 从 recent_store 统计每日入库数量
    - 支持 week/month 两种时间范围
    - _Requirements: 6.1, 6.2_

  - [ ] 6.3* 编写图表数据 API 属性测试
    - **Property 6: Chart Data Label-Value Alignment**
    - **Validates: Requirements 6.1, 6.2, 6.3**

- [x] 7. Checkpoint - 后端 API 完成
  - 确保所有 API 测试通过
  - 手动验证 API 响应格式

- [x] 8. 实现前端数据获取模块
  - [x] 8.1 创建 `static/js/dashboard-api.js`
    - 实现 DashboardAPI 对象
    - 封装 fetchStats, fetchRecent, fetchServices 等方法
    - _Requirements: 1.1, 2.1, 3.1_

  - [x] 8.2 实现 DashboardCache 缓存模块
    - 扩展现有 ConfigCache，设置 5 分钟 TTL
    - 实现 stale-while-revalidate 模式
    - _Requirements: 8.1, 8.2_

- [x] 9. 实现前端数据渲染
  - [x] 9.1 实现统计数据动态渲染
    - 替换 hero-stats 区域的硬编码数据
    - 添加骨架屏加载状态
    - _Requirements: 1.2, 1.3_

  - [x] 9.2 实现最近入库动态渲染
    - 替换 poster-grid 区域的硬编码卡片
    - 实现海报卡片模板渲染
    - _Requirements: 2.2, 2.3, 2.4, 2.6_

  - [x] 9.3 实现服务状态动态渲染
    - 替换 service-posters 区域的硬编码状态
    - 根据 API 返回更新状态指示器
    - _Requirements: 3.2, 3.3_

  - [x] 9.4 实现热榜预览动态渲染
    - 替换 hotlist-mini 区域的硬编码数据
    - 处理空状态显示
    - _Requirements: 4.2, 4.3_

  - [x] 9.5 实现图表数据动态渲染
    - 替换 trendChart 的硬编码数据
    - 实现周/月切换时重新获取数据
    - _Requirements: 6.3, 6.4_

- [x] 10. 实现海报墙动态数据
  - [x] 10.1 实现海报墙 API 调用
    - 从 recent API 获取海报 URL 列表
    - 填充不足 24 张时使用默认海报
    - _Requirements: 9.1, 9.2, 9.3_

- [x] 11. 实现错误处理和降级
  - [x] 11.1 实现 API 错误处理
    - 网络错误时显示缓存数据
    - 添加错误提示和重试按钮
    - _Requirements: 1.4, 8.2_

  - [x] 11.2 实现缓存时间显示
    - 显示"上次更新: X分钟前"
    - _Requirements: 8.5_

- [x] 12. Checkpoint - 前端集成完成
  - 确保所有功能正常工作
  - 测试缓存和错误处理

- [x] 13.* 编写属性测试
  - [x] 13.1* 编写 API 响应格式属性测试
    - **Property 1: API Response Format Consistency**
    - **Validates: Requirements 7.1, 7.2, 7.3, 7.4**

  - [x] 13.2* 编写缓存 TTL 属性测试
    - **Property 7: Cache TTL Enforcement**
    - **Validates: Requirements 8.1, 8.2**

- [x] 14. Final Checkpoint
  - 确保所有测试通过
  - 验证前后端数据打通完整性

## Notes

- 任务标记 `*` 为可选测试任务，可跳过以加快 MVP 开发
- 后端 API 基于现有代码提取，减少重复开发
- 前端使用渐进式替换，保持向后兼容
- 属性测试使用 Hypothesis (Python) 和 fast-check (JavaScript)
