# Requirements Document

## Introduction

本功能旨在将前端首页（Dashboard）的静态硬编码数据替换为后端 API 动态数据，实现前后端数据打通。当前首页展示的统计数据、最近入库、热榜订阅、推送记录等信息均为静态占位数据，需要通过 API 接口获取真实数据并动态渲染。

## Glossary

- **Dashboard**: 前端首页仪表盘，展示系统概览和关键统计信息
- **API_Gateway**: 后端 API 路由层，负责处理前端数据请求
- **Recent_Store**: 最近入库记录存储服务，管理媒体入库历史
- **Hotlist_Service**: 豆瓣热榜订阅服务，管理热榜数据和订阅状态
- **Stats_Aggregator**: 统计数据聚合器，汇总各类系统指标
- **Push_Log**: 推送记录日志，记录通知发送历史

## Requirements

### Requirement 1: 首页统计数据动态加载

**User Story:** As a user, I want to see real-time statistics on the dashboard, so that I can understand the current state of my media library.

#### Acceptance Criteria

1. WHEN the dashboard page loads, THE Dashboard SHALL request statistics data from the API within 500ms
2. WHEN statistics data is received, THE Dashboard SHALL display media total count, weekly additions, and hotlist subscription count
3. WHILE statistics data is loading, THE Dashboard SHALL display skeleton loading placeholders
4. IF the statistics API request fails, THEN THE Dashboard SHALL display cached data or fallback values with an error indicator
5. WHEN statistics data changes on the server, THE Dashboard SHALL reflect updates within 30 seconds via polling or manual refresh

### Requirement 2: 最近入库列表动态渲染

**User Story:** As a user, I want to see my recently added media items, so that I can track what has been added to my library.

#### Acceptance Criteria

1. WHEN the dashboard loads, THE Recent_Store SHALL provide the latest 12 media entries via API
2. WHEN recent entries are received, THE Dashboard SHALL render poster cards with title, year, genre, rating, and tags
3. WHEN a media entry has a poster image, THE Dashboard SHALL display the poster from the cached URL or TMDB
4. IF a media entry lacks a poster, THEN THE Dashboard SHALL display a placeholder image
5. WHEN the user clicks "查看全部", THE Dashboard SHALL navigate to the full recent entries list
6. WHILE recent entries are loading, THE Dashboard SHALL display skeleton poster cards

### Requirement 3: 服务状态实时监控

**User Story:** As a user, I want to see the connection status of integrated services, so that I can quickly identify any service issues.

#### Acceptance Criteria

1. WHEN the dashboard loads, THE Stats_Aggregator SHALL check connection status for Emby, Telegram, MediaHelp, and 115 Cloud
2. WHEN a service is connected, THE Dashboard SHALL display a green "在线" indicator
3. WHEN a service is disconnected, THE Dashboard SHALL display a red "离线" indicator
4. WHEN a service status changes, THE Dashboard SHALL update the indicator within 10 seconds
5. IF service status check fails, THEN THE Dashboard SHALL display "未知" status with a warning icon

### Requirement 4: 热榜订阅预览

**User Story:** As a user, I want to see a preview of my hotlist subscriptions, so that I can quickly check my subscription status.

#### Acceptance Criteria

1. WHEN the dashboard loads, THE Hotlist_Service SHALL provide the top 3 active subscriptions
2. WHEN subscriptions are received, THE Dashboard SHALL display list name and item count for each
3. WHEN no subscriptions exist, THE Dashboard SHALL display an empty state with "添加订阅" action
4. WHEN the user clicks a subscription row, THE Dashboard SHALL navigate to the hotlist detail page

### Requirement 5: 推送记录实时流

**User Story:** As a user, I want to see recent push notifications, so that I can track system activity.

#### Acceptance Criteria

1. WHEN the dashboard loads, THE Push_Log SHALL provide the latest 5 push records
2. WHEN push records are received, THE Dashboard SHALL display message content and relative timestamp
3. WHEN a new push occurs, THE Dashboard SHALL prepend the new record with animation
4. WHILE push records are loading, THE Dashboard SHALL display placeholder rows
5. IF no push records exist, THEN THE Dashboard SHALL display "暂无推送记录"

### Requirement 6: 入库趋势图表数据

**User Story:** As a user, I want to see a chart of my library additions over time, so that I can understand my media consumption patterns.

#### Acceptance Criteria

1. WHEN the dashboard loads, THE Stats_Aggregator SHALL provide daily addition counts for the past 7 days
2. WHEN the user switches to "月" view, THE Stats_Aggregator SHALL provide weekly addition counts for the past 4 weeks
3. WHEN chart data is received, THE Dashboard SHALL render a bar chart with the data
4. IF chart data is empty, THEN THE Dashboard SHALL display a flat line with "暂无数据" label

### Requirement 7: API 响应格式标准化

**User Story:** As a developer, I want consistent API response formats, so that I can reliably parse and handle data.

#### Acceptance Criteria

1. THE API_Gateway SHALL return JSON responses with `ok`, `data`, and optional `error` fields
2. WHEN a request succeeds, THE API_Gateway SHALL set `ok: true` and include data in `data` field
3. WHEN a request fails, THE API_Gateway SHALL set `ok: false` and include error message in `error` field
4. THE API_Gateway SHALL include `timestamp` field in all responses for cache validation

### Requirement 8: 数据缓存与刷新策略

**User Story:** As a user, I want fast page loads with fresh data, so that I can have a responsive experience.

#### Acceptance Criteria

1. THE Dashboard SHALL cache API responses in localStorage with TTL of 5 minutes
2. WHEN cached data exists and is valid, THE Dashboard SHALL display cached data immediately while fetching fresh data
3. WHEN fresh data differs from cached data, THE Dashboard SHALL update the display with smooth transitions
4. WHEN the user manually refreshes, THE Dashboard SHALL bypass cache and fetch fresh data
5. THE Dashboard SHALL display "上次更新: X分钟前" indicator for cached data

### Requirement 9: 海报墙动态数据

**User Story:** As a user, I want the background poster wall to show my actual media posters, so that the dashboard feels personalized.

#### Acceptance Criteria

1. WHEN the dashboard loads, THE Recent_Store SHALL provide up to 24 poster URLs for the background wall
2. WHEN poster URLs are received, THE Dashboard SHALL replace static TMDB URLs with actual media posters
3. WHEN fewer than 24 posters are available, THE Dashboard SHALL fill remaining slots with default TMDB posters
4. THE Dashboard SHALL rotate posters every 3 seconds with fade animation

### Requirement 10: Hero 面板动态内容

**User Story:** As a user, I want the hero panels to show relevant personalized content, so that I can see what's important at a glance.

#### Acceptance Criteria

1. WHEN the dashboard loads, THE Stats_Aggregator SHALL provide "今日精选" recommendation based on recent additions
2. WHEN the dashboard loads, THE Stats_Aggregator SHALL provide "即将更新" list from tracked series
3. WHEN the dashboard loads, THE Stats_Aggregator SHALL provide "正在追剧" progress from user watch history
4. IF no data is available for a panel section, THEN THE Dashboard SHALL display appropriate empty state
5. WHEN panel data is received, THE Dashboard SHALL render with smooth fade-in animation
