# Requirements Document

## Introduction

SubNotifyHub 是一个媒体通知管理系统，集成 Emby webhook、Telegram Bot、豆瓣热榜订阅、MediaHelp 联动和 115 云盘功能。本次前端重设计将从零开始构建，基于后端 API 能力设计现代化管理界面。

## Glossary

- **Admin_Panel**: 管理面板，系统的主要用户界面
- **Design_System**: 设计系统，定义所有视觉和交互规范
- **Component_Library**: 组件库，包含所有可复用的 UI 组件
- **Theme_System**: 主题系统，管理深色/浅色模式
- **Dashboard**: 仪表盘，显示系统概览和最近入库媒体
- **Settings_Module**: 设置模块，管理各类配置项
- **Hotlist_Module**: 热榜模块，管理豆瓣热榜订阅

## Requirements

### Requirement 1: 设计系统基础

**User Story:** As a 用户, I want 现代化的视觉设计, so that 使用体验愉悦且高效。

#### Acceptance Criteria

1. THE Design_System SHALL 采用 Bento Grid 布局风格，使用模块化卡片系统
2. THE Design_System SHALL 定义 8px 基础间距单位，所有间距为 8 的倍数
3. THE Design_System SHALL 使用 16px 作为基础字号，标题层级清晰（24px/20px/16px/14px）
4. THE Design_System SHALL 定义主色调（品牌绿 #22c55e）、中性色、语义色（成功/警告/错误）
5. THE Design_System SHALL 使用 12px-24px 范围的圆角，大组件用大圆角

### Requirement 2: 深色模式优先

**User Story:** As a 用户, I want 护眼的深色界面, so that 长时间使用不疲劳。

#### Acceptance Criteria

1. THE Theme_System SHALL 默认使用深色模式，背景色为 #0a0a0b
2. THE Theme_System SHALL 支持浅色模式切换，背景色为 #f5f5f7
3. THE Theme_System SHALL 支持跟随系统主题自动切换
4. WHEN 主题切换时, THE Theme_System SHALL 平滑过渡所有颜色（200ms）
5. THE Theme_System SHALL 确保深色模式下文字对比度达到 WCAG AA 标准

### Requirement 3: 顶部标签导航

**User Story:** As a 用户, I want 简洁的顶部导航, so that 我能快速切换功能模块。

#### Acceptance Criteria

1. THE Admin_Panel SHALL 在顶部显示标签式导航栏
2. THE Admin_Panel SHALL 显示导航标签：控制台、设置、联动、Bot 配置、热榜管理
3. WHEN 导航标签被选中时, THE Admin_Panel SHALL 显示下划线高亮指示
4. THE Admin_Panel SHALL 在导航栏右侧显示搜索、设置、全屏等快捷操作
5. IF 屏幕宽度小于 768px, THEN THE Admin_Panel SHALL 将导航标签收起为下拉菜单

### Requirement 4: 概览仪表盘（dala 风格）

**User Story:** As a 用户, I want 一目了然的系统概览, so that 我能快速掌握运行状态。

#### Acceptance Criteria

1. THE Dashboard SHALL 显示任务统计卡片（热榜订阅数、MediaHelp 状态、115 状态）
2. THE Dashboard SHALL 显示系统状态卡片（渐变背景，版本号、运行状态）
3. THE Dashboard SHALL 显示 Emby 媒体库卡片，包含最近7天入库趋势图
4. THE Dashboard SHALL 在右侧显示统计面板（电影数、剧集数、总数）
5. THE Dashboard SHALL 显示最近入库媒体横向滚动区域
6. THE Dashboard SHALL 为每个媒体卡片显示类型标签（电影/剧集/E01-08）
7. WHEN 点击媒体卡片时, THE Dashboard SHALL 跳转到详情页（如有 detail_url）

### Requirement 5: 基础设置页面

**User Story:** As a 用户, I want 结构清晰的配置页面, so that 我能轻松管理各项设置。

#### Acceptance Criteria

1. THE Settings_Module SHALL 将配置项分组显示：Emby 配置、Telegram 配置、通知配置、高级配置
2. THE Settings_Module SHALL 为敏感字段（Token/Key/Cookie）提供密码遮罩和显示切换
3. THE Settings_Module SHALL 调用 `POST /admin/settings` 保存配置
4. WHEN 配置保存成功时, THE Settings_Module SHALL 显示成功提示
5. IF 配置验证失败, THEN THE Settings_Module SHALL 在对应字段显示错误信息

### Requirement 6: 联动设置页面

**User Story:** As a 用户, I want 配置 MediaHelp 联动, so that 我能实现自动化订阅。

#### Acceptance Criteria

1. THE Settings_Module SHALL 显示 MediaHelp 连接状态和登录入口
2. THE Settings_Module SHALL 调用 `POST /admin/tg-bot/mediahelp/login` 进行登录
3. THE Settings_Module SHALL 调用 `GET /admin/tg-bot/mediahelp/test` 测试连接
4. THE Settings_Module SHALL 调用 `POST /admin/forward-settings` 保存联动配置
5. WHEN MediaHelp 登录成功时, THE Settings_Module SHALL 显示登录状态和 Token 有效期

### Requirement 7: Bot 配置页面

**User Story:** As a 用户, I want 配置 Telegram Bot 和 115 云盘, so that 我能使用 Bot 功能。

#### Acceptance Criteria

1. THE Settings_Module SHALL 显示 TG Bot 入站开关和允许用户 ID 配置
2. THE Settings_Module SHALL 显示 115 云盘 Cookie 配置和扫码登录入口
3. THE Settings_Module SHALL 调用 `POST /admin/tg-bot/115/qrcode/start` 获取二维码
4. THE Settings_Module SHALL 调用 `GET /admin/tg-bot/115/qrcode/poll` 轮询扫码状态
5. THE Settings_Module SHALL 调用 `POST /admin/tg-bot-settings` 保存 Bot 配置

### Requirement 8: 热榜管理页面

**User Story:** As a 用户, I want 管理豆瓣热榜订阅, so that 我能自动追踪热门影视。

#### Acceptance Criteria

1. THE Hotlist_Module SHALL 调用 `/admin/hotlist.json` 获取内置榜单和订阅列表
2. THE Hotlist_Module SHALL 显示内置榜单卡片，支持一键订阅
3. THE Hotlist_Module SHALL 显示我的订阅表格，支持排序和筛选
4. THE Hotlist_Module SHALL 调用 `POST /admin/hotlist/add` 添加订阅
5. THE Hotlist_Module SHALL 调用 `POST /admin/hotlist/delete` 删除订阅
6. THE Hotlist_Module SHALL 调用 `POST /admin/hotlist/patch` 修改订阅规则
7. THE Hotlist_Module SHALL 调用 `POST /admin/hotlist/backfill_next` 触发回填

### Requirement 9: 卡片组件

**User Story:** As a 用户, I want 美观的信息卡片, so that 内容展示清晰有层次。

#### Acceptance Criteria

1. THE Component_Library SHALL 提供标准卡片：标题、内容、操作区
2. THE Component_Library SHALL 提供统计卡片：图标、数值、标签
3. THE Component_Library SHALL 提供媒体卡片：封面、标题、元信息
4. THE Component_Library SHALL 支持卡片悬停效果（轻微上浮 + 阴影增强）
5. THE Component_Library SHALL 支持卡片加载骨架屏状态

### Requirement 10: 表单组件

**User Story:** As a 用户, I want 易用的表单控件, so that 数据输入高效准确。

#### Acceptance Criteria

1. THE Component_Library SHALL 提供输入框：文本、数字、密码、URL
2. THE Component_Library SHALL 提供选择器：下拉选择、多选、开关
3. THE Component_Library SHALL 提供文本域：支持自动高度调整
4. WHEN 输入框获得焦点时, THE Component_Library SHALL 显示品牌色边框
5. THE Component_Library SHALL 支持表单验证状态：正常、错误、成功

### Requirement 11: 按钮组件

**User Story:** As a 用户, I want 清晰的操作按钮, so that 我能准确执行操作。

#### Acceptance Criteria

1. THE Component_Library SHALL 提供主按钮（实心绿色）用于主要操作
2. THE Component_Library SHALL 提供次按钮（边框样式）用于次要操作
3. THE Component_Library SHALL 提供危险按钮（红色）用于破坏性操作
4. THE Component_Library SHALL 提供幽灵按钮（透明）用于辅助操作
5. THE Component_Library SHALL 支持按钮加载状态（旋转图标）

### Requirement 12: 模态框和抽屉

**User Story:** As a 用户, I want 聚焦的弹出界面, so that 我能专注当前任务。

#### Acceptance Criteria

1. THE Component_Library SHALL 提供居中模态框，支持多种尺寸
2. THE Component_Library SHALL 提供右侧抽屉，用于详情编辑
3. WHEN 弹出层打开时, THE Component_Library SHALL 显示半透明遮罩
4. THE Component_Library SHALL 支持 ESC 键关闭弹出层
5. THE Component_Library SHALL 支持点击遮罩关闭（可配置）

### Requirement 13: 通知反馈

**User Story:** As a 用户, I want 及时的操作反馈, so that 我知道操作结果。

#### Acceptance Criteria

1. THE Component_Library SHALL 提供 Toast 通知，显示在右上角
2. THE Component_Library SHALL 支持成功、错误、警告、信息四种类型
3. THE Component_Library SHALL 支持自动消失（默认 3 秒）
4. THE Component_Library SHALL 支持手动关闭
5. THE Component_Library SHALL 支持多条通知堆叠显示

### Requirement 14: 数据表格

**User Story:** As a 用户, I want 功能完善的数据表格, so that 我能高效管理数据。

#### Acceptance Criteria

1. THE Component_Library SHALL 提供响应式表格，支持水平滚动
2. THE Component_Library SHALL 支持列排序（升序/降序）
3. THE Component_Library SHALL 支持行选择（单选/多选）
4. THE Component_Library SHALL 支持行操作按钮（编辑/删除）
5. THE Component_Library SHALL 支持空状态和加载状态显示

### Requirement 15: 响应式布局

**User Story:** As a 用户, I want 在任何设备上都能使用, so that 我能随时管理系统。

#### Acceptance Criteria

1. THE Admin_Panel SHALL 定义三个断点：mobile(<768px)、tablet(768-1024px)、desktop(>1024px)
2. THE Admin_Panel SHALL 在移动端使用底部导航栏替代侧边栏
3. THE Admin_Panel SHALL 在移动端将多列布局改为单列
4. THE Admin_Panel SHALL 确保触摸目标最小 44x44px
5. THE Admin_Panel SHALL 支持 iOS 安全区域适配

### Requirement 16: 可访问性

**User Story:** As a 用户, I want 无障碍的界面, so that 所有人都能使用。

#### Acceptance Criteria

1. THE Admin_Panel SHALL 支持完整的键盘导航
2. THE Admin_Panel SHALL 为所有交互元素提供焦点指示器
3. THE Admin_Panel SHALL 为图标提供文字替代（aria-label）
4. THE Admin_Panel SHALL 确保颜色对比度符合 WCAG AA
5. THE Admin_Panel SHALL 为表单元素关联正确的标签
