# Design Document

## Introduction

本设计文档定义 SubNotifyHub 管理面板的完整前端架构，采用 Bento Grid 布局 + OLED 深色模式 + Swiss 极简排版的设计风格。

## 项目能力概述

基于后端代码分析，SubNotifyHub 具备以下核心能力：

### 核心功能模块
1. **Emby Webhook 通知** - 接收 Emby 入库事件，推送到 Telegram
2. **Telegram Bot** - 支持 polling/webhook 模式，处理用户命令
3. **豆瓣热榜订阅** - 10+ 内置榜单，支持自定义订阅、回填、忽略列表
4. **MediaHelp 联动** - 自动订阅、季度过滤、订阅缓存
5. **115 云盘集成** - 扫码登录、离线下载、分享解析

### 数据模型
- **NotificationContent** - 通知内容（媒体信息、封面、详情链接）
- **HotlistItem** - 热榜条目（subject_id, title, rating, cover）
- **Settings** - 配置项（50+ 配置键，分组管理）

### API 端点
- `/admin/recent.json` - 最近入库媒体
- `/admin/settings` - 基础配置保存
- `/admin/forward-settings` - 联动配置保存
- `/admin/tg-bot-settings` - Bot 配置保存
- `/admin/hotlist.json` - 热榜数据（内置榜单 + 订阅列表 + 快照）
- `/admin/hotlist/add|delete|patch|backfill_next` - 热榜操作
- `/admin/tg-bot/115/qrcode/start|poll` - 115 扫码登录
- `/admin/tg-bot/mediahelp/login|test` - MediaHelp 登录测试

## Architecture Overview

### 技术栈

- **模板引擎**: Jinja2 (FastAPI templates)
- **样式方案**: 原生 CSS + CSS Variables (无框架依赖)
- **交互逻辑**: 原生 JavaScript ES6+ (无框架依赖)
- **图标系统**: Lucide Icons (SVG inline)

### 文件结构

```
static/
├── css/
│   ├── variables.css      # CSS 变量定义
│   ├── base.css           # 基础样式重置
│   ├── layout.css         # 布局系统
│   ├── components.css     # 组件样式
│   └── pages.css          # 页面特定样式
├── js/
│   ├── app.js             # 应用入口
│   ├── api.js             # API 请求封装
│   ├── components.js      # 组件逻辑
│   ├── toast.js           # Toast 通知
│   └── theme.js           # 主题切换
templates/
├── base.html              # 基础模板
├── components/
│   ├── sidebar.html       # 侧边导航
│   ├── card.html          # 卡片组件
│   ├── form.html          # 表单组件
│   ├── modal.html         # 模态框组件
│   └── icons.html         # 图标宏
└── pages/
    ├── admin_dashboard.html   # 概览仪表盘
    ├── admin_settings.html    # 基础设置
    ├── admin_forward.html     # 联动设置
    ├── admin_bot.html         # Bot 配置
    ├── admin_hotlist_new.html # 热榜管理
    └── admin_login.html       # 登录页面
```


## Design System

### CSS Variables

```css
:root {
  /* === 颜色系统 === */
  /* 品牌色 */
  --color-primary: #22c55e;
  --color-primary-hover: #16a34a;
  --color-primary-light: rgba(34, 197, 94, 0.1);
  
  /* 中性色 - 深色模式 */
  --color-bg-base: #0a0a0b;
  --color-bg-elevated: #141416;
  --color-bg-card: #1a1a1d;
  --color-bg-hover: #242428;
  --color-border: #2a2a2e;
  --color-border-light: #3a3a3e;
  
  /* 文字色 */
  --color-text-primary: #fafafa;
  --color-text-secondary: #a1a1aa;
  --color-text-tertiary: #71717a;
  --color-text-disabled: #52525b;
  
  /* 语义色 */
  --color-success: #22c55e;
  --color-warning: #f59e0b;
  --color-error: #ef4444;
  --color-info: #3b82f6;
  
  /* === 间距系统 (8px 基准) === */
  --space-1: 4px;
  --space-2: 8px;
  --space-3: 12px;
  --space-4: 16px;
  --space-5: 20px;
  --space-6: 24px;
  --space-8: 32px;
  --space-10: 40px;
  --space-12: 48px;
  
  /* === 字体系统 === */
  --font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
  --font-mono: "SF Mono", Monaco, "Cascadia Code", monospace;
  
  --font-size-xs: 12px;
  --font-size-sm: 14px;
  --font-size-base: 16px;
  --font-size-lg: 18px;
  --font-size-xl: 20px;
  --font-size-2xl: 24px;
  --font-size-3xl: 30px;
  
  --font-weight-normal: 400;
  --font-weight-medium: 500;
  --font-weight-semibold: 600;
  --font-weight-bold: 700;
  
  --line-height-tight: 1.25;
  --line-height-normal: 1.5;
  --line-height-relaxed: 1.75;
  
  /* === 圆角系统 === */
  --radius-sm: 6px;
  --radius-md: 12px;
  --radius-lg: 16px;
  --radius-xl: 24px;
  --radius-full: 9999px;
  
  /* === 阴影系统 === */
  --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.3);
  --shadow-md: 0 4px 6px rgba(0, 0, 0, 0.4);
  --shadow-lg: 0 10px 15px rgba(0, 0, 0, 0.5);
  --shadow-card: 0 2px 8px rgba(0, 0, 0, 0.3);
  --shadow-card-hover: 0 8px 24px rgba(0, 0, 0, 0.4);
  
  /* === 过渡动画 === */
  --transition-fast: 150ms ease;
  --transition-normal: 200ms ease;
  --transition-slow: 300ms ease;
  
  /* === 布局尺寸 === */
  --sidebar-width: 240px;
  --sidebar-collapsed: 64px;
  --header-height: 64px;
  --content-max-width: 1400px;
}
```


### 浅色模式变量

```css
[data-theme="light"] {
  --color-bg-base: #f5f5f7;
  --color-bg-elevated: #ffffff;
  --color-bg-card: #ffffff;
  --color-bg-hover: #f0f0f2;
  --color-border: #e5e5e7;
  --color-border-light: #d4d4d8;
  
  --color-text-primary: #18181b;
  --color-text-secondary: #52525b;
  --color-text-tertiary: #71717a;
  --color-text-disabled: #a1a1aa;
  
  --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
  --shadow-md: 0 4px 6px rgba(0, 0, 0, 0.07);
  --shadow-lg: 0 10px 15px rgba(0, 0, 0, 0.1);
  --shadow-card: 0 2px 8px rgba(0, 0, 0, 0.06);
  --shadow-card-hover: 0 8px 24px rgba(0, 0, 0, 0.12);
}
```

## Component Specifications

### 1. 侧边导航栏 (Sidebar)

**结构**:
```html
<aside class="sidebar">
  <div class="sidebar-header">
    <div class="logo">
      <svg><!-- Logo Icon --></svg>
      <span class="logo-text">SubNotifyHub</span>
    </div>
  </div>
  <nav class="sidebar-nav">
    <a href="/admin" class="nav-item active">
      <svg><!-- Icon --></svg>
      <span>概览</span>
    </a>
    <!-- 更多导航项 -->
  </nav>
  <div class="sidebar-footer">
    <button class="theme-toggle">
      <svg><!-- Theme Icon --></svg>
    </button>
    <button class="logout-btn">
      <svg><!-- Logout Icon --></svg>
      <span>退出</span>
    </button>
  </div>
</aside>
```

**样式规范**:
- 宽度: 240px (固定)
- 背景: var(--color-bg-elevated)
- 导航项高度: 44px
- 导航项圆角: var(--radius-md)
- 激活态: 左侧 3px 品牌色指示条 + 浅色背景
- 悬停态: var(--color-bg-hover)

### 2. 卡片组件 (Card)

**变体**:

#### 标准卡片
```html
<div class="card">
  <div class="card-header">
    <h3 class="card-title">标题</h3>
    <div class="card-actions"><!-- 操作按钮 --></div>
  </div>
  <div class="card-body">
    <!-- 内容 -->
  </div>
</div>
```

#### 统计卡片
```html
<div class="card card-stat">
  <div class="stat-icon">
    <svg><!-- Icon --></svg>
  </div>
  <div class="stat-content">
    <span class="stat-value">128</span>
    <span class="stat-label">最近入库</span>
  </div>
</div>
```

#### 媒体卡片
```html
<div class="card card-media">
  <div class="media-cover">
    <img src="cover.jpg" alt="封面" loading="lazy">
    <span class="media-badge">电影</span>
  </div>
  <div class="media-info">
    <h4 class="media-title">标题</h4>
    <p class="media-meta">2024 · 剧情</p>
  </div>
</div>
```

**样式规范**:
- 背景: var(--color-bg-card)
- 边框: 1px solid var(--color-border)
- 圆角: var(--radius-lg)
- 内边距: var(--space-5)
- 悬停: transform: translateY(-2px) + shadow-card-hover


### 3. 表单组件 (Form)

#### 输入框
```html
<div class="form-group">
  <label class="form-label" for="input-id">标签</label>
  <div class="input-wrapper">
    <input type="text" id="input-id" class="form-input" placeholder="占位文字">
    <button class="input-action" type="button">
      <svg><!-- 操作图标 --></svg>
    </button>
  </div>
  <p class="form-hint">提示文字</p>
  <p class="form-error">错误信息</p>
</div>
```

#### 开关
```html
<label class="switch">
  <input type="checkbox">
  <span class="switch-slider"></span>
  <span class="switch-label">启用功能</span>
</label>
```

#### 下拉选择
```html
<div class="form-group">
  <label class="form-label">选择项</label>
  <select class="form-select">
    <option value="">请选择</option>
    <option value="1">选项一</option>
  </select>
</div>
```

**样式规范**:
- 输入框高度: 44px
- 边框: 1px solid var(--color-border)
- 圆角: var(--radius-md)
- 焦点态: border-color: var(--color-primary) + box-shadow
- 错误态: border-color: var(--color-error)
- 禁用态: opacity: 0.5 + cursor: not-allowed

### 4. 按钮组件 (Button)

**变体**:
```html
<!-- 主按钮 -->
<button class="btn btn-primary">保存设置</button>

<!-- 次按钮 -->
<button class="btn btn-secondary">取消</button>

<!-- 危险按钮 -->
<button class="btn btn-danger">删除</button>

<!-- 幽灵按钮 -->
<button class="btn btn-ghost">更多</button>

<!-- 图标按钮 -->
<button class="btn btn-icon" aria-label="刷新">
  <svg><!-- Icon --></svg>
</button>

<!-- 加载状态 -->
<button class="btn btn-primary loading" disabled>
  <span class="spinner"></span>
  <span>保存中...</span>
</button>
```

**样式规范**:
- 高度: 40px (默认), 36px (小), 48px (大)
- 内边距: 0 var(--space-4)
- 圆角: var(--radius-md)
- 主按钮: bg: var(--color-primary), color: white
- 次按钮: bg: transparent, border: 1px solid var(--color-border)
- 悬停: 亮度调整 + 轻微上移

### 5. 模态框 (Modal)

```html
<div class="modal-overlay" data-modal="example">
  <div class="modal" role="dialog" aria-modal="true">
    <div class="modal-header">
      <h2 class="modal-title">标题</h2>
      <button class="modal-close" aria-label="关闭">
        <svg><!-- X Icon --></svg>
      </button>
    </div>
    <div class="modal-body">
      <!-- 内容 -->
    </div>
    <div class="modal-footer">
      <button class="btn btn-secondary">取消</button>
      <button class="btn btn-primary">确认</button>
    </div>
  </div>
</div>
```

**样式规范**:
- 遮罩: rgba(0, 0, 0, 0.6) + backdrop-filter: blur(4px)
- 模态框宽度: 480px (默认), 640px (大), 320px (小)
- 圆角: var(--radius-xl)
- 动画: fadeIn + scaleUp (200ms)


### 6. Toast 通知

```html
<div class="toast-container">
  <div class="toast toast-success">
    <svg class="toast-icon"><!-- Check Icon --></svg>
    <span class="toast-message">保存成功</span>
    <button class="toast-close" aria-label="关闭">
      <svg><!-- X Icon --></svg>
    </button>
  </div>
</div>
```

**样式规范**:
- 位置: 右上角, top: 24px, right: 24px
- 宽度: 320px (最大)
- 圆角: var(--radius-md)
- 动画: slideInRight (300ms)
- 自动消失: 3000ms
- 堆叠间距: var(--space-2)

### 7. 数据表格 (Table)

```html
<div class="table-wrapper">
  <table class="table">
    <thead>
      <tr>
        <th class="sortable" data-sort="name">
          名称
          <svg class="sort-icon"><!-- Sort Icon --></svg>
        </th>
        <th>状态</th>
        <th>操作</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td>数据</td>
        <td><span class="badge badge-success">启用</span></td>
        <td>
          <div class="table-actions">
            <button class="btn btn-icon btn-ghost">编辑</button>
            <button class="btn btn-icon btn-ghost">删除</button>
          </div>
        </td>
      </tr>
    </tbody>
  </table>
</div>
```

**样式规范**:
- 表头背景: var(--color-bg-elevated)
- 行高: 52px
- 边框: 1px solid var(--color-border)
- 悬停行: var(--color-bg-hover)
- 响应式: 水平滚动 (overflow-x: auto)

## Page Layouts

### Bento Grid 系统

```css
.bento-grid {
  display: grid;
  gap: var(--space-4);
  grid-template-columns: repeat(12, 1fr);
}

/* 卡片跨度 */
.bento-1 { grid-column: span 1; }
.bento-2 { grid-column: span 2; }
.bento-3 { grid-column: span 3; }
.bento-4 { grid-column: span 4; }
.bento-6 { grid-column: span 6; }
.bento-8 { grid-column: span 8; }
.bento-12 { grid-column: span 12; }

/* 响应式 */
@media (max-width: 1024px) {
  .bento-grid { grid-template-columns: repeat(6, 1fr); }
  .bento-4, .bento-6 { grid-column: span 6; }
  .bento-8 { grid-column: span 6; }
}

@media (max-width: 768px) {
  .bento-grid { grid-template-columns: 1fr; }
  .bento-1, .bento-2, .bento-3, .bento-4, 
  .bento-6, .bento-8, .bento-12 { grid-column: span 1; }
}
```


### 概览仪表盘布局（SubNotifyHub 特色设计）

**设计理念：** 简洁、信息密度适中、视觉层次分明

```
┌─────────────────────────────────────────────────────────────────────────┐
│  ┌─ Logo ─┐                                          🔍  🌙  ⚙️  👤    │
│  │ SNH    │   控制台   设置   联动   Bot   热榜                         │
│  └────────┘   ═══════                                                   │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │  � 欢迎回─来                                          v1.2.3 运行中 │  │
│  │  ════════════════════════════════════════════════════════════════ │  │
│  │                                                                    │  │
│  │  ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ ┌─────────────┐ │  │
│  │  │ 🎬 12      │ │ 📺 8       │ │ 🔥 5       │ │ ☁️ 已连接   │ │  │
│  │  │ 今日入库   │ │ 热榜订阅   │ │ 待处理     │ │ 115云盘    │ │  │
│  │  │ ↑3 vs 昨日 │ │ 3个榜单活跃│ │ 回填任务   │ │ Cookie有效 │ │  │
│  │  └─────────────┘ └─────────────┘ └─────────────┘ └─────────────┘ │  │
│  └──────────────────────────────────────────────────────────────────┘  │
│                                                                         │
│  ┌────────────────────────────────────┐ ┌───────────────────────────┐  │
│  │ 🎬 最近入库                  全部 ▼│ │ 📊 服务状态               │  │
│  │ ──────────────────────────────────│ │ ─────────────────────────  │  │
│  │ ┌────────────────────────────────┐│ │                           │  │
│  │ │ ┌─────┐ 流浪地球2              ││ │ Emby      ● 已连接        │  │
│  │ │ │ 🎬  │ 电影 · 2023 · 科幻     ││ │ Telegram  ● Polling 模式  │  │
│  │ │ │     │ 2小时前入库            ││ │ MediaHelp ○ 未配置        │  │
│  │ │ └─────┘                        ││ │ 115云盘   ● Cookie有效    │  │
│  │ ├────────────────────────────────┤│ │                           │  │
│  │ │ ┌─────┐ 繁花 E01-E08           ││ │ ─────────────────────────  │  │
│  │ │ │ 📺  │ 剧集 · 2024 · 剧情     ││ │ 📈 本周入库               │  │
│  │ │ │     │ 5小时前入库            ││ │                           │  │
│  │ │ └─────┘                        ││ │ 电影  ████████░░  32      │  │
│  │ ├────────────────────────────────┤│ │ 剧集  ██████░░░░  24      │  │
│  │ │ ┌─────┐ 周处除三害             ││ │ 其他  ██░░░░░░░░  8       │  │
│  │ │ │ 🎬  │ 电影 · 2024 · 动作     ││ │                           │  │
│  │ │ │     │ 1天前入库              ││ │                           │  │
│  │ │ └─────┘                        ││ │                           │  │
│  │ └────────────────────────────────┘│ └───────────────────────────┘  │
│  │                        查看全部 → │                                 │
│  └────────────────────────────────────┘                                │
│                                                                         │
│  ┌──────────────────────────────────────────────────────────────────┐  │
│  │ 🔥 热门榜单动态                                                   │  │
│  │ ──────────────────────────────────────────────────────────────── │  │
│  │ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────┐│  │
│  │ │ 实时热门 │ │ 实时热门 │ │ 一周口碑 │ │ 华语剧集 │ │ Top250  ││  │
│  │ │ 电影     │ │ 电视     │ │ 电影榜   │ │ 周榜     │ │ 电影    ││  │
│  │ │ 🔴 3新   │ │ 🔴 5新   │ │ ● 已订阅 │ │ ○ 未订阅 │ │ ● 已订阅││  │
│  │ └──────────┘ └──────────┘ └──────────┘ └──────────┘ └──────────┘│  │
│  └──────────────────────────────────────────────────────────────────┘  │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

**设计亮点：**
1. **顶部导航** - Logo + 标签导航 + 快捷操作，简洁高效
2. **欢迎横幅** - 显示版本和运行状态，4个关键指标卡片
3. **最近入库列表** - 左侧列表式展示，信息更完整（封面+标题+元信息+时间）
4. **服务状态面板** - 右侧显示各服务连接状态 + 本周入库统计条形图
5. **热门榜单动态** - 底部横向展示订阅的榜单，显示新增数量

### 设置页面布局（标签导航风格）

```
┌─────────────────────────────────────────────────────────────────────────┐
│  顶部导航栏                                                    搜索 设置 │
│  ┌──────┬──────┬──────┬──────┬──────┐                                   │
│  │ 控制台│ 设置 │ 联动 │ Bot  │ 热榜 │  ← 当前高亮                       │
│  └──────┴──────┴──────┴──────┴──────┘                                   │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌─────────────────────────────────┐  ┌─────────────────────────────┐  │
│  │ 🎬 Emby 配置                    │  │ 📱 Telegram 配置            │  │
│  │                                 │  │                             │  │
│  │ Emby 地址                       │  │ Bot Token                   │  │
│  │ ┌─────────────────────────────┐│  │ ┌─────────────────────────┐ │  │
│  │ │ http:// │ 192.168.1.1:8096 ││  │ │ ●●●●●●●●●●●●●●●●●●●●●● 👁│ │  │
│  │ └─────────────────────────────┘│  │ └─────────────────────────┘ │  │
│  │                                 │  │                             │  │
│  │ API Key                         │  │ Chat ID                     │  │
│  │ ┌─────────────────────────────┐│  │ ┌─────────────────────────┐ │  │
│  │ │ ●●●●●●●●●●●●●●●●●●●●●● 👁  ││  │ │ -1001234567890          │ │  │
│  │ └─────────────────────────────┘│  │ └─────────────────────────┘ │  │
│  └─────────────────────────────────┘  └─────────────────────────────┘  │
│                                                                         │
│  ┌─────────────────────────────────┐  ┌─────────────────────────────┐  │
│  │ 🔔 通知配置                     │  │ ⚙️ 高级配置                  │  │
│  │                                 │  │                             │  │
│  │ ☑ 启用通知聚合                  │  │ 日志级别                    │  │
│  │ ☑ 启用去重                      │  │ ┌─────────────────────────┐ │  │
│  │                                 │  │ │ INFO              ▼    │ │  │
│  │ 聚合窗口（秒）                  │  │ └─────────────────────────┘ │  │
│  │ ┌─────────────────────────────┐│  │                             │  │
│  │ │ 30                          ││  │ TMDB API Key                │  │
│  │ └─────────────────────────────┘│  │ ┌─────────────────────────┐ │  │
│  └─────────────────────────────────┘  │ │ ●●●●●●●●●●●●●●●●●● 👁  │ │  │
│                                       │ └─────────────────────────┘ │  │
│                                       └─────────────────────────────┘  │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │                                              [重置] [保存设置]  │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### 热榜管理布局（标签导航风格）

```
┌─────────────────────────────────────────────────────────────────────────┐
│  顶部导航栏                                                    搜索 设置 │
│  ┌──────┬──────┬──────┬──────┬──────┐                                   │
│  │ 控制台│ 设置 │ 联动 │ Bot  │ 热榜 │  ← 当前高亮                       │
│  └──────┴──────┴──────┴──────┴──────┘                                   │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │ 📋 内置榜单                                        Chat ID: ▼   │   │
│  │ ┌─────────┬─────────┬─────────┬─────────┬─────────┬─────────┐  │   │
│  │ │ 🔥      │ 📺      │ ⭐      │ 🎬      │ 🌏      │ 🎭      │  │   │
│  │ │ 实时热门│ 实时热门│ 一周口碑│ 华语口碑│ 全球口碑│ 国内综艺│  │   │
│  │ │ 电影    │ 电视    │ 电影榜  │ 剧集榜  │ 剧集榜  │ 榜      │  │   │
│  │ │ [订阅]  │ [已订阅]│ [订阅]  │ [订阅]  │ [订阅]  │ [订阅]  │  │   │
│  │ └─────────┴─────────┴─────────┴─────────┴─────────┴─────────┘  │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
│  ┌─────────────────────────────────────────────────────────────────┐   │
│  │ 📊 我的订阅                                         [添加订阅]  │   │
│  │ ┌───────────────────────────────────────────────────────────┐  │   │
│  │ │ 榜单名称      │ 模式     │ 策略    │ 通知 │ 忽略 │ 操作   │  │   │
│  │ ├───────────────┼──────────┼─────────┼──────┼──────┼────────┤  │   │
│  │ │ 实时热门电视  │ 增量     │ 仅新增  │ ✓    │ 12   │ ⚙ 🗑  │  │   │
│  │ │ 一周口碑电影  │ 摘要     │ 分页    │ ✓    │ 5    │ ⚙ 🗑  │  │   │
│  │ │ 豆瓣Top250    │ 增量     │ 分页    │ ✓    │ 0    │ ⚙ 🗑  │  │   │
│  │ └───────────────────────────────────────────────────────────┘  │   │
│  │                                                                 │   │
│  │ 空状态: 暂无订阅，点击上方榜单卡片或"添加订阅"按钮开始          │   │
│  └─────────────────────────────────────────────────────────────────┘   │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```


## API Integration

### API 请求封装

```javascript
// api.js
const API = {
  async request(url, options = {}) {
    const defaults = {
      headers: { 'Content-Type': 'application/json' },
      credentials: 'same-origin'
    };
    const response = await fetch(url, { ...defaults, ...options });
    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.detail || `HTTP ${response.status}`);
    }
    return response.json();
  },

  // 概览
  getRecent: () => API.request('/admin/recent.json'),

  // 设置 (表单提交，非 JSON)
  // saveSettings 使用原生 form submit

  // 热榜
  getHotlist: () => API.request('/admin/hotlist.json'),
  addHotlist: (data) => API.request('/admin/hotlist/add', {
    method: 'POST', body: JSON.stringify(data)
  }),
  deleteHotlist: (data) => API.request('/admin/hotlist/delete', {
    method: 'POST', body: JSON.stringify(data)
  }),
  patchHotlist: (data) => API.request('/admin/hotlist/patch', {
    method: 'POST', body: JSON.stringify(data)
  }),
  backfillHotlist: (data) => API.request('/admin/hotlist/backfill_next', {
    method: 'POST', body: JSON.stringify(data)
  }),

  // Bot 配置
  // saveTgBotSettings 使用原生 form submit
  start115QRCode: () => API.request('/admin/tg-bot/115/qrcode/start', {
    method: 'POST'
  }),
  poll115QRCode: () => API.request('/admin/tg-bot/115/qrcode/poll'),

  // MediaHelp
  loginMediaHelp: (data) => API.request('/admin/tg-bot/mediahelp/login', {
    method: 'POST', body: JSON.stringify(data)
  }),
  testMediaHelp: () => API.request('/admin/tg-bot/mediahelp/test'),
  // saveForwardSettings 使用原生 form submit

  // 认证
  login: (data) => API.request('/admin/login', {
    method: 'POST', body: JSON.stringify(data)
  }),
  logout: () => API.request('/admin/logout', { method: 'POST' }),
  changePassword: (data) => API.request('/admin/change-password', {
    method: 'POST', body: JSON.stringify(data)
  })
};
```

### 配置项分组

基于 `settings/*.py` 分析，配置项分为以下组：

**基础设置页面 (admin_settings.html)**
- Emby 配置: EMBY_BASE_URL, EMBY_API_KEY, EMBY_WAIT_FOR_IMAGE_*
- Telegram 配置: TG_BOT_TOKEN, TG_CHAT_ID, TG_PARSE_MODE
- 通知配置: NOTIFIER_*, DEDUP_*, WEBHOOK_*
- 高级配置: LOG_LEVEL, TMDB_API_KEY, ADULT_*

**联动设置页面 (admin_forward.html)**
- MediaHelp: MEDIAHELP_BASE, MEDIAHELP_TOKEN (运行时)
- Forward Bridge: FORWARD_BRIDGE_ENABLED, ENABLE_SEASON_FILTER

**Bot 配置页面 (admin_bot.html)**
- TG Bot: TG_BOT_INBOUND_ENABLED, TG_BOT_MODE, TG_BOT_ALLOWED_USER_IDS
- 115 云盘: CLOUD115_COOKIE, CLOUD115_DIR_MODE, CLOUD115_TARGET_*

### 热榜数据结构

```typescript
// /admin/hotlist.json 响应
interface HotlistResponse {
  ok: boolean;
  builtins: Array<{
    key: string;      // "movie_real_time_hotest"
    title: string;    // "实时热门电影"
    url: string;      // "https://m.douban.com/subject_collection/..."
  }>;
  subs: Array<{
    chat_id: number;
    list_key: string;
    list_url: string;
    mode: "incremental" | "digest";
    filters: {
      sub_policy: "new_only" | "paged";
      notify: boolean;
      notify_new_items: boolean;
      notify_auto_result: boolean;
      baseline_ready: boolean;
      backfill_cursor: number;
    };
    created_ts: number;
    updated_ts: number;
  }>;
  snapshots: Record<string, {
    list_key: string;
    list_title: string;
    last_success_ts: number;
    last_items: Array<HotlistItem>;
    last_error_ts: number;
    last_error_reason: string;
  }>;
  ignore_counts: Record<string, number>;  // "chat_id::list_key" -> count
  pref_chat_id: number;
}
```

## Accessibility

### 键盘导航

- Tab 顺序遵循视觉流
- 所有交互元素可通过 Tab 聚焦
- Enter/Space 激活按钮和链接
- Escape 关闭模态框和下拉菜单
- 方向键导航菜单项

### ARIA 属性

```html
<!-- 导航 -->
<nav aria-label="主导航">
  <a href="/admin" aria-current="page">概览</a>
</nav>

<!-- 模态框 -->
<div role="dialog" aria-modal="true" aria-labelledby="modal-title">
  <h2 id="modal-title">标题</h2>
</div>

<!-- 表单 -->
<div class="form-group">
  <label id="label-name" for="input-name">名称</label>
  <input id="input-name" aria-labelledby="label-name" aria-describedby="hint-name">
  <p id="hint-name">提示信息</p>
</div>

<!-- 加载状态 -->
<button aria-busy="true" aria-disabled="true">
  <span class="spinner" aria-hidden="true"></span>
  加载中...
</button>

<!-- Toast -->
<div role="alert" aria-live="polite">保存成功</div>
```

### 焦点管理

```css
/* 焦点指示器 */
:focus-visible {
  outline: 2px solid var(--color-primary);
  outline-offset: 2px;
}

/* 跳过链接 */
.skip-link {
  position: absolute;
  top: -40px;
  left: 0;
  z-index: 100;
}
.skip-link:focus {
  top: 0;
}
```


## Responsive Design

### 断点定义

```css
/* Mobile First */
/* Base: < 768px (mobile) */

@media (min-width: 768px) {
  /* Tablet: 768px - 1024px */
}

@media (min-width: 1024px) {
  /* Desktop: > 1024px */
}
```

### 移动端适配

**侧边栏**:
- 默认隐藏，通过汉堡菜单触发
- 全屏覆盖式抽屉
- 点击遮罩或导航项后关闭

**底部导航** (可选):
```html
<nav class="bottom-nav">
  <a href="/admin" class="bottom-nav-item active">
    <svg><!-- Icon --></svg>
    <span>概览</span>
  </a>
  <!-- 更多项 -->
</nav>
```

**触摸优化**:
- 最小触摸目标: 44x44px
- 增大按钮和链接的点击区域
- 禁用 hover 效果 (使用 @media (hover: hover))

### iOS 安全区域

```css
.sidebar {
  padding-bottom: env(safe-area-inset-bottom);
}

.bottom-nav {
  padding-bottom: env(safe-area-inset-bottom);
}

.modal {
  padding: env(safe-area-inset-top) env(safe-area-inset-right) 
           env(safe-area-inset-bottom) env(safe-area-inset-left);
}
```

## Animation & Transitions

### 微交互动画

```css
/* 卡片悬停 */
.card {
  transition: transform var(--transition-normal), 
              box-shadow var(--transition-normal);
}
.card:hover {
  transform: translateY(-2px);
  box-shadow: var(--shadow-card-hover);
}

/* 按钮点击 */
.btn:active {
  transform: scale(0.98);
}

/* 开关切换 */
.switch-slider {
  transition: background-color var(--transition-fast);
}
.switch-slider::before {
  transition: transform var(--transition-fast);
}

/* 主题切换 */
* {
  transition: background-color var(--transition-normal),
              border-color var(--transition-normal),
              color var(--transition-normal);
}
```

### 页面过渡

```css
/* 模态框 */
.modal-overlay {
  opacity: 0;
  transition: opacity var(--transition-normal);
}
.modal-overlay.active {
  opacity: 1;
}

.modal {
  transform: scale(0.95) translateY(10px);
  transition: transform var(--transition-normal);
}
.modal-overlay.active .modal {
  transform: scale(1) translateY(0);
}

/* Toast 滑入 */
@keyframes slideInRight {
  from {
    transform: translateX(100%);
    opacity: 0;
  }
  to {
    transform: translateX(0);
    opacity: 1;
  }
}

.toast {
  animation: slideInRight var(--transition-slow) ease-out;
}
```

## Testing Correctness Properties

### 功能正确性

1. **主题切换**: 切换主题后，所有颜色变量正确应用，localStorage 持久化
2. **表单提交**: 提交后显示加载状态，成功/失败显示对应 Toast
3. **API 错误处理**: 网络错误、服务器错误显示友好提示
4. **导航状态**: 当前页面导航项正确高亮
5. **响应式**: 各断点下布局正确切换

### 可访问性正确性

1. **键盘导航**: 所有功能可通过键盘完成
2. **焦点管理**: 模态框打开时焦点移入，关闭时焦点返回触发元素
3. **屏幕阅读器**: 所有交互元素有正确的 ARIA 标签
4. **颜色对比度**: 文字与背景对比度 ≥ 4.5:1

### 性能正确性

1. **首屏加载**: CSS/JS 合理拆分，关键资源优先加载
2. **图片懒加载**: 媒体封面使用 loading="lazy"
3. **防抖节流**: 搜索输入、窗口 resize 事件正确防抖

## 后端扩展建议

基于前端需求，建议后端增加以下 API：

### 1. 系统状态 API
```python
@router.get("/admin/status.json")
async def admin_status_json():
    """返回系统运行状态，用于仪表盘统计卡片"""
    return {
        "ok": True,
        "recent_count": await recent_store.total_count(),
        "hotlist_sub_count": len(list_subscriptions()),
        "tg_bot_status": "polling" | "webhook" | "disabled",
        "mediahelp_status": "connected" | "disconnected",
        "cloud115_status": "logged_in" | "expired" | "not_configured",
        "uptime_seconds": int(time.time() - start_time),
    }
```

### 2. 配置元数据 API
```python
@router.get("/admin/settings-meta.json")
async def admin_settings_meta():
    """返回配置项元数据，用于动态表单生成"""
    return {
        "groups": [
            {
                "key": "emby",
                "title": "Emby 配置",
                "fields": [
                    {"key": "EMBY_BASE_URL", "type": "url", "required": True, "label": "Emby 地址"},
                    {"key": "EMBY_API_KEY", "type": "password", "required": True, "label": "API Key"},
                ]
            },
            # ...
        ]
    }
```

### 3. 热榜预览 API
```python
@router.get("/admin/hotlist/preview")
async def admin_hotlist_preview(list_key: str):
    """预览榜单内容（不订阅）"""
    items = await fetch_hotlist(list_key)
    return {"ok": True, "items": items}
```

这些 API 可以在后续迭代中实现，当前前端设计已考虑兼容性。
