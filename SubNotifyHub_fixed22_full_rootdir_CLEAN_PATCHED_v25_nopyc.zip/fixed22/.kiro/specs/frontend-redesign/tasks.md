# Implementation Plan: Frontend Redesign

## Overview

SubNotifyHub 管理面板前端重设计，采用 Bento Grid 布局 + OLED 深色模式 + 顶部标签导航的设计风格。

## Tasks

- [x] 1. 创建 CSS 变量系统
  - 创建 `static/css/variables.css`
  - 定义颜色、间距、字体、圆角、阴影、过渡变量
  - 定义深色模式变量（默认）和浅色模式变量
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 2.1, 2.2_

- [x] 2. 创建基础样式重置
  - 创建 `static/css/base.css`
  - 实现 CSS Reset、全局字体、焦点指示器、滚动条样式
  - _Requirements: 1.1, 16.2_

- [x] 3. 创建布局系统
  - 创建 `static/css/layout.css`
  - 实现顶部导航栏布局、Bento Grid 12列系统
  - 实现响应式断点和移动端适配
  - _Requirements: 3.1, 3.5, 15.1, 15.2, 15.3_

- [x] 4. 创建卡片组件样式
  - 在 `static/css/components.css` 添加卡片样式
  - 实现标准卡片、统计卡片、媒体卡片
  - 添加悬停效果和骨架屏状态
  - _Requirements: 9.1, 9.2, 9.3, 9.4, 9.5_

- [x] 5. 创建表单组件样式
  - 实现输入框、开关、下拉选择样式
  - 添加焦点、错误、禁用状态
  - _Requirements: 10.1, 10.2, 10.3, 10.4, 10.5_

- [x] 6. 创建按钮组件样式
  - 实现主按钮、次按钮、危险按钮、幽灵按钮、图标按钮
  - 实现加载状态
  - _Requirements: 11.1, 11.2, 11.3, 11.4, 11.5_

- [x] 7. 创建模态框组件样式
  - 实现遮罩层、模态框容器、打开/关闭动画
  - 支持多种尺寸
  - _Requirements: 12.1, 12.2, 12.3, 12.4, 12.5_

- [x] 8. 创建 Toast 通知样式
  - 实现 Toast 容器和四种类型样式
  - 添加滑入动画和堆叠布局
  - _Requirements: 13.1, 13.2, 13.5_

- [x] 9. 创建数据表格样式
  - 实现表格容器、排序图标、行悬停效果
  - 实现空状态和加载状态
  - _Requirements: 14.1, 14.2, 14.4, 14.5_

- [x] 10. 创建顶部导航组件样式
  - 实现导航栏容器、Logo区域、标签导航
  - 实现激活态下划线指示和右侧快捷操作区
  - _Requirements: 3.1, 3.2, 3.3, 3.4_

- [x] 11. 创建主题切换 JavaScript
  - 创建 `static/js/theme.js`
  - 实现主题检测、切换、持久化
  - _Requirements: 2.1, 2.2, 2.3, 2.4_

- [x] 12. 创建 Toast 通知 JavaScript
  - 创建 `static/js/toast.js`
  - 实现 show 方法、自动消失、手动关闭、堆叠管理
  - _Requirements: 13.1, 13.2, 13.3, 13.4, 13.5_

- [x] 13. 创建 API 请求封装
  - 创建 `static/js/api.js`
  - 封装所有 API 端点和错误处理
  - _Requirements: 4.1, 5.3, 6.2, 6.3, 7.3, 7.4, 8.1, 8.4, 8.5, 8.6, 8.7_

- [x] 14. 创建模态框 JavaScript
  - 创建 `static/js/components.js`
  - 实现 Modal 类、ESC关闭、遮罩关闭、焦点陷阱
  - _Requirements: 12.3, 12.4, 12.5_

- [x] 15. 创建基础模板
  - 创建 `templates/base.html`
  - 引入 CSS/JS、实现基础结构、跳过链接、主题初始化
  - _Requirements: 3.1, 16.1, 16.2_

- [x] 16. 创建顶部导航组件模板
  - 创建 `templates/components/navbar.html`
  - 实现 Logo、标签导航、快捷操作、移动端下拉菜单
  - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5_

- [x] 17. 创建卡片组件模板
  - 创建 `templates/components/card.html`
  - 实现标准卡片、统计卡片、媒体卡片、骨架屏宏
  - _Requirements: 9.1, 9.2, 9.3, 9.5_

- [x] 18. 创建表单组件模板
  - 创建 `templates/components/form.html`
  - 实现输入框、开关、下拉选择、表单组宏
  - _Requirements: 10.1, 10.2, 10.3, 10.5_

- [x] 19. 创建模态框组件模板
  - 创建 `templates/components/modal.html`
  - 实现模态框宏，支持多种尺寸
  - _Requirements: 12.1, 12.2_

- [x] 20. 创建图标系统
  - 创建 `templates/components/icons.html`
  - 定义 Lucide 图标宏，支持尺寸和颜色参数
  - _Requirements: 1.1, 3.2_

- [x] 21. 创建概览仪表盘页面
  - 创建 `templates/pages/admin_dashboard.html`
  - 实现欢迎横幅、统计卡片、最近入库列表、服务状态面板、热榜动态
  - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.7_

- [x] 22. 创建基础设置页面
  - 创建 `templates/pages/admin_settings.html`
  - 实现 Emby/Telegram/通知/高级配置卡片
  - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5_

- [x] 23. 创建联动设置页面
  - 创建 `templates/pages/admin_forward.html`
  - 实现 MediaHelp 连接状态、登录、测试连接
  - _Requirements: 6.1, 6.2, 6.3, 6.4, 6.5_

- [x] 24. 创建 Bot 配置页面
  - 创建 `templates/pages/admin_bot.html`
  - 实现 TG Bot 配置、115云盘配置、扫码登录
  - _Requirements: 7.1, 7.2, 7.3, 7.4, 7.5_

- [x] 25. 创建热榜管理页面
  - 创建 `templates/pages/admin_hotlist.html`
  - 实现内置榜单、订阅表格、添加/编辑/删除模态框
  - _Requirements: 8.1, 8.2, 8.3, 8.4, 8.5, 8.6, 8.7_

- [x] 26. 创建登录页面
  - 创建 `templates/pages/admin_login.html`
  - 实现登录表单、错误提示、强制改密
  - _Requirements: 5.3, 5.4, 5.5_

- [x] 27. 创建应用入口 JavaScript
  - 创建 `static/js/app.js`
  - 初始化主题、Toast、模态框系统
  - _Requirements: 4.1, 5.3, 6.2, 7.3, 8.4_

- [x] 28. 实现移动端响应式
  - 完善移动端导航下拉、触摸优化
  - _Requirements: 15.1, 15.2, 15.3, 15.4, 15.5_

- [x] 29. 实现可访问性增强
  - 添加 aria 属性、键盘导航、焦点陷阱
  - _Requirements: 16.1, 16.2, 16.3, 16.4, 16.5_

- [x] 30. 实现加载状态和骨架屏
  - 添加骨架屏动画、按钮加载状态、表格加载状态
  - _Requirements: 9.5, 14.5_

- [x] 31. 实现表单验证
  - 实现必填验证、格式验证、实时反馈
  - _Requirements: 5.5, 10.5_

- [x] 32. 实现密码字段切换
  - 实现密码显示/隐藏切换
  - _Requirements: 5.2_

- [x] 33. Checkpoint - 确保所有样式和组件正常工作
  - 检查所有 CSS 文件加载正确
  - 检查所有 JS 模块初始化正常
  - 检查主题切换功能

- [ ] 34. 集成测试 - 概览页面
  - 测试页面加载、API数据获取、响应式布局、主题切换
  - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5_
  - **需要手动测试**：启动应用后访问 /admin 页面验证

- [ ] 35. 集成测试 - 设置页面
  - 测试表单渲染、数据保存、验证反馈、Toast通知
  - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5_
  - **需要手动测试**：启动应用后访问 /admin/settings 页面验证

## Notes

- 所有任务都是必须完成的
- 每个任务引用具体的需求条款以便追踪
- Checkpoint 任务用于阶段性验证
