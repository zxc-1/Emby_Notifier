# Design Document: TMDB Lookup Refactor

## Overview

本设计文档描述了 `tmdb_lookup.py` 模块的拆分重构方案。目标是将 1344 行的单体模块拆分为多个职责单一的子模块，同时整合已有的优化模块，让所有优化真正生效。

### 设计目标

1. **模块化** - 将大函数拆分为独立模块，每个模块职责单一
2. **整合优化** - 让 `tmdb_lookup.py` 使用所有已有的优化模块
3. **消除重复** - 删除与优化模块重复的内部实现
4. **向后兼容** - 保持公共 API 不变，`usecase.py` 无需修改

### 重构前后对比

```
重构前 (1344 行):
┌─────────────────────────────────────────────────────────┐
│ tmdb_lookup.py                                          │
│ ├── pre_resolve_from_names_and_caches() (~400行)        │
│ │   ├── explicit TMDB ID extraction                     │
│ │   ├── IMDb ID lookup                                  │
│ │   ├── title-fingerprint cache                         │
│ │   ├── weak cached mapping                             │
│ │   └── global TV series cache                          │
│ └── build_candidate_sets() (~900行)                     │
│     ├── hint selection (~80行)                          │
│     ├── Stage-A/B execution (~150行)                    │
│     ├── candidate merging (~150行)                      │
│     ├── episode scoring (~100行) ← 重复实现             │
│     ├── year affinity (~50行)                           │
│     ├── fused score (~100行) ← 重复实现                 │
│     └── UI filtering (~40行)                            │
└─────────────────────────────────────────────────────────┘

重构后 (~300 行):
┌─────────────────────────────────────────────────────────┐
│ tmdb_lookup.py (协调层)                                 │
│ ├── pre_resolve_from_names_and_caches()                 │
│ │   └── 调用 pre_resolve.py                             │
│ └── build_candidate_sets()                              │
│     ├── 调用 hint_selection.py                          │
│     ├── 调用 stage_strategy.py (已存在)                 │
│     ├── 调用 candidate_merge.py                         │
│     ├── 调用 episode_scoring.py (已存在)                │
│     ├── 调用 consensus_scoring.py (已存在)              │
│     ├── 调用 anime_detection.py (已存在)                │
│     ├── 调用 sequel_detection.py (已存在)               │
│     ├── 调用 alias_matching.py (已存在)                 │
│     └── 调用 ui_filter.py                               │
└─────────────────────────────────────────────────────────┘
```

## Architecture

### 模块依赖图

```mermaid
graph TD
    subgraph "主入口"
        UL[usecase.py]
    end
    
    subgraph "协调层"
        TL[tmdb_lookup.py]
    end
    
    subgraph "新提取模块"
        PR[pre_resolve.py]
        HS[hint_selection.py]
        CM[candidate_merge.py]
        UF[ui_filter.py]
    end
    
    subgraph "已有优化模块"
        SS[stage_strategy.py]
        CS[consensus_scoring.py]
        ES[episode_scoring.py]
        HST[hint_strength.py]
        AD[anime_detection.py]
        SD[sequel_detection.py]
        AM[alias_matching.py]
        CV[cache_validation.py]
        EL[evidence_level.py]
        RT[retry.py]
        OB[observability.py]
    end
    
    subgraph "基础模块"
        HI[hints.py]
        SC[scoring.py]
        CO[constants.py]
    end
    
    UL --> TL
    TL --> PR
    TL --> HS
    TL --> CM
    TL --> UF
    TL --> SS
    TL --> ES
    TL --> CS
    TL --> AD
    TL --> SD
    TL --> AM
    TL --> OB
    
    PR --> CV
    PR --> RT
    HS --> SS
    HS --> HST
    CM --> CS
    UF --> HI
    
    PR --> CO
    HS --> CO
    CM --> CO
    UF --> CO

```

## Components and Interfaces

### 1. pre_resolve.py - 预解析模块

**职责**: 从外部 ID、缓存等来源快速解析 TMDB 匹配

```python
from __future__ import annotations
from typing import Any, Dict, List, Optional

async def pre_resolve_from_names_and_caches(
    *,
    q_title: str,
    q_year: Optional[int],
    season_hint_eff: Optional[int],
    tvish: bool,
    vc_reliable: bool,
    video_count: int,
    hints2: List[str],
    filename: str,
    hint_name: str,
    share_title: str,
    dir_path: List[str],
    cached_weak: Optional[Dict[str, Any]] = None,
    decision_trace: Optional[List[str]] = None,
) -> Dict[str, Any]:
    """预解析：从外部 ID 和缓存中快速解析 TMDB 匹配。
    
    Returns:
        Dict with:
        - picked: dict|None - 匹配结果
        - from_source: str|None - 来源
        - used_mt/used_title/used_year/used_season
        - cached_fp_tid: Optional[int] - 用于后续搜索的缓存 ID
        - seed_candidates: List[Dict] - 种子候选
    """
    pass

def extract_explicit_tmdb_id(
    sources: List[str],
) -> tuple[Optional[int], bool]:
    """从来源中提取显式 TMDB ID。
    
    Returns:
        Tuple of (tmdb_id, is_explicit_marker)
    """
    pass

def extract_imdb_id(
    sources: List[str],
) -> Optional[str]:
    """从来源中提取 IMDb ID。"""
    pass

def determine_media_type_preference(
    season_hint_eff: Optional[int],
    tvish: bool,
    vc_reliable: bool,
    video_count: int,
    hints2: List[str],
) -> str:
    """确定媒体类型偏好 (tv/movie)。"""
    pass
```

### 2. hint_selection.py - 提示选择模块

**职责**: 从多个提示池中选择最优的搜索提示

```python
from __future__ import annotations
from typing import Any, Dict, List, Optional, Tuple

def select_hints(
    hints_main: List[str],
    hints_msg: List[str],
    hints_extra: List[str],
    hints2: List[str],
    q_title: str,
) -> Tuple[List[str], Dict[str, str]]:
    """选择最强的提示用于 TMDB 搜索。
    
    Returns:
        Tuple of (selected_hints, hint_sources)
        - selected_hints: 选中的提示列表
        - hint_sources: 提示来源映射 {hint: "main"|"msg"|"extra"}
    """
    pass

def pick_primary_hint(
    selected_hints: List[str],
    hint_sources: Dict[str, str],
    strict_year: Optional[int],
) -> str:
    """选择主提示用于 Stage-A 搜索。"""
    pass

def compute_adaptive_hint_budget(
    main_hints: List[str],
    msg_hints: List[str],
    hints2: List[str],
) -> int:
    """计算自适应提示预算。"""
    pass

def extract_strict_year(
    hints: List[str],
) -> Optional[int]:
    """从 CJK 标题中提取严格年份，如 "剧名(2025)"。"""
    pass

def should_force_stage_b(
    hints_main: List[str],
    hints_msg: List[str],
    share_title: str,
) -> bool:
    """判断是否需要强制执行 Stage-B（双语证据）。"""
    pass
```

### 3. candidate_merge.py - 候选合并模块

**职责**: 跨提示合并候选结果，计算支持度和融合评分

```python
from __future__ import annotations
from typing import Any, Dict, List, Optional, Tuple

def merge_candidates(
    gmap: Dict[str, Dict[str, Any]],
    selected_hints: List[str],
    hint_sources: Dict[str, str],
) -> Dict[Tuple[int, str], Dict[str, Any]]:
    """合并来自多个提示的候选。
    
    Args:
        gmap: 提示 -> TMDB 搜索结果的映射
        selected_hints: 选中的提示列表
        hint_sources: 提示来源映射
    
    Returns:
        合并后的候选字典，键为 (tmdb_id, media_type)
    """
    pass

def inject_seeds(
    merged: Dict[Tuple[int, str], Dict[str, Any]],
    seeds: List[Dict[str, Any]],
) -> None:
    """将种子候选注入合并池（原地修改）。"""
    pass

def compute_top1_consensus(
    gmap: Dict[str, Dict[str, Any]],
    hint_sources: Dict[str, str],
) -> Dict[str, Tuple[int, str]]:
    """计算每个提示的 top-1 候选。
    
    Returns:
        Dict mapping hint -> (tmdb_id, media_type)
    """
    pass

def attach_top1_support(
    merged: Dict[Tuple[int, str], Dict[str, Any]],
    top1_by_hint: Dict[str, Tuple[int, str]],
    hint_sources: Dict[str, str],
) -> None:
    """附加 top-1 共识支持度指标（原地修改）。"""
    pass

def apply_evidence_fusion(
    merged: Dict[Tuple[int, str], Dict[str, Any]],
) -> None:
    """应用证据融合计算融合评分（原地修改）。"""
    pass
```

### 4. ui_filter.py - UI 过滤模块

**职责**: 过滤和排序展示候选

```python
from __future__ import annotations
from typing import Any, Dict, List

def filter_for_ui(
    cands_all: List[Dict[str, Any]],
    min_score: float = 0.60,
    min_coverage: float = 0.45,
    max_show: int = 8,
) -> List[Dict[str, Any]]:
    """过滤候选用于 UI 展示。
    
    规则:
    1. 过滤低于阈值的候选
    2. 过滤垃圾标题
    3. 如果没有候选通过阈值，显示 top-N 原始候选
    4. 确保 top-1 始终包含
    5. 限制最多 8 个候选
    
    Returns:
        过滤后的候选列表
    """
    pass

def is_ui_keepable(
    candidate: Dict[str, Any],
    min_score: float = 0.60,
    min_coverage: float = 0.45,
) -> bool:
    """判断候选是否应该保留在 UI 中。"""
    pass
```

## Data Models

### 现有数据模型（复用）

```python
# 来自 domain/tmdb_match/models.py
from dataclasses import dataclass
from enum import Enum
from typing import Any, Dict, List, Optional

class EvidenceLevel(Enum):
    L0 = 0  # 无证据
    L1 = 1  # 弱证据
    L2 = 2  # 中等证据
    L3 = 3  # 强证据

class HintSource(Enum):
    MAIN = "main"      # 主提示（视频文件名、季度文件夹）
    MSG = "msg"        # 消息提示（用户输入、URL 片段）
    EXTRA = "extra"    # 额外提示

@dataclass
class CandidateScoreBreakdown:
    base_score: float
    year_adjustment: float
    episode_score: float
    support_bonus: float
    anime_bonus: float
    sequel_penalty: float
    alias_bonus: float
    fused_score: float
```

### 新增数据模型

```python
@dataclass
class HintSelectionResult:
    """提示选择结果。"""
    selected_hints: List[str]
    hint_sources: Dict[str, str]
    primary_hint: str
    strict_year: Optional[int]
    force_stage_b: bool
    has_main_hint: bool

@dataclass
class MergeResult:
    """候选合并结果。"""
    merged: Dict[tuple, Dict[str, Any]]
    top1_by_hint: Dict[str, tuple]
    used_title: str
    used_year: Optional[int]
    used_mt: str
    used_season: Optional[int]

@dataclass
class PreResolveResult:
    """预解析结果。"""
    picked: Optional[Dict[str, Any]]
    from_source: Optional[str]
    used_mt: str
    used_title: str
    used_year: Optional[int]
    used_season: Optional[int]
    cached_fp_tid: Optional[int]
    seed_candidates: List[Dict[str, Any]]
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system-essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Pre-resolve Determinism

*For any* set of input parameters (q_title, q_year, hints, etc.), the pre-resolve function SHALL produce deterministic seed candidates - the same inputs always produce the same outputs.

**Validates: Requirements 1.2, 1.8**

### Property 2: Pre-resolve Early Return

*For any* pre-resolve execution, WHEN a valid match is found from any source (explicit ID, IMDb, cache), the function SHALL return immediately without checking subsequent sources.

**Validates: Requirements 1.7**

### Property 3: Hint Selection Stability

*For any* hint pools (main, msg, extra), the hint selection function SHALL produce stable results - selecting the same hints in the same order for identical inputs.

**Validates: Requirements 2.2, 2.3, 2.4**

### Property 4: Strict Year Extraction

*For any* CJK title containing an explicit year marker (e.g., "剧名(2025)"), the extraction function SHALL correctly identify and return the year as an integer.

**Validates: Requirements 2.7**

### Property 5: Candidate Merge Idempotence

*For any* set of candidates, merging the same candidates twice SHALL produce the same result as merging once.

**Validates: Requirements 3.2, 3.3**

### Property 6: Candidate Merge Commutativity

*For any* set of hints with candidates, the order in which hints are processed SHALL NOT affect the final merged result (same candidates, same support counts).

**Validates: Requirements 3.2**

### Property 7: Top-1 Consensus Correctness

*For any* merged candidate pool, the top-1 support metrics SHALL correctly reflect how many hints have that candidate as their top-1 result.

**Validates: Requirements 3.5**

### Property 8: UI Filter Top-1 Inclusion

*For any* candidate list with at least one candidate, the UI filter SHALL always include the top-1 candidate in the show list, regardless of whether it passes the threshold.

**Validates: Requirements 5.5**

### Property 9: UI Filter Threshold

*For any* candidate list, all candidates in the show list (except top-1) SHALL have score >= 0.60 AND coverage >= 0.45, OR the show list SHALL contain only raw top-N candidates when no candidates pass the threshold.

**Validates: Requirements 5.2, 5.4**

### Property 10: UI Filter Limit

*For any* candidate list, the show list SHALL never exceed 8 candidates.

**Validates: Requirements 5.6**

## Error Handling

### 错误处理策略

1. **TMDB API 错误** - 使用 `retry.py` 的重试机制
2. **缓存查询错误** - 记录日志，继续执行（降级到搜索）
3. **解析错误** - 记录日志，跳过该来源
4. **类型转换错误** - 使用默认值，记录日志

### 错误类型

```python
# 来自 retry.py
class TMDBAPIError(Exception):
    """TMDB API 基础错误。"""
    pass

class TMDBTimeoutError(TMDBAPIError):
    """TMDB API 超时错误。"""
    pass

class TMDBRateLimitError(TMDBAPIError):
    """TMDB API 限流错误。"""
    pass

class TMDBUnavailableError(TMDBAPIError):
    """TMDB API 不可用错误。"""
    pass
```

## Testing Strategy

### 测试方法

采用双重测试策略：
- **单元测试**: 验证特定示例和边界情况
- **属性测试**: 验证所有输入的通用属性

### 属性测试配置

- 使用 `hypothesis` 库
- 每个属性测试至少运行 100 次迭代
- 测试文件位于 `tests/property/`

### 测试文件结构

```
tests/property/
├── test_pre_resolve_properties.py      # Property 1, 2
├── test_hint_selection_properties.py   # Property 3, 4
├── test_candidate_merge_properties.py  # Property 5, 6, 7
└── test_ui_filter_properties.py        # Property 8, 9, 10
```

### 测试标注格式

每个属性测试必须包含注释引用设计文档中的属性：

```python
# Feature: tmdb-lookup-refactor, Property 1: Pre-resolve Determinism
# Validates: Requirements 1.2, 1.8
@given(...)
@settings(max_examples=100)
def test_pre_resolve_determinism(...):
    ...
```
