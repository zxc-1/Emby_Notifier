# Requirements Document

## Introduction

本规范定义了 `application/usecases/share_resolver/tmdb_lookup.py` 模块的拆分重构需求。该模块当前有 ~1344 行代码，职责过多，包含预解析、缓存查询、TMDB API 调用、候选合并、评分计算等多个功能。

### 现有模块分析

之前的 TMDB 识别优化 spec 创建了 14 个优化模块，但 `tmdb_lookup.py` **未使用大部分模块**，导致优化未生效：

| 模块 | 功能 | 当前使用情况 |
|------|------|-------------|
| `stage_strategy.py` | Stage-A/B 稳定性、双语检测 | ✅ 已被 tmdb_lookup.py 使用 |
| `consensus_scoring.py` | 支持权重计算、证据融合 | ❌ 未使用，内部有重复实现 |
| `episode_scoring.py` | 剧集评分 | ❌ 未使用，内部有重复实现 |
| `hint_strength.py` | 提示强度评估 | ❌ 未使用 |
| `anime_detection.py` | 动漫检测 | ❌ 未使用 |
| `sequel_detection.py` | 续集检测 | ❌ 未使用 |
| `alias_matching.py` | 别名匹配 | ❌ 未使用 |
| `cache_validation.py` | 缓存验证 | ❌ 未使用 |
| `evidence_level.py` | 证据等级 | ❌ 未使用 |
| `retry.py` | 重试机制 | ❌ 未使用 |
| `observability.py` | 可观测性 | ❌ 未使用 |
| `episode_dedup.py` | 剧集去重 | ❌ 未使用 |
| `autopick.py` | 自动选择决策 | ⚠️ 被 decide.py 使用 |
| `integration.py` | 优化入口 | ⚠️ 仅被测试使用，主流程未使用 |

### 重构策略

采用 **直接增强** 策略：让 `tmdb_lookup.py` 直接使用所有已有的优化模块，而不是创建并行流程。

1. **整合已有模块** - 让 `tmdb_lookup.py` 导入并使用所有优化模块，删除内部重复代码
2. **提取剩余逻辑** - 将预解析、提示选择、候选合并、UI 过滤提取到新模块
3. **废弃 integration.py** - 其功能合并到 tmdb_lookup.py
4. **保持向后兼容** - `usecase.py` 不需要修改

## Glossary

- **Pre_Resolver**: 预解析器，负责从外部 ID、缓存等来源快速解析 TMDB 匹配
- **Candidate_Merger**: 候选合并器，负责跨提示合并候选结果
- **Hint_Selector**: 提示选择器，负责从多个提示中选择最优的搜索提示
- **Episode_Scorer**: 剧集评分器，负责基于剧集一致性调整候选评分
- **UI_Filter**: UI 过滤器，负责过滤和排序展示候选
- **Seed_Candidate**: 种子候选，来自预解析阶段的验证候选（如显式 TMDB ID）
- **Stage_A**: 第一阶段搜索，使用主提示进行完整搜索
- **Stage_B**: 第二阶段搜索，使用次要提示进行轻量搜索
- **Fused_Score**: 融合评分，综合多个证据来源的最终评分

## Requirements

### Requirement 1: 预解析模块 (pre_resolve.py)

**User Story:** 作为开发者，我希望预解析逻辑被提取到独立模块，以便于单独测试和维护。

**当前状态:** `pre_resolve_from_names_and_caches()` 函数约 400 行，包含 5 个预解析来源。

#### Acceptance Criteria

1. THE Pre_Resolver SHALL be extracted to `application/usecases/share_resolver/pre_resolve.py`
2. THE Pre_Resolver SHALL handle explicit TMDB ID extraction from filenames and hints
3. THE Pre_Resolver SHALL handle IMDb ID lookup via TMDB /find endpoint
4. THE Pre_Resolver SHALL handle title-fingerprint cache validation
5. THE Pre_Resolver SHALL handle weak cached mapping validation
6. THE Pre_Resolver SHALL handle global TV series cache lookup
7. WHEN a pre-resolve source returns a valid match, THE Pre_Resolver SHALL return immediately without proceeding to search
8. THE Pre_Resolver SHALL return seed candidates for later competition with search results
9. THE Pre_Resolver SHALL preserve the existing function signature and return type
10. THE Pre_Resolver SHALL use `cache_validation.py` for cache hit validation

### Requirement 2: 提示选择模块 (hint_selection.py)

**User Story:** 作为开发者，我希望提示选择逻辑被提取到独立模块，以便于调整选择策略。

**当前状态:** 提示选择逻辑分散在 `build_candidate_sets()` 中约 80 行。

#### Acceptance Criteria

1. THE Hint_Selector SHALL be extracted to `application/usecases/share_resolver/hint_selection.py`
2. THE Hint_Selector SHALL select the strongest hints from main, msg, and extra hint pools
3. THE Hint_Selector SHALL implement adaptive hint budget based on hint quality
4. THE Hint_Selector SHALL track hint source (main/msg/extra) for weighting
5. THE Hint_Selector SHALL reuse `detect_bilingual_evidence()` from `stage_strategy.py`
6. THE Hint_Selector SHALL reuse `evaluate_hint_strength()` from `hint_strength.py`
7. THE Hint_Selector SHALL extract strict year from CJK titles with explicit year markers
8. THE Hint_Selector SHALL provide `select_hints()` and `pick_primary_hint()` functions

### Requirement 3: 候选合并模块 (candidate_merge.py)

**User Story:** 作为开发者，我希望候选合并逻辑被提取到独立模块，以便于理解评分融合机制。

**当前状态:** 候选合并逻辑在 `build_candidate_sets()` 中约 150 行。

#### Acceptance Criteria

1. THE Candidate_Merger SHALL be extracted to `application/usecases/share_resolver/candidate_merge.py`
2. THE Candidate_Merger SHALL merge candidates across multiple hints by (tmdb_id, media_type) key
3. THE Candidate_Merger SHALL track support counts and weights per candidate
4. THE Candidate_Merger SHALL inject seed candidates into the merged pool
5. THE Candidate_Merger SHALL compute top-1 consensus support metrics
6. THE Candidate_Merger SHALL reuse functions from `consensus_scoring.py`
7. THE Candidate_Merger SHALL provide `merge_candidates()` and `inject_seeds()` functions

### Requirement 4: 整合剧集评分 - 使用 episode_scoring.py

**User Story:** 作为开发者，我希望 `tmdb_lookup.py` 中的剧集评分逻辑使用已有的 `episode_scoring.py` 模块，消除重复代码。

**当前状态:** `episode_scoring.py` 已存在且功能完整，但 `build_candidate_sets()` 中有约 100 行重复的剧集评分逻辑。

#### Acceptance Criteria

1. THE tmdb_lookup.py SHALL import and use `enrich_episode_scores()` from `episode_scoring.py`
2. THE tmdb_lookup.py SHALL remove the internal `_apply_episode_score()` function
3. THE tmdb_lookup.py SHALL remove the internal `_season_total()` function
4. THE tmdb_lookup.py SHALL remove the internal `_year_score()` function
5. THE Episode_Scorer integration SHALL preserve existing behavior

### Requirement 5: UI 过滤模块 (ui_filter.py)

**User Story:** 作为开发者，我希望 UI 过滤逻辑被提取到独立模块，以便于调整展示策略。

**当前状态:** UI 过滤逻辑在 `build_candidate_sets()` 末尾约 40 行。

#### Acceptance Criteria

1. THE UI_Filter SHALL be extracted to `application/usecases/share_resolver/ui_filter.py`
2. THE UI_Filter SHALL prune candidates below score/coverage thresholds (score >= 0.60, coverage >= 0.45)
3. THE UI_Filter SHALL filter out garbage hint titles using `_is_garbage_hint()`
4. WHEN no candidates pass the threshold, THE UI_Filter SHALL show top-N raw candidates
5. THE UI_Filter SHALL ensure the top-1 candidate is always included in the show list
6. THE UI_Filter SHALL limit the show list to 8 candidates
7. THE UI_Filter SHALL provide `filter_for_ui()` function

### Requirement 6: 整合优化模块到 tmdb_lookup.py

**User Story:** 作为开发者，我希望 `tmdb_lookup.py` 使用所有已有的优化模块，让优化真正生效。

#### Acceptance Criteria

1. THE tmdb_lookup.py SHALL import and use `consensus_scoring.py` for support weight calculation
2. THE tmdb_lookup.py SHALL import and use `hint_strength.py` for hint quality evaluation
3. THE tmdb_lookup.py SHALL import and use `anime_detection.py` for anime bonus scoring
4. THE tmdb_lookup.py SHALL import and use `sequel_detection.py` for sequel penalty
5. THE tmdb_lookup.py SHALL import and use `alias_matching.py` for CJK/Latin alias matching
6. THE tmdb_lookup.py SHALL import and use `evidence_level.py` for evidence level computation
7. THE tmdb_lookup.py SHALL import and use `retry.py` for TMDB API retry logic
8. THE tmdb_lookup.py SHALL import and use `observability.py` for decision tracing
9. THE tmdb_lookup.py SHALL remove all internal implementations that duplicate these modules

### Requirement 7: 简化 tmdb_lookup.py

**User Story:** 作为开发者，我希望 `tmdb_lookup.py` 被简化为协调层，调用提取的模块。

#### Acceptance Criteria

1. THE tmdb_lookup.py SHALL import and use functions from all extracted and existing modules
2. THE tmdb_lookup.py SHALL maintain the same public API (`pre_resolve_from_names_and_caches`, `build_candidate_sets`)
3. THE tmdb_lookup.py SHALL be reduced to under 400 lines (from ~1344 lines)
4. THE tmdb_lookup.py SHALL preserve all existing function signatures and return types
5. THE tmdb_lookup.py SHALL maintain backward compatibility with existing callers

### Requirement 8: 废弃 integration.py

**User Story:** 作为开发者，我希望 `integration.py` 被废弃，其功能合并到 `tmdb_lookup.py`。

#### Acceptance Criteria

1. THE integration.py SHALL be marked as deprecated with a warning comment
2. THE integration.py SHALL re-export functions from tmdb_lookup.py for backward compatibility
3. THE integration.py SHALL NOT contain any unique logic (all logic moved to tmdb_lookup.py)
4. THE Test_Suite SHALL update imports from integration.py to tmdb_lookup.py

### Requirement 9: 测试覆盖

**User Story:** 作为开发者，我希望拆分后的模块有独立的单元测试，以便于验证正确性。

#### Acceptance Criteria

1. THE Test_Suite SHALL include property tests for each new module
2. THE Test_Suite SHALL verify that the refactored code produces identical results to the original
3. THE Test_Suite SHALL include property tests for key invariants:
   - Pre-resolve: 种子候选生成的确定性
   - Hint selection: 提示选择的稳定性
   - Candidate merge: 合并的幂等性和交换律
   - UI filter: 过滤后 top-1 始终包含
4. THE Test_Suite SHALL follow existing test patterns in `tests/property/`

## Out of Scope

以下内容不在本次重构范围内：

1. 修改 TMDB API 调用逻辑（保持现有行为）
2. 修改评分算法（保持现有评分逻辑）
3. 创建新的包结构（保持扁平模块结构）
4. 添加新功能（纯重构，不改变行为）
5. 修改 `usecase.py` 主流程（本次仅重构 `tmdb_lookup.py`）

## Dependencies

本重构依赖以下已存在的模块：

- `stage_strategy.py` - 提供 Stage-A/B 策略函数
- `consensus_scoring.py` - 提供共识评分函数
- `hint_strength.py` - 提供提示强度评估函数
- `episode_scoring.py` - 提供剧集评分基础函数
- `anime_detection.py` - 提供动漫检测函数
- `sequel_detection.py` - 提供续集检测函数
- `alias_matching.py` - 提供别名匹配函数
- `cache_validation.py` - 提供缓存验证函数
- `evidence_level.py` - 提供证据等级函数
- `retry.py` - 提供重试机制
- `observability.py` - 提供可观测性函数
- `hints.py` - 提供 `_is_garbage_hint()` 函数
- `scoring.py` - 提供 `_title_quality_score()` 函数
