# Design Document: TG Bot Data Integration

## Overview

本设计文档描述 TG Bot 配置页面与后端 API 数据打通的技术方案。核心目标是增强现有页面的数据加载、缓存策略、错误处理和用户体验，与 hotlist/forward 页面保持一致的架构模式。

设计采用以下架构模式：
- **API 层**: 复用现有后端 API 端点
- **前端层**: 增强 `static/js/tgbot.js`，添加 TgBotCache 和 TgBotAPI 模块
- **数据流**: 采用 stale-while-revalidate 模式，优先展示缓存数据

### 现有代码复用分析

| 功能 | 现有代码位置 | 复用方式 |
|------|-------------|---------|
| 配置获取 API | `/admin/tgbot/config.json` | ✅ 直接复用 |
| 配置保存 API | `/admin/tg-bot-settings` | ✅ 直接复用 |
| Bot 信息 API | `/admin/tgbot/info.json` | ✅ 直接复用 |
| 测试连接 API | `/admin/tgbot/test` | ✅ 直接复用 |
| 发送测试消息 API | `/admin/tgbot/send_test` | ✅ 直接复用 |
| 设置 Webhook API | `/admin/tgbot/set_webhook` | ✅ 直接复用 |
| 删除 Webhook API | `/admin/tgbot/delete_webhook` | ✅ 直接复用 |
| Webhook 信息 API | `/admin/tgbot/webhook_info.json` | ✅ 直接复用 |
| 115 健康检查 API | `/admin/cloud115/health` | ✅ 直接复用 |
| 115 扫码登录 API | `/admin/cloud115/qr/*` | ✅ 直接复用 |
| 前端渲染 | `static/js/tgbot.js` | ✅ 增强，添加缓存和错误处理 |
| Toast 通知 | `static/js/common.js:showToast()` | ✅ 直接复用 |

## Architecture

```
┌─────────────────────────────────────────────────────────────────┐
│                        Frontend (Browser)                        │
├─────────────────────────────────────────────────────────────────┤
│  tgbot.js                                                        │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐          │
│  │ TgBotAPI     │  │ TgBotCache   │  │ TgBotUI      │          │
│  │ - getConfig  │  │ - get/set    │  │ - fillForm   │          │
│  │ - saveConfig │  │ - isValid    │  │ - updateInfo │          │
│  │ - getBotInfo │  │ - invalidate │  │ - showToast  │          │
│  │ - testConn   │  │ - getStale   │  │ - addActivity│          │
│  │ - sendTest   │  │ - getAge     │  │ - setLoading │          │
│  │ - setWebhook │  └──────────────┘  │ - showQrModal│          │
│  │ - delWebhook │                    └──────────────┘          │
│  │ - getWebhook │                                               │
│  │ - health115  │                                               │
│  │ - qrLogin115 │                                               │
│  └──────────────┘                                               │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼ HTTP/JSON
┌─────────────────────────────────────────────────────────────────┐
│                        Backend (FastAPI)                         │
├─────────────────────────────────────────────────────────────────┤
│  /admin/tgbot/config.json      → 获取配置                        │
│  /admin/tg-bot-settings        → 保存配置                        │
│  /admin/tgbot/info.json        → 获取 Bot 信息                   │
│  /admin/tgbot/test             → 测试 Bot 连接                   │
│  /admin/tgbot/send_test        → 发送测试消息                    │
│  /admin/tgbot/set_webhook      → 设置 Webhook                    │
│  /admin/tgbot/delete_webhook   → 删除 Webhook                    │
│  /admin/tgbot/webhook_info.json→ 获取 Webhook 信息               │
│  /admin/cloud115/health        → 115 健康检查                    │
│  /admin/cloud115/qr/*          → 115 扫码登录                    │
└─────────────────────────────────────────────────────────────────┘
```

## Components and Interfaces

### 1. Backend API (已存在，无需修改)

#### 1.1 Config API (`/admin/tgbot/config.json`)

```python
@router.get("/admin/tgbot/config.json")
async def get_tgbot_config() -> Dict[str, Any]:
    """返回 TG Bot 配置"""
    return {
        "ok": True,
        "config": {
            "bot_token": str,
            "chat_id": str,
            "allowed_user_ids": list[int],
            "cloud115_cookie": str,
            "cloud115_qr_app": str,
            "cloud115_dup_mode": str,
            "cloud115_dup_window": int,
            "cloud115_health_enabled": bool,
            "cloud115_poll_on_submit": bool
        }
    }
```

#### 1.2 Bot Info API (`/admin/tgbot/info.json`)

```python
@router.get("/admin/tgbot/info.json")
async def get_tgbot_info() -> Dict[str, Any]:
    """返回 Bot 运行信息"""
    return {
        "ok": True,
        "bot": {
            "first_name": str,
            "username": str,
            "photo_url": str | None,
            "mode": str,           # "polling" | "webhook"
            "queue_size": int
        }
    }
```

#### 1.3 Save Config API (`/admin/tg-bot-settings`)

```python
@router.post("/admin/tg-bot-settings")
async def save_tg_bot_settings(request: Request) -> Dict[str, Any]:
    """保存 TG Bot 设置"""
    return {
        "ok": True,
        "title": str,
        "body": str,
        "effective": Dict[str, Any]
    }
```

### 2. Frontend Components (需要增强)

#### 2.1 TgBotCache Module

```javascript
const TgBotCache = {
    CONFIG_KEY: 'snh_tgbot_config_cache',
    INFO_KEY: 'snh_tgbot_info_cache',
    ACTIVITY_KEY: 'snh_tgbot_activity_log',
    CONFIG_TTL: 2 * 60 * 1000,   // 2 minutes for config
    INFO_TTL: 30 * 1000,         // 30 seconds for bot info
    
    // 获取缓存数据
    get(key) {
        try {
            const raw = localStorage.getItem(key);
            if (!raw) return null;
            return JSON.parse(raw);
        } catch (e) {
            return null;
        }
    },
    
    // 设置缓存数据
    set(key, data, ttl) {
        try {
            const item = { data, timestamp: Date.now(), ttl };
            localStorage.setItem(key, JSON.stringify(item));
        } catch (e) {
            console.warn('Cache set failed:', e);
        }
    },
    
    // 检查缓存是否有效
    isValid(key) {
        const item = this.get(key);
        if (!item) return false;
        return Date.now() - item.timestamp < item.ttl;
    },
    
    // 清除缓存
    invalidate(key) {
        localStorage.removeItem(key);
    },
    
    // 获取过期数据（用于 stale-while-revalidate）
    getStale(key) {
        const item = this.get(key);
        return item ? item.data : null;
    },
    
    // 获取缓存年龄（毫秒）
    getAge(key) {
        const item = this.get(key);
        if (!item) return Infinity;
        return Date.now() - item.timestamp;
    },
    
    // 格式化缓存时间
    formatAge(key) {
        const age = this.getAge(key);
        if (age === Infinity) return '未知';
        if (age < 60000) return '刚刚';
        if (age < 3600000) return `${Math.floor(age / 60000)} 分钟前`;
        return `${Math.floor(age / 3600000)} 小时前`;
    }
};
```

#### 2.2 TgBotAPI Module

```javascript
const TgBotAPI = {
    // 获取配置
    async getConfig() {
        const res = await fetch('/admin/tgbot/config.json');
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return await res.json();
    },
    
    // 保存配置
    async saveConfig(formData) {
        const res = await fetch('/admin/tg-bot-settings', {
            method: 'POST',
            headers: { 
                'Content-Type': 'application/x-www-form-urlencoded',
                'Accept': 'application/json',
                'X-Requested-With': 'fetch'
            },
            body: new URLSearchParams(formData)
        });
        return await res.json();
    },
    
    // 获取 Bot 信息
    async getBotInfo() {
        const res = await fetch('/admin/tgbot/info.json');
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        return await res.json();
    },
    
    // 测试 Bot 连接
    async testConnection(token) {
        const res = await fetch('/admin/tgbot/test', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ token })
        });
        return await res.json();
    },
    
    // 发送测试消息
    async sendTestMessage(chatId) {
        const res = await fetch('/admin/tgbot/send_test', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ chat_id: chatId })
        });
        return await res.json();
    },
    
    // 设置 Webhook
    async setWebhook(url, secret) {
        const res = await fetch('/admin/tgbot/set_webhook', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ url, secret })
        });
        return await res.json();
    },
    
    // 删除 Webhook
    async deleteWebhook() {
        const res = await fetch('/admin/tgbot/delete_webhook', { method: 'POST' });
        return await res.json();
    },
    
    // 获取 Webhook 信息
    async getWebhookInfo() {
        const res = await fetch('/admin/tgbot/webhook_info.json');
        return await res.json();
    },
    
    // 115 健康检查
    async check115Health() {
        const res = await fetch('/admin/cloud115/health', { method: 'POST' });
        return await res.json();
    },
    
    // 115 扫码登录 - 获取二维码
    async get115QrCode(app) {
        const res = await fetch('/admin/cloud115/qr/start', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ app })
        });
        return await res.json();
    },
    
    // 115 扫码登录 - 轮询状态
    async poll115QrStatus(uid) {
        const res = await fetch('/admin/cloud115/qr/poll', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ uid })
        });
        return await res.json();
    }
};
```

#### 2.3 Activity Log Module

```javascript
const ActivityLog = {
    MAX_ENTRIES: 10,
    
    // 添加日志
    add(msg) {
        const logs = this.getAll();
        const entry = {
            time: new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' }),
            msg
        };
        logs.unshift(entry);
        if (logs.length > this.MAX_ENTRIES) {
            logs.length = this.MAX_ENTRIES;
        }
        this.save(logs);
        this.render(logs);
    },
    
    // 获取所有日志
    getAll() {
        const raw = localStorage.getItem(TgBotCache.ACTIVITY_KEY);
        if (!raw) return [];
        try {
            return JSON.parse(raw);
        } catch (e) {
            return [];
        }
    },
    
    // 保存日志
    save(logs) {
        localStorage.setItem(TgBotCache.ACTIVITY_KEY, JSON.stringify(logs));
    },
    
    // 渲染日志
    render(logs) {
        const container = document.getElementById('activityLog');
        if (!container) return;
        
        if (logs.length === 0) {
            container.innerHTML = '<div class="activity-empty">暂无活动记录</div>';
            return;
        }
        
        container.innerHTML = logs.map(log => `
            <div class="activity-item">
                <span class="activity-time">${escapeHtml(log.time)}</span>
                <span class="activity-msg">${escapeHtml(log.msg)}</span>
            </div>
        `).join('');
    },
    
    // 初始化
    init() {
        this.render(this.getAll());
    }
};
```

#### 2.4 数据加载模式

```javascript
// Stale-while-revalidate 模式
async function loadConfigWithCache() {
    // 1. 先显示缓存数据
    const cached = TgBotCache.getStale(TgBotCache.CONFIG_KEY);
    if (cached && cached.config) {
        fillForm(cached.config);
        updateCacheIndicator('config');
    }
    
    // 2. 后台获取最新数据
    try {
        const data = await TgBotAPI.getConfig();
        if (data.ok) {
            TgBotCache.set(TgBotCache.CONFIG_KEY, data, TgBotCache.CONFIG_TTL);
            fillForm(data.config);
            updateCacheIndicator('config');
        }
    } catch (error) {
        if (!cached) {
            showError('加载配置失败', () => loadConfigWithCache());
        }
    }
}

// Bot 信息自动刷新
let botInfoInterval = null;

async function loadBotInfoWithCache() {
    updateBotStatus('pending', '检测中...');
    
    const cached = TgBotCache.getStale(TgBotCache.INFO_KEY);
    if (cached && cached.bot) {
        updateBotInfoDisplay(cached.bot);
    }
    
    try {
        const data = await TgBotAPI.getBotInfo();
        if (data.ok && data.bot) {
            TgBotCache.set(TgBotCache.INFO_KEY, data, TgBotCache.INFO_TTL);
            updateBotInfoDisplay(data.bot);
            updateBotStatus('online', '运行中');
        } else {
            updateBotStatus('offline', '未连接');
        }
    } catch (error) {
        updateBotStatus('offline', '连接失败');
        if (!cached) {
            updateBotInfoDisplay(null);
        }
    }
}

function startBotInfoAutoRefresh() {
    if (botInfoInterval) clearInterval(botInfoInterval);
    botInfoInterval = setInterval(loadBotInfoWithCache, 30000);
}
```

## Data Models

### Frontend Data Structures

```typescript
interface TgBotConfig {
    bot_token: string;
    chat_id: string;
    allowed_user_ids: number[];
    cloud115_cookie: string;
    cloud115_qr_app: string;
    cloud115_dup_mode: string;
    cloud115_dup_window: number;
    cloud115_health_enabled: boolean;
    cloud115_poll_on_submit: boolean;
}

interface TgBotInfo {
    first_name: string;
    username: string;
    photo_url: string | null;
    mode: 'polling' | 'webhook';
    queue_size: number;
}

interface CacheEntry<T> {
    data: T;
    timestamp: number;
    ttl: number;
}

interface ActivityLogEntry {
    time: string;      // HH:MM format
    msg: string;
}

interface APIResponse<T = any> {
    ok: boolean;
    detail?: string;
    config?: TgBotConfig;
    bot?: TgBotInfo;
    title?: string;
    body?: string;
    effective?: Record<string, any>;
}

interface QrLoginState {
    uid: string;
    qrUrl: string;
    status: 'pending' | 'scanned' | 'confirmed' | 'expired' | 'error';
    pollInterval: number | null;
}
```



## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Form Population Completeness

*For any* valid TgBotConfig object with non-null fields, when `fillForm(config)` is called, all corresponding form input elements SHALL have their values set to match the config object fields. Specifically:
- `bot_token` → `#botToken` input value
- `chat_id` → `#chatId` input value
- `allowed_user_ids` → `#allowedUserIds` textarea (joined by newlines)
- `cloud115_cookie` → `#cloud115Cookie` textarea value
- `cloud115_qr_app` → `#cloud115QrApp` select value
- `cloud115_dup_mode` → `#cloud115DupMode` select value
- `cloud115_health_enabled` → `#cloud115HealthEnabled` checkbox checked state
- `cloud115_poll_on_submit` → `#cloud115PollOnSubmit` checkbox checked state

**Validates: Requirements 1.2**

### Property 2: Bot Info Display Completeness

*For any* valid TgBotInfo object, when `updateBotInfoDisplay(bot)` is called, the display elements SHALL show:
- Bot 名称 (`#botName`): the value of `first_name` or "Bot" if empty
- Bot 用户名 (`#botUsername`): "@" + `username` or "@..." if empty
- 运行状态 (`#runStatus`): "运行中" with appropriate badge class
- 运行模式 (`#currentMode`): the value of `mode` or "--" if empty
- 消息队列 (`#queueSize`): the value of `queue_size` or "0" if undefined

When bot is null, display elements SHALL show default/offline values.

**Validates: Requirements 2.2**

### Property 3: Cache TTL Enforcement

*For any* cached data entry with timestamp T and TTL value:
- `isValid(key)` SHALL return true when current time < T + TTL
- `isValid(key)` SHALL return false when current time >= T + TTL
- After `invalidate(key)` is called, `isValid(key)` SHALL return false
- After `set(key, data, ttl)` is called, `getStale(key)` SHALL return the stored data
- Config cache TTL SHALL be 2 minutes (120000ms)
- Bot info cache TTL SHALL be 30 seconds (30000ms)

**Validates: Requirements 1.3, 2.4, 3.5**

### Property 4: Form Data Collection Accuracy

*For any* form state with input values, when `collectFormData()` is called, the returned object SHALL contain:
- All checkbox values as booleans matching their checked state
- All text input values as trimmed strings
- All textarea values as trimmed strings
- All select values as their selected option values
- `allowed_user_ids` parsed from newline-separated text to array of numbers

**Validates: Requirements 3.1**

### Property 5: Activity Log Management

*For any* sequence of activity log operations:
- After `add(msg)`, the log SHALL contain an entry with the message and current timestamp (HH:MM format)
- The log SHALL never contain more than 10 entries (oldest entries are removed first)
- After `save()`, localStorage SHALL contain the log data under the activity key
- After `getAll()`, the returned array SHALL match the stored data
- Entries SHALL be ordered newest-first

**Validates: Requirements 9.1, 9.2, 9.3**

### Property 6: API Response Format Consistency

*For any* API endpoint under `/admin/tgbot/*`:
- The response SHALL contain `ok` (boolean) field
- When `ok` is false, a `detail` string field SHALL be present
- `/admin/tgbot/config.json` response SHALL contain `config` object with all config fields when `ok` is true
- `/admin/tgbot/info.json` response SHALL contain `bot` object with `first_name`, `username`, `mode`, `queue_size` fields when `ok` is true

**Validates: Requirements 10.1, 10.2, 10.3, 10.4, 10.5**

### Property 7: Cache Age Formatting

*For any* cache age value in milliseconds:
- Age < 60000 (1 minute) SHALL format as "刚刚"
- Age >= 60000 and < 3600000 (1 hour) SHALL format as "N 分钟前" where N = floor(age / 60000)
- Age >= 3600000 SHALL format as "N 小时前" where N = floor(age / 3600000)
- Infinity (no cache) SHALL format as "未知"

**Validates: Requirements 11.3**

### Property 8: Token Generation

*For any* call to `generateToken()`:
- The generated token SHALL be exactly 32 characters long
- The token SHALL only contain alphanumeric characters (A-Z, a-z, 0-9)
- Each generated token SHALL be different from the previous one (with high probability due to randomness)

**Validates: Requirements 13.3**

## Error Handling

### Frontend Error Handling

1. **Network Error**: Show cached data + "离线模式" indicator, provide retry button
2. **API Error (ok: false)**: Show error toast with detail message
3. **Parse Error**: Log to console, show generic error message
4. **Timeout**: Retry once, then show timeout message

```javascript
async function fetchWithFallback(fetchFn, cacheKey, ttl) {
    try {
        const data = await fetchFn();
        if (data.ok) {
            TgBotCache.set(cacheKey, data, ttl);
            return { data, fromCache: false };
        } else {
            throw new Error(data.detail || '请求失败');
        }
    } catch (error) {
        const cached = TgBotCache.getStale(cacheKey);
        if (cached) {
            return { data: cached, fromCache: true, error };
        }
        throw error;
    }
}
```

### Mutation Error Handling

```javascript
async function withMutationFeedback(operation, successMsg, btn) {
    const originalText = btn?.innerHTML;
    try {
        if (btn) {
            btn.disabled = true;
            btn.innerHTML = '<span class="spinner-small"></span>处理中...';
        }
        
        const result = await operation();
        if (result.ok) {
            showToast(successMsg, 'success');
            TgBotCache.invalidate(TgBotCache.CONFIG_KEY);
            ActivityLog.add(successMsg);
        } else {
            showToast(result.detail || '操作失败', 'error');
        }
        return result;
    } catch (error) {
        showToast('网络错误，请重试', 'error');
        throw error;
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = originalText;
        }
    }
}
```

### 115 QR Login Error Handling

```javascript
async function handleQrLogin() {
    const app = document.getElementById('cloud115QrApp').value;
    let pollCount = 0;
    const maxPolls = 60;  // 最多轮询 60 次（约 2 分钟）
    
    try {
        // 获取二维码
        const qrResult = await TgBotAPI.get115QrCode(app);
        if (!qrResult.ok) {
            showToast(qrResult.detail || '获取二维码失败', 'error');
            return;
        }
        
        showQrModal(qrResult.qr_url);
        
        // 轮询登录状态
        const pollInterval = setInterval(async () => {
            pollCount++;
            if (pollCount > maxPolls) {
                clearInterval(pollInterval);
                closeQrModal();
                showToast('二维码已过期，请重试', 'error');
                return;
            }
            
            try {
                const status = await TgBotAPI.poll115QrStatus(qrResult.uid);
                if (status.ok && status.status === 'confirmed') {
                    clearInterval(pollInterval);
                    closeQrModal();
                    if (status.cookie) {
                        document.getElementById('cloud115Cookie').value = status.cookie;
                    }
                    showToast('扫码登录成功！', 'success');
                    ActivityLog.add('115 扫码登录成功');
                } else if (status.status === 'expired' || status.status === 'error') {
                    clearInterval(pollInterval);
                    closeQrModal();
                    showToast(status.detail || '登录失败', 'error');
                }
            } catch (e) {
                // 轮询失败，继续尝试
                console.warn('QR poll failed:', e);
            }
        }, 2000);
        
    } catch (error) {
        showToast('网络错误', 'error');
    }
}
```

## Testing Strategy

### Unit Tests

1. **Cache Logic**: Test TTL calculation, invalidation, stale data retrieval
2. **Form Population**: Test form field population with various config values
3. **Bot Info Display**: Test display update with various bot info values
4. **Activity Log**: Test log addition, limit enforcement, persistence
5. **Cache Age Formatting**: Test formatting for various age values
6. **Token Generation**: Test token length and character set
7. **Form Data Collection**: Test collection with various form states

### Property-Based Tests

使用 Hypothesis (Python) 进行属性测试：

1. **Property 1 (Form Population)**: Generate random config objects, verify form population
2. **Property 2 (Bot Info Display)**: Generate random bot info objects, verify display update
3. **Property 3 (Cache TTL)**: Generate random timestamps and TTL values, verify cache validity logic
4. **Property 4 (Form Collection)**: Generate random form values, verify collection accuracy
5. **Property 5 (Activity Log)**: Generate random activity sequences, verify log management
6. **Property 6 (API Format)**: Generate random API responses, verify schema compliance
7. **Property 7 (Cache Age)**: Generate random age values, verify formatting
8. **Property 8 (Token)**: Generate multiple tokens, verify length and uniqueness

### Integration Tests

1. **Config Load Flow**: Verify stale-while-revalidate works correctly
2. **Save Flow**: Verify save triggers cache invalidation and activity log
3. **Bot Info Refresh**: Verify auto-refresh works correctly
4. **Webhook Operations**: Verify set/delete/get webhook flows
5. **115 Health Check**: Verify health check flow
6. **115 QR Login**: Verify QR code display and polling flow
7. **Error Recovery**: Verify fallback to cache on API failure

### Test Configuration

- Minimum 100 iterations per property test
- Tag format: `Feature: tgbot-data-integration, Property {N}: {description}`
- Property tests use Hypothesis (Python) for backend validation
- Frontend tests use Jest with mock localStorage
