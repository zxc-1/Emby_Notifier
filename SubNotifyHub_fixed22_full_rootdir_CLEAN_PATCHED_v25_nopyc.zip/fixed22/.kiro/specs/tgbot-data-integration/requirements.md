# Requirements Document

## Introduction

本功能旨在优化 TG Bot 配置页面的前端数据集成，实现与 hotlist/forward 页面类似的缓存策略、错误处理和用户体验增强。当前页面已有基础的 API 调用，但缺乏缓存机制、统一的 API 封装层、完善的错误处理、加载状态指示和活动日志。此外，部分功能（115 健康检查、扫码登录）在 HTML 中有按钮但 JS 未实现。

## Glossary

- **TgBot_Page**: TG Bot 配置页面，用于管理 Telegram Bot 凭证、115 云盘设置和 Bot 状态监控
- **TgBot_Config**: TG Bot 的配置数据，包含 Bot Token、Chat ID、允许的用户 ID、115 Cookie 等
- **TgBot_Info**: Bot 的运行信息，包含名称、用户名、运行状态、运行模式、消息队列等
- **TgBotCache**: 前端本地缓存模块，用于缓存配置和 Bot 信息数据
- **TgBotAPI**: 前端 API 封装模块，统一处理所有 API 调用
- **Activity_Log**: 页面操作活动日志，记录用户操作历史
- **Webhook**: Telegram Bot 的消息接收方式之一，通过 HTTPS 回调接收消息
- **Cloud115**: 115 云盘服务，用于解析分享链接和离线下载

## Requirements

### Requirement 1: 配置数据加载与缓存

**User Story:** As a user, I want the configuration page to load quickly with cached data, so that I can have a responsive experience.

#### Acceptance Criteria

1. WHEN the TgBot page loads, THE TgBot_Page SHALL request configuration data from `/admin/tgbot/config.json` API
2. WHEN configuration data is received, THE TgBot_Page SHALL populate all form fields with the received values
3. THE TgBot_Page SHALL cache configuration data in localStorage with TTL of 2 minutes
4. WHEN cached data exists, THE TgBot_Page SHALL display cached data immediately while fetching fresh data (stale-while-revalidate)
5. IF the configuration API request fails, THEN THE TgBot_Page SHALL display cached data or show error state with retry option

### Requirement 2: Bot 信息加载与显示

**User Story:** As a user, I want to see real-time status of my Telegram Bot, so that I can monitor the bot health.

#### Acceptance Criteria

1. WHEN the TgBot page loads, THE TgBot_Page SHALL request bot info from `/admin/tgbot/info.json` API
2. WHEN bot info is received, THE TgBot_Page SHALL update Bot 名称、用户名、头像、运行状态、运行模式、消息队列显示
3. THE TgBot_Page SHALL auto-refresh bot info every 30 seconds
4. THE TgBot_Page SHALL cache bot info in localStorage with TTL of 30 seconds
5. WHILE bot info is loading, THE TgBot_Page SHALL show "检测中..." indicator
6. IF the bot info API request fails, THEN THE TgBot_Page SHALL show "连接失败" and use cached data if available

### Requirement 3: 配置保存功能

**User Story:** As a user, I want to save my configuration changes, so that they persist across sessions.

#### Acceptance Criteria

1. WHEN the user clicks "保存配置", THE TgBot_Page SHALL collect all form values and call `/admin/tg-bot-settings` API
2. WHILE the save request is in progress, THE TgBot_Page SHALL disable the save button and show loading state
3. IF the save request succeeds, THEN THE TgBot_Page SHALL show success toast, invalidate cache, and add activity log
4. IF the save request fails, THEN THE TgBot_Page SHALL show error toast with detail message
5. WHEN configuration is saved, THE TgBot_Page SHALL update the cached data

### Requirement 4: Bot 连接测试

**User Story:** As a user, I want to test Bot connection, so that I can verify my Bot Token is correct.

#### Acceptance Criteria

1. WHEN the user clicks "测试连接", THE TgBot_Page SHALL validate Bot Token is not empty
2. IF Bot Token is empty, THEN THE TgBot_Page SHALL show warning toast
3. WHILE the test request is in progress, THE TgBot_Page SHALL show "正在测试连接..." toast and disable the button
4. IF the test succeeds, THEN THE TgBot_Page SHALL show success toast with Bot username and add activity log
5. IF the test fails, THEN THE TgBot_Page SHALL show error toast with detail message

### Requirement 5: 发送测试消息

**User Story:** As a user, I want to send a test message, so that I can verify the Bot can send messages to my chat.

#### Acceptance Criteria

1. WHEN the user clicks "发送测试消息", THE TgBot_Page SHALL validate Chat ID is not empty
2. IF Chat ID is empty, THEN THE TgBot_Page SHALL show warning toast
3. WHILE the send request is in progress, THE TgBot_Page SHALL show loading state on the button
4. IF the send succeeds, THEN THE TgBot_Page SHALL show success toast and add activity log
5. IF the send fails, THEN THE TgBot_Page SHALL show error toast with detail message

### Requirement 6: Webhook 管理功能

**User Story:** As a user, I want to manage Webhook settings, so that I can configure how the Bot receives messages.

#### Acceptance Criteria

1. WHEN the user clicks "设置 Webhook", THE TgBot_Page SHALL validate Webhook URL is HTTPS
2. IF Webhook URL is invalid, THEN THE TgBot_Page SHALL show error toast
3. WHEN the user clicks "删除 Webhook", THE TgBot_Page SHALL show confirmation dialog before calling API
4. WHEN the user clicks "查看 Webhook 信息", THE TgBot_Page SHALL fetch and display Webhook info in modal
5. WHILE any Webhook operation is in progress, THE TgBot_Page SHALL disable the button and show loading state
6. IF a Webhook operation succeeds, THEN THE TgBot_Page SHALL show success toast and add activity log
7. IF a Webhook operation fails, THEN THE TgBot_Page SHALL show error toast with detail message

### Requirement 7: 115 云盘健康检查

**User Story:** As a user, I want to check 115 cloud connection status, so that I can verify my Cookie is valid.

#### Acceptance Criteria

1. WHEN the user clicks "健康检查", THE TgBot_Page SHALL call 115 health check API
2. WHILE the health check is in progress, THE TgBot_Page SHALL show loading state on the button
3. IF the health check succeeds, THEN THE TgBot_Page SHALL show success toast with account info and add activity log
4. IF the health check fails, THEN THE TgBot_Page SHALL show error toast with detail message

### Requirement 8: 115 扫码登录

**User Story:** As a user, I want to login to 115 via QR code, so that I can easily update my Cookie.

#### Acceptance Criteria

1. WHEN the user clicks "扫码登录", THE TgBot_Page SHALL call QR code generation API
2. WHEN QR code is received, THE TgBot_Page SHALL display QR code in a modal
3. THE TgBot_Page SHALL poll for login status until success, timeout, or user cancellation
4. IF login succeeds, THEN THE TgBot_Page SHALL update Cookie field, show success toast, and add activity log
5. IF login times out or fails, THEN THE TgBot_Page SHALL show error toast

### Requirement 9: 活动日志记录

**User Story:** As a user, I want to see recent activity logs, so that I can track what operations have been performed.

#### Acceptance Criteria

1. WHEN an operation is performed, THE TgBot_Page SHALL add a timestamped entry to the activity log
2. THE TgBot_Page SHALL display up to 10 most recent activity entries
3. THE TgBot_Page SHALL persist activity log to localStorage
4. WHEN the page loads, THE TgBot_Page SHALL restore activity log from localStorage

### Requirement 10: API 响应格式标准化

**User Story:** As a developer, I want consistent API response formats, so that I can reliably handle responses.

#### Acceptance Criteria

1. THE API SHALL return JSON responses with `ok` (boolean) field
2. WHEN a request succeeds, THE API SHALL set `ok: true` and include relevant data
3. WHEN a request fails, THE API SHALL set `ok: false` and include `detail` (error message) field
4. THE `/admin/tgbot/config.json` API SHALL include `config` object with all configuration fields
5. THE `/admin/tgbot/info.json` API SHALL include `bot` object with `first_name`, `username`, `mode`, `queue_size` fields

### Requirement 11: 缓存时间显示

**User Story:** As a user, I want to see when data was last updated, so that I know how fresh the displayed data is.

#### Acceptance Criteria

1. THE TgBot_Page SHALL display "上次更新" timestamp when showing cached data
2. WHEN data is refreshed, THE TgBot_Page SHALL update the timestamp display
3. THE TgBot_Page SHALL format timestamp in user-friendly format (e.g., "刚刚", "1 分钟前")

### Requirement 12: 错误处理和用户反馈

**User Story:** As a user, I want clear feedback on my actions, so that I know what's happening.

#### Acceptance Criteria

1. WHEN an API request is in progress, THE TgBot_Page SHALL disable the action button and show loading state
2. WHEN an API request succeeds, THE TgBot_Page SHALL show a success toast notification
3. WHEN an API request fails, THE TgBot_Page SHALL show an error toast with detail message
4. IF network is unavailable, THEN THE TgBot_Page SHALL display offline indicator and use cached data
5. THE TgBot_Page SHALL provide retry option for failed requests

### Requirement 13: 表单辅助功能

**User Story:** As a user, I want helpful form features, so that I can configure the Bot easily.

#### Acceptance Criteria

1. WHEN the user clicks password toggle button, THE TgBot_Page SHALL toggle password visibility for Bot Token
2. WHEN the user clicks "获取 Chat ID" button, THE TgBot_Page SHALL provide guidance on how to get Chat ID
3. WHEN the user clicks "生成随机 Token" button for Webhook Secret, THE TgBot_Page SHALL generate a 32-character random token

### Requirement 14: 功能模块显示

**User Story:** As a user, I want to see which feature modules are enabled, so that I can understand the Bot's capabilities.

#### Acceptance Criteria

1. WHEN bot info is loaded, THE TgBot_Page SHALL display feature module tags
2. THE TgBot_Page SHALL visually distinguish enabled and disabled modules
3. WHEN feature status changes, THE TgBot_Page SHALL update the display immediately
