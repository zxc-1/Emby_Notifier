# Implementation Plan: TG Bot Data Integration

## Overview

本实现计划将 TG Bot 配置页面的前端与后端 API 数据打通，实现动态数据加载、缓存策略、错误处理和用户体验增强。实现语言为 JavaScript，复用现有的 `static/js/tgbot.js` 文件并进行增强。

## Tasks

- [x] 1. 实现 TgBotCache 缓存模块
  - [x] 1.1 创建 TgBotCache 对象，定义缓存键和 TTL 常量
    - CONFIG_KEY: 'snh_tgbot_config_cache'
    - INFO_KEY: 'snh_tgbot_info_cache'
    - ACTIVITY_KEY: 'snh_tgbot_activity_log'
    - CONFIG_TTL: 2 分钟
    - INFO_TTL: 30 秒
    - _Requirements: 1.3, 2.4_
  
  - [x] 1.2 实现 get/set/isValid/invalidate/getStale/getAge 方法
    - get(key): 从 localStorage 获取缓存数据
    - set(key, data, ttl): 设置缓存数据，包含 timestamp 和 ttl
    - isValid(key): 检查缓存是否在 TTL 内
    - invalidate(key): 清除指定缓存
    - getStale(key): 获取过期数据用于 stale-while-revalidate
    - getAge(key): 获取缓存年龄（毫秒）
    - _Requirements: 1.3, 1.4, 2.4, 3.5_
  
  - [x] 1.3 实现 formatAge 方法
    - 格式化缓存时间为用户友好格式
    - < 1 分钟: "刚刚"
    - < 1 小时: "N 分钟前"
    - >= 1 小时: "N 小时前"
    - 无缓存: "未知"
    - _Requirements: 11.3_
  
  - [x] 1.4 编写 TgBotCache 属性测试
    - **Property 3: Cache TTL Enforcement**
    - **Property 7: Cache Age Formatting**
    - **Validates: Requirements 1.3, 2.4, 11.3**

- [x] 2. 实现 TgBotAPI 模块
  - [x] 2.1 创建 TgBotAPI 对象，实现配置相关 API
    - getConfig(): GET /admin/tgbot/config.json
    - saveConfig(formData): POST /admin/tg-bot-settings
    - _Requirements: 1.1, 3.1_
  
  - [x] 2.2 实现 Bot 信息相关 API
    - getBotInfo(): GET /admin/tgbot/info.json
    - testConnection(token): POST /admin/tgbot/test
    - sendTestMessage(chatId): POST /admin/tgbot/send_test
    - _Requirements: 2.1, 4.1, 5.1_
  
  - [x] 2.3 实现 Webhook 相关 API
    - setWebhook(url, secret): POST /admin/tgbot/set_webhook
    - deleteWebhook(): POST /admin/tgbot/delete_webhook
    - getWebhookInfo(): GET /admin/tgbot/webhook_info.json
    - _Requirements: 6.1, 6.3, 6.4_
  
  - [x] 2.4 实现 115 云盘相关 API
    - check115Health(): POST /admin/cloud115/health
    - get115QrCode(app): POST /admin/cloud115/qr/start
    - poll115QrStatus(uid): POST /admin/cloud115/qr/poll
    - _Requirements: 7.1, 8.1, 8.3_
  
  - [x] 2.5 编写 API 响应格式属性测试
    - **Property 6: API Response Format Consistency**
    - **Validates: Requirements 10.1, 10.2, 10.3, 10.4, 10.5**

- [x] 3. Checkpoint - 确保缓存和 API 模块测试通过
  - 确保所有测试通过，如有问题请询问用户。

- [x] 4. 实现 ActivityLog 活动日志模块
  - [x] 4.1 创建 ActivityLog 对象，实现日志管理
    - MAX_ENTRIES: 10
    - add(msg): 添加日志条目，包含时间戳
    - getAll(): 获取所有日志
    - save(logs): 保存到 localStorage
    - render(logs): 渲染日志到 DOM
    - init(): 初始化，从 localStorage 恢复
    - _Requirements: 9.1, 9.2, 9.3, 9.4_
  
  - [x] 4.2 编写 ActivityLog 属性测试
    - **Property 5: Activity Log Management**
    - **Validates: Requirements 9.1, 9.2, 9.3**

- [x] 5. 实现数据加载和表单填充功能
  - [x] 5.1 实现 loadConfigWithCache 函数
    - 使用 stale-while-revalidate 模式
    - 先显示缓存数据，后台获取最新数据
    - 失败时显示缓存或错误状态
    - _Requirements: 1.1, 1.4, 1.5_
  
  - [x] 5.2 实现 fillForm 函数
    - 将配置数据填充到表单字段
    - 处理 bot_token, chat_id, allowed_user_ids
    - 处理 115 相关配置字段
    - _Requirements: 1.2_
  
  - [x] 5.3 实现 collectFormData 函数
    - 收集表单数据用于保存
    - 处理复选框、文本框、下拉框
    - 解析 allowed_user_ids 为数组
    - _Requirements: 3.1_
  
  - [x] 5.4 编写表单填充和收集属性测试
    - **Property 1: Form Population Completeness**
    - **Property 4: Form Data Collection Accuracy**
    - **Validates: Requirements 1.2, 3.1**

- [x] 6. 实现 Bot 信息显示和自动刷新
  - [x] 6.1 实现 loadBotInfoWithCache 函数
    - 使用 stale-while-revalidate 模式
    - 更新 Bot 名称、用户名、头像、状态等
    - _Requirements: 2.1, 2.2, 2.5, 2.6_
  
  - [x] 6.2 实现 updateBotInfoDisplay 函数
    - 更新 #botName, #botUsername, #botAvatar
    - 更新 #runStatus, #currentMode, #queueSize
    - 处理 null/undefined 情况
    - _Requirements: 2.2_
  
  - [x] 6.3 实现 startBotInfoAutoRefresh 函数
    - 每 30 秒自动刷新 Bot 信息
    - 页面卸载时清除定时器
    - _Requirements: 2.3_
  
  - [x] 6.4 编写 Bot 信息显示属性测试
    - **Property 2: Bot Info Display Completeness**
    - **Validates: Requirements 2.2**

- [x] 7. Checkpoint - 确保数据加载和显示功能测试通过
  - 确保所有测试通过，如有问题请询问用户。

- [x] 8. 实现配置保存和操作反馈
  - [x] 8.1 重构 saveConfig 函数
    - 使用 withMutationFeedback 包装
    - 显示加载状态，禁用按钮
    - 成功后清除缓存，添加活动日志
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5_
  
  - [x] 8.2 实现 withMutationFeedback 辅助函数
    - 统一处理操作反馈
    - 管理按钮加载状态
    - 处理成功/失败 Toast
    - _Requirements: 12.1, 12.2, 12.3_

- [x] 9. 实现 Bot 连接测试和消息发送
  - [x] 9.1 重构 testBotConnection 函数
    - 验证 Bot Token 非空
    - 显示加载状态
    - 成功显示 Bot 用户名
    - 添加活动日志
    - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5_
  
  - [x] 9.2 重构 sendTestMessage 函数
    - 验证 Chat ID 非空
    - 显示加载状态
    - 添加活动日志
    - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5_

- [x] 10. 实现 Webhook 管理功能
  - [x] 10.1 重构 setWebhook 函数
    - 验证 URL 为 HTTPS
    - 显示加载状态
    - 添加活动日志
    - _Requirements: 6.1, 6.2, 6.5, 6.6, 6.7_
  
  - [x] 10.2 重构 deleteWebhook 函数
    - 显示确认对话框
    - 显示加载状态
    - 添加活动日志
    - _Requirements: 6.3, 6.5, 6.6, 6.7_
  
  - [x] 10.3 重构 getWebhookInfo 函数
    - 显示加载状态
    - 在模态框中显示信息
    - _Requirements: 6.4, 6.5_

- [x] 11. 实现 115 云盘功能
  - [x] 11.1 实现 test115Connection 函数（健康检查）
    - 调用健康检查 API
    - 显示加载状态
    - 成功显示账户信息
    - 添加活动日志
    - _Requirements: 7.1, 7.2, 7.3, 7.4_
  
  - [x] 11.2 实现 startQrLogin 函数（扫码登录）
    - 获取二维码并显示模态框
    - 轮询登录状态
    - 成功后更新 Cookie 字段
    - 处理超时和错误
    - 添加活动日志
    - _Requirements: 8.1, 8.2, 8.3, 8.4, 8.5_
  
  - [x] 11.3 实现 QR 登录模态框 UI
    - 显示二维码图片
    - 显示扫码状态
    - 提供取消按钮
    - _Requirements: 8.2_

- [x] 12. Checkpoint - 确保所有操作功能测试通过
  - 确保所有测试通过，如有问题请询问用户。

- [x] 13. 实现表单辅助功能
  - [x] 13.1 实现 generateToken 函数
    - 生成 32 位随机字母数字 Token
    - 显示生成的 Token
    - 显示成功 Toast
    - _Requirements: 13.3_
  
  - [x] 13.2 保持 togglePassword 函数
    - 切换密码可见性
    - _Requirements: 13.1_
  
  - [x] 13.3 保持 getChatId 函数
    - 提供获取 Chat ID 的指导
    - _Requirements: 13.2_
  
  - [x] 13.4 编写 Token 生成属性测试
    - **Property 8: Token Generation**
    - **Validates: Requirements 13.3**

- [x] 14. 实现缓存时间指示器和功能模块显示
  - [x] 14.1 实现 updateCacheIndicator 函数
    - 显示"上次更新"时间
    - 使用 formatAge 格式化
    - _Requirements: 11.1, 11.2_
  
  - [x] 14.2 保持 updateFeaturesDisplay 函数
    - 显示功能模块标签
    - 区分启用/禁用状态
    - _Requirements: 14.1, 14.2, 14.3_

- [x] 15. 更新 HTML 模板
  - [x] 15.1 添加活动日志容器
    - 在右侧边栏添加活动日志卡片
    - _Requirements: 9.1_
  
  - [x] 15.2 添加缓存时间指示器
    - 在配置卡片头部添加更新时间显示
    - _Requirements: 11.1_
  
  - [x] 15.3 添加 QR 登录模态框
    - 添加二维码显示模态框 HTML
    - _Requirements: 8.2_

- [x] 16. 更新页面初始化逻辑
  - [x] 16.1 重构 DOMContentLoaded 事件处理
    - 初始化 ActivityLog
    - 使用 loadConfigWithCache 加载配置
    - 使用 loadBotInfoWithCache 加载 Bot 信息
    - 启动自动刷新
    - _Requirements: 1.1, 2.1, 2.3, 9.4_

- [x] 17. Final Checkpoint - 确保所有测试通过
  - 确保所有测试通过，如有问题请询问用户。

## Notes

- 所有任务（包括测试任务）均为必需任务
- 每个任务引用具体的需求条款以确保可追溯性
- 检查点确保增量验证
- 属性测试验证通用正确性属性
- 单元测试验证具体示例和边界情况
