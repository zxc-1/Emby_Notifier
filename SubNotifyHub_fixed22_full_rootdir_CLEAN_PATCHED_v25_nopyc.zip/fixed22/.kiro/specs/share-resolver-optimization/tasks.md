# Implementation Plan: Share Resolver 全链路优化

## Overview

本实现计划将 18 个需求分解为可执行的编码任务，按阶段组织，确保增量交付和持续验证。

## Tasks

- [x] 1. hints.py 模块拆分
  - [x] 1.1 创建 hints/ 目录结构和 __init__.py
    - 创建 `application/usecases/share_resolver/hints/` 目录
    - 创建 `__init__.py` 重导出所有公共函数
    - _Requirements: 1.1, 1.9_

  - [x] 1.2 提取 hints_validation.py
    - 移动 `_is_garbage_hint()`, `_is_generic_share_title()`, `_fast_hint_strong()`, `clean_hints()`, `pick_best_hint()`
    - _Requirements: 1.7_

  - [x] 1.3 提取 hints_detection.py
    - 移动 `_detect_multi_season_markers()`, `_detect_mixed_content()`, `_detect_part_markers()`, `_detect_regional_version()`
    - _Requirements: 1.4_

  - [x] 1.4 提取 hints_extraction.py
    - 移动 `_extract_share_fragment_hint()`, `_extract_batch_title()`, `_extract_strict_year()`, `_prioritize_video_samples()`
    - _Requirements: 1.5_

  - [x] 1.5 提取 hints_episode.py
    - 移动 `_extract_episode_set()` 和相关剧集处理函数
    - _Requirements: 1.6_

  - [x] 1.6 创建 hints_core.py
    - 移动 `build_hint_pack()` 主函数
    - 更新导入以使用拆分后的子模块
    - _Requirements: 1.3_

  - [x] 1.7 更新原 hints.py 为兼容层
    - 从 hints/ 包重导出所有公共函数
    - 确保向后兼容
    - _Requirements: 1.9_

  - [x] 1.8 编写属性测试：重构保持行为一致
    - **Property 1: Refactor Preserves Behavior**
    - **Validates: Requirements 1.2**

- [x] 2. Checkpoint - hints 模块拆分验证
  - 确保所有测试通过
  - 验证无循环导入
  - 确认向后兼容性

- [x] 3. 字幕组识别模块
  - [x] 3.1 创建 hints_subtitle.py
    - 定义 `SubtitleGroupInfo` 数据类
    - 定义 `SUBTITLE_GROUPS` 字典（常见字幕组）
    - 实现 `detect_subtitle_group()` 函数
    - 实现 `extract_all_subtitle_groups()` 函数
    - _Requirements: 5.1, 5.2, 5.5_

  - [x] 3.2 集成字幕组信息到 hint_pack
    - 在 `build_hint_pack()` 中调用字幕组检测
    - 将检测结果添加到返回的 hint_pack
    - _Requirements: 5.3_

  - [x] 3.3 编写属性测试：字幕组检测
    - **Property 7: Subtitle Group Detection**
    - **Property 8: Subtitle Group Metadata Extraction**
    - **Validates: Requirements 5.1, 5.2, 5.5**

- [x] 4. TMDB 搜索缓存
  - [x] 4.1 创建 search_cache.py
    - 实现 `LRUSearchCache` 类
    - 实现 `_make_key()` 方法
    - 实现 `get()` 和 `set()` 方法
    - 实现 LRU 淘汰逻辑
    - _Requirements: 6.1, 6.3, 6.4, 6.5_

  - [x] 4.2 集成搜索缓存到 tmdb_lookup.py
    - 在 `build_candidate_sets()` 中添加缓存统计日志
    - 使用 `get_search_cache()` 获取缓存统计
    - 记录 hits/misses/hit_rate/evictions/expirations
    - _Requirements: 6.2, 6.6_

  - [x] 4.3 编写属性测试：搜索缓存
    - **Property 9: Search Cache LRU Eviction**
    - **Property 10: Search Cache Key Uniqueness**
    - **Validates: Requirements 6.3, 6.4, 6.5**

- [x] 5. 多语言标题关联
  - [x] 5.1 创建 title_alias.py
    - 实现 `fetch_title_aliases()` 函数
    - 实现 `normalize_alias()` 函数
    - 实现 `compute_alias_similarity()` 函数
    - 实现别名缓存逻辑
    - _Requirements: 2.1, 2.2, 2.6_

  - [x] 5.2 实现 boost_candidates_with_aliases()
    - 获取候选的别名（使用缓存）
    - 计算查询与别名的相似度
    - 匹配时提升分数
    - _Requirements: 2.3_

  - [x] 5.3 集成别名匹配到候选合并流程
    - 在 `candidate_merge.py` 中调用别名提升
    - 处理 API 错误的优雅降级
    - _Requirements: 2.4, 2.5_

  - [x] 5.4 编写属性测试：别名匹配
    - **Property 2: Alias Matching Boosts Scores**
    - **Property 3: Alias Cache TTL Enforcement**
    - **Property 4: Alias Normalization Consistency**
    - **Validates: Requirements 2.2, 2.3, 2.6**

- [x] 6. Checkpoint - 阶段 ⑤ 优化验证
  - 确保所有测试通过
  - 验证搜索缓存命中率
  - 验证别名匹配效果

- [x] 7. snapshot.py 并行扫描
  - [x] 7.1 重构 fetch_share_evidence 为并行版本
    - 使用 `asyncio.create_task()` 并行启动 fast 和 deep1
    - 实现 fast 成功时取消 deep1 的逻辑
    - 实现 fast 失败时等待 deep1 的逻辑
    - _Requirements: 4.1, 4.2, 4.3_

  - [x] 7.2 实现资源清理
    - 确保取消的任务正确清理
    - 保持现有缓存和锁机制
    - _Requirements: 4.5, 4.6_

  - [x] 7.3 编写属性测试：并行扫描
    - **Property 5: Parallel Scan Cancellation**
    - **Property 6: Parallel Scan Fallback**
    - **Validates: Requirements 4.2, 4.3**

- [x] 8. decide.py 逻辑简化
  - [x] 8.1 提取 _episode_aware_fastpass() 函数
    - 从 `decide_best_candidate()` 提取剧集感知快速通道逻辑
    - 添加清晰的参数和返回值文档
    - _Requirements: 3.1_

  - [x] 8.2 提取 _single_candidate_auto_upgrade() 函数
    - 从 `decide_best_candidate()` 提取单候选自动升级逻辑
    - 添加清晰的参数和返回值文档
    - 创建 `_is_collision_risky()` 辅助函数
    - 创建 `SingleCandidateUpgradeResult` 数据类
    - 替换 `decide_best_candidate()` 中的内联代码为函数调用
    - _Requirements: 3.2_

  - [x] 8.3 移动阈值常量到 constants.py
    - 定义 `DECIDE_*` 系列常量
    - 更新 `decide.py` 使用常量
    - _Requirements: 3.3_

  - [x] 8.4 编写属性测试：决策逻辑
    - **Property 14: Evidence Level Auto-Pick Gating**
    - **Property 20: Collision Risk Gate**
    - **Property 21: Mixed Content Gate**
    - **Property 22: Part Movie Gate**
    - **Validates: Requirements 3.4, 15.1-15.4**

- [x] 9. Checkpoint - 阶段 ②⑥ 优化验证
  - 确保所有测试通过
  - 验证并行扫描性能提升
  - 验证决策逻辑一致性

- [x] 10. 缓存签名验证优化
  - [x] 10.1 优化 cache.py 签名验证
    - 实现 v2 content-hash 比较逻辑
    - 实现 v1→v2 自动迁移
    - _Requirements: 7.2, 7.4_

  - [x] 10.2 实现签名不匹配降级
    - 签名不匹配时降级为 weak
    - 继续解析流程
    - _Requirements: 7.3_

  - [x] 10.3 编写属性测试：签名验证
    - **Property 11: Cache Signature Content-Hash Validation**
    - **Property 12: Cache Signature Mismatch Downgrade**
    - **Validates: Requirements 7.2, 7.3**

- [x] 11. 证据质量分级增强
  - [x] 11.1 完善证据等级分类
    - 确保 L0-L3 分类逻辑清晰
    - 实现 count_mismatch 降级
    - _Requirements: 10.1, 10.3_

  - [x] 11.2 增强证据等级门控
    - 确保 L0/L1 阻止 auto-pick
    - 在 decision_trace 中包含证据等级
    - _Requirements: 10.2, 10.4_

  - [x] 11.3 编写属性测试：证据等级
    - **Property 13: Evidence Level Classification**
    - **Validates: Requirements 10.1**

- [x] 12. 提示优先级和年份提取增强
  - [x] 12.1 增强通用标题检测
    - 完善 `_is_generic_share_title()` 模式
    - 实现 video_samples 优先逻辑
    - _Requirements: 11.1_

  - [x] 12.2 增强年份提取
    - 支持多种括号格式
    - 实现频率优先选择
    - _Requirements: 12.1, 12.2, 12.3, 12.4_

  - [x] 12.3 编写属性测试：提示和年份
    - **Property 15: Generic Title Detection**
    - **Property 16: Garbage Hint Filtering**
    - **Property 17: Year Extraction Multi-Format**
    - **Validates: Requirements 11.1, 11.4, 12.1**

- [x] 13. 显式 ID 提取和缓存验证阈值
  - [x] 13.1 增强显式 ID 提取
    - 完善 TMDB ID 模式匹配
    - 实现 IMDb ID 提取和查找
    - _Requirements: 13.1, 13.2_

  - [x] 13.2 配置化缓存验证阈值
    - 确保阈值从 constants.py 读取
    - 实现坏映射禁用逻辑
    - _Requirements: 14.1, 14.2, 14.3, 14.4_

  - [x] 13.3 编写属性测试：ID 提取和缓存验证
    - **Property 18: Explicit TMDB ID Extraction**
    - **Property 19: Cache Validation Thresholds**
    - **Validates: Requirements 13.1, 14.1**

- [x] 14. Checkpoint - 阶段 ①③④ 优化验证
  - 确保所有测试通过
  - 验证缓存命中率
  - 验证提示质量提升

- [x] 15. 自动选择门控增强
  - [x] 15.1 完善碰撞风险门控
    - 实现 collision_risky + support_count 逻辑
    - 设置高阈值要求
    - _Requirements: 15.2_

  - [x] 15.2 完善混合内容和 Part 门控
    - 确保混合内容阻止 auto-pick
    - 确保 Part 标记阻止 auto-pick
    - _Requirements: 15.3, 15.4_

  - [x] 15.3 增强 AutoPickResult
    - 包含 gate_blocked 原因
    - 包含调整后的阈值信息
    - _Requirements: 15.5_

- [x] 16. 单候选升级和学习安全性
  - [x] 16.1 完善单候选升级逻辑
    - 实现 score >= 0.90 + coverage >= 0.90 条件
    - 实现碰撞风险时的高阈值
    - _Requirements: 16.1, 16.2_

  - [x] 16.2 完善学习安全性
    - evidence_weak 时不学习
    - evidence_level < L2 时不学习全局映射
    - _Requirements: 17.1, 17.2_

  - [x] 16.3 完善弱映射持久化
    - score >= 0.75 时持久化弱映射
    - 包含 file_sig
    - _Requirements: 18.1, 18.2_

  - [x] 16.4 编写属性测试：升级和学习
    - **Property 23: Single Candidate Upgrade Threshold**
    - **Property 24: Learning Safety - Evidence Weak**
    - **Property 25: Learning Safety - Evidence Level**
    - **Property 26: Weak Mapping Persistence**
    - **Validates: Requirements 16.1, 17.1, 17.2, 18.1**

- [x] 17. Final Checkpoint - 全链路验证
  - 确保所有 297+ 属性测试通过
  - 运行完整集成测试
  - 验证性能指标
  - 确认无回归

## Notes

- 所有测试任务均为必需，确保全面覆盖
- 每个 Checkpoint 确保增量验证
- 属性测试使用 `hypothesis` 库，最少 100 次迭代
- 所有新模块需要添加到 `__init__.py` 导出

