# Requirements Document

## Introduction

本文档定义了 share_resolver 识别链路的全面优化需求。基于对现有代码的分析，识别出多个可优化的模块和功能点，旨在提升代码可维护性、识别准确率和性能。

## Glossary

- **Hint_Pack**: 从 115 分享链接中提取的搜索提示包，包含标题、年份、季度等信息
- **Evidence**: 从 115 API 获取的分享内容证据，包括文件名、目录结构等
- **Candidate**: TMDB 搜索返回的候选匹配结果
- **Auto_Pick**: 系统自动选择最佳候选的决策过程
- **Alias**: 同一影视作品的不同语言标题（如"大主宰"与"The Great Ruler"）
- **Subtitle_Group**: 字幕组标签（如 [CASO]、[ANi]、[VCB-Studio]）
- **Evidence_Level**: 证据质量等级（L0-L3）

## Requirements

### Requirement 1: hints.py 模块拆分

**User Story:** As a developer, I want the hints.py module to be split into smaller, focused modules, so that the codebase is more maintainable and testable.

#### Acceptance Criteria

1. THE Hints_Module SHALL be split into at least 4 separate sub-modules with clear responsibilities
2. WHEN the split is complete, THE System SHALL maintain all existing functionality without behavioral changes
3. THE Hints_Core module SHALL contain the main `build_hint_pack()` function and basic utilities
4. THE Hints_Detection module SHALL contain all detection functions (multi-season, mixed-content, part-markers, regional-version)
5. THE Hints_Extraction module SHALL contain title/year/batch-title extraction functions
6. THE Hints_Episode module SHALL contain episode set extraction, deduplication, and standard rate calculation
7. THE Hints_Validation module SHALL contain `_is_garbage_hint()`, `clean_hints()`, and related validation functions
8. WHEN any sub-module is imported, THE System SHALL not cause circular import errors
9. THE Original hints.py SHALL re-export all public functions for backward compatibility

### Requirement 2: 多语言标题关联

**User Story:** As a user, I want the system to correctly match Chinese titles with their English equivalents, so that searches like "大主宰" can find "The Great Ruler" on TMDB.

#### Acceptance Criteria

1. WHEN a CJK query is searched, THE System SHALL fetch alternative titles from TMDB API
2. THE System SHALL cache alias mappings with a TTL of at least 1 hour
3. WHEN an alias matches the query, THE System SHALL boost the candidate's score
4. THE Alias_Fetcher SHALL support both movie and TV show alternative titles endpoints
5. IF the TMDB API returns an error, THEN THE System SHALL gracefully fallback to standard search
6. WHEN building the alias index, THE System SHALL normalize titles for comparison (lowercase, remove punctuation)

### Requirement 3: decide.py 逻辑简化

**User Story:** As a developer, I want the decide.py module to have cleaner, more modular logic, so that the auto-pick decision process is easier to understand and maintain.

#### Acceptance Criteria

1. THE Episode_Aware_Fastpass logic SHALL be extracted into a separate function
2. THE Single_Candidate_Auto_Upgrade logic SHALL be extracted into a separate function
3. THE Decision thresholds SHALL be moved to constants.py for easy configuration
4. WHEN the refactor is complete, THE System SHALL produce identical decisions for the same inputs
5. THE decide_best_candidate function SHALL have reduced cyclomatic complexity (target: <15)

### Requirement 4: snapshot.py 并行扫描

**User Story:** As a user, I want faster share evidence fetching, so that the recognition process completes more quickly.

#### Acceptance Criteria

1. WHEN fetching share evidence, THE System SHALL start fast and deep1 scans in parallel
2. IF the fast scan succeeds with strong hints, THEN THE System SHALL cancel the deep1 scan
3. IF the fast scan fails or has weak hints, THEN THE System SHALL wait for deep1 results
4. THE Parallel_Scan SHALL reduce average scan time by at least 30%
5. WHEN a scan is cancelled, THE System SHALL properly clean up resources
6. THE System SHALL maintain the existing cache and lock mechanisms

### Requirement 5: 字幕组识别

**User Story:** As a user, I want the system to recognize subtitle group tags, so that quality and region information can improve matching accuracy.

#### Acceptance Criteria

1. THE System SHALL detect common subtitle group tags (CASO, ANi, VCB-Studio, etc.)
2. WHEN a subtitle group is detected, THE System SHALL extract quality and region metadata
3. THE Subtitle_Group information SHALL be included in the hint pack
4. WHEN scoring candidates, THE System MAY use subtitle group quality as a tiebreaker
5. THE Subtitle_Group detection SHALL support both bracket formats: [Group] and 【Group】

### Requirement 6: TMDB 搜索结果缓存

**User Story:** As a system operator, I want TMDB search results to be cached, so that repeated searches don't consume API quota unnecessarily.

#### Acceptance Criteria

1. THE System SHALL cache TMDB search results with a configurable TTL (default: 1 hour)
2. WHEN a cached result exists and is not expired, THE System SHALL return it without API call
3. THE Cache key SHALL include query, year, and media_type
4. THE Cache SHALL have a maximum size limit to prevent memory issues
5. WHEN the cache is full, THE System SHALL evict the oldest entries (LRU policy)
6. THE Cache statistics SHALL be logged for monitoring purposes

---

## 阶段 ① 初始化与缓存快速路径优化

### Requirement 7: 缓存签名验证优化

**User Story:** As a user, I want faster cache validation, so that previously resolved shares return results immediately.

#### Acceptance Criteria

1. WHEN a strong cached mapping exists without file_sig, THE System SHALL return immediately without evidence fetch
2. WHEN a strong cached mapping has file_sig, THE System SHALL validate using content-hash only (ignore filename changes)
3. IF file_sig validation fails, THEN THE System SHALL downgrade to weak mapping and continue resolution
4. THE System SHALL support automatic v1 to v2 signature migration
5. WHEN receive_code is missing but cached, THE System SHALL reuse the cached receive_code

### Requirement 8: 缓存预热机制

**User Story:** As a system operator, I want popular shares to be pre-cached, so that common requests are faster.

#### Acceptance Criteria

1. THE System MAY pre-warm cache for frequently accessed share_codes
2. WHEN a share is accessed multiple times within a window, THE System SHALL increase its cache priority
3. THE Cache_Warmer SHALL run as a background task without blocking main requests

---

## 阶段 ② 115 证据获取优化

### Requirement 9: 证据获取重试策略

**User Story:** As a user, I want the system to handle temporary 115 API failures gracefully, so that transient errors don't cause resolution failures.

#### Acceptance Criteria

1. WHEN 115 API returns rate limit error, THE System SHALL wait and retry with exponential backoff
2. THE System SHALL distinguish between temporary unavailable and permanent failures
3. WHEN evidence fetch fails temporarily, THE System SHALL NOT persist any weak mappings
4. THE System SHALL log detailed error information for debugging
5. IF all retries fail, THEN THE System SHALL return a clear error reason to the user

### Requirement 10: 证据质量分级增强

**User Story:** As a developer, I want clearer evidence quality levels, so that auto-pick decisions are more accurate.

#### Acceptance Criteria

1. THE System SHALL classify evidence into 4 levels: L0 (unavailable), L1 (title-only), L2 (video-sample), L3 (multi-video)
2. WHEN evidence_level is L0 or L1, THE System SHALL NEVER auto-pick
3. WHEN count_mismatch is detected, THE System SHALL downgrade evidence_level by 1
4. THE Evidence_Level SHALL be included in all decision traces for debugging

---

## 阶段 ③ 构造搜索提示优化

### Requirement 11: 提示优先级智能排序

**User Story:** As a user, I want the system to prioritize the most informative hints, so that TMDB searches are more accurate.

#### Acceptance Criteria

1. WHEN share_title is generic (e.g., "合集", "资源"), THE System SHALL prioritize video_samples instead
2. THE System SHALL extract batch_title from multiple video filenames for stable hints
3. WHEN CJK share_title exists, THE System SHALL prioritize it over English filenames
4. THE System SHALL filter out garbage hints (pure digits, extensions, common tags)
5. THE Hint_Quality_Score SHALL consider CJK presence, length, and specificity

### Requirement 12: 年份提取增强

**User Story:** As a user, I want accurate year extraction from various formats, so that year-based filtering works correctly.

#### Acceptance Criteria

1. THE System SHALL extract years from parentheses: "剧名(2025)", "剧名（2025）", "剧名[2025]"
2. WHEN multiple years are found, THE System SHALL prefer the most frequent one
3. IF no explicit year is found, THE System SHALL scan all evidence texts for plausible years
4. THE Year_Extractor SHALL handle both 19xx and 20xx year ranges

---

## 阶段 ④ 预解析优化

### Requirement 13: 显式 ID 提取增强

**User Story:** As a user, I want the system to recognize TMDB/IMDb IDs in filenames, so that explicit IDs bypass search.

#### Acceptance Criteria

1. THE System SHALL extract explicit TMDB IDs from patterns: tmdb:123, tmdbid-123, {tmdbid-123}
2. THE System SHALL extract IMDb IDs and lookup via TMDB /find endpoint
3. WHEN explicit ID is found but no title, THE System SHALL recover title by stripping ID tokens
4. IF explicit ID validation fails (low similarity), THEN THE System SHALL fallback to search

### Requirement 14: 缓存验证阈值优化

**User Story:** As a developer, I want configurable cache validation thresholds, so that cache hit rates can be tuned.

#### Acceptance Criteria

1. THE Title_Cache validation SHALL require confidence >= 0.82 and coverage >= 0.60
2. THE Series_Cache validation SHALL require confidence >= 0.80
3. WHEN validation fails with score < 0.72, THE System SHALL disable the bad mapping
4. THE Validation_Thresholds SHALL be configurable via constants.py

---

## 阶段 ⑥ 决策优化

### Requirement 15: 自动选择门控增强

**User Story:** As a user, I want safer auto-pick decisions, so that wrong matches are minimized.

#### Acceptance Criteria

1. WHEN evidence_level <= L1, THE System SHALL block auto-pick regardless of scores
2. WHEN collision_risky is True AND support_count < 2, THE System SHALL require score >= 0.97
3. WHEN mixed content (movie + TV) is detected, THE System SHALL block auto-pick
4. WHEN Part markers (Part 1/2/3) are detected, THE System SHALL block auto-pick
5. THE Auto_Pick_Result SHALL include gate_blocked reason for debugging

### Requirement 16: 单候选自动升级优化

**User Story:** As a user, I want single high-confidence candidates to be auto-picked, so that obvious matches don't require manual selection.

#### Acceptance Criteria

1. WHEN only 1 candidate exists with score >= 0.90 and coverage >= 0.90, THE System MAY auto-pick
2. IF title contains collision-risky words, THEN THE System SHALL require score >= 0.95
3. THE Single_Candidate_Upgrade SHALL fetch TMDB details for final validation
4. WHEN year mismatch >= 2 years, THE System SHALL NOT auto-upgrade to strong

---

## 阶段 ⑦ 持久化优化

### Requirement 17: 学习映射安全性

**User Story:** As a system operator, I want safe learning of title/series mappings, so that bad mappings don't pollute future resolutions.

#### Acceptance Criteria

1. WHEN evidence_weak is True, THE System SHALL NOT learn title/series mappings
2. WHEN evidence_level < L2, THE System SHALL NOT learn any global mappings
3. THE System SHALL only learn series mappings on strong auto-pick
4. WHEN learning series mappings, THE System SHALL include both Chinese and English titles

### Requirement 18: 弱映射持久化策略

**User Story:** As a user, I want weak mappings to help future resolutions, so that repeated requests are faster.

#### Acceptance Criteria

1. WHEN auto-pick fails but top candidate score >= 0.75, THE System SHALL persist as weak mapping
2. THE Weak_Mapping SHALL include file_sig for future validation
3. WHEN weak mapping is validated successfully, THE System MAY upgrade to strong
4. THE System SHALL create pending_choice tokens for user correction

