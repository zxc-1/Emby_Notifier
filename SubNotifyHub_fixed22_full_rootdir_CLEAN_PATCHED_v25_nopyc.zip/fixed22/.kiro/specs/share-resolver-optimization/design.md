# Design Document: Share Resolver 全链路优化

## Overview

本设计文档描述了 share_resolver 识别链路的全面优化方案，覆盖 7 个阶段的 18 个需求。优化目标包括：

1. **可维护性提升** - 拆分大型模块，降低复杂度
2. **识别准确率提升** - 多语言标题关联、字幕组识别、智能提示排序
3. **性能优化** - 并行扫描、搜索缓存、缓存预热
4. **安全性增强** - 多重门控、学习安全性、弱映射策略

## Architecture

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           Share Resolver Pipeline                            │
├─────────────────────────────────────────────────────────────────────────────┤
│                                                                              │
│  ① 初始化与缓存快速路径                                                       │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐                   │
│  │  usecase.py  │───▶│   cache.py   │───▶│ signatures.py│                   │
│  └──────────────┘    └──────────────┘    └──────────────┘                   │
│         │                   │                                                │
│         ▼                   ▼                                                │
│  ② 115 证据获取                                                              │
│  ┌──────────────┐    ┌──────────────┐                                       │
│  │ snapshot.py  │───▶│ gateways.py  │  ← 并行扫描优化                        │
│  └──────────────┘    └──────────────┘                                       │
│         │                                                                    │
│         ▼                                                                    │
│  ③ 构造搜索提示                                                              │
│  ┌──────────────────────────────────────────────────────┐                   │
│  │                    hints/ (拆分后)                    │                   │
│  │  ┌────────────┐ ┌────────────┐ ┌────────────┐       │                   │
│  │  │hints_core  │ │hints_detect│ │hints_extract│       │                   │
│  │  └────────────┘ └────────────┘ └────────────┘       │                   │
│  │  ┌────────────┐ ┌────────────┐ ┌────────────┐       │                   │
│  │  │hints_episode│ │hints_valid │ │hints_subtitle│ NEW │                   │
│  │  └────────────┘ └────────────┘ └────────────┘       │                   │
│  └──────────────────────────────────────────────────────┘                   │
│         │                                                                    │
│         ▼                                                                    │
│  ④ 预解析                                                                    │
│  ┌──────────────┐    ┌──────────────────┐                                   │
│  │pre_resolve.py│───▶│cache_validation.py│                                   │
│  └──────────────┘    └──────────────────┘                                   │
│         │                                                                    │
│         ▼                                                                    │
│  ⑤ TMDB 候选生成与合并                                                       │
│  ┌──────────────┐    ┌──────────────────┐    ┌──────────────┐               │
│  │tmdb_lookup.py│───▶│candidate_merge.py│───▶│ title_alias.py│ NEW          │
│  └──────────────┘    └──────────────────┘    └──────────────┘               │
│         │                    │                                               │
│         │              ┌─────┴─────┐                                         │
│         │              │search_cache│ NEW                                    │
│         │              └───────────┘                                         │
│         ▼                                                                    │
│  ⑥ 决策                                                                      │
│  ┌──────────────┐    ┌──────────────┐                                       │
│  │  decide.py   │───▶│ autopick.py  │  ← 逻辑简化                            │
│  └──────────────┘    └──────────────┘                                       │
│         │                                                                    │
│         ▼                                                                    │
│  ⑦ 持久化与返回                                                              │
│  ┌──────────────┐    ┌──────────────┐                                       │
│  │  persist.py  │───▶│   repo.py    │                                       │
│  └──────────────┘    └──────────────┘                                       │
│                                                                              │
└─────────────────────────────────────────────────────────────────────────────┘
```

## Components and Interfaces

### 1. hints/ 模块拆分 (Requirement 1)

将 1009 行的 `hints.py` 拆分为 6 个子模块：

```python
# hints/__init__.py - 向后兼容的重导出
from .hints_core import build_hint_pack, pick_best_hint, clean_hints
from .hints_detection import (
    _detect_multi_season_markers,
    _detect_mixed_content,
    _detect_part_markers,
    _detect_regional_version,
)
from .hints_extraction import (
    _extract_share_fragment_hint,
    _extract_batch_title,
    _extract_strict_year,
    _prioritize_video_samples,
)
from .hints_episode import (
    _extract_episode_set,
    # episode dedup functions
)
from .hints_validation import (
    _is_garbage_hint,
    _is_generic_share_title,
    _fast_hint_strong,
)
from .hints_subtitle import (
    detect_subtitle_group,
    SUBTITLE_GROUPS,
)
```

### 2. title_alias.py - 多语言标题关联 (Requirement 2)

```python
# application/usecases/share_resolver/title_alias.py

from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
import time

@dataclass
class AliasCache:
    """Alias cache entry."""
    aliases: List[str]
    timestamp: float
    tmdb_id: int
    media_type: str

# In-memory cache with TTL
_ALIAS_CACHE: Dict[Tuple[int, str], AliasCache] = {}
_ALIAS_CACHE_TTL_SEC = 3600  # 1 hour

async def fetch_title_aliases(
    tmdb_id: int,
    media_type: str,
    *,
    timeout: float = 3.0,
) -> List[str]:
    """Fetch alternative titles from TMDB API.
    
    Calls:
    - /movie/{id}/alternative_titles for movies
    - /tv/{id}/alternative_titles for TV shows
    
    Returns list of alternative titles (all languages).
    """
    pass

def normalize_alias(title: str) -> str:
    """Normalize title for comparison.
    
    - Lowercase
    - Remove punctuation
    - Normalize whitespace
    """
    pass

def compute_alias_similarity(query: str, alias: str) -> float:
    """Compute similarity between query and alias.
    
    Uses normalized comparison with fuzzy matching.
    """
    pass

async def boost_candidates_with_aliases(
    candidates: List[Dict],
    query_title: str,
    *,
    boost_factor: float = 0.08,
) -> List[Dict]:
    """Boost candidate scores when aliases match query.
    
    For each candidate:
    1. Fetch aliases (cached)
    2. Check if query matches any alias
    3. If match, boost score by boost_factor
    """
    pass
```

### 3. search_cache.py - TMDB 搜索缓存 (Requirement 6)

```python
# application/usecases/share_resolver/search_cache.py

from typing import Any, Dict, List, Optional, Tuple
from collections import OrderedDict
import time
import threading

class LRUSearchCache:
    """LRU cache for TMDB search results."""
    
    def __init__(
        self,
        max_size: int = 1000,
        ttl_sec: float = 3600.0,
    ):
        self._cache: OrderedDict[str, Tuple[float, List[Dict]]] = OrderedDict()
        self._max_size = max_size
        self._ttl_sec = ttl_sec
        self._lock = threading.Lock()
        self._stats = {"hits": 0, "misses": 0, "evictions": 0}
    
    def _make_key(self, query: str, year: Optional[int], media_type: str) -> str:
        """Generate cache key from search parameters."""
        return f"{query.lower().strip()}|{year or ''}|{media_type.lower()}"
    
    def get(self, query: str, year: Optional[int], media_type: str) -> Optional[List[Dict]]:
        """Get cached results if not expired."""
        pass
    
    def set(self, query: str, year: Optional[int], media_type: str, results: List[Dict]) -> None:
        """Cache search results with LRU eviction."""
        pass
    
    def get_stats(self) -> Dict[str, int]:
        """Get cache statistics."""
        return dict(self._stats)

# Global cache instance
_SEARCH_CACHE = LRUSearchCache()

async def cached_tmdb_search(
    query: str,
    year: Optional[int],
    media_type: str,
    *,
    searcher: Any,
) -> List[Dict]:
    """Search TMDB with caching."""
    pass
```

### 4. hints_subtitle.py - 字幕组识别 (Requirement 5)

```python
# application/usecases/share_resolver/hints_subtitle.py

from typing import Dict, List, Optional
from dataclasses import dataclass
import re

@dataclass
class SubtitleGroupInfo:
    """Subtitle group metadata."""
    name: str
    quality: str  # "standard", "high", "premium"
    region: str   # "CN", "JP", "KR", etc.
    tags: List[str]

# Known subtitle groups database
SUBTITLE_GROUPS: Dict[str, SubtitleGroupInfo] = {
    "CASO": SubtitleGroupInfo("CASO", "high", "CN", ["动漫"]),
    "ANi": SubtitleGroupInfo("ANi", "high", "JP", ["动漫"]),
    "VCB-Studio": SubtitleGroupInfo("VCB-Studio", "premium", "JP", ["动漫", "高码率"]),
    "FZSD": SubtitleGroupInfo("FZSD", "high", "CN", ["电视剧"]),
    "CMCT": SubtitleGroupInfo("CMCT", "high", "CN", ["电影"]),
    "CHD": SubtitleGroupInfo("CHD", "high", "CN", ["电影"]),
    "MTeam": SubtitleGroupInfo("MTeam", "high", "CN", ["综合"]),
    "HDSky": SubtitleGroupInfo("HDSky", "high", "CN", ["综合"]),
    # ... more groups
}

# Patterns for subtitle group detection
_SUBTITLE_GROUP_PATTERNS = [
    re.compile(r"\[([A-Za-z0-9\-_]+(?:[-_][A-Za-z0-9]+)*)\]"),  # [Group-Name]
    re.compile(r"【([A-Za-z0-9\-_\u4e00-\u9fff]+)】"),           # 【字幕组】
    re.compile(r"@([A-Za-z0-9\-_]+)"),                          # @Group
]

def detect_subtitle_group(text: str) -> Optional[SubtitleGroupInfo]:
    """Detect subtitle group from text.
    
    Searches for known subtitle group tags in various formats:
    - [CASO], [ANi], [VCB-Studio]
    - 【字幕组】
    - @Group
    
    Returns SubtitleGroupInfo if found, None otherwise.
    """
    pass

def extract_all_subtitle_groups(texts: List[str]) -> List[SubtitleGroupInfo]:
    """Extract all subtitle groups from multiple texts."""
    pass
```

### 5. snapshot.py 并行扫描 (Requirement 4)

```python
# 修改 fetch_share_evidence 函数

async def fetch_share_evidence_parallel(
    *,
    share_url: str,
    share_code: str,
    receive_code: str,
    decision_trace: Optional[list[str]] = None,
) -> dict[str, Any]:
    """Fetch share evidence using parallel fast+deep strategy.
    
    Strategy:
    1. Start fast_scan and deep1_scan in parallel
    2. If fast_scan succeeds with strong hints, cancel deep1_scan
    3. If fast_scan fails/weak, wait for deep1_scan
    4. If deep1_scan fails, try deep2_scan
    """
    # ... existing cache/lock logic ...
    
    async with lk:
        # Start both scans in parallel
        fast_task = asyncio.create_task(
            _do_fast_scan(share_code, receive_code, fast_timeout)
        )
        deep1_task = asyncio.create_task(
            _do_deep1_scan(share_code, receive_code, deep1_timeout, deep1_depth, deep1_scans)
        )
        
        # Wait for fast scan first
        try:
            fast_result = await asyncio.wait_for(fast_task, timeout=fast_timeout)
            if _is_strong_evidence(fast_result):
                # Cancel deep1 and return fast result
                deep1_task.cancel()
                try:
                    await deep1_task
                except asyncio.CancelledError:
                    pass
                return fast_result
        except (asyncio.TimeoutError, Exception):
            pass
        
        # Fast scan failed/weak, wait for deep1
        try:
            deep1_result = await deep1_task
            if deep1_result.get("ok"):
                return deep1_result
        except asyncio.CancelledError:
            pass
        except Exception:
            pass
        
        # Fallback to deep2
        return await _do_deep2_scan(...)
```

### 6. decide.py 逻辑简化 (Requirement 3)

```python
# 提取独立函数

async def _episode_aware_fastpass(
    cands_all: List[Dict],
    used_season: Optional[int],
    ev_level: int,
    count_mismatch: bool,
    standard_rate: float,
    episode_set: Optional[List[int]],
    episode_best_files: Optional[List[Dict]],
) -> Tuple[bool, str]:
    """Episode-aware fast-pass for TV shows.
    
    Returns (ok_pick, reason).
    """
    pass

async def _single_candidate_auto_upgrade(
    picked: Dict,
    cands_all: List[Dict],
    q_title: str,
    q_year: Optional[int],
    has_main_hint: bool,
    force_mt: Optional[str],
) -> Tuple[str, float, float, float]:
    """Single candidate auto-upgrade logic.
    
    Returns (auto_strength, auto_score, auto_cov, auto_gap).
    """
    pass

# 阈值移到 constants.py
# constants.py 新增:
DECIDE_EPISODE_SIM_THRESHOLD = 0.95
DECIDE_EPISODE_SCORE_THRESHOLD = 0.45
DECIDE_EPISODE_GAP_THRESHOLD = 0.10
DECIDE_EPISODE_COV_THRESHOLD = 0.55
DECIDE_SINGLE_SCORE_THRESHOLD = 0.90
DECIDE_SINGLE_COV_THRESHOLD = 0.90
DECIDE_COLLISION_SCORE_THRESHOLD = 0.95
DECIDE_COLLISION_COV_THRESHOLD = 0.92
```

## Data Models

### AliasMapping

```python
@dataclass
class AliasMapping:
    """Cached alias mapping."""
    tmdb_id: int
    media_type: str
    original_title: str
    aliases: List[str]  # All alternative titles
    normalized_aliases: List[str]  # Normalized for comparison
    fetched_at: float
```

### SubtitleGroupInfo

```python
@dataclass
class SubtitleGroupInfo:
    """Subtitle group metadata."""
    name: str
    quality: str  # "standard", "high", "premium"
    region: str   # "CN", "JP", "KR", etc.
    tags: List[str]
```

### SearchCacheEntry

```python
@dataclass
class SearchCacheEntry:
    """TMDB search cache entry."""
    query: str
    year: Optional[int]
    media_type: str
    results: List[Dict]
    cached_at: float
    hit_count: int
```

## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*



### Property 1: Refactor Preserves Behavior (Round-Trip)

*For any* valid input to `build_hint_pack()` or `decide_best_candidate()`, the output after module refactoring SHALL be identical to the output before refactoring.

**Validates: Requirements 1.2, 3.4**

### Property 2: Alias Matching Boosts Scores

*For any* candidate with an alternative title that matches the query (similarity >= 0.85), the candidate's score SHALL be higher than without alias matching.

**Validates: Requirements 2.3**

### Property 3: Alias Cache TTL Enforcement

*For any* alias fetch, if a cached entry exists and is within TTL, the system SHALL return cached results without making an API call.

**Validates: Requirements 2.2**

### Property 4: Alias Normalization Consistency

*For any* title string, normalizing it twice SHALL produce the same result (idempotent), and the normalized form SHALL be lowercase without punctuation.

**Validates: Requirements 2.6**

### Property 5: Parallel Scan Cancellation

*For any* share evidence fetch where fast scan succeeds with strong hints, the deep1 scan task SHALL be cancelled and not awaited to completion.

**Validates: Requirements 4.2**

### Property 6: Parallel Scan Fallback

*For any* share evidence fetch where fast scan fails or returns weak hints, the system SHALL wait for and use deep1 scan results.

**Validates: Requirements 4.3**

### Property 7: Subtitle Group Detection

*For any* text containing a known subtitle group tag in either `[Group]` or `【Group】` format, the detection function SHALL return the correct SubtitleGroupInfo.

**Validates: Requirements 5.1, 5.5**

### Property 8: Subtitle Group Metadata Extraction

*For any* detected subtitle group, the returned SubtitleGroupInfo SHALL contain non-empty quality and region fields.

**Validates: Requirements 5.2**

### Property 9: Search Cache LRU Eviction

*For any* sequence of cache insertions exceeding max_size, the cache SHALL evict the least recently used entries first, maintaining size <= max_size.

**Validates: Requirements 6.4, 6.5**

### Property 10: Search Cache Key Uniqueness

*For any* two searches with different (query, year, media_type) combinations, they SHALL have different cache keys and be cached separately.

**Validates: Requirements 6.3**

### Property 11: Cache Signature Content-Hash Validation

*For any* v2 signature comparison, only the content-hash portion SHALL be compared, ignoring filename changes.

**Validates: Requirements 7.2**

### Property 12: Cache Signature Mismatch Downgrade

*For any* strong cached mapping where file_sig validation fails, the mapping SHALL be downgraded to weak and resolution SHALL continue.

**Validates: Requirements 7.3**

### Property 13: Evidence Level Classification

*For any* share evidence, the system SHALL classify it into exactly one of L0 (unavailable), L1 (title-only), L2 (video-sample), or L3 (multi-video).

**Validates: Requirements 10.1**

### Property 14: Evidence Level Auto-Pick Gating

*For any* resolution where evidence_level <= L1, auto-pick SHALL be blocked regardless of candidate scores.

**Validates: Requirements 10.2, 15.1**

### Property 15: Generic Title Detection

*For any* share_title matching generic patterns (e.g., "合集", "资源", "1080p"), the system SHALL prioritize video_samples over share_title in hints.

**Validates: Requirements 11.1**

### Property 16: Garbage Hint Filtering

*For any* hint that is pure digits, file extensions, or common tags, the `_is_garbage_hint()` function SHALL return True.

**Validates: Requirements 11.4**

### Property 17: Year Extraction Multi-Format

*For any* title containing a year in parentheses format (e.g., "(2025)", "（2025）", "[2025]"), the year extractor SHALL correctly extract the year.

**Validates: Requirements 12.1**

### Property 18: Explicit TMDB ID Extraction

*For any* text containing explicit TMDB ID patterns (tmdb:123, tmdbid-123, {tmdbid-123}), the extractor SHALL return the correct ID.

**Validates: Requirements 13.1**

### Property 19: Cache Validation Thresholds

*For any* title cache hit with confidence < 0.82 or coverage < 0.60, the validation SHALL fail and return rejection reason.

**Validates: Requirements 14.1**

### Property 20: Collision Risk Gate

*For any* query with collision_risky=True AND support_count < 2, auto-pick SHALL be blocked unless score >= 0.97 AND coverage >= 0.92.

**Validates: Requirements 15.2**

### Property 21: Mixed Content Gate

*For any* share containing both movie and TV markers, auto-pick SHALL be blocked.

**Validates: Requirements 15.3**

### Property 22: Part Movie Gate

*For any* share containing Part 1/2/3 markers, auto-pick SHALL be blocked.

**Validates: Requirements 15.4**

### Property 23: Single Candidate Upgrade Threshold

*For any* single candidate with score >= 0.90 AND coverage >= 0.90, the system MAY auto-pick; if collision-risky, require score >= 0.95.

**Validates: Requirements 16.1, 16.2**

### Property 24: Learning Safety - Evidence Weak

*For any* resolution where evidence_weak=True, the system SHALL NOT learn title or series mappings.

**Validates: Requirements 17.1**

### Property 25: Learning Safety - Evidence Level

*For any* resolution where evidence_level < L2, the system SHALL NOT learn any global mappings.

**Validates: Requirements 17.2**

### Property 26: Weak Mapping Persistence

*For any* resolution where auto-pick fails but top candidate score >= 0.75, the system SHALL persist a weak mapping with file_sig.

**Validates: Requirements 18.1, 18.2**

## Error Handling

### TMDB API Errors

- **Rate Limiting**: Exponential backoff with max 3 retries
- **Timeout**: Configurable timeout (default 3s), fallback to cached results
- **Network Errors**: Log and continue with degraded functionality

### 115 API Errors

- **Rate Limiting**: Classify as `temp_unavailable`, do not persist mappings
- **Invalid Share**: Return clear error reason
- **Timeout**: Retry with increasing depth limits

### Cache Errors

- **Memory Pressure**: LRU eviction, configurable max size
- **Corruption**: Clear and rebuild on next access

## Testing Strategy

### Unit Tests

- Test each extracted function in isolation
- Test cache operations (get/set/evict)
- Test detection functions with known inputs
- Test normalization and similarity functions

### Property-Based Tests

使用 `hypothesis` 库进行属性测试，每个属性至少运行 100 次迭代。

测试标注格式：`**Feature: share-resolver-optimization, Property {number}: {property_text}**`

### Integration Tests

- End-to-end resolution with mocked TMDB/115 APIs
- Cache hit/miss scenarios
- Parallel scan cancellation verification

### Performance Tests

- Benchmark parallel vs sequential scanning
- Cache hit rate measurement
- Memory usage under load

