<!-- 用于 $clear-plan 命令，清空当前项目所有计划文档与 MCP 任务，包含危险确认与清理流程。 -->

# 清空所有计划

清空当前项目的所有计划文档和 MCP 任务 #$ARGUMENTS。

---

## ⚠️ 危险操作警告

**此操作将永久删除**：
- `.codex/plans/current/` 中的所有计划文档
- `.codex/plans/archive/` 中的所有归档文档
- MCP 中的所有任务记录

**不可恢复**（除非有 Git 版本控制）

---

## 核心概念

**清空 = 完全重新开始**：删除所有计划相关内容，让项目回到"从未使用过计划系统"的状态。

**使用场景**：
- 项目计划体系需要完全重建
- 切换到新的项目阶段，旧计划不再需要
- 测试/演示环境清理
- 计划数据严重混乱，需要彻底清理

---

## 与其他指令的区别

| 指令 | 操作强度 | 保留内容 | 删除内容 |
|------|---------|---------|---------|
| `$reset-plan` | ★☆☆ 轻 | 计划文档、步骤定义 | 执行进度、记录、MCP 状态 |
| `$clean-plan` | ★★☆ 中 | 活跃计划 | 已完成计划（归档）、旧归档 |
| `$clear-plan` | ★★★ 重 | **无** | **所有计划文档 + MCP 任务** |

---

## 执行流程

### 1. 扫描现有计划

```bash
# 统计计划文件
ls -la .codex/plans/current/*.md 2>/dev/null | wc -l
ls -la .codex/plans/archive/*.md 2>/dev/null | wc -l
ls -la .codex/plans/backup/*.md 2>/dev/null | wc -l
```

```
# 获取 MCP 任务统计
mcp__mcp-router__list_tasks({ status: "all" })
```

### 2. 展示将被删除的内容

```markdown
## [DANGER] 即将清空所有计划

**项目**：[项目名称/路径]

### 将被删除的内容

| 位置 | 文件数 | 说明 |
|------|--------|------|
| current/ | X 个 | 活跃计划 |
| archive/ | X 个 | 已归档计划 |
| backup/ | X 个 | 备份文件 |
| MCP 任务 | X 个 | 任务记录 |

**总计**：X 个文件 + X 个 MCP 任务

### 详细文件列表

**current/**：
- 2025-12-22_feature-a.md（执行中，进度 3/5）
- 2025-12-21_bugfix-b.md（待审批）

**archive/**：
- 2025-12-20_refactor-c.md（已完成）
- 2025-12-19_setup-d.md（已完成）

---

⚠️ **警告**：此操作不可恢复！
```

### 3. 多重确认

**第一次确认**（选择菜单）：

```
问题：确认要清空所有 X 个计划文档和 X 个 MCP 任务？此操作不可恢复！
header: "清空确认"
选项：
1. ??? 确认清空所有计划 — 永久删除所有计划文档和 MCP 任务
2. ?? 先备份再清空 — 创建完整备份后再执行清空
3. ? 取消操作 — 不执行任何操作
```

**第二次确认**（如果选择"确认清空"）：

```
问题：?? 最终确认：输入项目名称「[项目名]」以确认清空操作
header: "最终确认"
选项：
1. 我已确认，执行清空 — 我理解此操作不可恢复，确认执行
2. 我再想想 — 取消操作，返回
```

### 4. 创建备份（可选）

如果用户选择"先备份再清空"：

```bash
# 创建带时间戳的备份目录
backup_dir=".codex/plans-backup-$(date +%Y%m%d_%H%M%S)"
mkdir -p "$backup_dir"

# 复制所有计划文件
cp -r .codex/plans/current/ "$backup_dir/"
cp -r .codex/plans/archive/ "$backup_dir/"
cp -r .codex/plans/backup/ "$backup_dir/" 2>/dev/null
```

输出：
```markdown
## [OK] 备份已创建

**备份位置**：.codex/plans-backup-20251222_103000/
**备份内容**：
- current/：X 个文件
- archive/：X 个文件
- backup/：X 个文件

**总大小**：XXX KB

继续执行清空操作...
```

### 5. 执行清空

#### 5.1 清空本地文件

```bash
# 删除所有计划文件
rm -rf .codex/plans/current/*.md
rm -rf .codex/plans/archive/*.md
rm -rf .codex/plans/backup/*.md

# 保留目录结构（可选）
# 或完全删除目录：rm -rf .codex/plans/
```

#### 5.2 清空 MCP 任务

```
mcp__mcp-router__clear_all_tasks({ confirm: true })
```

### 6. 输出清空结果

```markdown
## [OK] 所有计划已清空

**项目**：[项目名称/路径]

### 已删除内容

| 位置 | 删除数量 |
|------|----------|
| current/ | X 个文件 |
| archive/ | X 个文件 |
| backup/ | X 个文件 |
| MCP 任务 | X 个 |

### 当前状态

```
.codex/
└── plans/
    ├── current/    ← 空
    ├── archive/    ← 空
    └── backup/     ← 空
```

**MCP 任务**：0 个

---

**下一步操作**：
- `$plan [需求]` — 创建新计划
- 如有备份：备份位于 `.codex/plans-backup-XXXXXXXX/`

🧹 计划系统已重置，可以重新开始！
```

---

## 特殊参数处理

| 参数 | 行为 |
|------|------|
| 无参数 | 交互式确认后清空所有计划 |
| `--yes`, `-y` | 跳过第一次确认（仍需第二次确认） |
| `--force`, `-F` | 跳过所有确认（危险！） |
| `--backup` | 强制先备份再清空 |
| `--no-backup` | 不创建备份 |
| `--keep-structure` | 保留目录结构，只删除文件 |
| `--current-only` | 只清空 current/ 目录 |
| `--archive-only` | 只清空 archive/ 目录 |
| `--mcp-only` | 只清空 MCP 任务，不删除本地文件 |
| `--dry-run` | 预览将被删除的内容，不实际执行 |

### 参数组合示例

```bash
# 只清空当前活跃计划，保留归档
$clear-plan --current-only

# 强制清空（跳过所有确认）- 慎用！
$clear-plan --force

# 预览将被删除的内容
$clear-plan --dry-run

# 备份后清空，保留目录结构
$clear-plan --backup --keep-structure
```

---

## 恢复选项

### 从备份恢复

如果之前选择了"先备份再清空"：

```bash
# 恢复备份
cp -r .codex/plans-backup-XXXXXXXX/* .codex/plans/
```

### 从 Git 恢复

如果项目使用 Git 版本控制：

```bash
# 查看 .codex/plans/ 的历史版本
git log --oneline -- .codex/plans/

# 恢复到特定版本
git checkout [commit-hash] -- .codex/plans/
```

---

## 注意事项

1. **此操作不可恢复**——除非有备份或 Git 版本控制
2. **建议先备份**——除非确定不需要历史记录
3. **MCP 任务无法恢复**——MCP 不保留历史版本
4. **考虑使用其他指令**：
   - 只想重置某个计划？用 `$reset-plan`
   - 只想归档已完成的？用 `$clean-plan`
5. **团队项目谨慎使用**——可能影响其他成员的工作

---

## 快捷操作

- `$plan [需求]` — 创建新计划
- `$show-plan` — 查看计划列表
- `$do-plan` — 执行计划
- `$reset-plan` — 重置计划进度
- `$clean-plan` — 归档和清理计划
- `$clear-plan` — 清空所有计划（当前指令）
